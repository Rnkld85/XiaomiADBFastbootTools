import java.net.URLConnection;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.GlobalScope;
import org.jetbrains.annotations.Nullable;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import org.jetbrains.annotations.NotNull;
import kotlinx.coroutines.CoroutineScope;
import javafx.scene.control.Label;
import java.io.File;
import java.net.URL;
import kotlin.Metadata;

// 
// Decompiled by Procyon v0.5.36
// 

@Metadata(mv = { 1, 4, 0 }, bv = { 1, 0, 3 }, k = 1, d1 = { "\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0006\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bJ\u001b\u0010\u0014\u001a\u00020\u00152\b\b\u0002\u0010\u0016\u001a\u00020\u0017H\u0086@\u00f8\u0001\u0000¢\u0006\u0002\u0010\u0018R\u0014\u0010\t\u001a\u00020\n8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\fR\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\u00020\n8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\fR\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006\u0019" }, d2 = { "LDownloader;", "", "link", "", "target", "Ljava/io/File;", "progressLabel", "Ljavafx/scene/control/Label;", "(Ljava/lang/String;Ljava/io/File;Ljavafx/scene/control/Label;)V", "progress", "", "getProgress", "()F", "size", "speed", "getSpeed", "startTime", "", "url", "Ljava/net/URL;", "start", "", "scope", "Lkotlinx/coroutines/CoroutineScope;", "(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "XiaomiADBFastbootTools" })
public final class Downloader
{
    private final URL url;
    private final float size;
    private long startTime;
    private final File target;
    private final Label progressLabel;
    
    private final float getProgress() {
        return this.target.length() / this.size * 100.0f;
    }
    
    private final float getSpeed() {
        return this.target.length() / ((System.currentTimeMillis() - this.startTime) / 1000.0f);
    }
    
    @Nullable
    public final Object start(@NotNull final CoroutineScope scope, @NotNull final Continuation<? super Unit> $completion) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: instanceof      LDownloader$start$1;
        //     4: ifeq            39
        //     7: aload_2         /* $completion */
        //     8: checkcast       LDownloader$start$1;
        //    11: astore          7
        //    13: aload           7
        //    15: getfield        Downloader$start$1.label:I
        //    18: ldc             -2147483648
        //    20: iand           
        //    21: ifeq            39
        //    24: aload           7
        //    26: dup            
        //    27: getfield        Downloader$start$1.label:I
        //    30: ldc             -2147483648
        //    32: isub           
        //    33: putfield        Downloader$start$1.label:I
        //    36: goto            50
        //    39: new             LDownloader$start$1;
        //    42: dup            
        //    43: aload_0         /* this */
        //    44: aload_2         /* $completion */
        //    45: invokespecial   Downloader$start$1.<init>:(LDownloader;Lkotlin/coroutines/Continuation;)V
        //    48: astore          $continuation
        //    50: aload           $continuation
        //    52: getfield        Downloader$start$1.result:Ljava/lang/Object;
        //    55: astore          $result
        //    57: invokestatic    kotlin/coroutines/intrinsics/IntrinsicsKt.getCOROUTINE_SUSPENDED:()Ljava/lang/Object;
        //    60: astore          8
        //    62: aload           $continuation
        //    64: getfield        Downloader$start$1.label:I
        //    67: tableswitch {
        //                0: 92
        //                1: 259
        //                2: 369
        //          default: 431
        //        }
        //    92: aload           $result
        //    94: invokestatic    kotlin/ResultKt.throwOnFailure:(Ljava/lang/Object;)V
        //    97: aload_0         /* this */
        //    98: invokestatic    java/lang/System.currentTimeMillis:()J
        //   101: putfield        Downloader.startTime:J
        //   104: aload_1         /* scope */
        //   105: invokestatic    kotlinx/coroutines/Dispatchers.getIO:()Lkotlinx/coroutines/CoroutineDispatcher;
        //   108: checkcast       Lkotlin/coroutines/CoroutineContext;
        //   111: aconst_null    
        //   112: new             LDownloader$start$job$1;
        //   115: dup            
        //   116: aload_0         /* this */
        //   117: aconst_null    
        //   118: invokespecial   Downloader$start$job$1.<init>:(LDownloader;Lkotlin/coroutines/Continuation;)V
        //   121: checkcast       Lkotlin/jvm/functions/Function2;
        //   124: iconst_2       
        //   125: aconst_null    
        //   126: invokestatic    kotlinx/coroutines/BuildersKt.launch$default:(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;
        //   129: astore_3        /* job */
        //   130: aload_3         /* job */
        //   131: invokeinterface kotlinx/coroutines/Job.isCompleted:()Z
        //   136: ifne            427
        //   139: new             Lkotlin/jvm/internal/Ref$FloatRef;
        //   142: dup            
        //   143: invokespecial   kotlin/jvm/internal/Ref$FloatRef.<init>:()V
        //   146: astore          4
        //   148: aload           4
        //   150: aload_0         /* this */
        //   151: invokespecial   Downloader.getSpeed:()F
        //   154: ldc             1000.0
        //   156: fdiv           
        //   157: putfield        kotlin/jvm/internal/Ref$FloatRef.element:F
        //   160: new             Lkotlin/jvm/internal/Ref$ObjectRef;
        //   163: dup            
        //   164: invokespecial   kotlin/jvm/internal/Ref$ObjectRef.<init>:()V
        //   167: astore          5
        //   169: aload           5
        //   171: aload_0         /* this */
        //   172: invokespecial   Downloader.getProgress:()F
        //   175: invokestatic    java/lang/String.valueOf:(F)Ljava/lang/String;
        //   178: iconst_4       
        //   179: invokestatic    kotlin/text/StringsKt.take:(Ljava/lang/String;I)Ljava/lang/String;
        //   182: putfield        kotlin/jvm/internal/Ref$ObjectRef.element:Ljava/lang/Object;
        //   185: invokestatic    kotlinx/coroutines/Dispatchers.getMain:()Lkotlinx/coroutines/MainCoroutineDispatcher;
        //   188: checkcast       Lkotlin/coroutines/CoroutineContext;
        //   191: new             LDownloader$start$2;
        //   194: dup            
        //   195: aload_0         /* this */
        //   196: aload           speed
        //   198: aload           progress
        //   200: aconst_null    
        //   201: invokespecial   Downloader$start$2.<init>:(LDownloader;Lkotlin/jvm/internal/Ref$FloatRef;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/coroutines/Continuation;)V
        //   204: checkcast       Lkotlin/jvm/functions/Function2;
        //   207: aload           $continuation
        //   209: aload           $continuation
        //   211: aload_0         /* this */
        //   212: putfield        Downloader$start$1.L$0:Ljava/lang/Object;
        //   215: aload           $continuation
        //   217: aload_1         /* scope */
        //   218: putfield        Downloader$start$1.L$1:Ljava/lang/Object;
        //   221: aload           $continuation
        //   223: aload_3         /* job */
        //   224: putfield        Downloader$start$1.L$2:Ljava/lang/Object;
        //   227: aload           $continuation
        //   229: aload           speed
        //   231: putfield        Downloader$start$1.L$3:Ljava/lang/Object;
        //   234: aload           $continuation
        //   236: aload           progress
        //   238: putfield        Downloader$start$1.L$4:Ljava/lang/Object;
        //   241: aload           $continuation
        //   243: iconst_1       
        //   244: putfield        Downloader$start$1.label:I
        //   247: invokestatic    kotlinx/coroutines/BuildersKt.withContext:(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
        //   250: dup            
        //   251: aload           8
        //   253: if_acmpne       313
        //   256: aload           8
        //   258: areturn        
        //   259: aload           $continuation
        //   261: getfield        Downloader$start$1.L$4:Ljava/lang/Object;
        //   264: checkcast       Lkotlin/jvm/internal/Ref$ObjectRef;
        //   267: astore          progress
        //   269: aload           $continuation
        //   271: getfield        Downloader$start$1.L$3:Ljava/lang/Object;
        //   274: checkcast       Lkotlin/jvm/internal/Ref$FloatRef;
        //   277: astore          speed
        //   279: aload           $continuation
        //   281: getfield        Downloader$start$1.L$2:Ljava/lang/Object;
        //   284: checkcast       Lkotlinx/coroutines/Job;
        //   287: astore_3        /* job */
        //   288: aload           $continuation
        //   290: getfield        Downloader$start$1.L$1:Ljava/lang/Object;
        //   293: checkcast       Lkotlinx/coroutines/CoroutineScope;
        //   296: astore_1        /* scope */
        //   297: aload           $continuation
        //   299: getfield        Downloader$start$1.L$0:Ljava/lang/Object;
        //   302: checkcast       LDownloader;
        //   305: astore_0        /* this */
        //   306: aload           $result
        //   308: invokestatic    kotlin/ResultKt.throwOnFailure:(Ljava/lang/Object;)V
        //   311: aload           $result
        //   313: pop            
        //   314: ldc2_w          1000
        //   317: aload           $continuation
        //   319: aload           $continuation
        //   321: aload_0         /* this */
        //   322: putfield        Downloader$start$1.L$0:Ljava/lang/Object;
        //   325: aload           $continuation
        //   327: aload_1         /* scope */
        //   328: putfield        Downloader$start$1.L$1:Ljava/lang/Object;
        //   331: aload           $continuation
        //   333: aload_3         /* job */
        //   334: putfield        Downloader$start$1.L$2:Ljava/lang/Object;
        //   337: aload           $continuation
        //   339: aload           speed
        //   341: putfield        Downloader$start$1.L$3:Ljava/lang/Object;
        //   344: aload           $continuation
        //   346: aload           progress
        //   348: putfield        Downloader$start$1.L$4:Ljava/lang/Object;
        //   351: aload           $continuation
        //   353: iconst_2       
        //   354: putfield        Downloader$start$1.label:I
        //   357: invokestatic    kotlinx/coroutines/DelayKt.delay:(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;
        //   360: dup            
        //   361: aload           8
        //   363: if_acmpne       423
        //   366: aload           8
        //   368: areturn        
        //   369: aload           $continuation
        //   371: getfield        Downloader$start$1.L$4:Ljava/lang/Object;
        //   374: checkcast       Lkotlin/jvm/internal/Ref$ObjectRef;
        //   377: astore          progress
        //   379: aload           $continuation
        //   381: getfield        Downloader$start$1.L$3:Ljava/lang/Object;
        //   384: checkcast       Lkotlin/jvm/internal/Ref$FloatRef;
        //   387: astore          speed
        //   389: aload           $continuation
        //   391: getfield        Downloader$start$1.L$2:Ljava/lang/Object;
        //   394: checkcast       Lkotlinx/coroutines/Job;
        //   397: astore_3        /* job */
        //   398: aload           $continuation
        //   400: getfield        Downloader$start$1.L$1:Ljava/lang/Object;
        //   403: checkcast       Lkotlinx/coroutines/CoroutineScope;
        //   406: astore_1        /* scope */
        //   407: aload           $continuation
        //   409: getfield        Downloader$start$1.L$0:Ljava/lang/Object;
        //   412: checkcast       LDownloader;
        //   415: astore_0        /* this */
        //   416: aload           $result
        //   418: invokestatic    kotlin/ResultKt.throwOnFailure:(Ljava/lang/Object;)V
        //   421: aload           $result
        //   423: pop            
        //   424: goto            130
        //   427: getstatic       kotlin/Unit.INSTANCE:Lkotlin/Unit;
        //   430: areturn        
        //   431: new             Ljava/lang/IllegalStateException;
        //   434: dup            
        //   435: ldc             "call to 'resume' before 'invoke' with coroutine"
        //   437: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/String;)V
        //   440: athrow         
        //    Signature:
        //  (Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation<-Lkotlin/Unit;>;)Ljava/lang/Object;
        //    StackMapTable: 00 0A 27 FF 00 0A 00 08 07 00 02 07 00 98 07 00 BB 00 00 00 00 07 00 2B 00 00 FF 00 29 00 09 07 00 02 07 00 98 07 00 BB 00 00 00 07 00 04 07 00 2B 07 00 04 00 00 FF 00 25 00 09 07 00 02 07 00 98 07 00 BB 07 00 59 00 00 07 00 04 07 00 2B 07 00 04 00 00 FF 00 80 00 09 07 00 02 07 00 98 07 00 BB 00 00 00 07 00 04 07 00 2B 07 00 04 00 00 FF 00 35 00 09 07 00 02 07 00 98 07 00 BB 07 00 59 07 00 5F 07 00 69 07 00 04 07 00 2B 07 00 04 00 01 07 00 04 FF 00 37 00 09 07 00 02 07 00 98 07 00 BB 00 00 00 07 00 04 07 00 2B 07 00 04 00 00 FF 00 35 00 09 07 00 02 07 00 98 07 00 BB 07 00 59 07 00 5F 07 00 69 07 00 04 07 00 2B 07 00 04 00 01 07 00 04 FF 00 03 00 09 07 00 02 07 00 98 07 00 BB 07 00 59 00 00 07 00 04 07 00 2B 07 00 04 00 00 FF 00 03 00 09 07 00 02 07 00 98 07 00 BB 00 00 00 07 00 04 07 00 2B 07 00 04 00 00
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.decompiler.ast.AstBuilder.convertLocalVariables(AstBuilder.java:2895)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2445)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public Downloader(@NotNull final String link, @NotNull final File target, @NotNull final Label progressLabel) {
        Intrinsics.checkNotNullParameter(link, "link");
        Intrinsics.checkNotNullParameter(target, "target");
        Intrinsics.checkNotNullParameter(progressLabel, "progressLabel");
        this.target = target;
        this.progressLabel = progressLabel;
        this.url = new URL(link);
        final URLConnection openConnection = this.url.openConnection();
        Intrinsics.checkNotNullExpressionValue(openConnection, "url.openConnection()");
        this.size = (float)openConnection.getContentLengthLong();
    }
}
