import javafx.fxml.FXMLLoader;
import kotlin.jvm.internal.Intrinsics;
import javafx.scene.Node;
import org.jetbrains.annotations.Nullable;
import javafx.scene.image.Image;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.fxml.FXML;
import javafx.scene.layout.GridPane;
import kotlin.Metadata;
import javafx.scene.control.ListCell;

// 
// Decompiled by Procyon v0.5.36
// 

@Metadata(mv = { 1, 4, 0 }, bv = { 1, 0, 3 }, k = 1, d1 = { "\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0003J\u001a\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0012\u001a\u00020\u0013H\u0014R\u0012\u0010\u0004\u001a\u00020\u00058\u0002@\u0002X\u0083.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\t\u001a\u00020\n8\u0002@\u0002X\u0083.¢\u0006\u0002\n\u0000R\u0012\u0010\u000b\u001a\u00020\f8\u0002@\u0002X\u0083.¢\u0006\u0002\n\u0000R\u0012\u0010\r\u001a\u00020\f8\u0002@\u0002X\u0083.¢\u0006\u0002\n\u0000R\u0012\u0010\u000e\u001a\u00020\f8\u0002@\u0002X\u0083.¢\u0006\u0002\n\u0000¨\u0006\u0014" }, d2 = { "LFileListCell;", "Ljavafx/scene/control/ListCell;", "LAndroidFile;", "()V", "dir", "Ljavafx/scene/image/ImageView;", "fileimg", "Ljavafx/scene/image/Image;", "folderimg", "gridPane", "Ljavafx/scene/layout/GridPane;", "name", "Ljavafx/scene/control/Label;", "size", "time", "updateItem", "", "item", "empty", "", "XiaomiADBFastbootTools" })
public final class FileListCell extends ListCell<AndroidFile>
{
    @FXML
    private GridPane gridPane;
    @FXML
    private ImageView dir;
    @FXML
    private Label name;
    @FXML
    private Label size;
    @FXML
    private Label time;
    private final Image folderimg;
    private final Image fileimg;
    
    @Override
    protected void updateItem(@Nullable final AndroidFile item, final boolean empty) {
        super.updateItem(item, empty);
        if (empty || item == null) {
            this.setText(null);
            this.setGraphic(null);
        }
        else {
            final ImageView dir = this.dir;
            if (dir == null) {
                Intrinsics.throwUninitializedPropertyAccessException("dir");
            }
            dir.setImage(item.getDir() ? this.folderimg : this.fileimg);
            final Label name = this.name;
            if (name == null) {
                Intrinsics.throwUninitializedPropertyAccessException("name");
            }
            name.setText(item.getName());
            final Label size = this.size;
            if (size == null) {
                Intrinsics.throwUninitializedPropertyAccessException("size");
            }
            size.setText(item.getSize());
            final Label time = this.time;
            if (time == null) {
                Intrinsics.throwUninitializedPropertyAccessException("time");
            }
            time.setText(item.getTime());
            this.setText(null);
            final GridPane gridPane = this.gridPane;
            if (gridPane == null) {
                Intrinsics.throwUninitializedPropertyAccessException("gridPane");
            }
            this.setGraphic(gridPane);
        }
    }
    
    public FileListCell() {
        this.folderimg = new Image("folder.png");
        this.fileimg = new Image("file.png");
        final FXMLLoader fxmlLoader = new FXMLLoader(this.getClass().getClassLoader().getResource("File.fxml"));
        fxmlLoader.setController(this);
        fxmlLoader.load();
    }
}
