import kotlinx.coroutines.MainCoroutineDispatcher;
import kotlin.ResultKt;
import kotlin.Unit;
import org.jetbrains.annotations.Nullable;
import kotlin.coroutines.CoroutineContext;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlin.coroutines.Continuation;
import kotlin.jvm.internal.Intrinsics;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextInputControl;
import javafx.scene.control.ProgressBar;
import org.jetbrains.annotations.NotNull;
import java.io.File;
import kotlin.Metadata;

// 
// Decompiled by Procyon v0.5.36
// 

@Metadata(mv = { 1, 4, 0 }, bv = { 1, 0, 3 }, k = 1, d1 = { "\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001b\u0010\u001b\u001a\u00020\u001c2\b\u0010\u001d\u001a\u0004\u0018\u00010\u001eH\u0086@\u00f8\u0001\u0000¢\u0006\u0002\u0010\u001fJ\u0019\u0010 \u001a\u00020\u00042\u0006\u0010\u001d\u001a\u00020\u001eH\u0082@\u00f8\u0001\u0000¢\u0006\u0002\u0010\u001fR\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\nX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0015\u001a\u00020\u0016X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001a\u0082\u0002\u0004\n\u0002\b\u0019¨\u0006!" }, d2 = { "LROMFlasher;", "", "()V", "directory", "Ljava/io/File;", "getDirectory", "()Ljava/io/File;", "setDirectory", "(Ljava/io/File;)V", "outputTextArea", "Ljavafx/scene/control/TextInputControl;", "getOutputTextArea", "()Ljavafx/scene/control/TextInputControl;", "setOutputTextArea", "(Ljavafx/scene/control/TextInputControl;)V", "progressBar", "Ljavafx/scene/control/ProgressBar;", "getProgressBar", "()Ljavafx/scene/control/ProgressBar;", "setProgressBar", "(Ljavafx/scene/control/ProgressBar;)V", "progressIndicator", "Ljavafx/scene/control/ProgressIndicator;", "getProgressIndicator", "()Ljavafx/scene/control/ProgressIndicator;", "setProgressIndicator", "(Ljavafx/scene/control/ProgressIndicator;)V", "flash", "", "arg", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "setupScript", "XiaomiADBFastbootTools" })
public final class ROMFlasher
{
    @NotNull
    private static File directory;
    @NotNull
    public static ProgressBar progressBar;
    @NotNull
    public static TextInputControl outputTextArea;
    @NotNull
    public static ProgressIndicator progressIndicator;
    public static final ROMFlasher INSTANCE;
    
    @NotNull
    public final File getDirectory() {
        return ROMFlasher.directory;
    }
    
    public final void setDirectory(@NotNull final File <set-?>) {
        Intrinsics.checkNotNullParameter(<set-?>, "<set-?>");
        ROMFlasher.directory = <set-?>;
    }
    
    @NotNull
    public final ProgressBar getProgressBar() {
        final ProgressBar progressBar = ROMFlasher.progressBar;
        if (progressBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("progressBar");
        }
        return progressBar;
    }
    
    public final void setProgressBar(@NotNull final ProgressBar <set-?>) {
        Intrinsics.checkNotNullParameter(<set-?>, "<set-?>");
        ROMFlasher.progressBar = <set-?>;
    }
    
    @NotNull
    public final TextInputControl getOutputTextArea() {
        final TextInputControl outputTextArea = ROMFlasher.outputTextArea;
        if (outputTextArea == null) {
            Intrinsics.throwUninitializedPropertyAccessException("outputTextArea");
        }
        return outputTextArea;
    }
    
    public final void setOutputTextArea(@NotNull final TextInputControl <set-?>) {
        Intrinsics.checkNotNullParameter(<set-?>, "<set-?>");
        ROMFlasher.outputTextArea = <set-?>;
    }
    
    @NotNull
    public final ProgressIndicator getProgressIndicator() {
        final ProgressIndicator progressIndicator = ROMFlasher.progressIndicator;
        if (progressIndicator == null) {
            Intrinsics.throwUninitializedPropertyAccessException("progressIndicator");
        }
        return progressIndicator;
    }
    
    public final void setProgressIndicator(@NotNull final ProgressIndicator <set-?>) {
        Intrinsics.checkNotNullParameter(<set-?>, "<set-?>");
        ROMFlasher.progressIndicator = <set-?>;
    }
    
    @Nullable
    public final Object flash(@Nullable String arg, @NotNull final Continuation<? super Unit> $completion) {
        final Continuation $continuation;
        Label_0050: {
            if ($completion instanceof ROMFlasher$flash.ROMFlasher$flash$1) {
                final ROMFlasher$flash.ROMFlasher$flash$1 romFlasher$flash$1 = (ROMFlasher$flash.ROMFlasher$flash$1)$completion;
                if ((romFlasher$flash$1.label & Integer.MIN_VALUE) != 0x0) {
                    final ROMFlasher$flash.ROMFlasher$flash$1 romFlasher$flash$2 = romFlasher$flash$1;
                    romFlasher$flash$2.label -= Integer.MIN_VALUE;
                    break Label_0050;
                }
            }
            $continuation = (Continuation)new ROMFlasher$flash.ROMFlasher$flash$1(this, (Continuation)$completion);
        }
        final Object $result = ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).result;
        final Object coroutine_SUSPENDED = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
        Label_0254: {
            switch (((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).label) {
                case 0: {
                    ResultKt.throwOnFailure($result);
                    if (arg == null) {
                        return Unit.INSTANCE;
                    }
                    final MainCoroutineDispatcher context = Dispatchers.getMain();
                    final Function2<? super CoroutineScope, ? super Continuation<? super T>, ?> block = (Function2<? super CoroutineScope, ? super Continuation<? super T>, ?>)new ROMFlasher$flash.ROMFlasher$flash$2((Continuation)null);
                    final Continuation $completion2 = $continuation;
                    ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$0 = this;
                    ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$1 = arg;
                    ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).label = 1;
                    if (BuildersKt.withContext((CoroutineContext)context, (Function2<? super CoroutineScope, ? super Continuation<? super Object>, ?>)block, (Continuation<? super Object>)$completion2) == coroutine_SUSPENDED) {
                        return coroutine_SUSPENDED;
                    }
                    break;
                }
                case 1: {
                    arg = (String)((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$1;
                    this = (ROMFlasher)((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$0;
                    ResultKt.throwOnFailure($result);
                    break;
                }
                case 2: {
                    arg = (String)((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$1;
                    this = (ROMFlasher)((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$0;
                    ResultKt.throwOnFailure($result);
                    break Label_0254;
                }
                case 3: {
                    arg = (String)((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$1;
                    this = (ROMFlasher)((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$0;
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                }
                default: {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            }
            final CoroutineDispatcher context2 = Dispatchers.getIO();
            final Function2<? super CoroutineScope, ? super Continuation<? super T>, ?> block2 = (Function2<? super CoroutineScope, ? super Continuation<? super T>, ?>)new ROMFlasher$flash.ROMFlasher$flash$3(arg, (Continuation)null);
            final Continuation $completion3 = $continuation;
            ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$0 = this;
            ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$1 = arg;
            ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).label = 2;
            if (BuildersKt.withContext((CoroutineContext)context2, (Function2<? super CoroutineScope, ? super Continuation<? super Object>, ?>)block2, (Continuation<? super Object>)$completion3) == coroutine_SUSPENDED) {
                return coroutine_SUSPENDED;
            }
        }
        final MainCoroutineDispatcher context3 = Dispatchers.getMain();
        final Function2<? super CoroutineScope, ? super Continuation<? super T>, ?> block3 = (Function2<? super CoroutineScope, ? super Continuation<? super T>, ?>)new ROMFlasher$flash.ROMFlasher$flash$4((Continuation)null);
        final Continuation $completion4 = $continuation;
        ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$0 = this;
        ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).L$1 = arg;
        ((ROMFlasher$flash.ROMFlasher$flash$1)$continuation).label = 3;
        if (BuildersKt.withContext((CoroutineContext)context3, (Function2<? super CoroutineScope, ? super Continuation<? super Object>, ?>)block3, (Continuation<? super Object>)$completion4) == coroutine_SUSPENDED) {
            return coroutine_SUSPENDED;
        }
        return Unit.INSTANCE;
    }
    
    private ROMFlasher() {
    }
    
    static {
        INSTANCE = new ROMFlasher();
        ROMFlasher.directory = XiaomiADBFastbootTools.Companion.getDir();
    }
}
