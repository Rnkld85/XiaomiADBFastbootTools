// 
// Decompiled by Procyon v0.5.36
// 

package javafx.stage;

public enum Modality
{
    NONE, 
    WINDOW_MODAL, 
    APPLICATION_MODAL;
}
