// 
// Decompiled by Procyon v0.5.36
// 

package javafx.stage;

import javafx.beans.value.ObservableValue;
import javafx.beans.property.SimpleBooleanProperty;
import com.sun.javafx.tk.TKStage;
import com.sun.javafx.stage.WindowPeerListener;
import java.security.Permission;
import com.sun.javafx.FXPermissions;
import javafx.geometry.NodeOrientation;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.StringPropertyBase;
import javafx.beans.property.ReadOnlyBooleanProperty;
import com.sun.javafx.scene.SceneHelper;
import javafx.scene.Scene;
import com.sun.javafx.stage.StageHelper;
import javafx.beans.property.SimpleObjectProperty;
import com.sun.javafx.collections.VetoableListDecorator;
import java.util.Iterator;
import java.util.List;
import com.sun.javafx.tk.Toolkit;
import java.util.ArrayList;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import javafx.beans.NamedArg;
import javafx.scene.input.KeyCombination;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.image.Image;
import javafx.collections.ObservableList;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import com.sun.javafx.stage.StagePeerListener;

public class Stage extends Window
{
    private boolean inNestedEventLoop;
    private static final StagePeerListener.StageAccessor STAGE_ACCESSOR;
    private boolean primary;
    private boolean securityDialog;
    private boolean important;
    private StageStyle style;
    private Modality modality;
    private Window owner;
    private ReadOnlyBooleanWrapper fullScreen;
    private ObservableList<Image> icons;
    private StringProperty title;
    private ReadOnlyBooleanWrapper iconified;
    private ReadOnlyBooleanWrapper maximized;
    private ReadOnlyBooleanWrapper alwaysOnTop;
    private BooleanProperty resizable;
    private DoubleProperty minWidth;
    private DoubleProperty minHeight;
    private DoubleProperty maxWidth;
    private DoubleProperty maxHeight;
    private final ObjectProperty<KeyCombination> fullScreenExitCombination;
    private final ObjectProperty<String> fullScreenExitHint;
    
    public Stage() {
        this(StageStyle.DECORATED);
    }
    
    public Stage(@NamedArg(value = "style", defaultValue = "DECORATED") final StageStyle stageStyle) {
        this.inNestedEventLoop = false;
        this.primary = false;
        this.securityDialog = false;
        this.important = true;
        this.modality = Modality.NONE;
        this.owner = null;
        this.icons = new VetoableListDecorator<Image>((ObservableList)new TrackableObservableList<Image>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Image> change) {
                final ArrayList<Object> icons = new ArrayList<Object>();
                final Iterator iterator = Stage.this.icons.iterator();
                while (iterator.hasNext()) {
                    icons.add(Toolkit.getImageAccessor().getPlatformImage(iterator.next()));
                }
                if (Stage.this.getPeer() != null) {
                    Stage.this.getPeer().setIcons(icons);
                }
            }
        }) {
            @Override
            protected void onProposedChange(final List<Image> list, final int[] array) {
                final Iterator<Image> iterator = list.iterator();
                while (iterator.hasNext()) {
                    if (iterator.next() == null) {
                        throw new NullPointerException("icon can not be null.");
                    }
                }
            }
        };
        this.fullScreenExitCombination = new SimpleObjectProperty<KeyCombination>(this, "fullScreenExitCombination", null);
        this.fullScreenExitHint = new SimpleObjectProperty<String>(this, "fullScreenExitHint", null);
        Toolkit.getToolkit().checkFxUserThread();
        this.initStyle(stageStyle);
        StageHelper.initHelper(this);
    }
    
    public final void setScene(final Scene scene) {
        Toolkit.getToolkit().checkFxUserThread();
        super.setScene(scene);
    }
    
    public final void show() {
        super.show();
    }
    
    final void initSecurityDialog(final boolean securityDialog) {
        if (this.hasBeenVisible) {
            throw new IllegalStateException("Cannot set securityDialog once stage has been set visible");
        }
        this.securityDialog = securityDialog;
    }
    
    final boolean isSecurityDialog() {
        return this.securityDialog;
    }
    
    void setPrimary(final boolean primary) {
        this.primary = primary;
    }
    
    boolean isPrimary() {
        return this.primary;
    }
    
    void setImportant(final boolean important) {
        this.important = important;
    }
    
    private boolean isImportant() {
        return this.important;
    }
    
    public void showAndWait() {
        Toolkit.getToolkit().checkFxUserThread();
        if (this.isPrimary()) {
            throw new IllegalStateException("Cannot call this method on primary stage");
        }
        if (this.isShowing()) {
            throw new IllegalStateException("Stage already visible");
        }
        if (!Toolkit.getToolkit().canStartNestedEventLoop()) {
            throw new IllegalStateException("showAndWait is not allowed during animation or layout processing");
        }
        assert !this.inNestedEventLoop;
        this.show();
        this.inNestedEventLoop = true;
        Toolkit.getToolkit().enterNestedEventLoop(this);
    }
    
    public final void initStyle(final StageStyle style) {
        if (this.hasBeenVisible) {
            throw new IllegalStateException("Cannot set style once stage has been set visible");
        }
        this.style = style;
    }
    
    public final StageStyle getStyle() {
        return this.style;
    }
    
    public final void initModality(final Modality modality) {
        if (this.hasBeenVisible) {
            throw new IllegalStateException("Cannot set modality once stage has been set visible");
        }
        if (this.isPrimary()) {
            throw new IllegalStateException("Cannot set modality for the primary stage");
        }
        this.modality = modality;
    }
    
    public final Modality getModality() {
        return this.modality;
    }
    
    public final void initOwner(final Window owner) {
        if (this.hasBeenVisible) {
            throw new IllegalStateException("Cannot set owner once stage has been set visible");
        }
        if (this.isPrimary()) {
            throw new IllegalStateException("Cannot set owner for the primary stage");
        }
        this.owner = owner;
        final Scene scene = this.getScene();
        if (scene != null) {
            SceneHelper.parentEffectiveOrientationInvalidated(scene);
        }
    }
    
    public final Window getOwner() {
        return this.owner;
    }
    
    public final void setFullScreen(final boolean fullScreen) {
        Toolkit.getToolkit().checkFxUserThread();
        this.fullScreenPropertyImpl().set(fullScreen);
        if (this.getPeer() != null) {
            this.getPeer().setFullScreen(fullScreen);
        }
    }
    
    public final boolean isFullScreen() {
        return this.fullScreen != null && this.fullScreen.get();
    }
    
    public final ReadOnlyBooleanProperty fullScreenProperty() {
        return this.fullScreenPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper fullScreenPropertyImpl() {
        if (this.fullScreen == null) {
            this.fullScreen = new ReadOnlyBooleanWrapper(this, "fullScreen");
        }
        return this.fullScreen;
    }
    
    public final ObservableList<Image> getIcons() {
        return this.icons;
    }
    
    public final void setTitle(final String s) {
        this.titleProperty().set(s);
    }
    
    public final String getTitle() {
        return (this.title == null) ? null : this.title.get();
    }
    
    public final StringProperty titleProperty() {
        if (this.title == null) {
            this.title = new StringPropertyBase() {
                @Override
                protected void invalidated() {
                    if (Stage.this.getPeer() != null) {
                        Stage.this.getPeer().setTitle(this.get());
                    }
                }
                
                @Override
                public Object getBean() {
                    return Stage.this;
                }
                
                @Override
                public String getName() {
                    return "title";
                }
            };
        }
        return this.title;
    }
    
    public final void setIconified(final boolean iconified) {
        this.iconifiedPropertyImpl().set(iconified);
        if (this.getPeer() != null) {
            this.getPeer().setIconified(iconified);
        }
    }
    
    public final boolean isIconified() {
        return this.iconified != null && this.iconified.get();
    }
    
    public final ReadOnlyBooleanProperty iconifiedProperty() {
        return this.iconifiedPropertyImpl().getReadOnlyProperty();
    }
    
    private final ReadOnlyBooleanWrapper iconifiedPropertyImpl() {
        if (this.iconified == null) {
            this.iconified = new ReadOnlyBooleanWrapper(this, "iconified");
        }
        return this.iconified;
    }
    
    public final void setMaximized(final boolean maximized) {
        this.maximizedPropertyImpl().set(maximized);
        if (this.getPeer() != null) {
            this.getPeer().setMaximized(maximized);
        }
    }
    
    public final boolean isMaximized() {
        return this.maximized != null && this.maximized.get();
    }
    
    public final ReadOnlyBooleanProperty maximizedProperty() {
        return this.maximizedPropertyImpl().getReadOnlyProperty();
    }
    
    private final ReadOnlyBooleanWrapper maximizedPropertyImpl() {
        if (this.maximized == null) {
            this.maximized = new ReadOnlyBooleanWrapper(this, "maximized");
        }
        return this.maximized;
    }
    
    public final void setAlwaysOnTop(final boolean alwaysOnTop) {
        this.alwaysOnTopPropertyImpl().set(alwaysOnTop);
        if (this.getPeer() != null) {
            this.getPeer().setAlwaysOnTop(alwaysOnTop);
        }
    }
    
    public final boolean isAlwaysOnTop() {
        return this.alwaysOnTop != null && this.alwaysOnTop.get();
    }
    
    public final ReadOnlyBooleanProperty alwaysOnTopProperty() {
        return this.alwaysOnTopPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper alwaysOnTopPropertyImpl() {
        if (this.alwaysOnTop == null) {
            this.alwaysOnTop = new ReadOnlyBooleanWrapper(this, "alwaysOnTop");
        }
        return this.alwaysOnTop;
    }
    
    public final void setResizable(final boolean b) {
        this.resizableProperty().set(b);
    }
    
    public final boolean isResizable() {
        return this.resizable == null || this.resizable.get();
    }
    
    public final BooleanProperty resizableProperty() {
        if (this.resizable == null) {
            this.resizable = new ResizableProperty();
        }
        return this.resizable;
    }
    
    public final void setMinWidth(final double n) {
        this.minWidthProperty().set(n);
    }
    
    public final double getMinWidth() {
        return (this.minWidth == null) ? 0.0 : this.minWidth.get();
    }
    
    public final DoubleProperty minWidthProperty() {
        if (this.minWidth == null) {
            this.minWidth = new DoublePropertyBase(0.0) {
                @Override
                protected void invalidated() {
                    if (Stage.this.getPeer() != null) {
                        Stage.this.getPeer().setMinimumSize((int)Math.ceil(this.get()), (int)Math.ceil(Stage.this.getMinHeight()));
                    }
                    if (Stage.this.getWidth() < Stage.this.getMinWidth()) {
                        Stage.this.setWidth(Stage.this.getMinWidth());
                    }
                }
                
                @Override
                public Object getBean() {
                    return Stage.this;
                }
                
                @Override
                public String getName() {
                    return "minWidth";
                }
            };
        }
        return this.minWidth;
    }
    
    public final void setMinHeight(final double n) {
        this.minHeightProperty().set(n);
    }
    
    public final double getMinHeight() {
        return (this.minHeight == null) ? 0.0 : this.minHeight.get();
    }
    
    public final DoubleProperty minHeightProperty() {
        if (this.minHeight == null) {
            this.minHeight = new DoublePropertyBase(0.0) {
                @Override
                protected void invalidated() {
                    if (Stage.this.getPeer() != null) {
                        Stage.this.getPeer().setMinimumSize((int)Math.ceil(Stage.this.getMinWidth()), (int)Math.ceil(this.get()));
                    }
                    if (Stage.this.getHeight() < Stage.this.getMinHeight()) {
                        Stage.this.setHeight(Stage.this.getMinHeight());
                    }
                }
                
                @Override
                public Object getBean() {
                    return Stage.this;
                }
                
                @Override
                public String getName() {
                    return "minHeight";
                }
            };
        }
        return this.minHeight;
    }
    
    public final void setMaxWidth(final double n) {
        this.maxWidthProperty().set(n);
    }
    
    public final double getMaxWidth() {
        return (this.maxWidth == null) ? Double.MAX_VALUE : this.maxWidth.get();
    }
    
    public final DoubleProperty maxWidthProperty() {
        if (this.maxWidth == null) {
            this.maxWidth = new DoublePropertyBase(Double.MAX_VALUE) {
                @Override
                protected void invalidated() {
                    if (Stage.this.getPeer() != null) {
                        Stage.this.getPeer().setMaximumSize((int)Math.floor(this.get()), (int)Math.floor(Stage.this.getMaxHeight()));
                    }
                    if (Stage.this.getWidth() > Stage.this.getMaxWidth()) {
                        Stage.this.setWidth(Stage.this.getMaxWidth());
                    }
                }
                
                @Override
                public Object getBean() {
                    return Stage.this;
                }
                
                @Override
                public String getName() {
                    return "maxWidth";
                }
            };
        }
        return this.maxWidth;
    }
    
    public final void setMaxHeight(final double n) {
        this.maxHeightProperty().set(n);
    }
    
    public final double getMaxHeight() {
        return (this.maxHeight == null) ? Double.MAX_VALUE : this.maxHeight.get();
    }
    
    public final DoubleProperty maxHeightProperty() {
        if (this.maxHeight == null) {
            this.maxHeight = new DoublePropertyBase(Double.MAX_VALUE) {
                @Override
                protected void invalidated() {
                    if (Stage.this.getPeer() != null) {
                        Stage.this.getPeer().setMaximumSize((int)Math.floor(Stage.this.getMaxWidth()), (int)Math.floor(this.get()));
                    }
                    if (Stage.this.getHeight() > Stage.this.getMaxHeight()) {
                        Stage.this.setHeight(Stage.this.getMaxHeight());
                    }
                }
                
                @Override
                public Object getBean() {
                    return Stage.this;
                }
                
                @Override
                public String getName() {
                    return "maxHeight";
                }
            };
        }
        return this.maxHeight;
    }
    
    private void doVisibleChanging(final boolean b) {
        final Toolkit toolkit = Toolkit.getToolkit();
        if (b && this.getPeer() == null) {
            final Window owner = this.getOwner();
            final TKStage tkStage = (owner == null) ? null : owner.getPeer();
            final Scene scene = this.getScene();
            final boolean b2 = scene != null && scene.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT;
            StageStyle stageStyle = this.getStyle();
            if (stageStyle == StageStyle.TRANSPARENT) {
                final SecurityManager securityManager = System.getSecurityManager();
                if (securityManager != null) {
                    try {
                        securityManager.checkPermission(FXPermissions.CREATE_TRANSPARENT_WINDOW_PERMISSION);
                    }
                    catch (SecurityException ex) {
                        stageStyle = StageStyle.UNDECORATED;
                    }
                }
            }
            this.setPeer(toolkit.createTKStage(this, this.isSecurityDialog(), stageStyle, this.isPrimary(), this.getModality(), tkStage, b2, this.acc));
            this.getPeer().setMinimumSize((int)Math.ceil(this.getMinWidth()), (int)Math.ceil(this.getMinHeight()));
            this.getPeer().setMaximumSize((int)Math.floor(this.getMaxWidth()), (int)Math.floor(this.getMaxHeight()));
            this.setPeerListener(new StagePeerListener(this, Stage.STAGE_ACCESSOR));
        }
    }
    
    private void doVisibleChanged(final boolean b) {
        if (b) {
            final TKStage peer = this.getPeer();
            peer.setImportant(this.isImportant());
            peer.setResizable(this.isResizable());
            peer.setFullScreen(this.isFullScreen());
            peer.setAlwaysOnTop(this.isAlwaysOnTop());
            peer.setIconified(this.isIconified());
            peer.setMaximized(this.isMaximized());
            peer.setTitle(this.getTitle());
            final ArrayList<Object> icons = new ArrayList<Object>();
            final Iterator<Image> iterator = this.icons.iterator();
            while (iterator.hasNext()) {
                icons.add(Toolkit.getImageAccessor().getPlatformImage(iterator.next()));
            }
            if (peer != null) {
                peer.setIcons(icons);
            }
        }
        if (!b && this.inNestedEventLoop) {
            this.inNestedEventLoop = false;
            Toolkit.getToolkit().exitNestedEventLoop(this, null);
        }
    }
    
    public void toFront() {
        if (this.getPeer() != null) {
            this.getPeer().toFront();
        }
    }
    
    public void toBack() {
        if (this.getPeer() != null) {
            this.getPeer().toBack();
        }
    }
    
    public void close() {
        this.hide();
    }
    
    @Override
    Window getWindowOwner() {
        return this.getOwner();
    }
    
    public final void setFullScreenExitKeyCombination(final KeyCombination keyCombination) {
        this.fullScreenExitCombination.set(keyCombination);
    }
    
    public final KeyCombination getFullScreenExitKeyCombination() {
        return this.fullScreenExitCombination.get();
    }
    
    public final ObjectProperty<KeyCombination> fullScreenExitKeyProperty() {
        return this.fullScreenExitCombination;
    }
    
    public final void setFullScreenExitHint(final String s) {
        this.fullScreenExitHint.set(s);
    }
    
    public final String getFullScreenExitHint() {
        return this.fullScreenExitHint.get();
    }
    
    public final ObjectProperty<String> fullScreenExitHintProperty() {
        return this.fullScreenExitHint;
    }
    
    static {
        StageHelper.setStageAccessor(new StageHelper.StageAccessor() {
            @Override
            public void doVisibleChanging(final Window window, final boolean b) {
                ((Stage)window).doVisibleChanging(b);
            }
            
            @Override
            public void doVisibleChanged(final Window window, final boolean b) {
                ((Stage)window).doVisibleChanged(b);
            }
            
            @Override
            public void initSecurityDialog(final Stage stage, final boolean b) {
                stage.initSecurityDialog(b);
            }
            
            @Override
            public void setPrimary(final Stage stage, final boolean primary) {
                stage.setPrimary(primary);
            }
            
            @Override
            public void setImportant(final Stage stage, final boolean important) {
                stage.setImportant(important);
            }
        });
        STAGE_ACCESSOR = new StagePeerListener.StageAccessor() {
            @Override
            public void setIconified(final Stage stage, final boolean b) {
                stage.iconifiedPropertyImpl().set(b);
            }
            
            @Override
            public void setMaximized(final Stage stage, final boolean b) {
                stage.maximizedPropertyImpl().set(b);
            }
            
            @Override
            public void setResizable(final Stage stage, final boolean noInvalidate) {
                ((ResizableProperty)stage.resizableProperty()).setNoInvalidate(noInvalidate);
            }
            
            @Override
            public void setFullScreen(final Stage stage, final boolean b) {
                stage.fullScreenPropertyImpl().set(b);
            }
            
            @Override
            public void setAlwaysOnTop(final Stage stage, final boolean b) {
                stage.alwaysOnTopPropertyImpl().set(b);
            }
        };
    }
    
    private class ResizableProperty extends SimpleBooleanProperty
    {
        private boolean noInvalidate;
        
        public ResizableProperty() {
            super(Stage.this, "resizable", true);
        }
        
        void setNoInvalidate(final boolean b) {
            this.noInvalidate = true;
            this.set(b);
            this.noInvalidate = false;
        }
        
        @Override
        protected void invalidated() {
            if (this.noInvalidate) {
                return;
            }
            if (Stage.this.getPeer() != null) {
                Stage.this.applyBounds();
                Stage.this.getPeer().setResizable(this.get());
            }
        }
        
        @Override
        public void bind(final ObservableValue<? extends Boolean> observableValue) {
            throw new RuntimeException("Resizable property cannot be bound");
        }
    }
}
