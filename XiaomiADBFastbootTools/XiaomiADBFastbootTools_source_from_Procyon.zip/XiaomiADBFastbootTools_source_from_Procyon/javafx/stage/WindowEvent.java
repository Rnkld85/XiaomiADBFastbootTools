// 
// Decompiled by Procyon v0.5.36
// 

package javafx.stage;

import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;
import javafx.event.Event;

public class WindowEvent extends Event
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<WindowEvent> ANY;
    public static final EventType<WindowEvent> WINDOW_SHOWING;
    public static final EventType<WindowEvent> WINDOW_SHOWN;
    public static final EventType<WindowEvent> WINDOW_HIDING;
    public static final EventType<WindowEvent> WINDOW_HIDDEN;
    public static final EventType<WindowEvent> WINDOW_CLOSE_REQUEST;
    
    public WindowEvent(@NamedArg("source") final Window window, @NamedArg("eventType") final EventType<? extends Event> eventType) {
        super(window, window, eventType);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("WindowEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        return sb.append("]").toString();
    }
    
    @Override
    public WindowEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (WindowEvent)super.copyFor(o, eventTarget);
    }
    
    public WindowEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<WindowEvent> eventType) {
        final WindowEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    @Override
    public EventType<WindowEvent> getEventType() {
        return (EventType<WindowEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<WindowEvent>(Event.ANY, "WINDOW");
        WINDOW_SHOWING = new EventType<WindowEvent>(WindowEvent.ANY, "WINDOW_SHOWING");
        WINDOW_SHOWN = new EventType<WindowEvent>(WindowEvent.ANY, "WINDOW_SHOWN");
        WINDOW_HIDING = new EventType<WindowEvent>(WindowEvent.ANY, "WINDOW_HIDING");
        WINDOW_HIDDEN = new EventType<WindowEvent>(WindowEvent.ANY, "WINDOW_HIDDEN");
        WINDOW_CLOSE_REQUEST = new EventType<WindowEvent>(WindowEvent.ANY, "WINDOW_CLOSE_REQUEST");
    }
}
