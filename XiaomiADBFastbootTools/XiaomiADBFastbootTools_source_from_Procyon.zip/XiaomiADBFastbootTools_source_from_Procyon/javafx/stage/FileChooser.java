// 
// Decompiled by Procyon v0.5.36
// 

package javafx.stage;

import java.util.Arrays;
import com.sun.javafx.tk.Toolkit;
import java.util.Iterator;
import com.sun.glass.ui.CommonDialogs;
import java.util.Collections;
import java.util.List;
import com.sun.javafx.tk.FileChooserType;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.io.File;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;

public final class FileChooser
{
    private StringProperty title;
    private ObjectProperty<File> initialDirectory;
    private ObjectProperty<String> initialFileName;
    private ObservableList<ExtensionFilter> extensionFilters;
    private ObjectProperty<ExtensionFilter> selectedExtensionFilter;
    
    public FileChooser() {
        this.extensionFilters = FXCollections.observableArrayList();
    }
    
    public final void setTitle(final String s) {
        this.titleProperty().set(s);
    }
    
    public final String getTitle() {
        return (this.title != null) ? this.title.get() : null;
    }
    
    public final StringProperty titleProperty() {
        if (this.title == null) {
            this.title = new SimpleStringProperty(this, "title");
        }
        return this.title;
    }
    
    public final void setInitialDirectory(final File file) {
        this.initialDirectoryProperty().set(file);
    }
    
    public final File getInitialDirectory() {
        return (this.initialDirectory != null) ? this.initialDirectory.get() : null;
    }
    
    public final ObjectProperty<File> initialDirectoryProperty() {
        if (this.initialDirectory == null) {
            this.initialDirectory = new SimpleObjectProperty<File>(this, "initialDirectory");
        }
        return this.initialDirectory;
    }
    
    public final void setInitialFileName(final String s) {
        this.initialFileNameProperty().set(s);
    }
    
    public final String getInitialFileName() {
        return (this.initialFileName != null) ? this.initialFileName.get() : null;
    }
    
    public final ObjectProperty<String> initialFileNameProperty() {
        if (this.initialFileName == null) {
            this.initialFileName = new SimpleObjectProperty<String>(this, "initialFileName");
        }
        return this.initialFileName;
    }
    
    public ObservableList<ExtensionFilter> getExtensionFilters() {
        return this.extensionFilters;
    }
    
    public final ObjectProperty<ExtensionFilter> selectedExtensionFilterProperty() {
        if (this.selectedExtensionFilter == null) {
            this.selectedExtensionFilter = new SimpleObjectProperty<ExtensionFilter>(this, "selectedExtensionFilter");
        }
        return this.selectedExtensionFilter;
    }
    
    public final void setSelectedExtensionFilter(final ExtensionFilter value) {
        this.selectedExtensionFilterProperty().setValue(value);
    }
    
    public final ExtensionFilter getSelectedExtensionFilter() {
        return (this.selectedExtensionFilter != null) ? this.selectedExtensionFilter.get() : null;
    }
    
    public File showOpenDialog(final Window window) {
        final List<File> showDialog = this.showDialog(window, FileChooserType.OPEN);
        return (showDialog != null && showDialog.size() > 0) ? showDialog.get(0) : null;
    }
    
    public List<File> showOpenMultipleDialog(final Window window) {
        final List<File> showDialog = this.showDialog(window, FileChooserType.OPEN_MULTIPLE);
        return (List<File>)((showDialog != null && showDialog.size() > 0) ? Collections.unmodifiableList((List<?>)showDialog) : null);
    }
    
    public File showSaveDialog(final Window window) {
        final List<File> showDialog = this.showDialog(window, FileChooserType.SAVE);
        return (showDialog != null && showDialog.size() > 0) ? showDialog.get(0) : null;
    }
    
    private ExtensionFilter findSelectedFilter(final CommonDialogs.ExtensionFilter extensionFilter) {
        if (extensionFilter != null) {
            final String description = extensionFilter.getDescription();
            final List<String> extensions = extensionFilter.getExtensions();
            for (final ExtensionFilter extensionFilter2 : this.extensionFilters) {
                if (description.equals(extensionFilter2.getDescription()) && extensions.equals(extensionFilter2.getExtensions())) {
                    return extensionFilter2;
                }
            }
        }
        return null;
    }
    
    private List<File> showDialog(final Window window, final FileChooserType fileChooserType) {
        final CommonDialogs.FileChooserResult showFileChooser = Toolkit.getToolkit().showFileChooser((window != null) ? window.getPeer() : null, this.getTitle(), this.getInitialDirectory(), this.getInitialFileName(), fileChooserType, this.extensionFilters, this.getSelectedExtensionFilter());
        if (showFileChooser == null) {
            return null;
        }
        final List<File> files = showFileChooser.getFiles();
        if (files != null && files.size() > 0) {
            this.selectedExtensionFilterProperty().set(this.findSelectedFilter(showFileChooser.getExtensionFilter()));
        }
        return files;
    }
    
    public static final class ExtensionFilter
    {
        private final String description;
        private final List<String> extensions;
        
        public ExtensionFilter(final String description, final String... array) {
            validateArgs(description, array);
            this.description = description;
            this.extensions = Collections.unmodifiableList((List<? extends String>)Arrays.asList((T[])array.clone()));
        }
        
        public ExtensionFilter(final String description, final List<String> list) {
            final String[] a = (String[])((list != null) ? ((String[])list.toArray(new String[list.size()])) : null);
            validateArgs(description, a);
            this.description = description;
            this.extensions = (List<String>)Collections.unmodifiableList((List<?>)Arrays.asList((T[])a));
        }
        
        public String getDescription() {
            return this.description;
        }
        
        public List<String> getExtensions() {
            return this.extensions;
        }
        
        private static void validateArgs(final String s, final String[] array) {
            if (s == null) {
                throw new NullPointerException("Description must not be null");
            }
            if (s.isEmpty()) {
                throw new IllegalArgumentException("Description must not be empty");
            }
            if (array == null) {
                throw new NullPointerException("Extensions must not be null");
            }
            if (array.length == 0) {
                throw new IllegalArgumentException("At least one extension must be defined");
            }
            for (final String s2 : array) {
                if (s2 == null) {
                    throw new NullPointerException("Extension must not be null");
                }
                if (s2.isEmpty()) {
                    throw new IllegalArgumentException("Extension must not be empty");
                }
            }
        }
    }
}
