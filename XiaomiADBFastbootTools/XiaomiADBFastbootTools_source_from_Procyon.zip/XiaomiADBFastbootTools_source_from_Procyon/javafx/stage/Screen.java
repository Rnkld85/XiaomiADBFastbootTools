// 
// Decompiled by Procyon v0.5.36
// 

package javafx.stage;

import java.util.Iterator;
import java.util.List;
import java.util.Collection;
import javafx.collections.FXCollections;
import com.sun.javafx.tk.Toolkit;
import javafx.geometry.Rectangle2D;
import javafx.collections.ObservableList;
import com.sun.javafx.tk.ScreenConfigurationAccessor;
import java.util.concurrent.atomic.AtomicBoolean;

public final class Screen
{
    private static final AtomicBoolean configurationDirty;
    private static final ScreenConfigurationAccessor accessor;
    private static Screen primary;
    private static final ObservableList<Screen> screens;
    private static final ObservableList<Screen> unmodifiableScreens;
    private Rectangle2D bounds;
    private Rectangle2D visualBounds;
    private double dpi;
    private float outputScaleX;
    private float outputScaleY;
    
    private Screen() {
        this.bounds = Rectangle2D.EMPTY;
        this.visualBounds = Rectangle2D.EMPTY;
    }
    
    private static void checkDirty() {
        if (Screen.configurationDirty.compareAndSet(true, false)) {
            updateConfiguration();
        }
    }
    
    private static void updateConfiguration() {
        final Screen nativeToScreen = nativeToScreen(Toolkit.getToolkit().getPrimaryScreen(), Screen.primary);
        if (nativeToScreen != null) {
            Screen.primary = nativeToScreen;
        }
        final List<?> screens = Toolkit.getToolkit().getScreens();
        final ObservableList<Object> observableArrayList = FXCollections.observableArrayList();
        int n = (Screen.screens.size() == screens.size()) ? 1 : 0;
        for (int i = 0; i < screens.size(); ++i) {
            final Object value = screens.get(i);
            Screen screen = null;
            if (n != 0) {
                screen = Screen.screens.get(i);
            }
            final Screen nativeToScreen2 = nativeToScreen(value, screen);
            if (nativeToScreen2 != null) {
                if (n != 0) {
                    n = 0;
                    observableArrayList.clear();
                    observableArrayList.addAll(Screen.screens.subList(0, i));
                }
                observableArrayList.add(nativeToScreen2);
            }
        }
        if (n == 0) {
            Screen.screens.clear();
            Screen.screens.addAll((Collection<?>)observableArrayList);
        }
        Screen.configurationDirty.set(false);
    }
    
    private static Screen nativeToScreen(final Object o, final Screen screen) {
        final int minX = Screen.accessor.getMinX(o);
        final int minY = Screen.accessor.getMinY(o);
        final int width = Screen.accessor.getWidth(o);
        final int height = Screen.accessor.getHeight(o);
        final int visualMinX = Screen.accessor.getVisualMinX(o);
        final int visualMinY = Screen.accessor.getVisualMinY(o);
        final int visualWidth = Screen.accessor.getVisualWidth(o);
        final int visualHeight = Screen.accessor.getVisualHeight(o);
        final double dpi = Screen.accessor.getDPI(o);
        final float recommendedOutputScaleX = Screen.accessor.getRecommendedOutputScaleX(o);
        final float recommendedOutputScaleY = Screen.accessor.getRecommendedOutputScaleY(o);
        if (screen == null || screen.bounds.getMinX() != minX || screen.bounds.getMinY() != minY || screen.bounds.getWidth() != width || screen.bounds.getHeight() != height || screen.visualBounds.getMinX() != visualMinX || screen.visualBounds.getMinY() != visualMinY || screen.visualBounds.getWidth() != visualWidth || screen.visualBounds.getHeight() != visualHeight || screen.dpi != dpi || screen.outputScaleX != recommendedOutputScaleX || screen.outputScaleY != recommendedOutputScaleY) {
            final Screen screen2 = new Screen();
            screen2.bounds = new Rectangle2D(minX, minY, width, height);
            screen2.visualBounds = new Rectangle2D(visualMinX, visualMinY, visualWidth, visualHeight);
            screen2.dpi = dpi;
            screen2.outputScaleX = recommendedOutputScaleX;
            screen2.outputScaleY = recommendedOutputScaleY;
            return screen2;
        }
        return null;
    }
    
    static Screen getScreenForNative(final Object o) {
        final double n = Screen.accessor.getMinX(o);
        final double n2 = Screen.accessor.getMinY(o);
        final double n3 = Screen.accessor.getWidth(o);
        final double n4 = Screen.accessor.getHeight(o);
        Screen screen = null;
        for (int i = 0; i < Screen.screens.size(); ++i) {
            final Screen screen2 = Screen.screens.get(i);
            if (screen2.bounds.contains(n, n2, n3, n4)) {
                return screen2;
            }
            if (screen == null && screen2.bounds.intersects(n, n2, n3, n4)) {
                screen = screen2;
            }
        }
        return (screen == null) ? getPrimary() : screen;
    }
    
    public static Screen getPrimary() {
        checkDirty();
        return Screen.primary;
    }
    
    public static ObservableList<Screen> getScreens() {
        checkDirty();
        return Screen.unmodifiableScreens;
    }
    
    public static ObservableList<Screen> getScreensForRectangle(final double n, final double n2, final double n3, final double n4) {
        checkDirty();
        final ObservableList<Screen> observableArrayList = FXCollections.observableArrayList();
        for (final Screen screen : Screen.screens) {
            if (screen.bounds.intersects(n, n2, n3, n4)) {
                observableArrayList.add(screen);
            }
        }
        return observableArrayList;
    }
    
    public static ObservableList<Screen> getScreensForRectangle(final Rectangle2D rectangle2D) {
        checkDirty();
        return getScreensForRectangle(rectangle2D.getMinX(), rectangle2D.getMinY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    }
    
    public final Rectangle2D getBounds() {
        return this.bounds;
    }
    
    public final Rectangle2D getVisualBounds() {
        return this.visualBounds;
    }
    
    public final double getDpi() {
        return this.dpi;
    }
    
    public final double getOutputScaleX() {
        return this.outputScaleX;
    }
    
    public final double getOutputScaleY() {
        return this.outputScaleY;
    }
    
    @Override
    public int hashCode() {
        final long n = 37L * (37L * (37L * (37L * (37L * 7L + this.bounds.hashCode()) + this.visualBounds.hashCode()) + Double.doubleToLongBits(this.dpi)) + Float.floatToIntBits(this.outputScaleX)) + Float.floatToIntBits(this.outputScaleY);
        return (int)(n ^ n >> 32);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof Screen) {
            final Screen screen = (Screen)o;
            if (this.bounds == null) {
                if (screen.bounds != null) {
                    return false;
                }
            }
            else if (!this.bounds.equals(screen.bounds)) {
                return false;
            }
            if (this.visualBounds == null) {
                if (screen.visualBounds != null) {
                    return false;
                }
            }
            else if (!this.visualBounds.equals(screen.visualBounds)) {
                return false;
            }
            if (screen.dpi == this.dpi && screen.outputScaleX == this.outputScaleX && screen.outputScaleY == this.outputScaleY) {
                return true;
            }
            return false;
        }
        return false;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/geometry/Rectangle2D;Ljavafx/geometry/Rectangle2D;DFF)Ljava/lang/String;, super.toString(), this.bounds, this.visualBounds, this.dpi, this.outputScaleX, this.outputScaleY);
    }
    
    static {
        configurationDirty = new AtomicBoolean(true);
        screens = FXCollections.observableArrayList();
        unmodifiableScreens = FXCollections.unmodifiableObservableList(Screen.screens);
        accessor = Toolkit.getToolkit().setScreenConfigurationListener(() -> updateConfiguration());
    }
}
