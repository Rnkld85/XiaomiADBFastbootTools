// 
// Decompiled by Procyon v0.5.36
// 

package javafx.stage;

import javafx.scene.Node;
import javafx.collections.ObservableList;

public class Popup extends PopupWindow
{
    public final ObservableList<Node> getContent() {
        return super.getContent();
    }
}
