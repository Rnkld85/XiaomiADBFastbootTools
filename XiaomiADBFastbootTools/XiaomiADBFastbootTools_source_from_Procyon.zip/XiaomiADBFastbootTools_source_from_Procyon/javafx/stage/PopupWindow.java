// 
// Decompiled by Procyon v0.5.36
// 

package javafx.stage;

import com.sun.javafx.event.EventUtil;
import com.sun.javafx.event.DirectEvent;
import com.sun.javafx.stage.FocusUngrabEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCombination;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.event.EventRedirector;
import com.sun.javafx.event.EventHandlerManager;
import com.sun.javafx.stage.WindowCloseRequestHandler;
import com.sun.javafx.stage.WindowEventDispatcher;
import javafx.event.EventType;
import javafx.event.EventTarget;
import javafx.geometry.BoundingBox;
import javafx.geometry.Rectangle2D;
import com.sun.javafx.util.Utils;
import javafx.beans.property.ReadOnlyDoubleProperty;
import com.sun.javafx.stage.WindowHelper;
import com.sun.javafx.stage.WindowPeerListener;
import com.sun.javafx.stage.PopupWindowPeerListener;
import java.security.Permission;
import com.sun.javafx.FXPermissions;
import com.sun.javafx.tk.Toolkit;
import com.sun.javafx.perf.PerformanceTracker;
import java.util.Iterator;
import java.util.Collection;
import com.sun.javafx.scene.NodeHelper;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.Group;
import javafx.collections.ObservableList;
import com.sun.javafx.stage.PopupWindowHelper;
import javafx.scene.Scene;
import javafx.scene.paint.Paint;
import javafx.scene.Parent;
import com.sun.javafx.scene.SceneHelper;
import javafx.scene.layout.Background;
import javafx.scene.layout.Pane;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.BooleanPropertyBase;
import javafx.beans.Observable;
import java.util.ArrayList;
import javafx.geometry.Bounds;
import javafx.beans.property.ReadOnlyDoubleWrapper;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.BooleanProperty;
import javafx.scene.Node;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.WeakChangeListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.InvalidationListener;
import java.util.List;

public abstract class PopupWindow extends Window
{
    private final List<PopupWindow> children;
    private final InvalidationListener popupWindowUpdater;
    private ChangeListener<Boolean> changeListener;
    private WeakChangeListener<Boolean> weakOwnerNodeListener;
    private ReadOnlyObjectWrapper<Window> ownerWindow;
    private ReadOnlyObjectWrapper<Node> ownerNode;
    private BooleanProperty autoFix;
    private BooleanProperty autoHide;
    private ObjectProperty<EventHandler<Event>> onAutoHide;
    private BooleanProperty hideOnEscape;
    private BooleanProperty consumeAutoHidingEvents;
    private Window rootWindow;
    private final ReadOnlyDoubleWrapper anchorX;
    private final ReadOnlyDoubleWrapper anchorY;
    private final ObjectProperty<AnchorLocation> anchorLocation;
    private Bounds cachedExtendedBounds;
    private Bounds cachedAnchorBounds;
    private ChangeListener<Boolean> ownerFocusedListener;
    private boolean autofixActive;
    private boolean autohideActive;
    
    public PopupWindow() {
        this.children = new ArrayList<PopupWindow>();
        this.popupWindowUpdater = new InvalidationListener() {
            @Override
            public void invalidated(final Observable observable) {
                PopupWindow.this.cachedExtendedBounds = null;
                PopupWindow.this.cachedAnchorBounds = null;
                PopupWindow.this.updateWindow(PopupWindow.this.getAnchorX(), PopupWindow.this.getAnchorY());
            }
        };
        this.changeListener = ((p0, b, b2) -> {
            if (b && !b2) {
                this.hide();
            }
            return;
        });
        this.weakOwnerNodeListener = new WeakChangeListener<Boolean>(this.changeListener);
        this.ownerWindow = new ReadOnlyObjectWrapper<Window>(this, "ownerWindow");
        this.ownerNode = new ReadOnlyObjectWrapper<Node>(this, "ownerNode");
        this.autoFix = new BooleanPropertyBase(true) {
            @Override
            protected void invalidated() {
                PopupWindow.this.handleAutofixActivation(PopupWindow.this.isShowing(), this.get());
            }
            
            @Override
            public Object getBean() {
                return PopupWindow.this;
            }
            
            @Override
            public String getName() {
                return "autoFix";
            }
        };
        this.autoHide = new BooleanPropertyBase() {
            @Override
            protected void invalidated() {
                PopupWindow.this.handleAutohideActivation(PopupWindow.this.isShowing(), this.get());
            }
            
            @Override
            public Object getBean() {
                return PopupWindow.this;
            }
            
            @Override
            public String getName() {
                return "autoHide";
            }
        };
        this.onAutoHide = new SimpleObjectProperty<EventHandler<Event>>(this, "onAutoHide");
        this.hideOnEscape = new SimpleBooleanProperty(this, "hideOnEscape", true);
        this.consumeAutoHidingEvents = new SimpleBooleanProperty(this, "consumeAutoHidingEvents", true);
        this.anchorX = new ReadOnlyDoubleWrapper(this, "anchorX", Double.NaN);
        this.anchorY = new ReadOnlyDoubleWrapper(this, "anchorY", Double.NaN);
        this.anchorLocation = new ObjectPropertyBase<AnchorLocation>(AnchorLocation.WINDOW_TOP_LEFT) {
            @Override
            protected void invalidated() {
                PopupWindow.this.cachedAnchorBounds = null;
                PopupWindow.this.updateWindow(PopupWindow.this.windowToAnchorX(PopupWindow.this.getX()), PopupWindow.this.windowToAnchorY(PopupWindow.this.getY()));
            }
            
            @Override
            public Object getBean() {
                return PopupWindow.this;
            }
            
            @Override
            public String getName() {
                return "anchorLocation";
            }
        };
        final Pane pane = new Pane();
        pane.setBackground(Background.EMPTY);
        pane.getStyleClass().add("popup");
        final Scene popupScene = SceneHelper.createPopupScene(pane);
        popupScene.setFill(null);
        super.setScene(popupScene);
        pane.layoutBoundsProperty().addListener(this.popupWindowUpdater);
        pane.boundsInLocalProperty().addListener(this.popupWindowUpdater);
        popupScene.rootProperty().addListener(new InvalidationListener() {
            private Node oldRoot = popupScene.getRoot();
            
            @Override
            public void invalidated(final Observable observable) {
                final Parent root = popupScene.getRoot();
                if (this.oldRoot != root) {
                    if (this.oldRoot != null) {
                        this.oldRoot.layoutBoundsProperty().removeListener(PopupWindow.this.popupWindowUpdater);
                        this.oldRoot.boundsInLocalProperty().removeListener(PopupWindow.this.popupWindowUpdater);
                        this.oldRoot.getStyleClass().remove("popup");
                    }
                    if (root != null) {
                        root.layoutBoundsProperty().addListener(PopupWindow.this.popupWindowUpdater);
                        root.boundsInLocalProperty().addListener(PopupWindow.this.popupWindowUpdater);
                        root.getStyleClass().add("popup");
                    }
                    this.oldRoot = root;
                    PopupWindow.this.cachedExtendedBounds = null;
                    PopupWindow.this.cachedAnchorBounds = null;
                    PopupWindow.this.updateWindow(PopupWindow.this.getAnchorX(), PopupWindow.this.getAnchorY());
                }
            }
        });
        PopupWindowHelper.initHelper(this);
    }
    
    ObservableList<Node> getContent() {
        final Parent root = this.getScene().getRoot();
        if (root instanceof Group) {
            return ((Group)root).getChildren();
        }
        if (root instanceof Pane) {
            return ((Pane)root).getChildren();
        }
        throw new IllegalStateException("The content of the Popup can't be accessed");
    }
    
    public final Window getOwnerWindow() {
        return this.ownerWindow.get();
    }
    
    public final ReadOnlyObjectProperty<Window> ownerWindowProperty() {
        return this.ownerWindow.getReadOnlyProperty();
    }
    
    public final Node getOwnerNode() {
        return this.ownerNode.get();
    }
    
    public final ReadOnlyObjectProperty<Node> ownerNodeProperty() {
        return this.ownerNode.getReadOnlyProperty();
    }
    
    @Override
    protected final void setScene(final Scene scene) {
        throw new UnsupportedOperationException();
    }
    
    public final void setAutoFix(final boolean b) {
        this.autoFix.set(b);
    }
    
    public final boolean isAutoFix() {
        return this.autoFix.get();
    }
    
    public final BooleanProperty autoFixProperty() {
        return this.autoFix;
    }
    
    public final void setAutoHide(final boolean b) {
        this.autoHide.set(b);
    }
    
    public final boolean isAutoHide() {
        return this.autoHide.get();
    }
    
    public final BooleanProperty autoHideProperty() {
        return this.autoHide;
    }
    
    public final void setOnAutoHide(final EventHandler<Event> eventHandler) {
        this.onAutoHide.set(eventHandler);
    }
    
    public final EventHandler<Event> getOnAutoHide() {
        return this.onAutoHide.get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onAutoHideProperty() {
        return this.onAutoHide;
    }
    
    public final void setHideOnEscape(final boolean b) {
        this.hideOnEscape.set(b);
    }
    
    public final boolean isHideOnEscape() {
        return this.hideOnEscape.get();
    }
    
    public final BooleanProperty hideOnEscapeProperty() {
        return this.hideOnEscape;
    }
    
    public final void setConsumeAutoHidingEvents(final boolean b) {
        this.consumeAutoHidingEvents.set(b);
    }
    
    public final boolean getConsumeAutoHidingEvents() {
        return this.consumeAutoHidingEvents.get();
    }
    
    public final BooleanProperty consumeAutoHidingEventsProperty() {
        return this.consumeAutoHidingEvents;
    }
    
    public void show(final Window window) {
        this.validateOwnerWindow(window);
        this.showImpl(window);
    }
    
    public void show(final Node node, final double n, final double n2) {
        if (node == null) {
            throw new NullPointerException("The owner node must not be null");
        }
        final Scene scene = node.getScene();
        if (scene == null || scene.getWindow() == null) {
            throw new IllegalArgumentException("The owner node needs to be associated with a window");
        }
        final Window window = scene.getWindow();
        this.validateOwnerWindow(window);
        this.ownerNode.set(node);
        if (node != null) {
            NodeHelper.treeShowingProperty(node).addListener(this.weakOwnerNodeListener);
        }
        this.updateWindow(n, n2);
        this.showImpl(window);
    }
    
    public void show(final Window window, final double n, final double n2) {
        this.validateOwnerWindow(window);
        this.updateWindow(n, n2);
        this.showImpl(window);
    }
    
    private void showImpl(final Window window) {
        this.ownerWindow.set(window);
        if (window instanceof PopupWindow) {
            ((PopupWindow)window).children.add(this);
        }
        if (window != null) {
            window.showingProperty().addListener(this.weakOwnerNodeListener);
        }
        final Scene scene = this.getScene();
        SceneHelper.parentEffectiveOrientationInvalidated(scene);
        final Scene scene2 = getRootWindow(window).getScene();
        if (scene2 != null) {
            if (scene2.getUserAgentStylesheet() != null) {
                scene.setUserAgentStylesheet(scene2.getUserAgentStylesheet());
            }
            scene.getStylesheets().setAll(scene2.getStylesheets());
            if (scene.getCursor() == null) {
                scene.setCursor(scene2.getCursor());
            }
        }
        if (getRootWindow(window).isShowing()) {
            this.show();
        }
    }
    
    @Override
    public void hide() {
        for (final PopupWindow popupWindow : this.children) {
            if (popupWindow.isShowing()) {
                popupWindow.hide();
            }
        }
        this.children.clear();
        super.hide();
        if (this.getOwnerWindow() != null) {
            this.getOwnerWindow().showingProperty().removeListener(this.weakOwnerNodeListener);
        }
        if (this.getOwnerNode() != null) {
            NodeHelper.treeShowingProperty(this.getOwnerNode()).removeListener(this.weakOwnerNodeListener);
        }
    }
    
    private void doVisibleChanging(final boolean b) {
        PerformanceTracker.logEvent("PopupWindow.storeVisible for [PopupWindow]");
        final Toolkit toolkit = Toolkit.getToolkit();
        if (b && this.getPeer() == null) {
            StageStyle stageStyle;
            try {
                final SecurityManager securityManager = System.getSecurityManager();
                if (securityManager != null) {
                    securityManager.checkPermission(FXPermissions.CREATE_TRANSPARENT_WINDOW_PERMISSION);
                }
                stageStyle = StageStyle.TRANSPARENT;
            }
            catch (SecurityException ex) {
                stageStyle = StageStyle.UNDECORATED;
            }
            this.setPeer(toolkit.createTKPopupStage(this, stageStyle, this.getOwnerWindow().getPeer(), this.acc));
            this.setPeerListener(new PopupWindowPeerListener(this));
        }
    }
    
    private void doVisibleChanged(final boolean b) {
        final Window ownerWindow = this.getOwnerWindow();
        if (b) {
            this.rootWindow = getRootWindow(ownerWindow);
            this.startMonitorOwnerEvents(ownerWindow);
            this.bindOwnerFocusedProperty(ownerWindow);
            WindowHelper.setFocused(this, ownerWindow.isFocused());
            this.handleAutofixActivation(true, this.isAutoFix());
            this.handleAutohideActivation(true, this.isAutoHide());
        }
        else {
            this.stopMonitorOwnerEvents(ownerWindow);
            this.unbindOwnerFocusedProperty(ownerWindow);
            WindowHelper.setFocused(this, false);
            this.handleAutofixActivation(false, this.isAutoFix());
            this.handleAutohideActivation(false, this.isAutoHide());
            this.rootWindow = null;
        }
        PerformanceTracker.logEvent("PopupWindow.storeVisible for [PopupWindow] finished");
    }
    
    public final void setAnchorX(final double n) {
        this.updateWindow(n, this.getAnchorY());
    }
    
    public final double getAnchorX() {
        return this.anchorX.get();
    }
    
    public final ReadOnlyDoubleProperty anchorXProperty() {
        return this.anchorX.getReadOnlyProperty();
    }
    
    public final void setAnchorY(final double n) {
        this.updateWindow(this.getAnchorX(), n);
    }
    
    public final double getAnchorY() {
        return this.anchorY.get();
    }
    
    public final ReadOnlyDoubleProperty anchorYProperty() {
        return this.anchorY.getReadOnlyProperty();
    }
    
    public final void setAnchorLocation(final AnchorLocation anchorLocation) {
        this.anchorLocation.set(anchorLocation);
    }
    
    public final AnchorLocation getAnchorLocation() {
        return this.anchorLocation.get();
    }
    
    public final ObjectProperty<AnchorLocation> anchorLocationProperty() {
        return this.anchorLocation;
    }
    
    @Override
    void setXInternal(final double n) {
        this.updateWindow(this.windowToAnchorX(n), this.getAnchorY());
    }
    
    @Override
    void setYInternal(final double n) {
        this.updateWindow(this.getAnchorX(), this.windowToAnchorY(n));
    }
    
    @Override
    void notifyLocationChanged(final double n, final double n2) {
        super.notifyLocationChanged(n, n2);
        this.anchorX.set(this.windowToAnchorX(n));
        this.anchorY.set(this.windowToAnchorY(n2));
    }
    
    private Bounds getExtendedBounds() {
        if (this.cachedExtendedBounds == null) {
            final Parent root = this.getScene().getRoot();
            this.cachedExtendedBounds = this.union(root.getLayoutBounds(), root.getBoundsInLocal());
        }
        return this.cachedExtendedBounds;
    }
    
    private Bounds getAnchorBounds() {
        if (this.cachedAnchorBounds == null) {
            this.cachedAnchorBounds = (this.getAnchorLocation().isContentLocation() ? this.getScene().getRoot().getLayoutBounds() : this.getExtendedBounds());
        }
        return this.cachedAnchorBounds;
    }
    
    private void updateWindow(final double n, final double n2) {
        final AnchorLocation anchorLocation = this.getAnchorLocation();
        final Parent root = this.getScene().getRoot();
        final Bounds extendedBounds = this.getExtendedBounds();
        final Bounds anchorBounds = this.getAnchorBounds();
        final double xCoef = anchorLocation.getXCoef();
        final double yCoef = anchorLocation.getYCoef();
        final double n3 = xCoef * anchorBounds.getWidth();
        final double n4 = yCoef * anchorBounds.getHeight();
        double n5 = n - n3;
        double n6 = n2 - n4;
        if (this.autofixActive) {
            final Screen screenForPoint = Utils.getScreenForPoint(n, n2);
            final Rectangle2D rectangle2D = Utils.hasFullScreenStage(screenForPoint) ? screenForPoint.getBounds() : screenForPoint.getVisualBounds();
            if (xCoef <= 0.5) {
                n5 = Math.max(Math.min(n5, rectangle2D.getMaxX() - anchorBounds.getWidth()), rectangle2D.getMinX());
            }
            else {
                n5 = Math.min(Math.max(n5, rectangle2D.getMinX()), rectangle2D.getMaxX() - anchorBounds.getWidth());
            }
            if (yCoef <= 0.5) {
                n6 = Math.max(Math.min(n6, rectangle2D.getMaxY() - anchorBounds.getHeight()), rectangle2D.getMinY());
            }
            else {
                n6 = Math.min(Math.max(n6, rectangle2D.getMinY()), rectangle2D.getMaxY() - anchorBounds.getHeight());
            }
        }
        final double n7 = n5 - anchorBounds.getMinX() + extendedBounds.getMinX();
        final double n8 = n6 - anchorBounds.getMinY() + extendedBounds.getMinY();
        this.setWidth(extendedBounds.getWidth());
        this.setHeight(extendedBounds.getHeight());
        root.setTranslateX(-extendedBounds.getMinX());
        root.setTranslateY(-extendedBounds.getMinY());
        if (!Double.isNaN(n7)) {
            super.setXInternal(n7);
        }
        if (!Double.isNaN(n8)) {
            super.setYInternal(n8);
        }
        this.anchorX.set(n5 + n3);
        this.anchorY.set(n6 + n4);
    }
    
    private Bounds union(final Bounds bounds, final Bounds bounds2) {
        final double min = Math.min(bounds.getMinX(), bounds2.getMinX());
        final double min2 = Math.min(bounds.getMinY(), bounds2.getMinY());
        return new BoundingBox(min, min2, Math.max(bounds.getMaxX(), bounds2.getMaxX()) - min, Math.max(bounds.getMaxY(), bounds2.getMaxY()) - min2);
    }
    
    private double windowToAnchorX(final double n) {
        final Bounds anchorBounds = this.getAnchorBounds();
        return n - this.getExtendedBounds().getMinX() + anchorBounds.getMinX() + this.getAnchorLocation().getXCoef() * anchorBounds.getWidth();
    }
    
    private double windowToAnchorY(final double n) {
        final Bounds anchorBounds = this.getAnchorBounds();
        return n - this.getExtendedBounds().getMinY() + anchorBounds.getMinY() + this.getAnchorLocation().getYCoef() * anchorBounds.getHeight();
    }
    
    private static Window getRootWindow(Window ownerWindow) {
        while (ownerWindow instanceof PopupWindow) {
            ownerWindow = ((PopupWindow)ownerWindow).getOwnerWindow();
        }
        return ownerWindow;
    }
    
    void doAutoHide() {
        this.hide();
        if (this.getOnAutoHide() != null) {
            this.getOnAutoHide().handle(new Event(this, this, Event.ANY));
        }
    }
    
    @Override
    WindowEventDispatcher createInternalEventDispatcher() {
        return new WindowEventDispatcher(new PopupEventRedirector(this), new WindowCloseRequestHandler(this), new EventHandlerManager(this));
    }
    
    @Override
    Window getWindowOwner() {
        return this.getOwnerWindow();
    }
    
    private void startMonitorOwnerEvents(final Window window) {
        window.getInternalEventDispatcher().getEventRedirector().addEventDispatcher(this.getEventDispatcher());
    }
    
    private void stopMonitorOwnerEvents(final Window window) {
        window.getInternalEventDispatcher().getEventRedirector().removeEventDispatcher(this.getEventDispatcher());
    }
    
    private void bindOwnerFocusedProperty(final Window window) {
        this.ownerFocusedListener = ((p0, p1, b) -> WindowHelper.setFocused(this, b));
        window.focusedProperty().addListener(this.ownerFocusedListener);
    }
    
    private void unbindOwnerFocusedProperty(final Window window) {
        window.focusedProperty().removeListener(this.ownerFocusedListener);
        this.ownerFocusedListener = null;
    }
    
    private void handleAutofixActivation(final boolean b, final boolean b2) {
        final boolean autofixActive = b && b2;
        if (this.autofixActive != autofixActive) {
            this.autofixActive = autofixActive;
            if (autofixActive) {
                Screen.getScreens().addListener(this.popupWindowUpdater);
                this.updateWindow(this.getAnchorX(), this.getAnchorY());
            }
            else {
                Screen.getScreens().removeListener(this.popupWindowUpdater);
            }
        }
    }
    
    private void handleAutohideActivation(final boolean b, final boolean b2) {
        final boolean autohideActive = b && b2;
        if (this.autohideActive != autohideActive) {
            this.autohideActive = autohideActive;
            if (autohideActive) {
                this.rootWindow.increaseFocusGrabCounter();
            }
            else {
                this.rootWindow.decreaseFocusGrabCounter();
            }
        }
    }
    
    private void validateOwnerWindow(final Window window) {
        if (window == null) {
            throw new NullPointerException("Owner window must not be null");
        }
        if (wouldCreateCycle(window, this)) {
            throw new IllegalArgumentException("Specified owner window would create cycle in the window hierarchy");
        }
        if (this.isShowing() && this.getOwnerWindow() != window) {
            throw new IllegalStateException("Popup is already shown with different owner window");
        }
    }
    
    private static boolean wouldCreateCycle(Window windowOwner, final Window window) {
        while (windowOwner != null) {
            if (windowOwner == window) {
                return true;
            }
            windowOwner = windowOwner.getWindowOwner();
        }
        return false;
    }
    
    static {
        PopupWindowHelper.setPopupWindowAccessor(new PopupWindowHelper.PopupWindowAccessor() {
            @Override
            public void doVisibleChanging(final Window window, final boolean b) {
                ((PopupWindow)window).doVisibleChanging(b);
            }
            
            @Override
            public void doVisibleChanged(final Window window, final boolean b) {
                ((PopupWindow)window).doVisibleChanged(b);
            }
            
            @Override
            public ObservableList<Node> getContent(final PopupWindow popupWindow) {
                return popupWindow.getContent();
            }
        });
    }
    
    public enum AnchorLocation
    {
        WINDOW_TOP_LEFT(0.0, 0.0, false), 
        WINDOW_TOP_RIGHT(1.0, 0.0, false), 
        WINDOW_BOTTOM_LEFT(0.0, 1.0, false), 
        WINDOW_BOTTOM_RIGHT(1.0, 1.0, false), 
        CONTENT_TOP_LEFT(0.0, 0.0, true), 
        CONTENT_TOP_RIGHT(1.0, 0.0, true), 
        CONTENT_BOTTOM_LEFT(0.0, 1.0, true), 
        CONTENT_BOTTOM_RIGHT(1.0, 1.0, true);
        
        private final double xCoef;
        private final double yCoef;
        private final boolean contentLocation;
        
        private AnchorLocation(final double xCoef, final double yCoef, final boolean contentLocation) {
            this.xCoef = xCoef;
            this.yCoef = yCoef;
            this.contentLocation = contentLocation;
        }
        
        double getXCoef() {
            return this.xCoef;
        }
        
        double getYCoef() {
            return this.yCoef;
        }
        
        boolean isContentLocation() {
            return this.contentLocation;
        }
    }
    
    static class PopupEventRedirector extends EventRedirector
    {
        private static final KeyCombination ESCAPE_KEY_COMBINATION;
        private final PopupWindow popupWindow;
        
        public PopupEventRedirector(final PopupWindow popupWindow) {
            super(popupWindow);
            this.popupWindow = popupWindow;
        }
        
        @Override
        protected void handleRedirectedEvent(final Object o, final Event event) {
            if (event instanceof KeyEvent) {
                this.handleKeyEvent((KeyEvent)event);
                return;
            }
            final EventType<? extends Event> eventType = event.getEventType();
            if (eventType == MouseEvent.MOUSE_PRESSED || eventType == ScrollEvent.SCROLL) {
                this.handleAutoHidingEvents(o, event);
                return;
            }
            if (eventType == FocusUngrabEvent.FOCUS_UNGRAB) {
                this.handleFocusUngrabEvent();
            }
        }
        
        private void handleKeyEvent(final KeyEvent keyEvent) {
            if (keyEvent.isConsumed()) {
                return;
            }
            final Scene scene = this.popupWindow.getScene();
            if (scene != null) {
                final Node focusOwner = scene.getFocusOwner();
                final Scene scene2 = (Scene)((focusOwner != null) ? focusOwner : scene);
                if (EventUtil.fireEvent(scene2, new DirectEvent(keyEvent.copyFor(this.popupWindow, scene2))) == null) {
                    keyEvent.consume();
                    return;
                }
            }
            if (keyEvent.getEventType() == KeyEvent.KEY_PRESSED && PopupEventRedirector.ESCAPE_KEY_COMBINATION.match(keyEvent)) {
                this.handleEscapeKeyPressedEvent(keyEvent);
            }
        }
        
        private void handleEscapeKeyPressedEvent(final Event event) {
            if (this.popupWindow.isHideOnEscape()) {
                this.popupWindow.doAutoHide();
                if (this.popupWindow.getConsumeAutoHidingEvents()) {
                    event.consume();
                }
            }
        }
        
        private void handleAutoHidingEvents(final Object o, final Event event) {
            if (this.popupWindow.getOwnerWindow() != o) {
                return;
            }
            if (this.popupWindow.isAutoHide() && !this.isOwnerNodeEvent(event)) {
                Event.fireEvent(this.popupWindow, new FocusUngrabEvent());
                this.popupWindow.doAutoHide();
                if (this.popupWindow.getConsumeAutoHidingEvents()) {
                    event.consume();
                }
            }
        }
        
        private void handleFocusUngrabEvent() {
            if (this.popupWindow.isAutoHide()) {
                this.popupWindow.doAutoHide();
            }
        }
        
        private boolean isOwnerNodeEvent(final Event event) {
            final Node ownerNode = this.popupWindow.getOwnerNode();
            if (ownerNode == null) {
                return false;
            }
            final EventTarget target = event.getTarget();
            if (!(target instanceof Node)) {
                return false;
            }
            Node parent = (Node)target;
            while (parent != ownerNode) {
                parent = parent.getParent();
                if (parent == null) {
                    return false;
                }
            }
            return true;
        }
        
        static {
            ESCAPE_KEY_COMBINATION = KeyCombination.keyCombination("Esc");
        }
    }
}
