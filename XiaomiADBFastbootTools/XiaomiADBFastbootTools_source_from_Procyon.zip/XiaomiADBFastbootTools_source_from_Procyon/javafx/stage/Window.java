// 
// Decompiled by Procyon v0.5.36
// 

package javafx.stage;

import com.sun.javafx.util.Utils;
import javafx.event.EventDispatchChain;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.Scene;
import java.util.Map;
import javafx.collections.FXCollections;
import java.util.HashMap;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.geometry.Rectangle2D;
import com.sun.javafx.css.StyleManager;
import com.sun.javafx.tk.TKScene;
import com.sun.javafx.scene.SceneHelper;
import com.sun.javafx.tk.TKPulseListener;
import com.sun.javafx.tk.TKStageListener;
import com.sun.javafx.tk.Toolkit;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import java.security.AccessController;
import java.security.Permission;
import com.sun.javafx.FXPermissions;
import javafx.beans.property.ReadOnlyObjectWrapper;
import com.sun.javafx.stage.WindowEventDispatcher;
import javafx.event.EventDispatcher;
import javafx.event.EventHandler;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableMap;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyDoubleWrapper;
import com.sun.javafx.tk.TKStage;
import com.sun.javafx.stage.WindowPeerListener;
import java.security.AccessControlContext;
import com.sun.javafx.stage.WindowHelper;
import javafx.collections.ObservableList;
import javafx.event.EventTarget;

public class Window implements EventTarget
{
    private static ObservableList<Window> windows;
    private static ObservableList<Window> unmodifiableWindows;
    private WindowHelper windowHelper;
    final AccessControlContext acc;
    private WindowPeerListener peerListener;
    private TKStage peer;
    private TKBoundsConfigurator peerBoundsConfigurator;
    private boolean sizeToScene;
    private static final float CENTER_ON_SCREEN_X_FRACTION = 0.5f;
    private static final float CENTER_ON_SCREEN_Y_FRACTION = 0.33333334f;
    private ReadOnlyDoubleWrapper outputScaleX;
    private ReadOnlyDoubleWrapper outputScaleY;
    private BooleanProperty forceIntegerRenderScale;
    private DoubleProperty renderScaleX;
    private DoubleProperty renderScaleY;
    private boolean xExplicit;
    private ReadOnlyDoubleWrapper x;
    private boolean yExplicit;
    private ReadOnlyDoubleWrapper y;
    private boolean widthExplicit;
    private ReadOnlyDoubleWrapper width;
    private boolean heightExplicit;
    private ReadOnlyDoubleWrapper height;
    private ReadOnlyBooleanWrapper focused;
    private static final Object USER_DATA_KEY;
    private ObservableMap<Object, Object> properties;
    private SceneModel scene;
    private DoubleProperty opacity;
    private ObjectProperty<EventHandler<WindowEvent>> onCloseRequest;
    private ObjectProperty<EventHandler<WindowEvent>> onShowing;
    private ObjectProperty<EventHandler<WindowEvent>> onShown;
    private ObjectProperty<EventHandler<WindowEvent>> onHiding;
    private ObjectProperty<EventHandler<WindowEvent>> onHidden;
    private ReadOnlyBooleanWrapper showing;
    boolean hasBeenVisible;
    private ObjectProperty<EventDispatcher> eventDispatcher;
    private WindowEventDispatcher internalEventDispatcher;
    private int focusGrabCounter;
    private final ReadOnlyObjectWrapper<Screen> screen;
    
    public static ObservableList<Window> getWindows() {
        final SecurityManager securityManager = System.getSecurityManager();
        if (securityManager != null) {
            securityManager.checkPermission(FXPermissions.ACCESS_WINDOW_LIST_PERMISSION);
        }
        return Window.unmodifiableWindows;
    }
    
    protected Window() {
        this.windowHelper = null;
        this.acc = AccessController.getContext();
        this.peerBoundsConfigurator = new TKBoundsConfigurator();
        this.sizeToScene = false;
        this.outputScaleX = new ReadOnlyDoubleWrapper(this, "outputScaleX", 1.0);
        this.outputScaleY = new ReadOnlyDoubleWrapper(this, "outputScaleY", 1.0);
        this.forceIntegerRenderScale = new SimpleBooleanProperty((Object)this, "forceIntegerRenderScale", false) {
            @Override
            protected void invalidated() {
                Window.this.updateRenderScales(Window.this.getOutputScaleX(), Window.this.getOutputScaleY());
            }
        };
        this.renderScaleX = new SimpleDoubleProperty((Object)this, "renderScaleX", 1.0) {
            @Override
            protected void invalidated() {
                Window.this.peerBoundsConfigurator.setRenderScaleX(this.get());
            }
        };
        this.renderScaleY = new SimpleDoubleProperty((Object)this, "renderScaleY", 1.0) {
            @Override
            protected void invalidated() {
                Window.this.peerBoundsConfigurator.setRenderScaleY(this.get());
            }
        };
        this.xExplicit = false;
        this.x = new ReadOnlyDoubleWrapper(this, "x", Double.NaN);
        this.yExplicit = false;
        this.y = new ReadOnlyDoubleWrapper(this, "y", Double.NaN);
        this.widthExplicit = false;
        this.width = new ReadOnlyDoubleWrapper(this, "width", Double.NaN);
        this.heightExplicit = false;
        this.height = new ReadOnlyDoubleWrapper(this, "height", Double.NaN);
        this.focused = new ReadOnlyBooleanWrapper() {
            @Override
            protected void invalidated() {
                Window.this.focusChanged(this.get());
            }
            
            @Override
            public Object getBean() {
                return Window.this;
            }
            
            @Override
            public String getName() {
                return "focused";
            }
        };
        this.scene = new SceneModel();
        this.showing = new ReadOnlyBooleanWrapper() {
            private boolean oldVisible;
            
            @Override
            protected void invalidated() {
                final boolean value = this.get();
                if (this.oldVisible == value) {
                    return;
                }
                if (!this.oldVisible && value) {
                    Window.this.fireEvent(new WindowEvent(Window.this, WindowEvent.WINDOW_SHOWING));
                }
                else {
                    Window.this.fireEvent(new WindowEvent(Window.this, WindowEvent.WINDOW_HIDING));
                }
                this.oldVisible = value;
                WindowHelper.visibleChanging(Window.this, value);
                if (value) {
                    Window.this.hasBeenVisible = true;
                    Window.windows.add(Window.this);
                }
                else {
                    Window.windows.remove(Window.this);
                }
                final Toolkit toolkit = Toolkit.getToolkit();
                if (Window.this.peer != null) {
                    if (value) {
                        if (Window.this.peerListener == null) {
                            Window.this.peerListener = new WindowPeerListener(Window.this);
                        }
                        Window.this.peer.setTKStageListener(Window.this.peerListener);
                        toolkit.addStageTkPulseListener(Window.this.peerBoundsConfigurator);
                        if (Window.this.getScene() != null) {
                            SceneHelper.initPeer(Window.this.getScene());
                            Window.this.peer.setScene(SceneHelper.getPeer(Window.this.getScene()));
                            SceneHelper.preferredSize(Window.this.getScene());
                        }
                        Window.this.updateOutputScales(Window.this.peer.getOutputScaleX(), Window.this.peer.getOutputScaleY());
                        Window.this.peerBoundsConfigurator.setRenderScaleX(Window.this.getRenderScaleX());
                        Window.this.peerBoundsConfigurator.setRenderScaleY(Window.this.getRenderScaleY());
                        if (Window.this.getScene() != null && (!Window.this.widthExplicit || !Window.this.heightExplicit)) {
                            Window.this.adjustSize(true);
                        }
                        else {
                            Window.this.peerBoundsConfigurator.setSize(Window.this.getWidth(), Window.this.getHeight(), -1.0, -1.0);
                        }
                        if (!Window.this.xExplicit && !Window.this.yExplicit) {
                            Window.this.centerOnScreen();
                        }
                        else {
                            Window.this.peerBoundsConfigurator.setLocation(Window.this.getX(), Window.this.getY(), 0.0f, 0.0f);
                        }
                        Window.this.applyBounds();
                        Window.this.peer.setOpacity((float)Window.this.getOpacity());
                        Window.this.peer.setVisible(true);
                        Window.this.fireEvent(new WindowEvent(Window.this, WindowEvent.WINDOW_SHOWN));
                    }
                    else {
                        Window.this.peer.setVisible(false);
                        Window.this.fireEvent(new WindowEvent(Window.this, WindowEvent.WINDOW_HIDDEN));
                        if (Window.this.getScene() != null) {
                            Window.this.peer.setScene(null);
                            SceneHelper.disposePeer(Window.this.getScene());
                            StyleManager.getInstance().forget(Window.this.getScene());
                        }
                        toolkit.removeStageTkPulseListener(Window.this.peerBoundsConfigurator);
                        Window.this.peer.setTKStageListener(null);
                        Window.this.peer.close();
                    }
                }
                if (value) {
                    toolkit.requestNextPulse();
                }
                WindowHelper.visibleChanged(Window.this, value);
                if (Window.this.sizeToScene) {
                    if (value) {
                        Window.this.sizeToScene();
                    }
                    Window.this.sizeToScene = false;
                }
            }
            
            @Override
            public Object getBean() {
                return Window.this;
            }
            
            @Override
            public String getName() {
                return "showing";
            }
        };
        this.hasBeenVisible = false;
        this.screen = new ReadOnlyObjectWrapper<Screen>(Screen.getPrimary());
        this.initializeInternalEventDispatcher();
        WindowHelper.initHelper(this);
    }
    
    WindowPeerListener getPeerListener() {
        return this.peerListener;
    }
    
    void setPeerListener(final WindowPeerListener peerListener) {
        this.peerListener = peerListener;
    }
    
    TKStage getPeer() {
        return this.peer;
    }
    
    void setPeer(final TKStage peer) {
        this.peer = peer;
    }
    
    public void sizeToScene() {
        if (this.getScene() != null && this.peer != null) {
            SceneHelper.preferredSize(this.getScene());
            this.adjustSize(false);
        }
        else {
            this.sizeToScene = true;
        }
    }
    
    private void adjustSize(final boolean b) {
        if (this.getScene() == null) {
            return;
        }
        if (this.peer != null) {
            final double width = this.getScene().getWidth();
            final double n = (width > 0.0) ? width : -1.0;
            double width2 = -1.0;
            if (b && this.widthExplicit) {
                width2 = this.getWidth();
            }
            else if (n <= 0.0) {
                width2 = (this.widthExplicit ? this.getWidth() : -1.0);
            }
            else {
                this.widthExplicit = false;
            }
            final double height = this.getScene().getHeight();
            final double n2 = (height > 0.0) ? height : -1.0;
            double height2 = -1.0;
            if (b && this.heightExplicit) {
                height2 = this.getHeight();
            }
            else if (n2 <= 0.0) {
                height2 = (this.heightExplicit ? this.getHeight() : -1.0);
            }
            else {
                this.heightExplicit = false;
            }
            this.peerBoundsConfigurator.setSize(width2, height2, n, n2);
            this.applyBounds();
        }
    }
    
    public void centerOnScreen() {
        this.xExplicit = false;
        this.yExplicit = false;
        if (this.peer != null) {
            final Rectangle2D visualBounds = this.getWindowScreen().getVisualBounds();
            final double n = visualBounds.getMinX() + (visualBounds.getWidth() - this.getWidth()) * 0.5;
            final double n2 = visualBounds.getMinY() + (visualBounds.getHeight() - this.getHeight()) * 0.3333333432674408;
            this.x.set(n);
            this.y.set(n2);
            this.peerBoundsConfigurator.setLocation(n, n2, 0.5f, 0.33333334f);
            this.applyBounds();
        }
    }
    
    private void updateOutputScales(final double n, final double n2) {
        this.updateRenderScales(n, n2);
        this.outputScaleX.set(n);
        this.outputScaleY.set(n2);
    }
    
    void updateRenderScales(final double a, final double a2) {
        final boolean value = this.forceIntegerRenderScale.get();
        if (!this.renderScaleX.isBound()) {
            this.renderScaleX.set(value ? Math.ceil(a) : a);
        }
        if (!this.renderScaleY.isBound()) {
            this.renderScaleY.set(value ? Math.ceil(a2) : a2);
        }
    }
    
    public final double getOutputScaleX() {
        return this.outputScaleX.get();
    }
    
    public final ReadOnlyDoubleProperty outputScaleXProperty() {
        return this.outputScaleX.getReadOnlyProperty();
    }
    
    public final double getOutputScaleY() {
        return this.outputScaleY.get();
    }
    
    public final ReadOnlyDoubleProperty outputScaleYProperty() {
        return this.outputScaleY.getReadOnlyProperty();
    }
    
    public final void setForceIntegerRenderScale(final boolean b) {
        this.forceIntegerRenderScale.set(b);
    }
    
    public final boolean isForceIntegerRenderScale() {
        return this.forceIntegerRenderScale.get();
    }
    
    public final BooleanProperty forceIntegerRenderScaleProperty() {
        return this.forceIntegerRenderScale;
    }
    
    public final void setRenderScaleX(final double n) {
        this.renderScaleX.set(n);
    }
    
    public final double getRenderScaleX() {
        return this.renderScaleX.get();
    }
    
    public final DoubleProperty renderScaleXProperty() {
        return this.renderScaleX;
    }
    
    public final void setRenderScaleY(final double n) {
        this.renderScaleY.set(n);
    }
    
    public final double getRenderScaleY() {
        return this.renderScaleY.get();
    }
    
    public final DoubleProperty renderScaleYProperty() {
        return this.renderScaleY;
    }
    
    public final void setX(final double xInternal) {
        this.setXInternal(xInternal);
    }
    
    public final double getX() {
        return this.x.get();
    }
    
    public final ReadOnlyDoubleProperty xProperty() {
        return this.x.getReadOnlyProperty();
    }
    
    void setXInternal(final double n) {
        this.x.set(n);
        this.peerBoundsConfigurator.setX(n, 0.0f);
        this.xExplicit = true;
    }
    
    public final void setY(final double yInternal) {
        this.setYInternal(yInternal);
    }
    
    public final double getY() {
        return this.y.get();
    }
    
    public final ReadOnlyDoubleProperty yProperty() {
        return this.y.getReadOnlyProperty();
    }
    
    void setYInternal(final double n) {
        this.y.set(n);
        this.peerBoundsConfigurator.setY(n, 0.0f);
        this.yExplicit = true;
    }
    
    void notifyLocationChanged(final double n, final double n2) {
        this.x.set(n);
        this.y.set(n2);
    }
    
    public final void setWidth(final double windowWidth) {
        this.width.set(windowWidth);
        this.peerBoundsConfigurator.setWindowWidth(windowWidth);
        this.widthExplicit = true;
    }
    
    public final double getWidth() {
        return this.width.get();
    }
    
    public final ReadOnlyDoubleProperty widthProperty() {
        return this.width.getReadOnlyProperty();
    }
    
    public final void setHeight(final double windowHeight) {
        this.height.set(windowHeight);
        this.peerBoundsConfigurator.setWindowHeight(windowHeight);
        this.heightExplicit = true;
    }
    
    public final double getHeight() {
        return this.height.get();
    }
    
    public final ReadOnlyDoubleProperty heightProperty() {
        return this.height.getReadOnlyProperty();
    }
    
    void notifySizeChanged(final double n, final double n2) {
        this.width.set(n);
        this.height.set(n2);
    }
    
    final void setFocused(final boolean b) {
        this.focused.set(b);
    }
    
    public final void requestFocus() {
        if (this.peer != null) {
            this.peer.requestFocus();
        }
    }
    
    public final boolean isFocused() {
        return this.focused.get();
    }
    
    public final ReadOnlyBooleanProperty focusedProperty() {
        return this.focused.getReadOnlyProperty();
    }
    
    public final ObservableMap<Object, Object> getProperties() {
        if (this.properties == null) {
            this.properties = FXCollections.observableMap(new HashMap<Object, Object>());
        }
        return this.properties;
    }
    
    public boolean hasProperties() {
        return this.properties != null && !this.properties.isEmpty();
    }
    
    public void setUserData(final Object o) {
        this.getProperties().put(Window.USER_DATA_KEY, o);
    }
    
    public Object getUserData() {
        return this.getProperties().get(Window.USER_DATA_KEY);
    }
    
    protected void setScene(final Scene scene) {
        this.scene.set(scene);
    }
    
    public final Scene getScene() {
        return this.scene.get();
    }
    
    public final ReadOnlyObjectProperty<Scene> sceneProperty() {
        return this.scene.getReadOnlyProperty();
    }
    
    public final void setOpacity(final double n) {
        this.opacityProperty().set(n);
    }
    
    public final double getOpacity() {
        return (this.opacity == null) ? 1.0 : this.opacity.get();
    }
    
    public final DoubleProperty opacityProperty() {
        if (this.opacity == null) {
            this.opacity = new DoublePropertyBase(1.0) {
                @Override
                protected void invalidated() {
                    if (Window.this.peer != null) {
                        Window.this.peer.setOpacity((float)this.get());
                    }
                }
                
                @Override
                public Object getBean() {
                    return Window.this;
                }
                
                @Override
                public String getName() {
                    return "opacity";
                }
            };
        }
        return this.opacity;
    }
    
    public final void setOnCloseRequest(final EventHandler<WindowEvent> eventHandler) {
        this.onCloseRequestProperty().set(eventHandler);
    }
    
    public final EventHandler<WindowEvent> getOnCloseRequest() {
        return (this.onCloseRequest != null) ? this.onCloseRequest.get() : null;
    }
    
    public final ObjectProperty<EventHandler<WindowEvent>> onCloseRequestProperty() {
        if (this.onCloseRequest == null) {
            this.onCloseRequest = new ObjectPropertyBase<EventHandler<WindowEvent>>() {
                @Override
                protected void invalidated() {
                    Window.this.setEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, ((ObjectPropertyBase<EventHandler<? super WindowEvent>>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return Window.this;
                }
                
                @Override
                public String getName() {
                    return "onCloseRequest";
                }
            };
        }
        return this.onCloseRequest;
    }
    
    public final void setOnShowing(final EventHandler<WindowEvent> eventHandler) {
        this.onShowingProperty().set(eventHandler);
    }
    
    public final EventHandler<WindowEvent> getOnShowing() {
        return (this.onShowing == null) ? null : this.onShowing.get();
    }
    
    public final ObjectProperty<EventHandler<WindowEvent>> onShowingProperty() {
        if (this.onShowing == null) {
            this.onShowing = new ObjectPropertyBase<EventHandler<WindowEvent>>() {
                @Override
                protected void invalidated() {
                    Window.this.setEventHandler(WindowEvent.WINDOW_SHOWING, ((ObjectPropertyBase<EventHandler<? super WindowEvent>>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return Window.this;
                }
                
                @Override
                public String getName() {
                    return "onShowing";
                }
            };
        }
        return this.onShowing;
    }
    
    public final void setOnShown(final EventHandler<WindowEvent> eventHandler) {
        this.onShownProperty().set(eventHandler);
    }
    
    public final EventHandler<WindowEvent> getOnShown() {
        return (this.onShown == null) ? null : this.onShown.get();
    }
    
    public final ObjectProperty<EventHandler<WindowEvent>> onShownProperty() {
        if (this.onShown == null) {
            this.onShown = new ObjectPropertyBase<EventHandler<WindowEvent>>() {
                @Override
                protected void invalidated() {
                    Window.this.setEventHandler(WindowEvent.WINDOW_SHOWN, ((ObjectPropertyBase<EventHandler<? super WindowEvent>>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return Window.this;
                }
                
                @Override
                public String getName() {
                    return "onShown";
                }
            };
        }
        return this.onShown;
    }
    
    public final void setOnHiding(final EventHandler<WindowEvent> eventHandler) {
        this.onHidingProperty().set(eventHandler);
    }
    
    public final EventHandler<WindowEvent> getOnHiding() {
        return (this.onHiding == null) ? null : this.onHiding.get();
    }
    
    public final ObjectProperty<EventHandler<WindowEvent>> onHidingProperty() {
        if (this.onHiding == null) {
            this.onHiding = new ObjectPropertyBase<EventHandler<WindowEvent>>() {
                @Override
                protected void invalidated() {
                    Window.this.setEventHandler(WindowEvent.WINDOW_HIDING, ((ObjectPropertyBase<EventHandler<? super WindowEvent>>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return Window.this;
                }
                
                @Override
                public String getName() {
                    return "onHiding";
                }
            };
        }
        return this.onHiding;
    }
    
    public final void setOnHidden(final EventHandler<WindowEvent> eventHandler) {
        this.onHiddenProperty().set(eventHandler);
    }
    
    public final EventHandler<WindowEvent> getOnHidden() {
        return (this.onHidden == null) ? null : this.onHidden.get();
    }
    
    public final ObjectProperty<EventHandler<WindowEvent>> onHiddenProperty() {
        if (this.onHidden == null) {
            this.onHidden = new ObjectPropertyBase<EventHandler<WindowEvent>>() {
                @Override
                protected void invalidated() {
                    Window.this.setEventHandler(WindowEvent.WINDOW_HIDDEN, ((ObjectPropertyBase<EventHandler<? super WindowEvent>>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return Window.this;
                }
                
                @Override
                public String getName() {
                    return "onHidden";
                }
            };
        }
        return this.onHidden;
    }
    
    private void setShowing(final boolean b) {
        Toolkit.getToolkit().checkFxUserThread();
        this.showing.set(b);
    }
    
    public final boolean isShowing() {
        return this.showing.get();
    }
    
    public final ReadOnlyBooleanProperty showingProperty() {
        return this.showing.getReadOnlyProperty();
    }
    
    protected void show() {
        this.setShowing(true);
    }
    
    public void hide() {
        this.setShowing(false);
    }
    
    private void doVisibleChanging(final boolean b) {
        if (b && this.getScene() != null) {
            NodeHelper.reapplyCSS(this.getScene().getRoot());
        }
    }
    
    private void doVisibleChanged(final boolean b) {
        assert this.peer != null;
        if (!b) {
            this.peerListener = null;
            this.peer = null;
        }
    }
    
    public final void setEventDispatcher(final EventDispatcher eventDispatcher) {
        this.eventDispatcherProperty().set(eventDispatcher);
    }
    
    public final EventDispatcher getEventDispatcher() {
        return this.eventDispatcherProperty().get();
    }
    
    public final ObjectProperty<EventDispatcher> eventDispatcherProperty() {
        this.initializeInternalEventDispatcher();
        return this.eventDispatcher;
    }
    
    public final <T extends Event> void addEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().addEventHandler(eventType, eventHandler);
    }
    
    public final <T extends Event> void removeEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().removeEventHandler(eventType, eventHandler);
    }
    
    public final <T extends Event> void addEventFilter(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().addEventFilter(eventType, eventHandler);
    }
    
    public final <T extends Event> void removeEventFilter(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().removeEventFilter(eventType, eventHandler);
    }
    
    protected final <T extends Event> void setEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().setEventHandler(eventType, eventHandler);
    }
    
    WindowEventDispatcher getInternalEventDispatcher() {
        this.initializeInternalEventDispatcher();
        return this.internalEventDispatcher;
    }
    
    private void initializeInternalEventDispatcher() {
        if (this.internalEventDispatcher == null) {
            this.internalEventDispatcher = this.createInternalEventDispatcher();
            this.eventDispatcher = new SimpleObjectProperty<EventDispatcher>(this, "eventDispatcher", this.internalEventDispatcher);
        }
    }
    
    WindowEventDispatcher createInternalEventDispatcher() {
        return new WindowEventDispatcher(this);
    }
    
    public final void fireEvent(final Event event) {
        Event.fireEvent(this, event);
    }
    
    @Override
    public EventDispatchChain buildEventDispatchChain(EventDispatchChain prepend) {
        if (this.eventDispatcher != null) {
            final EventDispatcher eventDispatcher = this.eventDispatcher.get();
            if (eventDispatcher != null) {
                prepend = prepend.prepend(eventDispatcher);
            }
        }
        return prepend;
    }
    
    void increaseFocusGrabCounter() {
        if (++this.focusGrabCounter == 1 && this.peer != null && this.isFocused()) {
            this.peer.grabFocus();
        }
    }
    
    void decreaseFocusGrabCounter() {
        final int focusGrabCounter = this.focusGrabCounter - 1;
        this.focusGrabCounter = focusGrabCounter;
        if (focusGrabCounter == 0 && this.peer != null) {
            this.peer.ungrabFocus();
        }
    }
    
    private void focusChanged(final boolean b) {
        if (this.focusGrabCounter > 0 && this.peer != null && b) {
            this.peer.grabFocus();
        }
    }
    
    final void applyBounds() {
        this.peerBoundsConfigurator.apply();
    }
    
    Window getWindowOwner() {
        return null;
    }
    
    private Screen getWindowScreen() {
        Window windowOwner = this;
        while (Double.isNaN(windowOwner.getX()) || Double.isNaN(windowOwner.getY()) || Double.isNaN(windowOwner.getWidth()) || Double.isNaN(windowOwner.getHeight())) {
            windowOwner = windowOwner.getWindowOwner();
            if (windowOwner == null) {
                return Screen.getPrimary();
            }
        }
        return Utils.getScreenForRectangle(new Rectangle2D(windowOwner.getX(), windowOwner.getY(), windowOwner.getWidth(), windowOwner.getHeight()));
    }
    
    private ReadOnlyObjectProperty<Screen> screenProperty() {
        return this.screen.getReadOnlyProperty();
    }
    
    private void notifyScreenChanged(final Object o, final Object o2) {
        this.screen.set(Screen.getScreenForNative(o2));
    }
    
    static {
        Window.windows = FXCollections.observableArrayList();
        Window.unmodifiableWindows = FXCollections.unmodifiableObservableList(Window.windows);
        WindowHelper.setWindowAccessor(new WindowHelper.WindowAccessor() {
            @Override
            public WindowHelper getHelper(final Window window) {
                return window.windowHelper;
            }
            
            @Override
            public void setHelper(final Window window, final WindowHelper windowHelper) {
                window.windowHelper = windowHelper;
            }
            
            @Override
            public void doVisibleChanging(final Window window, final boolean b) {
                window.doVisibleChanging(b);
            }
            
            @Override
            public void doVisibleChanged(final Window window, final boolean b) {
                window.doVisibleChanged(b);
            }
            
            @Override
            public TKStage getPeer(final Window window) {
                return window.getPeer();
            }
            
            @Override
            public void setPeer(final Window window, final TKStage peer) {
                window.setPeer(peer);
            }
            
            @Override
            public WindowPeerListener getPeerListener(final Window window) {
                return window.getPeerListener();
            }
            
            @Override
            public void setPeerListener(final Window window, final WindowPeerListener peerListener) {
                window.setPeerListener(peerListener);
            }
            
            @Override
            public void setFocused(final Window window, final boolean focused) {
                window.setFocused(focused);
            }
            
            @Override
            public void notifyLocationChanged(final Window window, final double n, final double n2) {
                window.notifyLocationChanged(n, n2);
            }
            
            @Override
            public void notifySizeChanged(final Window window, final double n, final double n2) {
                window.notifySizeChanged(n, n2);
            }
            
            @Override
            public void notifyScaleChanged(final Window window, final double n, final double n2) {
                window.updateOutputScales(n, n2);
            }
            
            @Override
            public void notifyScreenChanged(final Window window, final Object o, final Object o2) {
                window.notifyScreenChanged(o, o2);
            }
            
            @Override
            public float getPlatformScaleX(final Window window) {
                final TKStage peer = window.getPeer();
                return (peer == null) ? 1.0f : peer.getPlatformScaleX();
            }
            
            @Override
            public float getPlatformScaleY(final Window window) {
                final TKStage peer = window.getPeer();
                return (peer == null) ? 1.0f : peer.getPlatformScaleY();
            }
            
            @Override
            public ReadOnlyObjectProperty<Screen> screenProperty(final Window window) {
                return window.screenProperty();
            }
            
            @Override
            public AccessControlContext getAccessControlContext(final Window window) {
                return window.acc;
            }
        });
        USER_DATA_KEY = new Object();
    }
    
    private final class SceneModel extends ReadOnlyObjectWrapper<Scene>
    {
        private Scene oldScene;
        
        @Override
        protected void invalidated() {
            final Scene oldScene = this.get();
            if (this.oldScene == oldScene) {
                return;
            }
            if (Window.this.peer != null) {
                Toolkit.getToolkit().checkFxUserThread();
            }
            this.updatePeerScene(null);
            if (this.oldScene != null) {
                SceneHelper.setWindow(this.oldScene, null);
                StyleManager.getInstance().forget(this.oldScene);
            }
            if (oldScene != null) {
                final Window window = oldScene.getWindow();
                if (window != null) {
                    window.setScene(null);
                }
                SceneHelper.setWindow(oldScene, Window.this);
                this.updatePeerScene(SceneHelper.getPeer(oldScene));
                if (Window.this.isShowing()) {
                    NodeHelper.reapplyCSS(oldScene.getRoot());
                    if (!Window.this.widthExplicit || !Window.this.heightExplicit) {
                        SceneHelper.preferredSize(Window.this.getScene());
                        Window.this.adjustSize(true);
                    }
                }
            }
            this.oldScene = oldScene;
        }
        
        @Override
        public Object getBean() {
            return Window.this;
        }
        
        @Override
        public String getName() {
            return "scene";
        }
        
        private void updatePeerScene(final TKScene scene) {
            if (Window.this.peer != null) {
                Window.this.peer.setScene(scene);
            }
        }
    }
    
    private final class TKBoundsConfigurator implements TKPulseListener
    {
        private double renderScaleX;
        private double renderScaleY;
        private double x;
        private double y;
        private float xGravity;
        private float yGravity;
        private double windowWidth;
        private double windowHeight;
        private double clientWidth;
        private double clientHeight;
        private boolean dirty;
        
        public TKBoundsConfigurator() {
            this.reset();
        }
        
        public void setRenderScaleX(final double renderScaleX) {
            this.renderScaleX = renderScaleX;
            this.setDirty();
        }
        
        public void setRenderScaleY(final double renderScaleY) {
            this.renderScaleY = renderScaleY;
            this.setDirty();
        }
        
        public void setX(final double x, final float xGravity) {
            this.x = x;
            this.xGravity = xGravity;
            this.setDirty();
        }
        
        public void setY(final double y, final float yGravity) {
            this.y = y;
            this.yGravity = yGravity;
            this.setDirty();
        }
        
        public void setWindowWidth(final double windowWidth) {
            this.windowWidth = windowWidth;
            this.setDirty();
        }
        
        public void setWindowHeight(final double windowHeight) {
            this.windowHeight = windowHeight;
            this.setDirty();
        }
        
        public void setClientWidth(final double clientWidth) {
            this.clientWidth = clientWidth;
            this.setDirty();
        }
        
        public void setClientHeight(final double clientHeight) {
            this.clientHeight = clientHeight;
            this.setDirty();
        }
        
        public void setLocation(final double x, final double y, final float xGravity, final float yGravity) {
            this.x = x;
            this.y = y;
            this.xGravity = xGravity;
            this.yGravity = yGravity;
            this.setDirty();
        }
        
        public void setSize(final double windowWidth, final double windowHeight, final double clientWidth, final double clientHeight) {
            this.windowWidth = windowWidth;
            this.windowHeight = windowHeight;
            this.clientWidth = clientWidth;
            this.clientHeight = clientHeight;
            this.setDirty();
        }
        
        public void apply() {
            if (this.dirty) {
                final boolean b = !Double.isNaN(this.x);
                final float n = b ? ((float)this.x) : 0.0f;
                final boolean b2 = !Double.isNaN(this.y);
                final float n2 = b2 ? ((float)this.y) : 0.0f;
                final float n3 = (float)this.windowWidth;
                final float n4 = (float)this.windowHeight;
                final float n5 = (float)this.clientWidth;
                final float n6 = (float)this.clientHeight;
                final float xGravity = this.xGravity;
                final float yGravity = this.yGravity;
                final float n7 = (float)this.renderScaleX;
                final float n8 = (float)this.renderScaleY;
                this.reset();
                Window.this.peer.setBounds(n, n2, b, b2, n3, n4, n5, n6, xGravity, yGravity, n7, n8);
            }
        }
        
        @Override
        public void pulse() {
            this.apply();
        }
        
        private void reset() {
            this.renderScaleX = 0.0;
            this.renderScaleY = 0.0;
            this.x = Double.NaN;
            this.y = Double.NaN;
            this.xGravity = 0.0f;
            this.yGravity = 0.0f;
            this.windowWidth = -1.0;
            this.windowHeight = -1.0;
            this.clientWidth = -1.0;
            this.clientHeight = -1.0;
            this.dirty = false;
        }
        
        private void setDirty() {
            if (!this.dirty) {
                Toolkit.getToolkit().requestNextPulse();
                this.dirty = true;
            }
        }
    }
}
