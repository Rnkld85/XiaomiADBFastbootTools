// 
// Decompiled by Procyon v0.5.36
// 

package javafx.geometry;

import javafx.beans.NamedArg;

public class Insets
{
    public static final Insets EMPTY;
    private double top;
    private double right;
    private double bottom;
    private double left;
    private int hash;
    
    public final double getTop() {
        return this.top;
    }
    
    public final double getRight() {
        return this.right;
    }
    
    public final double getBottom() {
        return this.bottom;
    }
    
    public final double getLeft() {
        return this.left;
    }
    
    public Insets(@NamedArg("top") final double top, @NamedArg("right") final double right, @NamedArg("bottom") final double bottom, @NamedArg("left") final double left) {
        this.hash = 0;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
        this.left = left;
    }
    
    public Insets(@NamedArg("topRightBottomLeft") final double n) {
        this.hash = 0;
        this.top = n;
        this.right = n;
        this.bottom = n;
        this.left = n;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof Insets) {
            final Insets insets = (Insets)o;
            return this.top == insets.top && this.right == insets.right && this.bottom == insets.bottom && this.left == insets.left;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            final long n = 37L * (37L * (37L * (37L * 17L + Double.doubleToLongBits(this.top)) + Double.doubleToLongBits(this.right)) + Double.doubleToLongBits(this.bottom)) + Double.doubleToLongBits(this.left);
            this.hash = (int)(n ^ n >> 32);
        }
        return this.hash;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(DDDD)Ljava/lang/String;, this.top, this.right, this.bottom, this.left);
    }
    
    static {
        EMPTY = new Insets(0.0, 0.0, 0.0, 0.0);
    }
}
