// 
// Decompiled by Procyon v0.5.36
// 

package javafx.geometry;

public abstract class Bounds
{
    private double minX;
    private double minY;
    private double minZ;
    private double width;
    private double height;
    private double depth;
    private double maxX;
    private double maxY;
    private double maxZ;
    
    public final double getMinX() {
        return this.minX;
    }
    
    public final double getMinY() {
        return this.minY;
    }
    
    public final double getMinZ() {
        return this.minZ;
    }
    
    public final double getWidth() {
        return this.width;
    }
    
    public final double getHeight() {
        return this.height;
    }
    
    public final double getDepth() {
        return this.depth;
    }
    
    public final double getMaxX() {
        return this.maxX;
    }
    
    public final double getMaxY() {
        return this.maxY;
    }
    
    public final double getMaxZ() {
        return this.maxZ;
    }
    
    public final double getCenterX() {
        return (this.getMaxX() + this.getMinX()) * 0.5;
    }
    
    public final double getCenterY() {
        return (this.getMaxY() + this.getMinY()) * 0.5;
    }
    
    public final double getCenterZ() {
        return (this.getMaxZ() + this.getMinZ()) * 0.5;
    }
    
    public abstract boolean isEmpty();
    
    public abstract boolean contains(final Point2D p0);
    
    public abstract boolean contains(final Point3D p0);
    
    public abstract boolean contains(final double p0, final double p1);
    
    public abstract boolean contains(final double p0, final double p1, final double p2);
    
    public abstract boolean contains(final Bounds p0);
    
    public abstract boolean contains(final double p0, final double p1, final double p2, final double p3);
    
    public abstract boolean contains(final double p0, final double p1, final double p2, final double p3, final double p4, final double p5);
    
    public abstract boolean intersects(final Bounds p0);
    
    public abstract boolean intersects(final double p0, final double p1, final double p2, final double p3);
    
    public abstract boolean intersects(final double p0, final double p1, final double p2, final double p3, final double p4, final double p5);
    
    protected Bounds(final double minX, final double minY, final double minZ, final double width, final double height, final double depth) {
        this.minX = minX;
        this.minY = minY;
        this.minZ = minZ;
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.maxX = minX + width;
        this.maxY = minY + height;
        this.maxZ = minZ + depth;
    }
}
