// 
// Decompiled by Procyon v0.5.36
// 

package javafx.geometry;

import javafx.beans.NamedArg;

public class Dimension2D
{
    private double width;
    private double height;
    private int hash;
    
    public Dimension2D(@NamedArg("width") final double width, @NamedArg("height") final double height) {
        this.hash = 0;
        this.width = width;
        this.height = height;
    }
    
    public final double getWidth() {
        return this.width;
    }
    
    public final double getHeight() {
        return this.height;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof Dimension2D) {
            final Dimension2D dimension2D = (Dimension2D)o;
            return this.getWidth() == dimension2D.getWidth() && this.getHeight() == dimension2D.getHeight();
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            final long n = 31L * (31L * 7L + Double.doubleToLongBits(this.getWidth())) + Double.doubleToLongBits(this.getHeight());
            this.hash = (int)(n ^ n >> 32);
        }
        return this.hash;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(DD)Ljava/lang/String;, this.getWidth(), this.getHeight());
    }
}
