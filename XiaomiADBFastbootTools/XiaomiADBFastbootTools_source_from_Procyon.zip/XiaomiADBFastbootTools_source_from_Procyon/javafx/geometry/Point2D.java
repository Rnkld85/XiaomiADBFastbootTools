// 
// Decompiled by Procyon v0.5.36
// 

package javafx.geometry;

import javafx.beans.NamedArg;

public class Point2D
{
    public static final Point2D ZERO;
    private double x;
    private double y;
    private int hash;
    
    public final double getX() {
        return this.x;
    }
    
    public final double getY() {
        return this.y;
    }
    
    public Point2D(@NamedArg("x") final double x, @NamedArg("y") final double y) {
        this.hash = 0;
        this.x = x;
        this.y = y;
    }
    
    public double distance(final double n, final double n2) {
        final double n3 = this.getX() - n;
        final double n4 = this.getY() - n2;
        return Math.sqrt(n3 * n3 + n4 * n4);
    }
    
    public double distance(final Point2D point2D) {
        return this.distance(point2D.getX(), point2D.getY());
    }
    
    public Point2D add(final double n, final double n2) {
        return new Point2D(this.getX() + n, this.getY() + n2);
    }
    
    public Point2D add(final Point2D point2D) {
        return this.add(point2D.getX(), point2D.getY());
    }
    
    public Point2D subtract(final double n, final double n2) {
        return new Point2D(this.getX() - n, this.getY() - n2);
    }
    
    public Point2D multiply(final double n) {
        return new Point2D(this.getX() * n, this.getY() * n);
    }
    
    public Point2D subtract(final Point2D point2D) {
        return this.subtract(point2D.getX(), point2D.getY());
    }
    
    public Point2D normalize() {
        final double magnitude = this.magnitude();
        if (magnitude == 0.0) {
            return new Point2D(0.0, 0.0);
        }
        return new Point2D(this.getX() / magnitude, this.getY() / magnitude);
    }
    
    public Point2D midpoint(final double n, final double n2) {
        return new Point2D(n + (this.getX() - n) / 2.0, n2 + (this.getY() - n2) / 2.0);
    }
    
    public Point2D midpoint(final Point2D point2D) {
        return this.midpoint(point2D.getX(), point2D.getY());
    }
    
    public double angle(final double n, final double n2) {
        final double x = this.getX();
        final double y = this.getY();
        final double a = (x * n + y * n2) / Math.sqrt((x * x + y * y) * (n * n + n2 * n2));
        if (a > 1.0) {
            return 0.0;
        }
        if (a < -1.0) {
            return 180.0;
        }
        return Math.toDegrees(Math.acos(a));
    }
    
    public double angle(final Point2D point2D) {
        return this.angle(point2D.getX(), point2D.getY());
    }
    
    public double angle(final Point2D point2D, final Point2D point2D2) {
        final double x = this.getX();
        final double y = this.getY();
        final double n = point2D.getX() - x;
        final double n2 = point2D.getY() - y;
        final double n3 = point2D2.getX() - x;
        final double n4 = point2D2.getY() - y;
        final double a = (n * n3 + n2 * n4) / Math.sqrt((n * n + n2 * n2) * (n3 * n3 + n4 * n4));
        if (a > 1.0) {
            return 0.0;
        }
        if (a < -1.0) {
            return 180.0;
        }
        return Math.toDegrees(Math.acos(a));
    }
    
    public double magnitude() {
        final double x = this.getX();
        final double y = this.getY();
        return Math.sqrt(x * x + y * y);
    }
    
    public double dotProduct(final double n, final double n2) {
        return this.getX() * n + this.getY() * n2;
    }
    
    public double dotProduct(final Point2D point2D) {
        return this.dotProduct(point2D.getX(), point2D.getY());
    }
    
    public Point3D crossProduct(final double n, final double n2) {
        return new Point3D(0.0, 0.0, this.getX() * n2 - this.getY() * n);
    }
    
    public Point3D crossProduct(final Point2D point2D) {
        return this.crossProduct(point2D.getX(), point2D.getY());
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof Point2D) {
            final Point2D point2D = (Point2D)o;
            return this.getX() == point2D.getX() && this.getY() == point2D.getY();
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            final long n = 31L * (31L * 7L + Double.doubleToLongBits(this.getX())) + Double.doubleToLongBits(this.getY());
            this.hash = (int)(n ^ n >> 32);
        }
        return this.hash;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(DD)Ljava/lang/String;, this.getX(), this.getY());
    }
    
    static {
        ZERO = new Point2D(0.0, 0.0);
    }
}
