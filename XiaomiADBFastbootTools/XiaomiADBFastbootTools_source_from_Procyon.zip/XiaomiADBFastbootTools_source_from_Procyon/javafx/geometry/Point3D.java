// 
// Decompiled by Procyon v0.5.36
// 

package javafx.geometry;

import javafx.beans.NamedArg;

public class Point3D
{
    public static final Point3D ZERO;
    private double x;
    private double y;
    private double z;
    private int hash;
    
    public final double getX() {
        return this.x;
    }
    
    public final double getY() {
        return this.y;
    }
    
    public final double getZ() {
        return this.z;
    }
    
    public Point3D(@NamedArg("x") final double x, @NamedArg("y") final double y, @NamedArg("z") final double z) {
        this.hash = 0;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public double distance(final double n, final double n2, final double n3) {
        final double n4 = this.getX() - n;
        final double n5 = this.getY() - n2;
        final double n6 = this.getZ() - n3;
        return Math.sqrt(n4 * n4 + n5 * n5 + n6 * n6);
    }
    
    public double distance(final Point3D point3D) {
        return this.distance(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Point3D add(final double n, final double n2, final double n3) {
        return new Point3D(this.getX() + n, this.getY() + n2, this.getZ() + n3);
    }
    
    public Point3D add(final Point3D point3D) {
        return this.add(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Point3D subtract(final double n, final double n2, final double n3) {
        return new Point3D(this.getX() - n, this.getY() - n2, this.getZ() - n3);
    }
    
    public Point3D subtract(final Point3D point3D) {
        return this.subtract(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Point3D multiply(final double n) {
        return new Point3D(this.getX() * n, this.getY() * n, this.getZ() * n);
    }
    
    public Point3D normalize() {
        final double magnitude = this.magnitude();
        if (magnitude == 0.0) {
            return new Point3D(0.0, 0.0, 0.0);
        }
        return new Point3D(this.getX() / magnitude, this.getY() / magnitude, this.getZ() / magnitude);
    }
    
    public Point3D midpoint(final double n, final double n2, final double n3) {
        return new Point3D(n + (this.getX() - n) / 2.0, n2 + (this.getY() - n2) / 2.0, n3 + (this.getZ() - n3) / 2.0);
    }
    
    public Point3D midpoint(final Point3D point3D) {
        return this.midpoint(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public double angle(final double n, final double n2, final double n3) {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        final double a = (x * n + y * n2 + z * n3) / Math.sqrt((x * x + y * y + z * z) * (n * n + n2 * n2 + n3 * n3));
        if (a > 1.0) {
            return 0.0;
        }
        if (a < -1.0) {
            return 180.0;
        }
        return Math.toDegrees(Math.acos(a));
    }
    
    public double angle(final Point3D point3D) {
        return this.angle(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public double angle(final Point3D point3D, final Point3D point3D2) {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        final double n = point3D.getX() - x;
        final double n2 = point3D.getY() - y;
        final double n3 = point3D.getZ() - z;
        final double n4 = point3D2.getX() - x;
        final double n5 = point3D2.getY() - y;
        final double n6 = point3D2.getZ() - z;
        final double a = (n * n4 + n2 * n5 + n3 * n6) / Math.sqrt((n * n + n2 * n2 + n3 * n3) * (n4 * n4 + n5 * n5 + n6 * n6));
        if (a > 1.0) {
            return 0.0;
        }
        if (a < -1.0) {
            return 180.0;
        }
        return Math.toDegrees(Math.acos(a));
    }
    
    public double magnitude() {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        return Math.sqrt(x * x + y * y + z * z);
    }
    
    public double dotProduct(final double n, final double n2, final double n3) {
        return this.getX() * n + this.getY() * n2 + this.getZ() * n3;
    }
    
    public double dotProduct(final Point3D point3D) {
        return this.dotProduct(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Point3D crossProduct(final double n, final double n2, final double n3) {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        return new Point3D(y * n3 - z * n2, z * n - x * n3, x * n2 - y * n);
    }
    
    public Point3D crossProduct(final Point3D point3D) {
        return this.crossProduct(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof Point3D) {
            final Point3D point3D = (Point3D)o;
            return this.getX() == point3D.getX() && this.getY() == point3D.getY() && this.getZ() == point3D.getZ();
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            final long n = 31L * (31L * (31L * 7L + Double.doubleToLongBits(this.getX())) + Double.doubleToLongBits(this.getY())) + Double.doubleToLongBits(this.getZ());
            this.hash = (int)(n ^ n >> 32);
        }
        return this.hash;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(DDD)Ljava/lang/String;, this.getX(), this.getY(), this.getZ());
    }
    
    static {
        ZERO = new Point3D(0.0, 0.0, 0.0);
    }
}
