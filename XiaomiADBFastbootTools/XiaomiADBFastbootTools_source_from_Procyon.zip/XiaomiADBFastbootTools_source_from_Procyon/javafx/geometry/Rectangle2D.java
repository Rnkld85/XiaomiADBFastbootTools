// 
// Decompiled by Procyon v0.5.36
// 

package javafx.geometry;

import javafx.beans.NamedArg;

public class Rectangle2D
{
    public static final Rectangle2D EMPTY;
    private double minX;
    private double minY;
    private double width;
    private double height;
    private double maxX;
    private double maxY;
    private int hash;
    
    public double getMinX() {
        return this.minX;
    }
    
    public double getMinY() {
        return this.minY;
    }
    
    public double getWidth() {
        return this.width;
    }
    
    public double getHeight() {
        return this.height;
    }
    
    public double getMaxX() {
        return this.maxX;
    }
    
    public double getMaxY() {
        return this.maxY;
    }
    
    public Rectangle2D(@NamedArg("minX") final double minX, @NamedArg("minY") final double minY, @NamedArg("width") final double width, @NamedArg("height") final double height) {
        this.hash = 0;
        if (width < 0.0 || height < 0.0) {
            throw new IllegalArgumentException("Both width and height must be >= 0");
        }
        this.minX = minX;
        this.minY = minY;
        this.width = width;
        this.height = height;
        this.maxX = minX + width;
        this.maxY = minY + height;
    }
    
    public boolean contains(final Point2D point2D) {
        return point2D != null && this.contains(point2D.getX(), point2D.getY());
    }
    
    public boolean contains(final double n, final double n2) {
        return n >= this.minX && n <= this.maxX && n2 >= this.minY && n2 <= this.maxY;
    }
    
    public boolean contains(final Rectangle2D rectangle2D) {
        return rectangle2D != null && rectangle2D.minX >= this.minX && rectangle2D.minY >= this.minY && rectangle2D.maxX <= this.maxX && rectangle2D.maxY <= this.maxY;
    }
    
    public boolean contains(final double n, final double n2, final double n3, final double n4) {
        return n >= this.minX && n2 >= this.minY && n3 <= this.maxX - n && n4 <= this.maxY - n2;
    }
    
    public boolean intersects(final Rectangle2D rectangle2D) {
        return rectangle2D != null && rectangle2D.maxX > this.minX && rectangle2D.maxY > this.minY && rectangle2D.minX < this.maxX && rectangle2D.minY < this.maxY;
    }
    
    public boolean intersects(final double n, final double n2, final double n3, final double n4) {
        return n < this.maxX && n2 < this.maxY && n + n3 > this.minX && n2 + n4 > this.minY;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof Rectangle2D) {
            final Rectangle2D rectangle2D = (Rectangle2D)o;
            return this.minX == rectangle2D.minX && this.minY == rectangle2D.minY && this.width == rectangle2D.width && this.height == rectangle2D.height;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            final long n = 31L * (31L * (31L * (31L * 7L + Double.doubleToLongBits(this.minX)) + Double.doubleToLongBits(this.minY)) + Double.doubleToLongBits(this.width)) + Double.doubleToLongBits(this.height);
            this.hash = (int)(n ^ n >> 32);
        }
        return this.hash;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(DDDDDD)Ljava/lang/String;, this.minX, this.minY, this.maxX, this.maxY, this.width, this.height);
    }
    
    static {
        EMPTY = new Rectangle2D(0.0, 0.0, 0.0, 0.0);
    }
}
