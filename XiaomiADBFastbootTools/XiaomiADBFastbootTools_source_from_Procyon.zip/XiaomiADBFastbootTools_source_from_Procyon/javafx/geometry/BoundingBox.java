// 
// Decompiled by Procyon v0.5.36
// 

package javafx.geometry;

import javafx.beans.NamedArg;

public class BoundingBox extends Bounds
{
    private int hash;
    
    public BoundingBox(@NamedArg("minX") final double n, @NamedArg("minY") final double n2, @NamedArg("minZ") final double n3, @NamedArg("width") final double n4, @NamedArg("height") final double n5, @NamedArg("depth") final double n6) {
        super(n, n2, n3, n4, n5, n6);
        this.hash = 0;
    }
    
    public BoundingBox(@NamedArg("minX") final double n, @NamedArg("minY") final double n2, @NamedArg("width") final double n3, @NamedArg("height") final double n4) {
        super(n, n2, 0.0, n3, n4, 0.0);
        this.hash = 0;
    }
    
    @Override
    public boolean isEmpty() {
        return this.getMaxX() < this.getMinX() || this.getMaxY() < this.getMinY() || this.getMaxZ() < this.getMinZ();
    }
    
    @Override
    public boolean contains(final Point2D point2D) {
        return point2D != null && this.contains(point2D.getX(), point2D.getY(), 0.0);
    }
    
    @Override
    public boolean contains(final Point3D point3D) {
        return point3D != null && this.contains(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    @Override
    public boolean contains(final double n, final double n2) {
        return this.contains(n, n2, 0.0);
    }
    
    @Override
    public boolean contains(final double n, final double n2, final double n3) {
        return !this.isEmpty() && n >= this.getMinX() && n <= this.getMaxX() && n2 >= this.getMinY() && n2 <= this.getMaxY() && n3 >= this.getMinZ() && n3 <= this.getMaxZ();
    }
    
    @Override
    public boolean contains(final Bounds bounds) {
        return bounds != null && !bounds.isEmpty() && this.contains(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ(), bounds.getWidth(), bounds.getHeight(), bounds.getDepth());
    }
    
    @Override
    public boolean contains(final double n, final double n2, final double n3, final double n4) {
        return this.contains(n, n2) && this.contains(n + n3, n2 + n4);
    }
    
    @Override
    public boolean contains(final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        return this.contains(n, n2, n3) && this.contains(n + n4, n2 + n5, n3 + n6);
    }
    
    @Override
    public boolean intersects(final Bounds bounds) {
        return bounds != null && !bounds.isEmpty() && this.intersects(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ(), bounds.getWidth(), bounds.getHeight(), bounds.getDepth());
    }
    
    @Override
    public boolean intersects(final double n, final double n2, final double n3, final double n4) {
        return this.intersects(n, n2, 0.0, n3, n4, 0.0);
    }
    
    @Override
    public boolean intersects(final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        return !this.isEmpty() && n4 >= 0.0 && n5 >= 0.0 && n6 >= 0.0 && n + n4 >= this.getMinX() && n2 + n5 >= this.getMinY() && n3 + n6 >= this.getMinZ() && n <= this.getMaxX() && n2 <= this.getMaxY() && n3 <= this.getMaxZ();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof BoundingBox) {
            final BoundingBox boundingBox = (BoundingBox)o;
            return this.getMinX() == boundingBox.getMinX() && this.getMinY() == boundingBox.getMinY() && this.getMinZ() == boundingBox.getMinZ() && this.getWidth() == boundingBox.getWidth() && this.getHeight() == boundingBox.getHeight() && this.getDepth() == boundingBox.getDepth();
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            final long n = 31L * (31L * (31L * (31L * (31L * (31L * 7L + Double.doubleToLongBits(this.getMinX())) + Double.doubleToLongBits(this.getMinY())) + Double.doubleToLongBits(this.getMinZ())) + Double.doubleToLongBits(this.getWidth())) + Double.doubleToLongBits(this.getHeight())) + Double.doubleToLongBits(this.getDepth());
            this.hash = (int)(n ^ n >> 32);
        }
        return this.hash;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(DDDDDDDDD)Ljava/lang/String;, this.getMinX(), this.getMinY(), this.getMinZ(), this.getWidth(), this.getHeight(), this.getDepth(), this.getMaxX(), this.getMaxY(), this.getMaxZ());
    }
}
