// 
// Decompiled by Procyon v0.5.36
// 

package javafx.geometry;

public enum Side
{
    TOP, 
    BOTTOM, 
    LEFT, 
    RIGHT;
    
    public boolean isVertical() {
        return this == Side.LEFT || this == Side.RIGHT;
    }
    
    public boolean isHorizontal() {
        return this == Side.TOP || this == Side.BOTTOM;
    }
}
