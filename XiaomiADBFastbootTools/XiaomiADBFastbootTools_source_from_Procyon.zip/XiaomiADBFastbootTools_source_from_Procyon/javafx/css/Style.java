// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

public final class Style
{
    private final Selector selector;
    private final Declaration declaration;
    
    public Selector getSelector() {
        return this.selector;
    }
    
    public Declaration getDeclaration() {
        return this.declaration;
    }
    
    public Style(final Selector selector, final Declaration declaration) {
        this.selector = selector;
        this.declaration = declaration;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        final Style style = (Style)o;
        return (this.selector == style.selector || (this.selector != null && this.selector.equals(style.selector))) && (this.declaration == style.declaration || (this.declaration != null && this.declaration.equals(style.declaration)));
    }
    
    @Override
    public int hashCode() {
        return 83 * (83 * 3 + ((this.selector != null) ? this.selector.hashCode() : 0)) + ((this.declaration != null) ? this.declaration.hashCode() : 0);
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.selector) + " { " + String.valueOf(this.declaration) + " } ";
    }
}
