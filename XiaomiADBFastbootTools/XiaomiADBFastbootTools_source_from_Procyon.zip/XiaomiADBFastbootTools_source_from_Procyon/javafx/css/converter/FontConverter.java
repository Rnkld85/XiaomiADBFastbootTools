// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import java.util.Locale;
import java.util.Iterator;
import javafx.css.Styleable;
import javafx.css.CssMetaData;
import java.util.Map;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.css.Size;
import com.sun.javafx.util.Utils;
import javafx.scene.text.Font;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class FontConverter extends StyleConverter<ParsedValue[], Font>
{
    public static StyleConverter<ParsedValue[], Font> getInstance() {
        return Holder.INSTANCE;
    }
    
    private FontConverter() {
    }
    
    @Override
    public Font convert(final ParsedValue<ParsedValue[], Font> parsedValue, final Font font) {
        final ParsedValue[] array = parsedValue.getValue();
        final Font font2 = (font != null) ? font : Font.getDefault();
        final String s = (array[0] != null) ? Utils.stripQuotes((String)array[0].convert(font2)) : font2.getFamily();
        double n = font2.getSize();
        if (array[1] != null) {
            n = ((ParsedValue<ParsedValue<ParsedValue<ParsedValue, Size>, Size>, Size>)array[1].getValue()).convert(font2).pixels(font2.getSize(), font2);
        }
        return Font.font(s, (array[2] != null) ? ((FontWeight)array[2].convert(font2)) : FontWeight.NORMAL, (array[3] != null) ? ((FontPosture)array[3].convert(font2)) : FontPosture.REGULAR, n);
    }
    
    @Override
    public Font convert(final Map<CssMetaData<? extends Styleable, ?>, Object> map) {
        final Font default1 = Font.getDefault();
        double n = default1.getSize();
        String s = default1.getFamily();
        FontWeight normal = FontWeight.NORMAL;
        FontPosture regular = FontPosture.REGULAR;
        for (final Map.Entry<CssMetaData<? extends Styleable, ?>, Object> entry : map.entrySet()) {
            final FontPosture value = entry.getValue();
            if (value == null) {
                continue;
            }
            final String property = entry.getKey().getProperty();
            if (property.endsWith("font-size")) {
                n = ((Number)value).doubleValue();
            }
            else if (property.endsWith("font-family")) {
                s = Utils.stripQuotes((String)value);
            }
            else if (property.endsWith("font-weight")) {
                normal = (FontWeight)value;
            }
            else {
                if (!property.endsWith("font-style")) {
                    continue;
                }
                regular = value;
            }
        }
        return Font.font(s, normal, regular, n);
    }
    
    @Override
    public String toString() {
        return "FontConverter";
    }
    
    private static class Holder
    {
        static final FontConverter INSTANCE;
        
        static {
            INSTANCE = new FontConverter(null);
        }
    }
    
    public static final class FontStyleConverter extends StyleConverter<String, FontPosture>
    {
        public static FontStyleConverter getInstance() {
            return Holder.INSTANCE;
        }
        
        private FontStyleConverter() {
        }
        
        @Override
        public FontPosture convert(final ParsedValue<String, FontPosture> parsedValue, final Font font) {
            final String value = parsedValue.getValue();
            FontPosture fontPosture = null;
            if (value instanceof String) {
                try {
                    fontPosture = Enum.valueOf(FontPosture.class, value.toUpperCase(Locale.ROOT));
                }
                catch (IllegalArgumentException ex) {
                    fontPosture = FontPosture.REGULAR;
                }
                catch (NullPointerException ex2) {
                    fontPosture = FontPosture.REGULAR;
                }
            }
            else if (value instanceof FontPosture) {
                fontPosture = (FontPosture)value;
            }
            return fontPosture;
        }
        
        @Override
        public String toString() {
            return "FontConverter.StyleConverter";
        }
        
        private static class Holder
        {
            static final FontStyleConverter INSTANCE;
            
            static {
                INSTANCE = new FontStyleConverter();
            }
        }
    }
    
    public static final class FontWeightConverter extends StyleConverter<String, FontWeight>
    {
        public static FontWeightConverter getInstance() {
            return Holder.INSTANCE;
        }
        
        private FontWeightConverter() {
        }
        
        @Override
        public FontWeight convert(final ParsedValue<String, FontWeight> parsedValue, final Font font) {
            final String value = parsedValue.getValue();
            FontWeight fontWeight = null;
            if (value instanceof String) {
                try {
                    fontWeight = Enum.valueOf(FontWeight.class, value.toUpperCase(Locale.ROOT));
                }
                catch (IllegalArgumentException ex) {
                    fontWeight = FontWeight.NORMAL;
                }
                catch (NullPointerException ex2) {
                    fontWeight = FontWeight.NORMAL;
                }
            }
            else if (value instanceof FontWeight) {
                fontWeight = (FontWeight)value;
            }
            return fontWeight;
        }
        
        @Override
        public String toString() {
            return "FontConverter.WeightConverter";
        }
        
        private static class Holder
        {
            static final FontWeightConverter INSTANCE;
            
            static {
                INSTANCE = new FontWeightConverter();
            }
        }
    }
    
    public static final class FontSizeConverter extends StyleConverter<ParsedValue<?, Size>, Number>
    {
        public static FontSizeConverter getInstance() {
            return Holder.INSTANCE;
        }
        
        private FontSizeConverter() {
        }
        
        @Override
        public Number convert(final ParsedValue<ParsedValue<?, Size>, Number> parsedValue, final Font font) {
            return parsedValue.getValue().convert(font).pixels(font.getSize(), font);
        }
        
        @Override
        public String toString() {
            return "FontConverter.FontSizeConverter";
        }
        
        private static class Holder
        {
            static final FontSizeConverter INSTANCE;
            
            static {
                INSTANCE = new FontSizeConverter();
            }
        }
    }
}
