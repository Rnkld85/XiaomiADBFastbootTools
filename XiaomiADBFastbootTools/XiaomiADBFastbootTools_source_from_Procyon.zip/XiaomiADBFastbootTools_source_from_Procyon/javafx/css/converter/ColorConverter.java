// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.text.Font;
import javafx.css.ParsedValue;
import javafx.scene.paint.Color;
import javafx.css.StyleConverter;

public final class ColorConverter extends StyleConverter<String, Color>
{
    public static StyleConverter<String, Color> getInstance() {
        return Holder.COLOR_INSTANCE;
    }
    
    private ColorConverter() {
    }
    
    @Override
    public Color convert(final ParsedValue<String, Color> parsedValue, final Font font) {
        final String value = parsedValue.getValue();
        if (value == null) {
            return null;
        }
        if (value instanceof Color) {
            return (Color)value;
        }
        if (value instanceof String) {
            final String anObject = value;
            if (anObject.isEmpty() || "null".equals(anObject)) {
                return null;
            }
            try {
                return Color.web(value);
            }
            catch (IllegalArgumentException ex) {}
        }
        System.err.println(invokedynamic(makeConcatWithConstants:(Ljavafx/css/ParsedValue;)Ljava/lang/String;, parsedValue));
        return Color.BLACK;
    }
    
    @Override
    public String toString() {
        return "ColorConverter";
    }
    
    private static class Holder
    {
        static final ColorConverter COLOR_INSTANCE;
        
        static {
            COLOR_INSTANCE = new ColorConverter(null);
        }
    }
}
