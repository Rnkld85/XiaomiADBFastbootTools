// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.text.Font;
import javafx.util.Duration;
import javafx.css.Size;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class DurationConverter extends StyleConverter<ParsedValue<?, Size>, Duration>
{
    public static StyleConverter<ParsedValue<?, Size>, Duration> getInstance() {
        return Holder.INSTANCE;
    }
    
    private DurationConverter() {
    }
    
    @Override
    public Duration convert(final ParsedValue<ParsedValue<?, Size>, Duration> parsedValue, final Font font) {
        final Size size = parsedValue.getValue().convert(font);
        final double value = size.getValue();
        Duration duration = null;
        if (value < Double.POSITIVE_INFINITY) {
            switch (size.getUnits()) {
                case S: {
                    duration = Duration.seconds(value);
                    break;
                }
                case MS: {
                    duration = Duration.millis(value);
                    break;
                }
                default: {
                    duration = Duration.UNKNOWN;
                    break;
                }
            }
        }
        else {
            duration = Duration.INDEFINITE;
        }
        return duration;
    }
    
    @Override
    public String toString() {
        return "DurationConverter";
    }
    
    private static class Holder
    {
        static final DurationConverter INSTANCE;
        
        static {
            INSTANCE = new DurationConverter(null);
        }
    }
}
