// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.paint.Color;
import javafx.css.Size;
import javafx.scene.text.Font;
import javafx.scene.paint.Stop;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class StopConverter extends StyleConverter<ParsedValue[], Stop>
{
    public static StopConverter getInstance() {
        return Holder.INSTANCE;
    }
    
    private StopConverter() {
    }
    
    @Override
    public Stop convert(final ParsedValue<ParsedValue[], Stop> parsedValue, final Font font) {
        final ParsedValue[] array = parsedValue.getValue();
        return new Stop(((Size)array[0].convert(font)).pixels(font), (Color)array[1].convert(font));
    }
    
    @Override
    public String toString() {
        return "StopConverter";
    }
    
    private static class Holder
    {
        static final StopConverter INSTANCE;
        
        static {
            INSTANCE = new StopConverter(null);
        }
    }
}
