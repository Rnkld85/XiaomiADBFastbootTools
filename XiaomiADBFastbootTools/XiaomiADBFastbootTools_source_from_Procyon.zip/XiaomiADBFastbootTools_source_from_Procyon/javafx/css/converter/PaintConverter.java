// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.paint.RadialGradient;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import com.sun.javafx.css.StyleManager;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.paint.CycleMethod;
import javafx.css.SizeUnits;
import javafx.css.Size;
import javafx.scene.text.Font;
import javafx.scene.paint.Paint;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class PaintConverter extends StyleConverter<ParsedValue<?, Paint>, Paint>
{
    public static StyleConverter<ParsedValue<?, Paint>, Paint> getInstance() {
        return Holder.INSTANCE;
    }
    
    private PaintConverter() {
    }
    
    @Override
    public Paint convert(final ParsedValue<ParsedValue<?, Paint>, Paint> parsedValue, final Font font) {
        final ParsedValue<?, Paint> value = parsedValue.getValue();
        if (value instanceof Paint) {
            return (Paint)value;
        }
        return parsedValue.getValue().convert(font);
    }
    
    @Override
    public String toString() {
        return "PaintConverter";
    }
    
    private static class Holder
    {
        static final PaintConverter INSTANCE;
        static final SequenceConverter SEQUENCE_INSTANCE;
        static final LinearGradientConverter LINEAR_GRADIENT_INSTANCE;
        static final ImagePatternConverter IMAGE_PATTERN_INSTANCE;
        static final RepeatingImagePatternConverter REPEATING_IMAGE_PATTERN_INSTANCE;
        static final RadialGradientConverter RADIAL_GRADIENT_INSTANCE;
        
        static {
            INSTANCE = new PaintConverter(null);
            SEQUENCE_INSTANCE = new SequenceConverter();
            LINEAR_GRADIENT_INSTANCE = new LinearGradientConverter();
            IMAGE_PATTERN_INSTANCE = new ImagePatternConverter();
            REPEATING_IMAGE_PATTERN_INSTANCE = new RepeatingImagePatternConverter();
            RADIAL_GRADIENT_INSTANCE = new RadialGradientConverter();
        }
    }
    
    public static final class SequenceConverter extends StyleConverter<ParsedValue<?, Paint>[], Paint[]>
    {
        public static SequenceConverter getInstance() {
            return Holder.SEQUENCE_INSTANCE;
        }
        
        private SequenceConverter() {
        }
        
        @Override
        public Paint[] convert(final ParsedValue<ParsedValue<?, Paint>[], Paint[]> parsedValue, final Font font) {
            final ParsedValue<?, Paint>[] array = parsedValue.getValue();
            final Paint[] array2 = new Paint[array.length];
            for (int i = 0; i < array.length; ++i) {
                array2[i] = array[i].convert(font);
            }
            return array2;
        }
        
        @Override
        public String toString() {
            return "Paint.SequenceConverter";
        }
    }
    
    public static final class LinearGradientConverter extends StyleConverter<ParsedValue[], Paint>
    {
        public static LinearGradientConverter getInstance() {
            return Holder.LINEAR_GRADIENT_INSTANCE;
        }
        
        private LinearGradientConverter() {
        }
        
        @Override
        public Paint convert(final ParsedValue<ParsedValue[], Paint> parsedValue, final Font font) {
            final Paint paint = super.getCachedValue(parsedValue);
            if (paint != null) {
                return paint;
            }
            final ParsedValue[] array = parsedValue.getValue();
            int n = 0;
            final Size size = (Size)array[n++].convert(font);
            final Size size2 = (Size)array[n++].convert(font);
            final Size size3 = (Size)array[n++].convert(font);
            final Size size4 = (Size)array[n++].convert(font);
            final boolean b = size.getUnits() == SizeUnits.PERCENT && size.getUnits() == size2.getUnits() && size.getUnits() == size3.getUnits() && size.getUnits() == size4.getUnits();
            final CycleMethod cycleMethod = (CycleMethod)array[n++].convert(font);
            final Stop[] array2 = new Stop[array.length - n];
            for (int i = n; i < array.length; ++i) {
                array2[i - n] = (Stop)array[i].convert(font);
            }
            final LinearGradient linearGradient = new LinearGradient(size.pixels(font), size2.pixels(font), size3.pixels(font), size4.pixels(font), b, cycleMethod, array2);
            super.cacheValue(parsedValue, linearGradient);
            return linearGradient;
        }
        
        @Override
        public String toString() {
            return "LinearGradientConverter";
        }
    }
    
    public static final class ImagePatternConverter extends StyleConverter<ParsedValue[], Paint>
    {
        public static ImagePatternConverter getInstance() {
            return Holder.IMAGE_PATTERN_INSTANCE;
        }
        
        private ImagePatternConverter() {
        }
        
        @Override
        public Paint convert(final ParsedValue<ParsedValue[], Paint> parsedValue, final Font font) {
            final Paint paint = super.getCachedValue(parsedValue);
            if (paint != null) {
                return paint;
            }
            final ParsedValue[] array = parsedValue.getValue();
            final String s = (String)array[0].convert(font);
            if (array.length == 1) {
                return new ImagePattern(StyleManager.getInstance().getCachedImage(s));
            }
            final ImagePattern imagePattern = new ImagePattern(new Image(s), ((Size)array[1].convert(font)).getValue(), ((Size)array[2].convert(font)).getValue(), ((Size)array[3].convert(font)).getValue(), ((Size)array[4].convert(font)).getValue(), array.length < 6 || (boolean)array[5].getValue());
            super.cacheValue(parsedValue, imagePattern);
            return imagePattern;
        }
        
        @Override
        public String toString() {
            return "ImagePatternConverter";
        }
    }
    
    public static final class RepeatingImagePatternConverter extends StyleConverter<ParsedValue[], Paint>
    {
        public static RepeatingImagePatternConverter getInstance() {
            return Holder.REPEATING_IMAGE_PATTERN_INSTANCE;
        }
        
        private RepeatingImagePatternConverter() {
        }
        
        @Override
        public Paint convert(final ParsedValue<ParsedValue[], Paint> parsedValue, final Font font) {
            final Paint paint = super.getCachedValue(parsedValue);
            if (paint != null) {
                return paint;
            }
            final String s = (String)parsedValue.getValue()[0].convert(font);
            if (s == null) {
                return null;
            }
            final Image image = new Image(s);
            final ImagePattern imagePattern = new ImagePattern(image, 0.0, 0.0, image.getWidth(), image.getHeight(), false);
            super.cacheValue(parsedValue, imagePattern);
            return imagePattern;
        }
        
        @Override
        public String toString() {
            return "RepeatingImagePatternConverter";
        }
    }
    
    public static final class RadialGradientConverter extends StyleConverter<ParsedValue[], Paint>
    {
        public static RadialGradientConverter getInstance() {
            return Holder.RADIAL_GRADIENT_INSTANCE;
        }
        
        private RadialGradientConverter() {
        }
        
        @Override
        public Paint convert(final ParsedValue<ParsedValue[], Paint> parsedValue, final Font font) {
            final Paint paint = super.getCachedValue(parsedValue);
            if (paint != null) {
                return paint;
            }
            final ParsedValue[] array = parsedValue.getValue();
            int n = 0;
            final Size size = (array[n++] != null) ? ((Size)array[n - 1].convert(font)) : null;
            final Size size2 = (array[n++] != null) ? ((Size)array[n - 1].convert(font)) : null;
            final Size size3 = (array[n++] != null) ? ((Size)array[n - 1].convert(font)) : null;
            final Size size4 = (array[n++] != null) ? ((Size)array[n - 1].convert(font)) : null;
            final Size size5 = (Size)array[n++].convert(font);
            final boolean equals = size5.getUnits().equals(SizeUnits.PERCENT);
            if ((size3 == null || equals == size3.getUnits().equals(SizeUnits.PERCENT)) && size4 != null && equals != size4.getUnits().equals(SizeUnits.PERCENT)) {
                throw new IllegalArgumentException("units do not agree");
            }
            final CycleMethod cycleMethod = (CycleMethod)array[n++].convert(font);
            final Stop[] array2 = new Stop[array.length - n];
            for (int i = n; i < array.length; ++i) {
                array2[i - n] = (Stop)array[i].convert(font);
            }
            double pixels = 0.0;
            if (size != null) {
                pixels = size.pixels(font);
                if (size.getUnits().equals(SizeUnits.PERCENT)) {
                    pixels = pixels * 360.0 % 360.0;
                }
            }
            final RadialGradient radialGradient = new RadialGradient(pixels, (size2 != null) ? size2.pixels() : 0.0, (size3 != null) ? size3.pixels() : 0.0, (size4 != null) ? size4.pixels() : 0.0, (size5 != null) ? size5.pixels() : 1.0, equals, cycleMethod, array2);
            super.cacheValue(parsedValue, radialGradient);
            return radialGradient;
        }
        
        @Override
        public String toString() {
            return "RadialGradientConverter";
        }
    }
}
