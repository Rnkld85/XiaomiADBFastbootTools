// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.effect.InnerShadow;
import javafx.scene.effect.DropShadow;
import javafx.css.Size;
import javafx.scene.paint.Color;
import javafx.scene.effect.BlurType;
import javafx.scene.text.Font;
import java.util.Map;
import javafx.scene.effect.Effect;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public class EffectConverter extends StyleConverter<ParsedValue[], Effect>
{
    private static Map<ParsedValue<ParsedValue[], Effect>, Effect> cache;
    
    public static StyleConverter<ParsedValue[], Effect> getInstance() {
        return Holder.EFFECT_CONVERTER;
    }
    
    @Override
    public Effect convert(final ParsedValue<ParsedValue[], Effect> parsedValue, final Font font) {
        throw new IllegalArgumentException("Parsed value is not an Effect");
    }
    
    protected EffectConverter() {
    }
    
    @Override
    public String toString() {
        return "EffectConverter";
    }
    
    public static void clearCache() {
        if (EffectConverter.cache != null) {
            EffectConverter.cache.clear();
        }
    }
    
    private static class Holder
    {
        static final EffectConverter EFFECT_CONVERTER;
        static final DropShadowConverter DROP_SHADOW_INSTANCE;
        static final InnerShadowConverter INNER_SHADOW_INSTANCE;
        
        static {
            EFFECT_CONVERTER = new EffectConverter();
            DROP_SHADOW_INSTANCE = new DropShadowConverter();
            INNER_SHADOW_INSTANCE = new InnerShadowConverter();
        }
    }
    
    public static final class DropShadowConverter extends EffectConverter
    {
        public static DropShadowConverter getInstance() {
            return Holder.DROP_SHADOW_INSTANCE;
        }
        
        private DropShadowConverter() {
        }
        
        @Override
        public Effect convert(final ParsedValue<ParsedValue[], Effect> parsedValue, final Font font) {
            final Effect effect = super.getCachedValue(parsedValue);
            if (effect != null) {
                return effect;
            }
            final ParsedValue[] array = parsedValue.getValue();
            final BlurType blurType = (BlurType)array[0].convert(font);
            final Color color = (Color)array[1].convert(font);
            final Double value = ((Size)array[2].convert(font)).pixels(font);
            final Double value2 = ((Size)array[3].convert(font)).pixels(font);
            final Double value3 = ((Size)array[4].convert(font)).pixels(font);
            final Double value4 = ((Size)array[5].convert(font)).pixels(font);
            final DropShadow dropShadow = new DropShadow();
            if (blurType != null) {
                dropShadow.setBlurType(blurType);
            }
            if (color != null) {
                dropShadow.setColor(color);
            }
            if (value2 != null) {
                dropShadow.setSpread(value2);
            }
            if (value != null) {
                dropShadow.setRadius(value);
            }
            if (value3 != null) {
                dropShadow.setOffsetX(value3);
            }
            if (value4 != null) {
                dropShadow.setOffsetY(value4);
            }
            super.cacheValue(parsedValue, dropShadow);
            return dropShadow;
        }
        
        @Override
        public String toString() {
            return "DropShadowConverter";
        }
    }
    
    public static final class InnerShadowConverter extends EffectConverter
    {
        public static InnerShadowConverter getInstance() {
            return Holder.INNER_SHADOW_INSTANCE;
        }
        
        private InnerShadowConverter() {
        }
        
        @Override
        public Effect convert(final ParsedValue<ParsedValue[], Effect> parsedValue, final Font font) {
            final Effect effect = super.getCachedValue(parsedValue);
            if (effect != null) {
                return effect;
            }
            final ParsedValue[] array = parsedValue.getValue();
            final BlurType blurType = (BlurType)array[0].convert(font);
            final Color color = (Color)array[1].convert(font);
            final Double value = ((Size)array[2].convert(font)).pixels(font);
            final Double value2 = ((Size)array[3].convert(font)).pixels(font);
            final Double value3 = ((Size)array[4].convert(font)).pixels(font);
            final Double value4 = ((Size)array[5].convert(font)).pixels(font);
            final InnerShadow innerShadow = new InnerShadow();
            if (blurType != null) {
                innerShadow.setBlurType(blurType);
            }
            if (color != null) {
                innerShadow.setColor(color);
            }
            if (value != null) {
                innerShadow.setRadius(value);
            }
            if (value2 != null) {
                innerShadow.setChoke(value2);
            }
            if (value3 != null) {
                innerShadow.setOffsetX(value3);
            }
            if (value4 != null) {
                innerShadow.setOffsetY(value4);
            }
            super.cacheValue(parsedValue, innerShadow);
            return innerShadow;
        }
        
        @Override
        public String toString() {
            return "InnerShadowConverter";
        }
    }
}
