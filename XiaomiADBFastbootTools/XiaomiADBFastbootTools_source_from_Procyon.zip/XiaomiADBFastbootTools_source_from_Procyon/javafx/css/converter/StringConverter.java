// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import com.sun.javafx.util.Utils;
import javafx.scene.text.Font;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class StringConverter extends StyleConverter<String, String>
{
    public static StyleConverter<String, String> getInstance() {
        return Holder.INSTANCE;
    }
    
    private StringConverter() {
    }
    
    @Override
    public String convert(final ParsedValue<String, String> parsedValue, final Font font) {
        final String s = parsedValue.getValue();
        if (s == null) {
            return null;
        }
        return Utils.convertUnicode(s);
    }
    
    @Override
    public String toString() {
        return "StringConverter";
    }
    
    private static class Holder
    {
        static final StringConverter INSTANCE;
        static final SequenceConverter SEQUENCE_INSTANCE;
        
        static {
            INSTANCE = new StringConverter(null);
            SEQUENCE_INSTANCE = new SequenceConverter();
        }
    }
    
    public static final class SequenceConverter extends StyleConverter<ParsedValue<String, String>[], String[]>
    {
        public static SequenceConverter getInstance() {
            return Holder.SEQUENCE_INSTANCE;
        }
        
        private SequenceConverter() {
        }
        
        @Override
        public String[] convert(final ParsedValue<ParsedValue<String, String>[], String[]> parsedValue, final Font font) {
            final ParsedValue<String, String>[] array = parsedValue.getValue();
            final String[] array2 = new String[array.length];
            for (int i = 0; i < array.length; ++i) {
                array2[i] = StringConverter.getInstance().convert(array[i], font);
            }
            return array2;
        }
        
        @Override
        public String toString() {
            return "String.SequenceConverter";
        }
    }
}
