// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.shape.SVGPath;
import javafx.scene.text.Font;
import javafx.css.ParsedValue;
import java.util.Map;
import javafx.scene.shape.Shape;
import javafx.css.StyleConverter;

public class ShapeConverter extends StyleConverter<String, Shape>
{
    private static final ShapeConverter INSTANCE;
    private static Map<ParsedValue<String, Shape>, Shape> cache;
    
    public static StyleConverter<String, Shape> getInstance() {
        return ShapeConverter.INSTANCE;
    }
    
    @Override
    public Shape convert(final ParsedValue<String, Shape> parsedValue, final Font font) {
        final Shape shape = super.getCachedValue(parsedValue);
        if (shape != null) {
            return shape;
        }
        final String content = parsedValue.getValue();
        if (content == null || content.isEmpty()) {
            return null;
        }
        final SVGPath svgPath = new SVGPath();
        svgPath.setContent(content);
        super.cacheValue(parsedValue, svgPath);
        return svgPath;
    }
    
    public static void clearCache() {
        if (ShapeConverter.cache != null) {
            ShapeConverter.cache.clear();
        }
    }
    
    static {
        INSTANCE = new ShapeConverter();
    }
}
