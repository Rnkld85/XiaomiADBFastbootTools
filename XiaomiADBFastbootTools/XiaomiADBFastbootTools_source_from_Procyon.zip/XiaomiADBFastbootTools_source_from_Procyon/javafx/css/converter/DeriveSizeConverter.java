// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.css.SizeUnits;
import javafx.scene.text.Font;
import javafx.css.Size;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class DeriveSizeConverter extends StyleConverter<ParsedValue<Size, Size>[], Size>
{
    public static DeriveSizeConverter getInstance() {
        return Holder.INSTANCE;
    }
    
    private DeriveSizeConverter() {
    }
    
    @Override
    public Size convert(final ParsedValue<ParsedValue<Size, Size>[], Size> parsedValue, final Font font) {
        final ParsedValue<Size, Size>[] array = parsedValue.getValue();
        return new Size(array[0].convert(font).pixels(font) + array[1].convert(font).pixels(font), SizeUnits.PX);
    }
    
    @Override
    public String toString() {
        return "DeriveSizeConverter";
    }
    
    private static class Holder
    {
        static final DeriveSizeConverter INSTANCE;
        
        static {
            INSTANCE = new DeriveSizeConverter(null);
        }
    }
}
