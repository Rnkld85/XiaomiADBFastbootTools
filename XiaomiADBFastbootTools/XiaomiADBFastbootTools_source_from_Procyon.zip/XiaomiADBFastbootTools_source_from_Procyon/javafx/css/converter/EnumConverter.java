// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.text.TextAlignment;
import javafx.scene.text.FontWeight;
import javafx.scene.text.FontSmoothingType;
import javafx.scene.text.FontPosture;
import javafx.scene.shape.StrokeType;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.ArcType;
import javafx.scene.paint.CycleMethod;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.BlendMode;
import javafx.geometry.VPos;
import javafx.geometry.Side;
import javafx.geometry.Pos;
import javafx.geometry.Orientation;
import javafx.geometry.HPos;
import javafx.scene.layout.BackgroundRepeat;
import com.sun.javafx.cursor.CursorType;
import java.util.HashMap;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.util.Logging;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.DataOutputStream;
import java.util.Locale;
import javafx.scene.text.Font;
import javafx.css.ParsedValue;
import java.util.Map;
import javafx.css.StyleConverter;

public final class EnumConverter<E extends Enum<E>> extends StyleConverter<String, E>
{
    final Class<E> enumClass;
    private static Map<String, StyleConverter<?, ?>> converters;
    
    public EnumConverter(final Class<E> enumClass) {
        this.enumClass = enumClass;
    }
    
    @Override
    public E convert(final ParsedValue<String, E> parsedValue, final Font font) {
        if (this.enumClass == null) {
            return null;
        }
        String name = parsedValue.getValue();
        final int lastIndex = name.lastIndexOf(46);
        if (lastIndex > -1) {
            name = name.substring(lastIndex + 1);
        }
        try {
            name = name.replace('-', '_');
            return Enum.valueOf(this.enumClass, name.toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException ex) {
            return Enum.valueOf(this.enumClass, name);
        }
    }
    
    @Override
    public void writeBinary(final DataOutputStream dataOutputStream, final StringStore stringStore) throws IOException {
        super.writeBinary(dataOutputStream, stringStore);
        dataOutputStream.writeShort(stringStore.addString(this.enumClass.getName()));
    }
    
    public static StyleConverter<?, ?> readBinary(final DataInputStream dataInputStream, final String[] array) throws IOException {
        final short short1 = dataInputStream.readShort();
        final String s = (0 <= short1 && short1 <= array.length) ? array[short1] : null;
        if (s == null || s.isEmpty()) {
            return null;
        }
        if (EnumConverter.converters == null || !EnumConverter.converters.containsKey(s)) {
            final StyleConverter<?, ?> instance = getInstance(s);
            if (instance == null) {
                final PlatformLogger cssLogger = Logging.getCSSLogger();
                if (cssLogger.isLoggable(PlatformLogger.Level.SEVERE)) {
                    cssLogger.severe(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                }
            }
            if (EnumConverter.converters == null) {
                EnumConverter.converters = new HashMap<String, StyleConverter<?, ?>>();
            }
            EnumConverter.converters.put(s, instance);
            return instance;
        }
        return EnumConverter.converters.get(s);
    }
    
    public static StyleConverter<?, ?> getInstance(final String s) {
        StyleConverter<?, ?> styleConverter = null;
        switch (s) {
            case "com.sun.javafx.cursor.CursorType": {
                styleConverter = new EnumConverter<Object>(CursorType.class);
                break;
            }
            case "javafx.scene.layout.BackgroundRepeat":
            case "com.sun.javafx.scene.layout.region.Repeat": {
                styleConverter = new EnumConverter<Object>(BackgroundRepeat.class);
                break;
            }
            case "javafx.geometry.HPos": {
                styleConverter = new EnumConverter<Object>(HPos.class);
                break;
            }
            case "javafx.geometry.Orientation": {
                styleConverter = new EnumConverter<Object>(Orientation.class);
                break;
            }
            case "javafx.geometry.Pos": {
                styleConverter = new EnumConverter<Object>(Pos.class);
                break;
            }
            case "javafx.geometry.Side": {
                styleConverter = new EnumConverter<Object>(Side.class);
                break;
            }
            case "javafx.geometry.VPos": {
                styleConverter = new EnumConverter<Object>(VPos.class);
                break;
            }
            case "javafx.scene.effect.BlendMode": {
                styleConverter = new EnumConverter<Object>(BlendMode.class);
                break;
            }
            case "javafx.scene.effect.BlurType": {
                styleConverter = new EnumConverter<Object>(BlurType.class);
                break;
            }
            case "javafx.scene.paint.CycleMethod": {
                styleConverter = new EnumConverter<Object>(CycleMethod.class);
                break;
            }
            case "javafx.scene.shape.ArcType": {
                styleConverter = new EnumConverter<Object>(ArcType.class);
                break;
            }
            case "javafx.scene.shape.StrokeLineCap": {
                styleConverter = new EnumConverter<Object>(StrokeLineCap.class);
                break;
            }
            case "javafx.scene.shape.StrokeLineJoin": {
                styleConverter = new EnumConverter<Object>(StrokeLineJoin.class);
                break;
            }
            case "javafx.scene.shape.StrokeType": {
                styleConverter = new EnumConverter<Object>(StrokeType.class);
                break;
            }
            case "javafx.scene.text.FontPosture": {
                styleConverter = new EnumConverter<Object>(FontPosture.class);
                break;
            }
            case "javafx.scene.text.FontSmoothingType": {
                styleConverter = new EnumConverter<Object>(FontSmoothingType.class);
                break;
            }
            case "javafx.scene.text.FontWeight": {
                styleConverter = new EnumConverter<Object>(FontWeight.class);
                break;
            }
            case "javafx.scene.text.TextAlignment": {
                styleConverter = new EnumConverter<Object>(TextAlignment.class);
                break;
            }
            default: {
                assert false : invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s);
                final PlatformLogger cssLogger = Logging.getCSSLogger();
                if (cssLogger.isLoggable(PlatformLogger.Level.SEVERE)) {
                    cssLogger.severe(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                    break;
                }
                break;
            }
        }
        return styleConverter;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o == this || (o != null && o instanceof EnumConverter && this.enumClass.equals(((EnumConverter)o).enumClass));
    }
    
    @Override
    public int hashCode() {
        return this.enumClass.hashCode();
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.enumClass.getName());
    }
}
