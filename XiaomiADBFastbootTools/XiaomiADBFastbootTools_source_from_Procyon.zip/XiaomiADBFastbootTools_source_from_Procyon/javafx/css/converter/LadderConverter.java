// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import com.sun.javafx.util.Utils;
import javafx.scene.paint.Stop;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class LadderConverter extends StyleConverter<ParsedValue[], Color>
{
    public static LadderConverter getInstance() {
        return Holder.INSTANCE;
    }
    
    private LadderConverter() {
    }
    
    @Override
    public Color convert(final ParsedValue<ParsedValue[], Color> parsedValue, final Font font) {
        final ParsedValue[] array = parsedValue.getValue();
        final Color color = (Color)array[0].convert(font);
        final Stop[] array2 = new Stop[array.length - 1];
        for (int i = 1; i < array.length; ++i) {
            array2[i - 1] = (Stop)array[i].convert(font);
        }
        return Utils.ladder(color, array2);
    }
    
    @Override
    public String toString() {
        return "LadderConverter";
    }
    
    private static class Holder
    {
        static final LadderConverter INSTANCE;
        
        static {
            INSTANCE = new LadderConverter(null);
        }
    }
}
