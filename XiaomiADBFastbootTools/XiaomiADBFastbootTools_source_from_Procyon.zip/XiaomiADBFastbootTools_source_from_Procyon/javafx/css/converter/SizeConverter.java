// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.text.Font;
import javafx.css.Size;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class SizeConverter extends StyleConverter<ParsedValue<?, Size>, Number>
{
    public static StyleConverter<ParsedValue<?, Size>, Number> getInstance() {
        return Holder.INSTANCE;
    }
    
    private SizeConverter() {
    }
    
    @Override
    public Number convert(final ParsedValue<ParsedValue<?, Size>, Number> parsedValue, final Font font) {
        return parsedValue.getValue().convert(font).pixels(font);
    }
    
    @Override
    public String toString() {
        return "SizeConverter";
    }
    
    private static class Holder
    {
        static final SizeConverter INSTANCE;
        static final SequenceConverter SEQUENCE_INSTANCE;
        
        static {
            INSTANCE = new SizeConverter(null);
            SEQUENCE_INSTANCE = new SequenceConverter();
        }
    }
    
    public static final class SequenceConverter extends StyleConverter<ParsedValue[], Number[]>
    {
        public static SequenceConverter getInstance() {
            return Holder.SEQUENCE_INSTANCE;
        }
        
        private SequenceConverter() {
        }
        
        @Override
        public Number[] convert(final ParsedValue<ParsedValue[], Number[]> parsedValue, final Font font) {
            final ParsedValue[] array = parsedValue.getValue();
            final Number[] array2 = new Number[array.length];
            for (int i = 0; i < array.length; ++i) {
                array2[i] = ((Size)array[i].convert(font)).pixels(font);
            }
            return array2;
        }
        
        @Override
        public String toString() {
            return "Size.SequenceConverter";
        }
    }
}
