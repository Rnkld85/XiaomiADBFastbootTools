// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.text.Font;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class BooleanConverter extends StyleConverter<String, Boolean>
{
    public static StyleConverter<String, Boolean> getInstance() {
        return Holder.INSTANCE;
    }
    
    private BooleanConverter() {
    }
    
    @Override
    public Boolean convert(final ParsedValue<String, Boolean> parsedValue, final Font font) {
        return Boolean.valueOf(parsedValue.getValue());
    }
    
    @Override
    public String toString() {
        return "BooleanConverter";
    }
    
    private static class Holder
    {
        static final BooleanConverter INSTANCE;
        
        static {
            INSTANCE = new BooleanConverter(null);
        }
    }
}
