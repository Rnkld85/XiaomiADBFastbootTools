// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.scene.text.Font;
import javafx.css.ParsedValue;
import javafx.scene.Cursor;
import javafx.css.StyleConverter;

public final class CursorConverter extends StyleConverter<String, Cursor>
{
    public static StyleConverter<String, Cursor> getInstance() {
        return Holder.INSTANCE;
    }
    
    private CursorConverter() {
    }
    
    @Override
    public Cursor convert(final ParsedValue<String, Cursor> parsedValue, final Font font) {
        String s = parsedValue.getValue();
        if (s != null) {
            final int index = s.indexOf("Cursor.");
            if (index > -1) {
                s = s.substring(index + "Cursor.".length());
            }
            s = s.replace('-', '_').toUpperCase();
        }
        try {
            return Cursor.cursor(s);
        }
        catch (IllegalArgumentException | NullPointerException ex) {
            return Cursor.DEFAULT;
        }
    }
    
    @Override
    public String toString() {
        return "CursorConverter";
    }
    
    private static class Holder
    {
        static final CursorConverter INSTANCE;
        
        static {
            INSTANCE = new CursorConverter(null);
        }
    }
}
