// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import java.security.PrivilegedActionException;
import java.security.AccessController;
import javafx.application.Application;
import java.net.URISyntaxException;
import java.net.MalformedURLException;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.util.Logging;
import java.net.URI;
import java.net.URL;
import com.sun.javafx.util.Utils;
import javafx.scene.text.Font;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class URLConverter extends StyleConverter<ParsedValue[], String>
{
    public static StyleConverter<ParsedValue[], String> getInstance() {
        return Holder.INSTANCE;
    }
    
    private URLConverter() {
    }
    
    @Override
    public String convert(final ParsedValue<ParsedValue[], String> parsedValue, final Font font) {
        String externalForm = null;
        final ParsedValue[] array = parsedValue.getValue();
        final String s = (array.length > 0) ? StringConverter.getInstance().convert(array[0], font) : null;
        if (s != null && !s.trim().isEmpty()) {
            String s2;
            if (s.startsWith("url(")) {
                s2 = Utils.stripQuotes(s.substring(4, s.length() - 1));
            }
            else {
                s2 = Utils.stripQuotes(s);
            }
            final URL resolve = this.resolve((array.length > 1 && array[1] != null) ? ((String)array[1].getValue()) : null, s2);
            if (resolve != null) {
                externalForm = resolve.toExternalForm();
            }
        }
        return externalForm;
    }
    
    URL resolve(final String s, final String s2) {
        final String str = (s2 != null) ? s2.trim() : null;
        if (str == null || str.isEmpty()) {
            return null;
        }
        try {
            final URI uri = new URI(str);
            if (uri.isAbsolute()) {
                return uri.toURL();
            }
            final URL resolveRuntimeImport = this.resolveRuntimeImport(uri);
            if (resolveRuntimeImport != null) {
                return resolveRuntimeImport;
            }
            final String path = uri.getPath();
            if (path.startsWith("/")) {
                return Thread.currentThread().getContextClassLoader().getResource(path.substring(1));
            }
            final String str2 = (s != null) ? s.trim() : null;
            if (str2 == null || str2.isEmpty()) {
                return Thread.currentThread().getContextClassLoader().getResource(path);
            }
            final URI uri2 = new URI(str2);
            if (!uri2.isOpaque()) {
                return uri2.resolve(uri).toURL();
            }
            return new URL(uri2.toURL(), uri.getPath());
        }
        catch (MalformedURLException | URISyntaxException ex3) {
            final URISyntaxException ex2;
            final URISyntaxException ex = ex2;
            final PlatformLogger cssLogger = Logging.getCSSLogger();
            if (cssLogger.isLoggable(PlatformLogger.Level.WARNING)) {
                cssLogger.warning(ex.getLocalizedMessage());
            }
            return null;
        }
    }
    
    private URL resolveRuntimeImport(final URI uri) {
        final String path = uri.getPath();
        final String s = path.startsWith("/") ? path.substring(1) : path;
        if ((s.startsWith("com/sun/javafx/scene/control/skin/modena/") || s.startsWith("com/sun/javafx/scene/control/skin/caspian/")) && (s.endsWith(".css") || s.endsWith(".bss"))) {
            System.err.println(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
            if (System.getSecurityManager() == null) {
                return Thread.currentThread().getContextClassLoader().getResource(s);
            }
            try {
                final URI uri2 = AccessController.doPrivileged(() -> Application.class.getProtectionDomain().getCodeSource().getLocation()).toURI();
                String scheme = uri2.getScheme();
                String s2 = uri2.getPath();
                if ("file".equals(scheme) && s2.endsWith(".jar") && "file".equals(scheme)) {
                    scheme = "jar:file";
                    s2 = s2.concat("!/");
                }
                return new URI(scheme, uri2.getUserInfo(), uri2.getHost(), uri2.getPort(), s2.concat(s), null, null).toURL();
            }
            catch (URISyntaxException ex) {}
            catch (MalformedURLException ex2) {}
            catch (PrivilegedActionException ex3) {}
        }
        return null;
    }
    
    @Override
    public String toString() {
        return "URLType";
    }
    
    private static class Holder
    {
        static final URLConverter INSTANCE;
        static final SequenceConverter SEQUENCE_INSTANCE;
        
        static {
            INSTANCE = new URLConverter(null);
            SEQUENCE_INSTANCE = new SequenceConverter();
        }
    }
    
    public static final class SequenceConverter extends StyleConverter<ParsedValue<ParsedValue[], String>[], String[]>
    {
        public static SequenceConverter getInstance() {
            return Holder.SEQUENCE_INSTANCE;
        }
        
        private SequenceConverter() {
        }
        
        @Override
        public String[] convert(final ParsedValue<ParsedValue<ParsedValue[], String>[], String[]> parsedValue, final Font font) {
            final ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[] array = (ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[], String[]>[], String>[])parsedValue.getValue();
            final String[] array2 = new String[array.length];
            for (int i = 0; i < array.length; ++i) {
                array2[i] = URLConverter.getInstance().convert((ParsedValue<ParsedValue[], String>)array[i], font);
            }
            return array2;
        }
        
        @Override
        public String toString() {
            return "URLSeqType";
        }
    }
}
