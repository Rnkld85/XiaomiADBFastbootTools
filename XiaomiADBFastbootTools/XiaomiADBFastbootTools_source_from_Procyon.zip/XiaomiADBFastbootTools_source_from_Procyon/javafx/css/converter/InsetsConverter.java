// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import javafx.css.Size;
import javafx.scene.text.Font;
import javafx.geometry.Insets;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class InsetsConverter extends StyleConverter<ParsedValue[], Insets>
{
    public static StyleConverter<ParsedValue[], Insets> getInstance() {
        return Holder.INSTANCE;
    }
    
    private InsetsConverter() {
    }
    
    @Override
    public Insets convert(final ParsedValue<ParsedValue[], Insets> parsedValue, final Font font) {
        final ParsedValue[] array = parsedValue.getValue();
        final double pixels = ((Size)array[0].convert(font)).pixels(font);
        final double n = (array.length > 1) ? ((Size)array[1].convert(font)).pixels(font) : pixels;
        return new Insets(pixels, n, (array.length > 2) ? ((Size)array[2].convert(font)).pixels(font) : pixels, (array.length > 3) ? ((Size)array[3].convert(font)).pixels(font) : n);
    }
    
    @Override
    public String toString() {
        return "InsetsConverter";
    }
    
    private static class Holder
    {
        static final InsetsConverter INSTANCE;
        static final SequenceConverter SEQUENCE_INSTANCE;
        
        static {
            INSTANCE = new InsetsConverter(null);
            SEQUENCE_INSTANCE = new SequenceConverter();
        }
    }
    
    public static final class SequenceConverter extends StyleConverter<ParsedValue<ParsedValue[], Insets>[], Insets[]>
    {
        public static SequenceConverter getInstance() {
            return Holder.SEQUENCE_INSTANCE;
        }
        
        private SequenceConverter() {
        }
        
        @Override
        public Insets[] convert(final ParsedValue<ParsedValue<ParsedValue[], Insets>[], Insets[]> parsedValue, final Font font) {
            final ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[] array = (ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue<ParsedValue[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[], Insets[]>[], Insets>[])parsedValue.getValue();
            final Insets[] array2 = new Insets[array.length];
            for (int i = 0; i < array.length; ++i) {
                array2[i] = InsetsConverter.getInstance().convert((ParsedValue<ParsedValue[], Insets>)array[i], font);
            }
            return array2;
        }
        
        @Override
        public String toString() {
            return "InsetsSequenceConverter";
        }
    }
}
