// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css.converter;

import com.sun.javafx.util.Utils;
import javafx.css.Size;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
import javafx.css.ParsedValue;
import javafx.css.StyleConverter;

public final class DeriveColorConverter extends StyleConverter<ParsedValue[], Color>
{
    public static DeriveColorConverter getInstance() {
        return Holder.INSTANCE;
    }
    
    private DeriveColorConverter() {
    }
    
    @Override
    public Color convert(final ParsedValue<ParsedValue[], Color> parsedValue, final Font font) {
        final ParsedValue[] array = parsedValue.getValue();
        return Utils.deriveColor((Color)array[0].convert(font), ((Size)array[1].convert(font)).pixels(font));
    }
    
    @Override
    public String toString() {
        return "DeriveColorConverter";
    }
    
    private static class Holder
    {
        static final DeriveColorConverter INSTANCE;
        
        static {
            INSTANCE = new DeriveColorConverter(null);
        }
    }
}
