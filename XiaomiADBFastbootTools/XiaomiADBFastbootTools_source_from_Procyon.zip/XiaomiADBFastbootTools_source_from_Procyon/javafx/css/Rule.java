// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.Set;
import javafx.scene.Node;
import javafx.collections.ObservableList;
import java.io.IOException;
import java.io.InputStream;
import java.io.DataInputStream;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

public final class Rule
{
    private List<Selector> selectors;
    private List<Declaration> declarations;
    private Observables observables;
    private Stylesheet stylesheet;
    private byte[] serializedDecls;
    private final int bssVersion;
    
    List<Selector> getUnobservedSelectorList() {
        if (this.selectors == null) {
            this.selectors = new ArrayList<Selector>();
        }
        return this.selectors;
    }
    
    List<Declaration> getUnobservedDeclarationList() {
        if (this.declarations == null && this.serializedDecls != null) {
            try {
                final DataInputStream dataInputStream = new DataInputStream(new ByteArrayInputStream(this.serializedDecls));
                final short short1 = dataInputStream.readShort();
                this.declarations = new ArrayList<Declaration>(short1);
                for (short n = 0; n < short1; ++n) {
                    final Declaration binary = Declaration.readBinary(this.bssVersion, dataInputStream, this.stylesheet.getStringStore());
                    binary.rule = this;
                    if (this.stylesheet != null && this.stylesheet.getUrl() != null) {
                        binary.fixUrl(this.stylesheet.getUrl());
                    }
                    this.declarations.add(binary);
                }
            }
            catch (IOException ex) {
                this.declarations = new ArrayList<Declaration>();
                assert false;
                ex.getMessage();
            }
            finally {
                this.serializedDecls = null;
            }
        }
        return this.declarations;
    }
    
    public final ObservableList<Declaration> getDeclarations() {
        if (this.observables == null) {
            this.observables = new Observables(this);
        }
        return this.observables.getDeclarations();
    }
    
    public final ObservableList<Selector> getSelectors() {
        if (this.observables == null) {
            this.observables = new Observables(this);
        }
        return this.observables.getSelectors();
    }
    
    public Stylesheet getStylesheet() {
        return this.stylesheet;
    }
    
    void setStylesheet(final Stylesheet stylesheet) {
        this.stylesheet = stylesheet;
        if (stylesheet != null && stylesheet.getUrl() != null) {
            final String url = stylesheet.getUrl();
            for (int n = (this.declarations != null) ? this.declarations.size() : 0, i = 0; i < n; ++i) {
                this.declarations.get(i).fixUrl(url);
            }
        }
    }
    
    public StyleOrigin getOrigin() {
        return (this.stylesheet != null) ? this.stylesheet.getOrigin() : null;
    }
    
    Rule(final List<Selector> selectors, final List<Declaration> declarations) {
        this.selectors = null;
        this.declarations = null;
        this.observables = null;
        this.selectors = selectors;
        this.declarations = declarations;
        this.serializedDecls = null;
        this.bssVersion = 6;
        for (int n = (selectors != null) ? selectors.size() : 0, i = 0; i < n; ++i) {
            selectors.get(i).setRule(this);
        }
        for (int n2 = (declarations != null) ? declarations.size() : 0, j = 0; j < n2; ++j) {
            declarations.get(j).rule = this;
        }
    }
    
    private Rule(final List<Selector> selectors, final byte[] serializedDecls, final int bssVersion) {
        this.selectors = null;
        this.declarations = null;
        this.observables = null;
        this.selectors = selectors;
        this.declarations = null;
        this.serializedDecls = serializedDecls;
        this.bssVersion = bssVersion;
        for (int n = (selectors != null) ? selectors.size() : 0, i = 0; i < n; ++i) {
            selectors.get(i).setRule(this);
        }
    }
    
    long applies(final Node node, final Set<PseudoClass>[] array) {
        long n = 0L;
        for (int i = 0; i < this.selectors.size(); ++i) {
            if (this.selectors.get(i).applies(node, array, 0)) {
                n |= 1L << i;
            }
        }
        return n;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        if (this.selectors.size() > 0) {
            sb.append(this.selectors.get(0));
        }
        for (int i = 1; i < this.selectors.size(); ++i) {
            sb.append(',');
            sb.append(this.selectors.get(i));
        }
        sb.append("{\n");
        for (int n = (this.declarations != null) ? this.declarations.size() : 0, j = 0; j < n; ++j) {
            sb.append("\t");
            sb.append(this.declarations.get(j));
            sb.append("\n");
        }
        sb.append("}");
        return sb.toString();
    }
    
    final void writeBinary(final DataOutputStream dataOutputStream, final StyleConverter.StringStore stringStore) throws IOException {
        final int v = (this.selectors != null) ? this.selectors.size() : 0;
        dataOutputStream.writeShort(v);
        for (int i = 0; i < v; ++i) {
            this.selectors.get(i).writeBinary(dataOutputStream, stringStore);
        }
        final List<Declaration> unobservedDeclarationList = this.getUnobservedDeclarationList();
        if (unobservedDeclarationList != null) {
            final ByteArrayOutputStream out = new ByteArrayOutputStream(5192);
            final DataOutputStream dataOutputStream2 = new DataOutputStream(out);
            final int size = unobservedDeclarationList.size();
            dataOutputStream2.writeShort(size);
            for (int j = 0; j < size; ++j) {
                this.declarations.get(j).writeBinary(dataOutputStream2, stringStore);
            }
            dataOutputStream.writeInt(out.size());
            dataOutputStream.write(out.toByteArray());
        }
        else {
            dataOutputStream.writeShort(0);
        }
    }
    
    static Rule readBinary(final int n, final DataInputStream dataInputStream, final String[] array) throws IOException {
        final short short1 = dataInputStream.readShort();
        final ArrayList list = new ArrayList<Selector>(short1);
        for (short n2 = 0; n2 < short1; ++n2) {
            list.add(Selector.readBinary(n, dataInputStream, array));
        }
        if (n < 4) {
            final short short2 = dataInputStream.readShort();
            final ArrayList list2 = new ArrayList<Declaration>(short2);
            for (short n3 = 0; n3 < short2; ++n3) {
                list2.add(Declaration.readBinary(n, dataInputStream, array));
            }
            return new Rule((List<Selector>)list, (List<Declaration>)list2);
        }
        final int int1 = dataInputStream.readInt();
        final byte[] b = new byte[int1];
        if (int1 > 0) {
            dataInputStream.readFully(b);
        }
        return new Rule((List<Selector>)list, b, n);
    }
    
    private static final class Observables
    {
        private final Rule rule;
        private final ObservableList<Selector> selectorObservableList;
        private final ObservableList<Declaration> declarationObservableList;
        
        private Observables(final Rule rule) {
            this.rule = rule;
            this.selectorObservableList = new TrackableObservableList<Selector>(rule.getUnobservedSelectorList()) {
                @Override
                protected void onChanged(final ListChangeListener.Change<Selector> change) {
                    while (change.next()) {
                        if (change.wasAdded()) {
                            final List<Selector> addedSubList = change.getAddedSubList();
                            for (int i = 0; i < addedSubList.size(); ++i) {
                                addedSubList.get(i).setRule(Observables.this.rule);
                            }
                        }
                        if (change.wasRemoved()) {
                            final List<Selector> addedSubList2 = change.getAddedSubList();
                            for (int j = 0; j < addedSubList2.size(); ++j) {
                                final Selector selector = addedSubList2.get(j);
                                if (selector.getRule() == Observables.this.rule) {
                                    selector.setRule(null);
                                }
                            }
                        }
                    }
                }
            };
            this.declarationObservableList = new TrackableObservableList<Declaration>(rule.getUnobservedDeclarationList()) {
                @Override
                protected void onChanged(final ListChangeListener.Change<Declaration> change) {
                    while (change.next()) {
                        if (change.wasAdded()) {
                            final List<Declaration> addedSubList = change.getAddedSubList();
                            for (int i = 0; i < addedSubList.size(); ++i) {
                                final Declaration declaration = addedSubList.get(i);
                                declaration.rule = Observables.this.rule;
                                final Stylesheet access$400 = Observables.this.rule.stylesheet;
                                if (access$400 != null && access$400.getUrl() != null) {
                                    declaration.fixUrl(access$400.getUrl());
                                }
                            }
                        }
                        if (change.wasRemoved()) {
                            final List<Declaration> removed = change.getRemoved();
                            for (int j = 0; j < removed.size(); ++j) {
                                final Declaration declaration2 = removed.get(j);
                                if (declaration2.rule == Observables.this.rule) {
                                    declaration2.rule = null;
                                }
                            }
                        }
                    }
                }
            };
        }
        
        private ObservableList<Selector> getSelectors() {
            return this.selectorObservableList;
        }
        
        private ObservableList<Declaration> getDeclarations() {
            return this.declarationObservableList;
        }
    }
}
