// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.scene.Node;
import javafx.collections.ObservableSet;
import java.util.List;
import javafx.collections.ObservableList;

public interface Styleable
{
    String getTypeSelector();
    
    String getId();
    
    ObservableList<String> getStyleClass();
    
    String getStyle();
    
    List<CssMetaData<? extends Styleable, ?>> getCssMetaData();
    
    Styleable getStyleableParent();
    
    ObservableSet<PseudoClass> getPseudoClassStates();
    
    default Node getStyleableNode() {
        return null;
    }
}
