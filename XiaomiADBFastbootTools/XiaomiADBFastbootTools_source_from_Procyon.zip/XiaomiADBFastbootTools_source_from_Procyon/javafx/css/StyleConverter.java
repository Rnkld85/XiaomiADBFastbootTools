// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import javafx.css.converter.StopConverter;
import javafx.css.converter.LadderConverter;
import javafx.css.converter.DeriveSizeConverter;
import javafx.css.converter.DeriveColorConverter;
import com.sun.javafx.scene.layout.region.CornerRadiiConverter;
import com.sun.javafx.scene.layout.region.Margins;
import com.sun.javafx.scene.layout.region.StrokeBorderPaintConverter;
import com.sun.javafx.scene.layout.region.SliceSequenceConverter;
import com.sun.javafx.scene.layout.region.RepeatStructConverter;
import com.sun.javafx.scene.layout.region.LayeredBorderStyleConverter;
import com.sun.javafx.scene.layout.region.LayeredBorderPaintConverter;
import com.sun.javafx.scene.layout.region.LayeredBackgroundSizeConverter;
import com.sun.javafx.scene.layout.region.LayeredBackgroundPositionConverter;
import com.sun.javafx.scene.layout.region.BorderStyleConverter;
import com.sun.javafx.scene.layout.region.BorderStrokeStyleSequenceConverter;
import com.sun.javafx.scene.layout.region.BorderImageWidthsSequenceConverter;
import com.sun.javafx.scene.layout.region.BorderImageWidthConverter;
import com.sun.javafx.scene.layout.region.BorderImageSliceConverter;
import com.sun.javafx.scene.layout.region.BackgroundSizeConverter;
import com.sun.javafx.scene.layout.region.BackgroundPositionConverter;
import javafx.css.converter.CursorConverter;
import java.util.HashMap;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.util.Logging;
import java.io.DataInputStream;
import java.util.WeakHashMap;
import java.io.IOException;
import java.io.DataOutputStream;
import javafx.css.converter.URLConverter;
import javafx.css.converter.StringConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.converter.PaintConverter;
import javafx.scene.paint.Paint;
import javafx.css.converter.InsetsConverter;
import javafx.geometry.Insets;
import javafx.css.converter.FontConverter;
import javafx.css.converter.EnumConverter;
import javafx.css.converter.EffectConverter;
import javafx.scene.effect.Effect;
import javafx.css.converter.ColorConverter;
import javafx.scene.paint.Color;
import javafx.css.converter.DurationConverter;
import javafx.util.Duration;
import javafx.css.converter.BooleanConverter;
import javafx.scene.text.Font;
import java.util.Map;

public class StyleConverter<F, T>
{
    private static Map<ParsedValue, Object> cache;
    private static Map<String, StyleConverter<?, ?>> tmap;
    
    public T convert(final ParsedValue<F, T> parsedValue, final Font font) {
        return (T)parsedValue.getValue();
    }
    
    public static StyleConverter<String, Boolean> getBooleanConverter() {
        return BooleanConverter.getInstance();
    }
    
    public static StyleConverter<?, Duration> getDurationConverter() {
        return DurationConverter.getInstance();
    }
    
    public static StyleConverter<String, Color> getColorConverter() {
        return ColorConverter.getInstance();
    }
    
    public static StyleConverter<ParsedValue[], Effect> getEffectConverter() {
        return EffectConverter.getInstance();
    }
    
    public static <E extends Enum<E>> StyleConverter<String, E> getEnumConverter(final Class<E> clazz) {
        return (StyleConverter<String, E>)new EnumConverter((Class<Enum>)clazz);
    }
    
    public static StyleConverter<ParsedValue[], Font> getFontConverter() {
        return FontConverter.getInstance();
    }
    
    public static StyleConverter<ParsedValue[], Insets> getInsetsConverter() {
        return InsetsConverter.getInstance();
    }
    
    public static StyleConverter<ParsedValue<?, Paint>, Paint> getPaintConverter() {
        return PaintConverter.getInstance();
    }
    
    public static StyleConverter<?, Number> getSizeConverter() {
        return SizeConverter.getInstance();
    }
    
    public static StyleConverter<String, String> getStringConverter() {
        return StringConverter.getInstance();
    }
    
    public static StyleConverter<ParsedValue[], String> getUrlConverter() {
        return URLConverter.getInstance();
    }
    
    public T convert(final Map<CssMetaData<? extends Styleable, ?>, Object> map) {
        return null;
    }
    
    public void writeBinary(final DataOutputStream dataOutputStream, final StringStore stringStore) throws IOException {
        dataOutputStream.writeShort(stringStore.addString(this.getClass().getName()));
    }
    
    public static void clearCache() {
        if (StyleConverter.cache != null) {
            StyleConverter.cache.clear();
        }
    }
    
    protected T getCachedValue(final ParsedValue parsedValue) {
        if (StyleConverter.cache != null) {
            return (T)StyleConverter.cache.get(parsedValue);
        }
        return null;
    }
    
    protected void cacheValue(final ParsedValue parsedValue, final Object o) {
        if (StyleConverter.cache == null) {
            StyleConverter.cache = new WeakHashMap<ParsedValue, Object>();
        }
        StyleConverter.cache.put(parsedValue, o);
    }
    
    public static StyleConverter<?, ?> readBinary(final DataInputStream dataInputStream, final String[] array) throws IOException {
        String s = array[dataInputStream.readShort()];
        if (s == null || s.isEmpty()) {
            return null;
        }
        if (s.startsWith("com.sun.javafx.css.converters.")) {
            s = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s.substring("com.sun.javafx.css.converters.".length()));
        }
        if (s.startsWith("javafx.css.converter.EnumConverter")) {
            return EnumConverter.readBinary(dataInputStream, array);
        }
        if (StyleConverter.tmap == null || !StyleConverter.tmap.containsKey(s)) {
            final StyleConverter<?, ?> instance = getInstance(s);
            if (instance == null) {
                final PlatformLogger cssLogger = Logging.getCSSLogger();
                if (cssLogger.isLoggable(PlatformLogger.Level.SEVERE)) {
                    cssLogger.severe(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                }
            }
            if (instance == null) {
                System.err.println(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
            }
            if (StyleConverter.tmap == null) {
                StyleConverter.tmap = new HashMap<String, StyleConverter<?, ?>>();
            }
            StyleConverter.tmap.put(s, instance);
            return instance;
        }
        return StyleConverter.tmap.get(s);
    }
    
    static StyleConverter<?, ?> getInstance(final String s) {
        StyleConverter<?, ?> styleConverter = null;
        switch (s) {
            case "javafx.css.converter.BooleanConverter": {
                styleConverter = BooleanConverter.getInstance();
                break;
            }
            case "javafx.css.converter.ColorConverter": {
                styleConverter = ColorConverter.getInstance();
                break;
            }
            case "javafx.css.converter.CursorConverter": {
                styleConverter = CursorConverter.getInstance();
                break;
            }
            case "javafx.css.converter.EffectConverter": {
                styleConverter = EffectConverter.getInstance();
                break;
            }
            case "javafx.css.converter.EffectConverter$DropShadowConverter": {
                styleConverter = EffectConverter.DropShadowConverter.getInstance();
                break;
            }
            case "javafx.css.converter.EffectConverter$InnerShadowConverter": {
                styleConverter = EffectConverter.InnerShadowConverter.getInstance();
                break;
            }
            case "javafx.css.converter.FontConverter": {
                styleConverter = FontConverter.getInstance();
                break;
            }
            case "javafx.css.converter.FontConverter$FontStyleConverter":
            case "javafx.css.converter.FontConverter$StyleConverter": {
                styleConverter = FontConverter.FontStyleConverter.getInstance();
                break;
            }
            case "javafx.css.converter.FontConverter$FontWeightConverter":
            case "javafx.css.converter.FontConverter$WeightConverter": {
                styleConverter = FontConverter.FontWeightConverter.getInstance();
                break;
            }
            case "javafx.css.converter.FontConverter$FontSizeConverter":
            case "javafx.css.converter.FontConverter$SizeConverter": {
                styleConverter = FontConverter.FontSizeConverter.getInstance();
                break;
            }
            case "javafx.css.converter.InsetsConverter": {
                styleConverter = InsetsConverter.getInstance();
                break;
            }
            case "javafx.css.converter.InsetsConverter$SequenceConverter": {
                styleConverter = InsetsConverter.SequenceConverter.getInstance();
                break;
            }
            case "javafx.css.converter.PaintConverter": {
                styleConverter = PaintConverter.getInstance();
                break;
            }
            case "javafx.css.converter.PaintConverter$SequenceConverter": {
                styleConverter = PaintConverter.SequenceConverter.getInstance();
                break;
            }
            case "javafx.css.converter.PaintConverter$LinearGradientConverter": {
                styleConverter = PaintConverter.LinearGradientConverter.getInstance();
                break;
            }
            case "javafx.css.converter.PaintConverter$RadialGradientConverter": {
                styleConverter = PaintConverter.RadialGradientConverter.getInstance();
                break;
            }
            case "javafx.css.converter.SizeConverter": {
                styleConverter = SizeConverter.getInstance();
                break;
            }
            case "javafx.css.converter.SizeConverter$SequenceConverter": {
                styleConverter = SizeConverter.SequenceConverter.getInstance();
                break;
            }
            case "javafx.css.converter.StringConverter": {
                styleConverter = StringConverter.getInstance();
                break;
            }
            case "javafx.css.converter.StringConverter$SequenceConverter": {
                styleConverter = StringConverter.SequenceConverter.getInstance();
                break;
            }
            case "javafx.css.converter.URLConverter": {
                styleConverter = URLConverter.getInstance();
                break;
            }
            case "javafx.css.converter.URLConverter$SequenceConverter": {
                styleConverter = URLConverter.SequenceConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.BackgroundPositionConverter":
            case "com.sun.javafx.scene.layout.region.BackgroundImage$BackgroundPositionConverter": {
                styleConverter = BackgroundPositionConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.BackgroundSizeConverter":
            case "com.sun.javafx.scene.layout.region.BackgroundImage$BackgroundSizeConverter": {
                styleConverter = BackgroundSizeConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.BorderImageSliceConverter":
            case "com.sun.javafx.scene.layout.region.BorderImage$SliceConverter": {
                styleConverter = BorderImageSliceConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.BorderImageWidthConverter": {
                styleConverter = BorderImageWidthConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.BorderImageWidthsSequenceConverter": {
                styleConverter = BorderImageWidthsSequenceConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.BorderStrokeStyleSequenceConverter":
            case "com.sun.javafx.scene.layout.region.StrokeBorder$BorderStyleSequenceConverter": {
                styleConverter = BorderStrokeStyleSequenceConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.BorderStyleConverter":
            case "com.sun.javafx.scene.layout.region.StrokeBorder$BorderStyleConverter": {
                styleConverter = BorderStyleConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.LayeredBackgroundPositionConverter":
            case "com.sun.javafx.scene.layout.region.BackgroundImage$LayeredBackgroundPositionConverter": {
                styleConverter = LayeredBackgroundPositionConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.LayeredBackgroundSizeConverter":
            case "com.sun.javafx.scene.layout.region.BackgroundImage$LayeredBackgroundSizeConverter": {
                styleConverter = LayeredBackgroundSizeConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.LayeredBorderPaintConverter":
            case "com.sun.javafx.scene.layout.region.StrokeBorder$LayeredBorderPaintConverter": {
                styleConverter = LayeredBorderPaintConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.LayeredBorderStyleConverter":
            case "com.sun.javafx.scene.layout.region.StrokeBorder$LayeredBorderStyleConverter": {
                styleConverter = LayeredBorderStyleConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.RepeatStructConverter":
            case "com.sun.javafx.scene.layout.region.BackgroundImage$BackgroundRepeatConverter":
            case "com.sun.javafx.scene.layout.region.BorderImage$RepeatConverter": {
                styleConverter = RepeatStructConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.SliceSequenceConverter":
            case "com.sun.javafx.scene.layout.region.BorderImage$SliceSequenceConverter": {
                styleConverter = SliceSequenceConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.StrokeBorderPaintConverter":
            case "com.sun.javafx.scene.layout.region.StrokeBorder$BorderPaintConverter": {
                styleConverter = StrokeBorderPaintConverter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.Margins$Converter": {
                styleConverter = Margins.Converter.getInstance();
                break;
            }
            case "com.sun.javafx.scene.layout.region.Margins$SequenceConverter": {
                styleConverter = Margins.SequenceConverter.getInstance();
                break;
            }
            case "javafx.scene.layout.CornerRadiiConverter":
            case "com.sun.javafx.scene.layout.region.CornerRadiiConverter": {
                styleConverter = CornerRadiiConverter.getInstance();
                break;
            }
            case "javafx.css.converter.DeriveColorConverter":
            case "com.sun.javafx.css.parser.DeriveColorConverter": {
                styleConverter = DeriveColorConverter.getInstance();
                break;
            }
            case "javafx.css.converter.DeriveSizeConverter":
            case "com.sun.javafx.css.parser.DeriveSizeConverter": {
                styleConverter = DeriveSizeConverter.getInstance();
                break;
            }
            case "javafx.css.converter.LadderConverter":
            case "com.sun.javafx.css.parser.LadderConverter": {
                styleConverter = LadderConverter.getInstance();
                break;
            }
            case "javafx.css.converter.StopConverter":
            case "com.sun.javafx.css.parser.StopConverter": {
                styleConverter = StopConverter.getInstance();
                break;
            }
            default: {
                final PlatformLogger cssLogger = Logging.getCSSLogger();
                if (cssLogger.isLoggable(PlatformLogger.Level.SEVERE)) {
                    cssLogger.severe(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                    break;
                }
                break;
            }
        }
        return styleConverter;
    }
    
    public static class StringStore
    {
        private final Map<String, Integer> stringMap;
        public final List<String> strings;
        
        public StringStore() {
            this.stringMap = new HashMap<String, Integer>();
            this.strings = new ArrayList<String>();
        }
        
        public int addString(final String s) {
            Integer value = this.stringMap.get(s);
            if (value == null) {
                value = this.strings.size();
                this.strings.add(s);
                this.stringMap.put(s, value);
            }
            return value;
        }
        
        public void writeBinary(final DataOutputStream dataOutputStream) throws IOException {
            dataOutputStream.writeShort(this.strings.size());
            if (this.stringMap.containsKey(null)) {
                dataOutputStream.writeShort(this.stringMap.get(null));
            }
            else {
                dataOutputStream.writeShort(-1);
            }
            for (int i = 0; i < this.strings.size(); ++i) {
                final String str = this.strings.get(i);
                if (str != null) {
                    dataOutputStream.writeUTF(str);
                }
            }
        }
        
        public static String[] readBinary(final DataInputStream dataInputStream) throws IOException {
            final short short1 = dataInputStream.readShort();
            final short short2 = dataInputStream.readShort();
            final String[] a = new String[short1];
            Arrays.fill(a, null);
            for (short n = 0; n < short1; ++n) {
                if (n != short2) {
                    a[n] = dataInputStream.readUTF();
                }
            }
            return a;
        }
    }
}
