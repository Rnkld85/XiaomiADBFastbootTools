// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.NamedArg;

public class SimpleStyleableDoubleProperty extends StyleableDoubleProperty
{
    private static final Object DEFAULT_BEAN;
    private static final String DEFAULT_NAME = "";
    private final Object bean;
    private final String name;
    private final CssMetaData<? extends Styleable, Number> cssMetaData;
    
    public SimpleStyleableDoubleProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Number> cssMetaData) {
        this(cssMetaData, SimpleStyleableDoubleProperty.DEFAULT_BEAN, "");
    }
    
    public SimpleStyleableDoubleProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Number> cssMetaData, @NamedArg("initialValue") final Double n) {
        this(cssMetaData, SimpleStyleableDoubleProperty.DEFAULT_BEAN, "", n);
    }
    
    public SimpleStyleableDoubleProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Number> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s) {
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    public SimpleStyleableDoubleProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Number> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s, @NamedArg("initialValue") final Double n) {
        super(n);
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    @Override
    public Object getBean() {
        return this.bean;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public final CssMetaData<? extends Styleable, Number> getCssMetaData() {
        return this.cssMetaData;
    }
    
    static {
        DEFAULT_BEAN = null;
    }
}
