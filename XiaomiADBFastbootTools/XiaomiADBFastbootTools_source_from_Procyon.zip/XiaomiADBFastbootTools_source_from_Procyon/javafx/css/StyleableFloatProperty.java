// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.value.ObservableValue;
import javafx.beans.property.FloatPropertyBase;

public abstract class StyleableFloatProperty extends FloatPropertyBase implements StyleableProperty<Number>
{
    private StyleOrigin origin;
    
    public StyleableFloatProperty() {
        this.origin = null;
    }
    
    public StyleableFloatProperty(final float n) {
        super(n);
        this.origin = null;
    }
    
    @Override
    public void applyStyle(final StyleOrigin origin, final Number value) {
        this.setValue(value);
        this.origin = origin;
    }
    
    @Override
    public void bind(final ObservableValue<? extends Number> observableValue) {
        super.bind(observableValue);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public void set(final float n) {
        super.set(n);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public StyleOrigin getStyleOrigin() {
        return this.origin;
    }
}
