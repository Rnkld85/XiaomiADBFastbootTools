// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.NamedArg;

public class SimpleStyleableLongProperty extends StyleableLongProperty
{
    private static final Object DEFAULT_BEAN;
    private static final String DEFAULT_NAME = "";
    private final Object bean;
    private final String name;
    private final CssMetaData<? extends Styleable, Number> cssMetaData;
    
    public SimpleStyleableLongProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Number> cssMetaData) {
        this(cssMetaData, SimpleStyleableLongProperty.DEFAULT_BEAN, "");
    }
    
    public SimpleStyleableLongProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Number> cssMetaData, @NamedArg("initialValue") final Long n) {
        this(cssMetaData, SimpleStyleableLongProperty.DEFAULT_BEAN, "", n);
    }
    
    public SimpleStyleableLongProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Number> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s) {
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    public SimpleStyleableLongProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Number> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s, @NamedArg("initialValue") final Long n) {
        super(n);
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    @Override
    public Object getBean() {
        return this.bean;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public final CssMetaData<? extends Styleable, Number> getCssMetaData() {
        return this.cssMetaData;
    }
    
    static {
        DEFAULT_BEAN = null;
    }
}
