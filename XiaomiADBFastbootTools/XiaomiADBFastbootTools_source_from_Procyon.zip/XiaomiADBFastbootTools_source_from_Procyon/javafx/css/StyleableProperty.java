// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.value.WritableValue;

public interface StyleableProperty<T> extends WritableValue<T>
{
    void applyStyle(final StyleOrigin p0, final T p1);
    
    StyleOrigin getStyleOrigin();
    
    CssMetaData<? extends Styleable, T> getCssMetaData();
}
