// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.value.ObservableValue;
import javafx.beans.property.IntegerPropertyBase;

public abstract class StyleableIntegerProperty extends IntegerPropertyBase implements StyleableProperty<Number>
{
    private StyleOrigin origin;
    
    public StyleableIntegerProperty() {
        this.origin = null;
    }
    
    public StyleableIntegerProperty(final int n) {
        super(n);
        this.origin = null;
    }
    
    @Override
    public void applyStyle(final StyleOrigin origin, final Number value) {
        this.setValue(value);
        this.origin = origin;
    }
    
    @Override
    public void bind(final ObservableValue<? extends Number> observableValue) {
        super.bind(observableValue);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public void set(final int n) {
        super.set(n);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public StyleOrigin getStyleOrigin() {
        return this.origin;
    }
}
