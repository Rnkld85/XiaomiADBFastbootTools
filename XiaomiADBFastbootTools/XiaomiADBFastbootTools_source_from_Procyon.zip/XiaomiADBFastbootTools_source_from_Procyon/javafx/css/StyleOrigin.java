// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

public enum StyleOrigin
{
    USER_AGENT, 
    USER, 
    AUTHOR, 
    INLINE;
}
