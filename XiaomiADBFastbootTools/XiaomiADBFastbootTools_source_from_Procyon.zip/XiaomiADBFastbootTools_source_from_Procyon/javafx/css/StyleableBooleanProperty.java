// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.value.ObservableValue;
import javafx.beans.property.BooleanPropertyBase;

public abstract class StyleableBooleanProperty extends BooleanPropertyBase implements StyleableProperty<Boolean>
{
    private StyleOrigin origin;
    
    public StyleableBooleanProperty() {
        this.origin = null;
    }
    
    public StyleableBooleanProperty(final boolean b) {
        super(b);
        this.origin = null;
    }
    
    @Override
    public void applyStyle(final StyleOrigin origin, final Boolean b) {
        this.set(b);
        this.origin = origin;
    }
    
    @Override
    public void bind(final ObservableValue<? extends Boolean> observableValue) {
        super.bind(observableValue);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public void set(final boolean b) {
        super.set(b);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public StyleOrigin getStyleOrigin() {
        return this.origin;
    }
}
