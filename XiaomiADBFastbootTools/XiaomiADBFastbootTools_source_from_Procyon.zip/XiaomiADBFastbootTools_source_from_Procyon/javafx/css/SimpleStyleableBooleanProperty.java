// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.NamedArg;

public class SimpleStyleableBooleanProperty extends StyleableBooleanProperty
{
    private static final Object DEFAULT_BEAN;
    private static final String DEFAULT_NAME = "";
    private final Object bean;
    private final String name;
    private final CssMetaData<? extends Styleable, Boolean> cssMetaData;
    
    public SimpleStyleableBooleanProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Boolean> cssMetaData) {
        this(cssMetaData, SimpleStyleableBooleanProperty.DEFAULT_BEAN, "");
    }
    
    public SimpleStyleableBooleanProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Boolean> cssMetaData, @NamedArg("initialValue") final boolean b) {
        this(cssMetaData, SimpleStyleableBooleanProperty.DEFAULT_BEAN, "", b);
    }
    
    public SimpleStyleableBooleanProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Boolean> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s) {
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    public SimpleStyleableBooleanProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, Boolean> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s, @NamedArg("initialValue") final boolean b) {
        super(b);
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    @Override
    public Object getBean() {
        return this.bean;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public final CssMetaData<? extends Styleable, Boolean> getCssMetaData() {
        return this.cssMetaData;
    }
    
    static {
        DEFAULT_BEAN = null;
    }
}
