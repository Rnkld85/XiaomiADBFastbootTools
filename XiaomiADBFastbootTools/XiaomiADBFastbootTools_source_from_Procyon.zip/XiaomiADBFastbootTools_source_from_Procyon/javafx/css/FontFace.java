// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

public abstract class FontFace
{
    protected FontFace() {
    }
}
