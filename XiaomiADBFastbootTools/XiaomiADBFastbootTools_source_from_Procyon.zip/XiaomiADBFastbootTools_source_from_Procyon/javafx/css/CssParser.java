// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import com.sun.javafx.util.Logging;
import com.sun.javafx.css.Combinator;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URI;
import com.sun.javafx.css.FontFaceImpl;
import java.text.MessageFormat;
import javafx.scene.text.Font;
import javafx.css.converter.FontConverter;
import com.sun.javafx.scene.layout.region.BorderImageWidthsSequenceConverter;
import com.sun.javafx.scene.layout.region.BorderImageWidthConverter;
import javafx.scene.layout.BorderWidths;
import com.sun.javafx.scene.layout.region.SliceSequenceConverter;
import com.sun.javafx.scene.layout.region.BorderImageSliceConverter;
import com.sun.javafx.scene.layout.region.BorderImageSlices;
import javafx.scene.shape.StrokeLineJoin;
import com.sun.javafx.scene.layout.region.BorderStyleConverter;
import com.sun.javafx.scene.layout.region.LayeredBorderStyleConverter;
import com.sun.javafx.scene.layout.region.BorderStrokeStyleSequenceConverter;
import javafx.scene.layout.BorderStrokeStyle;
import com.sun.javafx.scene.layout.region.LayeredBorderPaintConverter;
import com.sun.javafx.scene.layout.region.StrokeBorderPaintConverter;
import com.sun.javafx.scene.layout.region.LayeredBackgroundSizeConverter;
import com.sun.javafx.scene.layout.region.BackgroundSizeConverter;
import javafx.scene.layout.BackgroundSize;
import com.sun.javafx.scene.layout.region.RepeatStructConverter;
import com.sun.javafx.scene.layout.region.RepeatStruct;
import javafx.scene.layout.BackgroundRepeat;
import com.sun.javafx.scene.layout.region.LayeredBackgroundPositionConverter;
import com.sun.javafx.scene.layout.region.BackgroundPositionConverter;
import javafx.scene.layout.BackgroundPosition;
import com.sun.javafx.scene.layout.region.CornerRadiiConverter;
import javafx.scene.layout.CornerRadii;
import com.sun.javafx.scene.layout.region.Margins;
import javafx.geometry.Insets;
import javafx.css.converter.URLConverter;
import javafx.css.converter.StringConverter;
import javafx.scene.paint.Paint;
import javafx.scene.paint.CycleMethod;
import javafx.css.converter.EffectConverter;
import javafx.css.converter.EnumConverter;
import javafx.scene.effect.BlurType;
import java.util.Arrays;
import javafx.css.converter.StopConverter;
import javafx.scene.paint.Stop;
import javafx.css.converter.LadderConverter;
import javafx.css.converter.DeriveColorConverter;
import javafx.css.converter.BooleanConverter;
import javafx.css.converter.DurationConverter;
import javafx.scene.shape.StrokeType;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.text.FontWeight;
import javafx.scene.text.FontPosture;
import javafx.css.converter.SizeConverter;
import javafx.css.converter.InsetsConverter;
import javafx.css.converter.PaintConverter;
import java.util.Locale;
import com.sun.javafx.util.Utils;
import javafx.scene.paint.Color;
import javafx.collections.ObservableList;
import com.sun.javafx.css.StyleManager;
import java.util.List;
import java.util.Collection;
import java.util.Collections;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.io.IOException;
import java.io.Reader;
import java.io.CharArrayReader;
import java.util.HashMap;
import java.util.Stack;
import com.sun.javafx.css.parser.Token;
import com.sun.javafx.css.ParsedValueImpl;
import java.util.Map;
import com.sun.javafx.logging.PlatformLogger;

public final class CssParser
{
    private String stylesheetAsText;
    private String sourceOfStylesheet;
    private Styleable sourceOfInlineStyle;
    private static final PlatformLogger LOGGER;
    private final Map<String, String> properties;
    private static final ParsedValueImpl<Size, Size> ZERO_PERCENT;
    private static final ParsedValueImpl<Size, Size> FIFTY_PERCENT;
    private static final ParsedValueImpl<Size, Size> ONE_HUNDRED_PERCENT;
    private static final String SPECIAL_REGION_URL_PREFIX = "SPECIAL-REGION-URL:";
    Token currentToken;
    private static Stack<String> imports;
    
    public CssParser() {
        this.currentToken = null;
        this.properties = new HashMap<String, String>();
    }
    
    private void setInputSource(final String sourceOfStylesheet, final String stylesheetAsText) {
        this.stylesheetAsText = stylesheetAsText;
        this.sourceOfStylesheet = sourceOfStylesheet;
        this.sourceOfInlineStyle = null;
    }
    
    private void setInputSource(final String stylesheetAsText) {
        this.stylesheetAsText = stylesheetAsText;
        this.sourceOfStylesheet = null;
        this.sourceOfInlineStyle = null;
    }
    
    private void setInputSource(final Styleable sourceOfInlineStyle) {
        this.stylesheetAsText = ((sourceOfInlineStyle != null) ? sourceOfInlineStyle.getStyle() : null);
        this.sourceOfStylesheet = null;
        this.sourceOfInlineStyle = sourceOfInlineStyle;
    }
    
    public Stylesheet parse(final String inputSource) {
        final Stylesheet stylesheet = new Stylesheet();
        if (inputSource != null && !inputSource.trim().isEmpty()) {
            this.setInputSource(inputSource);
            try {
                final CharArrayReader charArrayReader = new CharArrayReader(inputSource.toCharArray());
                try {
                    this.parse(stylesheet, charArrayReader);
                    charArrayReader.close();
                }
                catch (Throwable t) {
                    try {
                        charArrayReader.close();
                    }
                    catch (Throwable exception) {
                        t.addSuppressed(exception);
                    }
                    throw t;
                }
            }
            catch (IOException ex) {}
        }
        return stylesheet;
    }
    
    public Stylesheet parse(final String s, final String s2) throws IOException {
        final Stylesheet stylesheet = new Stylesheet(s);
        if (s2 != null && !s2.trim().isEmpty()) {
            this.setInputSource(s, s2);
            final CharArrayReader charArrayReader = new CharArrayReader(s2.toCharArray());
            try {
                this.parse(stylesheet, charArrayReader);
                charArrayReader.close();
            }
            catch (Throwable t) {
                try {
                    charArrayReader.close();
                }
                catch (Throwable exception) {
                    t.addSuppressed(exception);
                }
                throw t;
            }
        }
        return stylesheet;
    }
    
    public Stylesheet parse(final URL url) throws IOException {
        final String s = (url != null) ? url.toExternalForm() : null;
        final Stylesheet stylesheet = new Stylesheet(s);
        if (url != null) {
            this.setInputSource(s, null);
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(url.openStream()));
            try {
                this.parse(stylesheet, bufferedReader);
                bufferedReader.close();
            }
            catch (Throwable t) {
                try {
                    bufferedReader.close();
                }
                catch (Throwable exception) {
                    t.addSuppressed(exception);
                }
                throw t;
            }
        }
        return stylesheet;
    }
    
    private void parse(final Stylesheet stylesheet, final Reader reader) {
        final CssLexer cssLexer = new CssLexer();
        cssLexer.setReader(reader);
        try {
            this.parse(stylesheet, cssLexer);
        }
        catch (Exception ex) {
            this.reportException(ex);
        }
    }
    
    public Stylesheet parseInlineStyle(final Styleable inputSource) {
        final Stylesheet stylesheet = new Stylesheet();
        final String s = (inputSource != null) ? inputSource.getStyle() : null;
        if (s != null && !s.trim().isEmpty()) {
            this.setInputSource(inputSource);
            final ArrayList<Rule> list = new ArrayList<Rule>();
            try {
                final CharArrayReader reader = new CharArrayReader(s.toCharArray());
                try {
                    final CssLexer cssLexer = new CssLexer();
                    cssLexer.setReader(reader);
                    this.currentToken = this.nextToken(cssLexer);
                    final List<Declaration> declarations = this.declarations(cssLexer);
                    if (declarations != null && !declarations.isEmpty()) {
                        list.add(new Rule(Collections.singletonList(Selector.getUniversalSelector()), declarations));
                    }
                    reader.close();
                }
                catch (Throwable t) {
                    try {
                        reader.close();
                    }
                    catch (Throwable exception) {
                        t.addSuppressed(exception);
                    }
                    throw t;
                }
            }
            catch (IOException ex2) {}
            catch (Exception ex) {
                this.reportException(ex);
            }
            stylesheet.getRules().addAll(list);
        }
        this.setInputSource((Styleable)null);
        return stylesheet;
    }
    
    ParsedValue parseExpr(final String s, final String s2) {
        if (s == null || s2 == null) {
            return null;
        }
        ParsedValue value = null;
        this.setInputSource((String)null, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, s2));
        final char[] buf = new char[s2.length() + 1];
        System.arraycopy(s2.toCharArray(), 0, buf, 0, s2.length());
        buf[buf.length - 1] = ';';
        try {
            final CharArrayReader reader = new CharArrayReader(buf);
            try {
                final CssLexer cssLexer = new CssLexer();
                cssLexer.setReader(reader);
                this.currentToken = this.nextToken(cssLexer);
                value = this.valueFor(s, this.expr(cssLexer), cssLexer);
                reader.close();
            }
            catch (Throwable t) {
                try {
                    reader.close();
                }
                catch (Throwable exception) {
                    t.addSuppressed(exception);
                }
                throw t;
            }
        }
        catch (IOException ex3) {}
        catch (ParseException ex) {
            if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                CssParser.LOGGER.warning(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, s2, ex.toString()));
            }
        }
        catch (Exception ex2) {
            this.reportException(ex2);
        }
        return value;
    }
    
    private ParseError createError(final String s) {
        ParseError parseError;
        if (this.sourceOfStylesheet != null) {
            parseError = new ParseError.StylesheetParsingError(this.sourceOfStylesheet, s);
        }
        else if (this.sourceOfInlineStyle != null) {
            parseError = new ParseError.InlineStyleParsingError(this.sourceOfInlineStyle, s);
        }
        else {
            parseError = new ParseError.StringParsingError(this.stylesheetAsText, s);
        }
        return parseError;
    }
    
    private void reportError(final ParseError parseError) {
        final ObservableList<ParseError> errors;
        if ((errors = StyleManager.getErrors()) != null) {
            errors.add(parseError);
        }
    }
    
    private void error(final Term term, final String s) throws ParseException {
        final ParseException ex = new ParseException(s, (term != null) ? term.token : null, this);
        this.reportError(this.createError(ex.toString()));
        throw ex;
    }
    
    private void reportException(final Exception ex) {
        if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
            final StackTraceElement[] stackTrace = ex.getStackTrace();
            if (stackTrace.length > 0) {
                final StringBuilder sb = new StringBuilder("Please report ");
                sb.append(ex.getClass().getName()).append(" at:");
                int n = 0;
                while (n < stackTrace.length && this.getClass().getName().equals(stackTrace[n].getClassName())) {
                    sb.append("\n\t").append(stackTrace[n++].toString());
                }
                CssParser.LOGGER.warning(sb.toString());
            }
        }
    }
    
    private String formatDeprecatedMessage(final Term term, final String str) {
        final StringBuilder sb = new StringBuilder("Using deprecated syntax for ");
        sb.append(str);
        if (this.sourceOfStylesheet != null) {
            sb.append(" at ").append(this.sourceOfStylesheet).append("[").append(term.token.getLine()).append(',').append(term.token.getOffset()).append("]");
        }
        sb.append(". Refer to the CSS Reference Guide.");
        return sb.toString();
    }
    
    private ParsedValueImpl<Color, Color> colorValueOfString(final String s) {
        if (s.startsWith("#") || s.startsWith("0x")) {
            double n = 1.0;
            String s2 = s;
            final int n2 = s.startsWith("#") ? 1 : 2;
            final int length = s2.length();
            if (length - n2 == 4) {
                n = Integer.parseInt(s2.substring(length - 1), 16) / 15.0f;
                s2 = s2.substring(0, length - 1);
            }
            else if (length - n2 == 8) {
                n = Integer.parseInt(s2.substring(length - 2), 16) / 255.0f;
                s2 = s2.substring(0, length - 2);
            }
            return new ParsedValueImpl<Color, Color>(Color.web(s2, n), null);
        }
        try {
            return new ParsedValueImpl<Color, Color>(Color.web(s), null);
        }
        catch (IllegalArgumentException ex) {}
        catch (NullPointerException ex2) {}
        return null;
    }
    
    private String stripQuotes(final String s) {
        return Utils.stripQuotes(s);
    }
    
    private double clamp(final double n, final double n2, final double n3) {
        if (n2 < n) {
            return n;
        }
        if (n3 < n2) {
            return n3;
        }
        return n2;
    }
    
    private boolean isSize(final Token token) {
        switch (token.getType()) {
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26: {
                return true;
            }
            default: {
                return token.getType() == 11;
            }
        }
    }
    
    private Size size(final Token token) throws ParseException {
        final SizeUnits px = SizeUnits.PX;
        int n = 2;
        final String trim = token.getText().trim();
        final int length = trim.length();
        SizeUnits sizeUnits = null;
        switch (token.getType()) {
            case 13: {
                sizeUnits = SizeUnits.PX;
                n = 0;
                break;
            }
            case 22: {
                sizeUnits = SizeUnits.PERCENT;
                n = 1;
                break;
            }
            case 15: {
                sizeUnits = SizeUnits.EM;
                break;
            }
            case 16: {
                sizeUnits = SizeUnits.EX;
                break;
            }
            case 21: {
                sizeUnits = SizeUnits.PX;
                break;
            }
            case 14: {
                sizeUnits = SizeUnits.CM;
                break;
            }
            case 18: {
                sizeUnits = SizeUnits.MM;
                break;
            }
            case 17: {
                sizeUnits = SizeUnits.IN;
                break;
            }
            case 20: {
                sizeUnits = SizeUnits.PT;
                break;
            }
            case 19: {
                sizeUnits = SizeUnits.PC;
                break;
            }
            case 23: {
                sizeUnits = SizeUnits.DEG;
                n = 3;
                break;
            }
            case 24: {
                sizeUnits = SizeUnits.GRAD;
                n = 4;
                break;
            }
            case 25: {
                sizeUnits = SizeUnits.RAD;
                n = 3;
                break;
            }
            case 26: {
                sizeUnits = SizeUnits.TURN;
                n = 4;
                break;
            }
            case 45: {
                sizeUnits = SizeUnits.S;
                n = 1;
                break;
            }
            case 46: {
                sizeUnits = SizeUnits.MS;
                break;
            }
            default: {
                if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.FINEST)) {
                    CssParser.LOGGER.finest("Expected '<number>'");
                }
                final ParseException ex = new ParseException("Expected '<number>'", token, this);
                this.reportError(this.createError(ex.toString()));
                throw ex;
            }
        }
        return new Size(Double.parseDouble(trim.substring(0, length - n)), sizeUnits);
    }
    
    private int numberOfTerms(final Term term) {
        if (term == null) {
            return 0;
        }
        int n = 0;
        Term nextInSeries = term;
        do {
            ++n;
            nextInSeries = nextInSeries.nextInSeries;
        } while (nextInSeries != null);
        return n;
    }
    
    private int numberOfLayers(final Term term) {
        if (term == null) {
            return 0;
        }
        int n = 0;
        Term term2 = term;
        do {
            ++n;
            while (term2.nextInSeries != null) {
                term2 = term2.nextInSeries;
            }
            term2 = term2.nextLayer;
        } while (term2 != null);
        return n;
    }
    
    private int numberOfArgs(final Term term) {
        if (term == null) {
            return 0;
        }
        int n = 0;
        for (Term term2 = term.firstArg; term2 != null; term2 = term2.nextArg) {
            ++n;
        }
        return n;
    }
    
    private Term nextLayer(final Term term) {
        if (term == null) {
            return null;
        }
        Term nextInSeries;
        for (nextInSeries = term; nextInSeries.nextInSeries != null; nextInSeries = nextInSeries.nextInSeries) {}
        return nextInSeries.nextLayer;
    }
    
    ParsedValueImpl valueFor(final String s, final Term term, final CssLexer cssLexer) throws ParseException {
        final String lowerCase = s.toLowerCase(Locale.ROOT);
        this.properties.put(lowerCase, lowerCase);
        if (term == null || term.token == null) {
            this.error(term, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, lowerCase));
        }
        if (term.token.getType() == 11) {
            final String text = term.token.getText();
            if ("inherit".equalsIgnoreCase(text)) {
                return new ParsedValueImpl((V)"inherit", null);
            }
            if ("null".equalsIgnoreCase(text) || "none".equalsIgnoreCase(text)) {
                return new ParsedValueImpl((V)"null", null);
            }
        }
        if ("-fx-fill".equals(lowerCase)) {
            ParsedValueImpl<Object, Object> parse = (ParsedValueImpl<Object, Object>)this.parse(term);
            if (parse.getConverter() == StyleConverter.getUrlConverter()) {
                parse = new ParsedValueImpl<Object, Object>(new ParsedValue[] { parse }, (StyleConverter<Object, Object>)PaintConverter.ImagePatternConverter.getInstance());
            }
            return parse;
        }
        if ("-fx-background-color".equals(lowerCase)) {
            return this.parsePaintLayers(term);
        }
        if ("-fx-background-image".equals(lowerCase)) {
            return this.parseURILayers(term);
        }
        if ("-fx-background-insets".equals(lowerCase)) {
            return this.parseInsetsLayers(term);
        }
        if ("-fx-opaque-insets".equals(lowerCase)) {
            return this.parseInsetsLayer(term);
        }
        if ("-fx-background-position".equals(lowerCase)) {
            return this.parseBackgroundPositionLayers(term);
        }
        if ("-fx-background-radius".equals(lowerCase)) {
            return this.parseCornerRadius(term);
        }
        if ("-fx-background-repeat".equals(lowerCase)) {
            return this.parseBackgroundRepeatStyleLayers(term);
        }
        if ("-fx-background-size".equals(lowerCase)) {
            return this.parseBackgroundSizeLayers(term);
        }
        if ("-fx-border-color".equals(lowerCase)) {
            return this.parseBorderPaintLayers(term);
        }
        if ("-fx-border-insets".equals(lowerCase)) {
            return this.parseInsetsLayers(term);
        }
        if ("-fx-border-radius".equals(lowerCase)) {
            return this.parseCornerRadius(term);
        }
        if ("-fx-border-style".equals(lowerCase)) {
            return this.parseBorderStyleLayers(term);
        }
        if ("-fx-border-width".equals(lowerCase)) {
            return this.parseMarginsLayers(term);
        }
        if ("-fx-border-image-insets".equals(lowerCase)) {
            return this.parseInsetsLayers(term);
        }
        if ("-fx-border-image-repeat".equals(lowerCase)) {
            return this.parseBorderImageRepeatStyleLayers(term);
        }
        if ("-fx-border-image-slice".equals(lowerCase)) {
            return this.parseBorderImageSliceLayers(term);
        }
        if ("-fx-border-image-source".equals(lowerCase)) {
            return this.parseURILayers(term);
        }
        if ("-fx-border-image-width".equals(lowerCase)) {
            return this.parseBorderImageWidthLayers(term);
        }
        if ("-fx-padding".equals(lowerCase)) {
            return new ParsedValueImpl((V)(Object)this.parseSize1to4(term), (StyleConverter<V, T>)InsetsConverter.getInstance());
        }
        if ("-fx-label-padding".equals(lowerCase)) {
            return new ParsedValueImpl((V)(Object)this.parseSize1to4(term), (StyleConverter<V, T>)InsetsConverter.getInstance());
        }
        if (lowerCase.endsWith("font-family")) {
            return this.parseFontFamily(term);
        }
        if (lowerCase.endsWith("font-size")) {
            final ParsedValueImpl<ParsedValue<?, Size>, Number> fontSize = this.parseFontSize(term);
            if (fontSize == null) {
                this.error(term, "Expected '<font-size>'");
            }
            return fontSize;
        }
        if (lowerCase.endsWith("font-style")) {
            final ParsedValueImpl<String, FontPosture> fontStyle = this.parseFontStyle(term);
            if (fontStyle == null) {
                this.error(term, "Expected '<font-style>'");
            }
            return fontStyle;
        }
        if (lowerCase.endsWith("font-weight")) {
            final ParsedValueImpl<String, FontWeight> fontWeight = this.parseFontWeight(term);
            if (fontWeight == null) {
                this.error(term, "Expected '<font-style>'");
            }
            return fontWeight;
        }
        if (lowerCase.endsWith("font")) {
            return this.parseFont(term);
        }
        if ("-fx-stroke-dash-array".equals(lowerCase)) {
            Term nextInSeries = term;
            final ParsedValueImpl[] array = new ParsedValueImpl[this.numberOfTerms(nextInSeries)];
            int n = 0;
            while (nextInSeries != null) {
                array[n++] = this.parseSize(nextInSeries);
                nextInSeries = nextInSeries.nextInSeries;
            }
            return new ParsedValueImpl(array, (StyleConverter<Object, Object>)SizeConverter.SequenceConverter.getInstance());
        }
        if ("-fx-stroke-line-join".equals(lowerCase)) {
            final ParsedValueImpl[] strokeLineJoin = this.parseStrokeLineJoin(term);
            if (strokeLineJoin == null) {
                this.error(term, "Expected 'miter', 'bevel' or 'round'");
            }
            return strokeLineJoin[0];
        }
        if ("-fx-stroke-line-cap".equals(lowerCase)) {
            final ParsedValueImpl<String, StrokeLineCap> strokeLineCap = this.parseStrokeLineCap(term);
            if (strokeLineCap == null) {
                this.error(term, "Expected 'square', 'butt' or 'round'");
            }
            return strokeLineCap;
        }
        if ("-fx-stroke-type".equals(lowerCase)) {
            final ParsedValueImpl<String, StrokeType> strokeType = this.parseStrokeType(term);
            if (strokeType == null) {
                this.error(term, "Expected 'centered', 'inside' or 'outside'");
            }
            return strokeType;
        }
        if ("-fx-font-smoothing-type".equals(lowerCase)) {
            String text2 = null;
            final Token token = term.token;
            final int type;
            if (term.token == null || ((type = term.token.getType()) != 10 && type != 11) || (text2 = term.token.getText()) == null || text2.isEmpty()) {
                this.error(term, "Expected STRING or IDENT");
            }
            return new ParsedValueImpl(this.stripQuotes(text2), null, false);
        }
        return this.parse(term);
    }
    
    private ParsedValueImpl parse(final Term term) throws ParseException {
        if (term.token == null) {
            this.error(term, "Parse error");
        }
        final Token token = term.token;
        Object o = null;
        final int type = token.getType();
        switch (type) {
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26: {
                if (term.nextInSeries == null) {
                    o = new ParsedValueImpl(new ParsedValueImpl(this.size(token), null), (StyleConverter<Object, Object>)SizeConverter.getInstance());
                    break;
                }
                o = new ParsedValueImpl(this.parseSizeSeries(term), (StyleConverter<Object, Object>)SizeConverter.SequenceConverter.getInstance());
                break;
            }
            case 45:
            case 46: {
                o = new ParsedValueImpl(new ParsedValueImpl(this.size(token), null), (StyleConverter<Object, Object>)DurationConverter.getInstance());
                break;
            }
            case 10:
            case 11: {
                final boolean b = type == 11;
                final String stripQuotes = this.stripQuotes(token.getText());
                final String lowerCase = stripQuotes.toLowerCase(Locale.ROOT);
                if ("ladder".equals(lowerCase)) {
                    o = this.ladder(term);
                    break;
                }
                if ("linear".equals(lowerCase) && term.nextInSeries != null) {
                    o = this.linearGradient(term);
                    break;
                }
                if ("radial".equals(lowerCase) && term.nextInSeries != null) {
                    o = this.radialGradient(term);
                    break;
                }
                if ("infinity".equals(lowerCase)) {
                    o = new ParsedValueImpl(new ParsedValueImpl(new Size(Double.MAX_VALUE, SizeUnits.PX), null), (StyleConverter<Object, Object>)SizeConverter.getInstance());
                    break;
                }
                if ("indefinite".equals(lowerCase)) {
                    o = new ParsedValueImpl(new ParsedValueImpl(new Size(Double.POSITIVE_INFINITY, SizeUnits.PX), null), (StyleConverter<Object, Object>)DurationConverter.getInstance());
                    break;
                }
                if ("true".equals(lowerCase)) {
                    o = new ParsedValueImpl("true", (StyleConverter<Object, Object>)BooleanConverter.getInstance());
                    break;
                }
                if ("false".equals(lowerCase)) {
                    o = new ParsedValueImpl("false", (StyleConverter<Object, Object>)BooleanConverter.getInstance());
                    break;
                }
                final boolean b2 = b && this.properties.containsKey(lowerCase);
                if (b2 || (o = this.colorValueOfString(stripQuotes)) == null) {
                    o = new ParsedValueImpl(b2 ? lowerCase : stripQuotes, null, b || b2);
                }
                break;
            }
            case 37: {
                final String text = token.getText();
                try {
                    o = new ParsedValueImpl(Color.web(text), null);
                }
                catch (IllegalArgumentException ex) {
                    this.error(term, ex.getMessage());
                }
                break;
            }
            case 12: {
                return this.parseFunction(term);
            }
            case 43: {
                return this.parseURI(term);
            }
            default: {
                this.error(term, invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, type));
                break;
            }
        }
        return (ParsedValueImpl)o;
    }
    
    private ParsedValueImpl<?, Size> parseSize(final Term term) throws ParseException {
        if (term.token == null || !this.isSize(term.token)) {
            this.error(term, "Expected '<size>'");
        }
        ParsedValueImpl<Object, Size> parsedValueImpl;
        if (term.token.getType() != 11) {
            parsedValueImpl = new ParsedValueImpl<Object, Size>(this.size(term.token), null);
        }
        else {
            parsedValueImpl = new ParsedValueImpl<Object, Size>(term.token.getText(), null, true);
        }
        return parsedValueImpl;
    }
    
    private ParsedValueImpl<?, Color> parseColor(final Term term) throws ParseException {
        ParsedValueImpl<?, Color> parse = null;
        if (term.token != null && (term.token.getType() == 11 || term.token.getType() == 37 || term.token.getType() == 12)) {
            parse = (ParsedValueImpl<?, Color>)this.parse(term);
        }
        else {
            this.error(term, "Expected '<color>'");
        }
        return parse;
    }
    
    private ParsedValueImpl rgb(Term term) throws ParseException {
        final String other = (term.token != null) ? term.token.getText() : null;
        if (other == null || !"rgb".regionMatches(true, 0, other, 0, 3)) {
            this.error(term, "Expected 'rgb' or 'rgba'");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null) {
            this.error(term, "Expected '<number>' or '<percentage>'");
        }
        final Token token;
        if ((token = firstArg.token) == null || (token.getType() != 13 && token.getType() != 22)) {
            this.error(firstArg, "Expected '<number>' or '<percentage>'");
        }
        term = firstArg;
        final Term nextArg;
        if ((nextArg = firstArg.nextArg) == null) {
            this.error(term, "Expected '<number>' or '<percentage>'");
        }
        final Token token2;
        if ((token2 = nextArg.token) == null || (token2.getType() != 13 && token2.getType() != 22)) {
            this.error(nextArg, "Expected '<number>' or '<percentage>'");
        }
        term = nextArg;
        final Term nextArg2;
        if ((nextArg2 = nextArg.nextArg) == null) {
            this.error(term, "Expected '<number>' or '<percentage>'");
        }
        final Token token3;
        if ((token3 = nextArg2.token) == null || (token3.getType() != 13 && token3.getType() != 22)) {
            this.error(nextArg2, "Expected '<number>' or '<percentage>'");
        }
        term = nextArg2;
        final Term nextArg3;
        Token token4;
        if ((nextArg3 = nextArg2.nextArg) != null) {
            if ((token4 = nextArg3.token) == null || token4.getType() != 13) {
                this.error(nextArg3, "Expected '<number>'");
            }
        }
        else {
            token4 = null;
        }
        final int type = token.getType();
        if (type != token2.getType() || type != token3.getType() || (type != 13 && type != 22)) {
            this.error(term, "Argument type mistmatch");
        }
        final String text = token.getText();
        final String text2 = token2.getText();
        final String text3 = token3.getText();
        double n;
        double n2;
        double n3;
        if (type == 13) {
            n = this.clamp(0.0, Double.parseDouble(text) / 255.0, 1.0);
            n2 = this.clamp(0.0, Double.parseDouble(text2) / 255.0, 1.0);
            n3 = this.clamp(0.0, Double.parseDouble(text3) / 255.0, 1.0);
        }
        else {
            n = this.clamp(0.0, Double.parseDouble(text.substring(0, text.length() - 1)) / 100.0, 1.0);
            n2 = this.clamp(0.0, Double.parseDouble(text2.substring(0, text2.length() - 1)) / 100.0, 1.0);
            n3 = this.clamp(0.0, Double.parseDouble(text3.substring(0, text3.length() - 1)) / 100.0, 1.0);
        }
        final String s = (token4 != null) ? token4.getText() : null;
        return new ParsedValueImpl(Color.color(n, n2, n3, (s != null) ? this.clamp(0.0, Double.parseDouble(s), 1.0) : 1.0), null);
    }
    
    private ParsedValueImpl hsb(Term term) throws ParseException {
        final String other = (term.token != null) ? term.token.getText() : null;
        if (other == null || !"hsb".regionMatches(true, 0, other, 0, 3)) {
            this.error(term, "Expected 'hsb' or 'hsba'");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null) {
            this.error(term, "Expected '<number>'");
        }
        final Token token;
        if ((token = firstArg.token) == null || token.getType() != 13) {
            this.error(firstArg, "Expected '<number>'");
        }
        term = firstArg;
        final Term nextArg;
        if ((nextArg = firstArg.nextArg) == null) {
            this.error(term, "Expected '<percent>'");
        }
        final Token token2;
        if ((token2 = nextArg.token) == null || token2.getType() != 22) {
            this.error(nextArg, "Expected '<percent>'");
        }
        term = nextArg;
        final Term nextArg2;
        if ((nextArg2 = nextArg.nextArg) == null) {
            this.error(term, "Expected '<percent>'");
        }
        final Token token3;
        if ((token3 = nextArg2.token) == null || token3.getType() != 22) {
            this.error(nextArg2, "Expected '<percent>'");
        }
        term = nextArg2;
        final Term nextArg3;
        Token token4;
        if ((nextArg3 = nextArg2.nextArg) != null) {
            if ((token4 = nextArg3.token) == null || token4.getType() != 13) {
                this.error(nextArg3, "Expected '<number>'");
            }
        }
        else {
            token4 = null;
        }
        final Size size = this.size(token);
        final Size size2 = this.size(token2);
        final Size size3 = this.size(token3);
        final double pixels = size.pixels();
        final double clamp = this.clamp(0.0, size2.pixels(), 1.0);
        final double clamp2 = this.clamp(0.0, size3.pixels(), 1.0);
        final Size size4 = (token4 != null) ? this.size(token4) : null;
        return new ParsedValueImpl(Color.hsb(pixels, clamp, clamp2, (size4 != null) ? this.clamp(0.0, size4.pixels(), 1.0) : 1.0), null);
    }
    
    private ParsedValueImpl<ParsedValue[], Color> derive(final Term term) throws ParseException {
        final String other = (term.token != null) ? term.token.getText() : null;
        if (other == null || !"derive".regionMatches(true, 0, other, 0, 6)) {
            this.error(term, "Expected 'derive'");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null) {
            this.error(term, "Expected '<color>'");
        }
        final ParsedValueImpl<?, Color> color = this.parseColor(firstArg);
        final Term term2 = firstArg;
        final Term nextArg;
        if ((nextArg = firstArg.nextArg) == null) {
            this.error(term2, "Expected '<percent'");
        }
        return new ParsedValueImpl<ParsedValue[], Color>(new ParsedValueImpl[] { color, this.parseSize(nextArg) }, (StyleConverter<Object, Object>)DeriveColorConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], Color> ladder(final Term term) throws ParseException {
        final String other = (term.token != null) ? term.token.getText() : null;
        if (other == null || !"ladder".regionMatches(true, 0, other, 0, 6)) {
            this.error(term, "Expected 'ladder'");
        }
        if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
            CssParser.LOGGER.warning(this.formatDeprecatedMessage(term, "ladder"));
        }
        final Term nextInSeries;
        if ((nextInSeries = term.nextInSeries) == null) {
            this.error(term, "Expected '<color>'");
        }
        final ParsedValueImpl parse = this.parse(nextInSeries);
        final Term term2 = nextInSeries;
        final Term nextInSeries2;
        if ((nextInSeries2 = nextInSeries.nextInSeries) == null) {
            this.error(term2, "Expected 'stops'");
        }
        if (nextInSeries2.token == null || nextInSeries2.token.getType() != 11 || !"stops".equalsIgnoreCase(nextInSeries2.token.getText())) {
            this.error(nextInSeries2, "Expected 'stops'");
        }
        final Term term3 = nextInSeries2;
        Term nextInSeries3;
        if ((nextInSeries3 = nextInSeries2.nextInSeries) == null) {
            this.error(term3, "Expected '(<number>, <color>)'");
        }
        int n = 0;
        Term nextInSeries4 = nextInSeries3;
        do {
            ++n;
        } while ((nextInSeries4 = nextInSeries4.nextInSeries) != null && nextInSeries4.token != null && nextInSeries4.token.getType() == 34);
        final ParsedValueImpl[] array = new ParsedValueImpl[n + 1];
        array[0] = parse;
        int n2 = 1;
        Term term4;
        do {
            final ParsedValueImpl<ParsedValue[], Stop> stop = this.stop(nextInSeries3);
            if (stop != null) {
                array[n2++] = stop;
            }
            term4 = nextInSeries3;
        } while ((nextInSeries3 = nextInSeries3.nextInSeries) != null && nextInSeries3.token.getType() == 34);
        if (nextInSeries3 != null) {
            term.nextInSeries = nextInSeries3;
        }
        else {
            term.nextInSeries = null;
            term.nextLayer = term4.nextLayer;
        }
        return new ParsedValueImpl<ParsedValue[], Color>(array, (StyleConverter<Object, Object>)LadderConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], Color> parseLadder(final Term term) throws ParseException {
        final String other = (term.token != null) ? term.token.getText() : null;
        if (other == null || !"ladder".regionMatches(true, 0, other, 0, 6)) {
            this.error(term, "Expected 'ladder'");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null) {
            this.error(term, "Expected '<color>'");
        }
        final ParsedValueImpl parse = this.parse(firstArg);
        final Term term2 = firstArg;
        final Term nextArg;
        if ((nextArg = firstArg.nextArg) == null) {
            this.error(term2, "Expected '<color-stop>[, <color-stop>]+'");
        }
        final ParsedValueImpl<ParsedValue[], Stop>[] colorStops = this.parseColorStops(nextArg);
        final ParsedValueImpl[] array = new ParsedValueImpl[colorStops.length + 1];
        array[0] = parse;
        System.arraycopy(colorStops, 0, array, 1, colorStops.length);
        return new ParsedValueImpl<ParsedValue[], Color>(array, (StyleConverter<Object, Object>)LadderConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], Stop> stop(final Term term) throws ParseException {
        final String anObject = (term.token != null) ? term.token.getText() : null;
        if (anObject == null || !"(".equals(anObject)) {
            this.error(term, "Expected '('");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null) {
            this.error(term, "Expected '<number>'");
        }
        final ParsedValueImpl<?, Size> size = this.parseSize(firstArg);
        final Term term2 = firstArg;
        final Term nextArg;
        if ((nextArg = firstArg.nextArg) == null) {
            this.error(term2, "Expected '<color>'");
        }
        return new ParsedValueImpl<ParsedValue[], Stop>(new ParsedValueImpl[] { size, this.parseColor(nextArg) }, (StyleConverter<Object, Object>)StopConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], Stop>[] parseColorStops(final Term term) throws ParseException {
        int n = 1;
        Term term2 = term;
        while (term2 != null) {
            if (term2.nextArg != null) {
                ++n;
                term2 = term2.nextArg;
            }
            else {
                if (term2.nextInSeries == null) {
                    break;
                }
                term2 = term2.nextInSeries;
            }
        }
        if (n < 2) {
            this.error(term, "Expected '<color-stop>'");
        }
        final ParsedValueImpl[] array = new ParsedValueImpl[n];
        final Size[] a = new Size[n];
        Arrays.fill(a, null);
        Term term3 = term;
        final SizeUnits sizeUnits = null;
        for (int i = 0; i < n; ++i) {
            array[i] = this.parseColor(term3);
            final Term term4 = term3;
            final Term nextInSeries = term3.nextInSeries;
            if (nextInSeries != null) {
                if (this.isSize(nextInSeries.token)) {
                    a[i] = this.size(nextInSeries.token);
                    if (sizeUnits != null && sizeUnits != a[i].getUnits()) {
                        this.error(nextInSeries, "Parser unable to handle mixed '<percent>' and '<length>'");
                    }
                }
                else {
                    this.error(term4, "Expected '<percent>' or '<length>'");
                }
                term3 = nextInSeries.nextArg;
            }
            else {
                term3 = term3.nextArg;
            }
        }
        if (a[0] == null) {
            a[0] = new Size(0.0, SizeUnits.PERCENT);
        }
        if (a[n - 1] == null) {
            a[n - 1] = new Size(100.0, SizeUnits.PERCENT);
        }
        Size size = null;
        for (int j = 1; j < n; ++j) {
            final Size size2 = a[j - 1];
            if (size2 != null) {
                if (size == null || size.getValue() < size2.getValue()) {
                    size = size2;
                }
                final Size size3 = a[j];
                if (size3 != null) {
                    if (size3.getValue() < size.getValue()) {
                        a[j] = size;
                    }
                }
            }
        }
        Size size4 = null;
        int k = -1;
        for (int l = 0; l < n; ++l) {
            final Size size5 = a[l];
            if (size5 == null) {
                if (k == -1) {
                    k = l;
                }
            }
            else if (k > -1) {
                final int n2 = l - k;
                double value = size4.getValue();
                final double n3 = (size5.getValue() - value) / (n2 + 1);
                while (k < l) {
                    value += n3;
                    a[k++] = new Size(value, size5.getUnits());
                }
                k = -1;
                size4 = size5;
            }
            else {
                size4 = size5;
            }
        }
        final ParsedValueImpl[] array2 = new ParsedValueImpl[n];
        for (int n4 = 0; n4 < n; ++n4) {
            array2[n4] = new ParsedValueImpl<ParsedValue[], Stop>(new ParsedValueImpl[] { new ParsedValueImpl(a[n4], null), array[n4] }, (StyleConverter<Object, Object>)StopConverter.getInstance());
        }
        return (ParsedValueImpl<ParsedValue[], Stop>[])array2;
    }
    
    private ParsedValueImpl[] point(final Term term) throws ParseException {
        if (term.token == null || term.token.getType() != 34) {
            this.error(term, "Expected '(<number>, <number>)'");
        }
        final String text = term.token.getText();
        if (text == null || !"(".equalsIgnoreCase(text)) {
            this.error(term, "Expected '('");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null) {
            this.error(term, "Expected '<number>'");
        }
        final ParsedValueImpl<?, Size> size = this.parseSize(firstArg);
        final Term term2 = firstArg;
        final Term nextArg;
        if ((nextArg = firstArg.nextArg) == null) {
            this.error(term2, "Expected '<number>'");
        }
        return new ParsedValueImpl[] { size, this.parseSize(nextArg) };
    }
    
    private ParsedValueImpl parseFunction(final Term term) throws ParseException {
        final String other = (term.token != null) ? term.token.getText() : null;
        if (other == null) {
            this.error(term, "Expected function name");
        }
        else {
            if ("rgb".regionMatches(true, 0, other, 0, 3)) {
                return this.rgb(term);
            }
            if ("hsb".regionMatches(true, 0, other, 0, 3)) {
                return this.hsb(term);
            }
            if ("derive".regionMatches(true, 0, other, 0, 6)) {
                return this.derive(term);
            }
            if ("innershadow".regionMatches(true, 0, other, 0, 11)) {
                return this.innershadow(term);
            }
            if ("dropshadow".regionMatches(true, 0, other, 0, 10)) {
                return this.dropshadow(term);
            }
            if ("linear-gradient".regionMatches(true, 0, other, 0, 15)) {
                return this.parseLinearGradient(term);
            }
            if ("radial-gradient".regionMatches(true, 0, other, 0, 15)) {
                return this.parseRadialGradient(term);
            }
            if ("image-pattern".regionMatches(true, 0, other, 0, 13)) {
                return this.parseImagePattern(term);
            }
            if ("repeating-image-pattern".regionMatches(true, 0, other, 0, 23)) {
                return this.parseRepeatingImagePattern(term);
            }
            if ("ladder".regionMatches(true, 0, other, 0, 6)) {
                return this.parseLadder(term);
            }
            if ("region".regionMatches(true, 0, other, 0, 6)) {
                return this.parseRegion(term);
            }
            this.error(term, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, other));
        }
        return null;
    }
    
    private ParsedValueImpl<String, BlurType> blurType(final Term term) throws ParseException {
        if (term == null) {
            return null;
        }
        if (term.token == null || term.token.getType() != 11 || term.token.getText() == null || term.token.getText().isEmpty()) {
            this.error(term, "Expected 'gaussian', 'one-pass-box', 'two-pass-box', or 'three-pass-box'");
        }
        final String lowerCase = term.token.getText().toLowerCase(Locale.ROOT);
        BlurType blurType = BlurType.THREE_PASS_BOX;
        if ("gaussian".equals(lowerCase)) {
            blurType = BlurType.GAUSSIAN;
        }
        else if ("one-pass-box".equals(lowerCase)) {
            blurType = BlurType.ONE_PASS_BOX;
        }
        else if ("two-pass-box".equals(lowerCase)) {
            blurType = BlurType.TWO_PASS_BOX;
        }
        else if ("three-pass-box".equals(lowerCase)) {
            blurType = BlurType.THREE_PASS_BOX;
        }
        else {
            this.error(term, "Expected 'gaussian', 'one-pass-box', 'two-pass-box', or 'three-pass-box'");
        }
        return new ParsedValueImpl<String, BlurType>(blurType.name(), (StyleConverter<Object, Object>)new EnumConverter((Class<Enum>)BlurType.class));
    }
    
    private ParsedValueImpl innershadow(final Term term) throws ParseException {
        if (!"innershadow".regionMatches(true, 0, (term.token != null) ? term.token.getText() : null, 0, 11)) {
            this.error(term, "Expected 'innershadow'");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null) {
            this.error(term, "Expected '<blur-type>'");
        }
        final ParsedValueImpl<String, BlurType> blurType = this.blurType(firstArg);
        final Term term2 = firstArg;
        final Term nextArg;
        if ((nextArg = firstArg.nextArg) == null) {
            this.error(term2, "Expected '<color>'");
        }
        final ParsedValueImpl<?, Color> color = this.parseColor(nextArg);
        final Term term3 = nextArg;
        final Term nextArg2;
        if ((nextArg2 = nextArg.nextArg) == null) {
            this.error(term3, "Expected '<number>'");
        }
        final ParsedValueImpl<?, Size> size = this.parseSize(nextArg2);
        final Term term4 = nextArg2;
        final Term nextArg3;
        if ((nextArg3 = nextArg2.nextArg) == null) {
            this.error(term4, "Expected '<number>'");
        }
        final ParsedValueImpl<?, Size> size2 = this.parseSize(nextArg3);
        final Term term5 = nextArg3;
        final Term nextArg4;
        if ((nextArg4 = nextArg3.nextArg) == null) {
            this.error(term5, "Expected '<number>'");
        }
        final ParsedValueImpl<?, Size> size3 = this.parseSize(nextArg4);
        final Term term6 = nextArg4;
        final Term nextArg5;
        if ((nextArg5 = nextArg4.nextArg) == null) {
            this.error(term6, "Expected '<number>'");
        }
        return new ParsedValueImpl(new ParsedValueImpl[] { blurType, color, size, size2, size3, this.parseSize(nextArg5) }, (StyleConverter<Object, Object>)EffectConverter.InnerShadowConverter.getInstance());
    }
    
    private ParsedValueImpl dropshadow(final Term term) throws ParseException {
        if (!"dropshadow".regionMatches(true, 0, (term.token != null) ? term.token.getText() : null, 0, 10)) {
            this.error(term, "Expected 'dropshadow'");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null) {
            this.error(term, "Expected '<blur-type>'");
        }
        final ParsedValueImpl<String, BlurType> blurType = this.blurType(firstArg);
        final Term term2 = firstArg;
        final Term nextArg;
        if ((nextArg = firstArg.nextArg) == null) {
            this.error(term2, "Expected '<color>'");
        }
        final ParsedValueImpl<?, Color> color = this.parseColor(nextArg);
        final Term term3 = nextArg;
        final Term nextArg2;
        if ((nextArg2 = nextArg.nextArg) == null) {
            this.error(term3, "Expected '<number>'");
        }
        final ParsedValueImpl<?, Size> size = this.parseSize(nextArg2);
        final Term term4 = nextArg2;
        final Term nextArg3;
        if ((nextArg3 = nextArg2.nextArg) == null) {
            this.error(term4, "Expected '<number>'");
        }
        final ParsedValueImpl<?, Size> size2 = this.parseSize(nextArg3);
        final Term term5 = nextArg3;
        final Term nextArg4;
        if ((nextArg4 = nextArg3.nextArg) == null) {
            this.error(term5, "Expected '<number>'");
        }
        final ParsedValueImpl<?, Size> size3 = this.parseSize(nextArg4);
        final Term term6 = nextArg4;
        final Term nextArg5;
        if ((nextArg5 = nextArg4.nextArg) == null) {
            this.error(term6, "Expected '<number>'");
        }
        return new ParsedValueImpl(new ParsedValueImpl[] { blurType, color, size, size2, size3, this.parseSize(nextArg5) }, (StyleConverter<Object, Object>)EffectConverter.DropShadowConverter.getInstance());
    }
    
    private ParsedValueImpl<String, CycleMethod> cycleMethod(final Term term) {
        Enum enum1 = null;
        if (term != null && term.token.getType() == 11) {
            final String lowerCase = term.token.getText().toLowerCase(Locale.ROOT);
            if ("repeat".equals(lowerCase)) {
                enum1 = CycleMethod.REPEAT;
            }
            else if ("reflect".equals(lowerCase)) {
                enum1 = CycleMethod.REFLECT;
            }
            else if ("no-cycle".equals(lowerCase)) {
                enum1 = CycleMethod.NO_CYCLE;
            }
        }
        if (enum1 != null) {
            return new ParsedValueImpl<String, CycleMethod>(enum1.name(), (StyleConverter<Object, Object>)new EnumConverter((Class<Enum>)CycleMethod.class));
        }
        return null;
    }
    
    private ParsedValueImpl<ParsedValue[], Paint> linearGradient(final Term term) throws ParseException {
        final String anotherString = (term.token != null) ? term.token.getText() : null;
        if (anotherString == null || !"linear".equalsIgnoreCase(anotherString)) {
            this.error(term, "Expected 'linear'");
        }
        if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
            CssParser.LOGGER.warning(this.formatDeprecatedMessage(term, "linear gradient"));
        }
        final Term nextInSeries;
        if ((nextInSeries = term.nextInSeries) == null) {
            this.error(term, "Expected '(<number>, <number>)'");
        }
        final ParsedValueImpl[] point = this.point(nextInSeries);
        final Term term2 = nextInSeries;
        final Term nextInSeries2;
        if ((nextInSeries2 = nextInSeries.nextInSeries) == null) {
            this.error(term2, "Expected 'to'");
        }
        if (nextInSeries2.token == null || nextInSeries2.token.getType() != 11 || !"to".equalsIgnoreCase(nextInSeries2.token.getText())) {
            this.error(term, "Expected 'to'");
        }
        final Term term3 = nextInSeries2;
        final Term nextInSeries3;
        if ((nextInSeries3 = nextInSeries2.nextInSeries) == null) {
            this.error(term3, "Expected '(<number>, <number>)'");
        }
        final ParsedValueImpl[] point2 = this.point(nextInSeries3);
        final Term term4 = nextInSeries3;
        final Term nextInSeries4;
        if ((nextInSeries4 = nextInSeries3.nextInSeries) == null) {
            this.error(term4, "Expected 'stops'");
        }
        if (nextInSeries4.token == null || nextInSeries4.token.getType() != 11 || !"stops".equalsIgnoreCase(nextInSeries4.token.getText())) {
            this.error(nextInSeries4, "Expected 'stops'");
        }
        final Term term5 = nextInSeries4;
        Term nextInSeries5;
        if ((nextInSeries5 = nextInSeries4.nextInSeries) == null) {
            this.error(term5, "Expected '(<number>, <number>)'");
        }
        int n = 0;
        Term nextInSeries6 = nextInSeries5;
        do {
            ++n;
        } while ((nextInSeries6 = nextInSeries6.nextInSeries) != null && nextInSeries6.token != null && nextInSeries6.token.getType() == 34);
        final ParsedValueImpl[] array = new ParsedValueImpl[n];
        int n2 = 0;
        Term term6;
        do {
            final ParsedValueImpl<ParsedValue[], Stop> stop = this.stop(nextInSeries5);
            if (stop != null) {
                array[n2++] = stop;
            }
            term6 = nextInSeries5;
        } while ((nextInSeries5 = nextInSeries5.nextInSeries) != null && nextInSeries5.token.getType() == 34);
        ParsedValueImpl<String, CycleMethod> cycleMethod = this.cycleMethod(nextInSeries5);
        if (cycleMethod == null) {
            cycleMethod = new ParsedValueImpl<String, CycleMethod>(CycleMethod.NO_CYCLE.name(), (StyleConverter<String, CycleMethod>)new EnumConverter((Class<Enum>)CycleMethod.class));
            if (nextInSeries5 != null) {
                term.nextInSeries = nextInSeries5;
            }
            else {
                term.nextInSeries = null;
                term.nextLayer = term6.nextLayer;
            }
        }
        else {
            term.nextInSeries = nextInSeries5.nextInSeries;
            term.nextLayer = nextInSeries5.nextLayer;
        }
        final ParsedValueImpl[] array2 = new ParsedValueImpl[5 + array.length];
        int n3 = 0;
        array2[n3++] = ((point != null) ? point[0] : null);
        array2[n3++] = ((point != null) ? point[1] : null);
        array2[n3++] = ((point2 != null) ? point2[0] : null);
        array2[n3++] = ((point2 != null) ? point2[1] : null);
        array2[n3++] = cycleMethod;
        for (int i = 0; i < array.length; ++i) {
            array2[n3++] = array[i];
        }
        return new ParsedValueImpl<ParsedValue[], Paint>(array2, (StyleConverter<Object, Object>)PaintConverter.LinearGradientConverter.getInstance());
    }
    
    private ParsedValueImpl parseLinearGradient(final Term term) throws ParseException {
        if (!"linear-gradient".regionMatches(true, 0, (term.token != null) ? term.token.getText() : null, 0, 15)) {
            this.error(term, "Expected 'linear-gradient'");
        }
        Term term2;
        if ((term2 = term.firstArg) == null || term2.token == null || term2.token.getText().isEmpty()) {
            this.error(term, "Expected 'from <point> to <point>' or 'to <side-or-corner>' or '<cycle-method>' or '<color-stop>'");
        }
        Term term3 = term2;
        ParsedValueImpl[] array = null;
        ParsedValueImpl[] array2 = null;
        if ("from".equalsIgnoreCase(term2.token.getText())) {
            final Term term4 = term2;
            final Term nextInSeries;
            if ((nextInSeries = term2.nextInSeries) == null) {
                this.error(term4, "Expected '<point>'");
            }
            final ParsedValueImpl<?, Size> size = this.parseSize(nextInSeries);
            final Term term5 = nextInSeries;
            final Term nextInSeries2;
            if ((nextInSeries2 = nextInSeries.nextInSeries) == null) {
                this.error(term5, "Expected '<point>'");
            }
            array = new ParsedValueImpl[] { size, this.parseSize(nextInSeries2) };
            final Term term6 = nextInSeries2;
            final Term nextInSeries3;
            if ((nextInSeries3 = nextInSeries2.nextInSeries) == null) {
                this.error(term6, "Expected 'to'");
            }
            if (nextInSeries3.token == null || nextInSeries3.token.getType() != 11 || !"to".equalsIgnoreCase(nextInSeries3.token.getText())) {
                this.error(term6, "Expected 'to'");
            }
            final Term term7 = nextInSeries3;
            final Term nextInSeries4;
            if ((nextInSeries4 = nextInSeries3.nextInSeries) == null) {
                this.error(term7, "Expected '<point>'");
            }
            final ParsedValueImpl<?, Size> size2 = this.parseSize(nextInSeries4);
            final Term term8 = nextInSeries4;
            final Term nextInSeries5;
            if ((nextInSeries5 = nextInSeries4.nextInSeries) == null) {
                this.error(term8, "Expected '<point>'");
            }
            array2 = new ParsedValueImpl[] { size2, this.parseSize(nextInSeries5) };
            term3 = nextInSeries5;
            term2 = nextInSeries5.nextArg;
        }
        else if ("to".equalsIgnoreCase(term2.token.getText())) {
            final Term term9 = term2;
            Term term10;
            if ((term10 = term2.nextInSeries) == null || term10.token == null || term10.token.getType() != 11 || term10.token.getText().isEmpty()) {
                this.error(term9, "Expected '<side-or-corner>'");
            }
            int n = 0;
            int n2 = 0;
            int n3 = 0;
            int n4 = 0;
            final String lowerCase = term10.token.getText().toLowerCase(Locale.ROOT);
            if ("top".equals(lowerCase)) {
                n2 = 100;
                n4 = 0;
            }
            else if ("bottom".equals(lowerCase)) {
                n2 = 0;
                n4 = 100;
            }
            else if ("right".equals(lowerCase)) {
                n = 0;
                n3 = 100;
            }
            else if ("left".equals(lowerCase)) {
                n = 100;
                n3 = 0;
            }
            else {
                this.error(term10, "Invalid '<side-or-corner>'");
            }
            final Term term11 = term10;
            if (term10.nextInSeries != null) {
                term10 = term10.nextInSeries;
                if (term10.token != null && term10.token.getType() == 11 && !term10.token.getText().isEmpty()) {
                    final String lowerCase2 = term10.token.getText().toLowerCase(Locale.ROOT);
                    if ("right".equals(lowerCase2) && n == 0 && n3 == 0) {
                        n = 0;
                        n3 = 100;
                    }
                    else if ("left".equals(lowerCase2) && n == 0 && n3 == 0) {
                        n = 100;
                        n3 = 0;
                    }
                    else if ("top".equals(lowerCase2) && n2 == 0 && n4 == 0) {
                        n2 = 100;
                        n4 = 0;
                    }
                    else if ("bottom".equals(lowerCase2) && n2 == 0 && n4 == 0) {
                        n2 = 0;
                        n4 = 100;
                    }
                    else {
                        this.error(term10, "Invalid '<side-or-corner>'");
                    }
                }
                else {
                    this.error(term11, "Expected '<side-or-corner>'");
                }
            }
            array = new ParsedValueImpl[] { new ParsedValueImpl((V)new Size(n, SizeUnits.PERCENT), null), new ParsedValueImpl(new Size(n2, SizeUnits.PERCENT), null) };
            array2 = new ParsedValueImpl[] { new ParsedValueImpl((V)new Size(n3, SizeUnits.PERCENT), null), new ParsedValueImpl(new Size(n4, SizeUnits.PERCENT), null) };
            term3 = term10;
            term2 = term10.nextArg;
        }
        if (array == null && array2 == null) {
            array = new ParsedValueImpl[] { new ParsedValueImpl((V)new Size(0.0, SizeUnits.PERCENT), null), new ParsedValueImpl((V)new Size(0.0, SizeUnits.PERCENT), null) };
            array2 = new ParsedValueImpl[] { new ParsedValueImpl((V)new Size(0.0, SizeUnits.PERCENT), null), new ParsedValueImpl((V)new Size(100.0, SizeUnits.PERCENT), null) };
        }
        if (term2 == null || term2.token == null || term2.token.getText().isEmpty()) {
            this.error(term3, "Expected '<cycle-method>' or '<color-stop>'");
        }
        CycleMethod cycleMethod = CycleMethod.NO_CYCLE;
        if ("reflect".equalsIgnoreCase(term2.token.getText())) {
            cycleMethod = CycleMethod.REFLECT;
            term3 = term2;
            term2 = term2.nextArg;
        }
        else if ("repeat".equalsIgnoreCase(term2.token.getText())) {
            cycleMethod = CycleMethod.REFLECT;
            term3 = term2;
            term2 = term2.nextArg;
        }
        if (term2 == null || term2.token == null || term2.token.getText().isEmpty()) {
            this.error(term3, "Expected '<color-stop>'");
        }
        final ParsedValueImpl<ParsedValue[], Stop>[] colorStops = this.parseColorStops(term2);
        final ParsedValueImpl[] array3 = new ParsedValueImpl[5 + colorStops.length];
        int n5 = 0;
        array3[n5++] = ((array != null) ? array[0] : null);
        array3[n5++] = ((array != null) ? array[1] : null);
        array3[n5++] = ((array2 != null) ? array2[0] : null);
        array3[n5++] = ((array2 != null) ? array2[1] : null);
        array3[n5++] = new ParsedValueImpl((V)cycleMethod.name(), (StyleConverter<V, T>)new EnumConverter((Class<Enum>)CycleMethod.class));
        for (int i = 0; i < colorStops.length; ++i) {
            array3[n5++] = colorStops[i];
        }
        return new ParsedValueImpl(array3, (StyleConverter<Object, Object>)PaintConverter.LinearGradientConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], Paint> radialGradient(final Term term) throws ParseException {
        final String anotherString = (term.token != null) ? term.token.getText() : null;
        if (anotherString == null || !"radial".equalsIgnoreCase(anotherString)) {
            this.error(term, "Expected 'radial'");
        }
        if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
            CssParser.LOGGER.warning(this.formatDeprecatedMessage(term, "radial gradient"));
        }
        Term term2;
        if ((term2 = term.nextInSeries) == null) {
            this.error(term, "Expected 'focus-angle <number>', 'focus-distance <number>', 'center (<number>,<number>)' or '<size>'");
        }
        if (term2.token == null) {
            this.error(term2, "Expected 'focus-angle <number>', 'focus-distance <number>', 'center (<number>,<number>)' or '<size>'");
        }
        ParsedValueImpl<?, Size> size = null;
        if (term2.token.getType() == 11 && "focus-angle".equals(term2.token.getText().toLowerCase(Locale.ROOT))) {
            final Term term3 = term2;
            final Term nextInSeries;
            if ((nextInSeries = term2.nextInSeries) == null) {
                this.error(term3, "Expected '<number>'");
            }
            if (nextInSeries.token == null) {
                this.error(term3, "Expected '<number>'");
            }
            size = this.parseSize(nextInSeries);
            final Term term4 = nextInSeries;
            if ((term2 = nextInSeries.nextInSeries) == null) {
                this.error(term4, "Expected 'focus-distance <number>', 'center (<number>,<number>)' or '<size>'");
            }
            if (term2.token == null) {
                this.error(term2, "Expected 'focus-distance <number>', 'center (<number>,<number>)' or '<size>'");
            }
        }
        ParsedValueImpl<?, Size> size2 = null;
        if (term2.token.getType() == 11 && "focus-distance".equals(term2.token.getText().toLowerCase(Locale.ROOT))) {
            final Term term5 = term2;
            final Term nextInSeries2;
            if ((nextInSeries2 = term2.nextInSeries) == null) {
                this.error(term5, "Expected '<number>'");
            }
            if (nextInSeries2.token == null) {
                this.error(term5, "Expected '<number>'");
            }
            size2 = this.parseSize(nextInSeries2);
            final Term term6 = nextInSeries2;
            if ((term2 = nextInSeries2.nextInSeries) == null) {
                this.error(term6, "Expected  'center (<number>,<number>)' or '<size>'");
            }
            if (term2.token == null) {
                this.error(term2, "Expected  'center (<number>,<number>)' or '<size>'");
            }
        }
        ParsedValueImpl[] point = null;
        if (term2.token.getType() == 11 && "center".equals(term2.token.getText().toLowerCase(Locale.ROOT))) {
            final Term term7 = term2;
            final Term nextInSeries3;
            if ((nextInSeries3 = term2.nextInSeries) == null) {
                this.error(term7, "Expected '(<number>,<number>)'");
            }
            if (nextInSeries3.token == null || nextInSeries3.token.getType() != 34) {
                this.error(nextInSeries3, "Expected '(<number>,<number>)'");
            }
            point = this.point(nextInSeries3);
            final Term term8 = nextInSeries3;
            if ((term2 = nextInSeries3.nextInSeries) == null) {
                this.error(term8, "Expected '<size>'");
            }
            if (term2.token == null) {
                this.error(term2, "Expected '<size>'");
            }
        }
        final ParsedValueImpl<?, Size> size3 = this.parseSize(term2);
        final Term term9 = term2;
        final Term nextInSeries4;
        if ((nextInSeries4 = term2.nextInSeries) == null) {
            this.error(term9, "Expected 'stops' keyword");
        }
        if (nextInSeries4.token == null || nextInSeries4.token.getType() != 11) {
            this.error(nextInSeries4, "Expected 'stops' keyword");
        }
        if (!"stops".equalsIgnoreCase(nextInSeries4.token.getText())) {
            this.error(nextInSeries4, "Expected 'stops'");
        }
        final Term term10 = nextInSeries4;
        Term nextInSeries5;
        if ((nextInSeries5 = nextInSeries4.nextInSeries) == null) {
            this.error(term10, "Expected '(<number>, <number>)'");
        }
        int n = 0;
        Term nextInSeries6 = nextInSeries5;
        do {
            ++n;
        } while ((nextInSeries6 = nextInSeries6.nextInSeries) != null && nextInSeries6.token != null && nextInSeries6.token.getType() == 34);
        final ParsedValueImpl[] array = new ParsedValueImpl[n];
        int n2 = 0;
        Term term11;
        do {
            final ParsedValueImpl<ParsedValue[], Stop> stop = this.stop(nextInSeries5);
            if (stop != null) {
                array[n2++] = stop;
            }
            term11 = nextInSeries5;
        } while ((nextInSeries5 = nextInSeries5.nextInSeries) != null && nextInSeries5.token.getType() == 34);
        ParsedValueImpl<String, CycleMethod> cycleMethod = this.cycleMethod(nextInSeries5);
        if (cycleMethod == null) {
            cycleMethod = new ParsedValueImpl<String, CycleMethod>(CycleMethod.NO_CYCLE.name(), (StyleConverter<String, CycleMethod>)new EnumConverter((Class<Enum>)CycleMethod.class));
            if (nextInSeries5 != null) {
                term.nextInSeries = nextInSeries5;
            }
            else {
                term.nextInSeries = null;
                term.nextLayer = term11.nextLayer;
            }
        }
        else {
            term.nextInSeries = nextInSeries5.nextInSeries;
            term.nextLayer = nextInSeries5.nextLayer;
        }
        final ParsedValueImpl[] array2 = new ParsedValueImpl[6 + array.length];
        int n3 = 0;
        array2[n3++] = size;
        array2[n3++] = size2;
        array2[n3++] = ((point != null) ? point[0] : null);
        array2[n3++] = ((point != null) ? point[1] : null);
        array2[n3++] = size3;
        array2[n3++] = cycleMethod;
        for (int i = 0; i < array.length; ++i) {
            array2[n3++] = array[i];
        }
        return new ParsedValueImpl<ParsedValue[], Paint>(array2, (StyleConverter<Object, Object>)PaintConverter.RadialGradientConverter.getInstance());
    }
    
    private ParsedValueImpl parseRadialGradient(final Term term) throws ParseException {
        if (!"radial-gradient".regionMatches(true, 0, (term.token != null) ? term.token.getText() : null, 0, 15)) {
            this.error(term, "Expected 'radial-gradient'");
        }
        Term term2;
        if ((term2 = term.firstArg) == null || term2.token == null || term2.token.getText().isEmpty()) {
            this.error(term, "Expected 'focus-angle <angle>' or 'focus-distance <percentage>' or 'center <point>' or 'radius [<length> | <percentage>]'");
        }
        Term term3 = term2;
        ParsedValueImpl parsedValueImpl = null;
        ParsedValueImpl parsedValueImpl2 = null;
        ParsedValueImpl[] array = null;
        ParsedValueImpl<?, Size> size = null;
        if ("focus-angle".equalsIgnoreCase(term2.token.getText())) {
            final Term term4 = term2;
            final Term nextInSeries;
            if ((nextInSeries = term2.nextInSeries) == null || !this.isSize(nextInSeries.token)) {
                this.error(term4, "Expected '<angle>'");
            }
            final Size size2 = this.size(nextInSeries.token);
            switch (size2.getUnits()) {
                case DEG:
                case RAD:
                case GRAD:
                case TURN:
                case PX: {
                    break;
                }
                default: {
                    this.error(nextInSeries, "Expected [deg | rad | grad | turn ]");
                    break;
                }
            }
            parsedValueImpl = new ParsedValueImpl(size2, null);
            term3 = nextInSeries;
            if ((term2 = nextInSeries.nextArg) == null) {
                this.error(term3, "Expected 'focus-distance <percentage>' or 'center <point>' or 'radius [<length> | <percentage>]'");
            }
        }
        if ("focus-distance".equalsIgnoreCase(term2.token.getText())) {
            final Term term5 = term2;
            final Term nextInSeries2;
            if ((nextInSeries2 = term2.nextInSeries) == null || !this.isSize(nextInSeries2.token)) {
                this.error(term5, "Expected '<percentage>'");
            }
            final Size size3 = this.size(nextInSeries2.token);
            switch (size3.getUnits()) {
                case PERCENT: {
                    break;
                }
                default: {
                    this.error(nextInSeries2, "Expected '%'");
                    break;
                }
            }
            parsedValueImpl2 = new ParsedValueImpl(size3, null);
            term3 = nextInSeries2;
            if ((term2 = nextInSeries2.nextArg) == null) {
                this.error(term3, "Expected 'center <center>' or 'radius <length>'");
            }
        }
        if ("center".equalsIgnoreCase(term2.token.getText())) {
            final Term term6 = term2;
            final Term nextInSeries3;
            if ((nextInSeries3 = term2.nextInSeries) == null) {
                this.error(term6, "Expected '<point>'");
            }
            final ParsedValueImpl<?, Size> size4 = this.parseSize(nextInSeries3);
            final Term term7 = nextInSeries3;
            final Term nextInSeries4;
            if ((nextInSeries4 = nextInSeries3.nextInSeries) == null) {
                this.error(term7, "Expected '<point>'");
            }
            array = new ParsedValueImpl[] { size4, this.parseSize(nextInSeries4) };
            term3 = nextInSeries4;
            if ((term2 = nextInSeries4.nextArg) == null) {
                this.error(term3, "Expected 'radius [<length> | <percentage>]'");
            }
        }
        if ("radius".equalsIgnoreCase(term2.token.getText())) {
            final Term term8 = term2;
            final Term nextInSeries5;
            if ((nextInSeries5 = term2.nextInSeries) == null || !this.isSize(nextInSeries5.token)) {
                this.error(term8, "Expected '[<length> | <percentage>]'");
            }
            size = this.parseSize(nextInSeries5);
            term3 = nextInSeries5;
            if ((term2 = nextInSeries5.nextArg) == null) {
                this.error(term3, "Expected 'radius [<length> | <percentage>]'");
            }
        }
        CycleMethod cycleMethod = CycleMethod.NO_CYCLE;
        if ("reflect".equalsIgnoreCase(term2.token.getText())) {
            cycleMethod = CycleMethod.REFLECT;
            term3 = term2;
            term2 = term2.nextArg;
        }
        else if ("repeat".equalsIgnoreCase(term2.token.getText())) {
            cycleMethod = CycleMethod.REFLECT;
            term3 = term2;
            term2 = term2.nextArg;
        }
        if (term2 == null || term2.token == null || term2.token.getText().isEmpty()) {
            this.error(term3, "Expected '<color-stop>'");
        }
        final ParsedValueImpl<ParsedValue[], Stop>[] colorStops = this.parseColorStops(term2);
        final ParsedValueImpl[] array2 = new ParsedValueImpl[6 + colorStops.length];
        int n = 0;
        array2[n++] = parsedValueImpl;
        array2[n++] = parsedValueImpl2;
        array2[n++] = ((array != null) ? array[0] : null);
        array2[n++] = ((array != null) ? array[1] : null);
        array2[n++] = size;
        array2[n++] = new ParsedValueImpl((V)cycleMethod.name(), (StyleConverter<V, T>)new EnumConverter((Class<Enum>)CycleMethod.class));
        for (int i = 0; i < colorStops.length; ++i) {
            array2[n++] = colorStops[i];
        }
        return new ParsedValueImpl(array2, (StyleConverter<Object, Object>)PaintConverter.RadialGradientConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], Paint> parseImagePattern(final Term term) throws ParseException {
        if (!"image-pattern".regionMatches(true, 0, (term.token != null) ? term.token.getText() : null, 0, 13)) {
            this.error(term, "Expected 'image-pattern'");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null || firstArg.token == null || firstArg.token.getText().isEmpty()) {
            this.error(term, "Expected '<uri-string>'");
        }
        final Term term2 = firstArg;
        final ParsedValueImpl parsedValueImpl = new ParsedValueImpl(new ParsedValueImpl[] { new ParsedValueImpl((V)firstArg.token.getText(), (StyleConverter<V, T>)StringConverter.getInstance()), null }, (StyleConverter<Object, Object>)URLConverter.getInstance());
        if (firstArg.nextArg == null) {
            return new ParsedValueImpl<ParsedValue[], Paint>(new ParsedValueImpl[] { parsedValueImpl }, (StyleConverter<Object, Object>)PaintConverter.ImagePatternConverter.getInstance());
        }
        final Term nextArg;
        if ((nextArg = firstArg.nextArg) == null) {
            this.error(term2, "Expected '<size>'");
        }
        final ParsedValueImpl<?, Size> size = this.parseSize(nextArg);
        final Term term3 = nextArg;
        final Term nextArg2;
        if ((nextArg2 = nextArg.nextArg) == null) {
            this.error(term3, "Expected '<size>'");
        }
        final ParsedValueImpl<?, Size> size2 = this.parseSize(nextArg2);
        final Term term4 = nextArg2;
        final Term nextArg3;
        if ((nextArg3 = nextArg2.nextArg) == null) {
            this.error(term4, "Expected '<size>'");
        }
        final ParsedValueImpl<?, Size> size3 = this.parseSize(nextArg3);
        final Term term5 = nextArg3;
        final Term nextArg4;
        if ((nextArg4 = nextArg3.nextArg) == null) {
            this.error(term5, "Expected '<size>'");
        }
        final ParsedValueImpl<?, Size> size4 = this.parseSize(nextArg4);
        if (nextArg4.nextArg == null) {
            return new ParsedValueImpl<ParsedValue[], Paint>(new ParsedValueImpl[] { parsedValueImpl, size, size2, size3, size4 }, (StyleConverter<Object, Object>)PaintConverter.ImagePatternConverter.getInstance());
        }
        final Term term6 = nextArg4;
        final Term nextArg5;
        if ((nextArg5 = nextArg4.nextArg) == null) {
            this.error(term6, "Expected '<boolean>'");
        }
        final Token token;
        if ((token = nextArg5.token) == null || token.getText() == null) {
            this.error(nextArg5, "Expected '<boolean>'");
        }
        return new ParsedValueImpl<ParsedValue[], Paint>(new ParsedValueImpl[] { parsedValueImpl, size, size2, size3, size4, new ParsedValueImpl(Boolean.parseBoolean(token.getText()), null) }, (StyleConverter<Object, Object>)PaintConverter.ImagePatternConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], Paint> parseRepeatingImagePattern(final Term term) throws ParseException {
        if (!"repeating-image-pattern".regionMatches(true, 0, (term.token != null) ? term.token.getText() : null, 0, 23)) {
            this.error(term, "Expected 'repeating-image-pattern'");
        }
        final Term firstArg;
        if ((firstArg = term.firstArg) == null || firstArg.token == null || firstArg.token.getText().isEmpty()) {
            this.error(term, "Expected '<uri-string>'");
        }
        return new ParsedValueImpl<ParsedValue[], Paint>(new ParsedValueImpl[] { new ParsedValueImpl(new ParsedValueImpl[] { new ParsedValueImpl(firstArg.token.getText(), (StyleConverter<Object, Object>)StringConverter.getInstance()), null }, (StyleConverter<Object, Object>)URLConverter.getInstance()) }, (StyleConverter<Object, Object>)PaintConverter.RepeatingImagePatternConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<?, Paint>[], Paint[]> parsePaintLayers(final Term term) throws ParseException {
        final ParsedValueImpl[] array = new ParsedValueImpl[this.numberOfLayers(term)];
        Term nextLayer = term;
        int n = 0;
        do {
            if (nextLayer.token == null || nextLayer.token.getText() == null || nextLayer.token.getText().isEmpty()) {
                this.error(nextLayer, "Expected '<paint>'");
            }
            array[n++] = this.parse(nextLayer);
            nextLayer = this.nextLayer(nextLayer);
        } while (nextLayer != null);
        return new ParsedValueImpl<ParsedValue<?, Paint>[], Paint[]>(array, (StyleConverter<Object, Object>)PaintConverter.SequenceConverter.getInstance());
    }
    
    private ParsedValueImpl<?, Size>[] parseSize1to4(final Term term) throws ParseException {
        Term nextInSeries;
        ParsedValueImpl[] array;
        int n;
        for (nextInSeries = term, array = new ParsedValueImpl[4], n = 0; n < 4 && nextInSeries != null; array[n++] = this.parseSize(nextInSeries), nextInSeries = nextInSeries.nextInSeries) {}
        if (n < 2) {
            array[1] = array[0];
        }
        if (n < 3) {
            array[2] = array[0];
        }
        if (n < 4) {
            array[3] = array[1];
        }
        return (ParsedValueImpl<?, Size>[])array;
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue[], Insets>[], Insets[]> parseInsetsLayers(final Term term) throws ParseException {
        final int numberOfLayers = this.numberOfLayers(term);
        Term term2 = term;
        int n = 0;
        final ParsedValueImpl[] array = new ParsedValueImpl[numberOfLayers];
        while (term2 != null) {
            array[n++] = new ParsedValueImpl<ParsedValue[], Insets>((V)(Object)this.parseSize1to4(term2), (StyleConverter<V, T>)InsetsConverter.getInstance());
            while (term2.nextInSeries != null) {
                term2 = term2.nextInSeries;
            }
            term2 = this.nextLayer(term2);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue[], Insets>[], Insets[]>(array, (StyleConverter<Object, Object>)InsetsConverter.SequenceConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], Insets> parseInsetsLayer(final Term term) throws ParseException {
        Term term2 = term;
        ParsedValueImpl<ParsedValue[], Insets> parsedValueImpl = null;
        while (term2 != null) {
            parsedValueImpl = new ParsedValueImpl<ParsedValue[], Insets>(this.parseSize1to4(term2), InsetsConverter.getInstance());
            while (term2.nextInSeries != null) {
                term2 = term2.nextInSeries;
            }
            term2 = this.nextLayer(term2);
        }
        return parsedValueImpl;
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue[], Margins>[], Margins[]> parseMarginsLayers(final Term term) throws ParseException {
        final int numberOfLayers = this.numberOfLayers(term);
        Term term2 = term;
        int n = 0;
        final ParsedValueImpl[] array = new ParsedValueImpl[numberOfLayers];
        while (term2 != null) {
            array[n++] = new ParsedValueImpl<ParsedValue[], Margins>((V)(Object)this.parseSize1to4(term2), (StyleConverter<V, T>)Margins.Converter.getInstance());
            while (term2.nextInSeries != null) {
                term2 = term2.nextInSeries;
            }
            term2 = this.nextLayer(term2);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue[], Margins>[], Margins[]>(array, (StyleConverter<Object, Object>)Margins.SequenceConverter.getInstance());
    }
    
    private ParsedValueImpl<Size, Size>[] parseSizeSeries(final Term term) throws ParseException {
        if (term.token == null) {
            this.error(term, "Parse error");
        }
        final ArrayList<ParsedValueImpl<Size, Object>> list = new ArrayList<ParsedValueImpl<Size, Object>>();
        for (Term nextInSeries = term; nextInSeries != null; nextInSeries = nextInSeries.nextInSeries) {
            final Token token = nextInSeries.token;
            switch (token.getType()) {
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                case 26: {
                    list.add(new ParsedValueImpl<Size, Object>(this.size(token), null));
                    break;
                }
                default: {
                    this.error(term, "expected series of <size>");
                    break;
                }
            }
        }
        return list.toArray(new ParsedValueImpl[list.size()]);
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue<?, Size>[][], CornerRadii>[], CornerRadii[]> parseCornerRadius(final Term term) throws ParseException {
        final int numberOfLayers = this.numberOfLayers(term);
        Term term2 = term;
        int n = 0;
        final ParsedValueImpl[] array = new ParsedValueImpl[numberOfLayers];
        while (term2 != null) {
            int n2 = 0;
            Term term3;
            for (term3 = term2; term3 != null; term3 = term3.nextInSeries) {
                if (term3.token.getType() == 32) {
                    term3 = term3.nextInSeries;
                    break;
                }
                ++n2;
            }
            int n3 = 0;
            while (term3 != null) {
                if (term3.token.getType() == 32) {
                    this.error(term3, "unexpected SOLIDUS");
                    break;
                }
                ++n3;
                term3 = term3.nextInSeries;
            }
            if (n2 == 0 || n2 > 4 || n3 > 4) {
                this.error(term, "expected [<length>|<percentage>]{1,4} [/ [<length>|<percentage>]{1,4}]?");
            }
            int n4 = 0;
            final ParsedValueImpl[][] array2 = new ParsedValueImpl[2][4];
            final ParsedValueImpl<Object, Size> parsedValueImpl = new ParsedValueImpl<Object, Size>(new Size(0.0, SizeUnits.PX), null);
            for (int i = 0; i < 4; ++i) {
                array2[0][i] = parsedValueImpl;
                array2[1][i] = parsedValueImpl;
            }
            int n5 = 0;
            int n6 = 0;
            Term term4 = term2;
            while (n5 <= 4 && n6 <= 4 && term2 != null) {
                if (term2.token.getType() == 32) {
                    ++n4;
                }
                else {
                    final ParsedValueImpl<?, Size> size = this.parseSize(term2);
                    if (n4 == 0) {
                        array2[n4][n5++] = size;
                    }
                    else {
                        array2[n4][n6++] = size;
                    }
                }
                term4 = term2;
                term2 = term2.nextInSeries;
            }
            if (n5 != 0) {
                if (n5 < 2) {
                    array2[0][1] = array2[0][0];
                }
                if (n5 < 3) {
                    array2[0][2] = array2[0][0];
                }
                if (n5 < 4) {
                    array2[0][3] = array2[0][1];
                }
            }
            else {
                assert false;
            }
            if (n6 != 0) {
                if (n6 < 2) {
                    array2[1][1] = array2[1][0];
                }
                if (n6 < 3) {
                    array2[1][2] = array2[1][0];
                }
                if (n6 < 4) {
                    array2[1][3] = array2[1][1];
                }
            }
            else {
                array2[1][0] = array2[0][0];
                array2[1][1] = array2[0][1];
                array2[1][2] = array2[0][2];
                array2[1][3] = array2[0][3];
            }
            if (parsedValueImpl.equals(array2[0][0]) || parsedValueImpl.equals(array2[1][0])) {
                array2[1][0] = (array2[0][0] = parsedValueImpl);
            }
            if (parsedValueImpl.equals(array2[0][1]) || parsedValueImpl.equals(array2[1][1])) {
                array2[1][1] = (array2[0][1] = parsedValueImpl);
            }
            if (parsedValueImpl.equals(array2[0][2]) || parsedValueImpl.equals(array2[1][2])) {
                array2[1][2] = (array2[0][2] = parsedValueImpl);
            }
            if (parsedValueImpl.equals(array2[0][3]) || parsedValueImpl.equals(array2[1][3])) {
                array2[1][3] = (array2[0][3] = parsedValueImpl);
            }
            array[n++] = new ParsedValueImpl<ParsedValue<?, Size>[][], CornerRadii>(array2, null);
            term2 = this.nextLayer(term4);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue<?, Size>[][], CornerRadii>[], CornerRadii[]>(array, (StyleConverter<Object, Object>)CornerRadiiConverter.getInstance());
    }
    
    private static boolean isPositionKeyWord(final String anotherString) {
        return "center".equalsIgnoreCase(anotherString) || "top".equalsIgnoreCase(anotherString) || "bottom".equalsIgnoreCase(anotherString) || "left".equalsIgnoreCase(anotherString) || "right".equalsIgnoreCase(anotherString);
    }
    
    private ParsedValueImpl<ParsedValue[], BackgroundPosition> parseBackgroundPosition(final Term term) throws ParseException {
        if (term.token == null || term.token.getText() == null || term.token.getText().isEmpty()) {
            this.error(term, "Expected '<bg-position>'");
        }
        Term term2 = term;
        Token token = term.token;
        Term nextInSeries = term2.nextInSeries;
        Token token2 = (nextInSeries != null) ? nextInSeries.token : null;
        Term term3 = (nextInSeries != null) ? nextInSeries.nextInSeries : null;
        Token token3 = (term3 != null) ? term3.token : null;
        Term term4 = (term3 != null) ? term3.nextInSeries : null;
        Token token4 = (term4 != null) ? term4.token : null;
        if (token != null && token2 != null && token3 == null && token4 == null) {
            final String text = token.getText();
            final String text2 = token2.getText();
            if (("top".equals(text) || "bottom".equals(text)) && ("left".equals(text2) || "right".equals(text2) || "center".equals(text2))) {
                final Token token5 = token2;
                token2 = token;
                token = token5;
                final Term term5 = nextInSeries;
                nextInSeries = term2;
                term2 = term5;
            }
        }
        else if (token != null && token2 != null && token3 != null) {
            Term[] array = null;
            Token[] array2 = null;
            if (token4 != null) {
                if (("top".equals(token.getText()) || "bottom".equals(token.getText())) && ("left".equals(token3.getText()) || "right".equals(token3.getText()))) {
                    array = new Term[] { term3, term4, term2, nextInSeries };
                    array2 = new Token[] { token3, token4, token, token2 };
                }
            }
            else if ("top".equals(token.getText()) || "bottom".equals(token.getText())) {
                if ("left".equals(token2.getText()) || "right".equals(token2.getText())) {
                    array = new Term[] { nextInSeries, term3, term2, null };
                    array2 = new Token[] { token2, token3, token, null };
                }
                else {
                    array = new Term[] { term3, term2, nextInSeries, null };
                    array2 = new Token[] { token3, token, token2, null };
                }
            }
            if (array != null) {
                term2 = array[0];
                nextInSeries = array[1];
                term3 = array[2];
                term4 = array[3];
                token = array2[0];
                token2 = array2[1];
                token3 = array2[2];
                token4 = array2[3];
            }
        }
        ParsedValueImpl<?, Size> parsedValueImpl4;
        ParsedValueImpl<?, Size> parsedValueImpl3;
        ParsedValueImpl<?, Size> parsedValueImpl2;
        ParsedValueImpl<?, Size> parsedValueImpl = parsedValueImpl2 = (parsedValueImpl3 = (parsedValueImpl4 = CssParser.ZERO_PERCENT));
        if (token == null && token2 == null && token3 == null && token4 == null) {
            this.error(term, "No value found for background-position");
        }
        else if (token != null && token2 == null && token3 == null && token4 == null) {
            final String text3 = token.getText();
            if ("center".equals(text3)) {
                parsedValueImpl4 = CssParser.FIFTY_PERCENT;
                parsedValueImpl = CssParser.ZERO_PERCENT;
                parsedValueImpl2 = CssParser.FIFTY_PERCENT;
                parsedValueImpl3 = CssParser.ZERO_PERCENT;
            }
            else if ("left".equals(text3)) {
                parsedValueImpl4 = CssParser.ZERO_PERCENT;
                parsedValueImpl = CssParser.ZERO_PERCENT;
                parsedValueImpl2 = CssParser.FIFTY_PERCENT;
                parsedValueImpl3 = CssParser.ZERO_PERCENT;
            }
            else if ("right".equals(text3)) {
                parsedValueImpl4 = CssParser.ONE_HUNDRED_PERCENT;
                parsedValueImpl = CssParser.ZERO_PERCENT;
                parsedValueImpl2 = CssParser.FIFTY_PERCENT;
                parsedValueImpl3 = CssParser.ZERO_PERCENT;
            }
            else if ("top".equals(text3)) {
                parsedValueImpl4 = CssParser.FIFTY_PERCENT;
                parsedValueImpl = CssParser.ZERO_PERCENT;
                parsedValueImpl2 = CssParser.ZERO_PERCENT;
                parsedValueImpl3 = CssParser.ZERO_PERCENT;
            }
            else if ("bottom".equals(text3)) {
                parsedValueImpl4 = CssParser.FIFTY_PERCENT;
                parsedValueImpl = CssParser.ZERO_PERCENT;
                parsedValueImpl2 = CssParser.ONE_HUNDRED_PERCENT;
                parsedValueImpl3 = CssParser.ZERO_PERCENT;
            }
            else {
                parsedValueImpl4 = this.parseSize(term2);
                parsedValueImpl = CssParser.ZERO_PERCENT;
                parsedValueImpl2 = CssParser.FIFTY_PERCENT;
                parsedValueImpl3 = CssParser.ZERO_PERCENT;
            }
        }
        else if (token != null && token2 != null && token3 == null && token4 == null) {
            final String lowerCase = token.getText().toLowerCase(Locale.ROOT);
            final String lowerCase2 = token2.getText().toLowerCase(Locale.ROOT);
            if (!isPositionKeyWord(lowerCase)) {
                parsedValueImpl4 = this.parseSize(term2);
                parsedValueImpl = CssParser.ZERO_PERCENT;
                if ("top".equals(lowerCase2)) {
                    parsedValueImpl2 = CssParser.ZERO_PERCENT;
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else if ("bottom".equals(lowerCase2)) {
                    parsedValueImpl2 = CssParser.ONE_HUNDRED_PERCENT;
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else if ("center".equals(lowerCase2)) {
                    parsedValueImpl2 = CssParser.FIFTY_PERCENT;
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else if (!isPositionKeyWord(lowerCase2)) {
                    parsedValueImpl2 = this.parseSize(nextInSeries);
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else {
                    this.error(nextInSeries, "Expected 'top', 'bottom', 'center' or <size>");
                }
            }
            else if (lowerCase.equals("left") || lowerCase.equals("right")) {
                parsedValueImpl4 = (lowerCase.equals("right") ? CssParser.ONE_HUNDRED_PERCENT : CssParser.ZERO_PERCENT);
                parsedValueImpl = CssParser.ZERO_PERCENT;
                if (!isPositionKeyWord(lowerCase2)) {
                    parsedValueImpl2 = this.parseSize(nextInSeries);
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else if (lowerCase2.equals("top") || lowerCase2.equals("bottom") || lowerCase2.equals("center")) {
                    if (lowerCase2.equals("top")) {
                        parsedValueImpl2 = CssParser.ZERO_PERCENT;
                        parsedValueImpl3 = CssParser.ZERO_PERCENT;
                    }
                    else if (lowerCase2.equals("center")) {
                        parsedValueImpl2 = CssParser.FIFTY_PERCENT;
                        parsedValueImpl3 = CssParser.ZERO_PERCENT;
                    }
                    else {
                        parsedValueImpl2 = CssParser.ONE_HUNDRED_PERCENT;
                        parsedValueImpl3 = CssParser.ZERO_PERCENT;
                    }
                }
                else {
                    this.error(nextInSeries, "Expected 'top', 'bottom', 'center' or <size>");
                }
            }
            else if (lowerCase.equals("center")) {
                parsedValueImpl4 = CssParser.FIFTY_PERCENT;
                parsedValueImpl = CssParser.ZERO_PERCENT;
                if (lowerCase2.equals("top")) {
                    parsedValueImpl2 = CssParser.ZERO_PERCENT;
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else if (lowerCase2.equals("bottom")) {
                    parsedValueImpl2 = CssParser.ONE_HUNDRED_PERCENT;
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else if (lowerCase2.equals("center")) {
                    parsedValueImpl2 = CssParser.FIFTY_PERCENT;
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else if (!isPositionKeyWord(lowerCase2)) {
                    parsedValueImpl2 = this.parseSize(nextInSeries);
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else {
                    this.error(nextInSeries, "Expected 'top', 'bottom', 'center' or <size>");
                }
            }
        }
        else if (token != null && token2 != null && token3 != null && token4 == null) {
            final String lowerCase3 = token.getText().toLowerCase(Locale.ROOT);
            final String lowerCase4 = token2.getText().toLowerCase(Locale.ROOT);
            final String lowerCase5 = token3.getText().toLowerCase(Locale.ROOT);
            if (!isPositionKeyWord(lowerCase3) || "center".equals(lowerCase3)) {
                if ("center".equals(lowerCase3)) {
                    parsedValueImpl4 = CssParser.FIFTY_PERCENT;
                }
                else {
                    parsedValueImpl4 = this.parseSize(term2);
                }
                parsedValueImpl = CssParser.ZERO_PERCENT;
                if (!isPositionKeyWord(lowerCase5)) {
                    if ("top".equals(lowerCase4)) {
                        parsedValueImpl2 = this.parseSize(term3);
                        parsedValueImpl3 = CssParser.ZERO_PERCENT;
                    }
                    else if ("bottom".equals(lowerCase4)) {
                        parsedValueImpl2 = CssParser.ZERO_PERCENT;
                        parsedValueImpl3 = this.parseSize(term3);
                    }
                    else {
                        this.error(nextInSeries, "Expected 'top' or 'bottom'");
                    }
                }
                else {
                    this.error(term3, "Expected <size>");
                }
            }
            else if ("left".equals(lowerCase3) || "right".equals(lowerCase3)) {
                if (!isPositionKeyWord(lowerCase4)) {
                    if ("left".equals(lowerCase3)) {
                        parsedValueImpl4 = this.parseSize(nextInSeries);
                        parsedValueImpl = CssParser.ZERO_PERCENT;
                    }
                    else {
                        parsedValueImpl4 = CssParser.ZERO_PERCENT;
                        parsedValueImpl = this.parseSize(nextInSeries);
                    }
                    if ("top".equals(lowerCase5)) {
                        parsedValueImpl2 = CssParser.ZERO_PERCENT;
                        parsedValueImpl3 = CssParser.ZERO_PERCENT;
                    }
                    else if ("bottom".equals(lowerCase5)) {
                        parsedValueImpl2 = CssParser.ONE_HUNDRED_PERCENT;
                        parsedValueImpl3 = CssParser.ZERO_PERCENT;
                    }
                    else if ("center".equals(lowerCase5)) {
                        parsedValueImpl2 = CssParser.FIFTY_PERCENT;
                        parsedValueImpl3 = CssParser.ZERO_PERCENT;
                    }
                    else {
                        this.error(term3, "Expected 'top', 'bottom' or 'center'");
                    }
                }
                else {
                    if ("left".equals(lowerCase3)) {
                        parsedValueImpl4 = CssParser.ZERO_PERCENT;
                        parsedValueImpl = CssParser.ZERO_PERCENT;
                    }
                    else {
                        parsedValueImpl4 = CssParser.ONE_HUNDRED_PERCENT;
                        parsedValueImpl = CssParser.ZERO_PERCENT;
                    }
                    if (!isPositionKeyWord(lowerCase5)) {
                        if ("top".equals(lowerCase4)) {
                            parsedValueImpl2 = this.parseSize(term3);
                            parsedValueImpl3 = CssParser.ZERO_PERCENT;
                        }
                        else if ("bottom".equals(lowerCase4)) {
                            parsedValueImpl2 = CssParser.ZERO_PERCENT;
                            parsedValueImpl3 = this.parseSize(term3);
                        }
                        else {
                            this.error(nextInSeries, "Expected 'top' or 'bottom'");
                        }
                    }
                    else {
                        this.error(term3, "Expected <size>");
                    }
                }
            }
        }
        else {
            final String lowerCase6 = token.getText().toLowerCase(Locale.ROOT);
            final String lowerCase7 = token2.getText().toLowerCase(Locale.ROOT);
            final String lowerCase8 = token3.getText().toLowerCase(Locale.ROOT);
            final String lowerCase9 = token4.getText().toLowerCase(Locale.ROOT);
            if ((lowerCase6.equals("left") || lowerCase6.equals("right")) && (lowerCase8.equals("top") || lowerCase8.equals("bottom")) && !isPositionKeyWord(lowerCase7) && !isPositionKeyWord(lowerCase9)) {
                if (lowerCase6.equals("left")) {
                    parsedValueImpl4 = this.parseSize(nextInSeries);
                    parsedValueImpl = CssParser.ZERO_PERCENT;
                }
                else {
                    parsedValueImpl4 = CssParser.ZERO_PERCENT;
                    parsedValueImpl = this.parseSize(nextInSeries);
                }
                if (lowerCase8.equals("top")) {
                    parsedValueImpl2 = this.parseSize(term4);
                    parsedValueImpl3 = CssParser.ZERO_PERCENT;
                }
                else {
                    parsedValueImpl2 = CssParser.ZERO_PERCENT;
                    parsedValueImpl3 = this.parseSize(term4);
                }
            }
            else {
                this.error(term, "Expected 'left' or 'right' followed by <size> followed by 'top' or 'bottom' followed by <size>");
            }
        }
        return new ParsedValueImpl<ParsedValue[], BackgroundPosition>(new ParsedValueImpl[] { parsedValueImpl2, parsedValueImpl, parsedValueImpl3, parsedValueImpl4 }, (StyleConverter<Object, Object>)BackgroundPositionConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue[], BackgroundPosition>[], BackgroundPosition[]> parseBackgroundPositionLayers(final Term term) throws ParseException {
        final ParsedValueImpl[] array = new ParsedValueImpl[this.numberOfLayers(term)];
        int n = 0;
        for (Term nextLayer = term; nextLayer != null; nextLayer = this.nextLayer(nextLayer)) {
            array[n++] = this.parseBackgroundPosition(nextLayer);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue[], BackgroundPosition>[], BackgroundPosition[]>(array, (StyleConverter<Object, Object>)LayeredBackgroundPositionConverter.getInstance());
    }
    
    private ParsedValueImpl<String, BackgroundRepeat>[] parseRepeatStyle(final Term term) throws ParseException {
        BackgroundRepeat backgroundRepeat2;
        BackgroundRepeat backgroundRepeat = backgroundRepeat2 = BackgroundRepeat.NO_REPEAT;
        if (term.token == null || term.token.getType() != 11 || term.token.getText() == null || term.token.getText().isEmpty()) {
            this.error(term, "Expected '<repeat-style>'");
        }
        final String lowerCase = term.token.getText().toLowerCase(Locale.ROOT);
        if ("repeat-x".equals(lowerCase)) {
            backgroundRepeat2 = BackgroundRepeat.REPEAT;
            backgroundRepeat = BackgroundRepeat.NO_REPEAT;
        }
        else if ("repeat-y".equals(lowerCase)) {
            backgroundRepeat2 = BackgroundRepeat.NO_REPEAT;
            backgroundRepeat = BackgroundRepeat.REPEAT;
        }
        else if ("repeat".equals(lowerCase)) {
            backgroundRepeat2 = BackgroundRepeat.REPEAT;
            backgroundRepeat = BackgroundRepeat.REPEAT;
        }
        else if ("space".equals(lowerCase)) {
            backgroundRepeat2 = BackgroundRepeat.SPACE;
            backgroundRepeat = BackgroundRepeat.SPACE;
        }
        else if ("round".equals(lowerCase)) {
            backgroundRepeat2 = BackgroundRepeat.ROUND;
            backgroundRepeat = BackgroundRepeat.ROUND;
        }
        else if ("no-repeat".equals(lowerCase)) {
            backgroundRepeat2 = BackgroundRepeat.NO_REPEAT;
            backgroundRepeat = BackgroundRepeat.NO_REPEAT;
        }
        else if ("stretch".equals(lowerCase)) {
            backgroundRepeat2 = BackgroundRepeat.NO_REPEAT;
            backgroundRepeat = BackgroundRepeat.NO_REPEAT;
        }
        else {
            this.error(term, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, lowerCase));
        }
        final Term nextInSeries;
        if ((nextInSeries = term.nextInSeries) != null && nextInSeries.token != null && nextInSeries.token.getType() == 11 && nextInSeries.token.getText() != null && !nextInSeries.token.getText().isEmpty()) {
            final String lowerCase2 = nextInSeries.token.getText().toLowerCase(Locale.ROOT);
            if ("repeat-x".equals(lowerCase2)) {
                this.error(nextInSeries, "Unexpected 'repeat-x'");
            }
            else if ("repeat-y".equals(lowerCase2)) {
                this.error(nextInSeries, "Unexpected 'repeat-y'");
            }
            else if ("repeat".equals(lowerCase2)) {
                backgroundRepeat = BackgroundRepeat.REPEAT;
            }
            else if ("space".equals(lowerCase2)) {
                backgroundRepeat = BackgroundRepeat.SPACE;
            }
            else if ("round".equals(lowerCase2)) {
                backgroundRepeat = BackgroundRepeat.ROUND;
            }
            else if ("no-repeat".equals(lowerCase2)) {
                backgroundRepeat = BackgroundRepeat.NO_REPEAT;
            }
            else if ("stretch".equals(lowerCase2)) {
                backgroundRepeat = BackgroundRepeat.NO_REPEAT;
            }
            else {
                this.error(nextInSeries, "Expected  '<repeat-style>'");
            }
        }
        return (ParsedValueImpl<String, BackgroundRepeat>[])new ParsedValueImpl[] { new ParsedValueImpl((V)backgroundRepeat2.name(), (StyleConverter<V, T>)new EnumConverter((Class<Enum>)BackgroundRepeat.class)), new ParsedValueImpl(backgroundRepeat.name(), (StyleConverter<Object, Object>)new EnumConverter((Class<Enum>)BackgroundRepeat.class)) };
    }
    
    private ParsedValueImpl<ParsedValue<String, BackgroundRepeat>[][], RepeatStruct[]> parseBorderImageRepeatStyleLayers(final Term term) throws ParseException {
        final ParsedValueImpl[][] array = new ParsedValueImpl[this.numberOfLayers(term)][];
        int n = 0;
        for (Term nextLayer = term; nextLayer != null; nextLayer = this.nextLayer(nextLayer)) {
            array[n++] = this.parseRepeatStyle(nextLayer);
        }
        return new ParsedValueImpl<ParsedValue<String, BackgroundRepeat>[][], RepeatStruct[]>(array, (StyleConverter<Object, Object>)RepeatStructConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<String, BackgroundRepeat>[][], RepeatStruct[]> parseBackgroundRepeatStyleLayers(final Term term) throws ParseException {
        final ParsedValueImpl[][] array = new ParsedValueImpl[this.numberOfLayers(term)][];
        int n = 0;
        for (Term nextLayer = term; nextLayer != null; nextLayer = this.nextLayer(nextLayer)) {
            array[n++] = this.parseRepeatStyle(nextLayer);
        }
        return new ParsedValueImpl<ParsedValue<String, BackgroundRepeat>[][], RepeatStruct[]>(array, (StyleConverter<Object, Object>)RepeatStructConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], BackgroundSize> parseBackgroundSize(final Term term) throws ParseException {
        ParsedValueImpl<?, Size> parsedValueImpl = null;
        ParsedValueImpl<?, Size> parsedValueImpl2 = null;
        boolean b = false;
        boolean b2 = false;
        if (term.token == null) {
            this.error(term, "Expected '<bg-size>'");
        }
        if (term.token.getType() == 11) {
            final String s = (term.token.getText() != null) ? term.token.getText().toLowerCase(Locale.ROOT) : null;
            if (!"auto".equals(s)) {
                if ("cover".equals(s)) {
                    b = true;
                }
                else if ("contain".equals(s)) {
                    b2 = true;
                }
                else if ("stretch".equals(s)) {
                    parsedValueImpl2 = CssParser.ONE_HUNDRED_PERCENT;
                    parsedValueImpl = CssParser.ONE_HUNDRED_PERCENT;
                }
                else {
                    this.error(term, "Expected 'auto', 'cover', 'contain', or  'stretch'");
                }
            }
        }
        else if (this.isSize(term.token)) {
            parsedValueImpl2 = this.parseSize(term);
            parsedValueImpl = null;
        }
        else {
            this.error(term, "Expected '<bg-size>'");
        }
        final Term nextInSeries;
        if ((nextInSeries = term.nextInSeries) != null) {
            if (b || b2) {
                this.error(nextInSeries, "Unexpected '<bg-size>'");
            }
            if (nextInSeries.token.getType() == 11) {
                final String s2 = (nextInSeries.token.getText() != null) ? nextInSeries.token.getText().toLowerCase(Locale.ROOT) : null;
                if ("auto".equals(s2)) {
                    parsedValueImpl = null;
                }
                else if ("cover".equals(s2)) {
                    this.error(nextInSeries, "Unexpected 'cover'");
                }
                else if ("contain".equals(s2)) {
                    this.error(nextInSeries, "Unexpected 'contain'");
                }
                else if ("stretch".equals(s2)) {
                    parsedValueImpl = CssParser.ONE_HUNDRED_PERCENT;
                }
                else {
                    this.error(nextInSeries, "Expected 'auto' or 'stretch'");
                }
            }
            else if (this.isSize(nextInSeries.token)) {
                parsedValueImpl = this.parseSize(nextInSeries);
            }
            else {
                this.error(nextInSeries, "Expected '<bg-size>'");
            }
        }
        return new ParsedValueImpl<ParsedValue[], BackgroundSize>(new ParsedValueImpl[] { parsedValueImpl2, parsedValueImpl, new ParsedValueImpl((V)(b ? "true" : "false"), (StyleConverter<V, T>)BooleanConverter.getInstance()), new ParsedValueImpl(b2 ? "true" : "false", (StyleConverter<Object, Object>)BooleanConverter.getInstance()) }, (StyleConverter<Object, Object>)BackgroundSizeConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue[], BackgroundSize>[], BackgroundSize[]> parseBackgroundSizeLayers(final Term term) throws ParseException {
        final ParsedValueImpl[] array = new ParsedValueImpl[this.numberOfLayers(term)];
        int n = 0;
        for (Term nextLayer = term; nextLayer != null; nextLayer = this.nextLayer(nextLayer)) {
            array[n++] = this.parseBackgroundSize(nextLayer);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue[], BackgroundSize>[], BackgroundSize[]>(array, (StyleConverter<Object, Object>)LayeredBackgroundSizeConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<?, Paint>[], Paint[]> parseBorderPaint(final Term term) throws ParseException {
        Term nextInSeries = term;
        final ParsedValueImpl[] array = new ParsedValueImpl[4];
        int n = 0;
        while (nextInSeries != null) {
            if (nextInSeries.token == null || array.length <= n) {
                this.error(nextInSeries, "Expected '<paint>'");
            }
            array[n++] = this.parse(nextInSeries);
            nextInSeries = nextInSeries.nextInSeries;
        }
        if (n < 2) {
            array[1] = array[0];
        }
        if (n < 3) {
            array[2] = array[0];
        }
        if (n < 4) {
            array[3] = array[1];
        }
        return new ParsedValueImpl<ParsedValue<?, Paint>[], Paint[]>(array, (StyleConverter<Object, Object>)StrokeBorderPaintConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue<?, Paint>[], Paint[]>[], Paint[][]> parseBorderPaintLayers(final Term term) throws ParseException {
        final ParsedValueImpl[] array = new ParsedValueImpl[this.numberOfLayers(term)];
        int n = 0;
        for (Term nextLayer = term; nextLayer != null; nextLayer = this.nextLayer(nextLayer)) {
            array[n++] = this.parseBorderPaint(nextLayer);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue<?, Paint>[], Paint[]>[], Paint[][]>(array, (StyleConverter<Object, Object>)LayeredBorderPaintConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue[], BorderStrokeStyle>[], BorderStrokeStyle[]> parseBorderStyleSeries(final Term term) throws ParseException {
        Term nextInSeries = term;
        final ParsedValueImpl[] array = new ParsedValueImpl[4];
        int n = 0;
        while (nextInSeries != null) {
            array[n++] = this.parseBorderStyle(nextInSeries);
            nextInSeries = nextInSeries.nextInSeries;
        }
        if (n < 2) {
            array[1] = array[0];
        }
        if (n < 3) {
            array[2] = array[0];
        }
        if (n < 4) {
            array[3] = array[1];
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue[], BorderStrokeStyle>[], BorderStrokeStyle[]>(array, (StyleConverter<Object, Object>)BorderStrokeStyleSequenceConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue<ParsedValue[], BorderStrokeStyle>[], BorderStrokeStyle[]>[], BorderStrokeStyle[][]> parseBorderStyleLayers(final Term term) throws ParseException {
        final ParsedValueImpl[] array = new ParsedValueImpl[this.numberOfLayers(term)];
        int n = 0;
        for (Term nextLayer = term; nextLayer != null; nextLayer = this.nextLayer(nextLayer)) {
            array[n++] = this.parseBorderStyleSeries(nextLayer);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue<ParsedValue[], BorderStrokeStyle>[], BorderStrokeStyle[]>[], BorderStrokeStyle[][]>(array, (StyleConverter<Object, Object>)LayeredBorderStyleConverter.getInstance());
    }
    
    private String getKeyword(final Term term) {
        if (term != null && term.token != null && term.token.getType() == 11 && term.token.getText() != null && !term.token.getText().isEmpty()) {
            return term.token.getText().toLowerCase(Locale.ROOT);
        }
        return null;
    }
    
    private ParsedValueImpl<ParsedValue[], BorderStrokeStyle> parseBorderStyle(final Term term) throws ParseException {
        ParsedValue parsedValue = null;
        ParsedValue parsedValue2 = null;
        ParsedValue parsedValue3 = null;
        ParsedValue<String, StrokeLineCap> strokeLineCap = null;
        final ParsedValue<ParsedValue[], Number[]> dashStyle = this.dashStyle(term);
        Term term2 = term;
        Term nextInSeries = term.nextInSeries;
        if ("phase".equals(this.getKeyword(nextInSeries))) {
            final Term nextInSeries2;
            if ((nextInSeries2 = nextInSeries.nextInSeries) == null || nextInSeries2.token == null || !this.isSize(nextInSeries2.token)) {
                this.error(nextInSeries2, "Expected '<size>'");
            }
            parsedValue = new ParsedValueImpl(this.parseSize(nextInSeries2), (StyleConverter<Object, Object>)SizeConverter.getInstance());
            term2 = nextInSeries2;
            nextInSeries = nextInSeries2.nextInSeries;
        }
        final ParsedValueImpl<String, StrokeType> strokeType = this.parseStrokeType(nextInSeries);
        if (strokeType != null) {
            term2 = nextInSeries;
            nextInSeries = nextInSeries.nextInSeries;
        }
        String s = this.getKeyword(nextInSeries);
        if ("line-join".equals(s)) {
            final Term nextInSeries3 = nextInSeries.nextInSeries;
            final ParsedValueImpl[] strokeLineJoin = this.parseStrokeLineJoin(nextInSeries3);
            if (strokeLineJoin != null) {
                parsedValue2 = strokeLineJoin[0];
                parsedValue3 = strokeLineJoin[1];
            }
            else {
                this.error(nextInSeries3, "Expected 'miter <size>?', 'bevel' or 'round'");
            }
            term2 = nextInSeries3;
            nextInSeries = nextInSeries3.nextInSeries;
            s = this.getKeyword(nextInSeries);
        }
        if ("line-cap".equals(s)) {
            final Term nextInSeries4 = nextInSeries.nextInSeries;
            strokeLineCap = this.parseStrokeLineCap(nextInSeries4);
            if (strokeLineCap == null) {
                this.error(nextInSeries4, "Expected 'square', 'butt' or 'round'");
            }
            term2 = nextInSeries4;
            nextInSeries = nextInSeries4.nextInSeries;
        }
        if (nextInSeries != null) {
            term.nextInSeries = nextInSeries;
        }
        else {
            term.nextInSeries = null;
            term.nextLayer = term2.nextLayer;
        }
        return new ParsedValueImpl<ParsedValue[], BorderStrokeStyle>(new ParsedValue[] { dashStyle, parsedValue, strokeType, parsedValue2, parsedValue3, strokeLineCap }, (StyleConverter<Object, Object>)BorderStyleConverter.getInstance());
    }
    
    private ParsedValue<ParsedValue[], Number[]> dashStyle(final Term term) throws ParseException {
        if (term.token == null) {
            this.error(term, "Expected '<dash-style>'");
        }
        final int type = term.token.getType();
        ParsedValue<ParsedValue[], Number[]> parsedValue = null;
        if (type == 11) {
            parsedValue = this.borderStyle(term);
        }
        else if (type == 12) {
            parsedValue = this.segments(term);
        }
        else {
            this.error(term, "Expected '<dash-style>'");
        }
        return parsedValue;
    }
    
    private ParsedValue<ParsedValue[], Number[]> borderStyle(final Term term) throws ParseException {
        if (term.token == null || term.token.getType() != 11 || term.token.getText() == null || term.token.getText().isEmpty()) {
            this.error(term, "Expected '<border-style>'");
        }
        final String lowerCase = term.token.getText().toLowerCase(Locale.ROOT);
        if ("none".equals(lowerCase)) {
            return BorderStyleConverter.NONE;
        }
        if ("hidden".equals(lowerCase)) {
            return BorderStyleConverter.NONE;
        }
        if ("dotted".equals(lowerCase)) {
            return BorderStyleConverter.DOTTED;
        }
        if ("dashed".equals(lowerCase)) {
            return BorderStyleConverter.DASHED;
        }
        if ("solid".equals(lowerCase)) {
            return BorderStyleConverter.SOLID;
        }
        if ("double".equals(lowerCase)) {
            this.error(term, "Unsupported <border-style> 'double'");
        }
        else if ("groove".equals(lowerCase)) {
            this.error(term, "Unsupported <border-style> 'groove'");
        }
        else if ("ridge".equals(lowerCase)) {
            this.error(term, "Unsupported <border-style> 'ridge'");
        }
        else if ("inset".equals(lowerCase)) {
            this.error(term, "Unsupported <border-style> 'inset'");
        }
        else if ("outset".equals(lowerCase)) {
            this.error(term, "Unsupported <border-style> 'outset'");
        }
        else {
            this.error(term, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, lowerCase));
        }
        return BorderStyleConverter.SOLID;
    }
    
    private ParsedValueImpl<ParsedValue[], Number[]> segments(final Term term) throws ParseException {
        if (!"segments".regionMatches(true, 0, (term.token != null) ? term.token.getText() : null, 0, 8)) {
            this.error(term, "Expected 'segments'");
        }
        Term term2 = term.firstArg;
        if (term2 == null) {
            this.error(null, "Expected '<size>'");
        }
        final ParsedValueImpl[] array = new ParsedValueImpl[this.numberOfArgs(term)];
        int n = 0;
        while (term2 != null) {
            array[n++] = this.parseSize(term2);
            term2 = term2.nextArg;
        }
        return new ParsedValueImpl<ParsedValue[], Number[]>(array, (StyleConverter<Object, Object>)SizeConverter.SequenceConverter.getInstance());
    }
    
    private ParsedValueImpl<String, StrokeType> parseStrokeType(final Term term) throws ParseException {
        final String keyword = this.getKeyword(term);
        if ("centered".equals(keyword) || "inside".equals(keyword) || "outside".equals(keyword)) {
            return new ParsedValueImpl<String, StrokeType>(keyword, (StyleConverter<Object, Object>)new EnumConverter((Class<Enum>)StrokeType.class));
        }
        return null;
    }
    
    private ParsedValueImpl[] parseStrokeLineJoin(final Term term) throws ParseException {
        final String keyword = this.getKeyword(term);
        if ("miter".equals(keyword) || "bevel".equals(keyword) || "round".equals(keyword)) {
            final ParsedValueImpl parsedValueImpl = new ParsedValueImpl(keyword, new EnumConverter(StrokeLineJoin.class));
            ParsedValueImpl parsedValueImpl2 = null;
            if ("miter".equals(keyword)) {
                final Term nextInSeries = term.nextInSeries;
                if (nextInSeries != null && nextInSeries.token != null && this.isSize(nextInSeries.token)) {
                    term.nextInSeries = nextInSeries.nextInSeries;
                    parsedValueImpl2 = new ParsedValueImpl(this.parseSize(nextInSeries), (StyleConverter<Object, Object>)SizeConverter.getInstance());
                }
            }
            return new ParsedValueImpl[] { parsedValueImpl, parsedValueImpl2 };
        }
        return null;
    }
    
    private ParsedValueImpl<String, StrokeLineCap> parseStrokeLineCap(final Term term) throws ParseException {
        final String keyword = this.getKeyword(term);
        if ("square".equals(keyword) || "butt".equals(keyword) || "round".equals(keyword)) {
            return new ParsedValueImpl<String, StrokeLineCap>(keyword, (StyleConverter<Object, Object>)new EnumConverter((Class<Enum>)StrokeLineCap.class));
        }
        return null;
    }
    
    private ParsedValueImpl<ParsedValue[], BorderImageSlices> parseBorderImageSlice(final Term term) throws ParseException {
        Term nextInSeries = term;
        if (nextInSeries.token == null || !this.isSize(nextInSeries.token)) {
            this.error(nextInSeries, "Expected '<size>'");
        }
        final ParsedValueImpl[] array = new ParsedValueImpl[4];
        Boolean b = Boolean.FALSE;
        int n = 0;
        while (n < 4 && nextInSeries != null) {
            array[n++] = this.parseSize(nextInSeries);
            if ((nextInSeries = nextInSeries.nextInSeries) != null && nextInSeries.token != null && nextInSeries.token.getType() == 11 && "fill".equalsIgnoreCase(nextInSeries.token.getText())) {
                b = Boolean.TRUE;
                break;
            }
        }
        if (n < 2) {
            array[1] = array[0];
        }
        if (n < 3) {
            array[2] = array[0];
        }
        if (n < 4) {
            array[3] = array[1];
        }
        return new ParsedValueImpl<ParsedValue[], BorderImageSlices>(new ParsedValueImpl[] { new ParsedValueImpl((V)(Object)array, (StyleConverter<V, T>)InsetsConverter.getInstance()), new ParsedValueImpl(b, null) }, (StyleConverter<Object, Object>)BorderImageSliceConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue[], BorderImageSlices>[], BorderImageSlices[]> parseBorderImageSliceLayers(final Term term) throws ParseException {
        final ParsedValueImpl[] array = new ParsedValueImpl[this.numberOfLayers(term)];
        int n = 0;
        for (Term nextLayer = term; nextLayer != null; nextLayer = this.nextLayer(nextLayer)) {
            array[n++] = this.parseBorderImageSlice(nextLayer);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue[], BorderImageSlices>[], BorderImageSlices[]>(array, (StyleConverter<Object, Object>)SliceSequenceConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], BorderWidths> parseBorderImageWidth(final Term term) throws ParseException {
        Term nextInSeries = term;
        if (nextInSeries.token == null || !this.isSize(nextInSeries.token)) {
            this.error(nextInSeries, "Expected '<size>'");
        }
        final ParsedValueImpl[] array = new ParsedValueImpl[4];
        int n = 0;
        while (n < 4 && nextInSeries != null) {
            array[n++] = this.parseSize(nextInSeries);
            if ((nextInSeries = nextInSeries.nextInSeries) != null && nextInSeries.token != null && nextInSeries.token.getType() == 11) {
                continue;
            }
        }
        if (n < 2) {
            array[1] = array[0];
        }
        if (n < 3) {
            array[2] = array[0];
        }
        if (n < 4) {
            array[3] = array[1];
        }
        return new ParsedValueImpl<ParsedValue[], BorderWidths>(array, (StyleConverter<Object, Object>)BorderImageWidthConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue[], BorderWidths>[], BorderWidths[]> parseBorderImageWidthLayers(final Term term) throws ParseException {
        final ParsedValueImpl[] array = new ParsedValueImpl[this.numberOfLayers(term)];
        int n = 0;
        for (Term nextLayer = term; nextLayer != null; nextLayer = this.nextLayer(nextLayer)) {
            array[n++] = this.parseBorderImageWidth(nextLayer);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue[], BorderWidths>[], BorderWidths[]>(array, (StyleConverter<Object, Object>)BorderImageWidthsSequenceConverter.getInstance());
    }
    
    private ParsedValueImpl<String, String> parseRegion(final Term term) throws ParseException {
        if (!"region".regionMatches(true, 0, (term.token != null) ? term.token.getText() : null, 0, 6)) {
            this.error(term, "Expected 'region'");
        }
        final Term firstArg = term.firstArg;
        if (firstArg == null) {
            this.error(term, "Expected 'region(\"<styleclass-or-id-string>\")'");
        }
        if (firstArg.token == null || firstArg.token.getType() != 10 || firstArg.token.getText() == null || firstArg.token.getText().isEmpty()) {
            this.error(term, "Expected 'region(\"<styleclass-or-id-string>\")'");
        }
        return new ParsedValueImpl<String, String>(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, Utils.stripQuotes(firstArg.token.getText())), (StyleConverter<Object, Object>)StringConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], String> parseURI(final Term term) throws ParseException {
        if (term == null) {
            this.error(term, "Expected 'url(\"<uri-string>\")'");
        }
        if (term.token == null || term.token.getType() != 43 || term.token.getText() == null || term.token.getText().isEmpty()) {
            this.error(term, "Expected 'url(\"<uri-string>\")'");
        }
        return new ParsedValueImpl<ParsedValue[], String>(new ParsedValueImpl[] { new ParsedValueImpl((V)term.token.getText(), (StyleConverter<V, T>)StringConverter.getInstance()), null }, URLConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<ParsedValue[], String>[], String[]> parseURILayers(final Term term) throws ParseException {
        final int numberOfLayers = this.numberOfLayers(term);
        Term nextLayer = term;
        int n = 0;
        final ParsedValueImpl[] array = new ParsedValueImpl[numberOfLayers];
        while (nextLayer != null) {
            array[n++] = this.parseURI(nextLayer);
            nextLayer = this.nextLayer(nextLayer);
        }
        return new ParsedValueImpl<ParsedValue<ParsedValue[], String>[], String[]>(array, (StyleConverter<Object, Object>)URLConverter.SequenceConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue<?, Size>, Number> parseFontSize(final Term term) throws ParseException {
        if (term == null) {
            return null;
        }
        final Token token = term.token;
        if (token == null || !this.isSize(token)) {
            this.error(term, "Expected '<font-size>'");
        }
        Object size = null;
        if (token.getType() == 11) {
            final String lowerCase = token.getText().toLowerCase(Locale.ROOT);
            double n = -1.0;
            if ("inherit".equals(lowerCase)) {
                n = 100.0;
            }
            else if ("xx-small".equals(lowerCase)) {
                n = 60.0;
            }
            else if ("x-small".equals(lowerCase)) {
                n = 75.0;
            }
            else if ("small".equals(lowerCase)) {
                n = 80.0;
            }
            else if ("medium".equals(lowerCase)) {
                n = 100.0;
            }
            else if ("large".equals(lowerCase)) {
                n = 120.0;
            }
            else if ("x-large".equals(lowerCase)) {
                n = 150.0;
            }
            else if ("xx-large".equals(lowerCase)) {
                n = 200.0;
            }
            else if ("smaller".equals(lowerCase)) {
                n = 80.0;
            }
            else if ("larger".equals(lowerCase)) {
                n = 120.0;
            }
            if (n > -1.0) {
                size = new Size(n, SizeUnits.PERCENT);
            }
        }
        if (size == null) {
            size = this.size(token);
        }
        return new ParsedValueImpl<ParsedValue<?, Size>, Number>(new ParsedValueImpl<Object, Size>(size, null), (StyleConverter<Object, Object>)FontConverter.FontSizeConverter.getInstance());
    }
    
    private ParsedValueImpl<String, FontPosture> parseFontStyle(final Term term) throws ParseException {
        if (term == null) {
            return null;
        }
        final Token token = term.token;
        if (token == null || token.getType() != 11 || token.getText() == null || token.getText().isEmpty()) {
            this.error(term, "Expected '<font-style>'");
        }
        final String lowerCase = token.getText().toLowerCase(Locale.ROOT);
        FontPosture.REGULAR.name();
        String s;
        if ("normal".equals(lowerCase)) {
            s = FontPosture.REGULAR.name();
        }
        else if ("italic".equals(lowerCase)) {
            s = FontPosture.ITALIC.name();
        }
        else if ("oblique".equals(lowerCase)) {
            s = FontPosture.ITALIC.name();
        }
        else {
            if (!"inherit".equals(lowerCase)) {
                return null;
            }
            s = "inherit";
        }
        return new ParsedValueImpl<String, FontPosture>(s, (StyleConverter<Object, Object>)FontConverter.FontStyleConverter.getInstance());
    }
    
    private ParsedValueImpl<String, FontWeight> parseFontWeight(final Term term) throws ParseException {
        if (term == null) {
            return null;
        }
        final Token token = term.token;
        if (token == null || token.getText() == null || token.getText().isEmpty()) {
            this.error(term, "Expected '<font-weight>'");
        }
        final String lowerCase = token.getText().toLowerCase(Locale.ROOT);
        String s = FontWeight.NORMAL.name();
        if ("inherit".equals(lowerCase)) {
            s = FontWeight.NORMAL.name();
        }
        else if ("normal".equals(lowerCase)) {
            s = FontWeight.NORMAL.name();
        }
        else if ("bold".equals(lowerCase)) {
            s = FontWeight.BOLD.name();
        }
        else if ("bolder".equals(lowerCase)) {
            s = FontWeight.BOLD.name();
        }
        else if ("lighter".equals(lowerCase)) {
            s = FontWeight.LIGHT.name();
        }
        else if ("100".equals(lowerCase)) {
            s = FontWeight.findByWeight(100).name();
        }
        else if ("200".equals(lowerCase)) {
            s = FontWeight.findByWeight(200).name();
        }
        else if ("300".equals(lowerCase)) {
            s = FontWeight.findByWeight(300).name();
        }
        else if ("400".equals(lowerCase)) {
            s = FontWeight.findByWeight(400).name();
        }
        else if ("500".equals(lowerCase)) {
            s = FontWeight.findByWeight(500).name();
        }
        else if ("600".equals(lowerCase)) {
            s = FontWeight.findByWeight(600).name();
        }
        else if ("700".equals(lowerCase)) {
            s = FontWeight.findByWeight(700).name();
        }
        else if ("800".equals(lowerCase)) {
            s = FontWeight.findByWeight(800).name();
        }
        else if ("900".equals(lowerCase)) {
            s = FontWeight.findByWeight(900).name();
        }
        else {
            this.error(term, "Expected '<font-weight>'");
        }
        return new ParsedValueImpl<String, FontWeight>(s, (StyleConverter<Object, Object>)FontConverter.FontWeightConverter.getInstance());
    }
    
    private ParsedValueImpl<String, String> parseFontFamily(final Term term) throws ParseException {
        if (term == null) {
            return null;
        }
        final Token token = term.token;
        String text = null;
        if (token == null || (token.getType() != 11 && token.getType() != 10) || (text = token.getText()) == null || text.isEmpty()) {
            this.error(term, "Expected '<font-family>'");
        }
        final String stripQuotes = this.stripQuotes(text.toLowerCase(Locale.ROOT));
        if ("inherit".equals(stripQuotes)) {
            return new ParsedValueImpl<String, String>("inherit", StringConverter.getInstance());
        }
        if ("serif".equals(stripQuotes) || "sans-serif".equals(stripQuotes) || "cursive".equals(stripQuotes) || "fantasy".equals(stripQuotes) || "monospace".equals(stripQuotes)) {
            return new ParsedValueImpl<String, String>(stripQuotes, (StyleConverter<Object, Object>)StringConverter.getInstance());
        }
        return new ParsedValueImpl<String, String>(token.getText(), (StyleConverter<Object, Object>)StringConverter.getInstance());
    }
    
    private ParsedValueImpl<ParsedValue[], Font> parseFont(Term nextInSeries) throws ParseException {
        Term nextInSeries2 = nextInSeries.nextInSeries;
        nextInSeries.nextInSeries = null;
        while (nextInSeries2 != null) {
            final Term nextInSeries3 = nextInSeries2.nextInSeries;
            nextInSeries2.nextInSeries = nextInSeries;
            nextInSeries = nextInSeries2;
            nextInSeries2 = nextInSeries3;
        }
        final int type = nextInSeries.token.getType();
        if (type != 11 && type != 10) {
            this.error(nextInSeries, "Expected '<font-family>'");
        }
        final ParsedValueImpl<String, String> fontFamily = this.parseFontFamily(nextInSeries);
        Term term;
        if ((term = nextInSeries.nextInSeries) == null) {
            this.error(nextInSeries, "Expected '<size>'");
        }
        if (term.token == null || !this.isSize(term.token)) {
            this.error(term, "Expected '<size>'");
        }
        final Term nextInSeries4;
        if ((nextInSeries4 = term.nextInSeries) != null && nextInSeries4.token != null && nextInSeries4.token.getType() == 32) {
            nextInSeries = nextInSeries4;
            if ((term = nextInSeries4.nextInSeries) == null) {
                this.error(nextInSeries, "Expected '<size>'");
            }
            if (term.token == null || !this.isSize(term.token)) {
                this.error(term, "Expected '<size>'");
            }
            final Token token = term.token;
        }
        final ParsedValueImpl<ParsedValue<?, Size>, Number> fontSize = this.parseFontSize(term);
        if (fontSize == null) {
            this.error(nextInSeries, "Expected '<size>'");
        }
        ParsedValueImpl<String, FontPosture> fontStyle = null;
        ParsedValueImpl<String, FontWeight> fontWeight = null;
        String text = null;
        while ((term = term.nextInSeries) != null) {
            if (term.token == null || term.token.getType() != 11 || term.token.getText() == null || term.token.getText().isEmpty()) {
                this.error(term, "Expected '<font-weight>', '<font-style>' or '<font-variant>'");
            }
            if (fontStyle == null && (fontStyle = this.parseFontStyle(term)) != null) {
                continue;
            }
            if (text == null && "small-caps".equalsIgnoreCase(term.token.getText())) {
                text = term.token.getText();
            }
            else {
                if (fontWeight == null && (fontWeight = this.parseFontWeight(term)) != null) {
                    continue;
                }
                continue;
            }
        }
        return new ParsedValueImpl<ParsedValue[], Font>(new ParsedValueImpl[] { fontFamily, fontSize, fontWeight, fontStyle }, (StyleConverter<Object, Object>)FontConverter.getInstance());
    }
    
    private Token nextToken(final CssLexer cssLexer) {
        Token nextToken;
        do {
            nextToken = cssLexer.nextToken();
        } while ((nextToken != null && nextToken.getType() == 40) || nextToken.getType() == 41);
        if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.FINEST)) {
            CssParser.LOGGER.finest(nextToken.toString());
        }
        return nextToken;
    }
    
    private void parse(final Stylesheet stylesheet, final CssLexer cssLexer) {
        this.currentToken = this.nextToken(cssLexer);
        while (this.currentToken != null && this.currentToken.getType() == 47) {
            this.currentToken = this.nextToken(cssLexer);
            if (this.currentToken == null || this.currentToken.getType() != 11) {
                final ParseError error = this.createError(new ParseException("Expected IDENT", this.currentToken, this).toString());
                if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                    CssParser.LOGGER.warning(error.toString());
                }
                this.reportError(error);
                do {
                    this.currentToken = cssLexer.nextToken();
                } while ((this.currentToken != null && this.currentToken.getType() == 30) || this.currentToken.getType() == 40 || this.currentToken.getType() == 41);
            }
            else {
                final String lowerCase = this.currentToken.getText().toLowerCase(Locale.ROOT);
                if ("font-face".equals(lowerCase)) {
                    final FontFace fontFace = this.fontFace(cssLexer);
                    if (fontFace != null) {
                        stylesheet.getFontFaces().add(fontFace);
                    }
                    this.currentToken = this.nextToken(cssLexer);
                }
                else {
                    if (!"import".equals(lowerCase)) {
                        continue;
                    }
                    if (CssParser.imports == null) {
                        CssParser.imports = new Stack<String>();
                    }
                    if (!CssParser.imports.contains(this.sourceOfStylesheet)) {
                        CssParser.imports.push(this.sourceOfStylesheet);
                        final Stylesheet handleImport = this.handleImport(cssLexer);
                        if (handleImport != null) {
                            stylesheet.importStylesheet(handleImport);
                        }
                        CssParser.imports.pop();
                        if (CssParser.imports.isEmpty()) {
                            CssParser.imports = null;
                        }
                    }
                    else {
                        final ParseError error2 = this.createError(MessageFormat.format("Recursive @import at {2} [{0,number,#},{1,number,#}]", this.currentToken.getLine(), this.currentToken.getOffset(), CssParser.imports.peek()));
                        if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                            CssParser.LOGGER.warning(error2.toString());
                        }
                        this.reportError(error2);
                    }
                    do {
                        this.currentToken = cssLexer.nextToken();
                    } while ((this.currentToken != null && this.currentToken.getType() == 30) || this.currentToken.getType() == 40 || this.currentToken.getType() == 41);
                }
            }
        }
        while (this.currentToken != null && this.currentToken.getType() != -1) {
            final List<Selector> selectors = this.selectors(cssLexer);
            if (selectors == null) {
                return;
            }
            if (this.currentToken == null || this.currentToken.getType() != 28) {
                final ParseError error3 = this.createError(MessageFormat.format("Expected LBRACE at [{0,number,#},{1,number,#}]", (this.currentToken != null) ? this.currentToken.getLine() : -1, (this.currentToken != null) ? this.currentToken.getOffset() : -1));
                if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                    CssParser.LOGGER.warning(error3.toString());
                }
                this.reportError(error3);
                this.currentToken = null;
                return;
            }
            this.currentToken = this.nextToken(cssLexer);
            final List<Declaration> declarations = this.declarations(cssLexer);
            if (declarations == null) {
                return;
            }
            if (this.currentToken != null && this.currentToken.getType() != 29) {
                final ParseError error4 = this.createError(MessageFormat.format("Expected RBRACE at [{0,number,#},{1,number,#}]", this.currentToken.getLine(), this.currentToken.getOffset()));
                if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                    CssParser.LOGGER.warning(error4.toString());
                }
                this.reportError(error4);
                this.currentToken = null;
                return;
            }
            stylesheet.getRules().add(new Rule(selectors, declarations));
            this.currentToken = this.nextToken(cssLexer);
        }
        this.currentToken = null;
    }
    
    private FontFace fontFace(final CssLexer cssLexer) {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        final ArrayList<FontFaceImpl.FontFaceSrc> list = new ArrayList<FontFaceImpl.FontFaceSrc>();
        do {
            this.currentToken = this.nextToken(cssLexer);
            if (this.currentToken.getType() == 11) {
                final String text = this.currentToken.getText();
                this.currentToken = this.nextToken(cssLexer);
                this.currentToken = this.nextToken(cssLexer);
                if ("src".equalsIgnoreCase(text)) {
                    while (this.currentToken != null && this.currentToken.getType() != 30 && this.currentToken.getType() != 29 && this.currentToken.getType() != -1) {
                        if (this.currentToken.getType() == 11) {
                            list.add(new FontFaceImpl.FontFaceSrc(FontFaceImpl.FontFaceSrcType.REFERENCE, this.currentToken.getText()));
                        }
                        else if (this.currentToken.getType() == 43) {
                            final String str = new ParsedValueImpl<Object, String>((V)(Object)new ParsedValueImpl[] { new ParsedValueImpl((V)this.currentToken.getText(), (StyleConverter<V, T>)StringConverter.getInstance()), new ParsedValueImpl((V)this.sourceOfStylesheet, null) }, (StyleConverter<V, String>)URLConverter.getInstance()).convert(null);
                            URL url = null;
                            try {
                                url = new URI(str).toURL();
                            }
                            catch (URISyntaxException | MalformedURLException ex) {
                                final ParseError error = this.createError(MessageFormat.format("Could not resolve @font-face url [{2}] at [{0,number,#},{1,number,#}]", this.currentToken.getLine(), this.currentToken.getOffset(), str));
                                if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                                    CssParser.LOGGER.warning(error.toString());
                                }
                                this.reportError(error);
                                while (this.currentToken != null) {
                                    final int type = this.currentToken.getType();
                                    if (type == 29 || type == -1) {
                                        return null;
                                    }
                                    this.currentToken = this.nextToken(cssLexer);
                                }
                            }
                            String stripQuotes = null;
                            while (true) {
                                this.currentToken = this.nextToken(cssLexer);
                                final int n = (this.currentToken != null) ? this.currentToken.getType() : -1;
                                if (n == 12) {
                                    if ("format(".equalsIgnoreCase(this.currentToken.getText())) {
                                        continue;
                                    }
                                    break;
                                }
                                else if (n == 11 || n == 10) {
                                    stripQuotes = Utils.stripQuotes(this.currentToken.getText());
                                }
                                else {
                                    if (n == 35) {
                                        continue;
                                    }
                                    break;
                                }
                            }
                            list.add(new FontFaceImpl.FontFaceSrc(FontFaceImpl.FontFaceSrcType.URL, url.toExternalForm(), stripQuotes));
                        }
                        else if (this.currentToken.getType() == 12) {
                            if ("local(".equalsIgnoreCase(this.currentToken.getText())) {
                                this.currentToken = this.nextToken(cssLexer);
                                final StringBuilder sb = new StringBuilder();
                                while (this.currentToken != null && this.currentToken.getType() != 35 && this.currentToken.getType() != -1) {
                                    sb.append(this.currentToken.getText());
                                    this.currentToken = this.nextToken(cssLexer);
                                }
                                int n2 = 0;
                                int length = sb.length();
                                if (sb.charAt(n2) == '\'' || sb.charAt(n2) == '\"') {
                                    ++n2;
                                }
                                if (sb.charAt(length - 1) == '\'' || sb.charAt(length - 1) == '\"') {
                                    --length;
                                }
                                list.add(new FontFaceImpl.FontFaceSrc(FontFaceImpl.FontFaceSrcType.LOCAL, sb.substring(n2, length)));
                            }
                            else {
                                final ParseError error2 = this.createError(MessageFormat.format(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.currentToken.getText()), new Object[] { this.currentToken.getLine(), this.currentToken.getOffset() }));
                                if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                                    CssParser.LOGGER.warning(error2.toString());
                                }
                                this.reportError(error2);
                            }
                        }
                        else if (this.currentToken.getType() != 36) {
                            final ParseError error3 = this.createError(MessageFormat.format(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.currentToken.getText()), new Object[] { this.currentToken.getLine(), this.currentToken.getOffset() }));
                            if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                                CssParser.LOGGER.warning(error3.toString());
                            }
                            this.reportError(error3);
                        }
                        this.currentToken = this.nextToken(cssLexer);
                    }
                }
                else {
                    final StringBuilder sb2 = new StringBuilder();
                    while (this.currentToken != null && this.currentToken.getType() != 30 && this.currentToken.getType() != -1) {
                        sb2.append(this.currentToken.getText());
                        this.currentToken = this.nextToken(cssLexer);
                    }
                    hashMap.put(text, sb2.toString());
                }
            }
        } while (this.currentToken != null && this.currentToken.getType() != 29 && this.currentToken.getType() != -1);
        return new FontFaceImpl(hashMap, list);
    }
    
    private Stylesheet handleImport(final CssLexer cssLexer) {
        this.currentToken = this.nextToken(cssLexer);
        if (this.currentToken == null || this.currentToken.getType() == -1) {
            return null;
        }
        final int type = this.currentToken.getType();
        Object text = null;
        if (type == 10 || type == 43) {
            text = this.currentToken.getText();
        }
        Stylesheet loadStylesheet = null;
        final String sourceOfStylesheet = this.sourceOfStylesheet;
        if (text != null) {
            loadStylesheet = StyleManager.loadStylesheet(new ParsedValueImpl<Object, String>((V)(Object)new ParsedValueImpl[] { new ParsedValueImpl((V)text, (StyleConverter<V, T>)StringConverter.getInstance()), new ParsedValueImpl((V)this.sourceOfStylesheet, null) }, (StyleConverter<V, String>)URLConverter.getInstance()).convert(null));
            this.sourceOfStylesheet = sourceOfStylesheet;
        }
        if (loadStylesheet == null) {
            final ParseError error = this.createError(MessageFormat.format("Could not import {0}", text));
            if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                CssParser.LOGGER.warning(error.toString());
            }
            this.reportError(error);
        }
        return loadStylesheet;
    }
    
    private List<Selector> selectors(final CssLexer cssLexer) {
        final ArrayList<Selector> list = new ArrayList<Selector>();
        while (true) {
            final Selector selector = this.selector(cssLexer);
            if (selector == null) {
                while (this.currentToken != null && this.currentToken.getType() != 29 && this.currentToken.getType() != -1) {
                    this.currentToken = this.nextToken(cssLexer);
                }
                this.currentToken = this.nextToken(cssLexer);
                if (this.currentToken == null || this.currentToken.getType() == -1) {
                    this.currentToken = null;
                    return null;
                }
                continue;
            }
            else {
                list.add(selector);
                if (this.currentToken == null || this.currentToken.getType() != 36) {
                    return list;
                }
                this.currentToken = this.nextToken(cssLexer);
            }
        }
    }
    
    private Selector selector(final CssLexer cssLexer) {
        List<Combinator> list = null;
        List<SimpleSelector> list2 = null;
        final SimpleSelector simpleSelector = this.simpleSelector(cssLexer);
        if (simpleSelector == null) {
            return null;
        }
        while (true) {
            final Combinator combinator = this.combinator(cssLexer);
            if (combinator != null) {
                if (list == null) {
                    list = new ArrayList<Combinator>();
                }
                list.add(combinator);
                final SimpleSelector simpleSelector2 = this.simpleSelector(cssLexer);
                if (simpleSelector2 == null) {
                    return null;
                }
                if (list2 == null) {
                    list2 = new ArrayList<SimpleSelector>();
                    list2.add(simpleSelector);
                }
                list2.add(simpleSelector2);
            }
            else {
                if (this.currentToken != null && this.currentToken.getType() == 41) {
                    this.currentToken = this.nextToken(cssLexer);
                }
                if (list2 == null) {
                    return simpleSelector;
                }
                return new CompoundSelector(list2, list);
            }
        }
    }
    
    private SimpleSelector simpleSelector(final CssLexer cssLexer) {
        String text = "*";
        String substring = "";
        List<String> list = null;
        List<String> list2 = null;
        while (true) {
            switch ((this.currentToken != null) ? this.currentToken.getType() : 0) {
                case 11:
                case 33: {
                    text = this.currentToken.getText();
                    break;
                }
                case 38: {
                    this.currentToken = this.nextToken(cssLexer);
                    if (this.currentToken != null && this.currentToken.getType() == 11) {
                        if (list == null) {
                            list = new ArrayList<String>();
                        }
                        list.add(this.currentToken.getText());
                        break;
                    }
                    this.currentToken = Token.INVALID_TOKEN;
                    return null;
                }
                case 37: {
                    substring = this.currentToken.getText().substring(1);
                    break;
                }
                case 31: {
                    this.currentToken = this.nextToken(cssLexer);
                    if (this.currentToken != null && list2 == null) {
                        list2 = new ArrayList<String>();
                    }
                    if (this.currentToken.getType() == 11) {
                        list2.add(this.currentToken.getText());
                    }
                    else if (this.currentToken.getType() == 12) {
                        list2.add(this.functionalPseudo(cssLexer));
                    }
                    else {
                        this.currentToken = Token.INVALID_TOKEN;
                    }
                    if (this.currentToken.getType() == 0) {
                        return null;
                    }
                    break;
                }
                case -1:
                case 27:
                case 28:
                case 36:
                case 40:
                case 41: {
                    return new SimpleSelector(text, list, list2, substring);
                }
                default: {
                    return null;
                }
            }
            this.currentToken = cssLexer.nextToken();
            if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.FINEST)) {
                CssParser.LOGGER.finest(this.currentToken.toString());
            }
        }
    }
    
    private String functionalPseudo(final CssLexer cssLexer) {
        final StringBuilder sb = new StringBuilder(this.currentToken.getText());
        while (true) {
            this.currentToken = this.nextToken(cssLexer);
            switch (this.currentToken.getType()) {
                case 10:
                case 11: {
                    sb.append(this.currentToken.getText());
                    continue;
                }
                case 35: {
                    sb.append(')');
                    return sb.toString();
                }
                default: {
                    this.currentToken = Token.INVALID_TOKEN;
                    return null;
                }
            }
        }
    }
    
    private Combinator combinator(final CssLexer cssLexer) {
        Combinator combinator = null;
        while (true) {
            switch ((this.currentToken != null) ? this.currentToken.getType() : 0) {
                case 40: {
                    if (combinator == null && " ".equals(this.currentToken.getText())) {
                        combinator = Combinator.DESCENDANT;
                        break;
                    }
                    break;
                }
                case 27: {
                    combinator = Combinator.CHILD;
                    break;
                }
                case 11:
                case 31:
                case 33:
                case 37:
                case 38: {
                    return combinator;
                }
                default: {
                    return null;
                }
            }
            this.currentToken = cssLexer.nextToken();
            if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.FINEST)) {
                CssParser.LOGGER.finest(this.currentToken.toString());
            }
        }
    }
    
    private List<Declaration> declarations(final CssLexer cssLexer) {
        final ArrayList<Declaration> list = new ArrayList<Declaration>();
        while (true) {
            final Declaration declaration = this.declaration(cssLexer);
            if (declaration != null) {
                list.add(declaration);
            }
            else {
                while (this.currentToken != null && this.currentToken.getType() != 30 && this.currentToken.getType() != 29 && this.currentToken.getType() != -1) {
                    this.currentToken = this.nextToken(cssLexer);
                }
                if (this.currentToken != null && this.currentToken.getType() != 30) {
                    return list;
                }
            }
            while (this.currentToken != null && this.currentToken.getType() == 30) {
                this.currentToken = this.nextToken(cssLexer);
            }
            if (this.currentToken != null && this.currentToken.getType() == 11) {
                continue;
            }
            return list;
        }
    }
    
    private Declaration declaration(final CssLexer cssLexer) {
        final int n = (this.currentToken != null) ? this.currentToken.getType() : 0;
        if (this.currentToken == null || this.currentToken.getType() != 11) {
            return null;
        }
        final String text = this.currentToken.getText();
        this.currentToken = this.nextToken(cssLexer);
        if (this.currentToken == null || this.currentToken.getType() != 31) {
            final ParseError error = this.createError(MessageFormat.format("Expected COLON at [{0,number,#},{1,number,#}]", this.currentToken.getLine(), this.currentToken.getOffset()));
            if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                CssParser.LOGGER.warning(error.toString());
            }
            this.reportError(error);
            return null;
        }
        this.currentToken = this.nextToken(cssLexer);
        final Term expr = this.expr(cssLexer);
        ParsedValueImpl parsedValueImpl;
        try {
            parsedValueImpl = ((expr != null) ? this.valueFor(text, expr, cssLexer) : null);
        }
        catch (ParseException ex) {
            final Token access$300 = ex.tok;
            final ParseError error2 = this.createError(MessageFormat.format("{2} while parsing ''{3}'' at [{0,number,#},{1,number,#}]", (access$300 != null) ? access$300.getLine() : -1, (access$300 != null) ? access$300.getOffset() : -1, ex.getMessage(), text));
            if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                CssParser.LOGGER.warning(error2.toString());
            }
            this.reportError(error2);
            return null;
        }
        final boolean b = this.currentToken.getType() == 39;
        if (b) {
            this.currentToken = this.nextToken(cssLexer);
        }
        return (parsedValueImpl != null) ? new Declaration(text.toLowerCase(Locale.ROOT), parsedValueImpl, b) : null;
    }
    
    private Term expr(final CssLexer cssLexer) {
        Term term2;
        final Term term = term2 = this.term(cssLexer);
        while (true) {
            final int n = (term2 != null && this.currentToken != null) ? this.currentToken.getType() : 0;
            if (n == 0) {
                this.skipExpr(cssLexer);
                return null;
            }
            if (n == 30 || n == 39 || n == 29 || n == -1) {
                return term;
            }
            if (n == 36) {
                this.currentToken = this.nextToken(cssLexer);
                final Term term3 = term2;
                final Term term4 = this.term(cssLexer);
                term3.nextLayer = term4;
                term2 = term4;
            }
            else {
                final Term term5 = term2;
                final Term term6 = this.term(cssLexer);
                term5.nextInSeries = term6;
                term2 = term6;
            }
        }
    }
    
    private void skipExpr(final CssLexer cssLexer) {
        int n;
        do {
            this.currentToken = this.nextToken(cssLexer);
            n = ((this.currentToken != null) ? this.currentToken.getType() : 0);
        } while (n != 30 && n != 29 && n != -1);
    }
    
    private Term term(final CssLexer cssLexer) {
        switch ((this.currentToken != null) ? this.currentToken.getType() : 0) {
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 45:
            case 46: {
                break;
            }
            case 10: {
                break;
            }
            case 11: {
                break;
            }
            case 37: {
                break;
            }
            case 12:
            case 34: {
                final Term term = new Term(this.currentToken);
                this.currentToken = this.nextToken(cssLexer);
                Term term2 = this.term(cssLexer);
                term.firstArg = term2;
                while (true) {
                    final int n = (this.currentToken != null) ? this.currentToken.getType() : 0;
                    if (n == 35) {
                        break;
                    }
                    if (n == 36) {
                        this.currentToken = this.nextToken(cssLexer);
                        final Term term3 = term2;
                        final Term term4 = this.term(cssLexer);
                        term3.nextArg = term4;
                        term2 = term4;
                    }
                    else {
                        final Term term5 = term2;
                        final Term term6 = this.term(cssLexer);
                        term5.nextInSeries = term6;
                        term2 = term6;
                    }
                }
                this.currentToken = this.nextToken(cssLexer);
                return term;
            }
            case 43: {
                break;
            }
            case 32: {
                break;
            }
            default: {
                final ParseError error = this.createError(MessageFormat.format("Unexpected token {0}{1}{0} at [{2,number,#},{3,number,#}]", "'", (this.currentToken != null) ? this.currentToken.getText() : "", (this.currentToken != null) ? this.currentToken.getLine() : -1, (this.currentToken != null) ? this.currentToken.getOffset() : -1));
                if (CssParser.LOGGER.isLoggable(PlatformLogger.Level.WARNING)) {
                    CssParser.LOGGER.warning(error.toString());
                }
                this.reportError(error);
                return null;
            }
        }
        final Term term7 = new Term(this.currentToken);
        this.currentToken = this.nextToken(cssLexer);
        return term7;
    }
    
    public static ObservableList<ParseError> errorsProperty() {
        return StyleManager.errorsProperty();
    }
    
    static {
        LOGGER = Logging.getCSSLogger();
        ZERO_PERCENT = new ParsedValueImpl<Size, Size>(new Size(0.0, SizeUnits.PERCENT), null);
        FIFTY_PERCENT = new ParsedValueImpl<Size, Size>(new Size(50.0, SizeUnits.PERCENT), null);
        ONE_HUNDRED_PERCENT = new ParsedValueImpl<Size, Size>(new Size(100.0, SizeUnits.PERCENT), null);
    }
    
    private static final class ParseException extends Exception
    {
        private final Token tok;
        private final String source;
        
        ParseException(final String s) {
            this(s, null, null);
        }
        
        ParseException(final String message, final Token tok, final CssParser cssParser) {
            super(message);
            this.tok = tok;
            if (cssParser.sourceOfStylesheet != null) {
                this.source = cssParser.sourceOfStylesheet;
            }
            else if (cssParser.sourceOfInlineStyle != null) {
                this.source = cssParser.sourceOfInlineStyle.toString();
            }
            else if (cssParser.stylesheetAsText != null) {
                this.source = cssParser.stylesheetAsText;
            }
            else {
                this.source = "?";
            }
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder(super.getMessage());
            sb.append(this.source);
            if (this.tok != null) {
                sb.append(": ").append(this.tok.toString());
            }
            return sb.toString();
        }
    }
    
    static class Term
    {
        final Token token;
        Term nextInSeries;
        Term nextLayer;
        Term firstArg;
        Term nextArg;
        
        Term(final Token token) {
            this.token = token;
            this.nextLayer = null;
            this.nextInSeries = null;
            this.firstArg = null;
            this.nextArg = null;
        }
        
        Term() {
            this(null);
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            if (this.token != null) {
                sb.append(String.valueOf(this.token.getText()));
            }
            if (this.nextInSeries != null) {
                sb.append("<nextInSeries>");
                sb.append(this.nextInSeries.toString());
                sb.append("</nextInSeries>\n");
            }
            if (this.nextLayer != null) {
                sb.append("<nextLayer>");
                sb.append(this.nextLayer.toString());
                sb.append("</nextLayer>\n");
            }
            if (this.firstArg != null) {
                sb.append("<args>");
                sb.append(this.firstArg.toString());
                if (this.nextArg != null) {
                    sb.append(this.nextArg.toString());
                }
                sb.append("</args>");
            }
            return sb.toString();
        }
    }
    
    public static class ParseError
    {
        final String message;
        
        public final String getMessage() {
            return this.message;
        }
        
        public ParseError(final String message) {
            this.message = message;
        }
        
        @Override
        public String toString() {
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.message);
        }
        
        public static final class StylesheetParsingError extends ParseError
        {
            private final String url;
            
            StylesheetParsingError(final String url, final String s) {
                super(s);
                this.url = url;
            }
            
            String getURL() {
                return this.url;
            }
            
            @Override
            public String toString() {
                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, (this.url != null) ? this.url : "?", this.message);
            }
        }
        
        public static final class InlineStyleParsingError extends ParseError
        {
            private final Styleable styleable;
            
            InlineStyleParsingError(final Styleable styleable, final String s) {
                super(s);
                this.styleable = styleable;
            }
            
            Styleable getStyleable() {
                return this.styleable;
            }
            
            @Override
            public String toString() {
                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, this.styleable.getStyle(), this.styleable.toString(), this.message);
            }
        }
        
        public static final class StringParsingError extends ParseError
        {
            private final String style;
            
            StringParsingError(final String style, final String s) {
                super(s);
                this.style = style;
            }
            
            String getStyle() {
                return this.style;
            }
            
            @Override
            public String toString() {
                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, this.style, this.message);
            }
        }
        
        public static final class PropertySetError extends ParseError
        {
            private final CssMetaData styleableProperty;
            private final Styleable styleable;
            
            public PropertySetError(final CssMetaData styleableProperty, final Styleable styleable, final String s) {
                super(s);
                this.styleableProperty = styleableProperty;
                this.styleable = styleable;
            }
            
            Styleable getStyleable() {
                return this.styleable;
            }
            
            CssMetaData getProperty() {
                return this.styleableProperty;
            }
            
            @Override
            public String toString() {
                return invokedynamic(makeConcatWithConstants:(Ljavafx/css/CssMetaData;Ljava/lang/String;)Ljava/lang/String;, this.styleableProperty, this.message);
            }
        }
    }
}
