// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.NamedArg;

public class SimpleStyleableObjectProperty<T> extends StyleableObjectProperty<T>
{
    private static final Object DEFAULT_BEAN;
    private static final String DEFAULT_NAME = "";
    private final Object bean;
    private final String name;
    private final CssMetaData<? extends Styleable, T> cssMetaData;
    
    public SimpleStyleableObjectProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, T> cssMetaData) {
        this(cssMetaData, SimpleStyleableObjectProperty.DEFAULT_BEAN, "");
    }
    
    public SimpleStyleableObjectProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, T> cssMetaData, @NamedArg("initialValue") final T t) {
        this((CssMetaData<? extends Styleable, Object>)cssMetaData, SimpleStyleableObjectProperty.DEFAULT_BEAN, "", t);
    }
    
    public SimpleStyleableObjectProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, T> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s) {
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    public SimpleStyleableObjectProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, T> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s, @NamedArg("initialValue") final T t) {
        super(t);
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    @Override
    public Object getBean() {
        return this.bean;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public final CssMetaData<? extends Styleable, T> getCssMetaData() {
        return this.cssMetaData;
    }
    
    static {
        DEFAULT_BEAN = null;
    }
}
