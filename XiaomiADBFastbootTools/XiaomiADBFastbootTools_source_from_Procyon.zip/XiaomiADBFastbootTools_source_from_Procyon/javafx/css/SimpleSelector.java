// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.DataOutputStream;
import java.util.Collection;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import java.util.Set;
import java.util.Iterator;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import javafx.geometry.NodeOrientation;
import com.sun.javafx.css.PseudoClassState;
import com.sun.javafx.css.StyleClassSet;

public final class SimpleSelector extends Selector
{
    private final String name;
    private final StyleClassSet styleClassSet;
    private final String id;
    private final PseudoClassState pseudoClassState;
    private final boolean matchOnName;
    private final boolean matchOnId;
    private final boolean matchOnStyleClass;
    private final NodeOrientation nodeOrientation;
    
    public String getName() {
        return this.name;
    }
    
    public List<String> getStyleClasses() {
        final ArrayList<String> list = new ArrayList<String>();
        final Iterator iterator = this.styleClassSet.iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next().getStyleClassName());
        }
        return (List<String>)Collections.unmodifiableList((List<?>)list);
    }
    
    public Set<StyleClass> getStyleClassSet() {
        return this.styleClassSet;
    }
    
    public String getId() {
        return this.id;
    }
    
    Set<PseudoClass> getPseudoClassStates() {
        return this.pseudoClassState;
    }
    
    List<String> getPseudoclasses() {
        final ArrayList<String> list = new ArrayList<String>();
        final Iterator iterator = this.pseudoClassState.iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next().getPseudoClassName());
        }
        if (this.nodeOrientation == NodeOrientation.RIGHT_TO_LEFT) {
            list.add("dir(rtl)");
        }
        else if (this.nodeOrientation == NodeOrientation.LEFT_TO_RIGHT) {
            list.add("dir(ltr)");
        }
        return (List<String>)Collections.unmodifiableList((List<?>)list);
    }
    
    public NodeOrientation getNodeOrientation() {
        return this.nodeOrientation;
    }
    
    SimpleSelector(final String s, final List<String> list, final List<String> list2, final String anObject) {
        this.name = ((s == null) ? "*" : s);
        this.matchOnName = (s != null && !"".equals(s) && !"*".equals(s));
        this.styleClassSet = new StyleClassSet();
        for (int n = (list != null) ? list.size() : 0, i = 0; i < n; ++i) {
            final String s2 = list.get(i);
            if (s2 != null) {
                if (!s2.isEmpty()) {
                    this.styleClassSet.add((Object)StyleClassSet.getStyleClass(s2));
                }
            }
        }
        this.matchOnStyleClass = (this.styleClassSet.size() > 0);
        this.pseudoClassState = new PseudoClassState();
        final int n2 = (list2 != null) ? list2.size() : 0;
        NodeOrientation inherit = NodeOrientation.INHERIT;
        for (int j = 0; j < n2; ++j) {
            final String s3 = list2.get(j);
            if (s3 != null) {
                if (!s3.isEmpty()) {
                    if ("dir(".regionMatches(true, 0, s3, 0, 4)) {
                        inherit = ("dir(rtl)".equalsIgnoreCase(s3) ? NodeOrientation.RIGHT_TO_LEFT : NodeOrientation.LEFT_TO_RIGHT);
                    }
                    else {
                        this.pseudoClassState.add((Object)PseudoClassState.getPseudoClass(s3));
                    }
                }
            }
        }
        this.nodeOrientation = inherit;
        this.id = ((anObject == null) ? "" : anObject);
        this.matchOnId = (anObject != null && !"".equals(anObject));
    }
    
    @Override
    public Match createMatch() {
        return new Match(this, this.pseudoClassState, this.matchOnId ? 1 : 0, this.styleClassSet.size());
    }
    
    @Override
    public boolean applies(final Styleable styleable) {
        Label_0058: {
            if (this.nodeOrientation != NodeOrientation.INHERIT && styleable instanceof Node) {
                final Node node = (Node)styleable;
                final NodeOrientation nodeOrientation = node.getNodeOrientation();
                if (nodeOrientation == NodeOrientation.INHERIT) {
                    if (node.getEffectiveNodeOrientation() == this.nodeOrientation) {
                        break Label_0058;
                    }
                }
                else if (nodeOrientation == this.nodeOrientation) {
                    break Label_0058;
                }
                return false;
            }
        }
        if (this.matchOnId && !this.id.equals(styleable.getId())) {
            return false;
        }
        if (this.matchOnName && !this.name.equals(styleable.getTypeSelector())) {
            return false;
        }
        if (this.matchOnStyleClass) {
            final StyleClassSet set = new StyleClassSet();
            final ObservableList<String> styleClass = styleable.getStyleClass();
            for (int i = 0; i < styleClass.size(); ++i) {
                final String s = styleClass.get(i);
                if (s != null) {
                    if (!s.isEmpty()) {
                        set.add((Object)StyleClassSet.getStyleClass(s));
                    }
                }
            }
            if (!this.matchStyleClasses(set)) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public boolean applies(final Styleable styleable, final Set<PseudoClass>[] array, final int n) {
        final boolean applies = this.applies(styleable);
        if (applies && array != null && n < array.length) {
            if (array[n] == null) {
                array[n] = new PseudoClassState();
            }
            array[n].addAll(this.pseudoClassState);
        }
        return applies;
    }
    
    @Override
    public boolean stateMatches(final Styleable styleable, final Set<PseudoClass> set) {
        return set != null && set.containsAll(this.pseudoClassState);
    }
    
    private boolean matchStyleClasses(final StyleClassSet set) {
        return set.containsAll(this.styleClassSet);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        final SimpleSelector simpleSelector = (SimpleSelector)o;
        Label_0057: {
            if (this.name == null) {
                if (simpleSelector.name == null) {
                    break Label_0057;
                }
            }
            else if (this.name.equals(simpleSelector.name)) {
                break Label_0057;
            }
            return false;
        }
        if (this.id == null) {
            if (simpleSelector.id == null) {
                return this.styleClassSet.equals(simpleSelector.styleClassSet) && this.pseudoClassState.equals(simpleSelector.pseudoClassState);
            }
        }
        else if (this.id.equals(simpleSelector.id)) {
            return this.styleClassSet.equals(simpleSelector.styleClassSet) && this.pseudoClassState.equals(simpleSelector.pseudoClassState);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        final int n = 31 * (31 * (31 * (7 + this.name.hashCode()) + this.styleClassSet.hashCode()) + this.styleClassSet.hashCode());
        return 31 * (((this.id != null) ? (31 * (n + this.id.hashCode())) : 0) + this.pseudoClassState.hashCode());
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        if (this.name != null && !this.name.isEmpty()) {
            sb.append(this.name);
        }
        else {
            sb.append("*");
        }
        final Iterator iterator = this.styleClassSet.iterator();
        while (iterator.hasNext()) {
            sb.append('.').append(iterator.next().getStyleClassName());
        }
        if (this.id != null && !this.id.isEmpty()) {
            sb.append('#');
            sb.append(this.id);
        }
        final Iterator iterator2 = this.pseudoClassState.iterator();
        while (iterator2.hasNext()) {
            sb.append(':').append(iterator2.next().getPseudoClassName());
        }
        return sb.toString();
    }
    
    @Override
    protected final void writeBinary(final DataOutputStream dataOutputStream, final StyleConverter.StringStore stringStore) throws IOException {
        super.writeBinary(dataOutputStream, stringStore);
        dataOutputStream.writeShort(stringStore.addString(this.name));
        dataOutputStream.writeShort(this.styleClassSet.size());
        final Iterator iterator = this.styleClassSet.iterator();
        while (iterator.hasNext()) {
            dataOutputStream.writeShort(stringStore.addString(iterator.next().getStyleClassName()));
        }
        dataOutputStream.writeShort(stringStore.addString(this.id));
        dataOutputStream.writeShort(this.pseudoClassState.size() + ((this.nodeOrientation == NodeOrientation.RIGHT_TO_LEFT || this.nodeOrientation == NodeOrientation.LEFT_TO_RIGHT) ? 1 : 0));
        final Iterator iterator2 = this.pseudoClassState.iterator();
        while (iterator2.hasNext()) {
            dataOutputStream.writeShort(stringStore.addString(iterator2.next().getPseudoClassName()));
        }
        if (this.nodeOrientation == NodeOrientation.RIGHT_TO_LEFT) {
            dataOutputStream.writeShort(stringStore.addString("dir(rtl)"));
        }
        else if (this.nodeOrientation == NodeOrientation.LEFT_TO_RIGHT) {
            dataOutputStream.writeShort(stringStore.addString("dir(ltr)"));
        }
    }
    
    static SimpleSelector readBinary(final int n, final DataInputStream dataInputStream, final String[] array) throws IOException {
        final String s = array[dataInputStream.readShort()];
        final short short1 = dataInputStream.readShort();
        final ArrayList<String> list = new ArrayList<String>();
        for (short n2 = 0; n2 < short1; ++n2) {
            list.add(array[dataInputStream.readShort()]);
        }
        final String s2 = array[dataInputStream.readShort()];
        final short short2 = dataInputStream.readShort();
        final ArrayList<String> list2 = new ArrayList<String>();
        for (short n3 = 0; n3 < short2; ++n3) {
            list2.add(array[dataInputStream.readShort()]);
        }
        return new SimpleSelector(s, list, list2, s2);
    }
}
