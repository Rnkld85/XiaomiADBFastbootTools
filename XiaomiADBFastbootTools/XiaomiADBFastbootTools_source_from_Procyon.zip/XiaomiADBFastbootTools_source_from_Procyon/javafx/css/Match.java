// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.geometry.NodeOrientation;
import com.sun.javafx.css.PseudoClassState;

public final class Match implements Comparable<Match>
{
    final Selector selector;
    final PseudoClassState pseudoClasses;
    final int idCount;
    final int styleClassCount;
    final int specificity;
    
    Match(final Selector selector, final PseudoClassState pseudoClasses, final int idCount, final int styleClassCount) {
        assert selector != null;
        this.selector = selector;
        this.idCount = idCount;
        this.styleClassCount = styleClassCount;
        int n = ((this.pseudoClasses = pseudoClasses) != null) ? pseudoClasses.size() : 0;
        if (selector instanceof SimpleSelector && ((SimpleSelector)selector).getNodeOrientation() != NodeOrientation.INHERIT) {
            ++n;
        }
        this.specificity = (idCount << 8 | styleClassCount << 4 | n);
    }
    
    public Selector getSelector() {
        return this.selector;
    }
    
    public PseudoClassState getPseudoClasses() {
        return this.pseudoClasses;
    }
    
    public int getSpecificity() {
        return this.specificity;
    }
    
    @Override
    public int compareTo(final Match match) {
        return this.specificity - match.specificity;
    }
}
