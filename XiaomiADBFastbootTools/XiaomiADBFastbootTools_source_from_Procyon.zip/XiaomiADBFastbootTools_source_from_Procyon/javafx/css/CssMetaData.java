// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import java.util.Collections;
import java.util.List;

public abstract class CssMetaData<S extends Styleable, V>
{
    private final String property;
    private final StyleConverter<?, V> converter;
    private final V initialValue;
    private final List<CssMetaData<? extends Styleable, ?>> subProperties;
    private final boolean inherits;
    
    @Deprecated(since = "8")
    public void set(final S n, final V obj, final StyleOrigin styleOrigin) {
        final StyleableProperty<V> styleableProperty = this.getStyleableProperty(n);
        final StyleOrigin styleOrigin2 = styleableProperty.getStyleOrigin();
        final Object value = styleableProperty.getValue();
        if (styleOrigin2 == styleOrigin) {
            if (value != null) {
                if (value.equals(obj)) {
                    return;
                }
            }
            else if (obj == null) {
                return;
            }
        }
        styleableProperty.applyStyle(styleOrigin, obj);
    }
    
    public abstract boolean isSettable(final S p0);
    
    public abstract StyleableProperty<V> getStyleableProperty(final S p0);
    
    public final String getProperty() {
        return this.property;
    }
    
    public final StyleConverter<?, V> getConverter() {
        return this.converter;
    }
    
    public V getInitialValue(final S n) {
        return this.initialValue;
    }
    
    public final List<CssMetaData<? extends Styleable, ?>> getSubProperties() {
        return this.subProperties;
    }
    
    public final boolean isInherits() {
        return this.inherits;
    }
    
    protected CssMetaData(final String property, final StyleConverter<?, V> converter, final V initialValue, final boolean inherits, final List<CssMetaData<? extends Styleable, ?>> list) {
        this.property = property;
        this.converter = converter;
        this.initialValue = initialValue;
        this.inherits = inherits;
        this.subProperties = ((list != null) ? Collections.unmodifiableList((List<? extends CssMetaData<? extends Styleable, ?>>)list) : null);
        if (this.property == null || this.converter == null) {
            throw new IllegalArgumentException("neither property nor converter can be null");
        }
    }
    
    protected CssMetaData(final String s, final StyleConverter<?, V> styleConverter, final V v, final boolean b) {
        this(s, (StyleConverter<?, Object>)styleConverter, v, b, null);
    }
    
    protected CssMetaData(final String s, final StyleConverter<?, V> styleConverter, final V v) {
        this(s, (StyleConverter<?, Object>)styleConverter, v, false, null);
    }
    
    protected CssMetaData(final String s, final StyleConverter<?, V> styleConverter) {
        this(s, (StyleConverter<?, Object>)styleConverter, null, false, null);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        final CssMetaData cssMetaData = (CssMetaData)o;
        if (this.property == null) {
            if (cssMetaData.property == null) {
                return true;
            }
        }
        else if (this.property.equals(cssMetaData.property)) {
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return 19 * 3 + ((this.property != null) ? this.property.hashCode() : 0);
    }
    
    @Override
    public String toString() {
        return "CSSProperty {" + "property: " + this.property + ", converter: " + this.converter.toString() + ", initalValue: " + String.valueOf(this.initialValue) + ", inherits: " + this.inherits + ", subProperties: " + ((this.subProperties != null) ? this.subProperties.toString() : "[]") + "}";
    }
}
