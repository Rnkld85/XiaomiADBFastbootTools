// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import java.util.Collections;
import javafx.scene.text.FontWeight;
import javafx.scene.text.FontPosture;
import javafx.css.converter.SizeConverter;
import javafx.css.converter.StringConverter;
import java.util.ArrayList;
import java.util.List;
import javafx.css.converter.FontConverter;
import javafx.scene.text.Font;

public abstract class FontCssMetaData<S extends Styleable> extends CssMetaData<S, Font>
{
    public FontCssMetaData(final String s, final Font font) {
        super(s, FontConverter.getInstance(), font, true, createSubProperties(s, font));
    }
    
    private static <S extends Styleable> List<CssMetaData<? extends Styleable, ?>> createSubProperties(final String s, final Font font) {
        final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>();
        final Font font2 = (font != null) ? font : Font.getDefault();
        list.add(new CssMetaData<S, String>(s.concat("-family"), StringConverter.getInstance(), font2.getFamily(), true) {
            @Override
            public boolean isSettable(final S n) {
                return false;
            }
            
            @Override
            public StyleableProperty<String> getStyleableProperty(final S n) {
                return null;
            }
        });
        list.add(new CssMetaData<S, Number>(s.concat("-size"), SizeConverter.getInstance(), Double.valueOf(font2.getSize()), true) {
            @Override
            public boolean isSettable(final S n) {
                return false;
            }
            
            @Override
            public StyleableProperty<Number> getStyleableProperty(final S n) {
                return null;
            }
        });
        list.add(new CssMetaData<S, FontPosture>(s.concat("-style"), FontConverter.FontStyleConverter.getInstance(), FontPosture.REGULAR, true) {
            @Override
            public boolean isSettable(final S n) {
                return false;
            }
            
            @Override
            public StyleableProperty<FontPosture> getStyleableProperty(final S n) {
                return null;
            }
        });
        list.add(new CssMetaData<S, FontWeight>(s.concat("-weight"), FontConverter.FontWeightConverter.getInstance(), FontWeight.NORMAL, true) {
            @Override
            public boolean isSettable(final S n) {
                return false;
            }
            
            @Override
            public StyleableProperty<FontWeight> getStyleableProperty(final S n) {
                return null;
            }
        });
        return (List<CssMetaData<? extends Styleable, ?>>)Collections.unmodifiableList((List<?>)list);
    }
}
