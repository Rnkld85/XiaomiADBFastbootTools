// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.NamedArg;

public class SimpleStyleableStringProperty extends StyleableStringProperty
{
    private static final Object DEFAULT_BEAN;
    private static final String DEFAULT_NAME = "";
    private final Object bean;
    private final String name;
    private final CssMetaData<? extends Styleable, String> cssMetaData;
    
    public SimpleStyleableStringProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, String> cssMetaData) {
        this(cssMetaData, SimpleStyleableStringProperty.DEFAULT_BEAN, "");
    }
    
    public SimpleStyleableStringProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, String> cssMetaData, @NamedArg("initialValue") final String s) {
        this(cssMetaData, SimpleStyleableStringProperty.DEFAULT_BEAN, "", s);
    }
    
    public SimpleStyleableStringProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, String> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s) {
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    public SimpleStyleableStringProperty(@NamedArg("cssMetaData") final CssMetaData<? extends Styleable, String> cssMetaData, @NamedArg("bean") final Object bean, @NamedArg("name") final String s, @NamedArg("initialValue") final String s2) {
        super(s2);
        this.bean = bean;
        this.name = ((s == null) ? "" : s);
        this.cssMetaData = cssMetaData;
    }
    
    @Override
    public Object getBean() {
        return this.bean;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public final CssMetaData<? extends Styleable, String> getCssMetaData() {
        return this.cssMetaData;
    }
    
    static {
        DEFAULT_BEAN = null;
    }
}
