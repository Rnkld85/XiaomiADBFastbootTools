// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import com.sun.javafx.css.PseudoClassState;

public abstract class PseudoClass
{
    public static PseudoClass getPseudoClass(final String s) {
        return PseudoClassState.getPseudoClass(s);
    }
    
    public abstract String getPseudoClassName();
}
