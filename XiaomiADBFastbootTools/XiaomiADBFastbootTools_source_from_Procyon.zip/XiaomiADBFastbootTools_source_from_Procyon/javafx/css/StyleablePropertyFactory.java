// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.property.Property;
import java.util.NoSuchElementException;
import java.net.URL;
import javafx.css.converter.EnumConverter;
import javafx.scene.paint.Paint;
import javafx.geometry.Insets;
import javafx.scene.text.Font;
import javafx.scene.effect.Effect;
import javafx.util.Duration;
import javafx.scene.paint.Color;
import java.util.function.Function;
import java.util.HashMap;
import java.util.Collection;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import javafx.util.Pair;
import java.util.Map;

public class StyleablePropertyFactory<S extends Styleable>
{
    private final Map<String, Pair<Class, CssMetaData<S, ?>>> metaDataMap;
    private final List<CssMetaData<? extends Styleable, ?>> unmodifiableMetaDataList;
    private final List<CssMetaData<? extends Styleable, ?>> metaDataList;
    
    public StyleablePropertyFactory(final List<CssMetaData<? extends Styleable, ?>> list) {
        this.metaDataList = new ArrayList<CssMetaData<? extends Styleable, ?>>();
        this.unmodifiableMetaDataList = Collections.unmodifiableList((List<? extends CssMetaData<? extends Styleable, ?>>)this.metaDataList);
        if (list != null) {
            this.metaDataList.addAll(list);
        }
        this.metaDataMap = new HashMap<String, Pair<Class, CssMetaData<S, ?>>>();
    }
    
    public final List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return this.unmodifiableMetaDataList;
    }
    
    public final StyleableProperty<Boolean> createStyleableBooleanProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Boolean>> function, final boolean b, final boolean b2) {
        return new SimpleStyleableBooleanProperty(this.createBooleanCssMetaData(s2, function, b, b2), n, s, b);
    }
    
    public final StyleableProperty<Boolean> createStyleableBooleanProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Boolean>> function, final boolean b) {
        return this.createStyleableBooleanProperty(n, s, s2, function, b, false);
    }
    
    public final StyleableProperty<Boolean> createStyleableBooleanProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Boolean>> function) {
        return this.createStyleableBooleanProperty(n, s, s2, function, false, false);
    }
    
    public final StyleableProperty<Boolean> createStyleableBooleanProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(Boolean.class, s2);
        return new SimpleStyleableBooleanProperty((CssMetaData<? extends Styleable, Boolean>)cssMetaData, n, s, (boolean)cssMetaData.getInitialValue(n));
    }
    
    public final StyleableProperty<Color> createStyleableColorProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Color>> function, final Color color, final boolean b) {
        return new SimpleStyleableObjectProperty<Color>(this.createColorCssMetaData(s2, function, color, b), n, s, color);
    }
    
    public final StyleableProperty<Color> createStyleableColorProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Color>> function, final Color color) {
        return this.createStyleableColorProperty(n, s, s2, function, color, false);
    }
    
    public final StyleableProperty<Color> createStyleableColorProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Color>> function) {
        return this.createStyleableColorProperty(n, s, s2, function, Color.BLACK, false);
    }
    
    public final StyleableProperty<Color> createStyleableColorProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(Color.class, s2);
        return new SimpleStyleableObjectProperty<Color>((CssMetaData<? extends Styleable, Object>)cssMetaData, n, s, cssMetaData.getInitialValue(n));
    }
    
    public final StyleableProperty<Duration> createStyleableDurationProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Duration>> function, final Duration duration, final boolean b) {
        return new SimpleStyleableObjectProperty<Duration>(this.createDurationCssMetaData(s2, function, duration, b), n, s, duration);
    }
    
    public final StyleableProperty<Duration> createStyleableDurationProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Duration>> function, final Duration duration) {
        return this.createStyleableDurationProperty(n, s, s2, function, duration, false);
    }
    
    public final StyleableProperty<Duration> createStyleableDurationProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Duration>> function) {
        return this.createStyleableDurationProperty(n, s, s2, function, Duration.UNKNOWN, false);
    }
    
    public final StyleableProperty<Duration> createStyleableDurationProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(Duration.class, s2);
        return new SimpleStyleableObjectProperty<Duration>((CssMetaData<? extends Styleable, Object>)cssMetaData, n, s, cssMetaData.getInitialValue(n));
    }
    
    public final <E extends Effect> StyleableProperty<E> createStyleableEffectProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<E>> function, final E e, final boolean b) {
        return new SimpleStyleableObjectProperty<E>(this.createEffectCssMetaData(s2, function, e, b), n, s, e);
    }
    
    public final <E extends Effect> StyleableProperty<E> createStyleableEffectProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<E>> function, final E e) {
        return this.createStyleableEffectProperty(n, s, s2, function, e, false);
    }
    
    public final <E extends Effect> StyleableProperty<E> createStyleableEffectProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<E>> function) {
        return this.createStyleableEffectProperty(n, s, s2, function, (E)null, false);
    }
    
    public final StyleableProperty<Effect> createStyleableEffectProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(Effect.class, s2);
        return new SimpleStyleableObjectProperty<Effect>((CssMetaData<? extends Styleable, Object>)cssMetaData, n, s, cssMetaData.getInitialValue(n));
    }
    
    public final <E extends Enum<E>> StyleableProperty<E> createStyleableEnumProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<E>> function, final Class<E> clazz, final E e, final boolean b) {
        return new SimpleStyleableObjectProperty<E>(this.createEnumCssMetaData(clazz, s2, function, e, b), n, s, e);
    }
    
    public final <E extends Enum<E>> StyleableProperty<E> createStyleableEnumProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<E>> function, final Class<E> clazz, final E e) {
        return this.createStyleableEnumProperty(n, s, s2, function, clazz, e, false);
    }
    
    public final <E extends Enum<E>> StyleableProperty<E> createStyleableEnumProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<E>> function, final Class<E> clazz) {
        return this.createStyleableEnumProperty(n, s, s2, function, clazz, (E)null, false);
    }
    
    public final <E extends Enum<E>> StyleableProperty<E> createStyleableEffectProperty(final S n, final String s, final String s2, final Class<E> clazz) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(clazz, s2);
        return new SimpleStyleableObjectProperty<E>((CssMetaData<? extends Styleable, Object>)cssMetaData, n, s, cssMetaData.getInitialValue(n));
    }
    
    public final StyleableProperty<Font> createStyleableFontProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Font>> function, final Font font, final boolean b) {
        return new SimpleStyleableObjectProperty<Font>(this.createFontCssMetaData(s2, function, font, b), n, s, font);
    }
    
    public final StyleableProperty<Font> createStyleableFontProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Font>> function, final Font font) {
        return this.createStyleableFontProperty(n, s, s2, function, font, true);
    }
    
    public final StyleableProperty<Font> createStyleableFontProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Font>> function) {
        return this.createStyleableFontProperty(n, s, s2, function, Font.getDefault(), true);
    }
    
    public final StyleableProperty<Font> createStyleableFontProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(Font.class, s2);
        return new SimpleStyleableObjectProperty<Font>((CssMetaData<? extends Styleable, Object>)cssMetaData, n, s, cssMetaData.getInitialValue(n));
    }
    
    public final StyleableProperty<Insets> createStyleableInsetsProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Insets>> function, final Insets insets, final boolean b) {
        return new SimpleStyleableObjectProperty<Insets>(this.createInsetsCssMetaData(s2, function, insets, b), n, s, insets);
    }
    
    public final StyleableProperty<Insets> createStyleableInsetsProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Insets>> function, final Insets insets) {
        return this.createStyleableInsetsProperty(n, s, s2, function, insets, false);
    }
    
    public final StyleableProperty<Insets> createStyleableInsetsProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Insets>> function) {
        return this.createStyleableInsetsProperty(n, s, s2, function, Insets.EMPTY, false);
    }
    
    public final StyleableProperty<Insets> createStyleableInsetsProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(Insets.class, s2);
        return new SimpleStyleableObjectProperty<Insets>((CssMetaData<? extends Styleable, Object>)cssMetaData, n, s, cssMetaData.getInitialValue(n));
    }
    
    public final StyleableProperty<Paint> createStyleablePaintProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Paint>> function, final Paint paint, final boolean b) {
        return new SimpleStyleableObjectProperty<Paint>(this.createPaintCssMetaData(s2, function, paint, b), n, s, paint);
    }
    
    public final StyleableProperty<Paint> createStyleablePaintProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Paint>> function, final Paint paint) {
        return this.createStyleablePaintProperty(n, s, s2, function, paint, false);
    }
    
    public final StyleableProperty<Paint> createStyleablePaintProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Paint>> function) {
        return this.createStyleablePaintProperty(n, s, s2, function, Color.BLACK, false);
    }
    
    public final StyleableProperty<Paint> createStyleablePaintProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(Paint.class, s2);
        return new SimpleStyleableObjectProperty<Paint>((CssMetaData<? extends Styleable, Object>)cssMetaData, n, s, cssMetaData.getInitialValue(n));
    }
    
    public final StyleableProperty<Number> createStyleableNumberProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Number>> function, final Number n2, final boolean b) {
        return new SimpleStyleableObjectProperty<Number>(this.createSizeCssMetaData(s2, function, n2, b), n, s, n2);
    }
    
    public final StyleableProperty<Number> createStyleableNumberProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Number>> function, final Number n2) {
        return this.createStyleableNumberProperty(n, s, s2, function, n2, false);
    }
    
    public final StyleableProperty<Number> createStyleableNumberProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<Number>> function) {
        return this.createStyleableNumberProperty(n, s, s2, function, 0.0, false);
    }
    
    public final StyleableProperty<Number> createStyleableNumberProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(Number.class, s2);
        return new SimpleStyleableObjectProperty<Number>((CssMetaData<? extends Styleable, Object>)cssMetaData, n, s, cssMetaData.getInitialValue(n));
    }
    
    public final StyleableProperty<String> createStyleableStringProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<String>> function, final String s3, final boolean b) {
        return new SimpleStyleableStringProperty(this.createStringCssMetaData(s2, function, s3, b), n, s, s3);
    }
    
    public final StyleableProperty<String> createStyleableStringProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<String>> function, final String s3) {
        return this.createStyleableStringProperty(n, s, s2, function, s3, false);
    }
    
    public final StyleableProperty<String> createStyleableStringProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<String>> function) {
        return this.createStyleableStringProperty(n, s, s2, function, null, false);
    }
    
    public final StyleableProperty<String> createStyleableStringProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(String.class, s2);
        return new SimpleStyleableStringProperty((CssMetaData<? extends Styleable, String>)cssMetaData, n, s, (String)cssMetaData.getInitialValue(n));
    }
    
    public final StyleableProperty<String> createStyleableUrlProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<String>> function, final String s3, final boolean b) {
        return new SimpleStyleableStringProperty(this.createUrlCssMetaData(s2, function, s3, b), n, s, s3);
    }
    
    public final StyleableProperty<String> createStyleableUrlProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<String>> function, final String s3) {
        return this.createStyleableUrlProperty(n, s, s2, function, s3, false);
    }
    
    public final StyleableProperty<String> createStyleableUrlProperty(final S n, final String s, final String s2, final Function<S, StyleableProperty<String>> function) {
        return this.createStyleableUrlProperty(n, s, s2, function, null, false);
    }
    
    public final StyleableProperty<String> createStyleableUrlProperty(final S n, final String s, final String s2) {
        if (s2 == null || s2.isEmpty()) {
            throw new IllegalArgumentException("cssProperty cannot be null or empty string");
        }
        final CssMetaData<S, ?> cssMetaData = this.getCssMetaData(String.class, s2);
        return new SimpleStyleableStringProperty((CssMetaData<? extends Styleable, String>)cssMetaData, n, s, (String)cssMetaData.getInitialValue(n));
    }
    
    public final CssMetaData<S, Boolean> createBooleanCssMetaData(final String s, final Function<S, StyleableProperty<Boolean>> function, final boolean b, final boolean b2) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, Boolean>)this.getCssMetaData((Class)Boolean.class, s, s2 -> new SimpleCssMetaData<Styleable, Object>(s2, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getBooleanConverter(), b, b2));
    }
    
    public final CssMetaData<S, Boolean> createBooleanCssMetaData(final String s, final Function<S, StyleableProperty<Boolean>> function, final boolean b) {
        return this.createBooleanCssMetaData(s, function, b, false);
    }
    
    public final CssMetaData<S, Boolean> createBooleanCssMetaData(final String s, final Function<S, StyleableProperty<Boolean>> function) {
        return this.createBooleanCssMetaData(s, function, false, false);
    }
    
    public final CssMetaData<S, Color> createColorCssMetaData(final String s, final Function<S, StyleableProperty<Color>> function, final Color color, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, Color>)this.getCssMetaData((Class)Color.class, s, p4 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getColorConverter(), color, b));
    }
    
    public final CssMetaData<S, Color> createColorCssMetaData(final String s, final Function<S, StyleableProperty<Color>> function, final Color color) {
        return this.createColorCssMetaData(s, function, color, false);
    }
    
    public final CssMetaData<S, Color> createColorCssMetaData(final String s, final Function<S, StyleableProperty<Color>> function) {
        return this.createColorCssMetaData(s, function, Color.BLACK, false);
    }
    
    public final CssMetaData<S, Duration> createDurationCssMetaData(final String s, final Function<S, StyleableProperty<Duration>> function, final Duration duration, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, Duration>)this.getCssMetaData((Class)Duration.class, s, p4 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getDurationConverter(), duration, b));
    }
    
    public final CssMetaData<S, Duration> createDurationCssMetaData(final String s, final Function<S, StyleableProperty<Duration>> function, final Duration duration) {
        return this.createDurationCssMetaData(s, function, duration, false);
    }
    
    public final CssMetaData<S, Duration> createDurationCssMetaData(final String s, final Function<S, StyleableProperty<Duration>> function) {
        return this.createDurationCssMetaData(s, function, Duration.UNKNOWN, false);
    }
    
    public final <E extends Effect> CssMetaData<S, E> createEffectCssMetaData(final String s, final Function<S, StyleableProperty<E>> function, final E e, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, E>)this.getCssMetaData((Class)Effect.class, s, p4 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getEffectConverter(), e, b));
    }
    
    public final <E extends Effect> CssMetaData<S, E> createEffectCssMetaData(final String s, final Function<S, StyleableProperty<E>> function, final E e) {
        return this.createEffectCssMetaData(s, function, e, false);
    }
    
    public final <E extends Effect> CssMetaData<S, E> createEffectCssMetaData(final String s, final Function<S, StyleableProperty<E>> function) {
        return this.createEffectCssMetaData(s, function, (E)null, false);
    }
    
    public final <E extends Enum<E>> CssMetaData<S, E> createEnumCssMetaData(final Class<? extends Enum> clazz, final String s, final Function<S, StyleableProperty<E>> function, final E e, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, E>)this.getCssMetaData((Class)clazz, s, p5 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)new EnumConverter((Class<Enum>)clazz), e, b));
    }
    
    public final <E extends Enum<E>> CssMetaData<S, E> createEnumCssMetaData(final Class<? extends Enum> clazz, final String s, final Function<S, StyleableProperty<E>> function, final E e) {
        return this.createEnumCssMetaData(clazz, s, function, e, false);
    }
    
    public final <E extends Enum<E>> CssMetaData<S, E> createEnumCssMetaData(final Class<? extends Enum> clazz, final String s, final Function<S, StyleableProperty<E>> function) {
        return this.createEnumCssMetaData(clazz, s, function, (E)null, false);
    }
    
    public final CssMetaData<S, Font> createFontCssMetaData(final String s, final Function<S, StyleableProperty<Font>> function, final Font font, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, Font>)this.getCssMetaData((Class)Font.class, s, p4 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getFontConverter(), font, b));
    }
    
    public final CssMetaData<S, Font> createFontCssMetaData(final String s, final Function<S, StyleableProperty<Font>> function, final Font font) {
        return this.createFontCssMetaData(s, function, font, true);
    }
    
    public final CssMetaData<S, Font> createFontCssMetaData(final String s, final Function<S, StyleableProperty<Font>> function) {
        return this.createFontCssMetaData(s, function, Font.getDefault(), true);
    }
    
    public final CssMetaData<S, Insets> createInsetsCssMetaData(final String s, final Function<S, StyleableProperty<Insets>> function, final Insets insets, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, Insets>)this.getCssMetaData((Class)Insets.class, s, p4 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getInsetsConverter(), insets, b));
    }
    
    public final CssMetaData<S, Insets> createInsetsCssMetaData(final String s, final Function<S, StyleableProperty<Insets>> function, final Insets insets) {
        return this.createInsetsCssMetaData(s, function, insets, false);
    }
    
    public final CssMetaData<S, Insets> createInsetsCssMetaData(final String s, final Function<S, StyleableProperty<Insets>> function) {
        return this.createInsetsCssMetaData(s, function, Insets.EMPTY, false);
    }
    
    public final CssMetaData<S, Paint> createPaintCssMetaData(final String s, final Function<S, StyleableProperty<Paint>> function, final Paint paint, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, Paint>)this.getCssMetaData((Class)Paint.class, s, p4 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getPaintConverter(), paint, b));
    }
    
    public final CssMetaData<S, Paint> createPaintCssMetaData(final String s, final Function<S, StyleableProperty<Paint>> function, final Paint paint) {
        return this.createPaintCssMetaData(s, function, paint, false);
    }
    
    public final CssMetaData<S, Paint> createPaintCssMetaData(final String s, final Function<S, StyleableProperty<Paint>> function) {
        return this.createPaintCssMetaData(s, function, Color.BLACK, false);
    }
    
    public final CssMetaData<S, Number> createSizeCssMetaData(final String s, final Function<S, StyleableProperty<Number>> function, final Number n, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, Number>)this.getCssMetaData((Class)Number.class, s, p4 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getSizeConverter(), n, b));
    }
    
    public final CssMetaData<S, Number> createSizeCssMetaData(final String s, final Function<S, StyleableProperty<Number>> function, final Number n) {
        return this.createSizeCssMetaData(s, function, n, false);
    }
    
    public final CssMetaData<S, Number> createSizeCssMetaData(final String s, final Function<S, StyleableProperty<Number>> function) {
        return this.createSizeCssMetaData(s, function, 0.0, false);
    }
    
    public final CssMetaData<S, String> createStringCssMetaData(final String s, final Function<S, StyleableProperty<String>> function, final String s2, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, String>)this.getCssMetaData((Class)String.class, s, p4 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getStringConverter(), s2, b));
    }
    
    public final CssMetaData<S, String> createStringCssMetaData(final String s, final Function<S, StyleableProperty<String>> function, final String s2) {
        return this.createStringCssMetaData(s, function, s2, false);
    }
    
    public final CssMetaData<S, String> createStringCssMetaData(final String s, final Function<S, StyleableProperty<String>> function) {
        return this.createStringCssMetaData(s, function, null, false);
    }
    
    public final CssMetaData<S, String> createUrlCssMetaData(final String s, final Function<S, StyleableProperty<String>> function, final String s2, final boolean b) {
        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("property cannot be null or empty string");
        }
        if (function == null) {
            throw new IllegalArgumentException("function cannot be null");
        }
        return (CssMetaData<S, String>)this.getCssMetaData((Class)URL.class, s, p4 -> new SimpleCssMetaData(s, (Function<Styleable, StyleableProperty<Object>>)function, (StyleConverter<?, Object>)StyleConverter.getUrlConverter(), s2, b));
    }
    
    public final CssMetaData<S, String> createUrlCssMetaData(final String s, final Function<S, StyleableProperty<String>> function, final String s2) {
        return this.createUrlCssMetaData(s, function, s2, false);
    }
    
    public final CssMetaData<S, String> createUrlCssMetaData(final String s, final Function<S, StyleableProperty<String>> function) {
        return this.createUrlCssMetaData(s, function, null, false);
    }
    
    void clearDataForTesting() {
        this.metaDataMap.clear();
        this.metaDataList.clear();
    }
    
    private CssMetaData<S, ?> getCssMetaData(final Class clazz, final String s) {
        return this.getCssMetaData(clazz, s, null);
    }
    
    private CssMetaData<S, ?> getCssMetaData(final Class clazz, final String s, final Function<String, CssMetaData<S, ?>> function) {
        final String lowerCase = s.toLowerCase();
        final Pair<Class, CssMetaData<S, ?>> pair = this.metaDataMap.get(lowerCase);
        if (pair != null) {
            if (pair.getKey() == clazz) {
                return pair.getValue();
            }
            throw new ClassCastException(invokedynamic(makeConcatWithConstants:(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/String;, clazz, pair.getValue()));
        }
        else {
            if (function == null) {
                throw new NoSuchElementException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, lowerCase));
            }
            final CssMetaData<S, ?> cssMetaData = function.apply(lowerCase);
            this.metaDataMap.put(lowerCase, new Pair<Class, CssMetaData<S, ?>>(clazz, cssMetaData));
            this.metaDataList.add(cssMetaData);
            return cssMetaData;
        }
    }
    
    private static class SimpleCssMetaData<S extends Styleable, V> extends CssMetaData<S, V>
    {
        private final Function<S, StyleableProperty<V>> function;
        
        SimpleCssMetaData(final String s, final Function<S, StyleableProperty<V>> function, final StyleConverter<?, V> styleConverter, final V v, final boolean b) {
            super(s, styleConverter, v, b);
            this.function = function;
        }
        
        @Override
        public final boolean isSettable(final S n) {
            final StyleableProperty<V> styleableProperty = this.getStyleableProperty(n);
            if (styleableProperty instanceof Property) {
                return !((Property)styleableProperty).isBound();
            }
            return styleableProperty != null;
        }
        
        @Override
        public final StyleableProperty<V> getStyleableProperty(final S n) {
            if (n != null) {
                return this.function.apply(n);
            }
            return null;
        }
    }
}
