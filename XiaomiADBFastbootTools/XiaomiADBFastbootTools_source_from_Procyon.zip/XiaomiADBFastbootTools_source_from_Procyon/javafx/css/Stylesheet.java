// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.net.URL;
import java.util.Collection;
import java.io.DataInputStream;
import java.io.IOException;
import com.sun.javafx.css.FontFaceImpl;
import java.io.DataOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import java.util.List;
import javafx.collections.ObservableList;

public class Stylesheet
{
    static final int BINARY_CSS_VERSION = 6;
    private final String url;
    private StyleOrigin origin;
    private final ObservableList<Rule> rules;
    private final List<FontFace> fontFaces;
    private String[] stringStore;
    
    public String getUrl() {
        return this.url;
    }
    
    public StyleOrigin getOrigin() {
        return this.origin;
    }
    
    public void setOrigin(final StyleOrigin origin) {
        this.origin = origin;
    }
    
    Stylesheet() {
        this(null);
    }
    
    Stylesheet(final String url) {
        this.origin = StyleOrigin.AUTHOR;
        this.rules = new TrackableObservableList<Rule>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Rule> change) {
                change.reset();
                while (change.next()) {
                    if (change.wasAdded()) {
                        final Iterator<Rule> iterator = change.getAddedSubList().iterator();
                        while (iterator.hasNext()) {
                            iterator.next().setStylesheet(Stylesheet.this);
                        }
                    }
                    else {
                        if (!change.wasRemoved()) {
                            continue;
                        }
                        for (final Rule rule : change.getRemoved()) {
                            if (rule.getStylesheet() == Stylesheet.this) {
                                rule.setStylesheet(null);
                            }
                        }
                    }
                }
            }
        };
        this.fontFaces = new ArrayList<FontFace>();
        this.url = url;
    }
    
    public List<Rule> getRules() {
        return this.rules;
    }
    
    public List<FontFace> getFontFaces() {
        return this.fontFaces;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o instanceof Stylesheet) {
            final Stylesheet stylesheet = (Stylesheet)o;
            return (this.url == null && stylesheet.url == null) || (this.url != null && stylesheet.url != null && this.url.equals(stylesheet.url));
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return 13 * 7 + ((this.url != null) ? this.url.hashCode() : 0);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("/* ");
        if (this.url != null) {
            sb.append(this.url);
        }
        if (this.rules.isEmpty()) {
            sb.append(" */");
        }
        else {
            sb.append(" */\n");
            for (int i = 0; i < this.rules.size(); ++i) {
                sb.append(this.rules.get(i));
                sb.append('\n');
            }
        }
        return sb.toString();
    }
    
    final void writeBinary(final DataOutputStream dataOutputStream, final StyleConverter.StringStore stringStore) throws IOException {
        dataOutputStream.writeShort(stringStore.addString(this.origin.name()));
        dataOutputStream.writeShort(this.rules.size());
        final Iterator<Rule> iterator = this.rules.iterator();
        while (iterator.hasNext()) {
            iterator.next().writeBinary(dataOutputStream, stringStore);
        }
        final List<FontFace> fontFaces = this.getFontFaces();
        final int v = (fontFaces != null) ? fontFaces.size() : 0;
        dataOutputStream.writeShort(v);
        for (int i = 0; i < v; ++i) {
            final FontFace fontFace = fontFaces.get(i);
            if (fontFace instanceof FontFaceImpl) {
                ((FontFaceImpl)fontFace).writeBinary(dataOutputStream, stringStore);
            }
        }
    }
    
    final void readBinary(final int n, final DataInputStream dataInputStream, final String[] stringStore) throws IOException {
        this.stringStore = stringStore;
        this.setOrigin(StyleOrigin.valueOf(stringStore[dataInputStream.readShort()]));
        final short short1 = dataInputStream.readShort();
        final ArrayList list = new ArrayList<Rule>(short1);
        for (short n2 = 0; n2 < short1; ++n2) {
            list.add(Rule.readBinary(n, dataInputStream, stringStore));
        }
        this.rules.addAll((Collection<?>)list);
        if (n >= 5) {
            final List<FontFace> fontFaces = this.getFontFaces();
            for (short short2 = dataInputStream.readShort(), n3 = 0; n3 < short2; ++n3) {
                fontFaces.add(FontFaceImpl.readBinary(n, dataInputStream, stringStore));
            }
        }
    }
    
    final String[] getStringStore() {
        return this.stringStore;
    }
    
    public static Stylesheet loadBinary(final URL url) throws IOException {
        if (url == null) {
            return null;
        }
        Stylesheet stylesheet = null;
        try {
            final DataInputStream dataInputStream = new DataInputStream(new BufferedInputStream(url.openStream(), 40960));
            try {
                final short short1 = dataInputStream.readShort();
                if (short1 > 6) {
                    throw new IOException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;I)Ljava/lang/String;, url.toString(), short1));
                }
                final String[] binary = StyleConverter.StringStore.readBinary(dataInputStream);
                stylesheet = new Stylesheet(url.toExternalForm());
                try {
                    dataInputStream.mark(Integer.MAX_VALUE);
                    stylesheet.readBinary(short1, dataInputStream, binary);
                }
                catch (Exception ex) {
                    stylesheet = new Stylesheet(url.toExternalForm());
                    dataInputStream.reset();
                    if (short1 == 2) {
                        stylesheet.readBinary(3, dataInputStream, binary);
                    }
                    else {
                        stylesheet.readBinary(6, dataInputStream, binary);
                    }
                }
                dataInputStream.close();
            }
            catch (Throwable t) {
                try {
                    dataInputStream.close();
                }
                catch (Throwable exception) {
                    t.addSuppressed(exception);
                }
                throw t;
            }
        }
        catch (FileNotFoundException ex2) {}
        return stylesheet;
    }
    
    public static void convertToBinary(final File file, final File file2) throws IOException {
        if (file == null || file2 == null) {
            throw new IllegalArgumentException("parameters may not be null");
        }
        if (file.getAbsolutePath().equals(file2.getAbsolutePath())) {
            throw new IllegalArgumentException("source and destination may not be the same");
        }
        if (!file.canRead()) {
            throw new IllegalArgumentException("cannot read source file");
        }
        Label_0093: {
            if (file2.exists()) {
                if (file2.canWrite()) {
                    break Label_0093;
                }
            }
            else if (file2.createNewFile()) {
                break Label_0093;
            }
            throw new IllegalArgumentException("cannot write destination file");
        }
        final Stylesheet parse = new CssParser().parse(file.toURI().toURL());
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final DataOutputStream dataOutputStream = new DataOutputStream(out);
        final StyleConverter.StringStore stringStore = new StyleConverter.StringStore();
        parse.writeBinary(dataOutputStream, stringStore);
        dataOutputStream.flush();
        dataOutputStream.close();
        final DataOutputStream dataOutputStream2 = new DataOutputStream(new FileOutputStream(file2));
        dataOutputStream2.writeShort(6);
        stringStore.writeBinary(dataOutputStream2);
        dataOutputStream2.write(out.toByteArray());
        dataOutputStream2.flush();
        dataOutputStream2.close();
    }
    
    void importStylesheet(final Stylesheet stylesheet) {
        if (stylesheet == null) {
            return;
        }
        final List<Rule> rules = stylesheet.getRules();
        if (rules == null || rules.isEmpty()) {
            return;
        }
        final ArrayList list = new ArrayList<Rule>(rules.size());
        for (final Rule rule : rules) {
            list.add(new Rule(rule.getSelectors(), rule.getUnobservedDeclarationList()));
        }
        this.rules.addAll((Collection<?>)list);
    }
}
