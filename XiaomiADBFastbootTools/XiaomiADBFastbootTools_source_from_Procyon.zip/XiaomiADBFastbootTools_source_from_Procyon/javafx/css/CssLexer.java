// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import com.sun.javafx.css.parser.Token;
import java.io.Reader;
import com.sun.javafx.css.parser.LexerState;
import com.sun.javafx.css.parser.Recognizer;

final class CssLexer
{
    static final int STRING = 10;
    static final int IDENT = 11;
    static final int FUNCTION = 12;
    static final int NUMBER = 13;
    static final int CM = 14;
    static final int EMS = 15;
    static final int EXS = 16;
    static final int IN = 17;
    static final int MM = 18;
    static final int PC = 19;
    static final int PT = 20;
    static final int PX = 21;
    static final int PERCENTAGE = 22;
    static final int DEG = 23;
    static final int GRAD = 24;
    static final int RAD = 25;
    static final int TURN = 26;
    static final int GREATER = 27;
    static final int LBRACE = 28;
    static final int RBRACE = 29;
    static final int SEMI = 30;
    static final int COLON = 31;
    static final int SOLIDUS = 32;
    static final int STAR = 33;
    static final int LPAREN = 34;
    static final int RPAREN = 35;
    static final int COMMA = 36;
    static final int HASH = 37;
    static final int DOT = 38;
    static final int IMPORTANT_SYM = 39;
    static final int WS = 40;
    static final int NL = 41;
    static final int FONT_FACE = 42;
    static final int URL = 43;
    static final int IMPORT = 44;
    static final int SECONDS = 45;
    static final int MS = 46;
    static final int AT_KEYWORD = 47;
    private final Recognizer A;
    private final Recognizer B;
    private final Recognizer C;
    private final Recognizer D;
    private final Recognizer E;
    private final Recognizer F;
    private final Recognizer G;
    private final Recognizer H;
    private final Recognizer I;
    private final Recognizer J;
    private final Recognizer K;
    private final Recognizer L;
    private final Recognizer M;
    private final Recognizer N;
    private final Recognizer O;
    private final Recognizer P;
    private final Recognizer Q;
    private final Recognizer R;
    private final Recognizer S;
    private final Recognizer T;
    private final Recognizer U;
    private final Recognizer V;
    private final Recognizer W;
    private final Recognizer X;
    private final Recognizer Y;
    private final Recognizer Z;
    private final Recognizer ALPHA;
    private final Recognizer NON_ASCII;
    private final Recognizer DOT_CHAR;
    private final Recognizer GREATER_CHAR;
    private final Recognizer LBRACE_CHAR;
    private final Recognizer RBRACE_CHAR;
    private final Recognizer SEMI_CHAR;
    private final Recognizer COLON_CHAR;
    private final Recognizer SOLIDUS_CHAR;
    private final Recognizer MINUS_CHAR;
    private final Recognizer PLUS_CHAR;
    private final Recognizer STAR_CHAR;
    private final Recognizer LPAREN_CHAR;
    private final Recognizer RPAREN_CHAR;
    private final Recognizer COMMA_CHAR;
    private final Recognizer UNDERSCORE_CHAR;
    private final Recognizer HASH_CHAR;
    private final Recognizer WS_CHARS;
    private final Recognizer NL_CHARS;
    private final Recognizer DIGIT;
    private final Recognizer HEX_DIGIT;
    final LexerState initState;
    final LexerState hashState;
    final LexerState minusState;
    final LexerState plusState;
    final LexerState dotState;
    final LexerState nmStartState;
    final LexerState nmCharState;
    final LexerState hashNameCharState;
    final LexerState lparenState;
    final LexerState leadingDigitsState;
    final LexerState decimalMarkState;
    final LexerState trailingDigitsState;
    final LexerState unitsState;
    private int pos;
    private int offset;
    private int line;
    private int lastc;
    private int ch;
    private boolean charNotConsumed;
    private Reader reader;
    private Token token;
    private final Map<LexerState, LexerState[]> stateMap;
    private LexerState currentState;
    private final StringBuilder text;
    
    private Map<LexerState, LexerState[]> createStateMap() {
        final HashMap<LexerState, LexerState[]> hashMap = new HashMap<LexerState, LexerState[]>();
        hashMap.put(this.initState, new LexerState[] { this.hashState, this.minusState, this.nmStartState, this.plusState, this.minusState, this.leadingDigitsState, this.dotState });
        hashMap.put(this.minusState, new LexerState[] { this.nmStartState, this.leadingDigitsState, this.decimalMarkState });
        hashMap.put(this.hashState, new LexerState[] { this.hashNameCharState });
        hashMap.put(this.hashNameCharState, new LexerState[] { this.hashNameCharState });
        hashMap.put(this.nmStartState, new LexerState[] { this.nmCharState });
        hashMap.put(this.nmCharState, new LexerState[] { this.nmCharState, this.lparenState });
        hashMap.put(this.plusState, new LexerState[] { this.leadingDigitsState, this.decimalMarkState });
        hashMap.put(this.leadingDigitsState, new LexerState[] { this.leadingDigitsState, this.decimalMarkState, this.unitsState });
        hashMap.put(this.dotState, new LexerState[] { this.trailingDigitsState });
        hashMap.put(this.decimalMarkState, new LexerState[] { this.trailingDigitsState });
        hashMap.put(this.trailingDigitsState, new LexerState[] { this.trailingDigitsState, this.unitsState });
        hashMap.put(this.unitsState, new LexerState[] { this.unitsState });
        return hashMap;
    }
    
    CssLexer() {
        this.A = (n -> n == 97 || n == 65);
        this.B = (n2 -> n2 == 98 || n2 == 66);
        this.C = (n3 -> n3 == 99 || n3 == 67);
        this.D = (n4 -> n4 == 100 || n4 == 68);
        this.E = (n5 -> n5 == 101 || n5 == 69);
        this.F = (n6 -> n6 == 102 || n6 == 70);
        this.G = (n7 -> n7 == 103 || n7 == 71);
        this.H = (n8 -> n8 == 104 || n8 == 72);
        this.I = (n9 -> n9 == 105 || n9 == 73);
        this.J = (n10 -> n10 == 106 || n10 == 74);
        this.K = (n11 -> n11 == 107 || n11 == 75);
        this.L = (n12 -> n12 == 108 || n12 == 76);
        this.M = (n13 -> n13 == 109 || n13 == 77);
        this.N = (n14 -> n14 == 110 || n14 == 78);
        this.O = (n15 -> n15 == 111 || n15 == 79);
        this.P = (n16 -> n16 == 112 || n16 == 80);
        this.Q = (n17 -> n17 == 113 || n17 == 81);
        this.R = (n18 -> n18 == 114 || n18 == 82);
        this.S = (n19 -> n19 == 115 || n19 == 83);
        this.T = (n20 -> n20 == 116 || n20 == 84);
        this.U = (n21 -> n21 == 117 || n21 == 85);
        this.V = (n22 -> n22 == 118 || n22 == 86);
        this.W = (n23 -> n23 == 119 || n23 == 87);
        this.X = (n24 -> n24 == 120 || n24 == 88);
        this.Y = (n25 -> n25 == 121 || n25 == 89);
        this.Z = (n26 -> n26 == 122 || n26 == 90);
        this.ALPHA = (n27 -> (97 <= n27 && n27 <= 122) || (65 <= n27 && n27 <= 90));
        this.NON_ASCII = (n28 -> 128 <= n28 && n28 <= 65535);
        this.DOT_CHAR = (n29 -> n29 == 46);
        this.GREATER_CHAR = (n30 -> n30 == 62);
        this.LBRACE_CHAR = (n31 -> n31 == 123);
        this.RBRACE_CHAR = (n32 -> n32 == 125);
        this.SEMI_CHAR = (n33 -> n33 == 59);
        this.COLON_CHAR = (n34 -> n34 == 58);
        this.SOLIDUS_CHAR = (n35 -> n35 == 47);
        this.MINUS_CHAR = (n36 -> n36 == 45);
        this.PLUS_CHAR = (n37 -> n37 == 43);
        this.STAR_CHAR = (n38 -> n38 == 42);
        this.LPAREN_CHAR = (n39 -> n39 == 40);
        this.RPAREN_CHAR = (n40 -> n40 == 41);
        this.COMMA_CHAR = (n41 -> n41 == 44);
        this.UNDERSCORE_CHAR = (n42 -> n42 == 95);
        this.HASH_CHAR = (n43 -> n43 == 35);
        this.WS_CHARS = (n44 -> n44 == 32 || n44 == 9 || n44 == 13 || n44 == 10 || n44 == 12);
        this.NL_CHARS = (n45 -> n45 == 13 || n45 == 10);
        this.DIGIT = (n46 -> 48 <= n46 && n46 <= 57);
        this.HEX_DIGIT = (n47 -> (48 <= n47 && n47 <= 57) || (97 <= n47 && n47 <= 102) || (65 <= n47 && n47 <= 70));
        this.initState = new LexerState("initState", (Recognizer)null, new Recognizer[0]) {
            @Override
            public boolean accepts(final int n) {
                return true;
            }
        };
        this.hashState = new LexerState("hashState", this.HASH_CHAR, new Recognizer[0]);
        this.minusState = new LexerState("minusState", this.MINUS_CHAR, new Recognizer[0]);
        this.plusState = new LexerState("plusState", this.PLUS_CHAR, new Recognizer[0]);
        this.dotState = new LexerState(38, "dotState", this.DOT_CHAR, new Recognizer[0]);
        this.nmStartState = new LexerState(11, "nmStartState", this.UNDERSCORE_CHAR, new Recognizer[] { this.ALPHA });
        this.nmCharState = new LexerState(11, "nmCharState", this.UNDERSCORE_CHAR, new Recognizer[] { this.ALPHA, this.DIGIT, this.MINUS_CHAR });
        this.hashNameCharState = new LexerState(37, "hashNameCharState", this.UNDERSCORE_CHAR, new Recognizer[] { this.ALPHA, this.DIGIT, this.MINUS_CHAR });
        this.lparenState = new LexerState(12, "lparenState", this.LPAREN_CHAR, new Recognizer[0]) {
            @Override
            public int getType() {
                if (CssLexer.this.text.indexOf("url(") == 0) {
                    try {
                        return CssLexer.this.consumeUrl();
                    }
                    catch (IOException ex) {
                        return 0;
                    }
                }
                return super.getType();
            }
        };
        this.leadingDigitsState = new LexerState(13, "leadingDigitsState", this.DIGIT, new Recognizer[0]);
        this.decimalMarkState = new LexerState("decimalMarkState", this.DOT_CHAR, new Recognizer[0]);
        this.trailingDigitsState = new LexerState(13, "trailingDigitsState", this.DIGIT, new Recognizer[0]);
        this.unitsState = new UnitsState();
        this.pos = 0;
        this.offset = 0;
        this.line = 1;
        this.lastc = -1;
        this.charNotConsumed = false;
        this.stateMap = this.createStateMap();
        this.text = new StringBuilder(64);
        this.currentState = this.initState;
    }
    
    void setReader(final Reader reader) {
        this.reader = reader;
        this.lastc = -1;
        final int n = 0;
        this.offset = n;
        this.pos = n;
        this.line = 1;
        this.currentState = this.initState;
        this.token = null;
        try {
            this.ch = this.readChar();
        }
        catch (IOException ex) {
            this.token = Token.EOF_TOKEN;
        }
    }
    
    private Token scanImportant() throws IOException {
        final Recognizer[] array = { this.I, this.M, this.P, this.O, this.R, this.T, this.A, this.N, this.T };
        int n = 0;
        this.text.append((char)this.ch);
        this.ch = this.readChar();
        while (true) {
            switch (this.ch) {
                case -1: {
                    return this.token = Token.EOF_TOKEN;
                }
                case 47: {
                    this.ch = this.readChar();
                    if (this.ch == 42) {
                        this.skipComment();
                        continue;
                    }
                    if (this.ch == 47) {
                        this.skipEOL();
                        continue;
                    }
                    this.text.append('/').append((char)this.ch);
                    final int offset = this.offset;
                    this.offset = this.pos;
                    return new Token(0, this.text.toString(), this.line, offset);
                }
                case 9:
                case 10:
                case 12:
                case 13:
                case 32: {
                    this.ch = this.readChar();
                    continue;
                }
                default: {
                    boolean recognize = true;
                    while (recognize && n < array.length) {
                        recognize = array[n++].recognize(this.ch);
                        this.text.append((char)this.ch);
                        this.ch = this.readChar();
                    }
                    if (recognize) {
                        final int offset2 = this.offset;
                        this.offset = this.pos - 1;
                        return new Token(39, "!important", this.line, offset2);
                    }
                    while (this.ch != 59 && this.ch != 125 && this.ch != -1) {
                        this.ch = this.readChar();
                    }
                    if (this.ch != -1) {
                        final int offset3 = this.offset;
                        this.offset = this.pos - 1;
                        return new Token(1, this.text.toString(), this.line, offset3);
                    }
                    return Token.EOF_TOKEN;
                }
            }
        }
    }
    
    private int consumeUrl() throws IOException {
        this.text.delete(0, this.text.length());
        while (this.WS_CHARS.recognize(this.ch)) {
            this.ch = this.readChar();
        }
        if (this.ch == -1) {
            return -1;
        }
        if (this.ch == 39 || this.ch == 34) {
            final int ch = this.ch;
            this.ch = this.readChar();
            while (this.ch != ch) {
                if (this.ch == -1) {
                    break;
                }
                if (this.NL_CHARS.recognize(this.ch)) {
                    break;
                }
                if (this.ch == 92) {
                    this.ch = this.readChar();
                    if (this.NL_CHARS.recognize(this.ch)) {
                        while (this.NL_CHARS.recognize(this.ch)) {
                            this.ch = this.readChar();
                        }
                    }
                    else {
                        if (this.ch == -1) {
                            continue;
                        }
                        this.text.append((char)this.ch);
                        this.ch = this.readChar();
                    }
                }
                else {
                    this.text.append((char)this.ch);
                    this.ch = this.readChar();
                }
            }
            if (this.ch == ch) {
                this.ch = this.readChar();
                while (this.WS_CHARS.recognize(this.ch)) {
                    this.ch = this.readChar();
                }
                if (this.ch == 41) {
                    this.ch = this.readChar();
                    return 43;
                }
                if (this.ch == -1) {
                    return 43;
                }
            }
        }
        else {
            this.text.append((char)this.ch);
            this.ch = this.readChar();
            while (true) {
                if (this.WS_CHARS.recognize(this.ch)) {
                    this.ch = this.readChar();
                }
                else {
                    if (this.ch == 41) {
                        this.ch = this.readChar();
                        return 43;
                    }
                    if (this.ch == -1) {
                        return 43;
                    }
                    if (this.ch == 92) {
                        this.ch = this.readChar();
                        if (this.NL_CHARS.recognize(this.ch)) {
                            while (this.NL_CHARS.recognize(this.ch)) {
                                this.ch = this.readChar();
                            }
                        }
                        else {
                            if (this.ch == -1) {
                                continue;
                            }
                            this.text.append((char)this.ch);
                            this.ch = this.readChar();
                        }
                    }
                    else {
                        if (this.ch == 39 || this.ch == 34) {
                            break;
                        }
                        if (this.ch == 40) {
                            break;
                        }
                        this.text.append((char)this.ch);
                        this.ch = this.readChar();
                    }
                }
            }
        }
        while (true) {
            final int ch2 = this.ch;
            if (this.ch == -1) {
                return -1;
            }
            if (this.ch == 41 && ch2 != 92) {
                this.ch = this.readChar();
                return 0;
            }
            final int ch3 = this.ch;
            this.ch = this.readChar();
        }
    }
    
    private void skipComment() throws IOException {
        while (this.ch != -1) {
            if (this.ch == 42) {
                this.ch = this.readChar();
                if (this.ch == 47) {
                    this.offset = this.pos;
                    this.ch = this.readChar();
                    break;
                }
                continue;
            }
            else {
                this.ch = this.readChar();
            }
        }
    }
    
    private void skipEOL() throws IOException {
        final int ch = this.ch;
        while (this.ch != -1) {
            this.ch = this.readChar();
            if (this.ch == 10 || (ch == 13 && this.ch != 10)) {
                break;
            }
        }
    }
    
    private int readChar() throws IOException {
        final int read = this.reader.read();
        if (this.lastc == 10 || (this.lastc == 13 && read != 10)) {
            this.pos = 1;
            this.offset = 0;
            ++this.line;
        }
        else {
            ++this.pos;
        }
        return this.lastc = read;
    }
    
    Token nextToken() {
        Token token;
        if (this.token != null) {
            token = this.token;
            if (this.token.getType() != -1) {
                this.token = null;
            }
        }
        else {
            do {
                token = this.getToken();
            } while (token != null && Token.SKIP_TOKEN.equals(token));
        }
        this.text.delete(0, this.text.length());
        this.currentState = this.initState;
        return token;
    }
    
    private Token getToken() {
        try {
        Label_1236:
            while (true) {
                this.charNotConsumed = false;
                final LexerState[] array = (LexerState[])((this.currentState != null) ? ((LexerState[])this.stateMap.get(this.currentState)) : null);
                final int n = (array != null) ? array.length : 0;
                LexerState currentState = null;
                for (int n2 = 0; n2 < n && currentState == null; ++n2) {
                    final LexerState lexerState = array[n2];
                    if (lexerState.accepts(this.ch)) {
                        currentState = lexerState;
                    }
                }
                if (currentState != null) {
                    this.currentState = currentState;
                    this.text.append((char)this.ch);
                    this.ch = this.readChar();
                }
                else {
                    final int n3 = (this.currentState != null) ? this.currentState.getType() : 0;
                    if (n3 != 0 || !this.currentState.equals(this.initState)) {
                        final Token token = new Token(n3, this.text.toString(), this.line, this.offset);
                        this.offset = this.pos - 1;
                        return token;
                    }
                    switch (this.ch) {
                        case -1: {
                            return this.token = Token.EOF_TOKEN;
                        }
                        case 34:
                        case 39: {
                            this.text.append((char)this.ch);
                            final int ch = this.ch;
                            while ((this.ch = this.readChar()) != -1) {
                                this.text.append((char)this.ch);
                                if (this.ch == ch) {
                                    break;
                                }
                            }
                            if (this.ch != -1) {
                                this.token = new Token(10, this.text.toString(), this.line, this.offset);
                                this.offset = this.pos;
                                break Label_1236;
                            }
                            this.token = new Token(0, this.text.toString(), this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 47: {
                            this.ch = this.readChar();
                            if (this.ch == 42) {
                                this.skipComment();
                                if (this.ch != -1) {
                                    continue;
                                }
                                return this.token = Token.EOF_TOKEN;
                            }
                            else {
                                if (this.ch != 47) {
                                    this.token = new Token(32, "/", this.line, this.offset);
                                    this.offset = this.pos;
                                    this.charNotConsumed = true;
                                    break Label_1236;
                                }
                                this.skipEOL();
                                if (this.ch != -1) {
                                    continue;
                                }
                                return this.token = Token.EOF_TOKEN;
                            }
                            break;
                        }
                        case 62: {
                            this.token = new Token(27, ">", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 123: {
                            this.token = new Token(28, "{", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 125: {
                            this.token = new Token(29, "}", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 59: {
                            this.token = new Token(30, ";", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 58: {
                            this.token = new Token(31, ":", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 42: {
                            this.token = new Token(33, "*", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 40: {
                            this.token = new Token(34, "(", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 41: {
                            this.token = new Token(35, ")", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 44: {
                            this.token = new Token(36, ",", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 46: {
                            this.token = new Token(38, ".", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 9:
                        case 12:
                        case 32: {
                            this.token = new Token(40, Character.toString((char)this.ch), this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        case 13: {
                            this.token = new Token(41, "\\r", this.line, this.offset);
                            this.ch = this.readChar();
                            if (this.ch == 10) {
                                this.token = new Token(41, "\\r\\n", this.line, this.offset);
                                break Label_1236;
                            }
                            final Token token2 = this.token;
                            this.token = ((this.ch == -1) ? Token.EOF_TOKEN : null);
                            return token2;
                        }
                        case 10: {
                            this.token = new Token(41, "\\n", this.line, this.offset);
                            break Label_1236;
                        }
                        case 33: {
                            return this.scanImportant();
                        }
                        case 64: {
                            this.token = new Token(47, "@", this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                        default: {
                            this.token = new Token(0, Character.toString((char)this.ch), this.line, this.offset);
                            this.offset = this.pos;
                            break Label_1236;
                        }
                    }
                }
            }
            if (this.token == null) {
                this.token = new Token(0, null, this.line, this.offset);
                this.offset = this.pos;
            }
            else if (this.token.getType() == -1) {
                return this.token;
            }
            if (this.ch != -1 && !this.charNotConsumed) {
                this.ch = this.readChar();
            }
            final Token token3 = this.token;
            this.token = null;
            return token3;
        }
        catch (IOException ex) {
            return this.token = Token.EOF_TOKEN;
        }
    }
    
    private class UnitsState extends LexerState
    {
        private final Recognizer[][] units;
        private int unitsMask;
        private int index;
        
        UnitsState() {
            super(-1, "UnitsState", null, new Recognizer[0]);
            this.units = new Recognizer[][] { { CssLexer.this.C, CssLexer.this.M }, { CssLexer.this.D, CssLexer.this.E, CssLexer.this.G }, { CssLexer.this.E, CssLexer.this.M }, { CssLexer.this.E, CssLexer.this.X }, { CssLexer.this.G, CssLexer.this.R, CssLexer.this.A, CssLexer.this.D }, { CssLexer.this.I, CssLexer.this.N }, { CssLexer.this.M, CssLexer.this.M }, { CssLexer.this.M, CssLexer.this.S }, { CssLexer.this.P, CssLexer.this.C }, { CssLexer.this.P, CssLexer.this.T }, { CssLexer.this.P, CssLexer.this.X }, { CssLexer.this.R, CssLexer.this.A, CssLexer.this.D }, { CssLexer.this.S }, { CssLexer.this.T, CssLexer.this.U, CssLexer.this.R, CssLexer.this.N }, { n -> n == 37 } };
            this.unitsMask = 32767;
            this.index = -1;
        }
        
        @Override
        public int getType() {
            int n = 0;
            switch (this.unitsMask) {
                case 1: {
                    n = 14;
                    break;
                }
                case 2: {
                    n = 23;
                    break;
                }
                case 4: {
                    n = 15;
                    break;
                }
                case 8: {
                    n = 16;
                    break;
                }
                case 16: {
                    n = 24;
                    break;
                }
                case 32: {
                    n = 17;
                    break;
                }
                case 64: {
                    n = 18;
                    break;
                }
                case 128: {
                    n = 46;
                    break;
                }
                case 256: {
                    n = 19;
                    break;
                }
                case 512: {
                    n = 20;
                    break;
                }
                case 1024: {
                    n = 21;
                    break;
                }
                case 2048: {
                    n = 25;
                    break;
                }
                case 4096: {
                    n = 45;
                    break;
                }
                case 8192: {
                    n = 26;
                    break;
                }
                case 16384: {
                    n = 22;
                    break;
                }
                default: {
                    n = 0;
                    break;
                }
            }
            this.unitsMask = 32767;
            this.index = -1;
            return n;
        }
        
        @Override
        public boolean accepts(final int n) {
            if (!CssLexer.this.ALPHA.recognize(n) && n != 37) {
                return false;
            }
            if (this.unitsMask == 0) {
                return true;
            }
            ++this.index;
            for (int i = 0; i < this.units.length; ++i) {
                final int n2 = 1 << i;
                if ((this.unitsMask & n2) != 0x0) {
                    if (this.index >= this.units[i].length || !this.units[i][this.index].recognize(n)) {
                        this.unitsMask &= ~n2;
                    }
                }
            }
            return true;
        }
    }
}
