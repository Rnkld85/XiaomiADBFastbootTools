// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.scene.text.Font;

public enum SizeUnits
{
    PERCENT(0, false) {
        @Override
        public String toString() {
            return "%";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return n / 100.0 * n2;
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return n / 100.0 * n2;
        }
    }, 
    IN(1, true) {
        @Override
        public String toString() {
            return "in";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return n * 72.0;
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return n * 96.0;
        }
    }, 
    CM(2, true) {
        @Override
        public String toString() {
            return "cm";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return n / 2.54 * 72.0;
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return n / 2.54 * 96.0;
        }
    }, 
    MM(3, true) {
        @Override
        public String toString() {
            return "mm";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return n / 25.4 * 72.0;
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return n / 25.4 * 96.0;
        }
    }, 
    EM(4, false) {
        @Override
        public String toString() {
            return "em";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return round(n * pointSize(font));
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return round(n * pixelSize(font));
        }
    }, 
    EX(5, false) {
        @Override
        public String toString() {
            return "ex";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return round(n / 2.0 * pointSize(font));
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return round(n / 2.0 * pixelSize(font));
        }
    }, 
    PT(6, true) {
        @Override
        public String toString() {
            return "pt";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return n;
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return n * 1.3333333333333333;
        }
    }, 
    PC(7, true) {
        @Override
        public String toString() {
            return "pc";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return n * 12.0;
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return n * 12.0 * 1.3333333333333333;
        }
    }, 
    PX(8, true) {
        @Override
        public String toString() {
            return "px";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return n * 0.75;
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return n;
        }
    }, 
    DEG(9, true) {
        @Override
        public String toString() {
            return "deg";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return round(n);
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return round(n);
        }
    }, 
    GRAD(10, true) {
        @Override
        public String toString() {
            return "grad";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return round(n * 9.0 / 10.0);
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return round(n * 9.0 / 10.0);
        }
    }, 
    RAD(11, true) {
        @Override
        public String toString() {
            return "rad";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return round(n * 180.0 / 3.141592653589793);
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return round(n * 180.0 / 3.141592653589793);
        }
    }, 
    TURN(12, true) {
        @Override
        public String toString() {
            return "turn";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return round(n * 360.0);
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return round(n * 360.0);
        }
    }, 
    S(13, true) {
        @Override
        public String toString() {
            return "s";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return n;
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return n;
        }
    }, 
    MS(14, true) {
        @Override
        public String toString() {
            return "ms";
        }
        
        @Override
        public double points(final double n, final double n2, final Font font) {
            return n;
        }
        
        @Override
        public double pixels(final double n, final double n2, final Font font) {
            return n;
        }
    };
    
    private final boolean absolute;
    private static final double DOTS_PER_INCH = 96.0;
    private static final double POINTS_PER_INCH = 72.0;
    private static final double CM_PER_INCH = 2.54;
    private static final double MM_PER_INCH = 25.4;
    private static final double POINTS_PER_PICA = 12.0;
    
    public abstract double points(final double p0, final double p1, final Font p2);
    
    public abstract double pixels(final double p0, final double p1, final Font p2);
    
    private SizeUnits(final boolean absolute) {
        this.absolute = absolute;
    }
    
    public boolean isAbsolute() {
        return this.absolute;
    }
    
    private static double pointSize(final Font font) {
        return pixelSize(font) * 0.75;
    }
    
    private static double pixelSize(final Font font) {
        return (font != null) ? font.getSize() : Font.getDefault().getSize();
    }
    
    private static double round(final double n) {
        if (n == 0.0) {
            return n;
        }
        return (long)((n + ((n < 0.0) ? -0.05 : 0.05)) * 10.0) / 10.0;
    }
}
