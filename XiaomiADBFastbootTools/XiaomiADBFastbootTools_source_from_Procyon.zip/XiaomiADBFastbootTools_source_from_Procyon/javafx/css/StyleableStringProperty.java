// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.value.ObservableValue;
import javafx.beans.property.StringPropertyBase;

public abstract class StyleableStringProperty extends StringPropertyBase implements StyleableProperty<String>
{
    private StyleOrigin origin;
    
    public StyleableStringProperty() {
        this.origin = null;
    }
    
    public StyleableStringProperty(final String s) {
        super(s);
        this.origin = null;
    }
    
    @Override
    public void applyStyle(final StyleOrigin origin, final String s) {
        this.set(s);
        this.origin = origin;
    }
    
    @Override
    public void bind(final ObservableValue<? extends String> observableValue) {
        super.bind(observableValue);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public void set(final String s) {
        super.set(s);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public StyleOrigin getStyleOrigin() {
        return this.origin;
    }
}
