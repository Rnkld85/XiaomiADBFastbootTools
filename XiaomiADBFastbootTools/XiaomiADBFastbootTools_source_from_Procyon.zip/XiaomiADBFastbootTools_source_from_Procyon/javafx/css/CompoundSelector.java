// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import java.util.ArrayList;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.DataOutputStream;
import java.util.Set;
import java.util.Collection;
import com.sun.javafx.css.PseudoClassState;
import java.util.Collections;
import com.sun.javafx.css.Combinator;
import java.util.List;

public final class CompoundSelector extends Selector
{
    private final List<SimpleSelector> selectors;
    private final List<Combinator> relationships;
    private int hash;
    
    public List<SimpleSelector> getSelectors() {
        return this.selectors;
    }
    
    CompoundSelector(final List<SimpleSelector> list, final List<Combinator> list2) {
        this.hash = -1;
        this.selectors = ((list != null) ? Collections.unmodifiableList((List<? extends SimpleSelector>)list) : Collections.EMPTY_LIST);
        this.relationships = ((list2 != null) ? Collections.unmodifiableList((List<? extends Combinator>)list2) : Collections.EMPTY_LIST);
    }
    
    private CompoundSelector() {
        this(null, null);
    }
    
    @Override
    public Match createMatch() {
        final PseudoClassState pseudoClassState = new PseudoClassState();
        int n = 0;
        int n2 = 0;
        for (int i = 0; i < this.selectors.size(); ++i) {
            final Match match = this.selectors.get(i).createMatch();
            pseudoClassState.addAll(match.pseudoClasses);
            n += match.idCount;
            n2 += match.styleClassCount;
        }
        return new Match(this, pseudoClassState, n, n2);
    }
    
    @Override
    public boolean applies(final Styleable styleable) {
        return this.applies(styleable, this.selectors.size() - 1, null, 0);
    }
    
    @Override
    public boolean applies(final Styleable styleable, final Set<PseudoClass>[] array, final int n) {
        assert n < array.length;
        if (array != null && array.length <= n) {
            return false;
        }
        final PseudoClassState[] array2 = (PseudoClassState[])((array != null) ? new PseudoClassState[array.length] : null);
        final boolean applies = this.applies(styleable, this.selectors.size() - 1, array2, n);
        if (applies && array2 != null) {
            for (int i = 0; i < array.length; ++i) {
                final Set<PseudoClass> set = array[i];
                final PseudoClassState pseudoClassState = array2[i];
                if (set != null) {
                    set.addAll(pseudoClassState);
                }
                else {
                    array[i] = pseudoClassState;
                }
            }
        }
        return applies;
    }
    
    private boolean applies(final Styleable styleable, final int n, final Set<PseudoClass>[] array, int n2) {
        if (n < 0) {
            return false;
        }
        if (!this.selectors.get(n).applies(styleable, array, n2)) {
            return false;
        }
        if (n == 0) {
            return true;
        }
        if (this.relationships.get(n - 1) == Combinator.CHILD) {
            final Styleable styleableParent = styleable.getStyleableParent();
            return styleableParent != null && this.applies(styleableParent, n - 1, array, ++n2);
        }
        for (Styleable styleable2 = styleable.getStyleableParent(); styleable2 != null; styleable2 = styleable2.getStyleableParent()) {
            if (this.applies(styleable2, n - 1, array, ++n2)) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean stateMatches(final Styleable styleable, final Set<PseudoClass> set) {
        return this.stateMatches(styleable, set, this.selectors.size() - 1);
    }
    
    private boolean stateMatches(final Styleable styleable, final Set<PseudoClass> set, final int n) {
        if (n < 0) {
            return false;
        }
        if (!this.selectors.get(n).stateMatches(styleable, set)) {
            return false;
        }
        if (n == 0) {
            return true;
        }
        if (this.relationships.get(n - 1) == Combinator.CHILD) {
            final Styleable styleableParent = styleable.getStyleableParent();
            if (styleableParent == null) {
                return false;
            }
            if (this.selectors.get(n - 1).applies(styleableParent)) {
                return this.stateMatches(styleableParent, styleableParent.getPseudoClassStates(), n - 1);
            }
        }
        else {
            for (Styleable styleable2 = styleable.getStyleableParent(); styleable2 != null; styleable2 = styleable2.getStyleableParent()) {
                if (this.selectors.get(n - 1).applies(styleable2)) {
                    return this.stateMatches(styleable2, styleable2.getPseudoClassStates(), n - 1);
                }
            }
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == -1) {
            for (int i = 0; i < this.selectors.size(); ++i) {
                this.hash = 31 * (this.hash + this.selectors.get(i).hashCode());
            }
            for (int j = 0; j < this.relationships.size(); ++j) {
                this.hash = 31 * (this.hash + this.relationships.get(j).hashCode());
            }
        }
        return this.hash;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        final CompoundSelector compoundSelector = (CompoundSelector)o;
        if (compoundSelector.selectors.size() != this.selectors.size()) {
            return false;
        }
        for (int i = 0; i < this.selectors.size(); ++i) {
            if (!compoundSelector.selectors.get(i).equals(this.selectors.get(i))) {
                return false;
            }
        }
        if (compoundSelector.relationships.size() != this.relationships.size()) {
            return false;
        }
        for (int j = 0; j < this.relationships.size(); ++j) {
            if (!compoundSelector.relationships.get(j).equals(this.relationships.get(j))) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.selectors.get(0));
        for (int i = 1; i < this.selectors.size(); ++i) {
            sb.append(this.relationships.get(i - 1));
            sb.append(this.selectors.get(i));
        }
        return sb.toString();
    }
    
    @Override
    protected final void writeBinary(final DataOutputStream dataOutputStream, final StyleConverter.StringStore stringStore) throws IOException {
        super.writeBinary(dataOutputStream, stringStore);
        dataOutputStream.writeShort(this.selectors.size());
        for (int i = 0; i < this.selectors.size(); ++i) {
            this.selectors.get(i).writeBinary(dataOutputStream, stringStore);
        }
        dataOutputStream.writeShort(this.relationships.size());
        for (int j = 0; j < this.relationships.size(); ++j) {
            dataOutputStream.writeByte(this.relationships.get(j).ordinal());
        }
    }
    
    static CompoundSelector readBinary(final int n, final DataInputStream dataInputStream, final String[] array) throws IOException {
        final short short1 = dataInputStream.readShort();
        final ArrayList<SimpleSelector> list = new ArrayList<SimpleSelector>();
        for (short n2 = 0; n2 < short1; ++n2) {
            list.add((SimpleSelector)Selector.readBinary(n, dataInputStream, array));
        }
        final short short2 = dataInputStream.readShort();
        final ArrayList<Combinator> list2 = new ArrayList<Combinator>();
        for (short n3 = 0; n3 < short2; ++n3) {
            final byte byte1 = dataInputStream.readByte();
            if (byte1 == Combinator.CHILD.ordinal()) {
                list2.add(Combinator.CHILD);
            }
            else if (byte1 == Combinator.DESCENDANT.ordinal()) {
                list2.add(Combinator.DESCENDANT);
            }
            else {
                assert false : invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, byte1);
                list2.add(Combinator.DESCENDANT);
            }
        }
        return new CompoundSelector(list, list2);
    }
}
