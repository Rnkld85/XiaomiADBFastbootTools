// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.scene.text.Font;

public final class Size
{
    private final double value;
    private final SizeUnits units;
    
    public Size(final double value, final SizeUnits sizeUnits) {
        this.value = value;
        this.units = ((sizeUnits != null) ? sizeUnits : SizeUnits.PX);
    }
    
    public double getValue() {
        return this.value;
    }
    
    public SizeUnits getUnits() {
        return this.units;
    }
    
    public boolean isAbsolute() {
        return this.units.isAbsolute();
    }
    
    double points(final Font font) {
        return this.points(1.0, font);
    }
    
    double points(final double n, final Font font) {
        return this.units.points(this.value, n, font);
    }
    
    public double pixels(final double n, final Font font) {
        return this.units.pixels(this.value, n, font);
    }
    
    public double pixels(final Font font) {
        return this.pixels(1.0, font);
    }
    
    double pixels(final double n) {
        return this.pixels(n, null);
    }
    
    public double pixels() {
        return this.pixels(1.0, null);
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, Double.toString(this.value), this.units.toString());
    }
    
    @Override
    public int hashCode() {
        final long n = 37L * (37L * 17L + Double.doubleToLongBits(this.value)) + this.units.hashCode();
        return (int)(n ^ n >> 32);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }
        final Size size = (Size)o;
        if (this.units != size.units) {
            return false;
        }
        if (this.value == size.value) {
            return true;
        }
        if (this.value > 0.0) {
            if (size.value <= 0.0) {
                return false;
            }
        }
        else if (size.value >= 0.0) {
            return false;
        }
        final double n = (this.value > 0.0) ? this.value : (-this.value);
        final double n2 = (size.value > 0.0) ? size.value : (-size.value);
        final double n3 = this.value - size.value;
        return n3 >= -1.0E-6 && 1.0E-6 >= n3;
    }
}
