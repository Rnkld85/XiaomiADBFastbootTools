// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

public final class StyleClass
{
    private final String styleClassName;
    private final int index;
    
    public StyleClass(final String styleClassName, final int index) {
        this.styleClassName = styleClassName;
        this.index = index;
    }
    
    public String getStyleClassName() {
        return this.styleClassName;
    }
    
    @Override
    public String toString() {
        return this.styleClassName;
    }
    
    public int getIndex() {
        return this.index;
    }
}
