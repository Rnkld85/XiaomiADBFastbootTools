// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.value.ObservableValue;
import javafx.beans.property.LongPropertyBase;

public abstract class StyleableLongProperty extends LongPropertyBase implements StyleableProperty<Number>
{
    private StyleOrigin origin;
    
    public StyleableLongProperty() {
        this.origin = null;
    }
    
    public StyleableLongProperty(final long n) {
        super(n);
        this.origin = null;
    }
    
    @Override
    public void applyStyle(final StyleOrigin origin, final Number value) {
        this.setValue(value);
        this.origin = origin;
    }
    
    @Override
    public void bind(final ObservableValue<? extends Number> observableValue) {
        super.bind(observableValue);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public void set(final long n) {
        super.set(n);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public StyleOrigin getStyleOrigin() {
        return this.origin;
    }
}
