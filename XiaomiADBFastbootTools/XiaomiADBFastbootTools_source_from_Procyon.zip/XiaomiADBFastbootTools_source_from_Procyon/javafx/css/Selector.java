// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import java.util.List;
import com.sun.javafx.css.Combinator;
import java.util.ArrayList;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.DataOutputStream;
import java.util.Set;

public abstract class Selector
{
    private Rule rule;
    private int ordinal;
    private static final int TYPE_SIMPLE = 1;
    private static final int TYPE_COMPOUND = 2;
    
    public Selector() {
        this.ordinal = -1;
    }
    
    static Selector getUniversalSelector() {
        return UniversalSelector.INSTANCE;
    }
    
    void setRule(final Rule rule) {
        this.rule = rule;
    }
    
    public Rule getRule() {
        return this.rule;
    }
    
    public void setOrdinal(final int ordinal) {
        this.ordinal = ordinal;
    }
    
    public int getOrdinal() {
        return this.ordinal;
    }
    
    public abstract Match createMatch();
    
    public abstract boolean applies(final Styleable p0);
    
    public abstract boolean applies(final Styleable p0, final Set<PseudoClass>[] p1, final int p2);
    
    public abstract boolean stateMatches(final Styleable p0, final Set<PseudoClass> p1);
    
    protected void writeBinary(final DataOutputStream dataOutputStream, final StyleConverter.StringStore stringStore) throws IOException {
        if (this instanceof SimpleSelector) {
            dataOutputStream.writeByte(1);
        }
        else {
            dataOutputStream.writeByte(2);
        }
    }
    
    static Selector readBinary(final int n, final DataInputStream dataInputStream, final String[] array) throws IOException {
        if (dataInputStream.readByte() == 1) {
            return SimpleSelector.readBinary(n, dataInputStream, array);
        }
        return CompoundSelector.readBinary(n, dataInputStream, array);
    }
    
    public static Selector createSelector(final String s) {
        if (s == null || s.length() == 0) {
            return null;
        }
        final ArrayList<Object> list = new ArrayList<Object>();
        final ArrayList<Combinator> list2 = new ArrayList<Combinator>();
        final ArrayList<String> list3 = new ArrayList<String>();
        int n = 0;
        int endIndex = -1;
        int n2 = 0;
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            if (char1 == ' ') {
                if (n2 == 0) {
                    n2 = char1;
                    endIndex = i;
                }
            }
            else if (char1 == '>') {
                if (n2 == 0) {
                    endIndex = i;
                }
                n2 = char1;
            }
            else if (n2 != 0) {
                list3.add(s.substring(n, endIndex));
                n = i;
                list2.add((n2 == 32) ? Combinator.DESCENDANT : Combinator.CHILD);
                n2 = 0;
            }
        }
        list3.add(s.substring(n));
        for (int j = 0; j < list3.size(); ++j) {
            final String s2 = list3.get(j);
            if (s2 != null && !s2.equals("")) {
                final String[] split = s2.split(":");
                final ArrayList<String> list4 = new ArrayList<String>();
                for (int k = 1; k < split.length; ++k) {
                    if (split[k] != null && !split[k].equals("")) {
                        list4.add(split[k].trim());
                    }
                }
                final String[] split2 = split[0].trim().split("\\.");
                final ArrayList<String> list5 = new ArrayList<String>();
                for (int l = 1; l < split2.length; ++l) {
                    if (split2[l] != null && !split2[l].equals("")) {
                        list5.add(split2[l].trim());
                    }
                }
                String trim = null;
                String trim2 = null;
                if (!split2[0].equals("")) {
                    if (split2[0].charAt(0) == '#') {
                        trim2 = split2[0].substring(1).trim();
                    }
                    else {
                        trim = split2[0].trim();
                    }
                }
                list.add(new SimpleSelector(trim, list5, list4, trim2));
            }
        }
        if (list.size() != 0) {
            return (Selector)list.get(0);
        }
        return new CompoundSelector((List<SimpleSelector>)list, list2);
    }
    
    private static class UniversalSelector
    {
        private static final Selector INSTANCE;
        
        static {
            INSTANCE = new SimpleSelector("*", null, null, null);
        }
    }
}
