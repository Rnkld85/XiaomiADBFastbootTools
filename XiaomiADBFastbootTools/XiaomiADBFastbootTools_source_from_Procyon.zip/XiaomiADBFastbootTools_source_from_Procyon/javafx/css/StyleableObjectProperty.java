// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.value.ObservableValue;
import javafx.beans.property.ObjectPropertyBase;

public abstract class StyleableObjectProperty<T> extends ObjectPropertyBase<T> implements StyleableProperty<T>
{
    private StyleOrigin origin;
    
    public StyleableObjectProperty() {
        this.origin = null;
    }
    
    public StyleableObjectProperty(final T t) {
        super(t);
        this.origin = null;
    }
    
    @Override
    public void applyStyle(final StyleOrigin origin, final T t) {
        this.set(t);
        this.origin = origin;
    }
    
    @Override
    public void bind(final ObservableValue<? extends T> observableValue) {
        super.bind(observableValue);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public void set(final T t) {
        super.set(t);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public StyleOrigin getStyleOrigin() {
        return this.origin;
    }
}
