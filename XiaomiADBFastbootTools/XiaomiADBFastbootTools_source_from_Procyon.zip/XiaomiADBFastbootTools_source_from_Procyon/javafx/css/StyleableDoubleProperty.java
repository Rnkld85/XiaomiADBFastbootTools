// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import javafx.beans.value.ObservableValue;
import javafx.beans.property.DoublePropertyBase;

public abstract class StyleableDoubleProperty extends DoublePropertyBase implements StyleableProperty<Number>
{
    private StyleOrigin origin;
    
    public StyleableDoubleProperty() {
        this.origin = null;
    }
    
    public StyleableDoubleProperty(final double n) {
        super(n);
        this.origin = null;
    }
    
    @Override
    public void applyStyle(final StyleOrigin origin, final Number value) {
        this.setValue(value);
        this.origin = origin;
    }
    
    @Override
    public void bind(final ObservableValue<? extends Number> observableValue) {
        super.bind(observableValue);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public void set(final double n) {
        super.set(n);
        this.origin = StyleOrigin.USER;
    }
    
    @Override
    public StyleOrigin getStyleOrigin() {
        return this.origin;
    }
}
