// 
// Decompiled by Procyon v0.5.36
// 

package javafx.css;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.DataOutputStream;
import com.sun.javafx.css.ParsedValueImpl;
import javafx.css.converter.URLConverter;

public final class Declaration
{
    final String property;
    final ParsedValue parsedValue;
    final boolean important;
    Rule rule;
    
    Declaration(final String property, final ParsedValue parsedValue, final boolean important) {
        this.property = property;
        this.parsedValue = parsedValue;
        this.important = important;
        if (property == null) {
            throw new IllegalArgumentException("propertyName cannot be null");
        }
        if (parsedValue == null) {
            throw new IllegalArgumentException("parsedValue cannot be null");
        }
    }
    
    public ParsedValue getParsedValue() {
        return this.parsedValue;
    }
    
    public String getProperty() {
        return this.property;
    }
    
    public Rule getRule() {
        return this.rule;
    }
    
    public final boolean isImportant() {
        return this.important;
    }
    
    private StyleOrigin getOrigin() {
        final Rule rule = this.getRule();
        if (rule != null) {
            return rule.getOrigin();
        }
        return null;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        final Declaration declaration = (Declaration)o;
        if (this.important != declaration.important) {
            return false;
        }
        if (this.getOrigin() != declaration.getOrigin()) {
            return false;
        }
        if (this.property == null) {
            if (declaration.property == null) {
                return this.parsedValue == declaration.parsedValue || (this.parsedValue != null && this.parsedValue.equals(declaration.parsedValue));
            }
        }
        else if (this.property.equals(declaration.property)) {
            return this.parsedValue == declaration.parsedValue || (this.parsedValue != null && this.parsedValue.equals(declaration.parsedValue));
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return 89 * (89 * (89 * 5 + ((this.property != null) ? this.property.hashCode() : 0)) + ((this.parsedValue != null) ? this.parsedValue.hashCode() : 0)) + (this.important ? 1 : 0);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder(this.property);
        sb.append(": ");
        sb.append(this.parsedValue);
        if (this.important) {
            sb.append(" !important");
        }
        return sb.toString();
    }
    
    void fixUrl(final String s) {
        if (s == null) {
            return;
        }
        final StyleConverter converter = this.parsedValue.getConverter();
        if (converter == URLConverter.getInstance()) {
            ((ParsedValue[])this.parsedValue.getValue())[1] = new ParsedValueImpl(s, null);
        }
        else if (converter == URLConverter.SequenceConverter.getInstance()) {
            final ParsedValue[] array = this.parsedValue.getValue();
            for (int i = 0; i < array.length; ++i) {
                ((ParsedValue[])array[i].getValue())[1] = new ParsedValueImpl(s, null);
            }
        }
    }
    
    final void writeBinary(final DataOutputStream dataOutputStream, final StyleConverter.StringStore stringStore) throws IOException {
        if (this.parsedValue instanceof ParsedValueImpl) {
            dataOutputStream.writeShort(stringStore.addString(this.getProperty()));
            ((ParsedValueImpl)this.parsedValue).writeBinary(dataOutputStream, stringStore);
            dataOutputStream.writeBoolean(this.isImportant());
        }
    }
    
    static Declaration readBinary(final int n, final DataInputStream dataInputStream, final String[] array) throws IOException {
        return new Declaration(array[dataInputStream.readShort()], ParsedValueImpl.readBinary(n, dataInputStream, array), dataInputStream.readBoolean());
    }
}
