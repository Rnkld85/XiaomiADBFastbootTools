// 
// Decompiled by Procyon v0.5.36
// 

package javafx.event;

public interface EventDispatcher
{
    Event dispatchEvent(final Event p0, final EventDispatchChain p1);
}
