// 
// Decompiled by Procyon v0.5.36
// 

package javafx.event;

import java.util.Set;
import java.io.InvalidObjectException;
import java.io.ObjectStreamException;
import java.util.List;
import java.util.Collection;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.io.Serializable;

public final class EventType<T extends Event> implements Serializable
{
    public static final EventType<Event> ROOT;
    private WeakHashMap<EventType<? extends T>, Void> subTypes;
    private final EventType<? super T> superType;
    private final String name;
    
    @Deprecated
    public EventType() {
        this(EventType.ROOT, null);
    }
    
    public EventType(final String s) {
        this(EventType.ROOT, s);
    }
    
    public EventType(final EventType<? super T> eventType) {
        this(eventType, null);
    }
    
    public EventType(final EventType<? super T> superType, final String name) {
        if (superType == null) {
            throw new NullPointerException("Event super type must not be null!");
        }
        this.superType = superType;
        this.name = name;
        superType.register((EventType)this);
    }
    
    EventType(final String name, final EventType<? super T> superType) {
        this.superType = superType;
        this.name = name;
        if (superType != null) {
            if (superType.subTypes != null) {
                final Iterator<EventType<? extends T>> iterator = superType.subTypes.keySet().iterator();
                while (iterator.hasNext()) {
                    final EventType<? extends T> eventType = iterator.next();
                    if ((name == null && eventType.name == null) || (name != null && name.equals(eventType.name))) {
                        iterator.remove();
                    }
                }
            }
            superType.register((EventType)this);
        }
    }
    
    public final EventType<? super T> getSuperType() {
        return this.superType;
    }
    
    public final String getName() {
        return this.name;
    }
    
    @Override
    public String toString() {
        return (this.name != null) ? this.name : super.toString();
    }
    
    private void register(final EventType<? extends T> key) {
        if (this.subTypes == null) {
            this.subTypes = new WeakHashMap<EventType<? extends T>, Void>();
        }
        for (final EventType<? extends T> eventType : this.subTypes.keySet()) {
            if ((eventType.name == null && key.name == null) || (eventType.name != null && eventType.name.equals(key.name))) {
                throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/event/EventType;Ljavafx/event/EventType;)Ljava/lang/String;, key, key.getSuperType()));
            }
        }
        this.subTypes.put(key, null);
    }
    
    private Object writeReplace() throws ObjectStreamException {
        final LinkedList<String> c = new LinkedList<String>();
        for (EventType<? super Event> superType = (EventType<? super Event>)this; superType != EventType.ROOT; superType = superType.superType) {
            c.addFirst(superType.name);
        }
        return new EventTypeSerialization(new ArrayList<String>(c));
    }
    
    static {
        ROOT = new EventType<Event>("EVENT", null);
    }
    
    static class EventTypeSerialization implements Serializable
    {
        private List<String> path;
        
        public EventTypeSerialization(final List<String> path) {
            this.path = path;
        }
        
        private Object readResolve() throws ObjectStreamException {
            EventType<Event> root = EventType.ROOT;
            for (int i = 0; i < this.path.size(); ++i) {
                final String s = this.path.get(i);
                if (root.subTypes == null) {
                    throw new InvalidObjectException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/event/EventType;)Ljava/lang/String;, s, root));
                }
                final EventType subType = this.findSubType((Set<EventType>)root.subTypes.keySet(), s);
                if (subType == null) {
                    throw new InvalidObjectException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/event/EventType;)Ljava/lang/String;, s, root));
                }
                root = (EventType<Event>)subType;
            }
            return root;
        }
        
        private EventType findSubType(final Set<EventType> set, final String anObject) {
            for (final EventType<Event> eventType : set) {
                if ((eventType.name == null && anObject == null) || (eventType.name != null && eventType.name.equals(anObject))) {
                    return eventType;
                }
            }
            return null;
        }
    }
}
