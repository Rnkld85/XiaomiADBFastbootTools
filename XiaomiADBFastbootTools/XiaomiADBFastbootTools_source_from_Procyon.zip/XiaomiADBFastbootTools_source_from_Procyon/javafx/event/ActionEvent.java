// 
// Decompiled by Procyon v0.5.36
// 

package javafx.event;

public class ActionEvent extends Event
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<ActionEvent> ACTION;
    public static final EventType<ActionEvent> ANY;
    
    public ActionEvent() {
        super(ActionEvent.ACTION);
    }
    
    public ActionEvent(final Object o, final EventTarget eventTarget) {
        super(o, eventTarget, ActionEvent.ACTION);
    }
    
    @Override
    public ActionEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (ActionEvent)super.copyFor(o, eventTarget);
    }
    
    @Override
    public EventType<? extends ActionEvent> getEventType() {
        return (EventType<? extends ActionEvent>)super.getEventType();
    }
    
    static {
        ACTION = new EventType<ActionEvent>(Event.ANY, "ACTION");
        ANY = ActionEvent.ACTION;
    }
}
