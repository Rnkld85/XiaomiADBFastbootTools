// 
// Decompiled by Procyon v0.5.36
// 

package javafx.event;

public interface EventDispatchChain
{
    EventDispatchChain append(final EventDispatcher p0);
    
    EventDispatchChain prepend(final EventDispatcher p0);
    
    Event dispatchEvent(final Event p0);
}
