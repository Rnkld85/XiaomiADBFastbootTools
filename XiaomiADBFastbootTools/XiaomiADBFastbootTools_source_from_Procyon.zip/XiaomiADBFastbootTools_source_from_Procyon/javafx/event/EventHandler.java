// 
// Decompiled by Procyon v0.5.36
// 

package javafx.event;

import java.util.EventListener;

@FunctionalInterface
public interface EventHandler<T extends Event> extends EventListener
{
    void handle(final T p0);
}
