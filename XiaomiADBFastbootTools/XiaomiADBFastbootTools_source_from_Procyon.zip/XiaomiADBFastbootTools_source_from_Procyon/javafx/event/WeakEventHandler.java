// 
// Decompiled by Procyon v0.5.36
// 

package javafx.event;

import javafx.beans.NamedArg;
import java.lang.ref.WeakReference;

public final class WeakEventHandler<T extends Event> implements EventHandler<T>
{
    private final WeakReference<EventHandler<T>> weakRef;
    
    public WeakEventHandler(@NamedArg("eventHandler") final EventHandler<T> referent) {
        this.weakRef = new WeakReference<EventHandler<T>>(referent);
    }
    
    public boolean wasGarbageCollected() {
        return this.weakRef.get() == null;
    }
    
    @Override
    public void handle(final T t) {
        final EventHandler<T> eventHandler = this.weakRef.get();
        if (eventHandler != null) {
            eventHandler.handle(t);
        }
    }
    
    void clear() {
        this.weakRef.clear();
    }
}
