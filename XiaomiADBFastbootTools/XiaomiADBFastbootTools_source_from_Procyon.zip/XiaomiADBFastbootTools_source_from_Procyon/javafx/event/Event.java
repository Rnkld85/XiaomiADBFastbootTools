// 
// Decompiled by Procyon v0.5.36
// 

package javafx.event;

import com.sun.javafx.event.EventUtil;
import java.io.IOException;
import java.io.ObjectInputStream;
import javafx.beans.NamedArg;
import java.util.EventObject;

public class Event extends EventObject implements Cloneable
{
    private static final long serialVersionUID = 20121107L;
    public static final EventTarget NULL_SOURCE_TARGET;
    public static final EventType<Event> ANY;
    protected EventType<? extends Event> eventType;
    protected transient EventTarget target;
    protected boolean consumed;
    
    public Event(@NamedArg("eventType") final EventType<? extends Event> eventType) {
        this(null, null, eventType);
    }
    
    public Event(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<? extends Event> eventType) {
        super((o != null) ? o : Event.NULL_SOURCE_TARGET);
        this.target = ((eventTarget != null) ? eventTarget : Event.NULL_SOURCE_TARGET);
        this.eventType = eventType;
    }
    
    public EventTarget getTarget() {
        return this.target;
    }
    
    public EventType<? extends Event> getEventType() {
        return this.eventType;
    }
    
    public Event copyFor(final Object o, final EventTarget eventTarget) {
        final Event event = (Event)this.clone();
        event.source = ((o != null) ? o : Event.NULL_SOURCE_TARGET);
        event.target = ((eventTarget != null) ? eventTarget : Event.NULL_SOURCE_TARGET);
        event.consumed = false;
        return event;
    }
    
    public boolean isConsumed() {
        return this.consumed;
    }
    
    public void consume() {
        this.consumed = true;
    }
    
    public Object clone() {
        try {
            return super.clone();
        }
        catch (CloneNotSupportedException ex) {
            throw new RuntimeException("Can't clone Event");
        }
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.source = Event.NULL_SOURCE_TARGET;
        this.target = Event.NULL_SOURCE_TARGET;
    }
    
    public static void fireEvent(final EventTarget eventTarget, final Event event) {
        if (eventTarget == null) {
            throw new NullPointerException("Event target must not be null!");
        }
        if (event == null) {
            throw new NullPointerException("Event must not be null!");
        }
        EventUtil.fireEvent(eventTarget, event);
    }
    
    static {
        NULL_SOURCE_TARGET = (eventDispatchChain -> eventDispatchChain);
        ANY = EventType.ROOT;
    }
}
