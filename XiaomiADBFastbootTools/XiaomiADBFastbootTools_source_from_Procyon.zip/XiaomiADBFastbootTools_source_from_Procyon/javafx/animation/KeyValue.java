// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import com.sun.javafx.animation.KeyValueHelper;
import javafx.beans.value.WritableBooleanValue;
import javafx.beans.value.WritableLongValue;
import javafx.beans.value.WritableFloatValue;
import javafx.beans.value.WritableIntegerValue;
import javafx.beans.value.WritableDoubleValue;
import javafx.beans.value.WritableNumberValue;
import javafx.beans.NamedArg;
import javafx.beans.value.WritableValue;
import com.sun.javafx.animation.KeyValueType;

public final class KeyValue
{
    private static final Interpolator DEFAULT_INTERPOLATOR;
    private final KeyValueType type;
    private final WritableValue<?> target;
    private final Object endValue;
    private final Interpolator interpolator;
    
    KeyValueType getType() {
        return this.type;
    }
    
    public WritableValue<?> getTarget() {
        return this.target;
    }
    
    public Object getEndValue() {
        return this.endValue;
    }
    
    public Interpolator getInterpolator() {
        return this.interpolator;
    }
    
    public <T> KeyValue(@NamedArg("target") final WritableValue<T> target, @NamedArg("endValue") final T endValue, @NamedArg("interpolator") final Interpolator interpolator) {
        if (target == null) {
            throw new NullPointerException("Target needs to be specified");
        }
        if (interpolator == null) {
            throw new NullPointerException("Interpolator needs to be specified");
        }
        this.target = target;
        this.endValue = endValue;
        this.interpolator = interpolator;
        this.type = ((target instanceof WritableNumberValue) ? ((target instanceof WritableDoubleValue) ? KeyValueType.DOUBLE : ((target instanceof WritableIntegerValue) ? KeyValueType.INTEGER : ((target instanceof WritableFloatValue) ? KeyValueType.FLOAT : ((target instanceof WritableLongValue) ? KeyValueType.LONG : KeyValueType.OBJECT)))) : ((target instanceof WritableBooleanValue) ? KeyValueType.BOOLEAN : KeyValueType.OBJECT));
    }
    
    public <T> KeyValue(@NamedArg("target") final WritableValue<T> writableValue, @NamedArg("endValue") final T t) {
        this(writableValue, t, KeyValue.DEFAULT_INTERPOLATOR);
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljavafx/beans/value/WritableValue;Ljava/lang/Object;Ljavafx/animation/Interpolator;)Ljava/lang/String;, this.target, this.endValue, this.interpolator);
    }
    
    @Override
    public int hashCode() {
        assert this.target != null && this.interpolator != null;
        return 31 * (31 * (31 * 1 + this.target.hashCode()) + ((this.endValue == null) ? 0 : this.endValue.hashCode())) + this.interpolator.hashCode();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof KeyValue)) {
            return false;
        }
        final KeyValue keyValue = (KeyValue)o;
        assert this.target != null && this.interpolator != null && keyValue.target != null && keyValue.interpolator != null;
        if (this.target.equals(keyValue.target)) {
            if (this.endValue == null) {
                if (keyValue.endValue != null) {
                    return false;
                }
            }
            else if (!this.endValue.equals(keyValue.endValue)) {
                return false;
            }
            if (this.interpolator.equals(keyValue.interpolator)) {
                return true;
            }
        }
        return false;
    }
    
    static {
        DEFAULT_INTERPOLATOR = Interpolator.LINEAR;
        KeyValueHelper.setKeyValueAccessor(new KeyValueHelper.KeyValueAccessor() {
            @Override
            public KeyValueType getType(final KeyValue keyValue) {
                return keyValue.getType();
            }
        });
    }
}
