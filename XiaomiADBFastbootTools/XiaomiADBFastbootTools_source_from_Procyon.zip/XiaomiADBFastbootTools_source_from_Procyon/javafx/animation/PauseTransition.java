// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import javafx.beans.property.ObjectPropertyBase;
import javafx.util.Duration;
import javafx.beans.property.ObjectProperty;

public final class PauseTransition extends Transition
{
    private ObjectProperty<Duration> duration;
    private static final Duration DEFAULT_DURATION;
    
    public final void setDuration(final Duration duration) {
        if (this.duration != null || !PauseTransition.DEFAULT_DURATION.equals(duration)) {
            this.durationProperty().set(duration);
        }
    }
    
    public final Duration getDuration() {
        return (this.duration == null) ? PauseTransition.DEFAULT_DURATION : this.duration.get();
    }
    
    public final ObjectProperty<Duration> durationProperty() {
        if (this.duration == null) {
            this.duration = new ObjectPropertyBase<Duration>(PauseTransition.DEFAULT_DURATION) {
                public void invalidated() {
                    try {
                        PauseTransition.this.setCycleDuration(PauseTransition.this.getDuration());
                    }
                    catch (IllegalArgumentException ex) {
                        if (this.isBound()) {
                            this.unbind();
                        }
                        this.set(PauseTransition.this.getCycleDuration());
                        throw ex;
                    }
                }
                
                @Override
                public Object getBean() {
                    return PauseTransition.this;
                }
                
                @Override
                public String getName() {
                    return "duration";
                }
            };
        }
        return this.duration;
    }
    
    public PauseTransition(final Duration duration) {
        this.setDuration(duration);
        this.setCycleDuration(duration);
    }
    
    public PauseTransition() {
        this(PauseTransition.DEFAULT_DURATION);
    }
    
    public void interpolate(final double n) {
    }
    
    static {
        DEFAULT_DURATION = Duration.millis(400.0);
    }
}
