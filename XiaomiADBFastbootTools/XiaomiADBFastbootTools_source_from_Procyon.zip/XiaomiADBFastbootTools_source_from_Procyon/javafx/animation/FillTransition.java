// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import javafx.scene.Node;
import javafx.scene.paint.Paint;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleObjectProperty;
import javafx.util.Duration;
import javafx.scene.shape.Shape;
import javafx.beans.property.ObjectProperty;
import javafx.scene.paint.Color;

public final class FillTransition extends Transition
{
    private Color start;
    private Color end;
    private ObjectProperty<Shape> shape;
    private static final Shape DEFAULT_SHAPE;
    private Shape cachedShape;
    private ObjectProperty<Duration> duration;
    private static final Duration DEFAULT_DURATION;
    private ObjectProperty<Color> fromValue;
    private static final Color DEFAULT_FROM_VALUE;
    private ObjectProperty<Color> toValue;
    private static final Color DEFAULT_TO_VALUE;
    
    public final void setShape(final Shape shape) {
        if (this.shape != null || shape != null) {
            this.shapeProperty().set(shape);
        }
    }
    
    public final Shape getShape() {
        return (this.shape == null) ? FillTransition.DEFAULT_SHAPE : this.shape.get();
    }
    
    public final ObjectProperty<Shape> shapeProperty() {
        if (this.shape == null) {
            this.shape = new SimpleObjectProperty<Shape>(this, "shape", FillTransition.DEFAULT_SHAPE);
        }
        return this.shape;
    }
    
    public final void setDuration(final Duration duration) {
        if (this.duration != null || !FillTransition.DEFAULT_DURATION.equals(duration)) {
            this.durationProperty().set(duration);
        }
    }
    
    public final Duration getDuration() {
        return (this.duration == null) ? FillTransition.DEFAULT_DURATION : this.duration.get();
    }
    
    public final ObjectProperty<Duration> durationProperty() {
        if (this.duration == null) {
            this.duration = new ObjectPropertyBase<Duration>(FillTransition.DEFAULT_DURATION) {
                public void invalidated() {
                    try {
                        FillTransition.this.setCycleDuration(FillTransition.this.getDuration());
                    }
                    catch (IllegalArgumentException ex) {
                        if (this.isBound()) {
                            this.unbind();
                        }
                        this.set(FillTransition.this.getCycleDuration());
                        throw ex;
                    }
                }
                
                @Override
                public Object getBean() {
                    return FillTransition.this;
                }
                
                @Override
                public String getName() {
                    return "duration";
                }
            };
        }
        return this.duration;
    }
    
    public final void setFromValue(final Color color) {
        if (this.fromValue != null || color != null) {
            this.fromValueProperty().set(color);
        }
    }
    
    public final Color getFromValue() {
        return (this.fromValue == null) ? FillTransition.DEFAULT_FROM_VALUE : this.fromValue.get();
    }
    
    public final ObjectProperty<Color> fromValueProperty() {
        if (this.fromValue == null) {
            this.fromValue = new SimpleObjectProperty<Color>(this, "fromValue", FillTransition.DEFAULT_FROM_VALUE);
        }
        return this.fromValue;
    }
    
    public final void setToValue(final Color color) {
        if (this.toValue != null || color != null) {
            this.toValueProperty().set(color);
        }
    }
    
    public final Color getToValue() {
        return (this.toValue == null) ? FillTransition.DEFAULT_TO_VALUE : this.toValue.get();
    }
    
    public final ObjectProperty<Color> toValueProperty() {
        if (this.toValue == null) {
            this.toValue = new SimpleObjectProperty<Color>(this, "toValue", FillTransition.DEFAULT_TO_VALUE);
        }
        return this.toValue;
    }
    
    public FillTransition(final Duration duration, final Shape shape, final Color fromValue, final Color toValue) {
        this.setDuration(duration);
        this.setShape(shape);
        this.setFromValue(fromValue);
        this.setToValue(toValue);
        this.setCycleDuration(duration);
    }
    
    public FillTransition(final Duration duration, final Color color, final Color color2) {
        this(duration, null, color, color2);
    }
    
    public FillTransition(final Duration duration, final Shape shape) {
        this(duration, shape, null, null);
    }
    
    public FillTransition(final Duration duration) {
        this(duration, null, null, null);
    }
    
    public FillTransition() {
        this(FillTransition.DEFAULT_DURATION, null);
    }
    
    @Override
    protected void interpolate(final double n) {
        this.cachedShape.setFill(this.start.interpolate(this.end, n));
    }
    
    private Shape getTargetShape() {
        Shape shape = this.getShape();
        if (shape == null) {
            final Node parentTargetNode = this.getParentTargetNode();
            if (parentTargetNode instanceof Shape) {
                shape = (Shape)parentTargetNode;
            }
        }
        return shape;
    }
    
    @Override
    boolean startable(final boolean b) {
        if (!super.startable(b)) {
            return false;
        }
        if (!b && this.cachedShape != null) {
            return true;
        }
        final Shape targetShape = this.getTargetShape();
        return targetShape != null && (this.getFromValue() != null || targetShape.getFill() instanceof Color) && this.getToValue() != null;
    }
    
    @Override
    void sync(final boolean b) {
        super.sync(b);
        if (b || this.cachedShape == null) {
            this.cachedShape = this.getTargetShape();
            final Color fromValue = this.getFromValue();
            this.start = (Color)((fromValue != null) ? fromValue : this.cachedShape.getFill());
            this.end = this.getToValue();
        }
    }
    
    static {
        DEFAULT_SHAPE = null;
        DEFAULT_DURATION = Duration.millis(400.0);
        DEFAULT_FROM_VALUE = null;
        DEFAULT_TO_VALUE = null;
    }
}
