// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import java.util.Collections;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.Collection;
import javafx.beans.NamedArg;
import java.util.Set;
import javafx.util.Duration;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public final class KeyFrame
{
    private static final EventHandler<ActionEvent> DEFAULT_ON_FINISHED;
    private static final String DEFAULT_NAME;
    private final Duration time;
    private final Set<KeyValue> values;
    private final EventHandler<ActionEvent> onFinished;
    private final String name;
    
    public Duration getTime() {
        return this.time;
    }
    
    public Set<KeyValue> getValues() {
        return this.values;
    }
    
    public EventHandler<ActionEvent> getOnFinished() {
        return this.onFinished;
    }
    
    public String getName() {
        return this.name;
    }
    
    public KeyFrame(@NamedArg("time") final Duration time, @NamedArg("name") final String name, @NamedArg("onFinished") final EventHandler<ActionEvent> onFinished, @NamedArg("values") final Collection<KeyValue> c) {
        if (time == null) {
            throw new NullPointerException("The time has to be specified");
        }
        if (time.lessThan(Duration.ZERO) || time.equals(Duration.UNKNOWN)) {
            throw new IllegalArgumentException("The time is invalid.");
        }
        this.time = time;
        this.name = name;
        if (c != null) {
            final CopyOnWriteArraySet<KeyValue> s = new CopyOnWriteArraySet<KeyValue>(c);
            s.remove(null);
            this.values = (Set<KeyValue>)((s.size() == 0) ? Collections.emptySet() : ((s.size() == 1) ? Collections.singleton((KeyValue)s.iterator().next()) : Collections.unmodifiableSet((Set<?>)s)));
        }
        else {
            this.values = Collections.emptySet();
        }
        this.onFinished = onFinished;
    }
    
    public KeyFrame(@NamedArg("time") final Duration time, @NamedArg("name") final String name, @NamedArg("onFinished") final EventHandler<ActionEvent> onFinished, @NamedArg("values") final KeyValue... array) {
        if (time == null) {
            throw new NullPointerException("The time has to be specified");
        }
        if (time.lessThan(Duration.ZERO) || time.equals(Duration.UNKNOWN)) {
            throw new IllegalArgumentException("The time is invalid.");
        }
        this.time = time;
        this.name = name;
        if (array != null) {
            final CopyOnWriteArraySet<Object> s = new CopyOnWriteArraySet<Object>();
            for (final KeyValue keyValue : array) {
                if (keyValue != null) {
                    s.add(keyValue);
                }
            }
            this.values = ((s.size() == 0) ? Collections.emptySet() : ((s.size() == 1) ? Collections.singleton(s.iterator().next()) : Collections.unmodifiableSet((Set<? extends KeyValue>)s)));
        }
        else {
            this.values = Collections.emptySet();
        }
        this.onFinished = onFinished;
    }
    
    public KeyFrame(@NamedArg("time") final Duration duration, @NamedArg("onFinished") final EventHandler<ActionEvent> eventHandler, @NamedArg("values") final KeyValue... array) {
        this(duration, KeyFrame.DEFAULT_NAME, eventHandler, array);
    }
    
    public KeyFrame(@NamedArg("time") final Duration duration, @NamedArg("name") final String s, @NamedArg("values") final KeyValue... array) {
        this(duration, s, KeyFrame.DEFAULT_ON_FINISHED, array);
    }
    
    public KeyFrame(@NamedArg("time") final Duration duration, @NamedArg("values") final KeyValue... array) {
        this(duration, KeyFrame.DEFAULT_NAME, KeyFrame.DEFAULT_ON_FINISHED, array);
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljavafx/util/Duration;Ljava/util/Set;Ljavafx/event/EventHandler;Ljava/lang/String;)Ljava/lang/String;, this.time, this.values, this.onFinished, this.name);
    }
    
    @Override
    public int hashCode() {
        assert this.time != null && this.values != null;
        return 31 * (31 * (31 * (31 * 1 + this.time.hashCode()) + ((this.name == null) ? 0 : this.name.hashCode())) + ((this.onFinished == null) ? 0 : this.onFinished.hashCode())) + this.values.hashCode();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof KeyFrame)) {
            return false;
        }
        final KeyFrame keyFrame = (KeyFrame)o;
        assert this.time != null && this.values != null && keyFrame.time != null && keyFrame.values != null;
        if (this.time.equals(keyFrame.time)) {
            if (this.name == null) {
                if (keyFrame.name != null) {
                    return false;
                }
            }
            else if (!this.name.equals(keyFrame.name)) {
                return false;
            }
            if (this.onFinished == null) {
                if (keyFrame.onFinished != null) {
                    return false;
                }
            }
            else if (!this.onFinished.equals(keyFrame.onFinished)) {
                return false;
            }
            if (this.values.equals(keyFrame.values)) {
                return true;
            }
        }
        return false;
    }
    
    static {
        DEFAULT_ON_FINISHED = null;
        DEFAULT_NAME = null;
    }
}
