// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.DoubleProperty;
import javafx.util.Duration;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;

public final class ScaleTransition extends Transition
{
    private static final double EPSILON = 1.0E-12;
    private double startX;
    private double startY;
    private double startZ;
    private double deltaX;
    private double deltaY;
    private double deltaZ;
    private ObjectProperty<Node> node;
    private static final Node DEFAULT_NODE;
    private Node cachedNode;
    private ObjectProperty<Duration> duration;
    private static final Duration DEFAULT_DURATION;
    private DoubleProperty fromX;
    private static final double DEFAULT_FROM_X = Double.NaN;
    private DoubleProperty fromY;
    private static final double DEFAULT_FROM_Y = Double.NaN;
    private DoubleProperty fromZ;
    private static final double DEFAULT_FROM_Z = Double.NaN;
    private DoubleProperty toX;
    private static final double DEFAULT_TO_X = Double.NaN;
    private DoubleProperty toY;
    private static final double DEFAULT_TO_Y = Double.NaN;
    private DoubleProperty toZ;
    private static final double DEFAULT_TO_Z = Double.NaN;
    private DoubleProperty byX;
    private static final double DEFAULT_BY_X = 0.0;
    private DoubleProperty byY;
    private static final double DEFAULT_BY_Y = 0.0;
    private DoubleProperty byZ;
    private static final double DEFAULT_BY_Z = 0.0;
    
    public final void setNode(final Node node) {
        if (this.node != null || node != null) {
            this.nodeProperty().set(node);
        }
    }
    
    public final Node getNode() {
        return (this.node == null) ? ScaleTransition.DEFAULT_NODE : this.node.get();
    }
    
    public final ObjectProperty<Node> nodeProperty() {
        if (this.node == null) {
            this.node = new SimpleObjectProperty<Node>(this, "node", ScaleTransition.DEFAULT_NODE);
        }
        return this.node;
    }
    
    public final void setDuration(final Duration duration) {
        if (this.duration != null || !ScaleTransition.DEFAULT_DURATION.equals(duration)) {
            this.durationProperty().set(duration);
        }
    }
    
    public final Duration getDuration() {
        return (this.duration == null) ? ScaleTransition.DEFAULT_DURATION : this.duration.get();
    }
    
    public final ObjectProperty<Duration> durationProperty() {
        if (this.duration == null) {
            this.duration = new ObjectPropertyBase<Duration>(ScaleTransition.DEFAULT_DURATION) {
                public void invalidated() {
                    try {
                        ScaleTransition.this.setCycleDuration(ScaleTransition.this.getDuration());
                    }
                    catch (IllegalArgumentException ex) {
                        if (this.isBound()) {
                            this.unbind();
                        }
                        this.set(ScaleTransition.this.getCycleDuration());
                        throw ex;
                    }
                }
                
                @Override
                public Object getBean() {
                    return ScaleTransition.this;
                }
                
                @Override
                public String getName() {
                    return "duration";
                }
            };
        }
        return this.duration;
    }
    
    public final void setFromX(final double v) {
        if (this.fromX != null || !Double.isNaN(v)) {
            this.fromXProperty().set(v);
        }
    }
    
    public final double getFromX() {
        return (this.fromX == null) ? Double.NaN : this.fromX.get();
    }
    
    public final DoubleProperty fromXProperty() {
        if (this.fromX == null) {
            this.fromX = new SimpleDoubleProperty(this, "fromX", Double.NaN);
        }
        return this.fromX;
    }
    
    public final void setFromY(final double v) {
        if (this.fromY != null || !Double.isNaN(v)) {
            this.fromYProperty().set(v);
        }
    }
    
    public final double getFromY() {
        return (this.fromY == null) ? Double.NaN : this.fromY.get();
    }
    
    public final DoubleProperty fromYProperty() {
        if (this.fromY == null) {
            this.fromY = new SimpleDoubleProperty(this, "fromY", Double.NaN);
        }
        return this.fromY;
    }
    
    public final void setFromZ(final double v) {
        if (this.fromZ != null || !Double.isNaN(v)) {
            this.fromZProperty().set(v);
        }
    }
    
    public final double getFromZ() {
        return (this.fromZ == null) ? Double.NaN : this.fromZ.get();
    }
    
    public final DoubleProperty fromZProperty() {
        if (this.fromZ == null) {
            this.fromZ = new SimpleDoubleProperty(this, "fromZ", Double.NaN);
        }
        return this.fromZ;
    }
    
    public final void setToX(final double v) {
        if (this.toX != null || !Double.isNaN(v)) {
            this.toXProperty().set(v);
        }
    }
    
    public final double getToX() {
        return (this.toX == null) ? Double.NaN : this.toX.get();
    }
    
    public final DoubleProperty toXProperty() {
        if (this.toX == null) {
            this.toX = new SimpleDoubleProperty(this, "toX", Double.NaN);
        }
        return this.toX;
    }
    
    public final void setToY(final double v) {
        if (this.toY != null || !Double.isNaN(v)) {
            this.toYProperty().set(v);
        }
    }
    
    public final double getToY() {
        return (this.toY == null) ? Double.NaN : this.toY.get();
    }
    
    public final DoubleProperty toYProperty() {
        if (this.toY == null) {
            this.toY = new SimpleDoubleProperty(this, "toY", Double.NaN);
        }
        return this.toY;
    }
    
    public final void setToZ(final double v) {
        if (this.toZ != null || !Double.isNaN(v)) {
            this.toZProperty().set(v);
        }
    }
    
    public final double getToZ() {
        return (this.toZ == null) ? Double.NaN : this.toZ.get();
    }
    
    public final DoubleProperty toZProperty() {
        if (this.toZ == null) {
            this.toZ = new SimpleDoubleProperty(this, "toZ", Double.NaN);
        }
        return this.toZ;
    }
    
    public final void setByX(final double n) {
        if (this.byX != null || Math.abs(n - 0.0) > 1.0E-12) {
            this.byXProperty().set(n);
        }
    }
    
    public final double getByX() {
        return (this.byX == null) ? 0.0 : this.byX.get();
    }
    
    public final DoubleProperty byXProperty() {
        if (this.byX == null) {
            this.byX = new SimpleDoubleProperty(this, "byX", 0.0);
        }
        return this.byX;
    }
    
    public final void setByY(final double n) {
        if (this.byY != null || Math.abs(n - 0.0) > 1.0E-12) {
            this.byYProperty().set(n);
        }
    }
    
    public final double getByY() {
        return (this.byY == null) ? 0.0 : this.byY.get();
    }
    
    public final DoubleProperty byYProperty() {
        if (this.byY == null) {
            this.byY = new SimpleDoubleProperty(this, "byY", 0.0);
        }
        return this.byY;
    }
    
    public final void setByZ(final double n) {
        if (this.byZ != null || Math.abs(n - 0.0) > 1.0E-12) {
            this.byZProperty().set(n);
        }
    }
    
    public final double getByZ() {
        return (this.byZ == null) ? 0.0 : this.byZ.get();
    }
    
    public final DoubleProperty byZProperty() {
        if (this.byZ == null) {
            this.byZ = new SimpleDoubleProperty(this, "byZ", 0.0);
        }
        return this.byZ;
    }
    
    public ScaleTransition(final Duration duration, final Node node) {
        this.setDuration(duration);
        this.setNode(node);
        this.setCycleDuration(duration);
    }
    
    public ScaleTransition(final Duration duration) {
        this(duration, null);
    }
    
    public ScaleTransition() {
        this(ScaleTransition.DEFAULT_DURATION, null);
    }
    
    public void interpolate(final double n) {
        if (!Double.isNaN(this.startX)) {
            this.cachedNode.setScaleX(this.startX + n * this.deltaX);
        }
        if (!Double.isNaN(this.startY)) {
            this.cachedNode.setScaleY(this.startY + n * this.deltaY);
        }
        if (!Double.isNaN(this.startZ)) {
            this.cachedNode.setScaleZ(this.startZ + n * this.deltaZ);
        }
    }
    
    private Node getTargetNode() {
        final Node node = this.getNode();
        return (node != null) ? node : this.getParentTargetNode();
    }
    
    @Override
    boolean startable(final boolean b) {
        return super.startable(b) && (this.getTargetNode() != null || (!b && this.cachedNode != null));
    }
    
    @Override
    void sync(final boolean b) {
        super.sync(b);
        if (b || this.cachedNode == null) {
            this.cachedNode = this.getTargetNode();
            final double fromX = this.getFromX();
            final double fromY = this.getFromY();
            final double fromZ = this.getFromZ();
            final double toX = this.getToX();
            final double toY = this.getToY();
            final double toZ = this.getToZ();
            final double byX = this.getByX();
            final double byY = this.getByY();
            final double byZ = this.getByZ();
            if (Double.isNaN(fromX) && Double.isNaN(toX) && Math.abs(byX) < 1.0E-12) {
                this.startX = Double.NaN;
            }
            else {
                this.startX = (Double.isNaN(fromX) ? this.cachedNode.getScaleX() : fromX);
                this.deltaX = (Double.isNaN(toX) ? this.getByX() : (toX - this.startX));
            }
            if (Double.isNaN(fromY) && Double.isNaN(toY) && Math.abs(byY) < 1.0E-12) {
                this.startY = Double.NaN;
            }
            else {
                this.startY = (Double.isNaN(fromY) ? this.cachedNode.getScaleY() : fromY);
                this.deltaY = (Double.isNaN(toY) ? this.getByY() : (toY - this.startY));
            }
            if (Double.isNaN(fromZ) && Double.isNaN(toZ) && Math.abs(byZ) < 1.0E-12) {
                this.startZ = Double.NaN;
            }
            else {
                this.startZ = (Double.isNaN(fromZ) ? this.cachedNode.getScaleZ() : fromZ);
                this.deltaZ = (Double.isNaN(toZ) ? this.getByZ() : (toZ - this.startZ));
            }
        }
    }
    
    static {
        DEFAULT_NODE = null;
        DEFAULT_DURATION = Duration.millis(400.0);
    }
}
