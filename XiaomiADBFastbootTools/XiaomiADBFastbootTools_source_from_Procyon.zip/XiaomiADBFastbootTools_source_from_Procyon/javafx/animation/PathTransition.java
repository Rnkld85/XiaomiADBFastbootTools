// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import com.sun.javafx.geom.PathIterator;
import com.sun.javafx.scene.shape.ShapeHelper;
import com.sun.javafx.scene.NodeHelper;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.shape.Shape;
import javafx.util.Duration;
import java.util.ArrayList;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;

public final class PathTransition extends Transition
{
    private ObjectProperty<Node> node;
    private double totalLength;
    private final ArrayList<Segment> segments;
    private static final Node DEFAULT_NODE;
    private static final int SMOOTH_ZONE = 10;
    private Node cachedNode;
    private ObjectProperty<Duration> duration;
    private static final Duration DEFAULT_DURATION;
    private ObjectProperty<Shape> path;
    private static final Shape DEFAULT_PATH;
    private ObjectProperty<OrientationType> orientation;
    private static final OrientationType DEFAULT_ORIENTATION;
    private boolean cachedIsNormalRequired;
    
    public final void setNode(final Node node) {
        if (this.node != null || node != null) {
            this.nodeProperty().set(node);
        }
    }
    
    public final Node getNode() {
        return (this.node == null) ? PathTransition.DEFAULT_NODE : this.node.get();
    }
    
    public final ObjectProperty<Node> nodeProperty() {
        if (this.node == null) {
            this.node = new SimpleObjectProperty<Node>(this, "node", PathTransition.DEFAULT_NODE);
        }
        return this.node;
    }
    
    public final void setDuration(final Duration duration) {
        if (this.duration != null || !PathTransition.DEFAULT_DURATION.equals(duration)) {
            this.durationProperty().set(duration);
        }
    }
    
    public final Duration getDuration() {
        return (this.duration == null) ? PathTransition.DEFAULT_DURATION : this.duration.get();
    }
    
    public final ObjectProperty<Duration> durationProperty() {
        if (this.duration == null) {
            this.duration = new ObjectPropertyBase<Duration>(PathTransition.DEFAULT_DURATION) {
                public void invalidated() {
                    try {
                        PathTransition.this.setCycleDuration(PathTransition.this.getDuration());
                    }
                    catch (IllegalArgumentException ex) {
                        if (this.isBound()) {
                            this.unbind();
                        }
                        this.set(PathTransition.this.getCycleDuration());
                        throw ex;
                    }
                }
                
                @Override
                public Object getBean() {
                    return PathTransition.this;
                }
                
                @Override
                public String getName() {
                    return "duration";
                }
            };
        }
        return this.duration;
    }
    
    public final void setPath(final Shape shape) {
        if (this.path != null || shape != null) {
            this.pathProperty().set(shape);
        }
    }
    
    public final Shape getPath() {
        return (this.path == null) ? PathTransition.DEFAULT_PATH : this.path.get();
    }
    
    public final ObjectProperty<Shape> pathProperty() {
        if (this.path == null) {
            this.path = new SimpleObjectProperty<Shape>(this, "path", PathTransition.DEFAULT_PATH);
        }
        return this.path;
    }
    
    public final void setOrientation(final OrientationType other) {
        if (this.orientation != null || !PathTransition.DEFAULT_ORIENTATION.equals(other)) {
            this.orientationProperty().set(other);
        }
    }
    
    public final OrientationType getOrientation() {
        return (this.orientation == null) ? OrientationType.NONE : this.orientation.get();
    }
    
    public final ObjectProperty<OrientationType> orientationProperty() {
        if (this.orientation == null) {
            this.orientation = new SimpleObjectProperty<OrientationType>(this, "orientation", PathTransition.DEFAULT_ORIENTATION);
        }
        return this.orientation;
    }
    
    public PathTransition(final Duration duration, final Shape path, final Node node) {
        this.totalLength = 0.0;
        this.segments = new ArrayList<Segment>();
        this.setDuration(duration);
        this.setPath(path);
        this.setNode(node);
        this.setCycleDuration(duration);
    }
    
    public PathTransition(final Duration duration, final Shape shape) {
        this(duration, shape, null);
    }
    
    public PathTransition() {
        this(PathTransition.DEFAULT_DURATION, null, null);
    }
    
    public void interpolate(final double b) {
        final double n = this.totalLength * Math.min(1.0, Math.max(0.0, b));
        final Segment segment = this.segments.get(this.findSegment(0, this.segments.size() - 1, n));
        final double n2 = n - (segment.accumLength - segment.length);
        final double n3 = n2 / segment.length;
        final Segment prevSeg = segment.prevSeg;
        final double n4 = prevSeg.toX + (segment.toX - prevSeg.toX) * n3;
        final double n5 = prevSeg.toY + (segment.toY - prevSeg.toY) * n3;
        double rotate = segment.rotateAngle;
        final double min = Math.min(10.0, segment.length / 2.0);
        if (n2 < min && !prevSeg.isMoveTo) {
            rotate = interpolate(prevSeg.rotateAngle, segment.rotateAngle, n2 / min / 2.0 + 0.5);
        }
        else {
            final double n6 = segment.length - n2;
            final Segment nextSeg = segment.nextSeg;
            if (n6 < min && nextSeg != null && !nextSeg.isMoveTo) {
                rotate = interpolate(segment.rotateAngle, nextSeg.rotateAngle, (min - n6) / min / 2.0);
            }
        }
        this.cachedNode.setTranslateX(n4 - NodeHelper.getPivotX(this.cachedNode));
        this.cachedNode.setTranslateY(n5 - NodeHelper.getPivotY(this.cachedNode));
        if (this.cachedIsNormalRequired) {
            this.cachedNode.setRotate(rotate);
        }
    }
    
    private Node getTargetNode() {
        final Node node = this.getNode();
        return (node != null) ? node : this.getParentTargetNode();
    }
    
    @Override
    boolean startable(final boolean b) {
        return super.startable(b) && ((this.getTargetNode() != null && this.getPath() != null && !this.getPath().getLayoutBounds().isEmpty()) || (!b && this.cachedNode != null));
    }
    
    @Override
    void sync(final boolean b) {
        super.sync(b);
        if (b || this.cachedNode == null) {
            this.cachedNode = this.getTargetNode();
            this.recomputeSegments();
            this.cachedIsNormalRequired = (this.getOrientation() == OrientationType.ORTHOGONAL_TO_TANGENT);
        }
    }
    
    private void recomputeSegments() {
        this.segments.clear();
        final Shape path = this.getPath();
        Segment zeroSegment = Segment.getZeroSegment();
        Segment zeroSegment2 = Segment.getZeroSegment();
        final float[] array = new float[6];
        final PathIterator pathIterator = ShapeHelper.configShape(path).getPathIterator(NodeHelper.getLeafTransform(path), 1.0f);
        while (!pathIterator.isDone()) {
            Segment e = null;
            final int currentSegment = pathIterator.currentSegment(array);
            final double n = array[0];
            final double n2 = array[1];
            switch (currentSegment) {
                case 0: {
                    zeroSegment = (e = Segment.newMoveTo(n, n2, zeroSegment2.accumLength));
                    break;
                }
                case 4: {
                    e = Segment.newClosePath(zeroSegment2, zeroSegment);
                    if (e == null) {
                        zeroSegment2.convertToClosePath(zeroSegment);
                        break;
                    }
                    break;
                }
                case 1: {
                    e = Segment.newLineTo(zeroSegment2, n, n2);
                    break;
                }
            }
            if (e != null) {
                this.segments.add(e);
                zeroSegment2 = e;
            }
            pathIterator.next();
        }
        this.totalLength = zeroSegment2.accumLength;
    }
    
    private int findSegment(final int index, final int n, final double n2) {
        if (index == n) {
            return (this.segments.get(index).isMoveTo && index > 0) ? this.findSegment(index - 1, index - 1, n2) : index;
        }
        final int index2 = index + (n - index) / 2;
        return (this.segments.get(index2).accumLength > n2) ? this.findSegment(index, index2, n2) : this.findSegment(index2 + 1, n, n2);
    }
    
    private static double interpolate(final double n, double n2, final double n3) {
        final double a = n2 - n;
        if (Math.abs(a) > 180.0) {
            n2 += ((a > 0.0) ? -360.0 : 360.0);
        }
        return normalize(n + n3 * (n2 - n));
    }
    
    private static double normalize(double n) {
        while (n > 360.0) {
            n -= 360.0;
        }
        while (n < 0.0) {
            n += 360.0;
        }
        return n;
    }
    
    static {
        DEFAULT_NODE = null;
        DEFAULT_DURATION = Duration.millis(400.0);
        DEFAULT_PATH = null;
        DEFAULT_ORIENTATION = OrientationType.NONE;
    }
    
    public enum OrientationType
    {
        NONE, 
        ORTHOGONAL_TO_TANGENT;
    }
    
    private static class Segment
    {
        private static final Segment zeroSegment;
        boolean isMoveTo;
        double length;
        double accumLength;
        double toX;
        double toY;
        double rotateAngle;
        Segment prevSeg;
        Segment nextSeg;
        
        private Segment(final boolean isMoveTo, final double toX, final double toY, final double length, final double n, final double rotateAngle) {
            this.isMoveTo = isMoveTo;
            this.toX = toX;
            this.toY = toY;
            this.length = length;
            this.accumLength = n + length;
            this.rotateAngle = rotateAngle;
        }
        
        public static Segment getZeroSegment() {
            return Segment.zeroSegment;
        }
        
        public static Segment newMoveTo(final double n, final double n2, final double n3) {
            return new Segment(true, n, n2, 0.0, n3, 0.0);
        }
        
        public static Segment newLineTo(final Segment prevSeg, final double n, final double n2) {
            final double n3 = n - prevSeg.toX;
            final double n4 = n2 - prevSeg.toY;
            final double sqrt = Math.sqrt(n3 * n3 + n4 * n4);
            if (sqrt >= 1.0 || prevSeg.isMoveTo) {
                final Segment nextSeg = new Segment(false, n, n2, sqrt, prevSeg.accumLength, normalize(Math.signum((n4 == 0.0) ? n3 : n4) * Math.acos(n3 / sqrt) / 3.141592653589793 * 180.0));
                prevSeg.nextSeg = nextSeg;
                nextSeg.prevSeg = prevSeg;
                return nextSeg;
            }
            return null;
        }
        
        public static Segment newClosePath(final Segment segment, final Segment segment2) {
            final Segment lineTo = newLineTo(segment, segment2.toX, segment2.toY);
            if (lineTo != null) {
                lineTo.convertToClosePath(segment2);
            }
            return lineTo;
        }
        
        public void convertToClosePath(final Segment segment) {
            final Segment nextSeg = segment.nextSeg;
            this.nextSeg = nextSeg;
            nextSeg.prevSeg = this;
        }
        
        static {
            zeroSegment = new Segment(true, 0.0, 0.0, 0.0, 0.0, 0.0);
        }
    }
}
