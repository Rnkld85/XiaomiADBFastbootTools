// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import com.sun.scenario.animation.shared.AnimationAccessor;

final class AnimationAccessorImpl extends AnimationAccessor
{
    @Override
    public void setCurrentRate(final Animation animation, final double currentRate) {
        animation.setCurrentRate(currentRate);
    }
    
    @Override
    public void playTo(final Animation animation, final long n, final long n2) {
        animation.doPlayTo(n, n2);
    }
    
    @Override
    public void jumpTo(final Animation animation, final long n, final long n2, final boolean b) {
        animation.doJumpTo(n, n2, b);
    }
    
    @Override
    public void finished(final Animation animation) {
        animation.finished();
    }
    
    @Override
    public void setCurrentTicks(final Animation animation, final long currentTicks) {
        animation.setCurrentTicks(currentTicks);
    }
}
