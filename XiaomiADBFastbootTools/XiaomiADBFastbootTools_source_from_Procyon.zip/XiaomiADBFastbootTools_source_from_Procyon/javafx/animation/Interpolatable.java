// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

@FunctionalInterface
public interface Interpolatable<T>
{
    T interpolate(final T p0, final double p1);
}
