// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import com.sun.scenario.animation.shared.TimerReceiver;
import java.security.AccessController;
import com.sun.javafx.tk.Toolkit;
import java.security.AccessControlContext;
import com.sun.scenario.animation.AbstractMasterTimer;

public abstract class AnimationTimer
{
    private final AbstractMasterTimer timer;
    private final AnimationTimerReceiver timerReceiver;
    private boolean active;
    private AccessControlContext accessCtrlCtx;
    
    public AnimationTimer() {
        this.timerReceiver = new AnimationTimerReceiver();
        this.accessCtrlCtx = null;
        this.timer = Toolkit.getToolkit().getMasterTimer();
    }
    
    AnimationTimer(final AbstractMasterTimer timer) {
        this.timerReceiver = new AnimationTimerReceiver();
        this.accessCtrlCtx = null;
        this.timer = timer;
    }
    
    public abstract void handle(final long p0);
    
    public void start() {
        if (!this.active) {
            this.accessCtrlCtx = AccessController.getContext();
            this.timer.addAnimationTimer(this.timerReceiver);
            this.active = true;
        }
    }
    
    public void stop() {
        if (this.active) {
            this.timer.removeAnimationTimer(this.timerReceiver);
            this.active = false;
        }
    }
    
    private class AnimationTimerReceiver implements TimerReceiver
    {
        @Override
        public void handle(final long n) {
            if (AnimationTimer.this.accessCtrlCtx == null) {
                throw new IllegalStateException("Error: AccessControlContext not captured");
            }
            AccessController.doPrivileged(() -> {
                AnimationTimer.this.handle(n);
                return null;
            }, AnimationTimer.this.accessCtrlCtx);
        }
    }
}
