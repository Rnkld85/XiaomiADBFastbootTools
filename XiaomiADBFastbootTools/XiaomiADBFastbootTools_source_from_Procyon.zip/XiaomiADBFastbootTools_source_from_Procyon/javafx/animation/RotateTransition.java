// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Point3D;
import javafx.util.Duration;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;

public final class RotateTransition extends Transition
{
    private static final double EPSILON = 1.0E-12;
    private double start;
    private double delta;
    private ObjectProperty<Node> node;
    private static final Node DEFAULT_NODE;
    private Node cachedNode;
    private ObjectProperty<Duration> duration;
    private static final Duration DEFAULT_DURATION;
    private ObjectProperty<Point3D> axis;
    private static final Point3D DEFAULT_AXIS;
    private DoubleProperty fromAngle;
    private static final double DEFAULT_FROM_ANGLE = Double.NaN;
    private DoubleProperty toAngle;
    private static final double DEFAULT_TO_ANGLE = Double.NaN;
    private DoubleProperty byAngle;
    private static final double DEFAULT_BY_ANGLE = 0.0;
    
    public final void setNode(final Node node) {
        if (this.node != null || node != null) {
            this.nodeProperty().set(node);
        }
    }
    
    public final Node getNode() {
        return (this.node == null) ? RotateTransition.DEFAULT_NODE : this.node.get();
    }
    
    public final ObjectProperty<Node> nodeProperty() {
        if (this.node == null) {
            this.node = new SimpleObjectProperty<Node>(this, "node", RotateTransition.DEFAULT_NODE);
        }
        return this.node;
    }
    
    public final void setDuration(final Duration duration) {
        if (this.duration != null || !RotateTransition.DEFAULT_DURATION.equals(duration)) {
            this.durationProperty().set(duration);
        }
    }
    
    public final Duration getDuration() {
        return (this.duration == null) ? RotateTransition.DEFAULT_DURATION : this.duration.get();
    }
    
    public final ObjectProperty<Duration> durationProperty() {
        if (this.duration == null) {
            this.duration = new ObjectPropertyBase<Duration>(RotateTransition.DEFAULT_DURATION) {
                public void invalidated() {
                    try {
                        RotateTransition.this.setCycleDuration(RotateTransition.this.getDuration());
                    }
                    catch (IllegalArgumentException ex) {
                        if (this.isBound()) {
                            this.unbind();
                        }
                        this.set(RotateTransition.this.getCycleDuration());
                        throw ex;
                    }
                }
                
                @Override
                public Object getBean() {
                    return RotateTransition.this;
                }
                
                @Override
                public String getName() {
                    return "duration";
                }
            };
        }
        return this.duration;
    }
    
    public final void setAxis(final Point3D point3D) {
        if (this.axis != null || point3D != null) {
            this.axisProperty().set(point3D);
        }
    }
    
    public final Point3D getAxis() {
        return (this.axis == null) ? RotateTransition.DEFAULT_AXIS : this.axis.get();
    }
    
    public final ObjectProperty<Point3D> axisProperty() {
        if (this.axis == null) {
            this.axis = new SimpleObjectProperty<Point3D>(this, "axis", RotateTransition.DEFAULT_AXIS);
        }
        return this.axis;
    }
    
    public final void setFromAngle(final double v) {
        if (this.fromAngle != null || !Double.isNaN(v)) {
            this.fromAngleProperty().set(v);
        }
    }
    
    public final double getFromAngle() {
        return (this.fromAngle == null) ? Double.NaN : this.fromAngle.get();
    }
    
    public final DoubleProperty fromAngleProperty() {
        if (this.fromAngle == null) {
            this.fromAngle = new SimpleDoubleProperty(this, "fromAngle", Double.NaN);
        }
        return this.fromAngle;
    }
    
    public final void setToAngle(final double v) {
        if (this.toAngle != null || !Double.isNaN(v)) {
            this.toAngleProperty().set(v);
        }
    }
    
    public final double getToAngle() {
        return (this.toAngle == null) ? Double.NaN : this.toAngle.get();
    }
    
    public final DoubleProperty toAngleProperty() {
        if (this.toAngle == null) {
            this.toAngle = new SimpleDoubleProperty(this, "toAngle", Double.NaN);
        }
        return this.toAngle;
    }
    
    public final void setByAngle(final double n) {
        if (this.byAngle != null || Math.abs(n - 0.0) > 1.0E-12) {
            this.byAngleProperty().set(n);
        }
    }
    
    public final double getByAngle() {
        return (this.byAngle == null) ? 0.0 : this.byAngle.get();
    }
    
    public final DoubleProperty byAngleProperty() {
        if (this.byAngle == null) {
            this.byAngle = new SimpleDoubleProperty(this, "byAngle", 0.0);
        }
        return this.byAngle;
    }
    
    public RotateTransition(final Duration duration, final Node node) {
        this.setDuration(duration);
        this.setNode(node);
        this.setCycleDuration(duration);
    }
    
    public RotateTransition(final Duration duration) {
        this(duration, null);
    }
    
    public RotateTransition() {
        this(RotateTransition.DEFAULT_DURATION, null);
    }
    
    @Override
    protected void interpolate(final double n) {
        this.cachedNode.setRotate(this.start + n * this.delta);
    }
    
    private Node getTargetNode() {
        final Node node = this.getNode();
        return (node != null) ? node : this.getParentTargetNode();
    }
    
    @Override
    boolean startable(final boolean b) {
        return super.startable(b) && (this.getTargetNode() != null || (!b && this.cachedNode != null));
    }
    
    @Override
    void sync(final boolean b) {
        super.sync(b);
        if (b || this.cachedNode == null) {
            this.cachedNode = this.getTargetNode();
            final double fromAngle = this.getFromAngle();
            final double toAngle = this.getToAngle();
            this.start = (Double.isNaN(fromAngle) ? this.cachedNode.getRotate() : fromAngle);
            this.delta = (Double.isNaN(toAngle) ? this.getByAngle() : (toAngle - this.start));
            final Point3D axis = this.getAxis();
            if (axis != null) {
                this.node.get().setRotationAxis(axis);
            }
        }
    }
    
    static {
        DEFAULT_NODE = null;
        DEFAULT_DURATION = Duration.millis(400.0);
        DEFAULT_AXIS = null;
    }
}
