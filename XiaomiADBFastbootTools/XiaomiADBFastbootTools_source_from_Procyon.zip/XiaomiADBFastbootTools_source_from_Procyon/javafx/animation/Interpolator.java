// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import com.sun.scenario.animation.NumberTangentInterpolator;
import javafx.util.Duration;
import com.sun.scenario.animation.SplineInterpolator;

public abstract class Interpolator
{
    private static final double EPSILON = 1.0E-12;
    public static final Interpolator DISCRETE;
    public static final Interpolator LINEAR;
    public static final Interpolator EASE_BOTH;
    public static final Interpolator EASE_IN;
    public static final Interpolator EASE_OUT;
    
    protected Interpolator() {
    }
    
    public static Interpolator SPLINE(final double n, final double n2, final double n3, final double n4) {
        return new SplineInterpolator(n, n2, n3, n4);
    }
    
    public static Interpolator TANGENT(final Duration duration, final double n, final Duration duration2, final double n2) {
        return new NumberTangentInterpolator(duration, n, duration2, n2);
    }
    
    public static Interpolator TANGENT(final Duration duration, final double n) {
        return new NumberTangentInterpolator(duration, n);
    }
    
    public Object interpolate(final Object o, final Object o2, final double n) {
        if (o instanceof Number && o2 instanceof Number) {
            final double doubleValue = ((Number)o).doubleValue();
            final double a = doubleValue + (((Number)o2).doubleValue() - doubleValue) * this.curve(n);
            if (o instanceof Double || o2 instanceof Double) {
                return a;
            }
            if (o instanceof Float || o2 instanceof Float) {
                return (float)a;
            }
            if (o instanceof Long || o2 instanceof Long) {
                return Math.round(a);
            }
            return (int)Math.round(a);
        }
        else {
            if (o instanceof Interpolatable && o2 instanceof Interpolatable) {
                return ((Interpolatable)o).interpolate(o2, this.curve(n));
            }
            return (this.curve(n) == 1.0) ? o2 : o;
        }
    }
    
    public boolean interpolate(final boolean b, final boolean b2, final double n) {
        return (Math.abs(this.curve(n) - 1.0) < 1.0E-12) ? b2 : b;
    }
    
    public double interpolate(final double n, final double n2, final double n3) {
        return n + (n2 - n) * this.curve(n3);
    }
    
    public int interpolate(final int n, final int n2, final double n3) {
        return n + (int)Math.round((n2 - n) * this.curve(n3));
    }
    
    public long interpolate(final long n, final long n2, final double n3) {
        return n + Math.round((n2 - n) * this.curve(n3));
    }
    
    private static double clamp(final double n) {
        return (n < 0.0) ? 0.0 : ((n > 1.0) ? 1.0 : n);
    }
    
    protected abstract double curve(final double p0);
    
    static {
        DISCRETE = new Interpolator() {
            @Override
            protected double curve(final double n) {
                return (Math.abs(n - 1.0) < 1.0E-12) ? 1.0 : 0.0;
            }
            
            @Override
            public String toString() {
                return "Interpolator.DISCRETE";
            }
        };
        LINEAR = new Interpolator() {
            @Override
            protected double curve(final double n) {
                return n;
            }
            
            @Override
            public String toString() {
                return "Interpolator.LINEAR";
            }
        };
        EASE_BOTH = new Interpolator() {
            @Override
            protected double curve(final double n) {
                return clamp((n < 0.2) ? (3.125 * n * n) : ((n > 0.8) ? (-3.125 * n * n + 6.25 * n - 2.125) : (1.25 * n - 0.125)));
            }
            
            @Override
            public String toString() {
                return "Interpolator.EASE_BOTH";
            }
        };
        EASE_IN = new Interpolator() {
            private static final double S1 = 2.7777777777777777;
            private static final double S3 = 1.1111111111111112;
            private static final double S4 = 0.1111111111111111;
            
            @Override
            protected double curve(final double n) {
                return clamp((n < 0.2) ? (2.7777777777777777 * n * n) : (1.1111111111111112 * n - 0.1111111111111111));
            }
            
            @Override
            public String toString() {
                return "Interpolator.EASE_IN";
            }
        };
        EASE_OUT = new Interpolator() {
            private static final double S1 = -2.7777777777777777;
            private static final double S2 = 5.555555555555555;
            private static final double S3 = -1.7777777777777777;
            private static final double S4 = 1.1111111111111112;
            
            @Override
            protected double curve(final double n) {
                return clamp((n > 0.8) ? (-2.7777777777777777 * n * n + 5.555555555555555 * n - 1.7777777777777777) : (1.1111111111111112 * n));
            }
            
            @Override
            public String toString() {
                return "Interpolator.EASE_OUT";
            }
        };
    }
}
