// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import javafx.event.EventHandler;
import javafx.event.EventTarget;
import javafx.event.ActionEvent;
import com.sun.javafx.animation.TickCalculation;
import java.util.Arrays;
import javafx.util.Duration;
import com.sun.scenario.animation.AbstractMasterTimer;
import java.util.Collection;
import java.util.List;
import com.sun.javafx.collections.VetoableListDecorator;
import java.util.Iterator;
import javafx.beans.Observable;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import java.util.HashSet;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ObservableList;
import java.util.Set;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.InvalidationListener;

public final class SequentialTransition extends Transition
{
    private static final Animation[] EMPTY_ANIMATION_ARRAY;
    private static final int BEFORE = -1;
    private static final double EPSILON = 1.0E-12;
    private Animation[] cachedChildren;
    private long[] startTimes;
    private long[] durations;
    private long[] delays;
    private double[] rates;
    private boolean[] forceChildSync;
    private int end;
    private int curIndex;
    private long oldTicks;
    private long offsetTicks;
    private boolean childrenChanged;
    private boolean toggledRate;
    private final InvalidationListener childrenListener;
    private final ChangeListener<Number> rateListener;
    private ObjectProperty<Node> node;
    private static final Node DEFAULT_NODE;
    private final Set<Animation> childrenSet;
    private final ObservableList<Animation> children;
    
    public final void setNode(final Node node) {
        if (this.node != null || node != null) {
            this.nodeProperty().set(node);
        }
    }
    
    public final Node getNode() {
        return (this.node == null) ? SequentialTransition.DEFAULT_NODE : this.node.get();
    }
    
    public final ObjectProperty<Node> nodeProperty() {
        if (this.node == null) {
            this.node = new SimpleObjectProperty<Node>(this, "node", SequentialTransition.DEFAULT_NODE);
        }
        return this.node;
    }
    
    private static boolean checkCycle(final Animation animation, final Animation animation2) {
        for (Animation parent = animation2; parent != animation; parent = parent.parent) {
            if (parent.parent == null) {
                return false;
            }
        }
        return true;
    }
    
    public final ObservableList<Animation> getChildren() {
        return this.children;
    }
    
    public SequentialTransition(final Node node, final Animation... all) {
        this.cachedChildren = SequentialTransition.EMPTY_ANIMATION_ARRAY;
        this.curIndex = -1;
        this.oldTicks = 0L;
        this.childrenChanged = true;
        this.childrenListener = (p0 -> {
            this.childrenChanged = true;
            if (this.getStatus() == Status.STOPPED) {
                this.setCycleDuration(this.computeCycleDuration());
            }
            return;
        });
        this.rateListener = new ChangeListener<Number>() {
            @Override
            public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
                if (n.doubleValue() * n2.doubleValue() < 0.0) {
                    for (int i = 0; i < SequentialTransition.this.cachedChildren.length; ++i) {
                        SequentialTransition.this.cachedChildren[i].clipEnvelope.setRate(SequentialTransition.this.rates[i] * Math.signum(SequentialTransition.this.getCurrentRate()));
                    }
                    SequentialTransition.this.toggledRate = true;
                }
            }
        };
        this.childrenSet = new HashSet<Animation>();
        this.children = new VetoableListDecorator<Animation>((ObservableList)new TrackableObservableList<Animation>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Animation> change) {
                while (change.next()) {
                    for (final Animation animation : change.getRemoved()) {
                        animation.parent = null;
                        animation.rateProperty().removeListener(SequentialTransition.this.childrenListener);
                        animation.totalDurationProperty().removeListener(SequentialTransition.this.childrenListener);
                        animation.delayProperty().removeListener(SequentialTransition.this.childrenListener);
                    }
                    for (final Animation animation2 : change.getAddedSubList()) {
                        animation2.parent = SequentialTransition.this;
                        animation2.rateProperty().addListener(SequentialTransition.this.childrenListener);
                        animation2.totalDurationProperty().addListener(SequentialTransition.this.childrenListener);
                        animation2.delayProperty().addListener(SequentialTransition.this.childrenListener);
                    }
                }
                SequentialTransition.this.childrenListener.invalidated(SequentialTransition.this.children);
            }
        }) {
            @Override
            protected void onProposedChange(final List<Animation> list, final int... array) {
                Object o = null;
                for (int i = 0; i < array.length; i += 2) {
                    for (int j = array[i]; j < array[i + 1]; ++j) {
                        SequentialTransition.this.childrenSet.remove(SequentialTransition.this.children.get(j));
                    }
                }
                for (final Animation animation : list) {
                    if (animation == null) {
                        o = new IllegalArgumentException("Child cannot be null");
                        break;
                    }
                    if (!SequentialTransition.this.childrenSet.add(animation)) {
                        o = new IllegalArgumentException("Attempting to add a duplicate to the list of children");
                        break;
                    }
                    if (checkCycle(animation, SequentialTransition.this)) {
                        o = new IllegalArgumentException("This change would create cycle");
                        break;
                    }
                }
                if (o != null) {
                    SequentialTransition.this.childrenSet.clear();
                    SequentialTransition.this.childrenSet.addAll(SequentialTransition.this.children);
                    throw o;
                }
            }
        };
        this.setInterpolator(Interpolator.LINEAR);
        this.setNode(node);
        this.getChildren().setAll(all);
    }
    
    public SequentialTransition(final Animation... array) {
        this((Node)null, array);
    }
    
    public SequentialTransition(final Node node) {
        this.cachedChildren = SequentialTransition.EMPTY_ANIMATION_ARRAY;
        this.curIndex = -1;
        this.oldTicks = 0L;
        this.childrenChanged = true;
        this.childrenListener = (p0 -> {
            this.childrenChanged = true;
            if (this.getStatus() == Status.STOPPED) {
                this.setCycleDuration(this.computeCycleDuration());
            }
            return;
        });
        this.rateListener = new ChangeListener<Number>() {
            @Override
            public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
                if (n.doubleValue() * n2.doubleValue() < 0.0) {
                    for (int i = 0; i < SequentialTransition.this.cachedChildren.length; ++i) {
                        SequentialTransition.this.cachedChildren[i].clipEnvelope.setRate(SequentialTransition.this.rates[i] * Math.signum(SequentialTransition.this.getCurrentRate()));
                    }
                    SequentialTransition.this.toggledRate = true;
                }
            }
        };
        this.childrenSet = new HashSet<Animation>();
        this.children = new VetoableListDecorator<Animation>((ObservableList)new TrackableObservableList<Animation>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Animation> change) {
                while (change.next()) {
                    for (final Animation animation : change.getRemoved()) {
                        animation.parent = null;
                        animation.rateProperty().removeListener(SequentialTransition.this.childrenListener);
                        animation.totalDurationProperty().removeListener(SequentialTransition.this.childrenListener);
                        animation.delayProperty().removeListener(SequentialTransition.this.childrenListener);
                    }
                    for (final Animation animation2 : change.getAddedSubList()) {
                        animation2.parent = SequentialTransition.this;
                        animation2.rateProperty().addListener(SequentialTransition.this.childrenListener);
                        animation2.totalDurationProperty().addListener(SequentialTransition.this.childrenListener);
                        animation2.delayProperty().addListener(SequentialTransition.this.childrenListener);
                    }
                }
                SequentialTransition.this.childrenListener.invalidated(SequentialTransition.this.children);
            }
        }) {
            @Override
            protected void onProposedChange(final List<Animation> list, final int... array) {
                Object o = null;
                for (int i = 0; i < array.length; i += 2) {
                    for (int j = array[i]; j < array[i + 1]; ++j) {
                        SequentialTransition.this.childrenSet.remove(SequentialTransition.this.children.get(j));
                    }
                }
                for (final Animation animation : list) {
                    if (animation == null) {
                        o = new IllegalArgumentException("Child cannot be null");
                        break;
                    }
                    if (!SequentialTransition.this.childrenSet.add(animation)) {
                        o = new IllegalArgumentException("Attempting to add a duplicate to the list of children");
                        break;
                    }
                    if (checkCycle(animation, SequentialTransition.this)) {
                        o = new IllegalArgumentException("This change would create cycle");
                        break;
                    }
                }
                if (o != null) {
                    SequentialTransition.this.childrenSet.clear();
                    SequentialTransition.this.childrenSet.addAll(SequentialTransition.this.children);
                    throw o;
                }
            }
        };
        this.setInterpolator(Interpolator.LINEAR);
        this.setNode(node);
    }
    
    public SequentialTransition() {
        this((Node)null);
    }
    
    SequentialTransition(final AbstractMasterTimer abstractMasterTimer) {
        super(abstractMasterTimer);
        this.cachedChildren = SequentialTransition.EMPTY_ANIMATION_ARRAY;
        this.curIndex = -1;
        this.oldTicks = 0L;
        this.childrenChanged = true;
        this.childrenListener = (p0 -> {
            this.childrenChanged = true;
            if (this.getStatus() == Status.STOPPED) {
                this.setCycleDuration(this.computeCycleDuration());
            }
            return;
        });
        this.rateListener = new ChangeListener<Number>() {
            @Override
            public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
                if (n.doubleValue() * n2.doubleValue() < 0.0) {
                    for (int i = 0; i < SequentialTransition.this.cachedChildren.length; ++i) {
                        SequentialTransition.this.cachedChildren[i].clipEnvelope.setRate(SequentialTransition.this.rates[i] * Math.signum(SequentialTransition.this.getCurrentRate()));
                    }
                    SequentialTransition.this.toggledRate = true;
                }
            }
        };
        this.childrenSet = new HashSet<Animation>();
        this.children = new VetoableListDecorator<Animation>((ObservableList)new TrackableObservableList<Animation>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Animation> change) {
                while (change.next()) {
                    for (final Animation animation : change.getRemoved()) {
                        animation.parent = null;
                        animation.rateProperty().removeListener(SequentialTransition.this.childrenListener);
                        animation.totalDurationProperty().removeListener(SequentialTransition.this.childrenListener);
                        animation.delayProperty().removeListener(SequentialTransition.this.childrenListener);
                    }
                    for (final Animation animation2 : change.getAddedSubList()) {
                        animation2.parent = SequentialTransition.this;
                        animation2.rateProperty().addListener(SequentialTransition.this.childrenListener);
                        animation2.totalDurationProperty().addListener(SequentialTransition.this.childrenListener);
                        animation2.delayProperty().addListener(SequentialTransition.this.childrenListener);
                    }
                }
                SequentialTransition.this.childrenListener.invalidated(SequentialTransition.this.children);
            }
        }) {
            @Override
            protected void onProposedChange(final List<Animation> list, final int... array) {
                Object o = null;
                for (int i = 0; i < array.length; i += 2) {
                    for (int j = array[i]; j < array[i + 1]; ++j) {
                        SequentialTransition.this.childrenSet.remove(SequentialTransition.this.children.get(j));
                    }
                }
                for (final Animation animation : list) {
                    if (animation == null) {
                        o = new IllegalArgumentException("Child cannot be null");
                        break;
                    }
                    if (!SequentialTransition.this.childrenSet.add(animation)) {
                        o = new IllegalArgumentException("Attempting to add a duplicate to the list of children");
                        break;
                    }
                    if (checkCycle(animation, SequentialTransition.this)) {
                        o = new IllegalArgumentException("This change would create cycle");
                        break;
                    }
                }
                if (o != null) {
                    SequentialTransition.this.childrenSet.clear();
                    SequentialTransition.this.childrenSet.addAll(SequentialTransition.this.children);
                    throw o;
                }
            }
        };
        this.setInterpolator(Interpolator.LINEAR);
    }
    
    @Override
    protected Node getParentTargetNode() {
        final Node node = this.getNode();
        return (node != null) ? node : ((this.parent != null && this.parent instanceof Transition) ? ((Transition)this.parent).getParentTargetNode() : null);
    }
    
    private Duration computeCycleDuration() {
        Duration duration = Duration.ZERO;
        for (final Animation animation : this.getChildren()) {
            final Duration add = duration.add(animation.getDelay());
            final double abs = Math.abs(animation.getRate());
            duration = add.add((abs < 1.0E-12) ? animation.getTotalDuration() : animation.getTotalDuration().divide(abs));
            if (duration.isIndefinite()) {
                break;
            }
        }
        return duration;
    }
    
    private double calculateFraction(final long n, final long n2) {
        final double n3 = n / (double)n2;
        return (n3 <= 0.0) ? 0.0 : ((n3 >= 1.0) ? 1.0 : n3);
    }
    
    private int findNewIndex(final long key) {
        if (this.curIndex != -1 && this.curIndex != this.end && this.startTimes[this.curIndex] <= key && key <= this.startTimes[this.curIndex + 1]) {
            return this.curIndex;
        }
        final boolean b = this.curIndex == -1 || this.curIndex == this.end;
        final int binarySearch = Arrays.binarySearch(this.startTimes, (b || key < this.oldTicks) ? 0 : (this.curIndex + 1), (b || this.oldTicks < key) ? this.end : this.curIndex, key);
        return (binarySearch < 0) ? (-binarySearch - 2) : ((binarySearch > 0) ? (binarySearch - 1) : 0);
    }
    
    @Override
    void sync(final boolean b) {
        super.sync(b);
        if ((b && this.childrenChanged) || this.startTimes == null) {
            this.cachedChildren = this.getChildren().toArray(SequentialTransition.EMPTY_ANIMATION_ARRAY);
            this.end = this.cachedChildren.length;
            this.startTimes = new long[this.end + 1];
            this.durations = new long[this.end];
            this.delays = new long[this.end];
            this.rates = new double[this.end];
            this.forceChildSync = new boolean[this.end];
            long add = 0L;
            int n = 0;
            for (final Animation animation : this.cachedChildren) {
                this.startTimes[n] = add;
                this.rates[n] = Math.abs(animation.getRate());
                if (this.rates[n] < 1.0E-12) {
                    this.rates[n] = 1.0;
                }
                this.durations[n] = TickCalculation.fromDuration(animation.getTotalDuration(), this.rates[n]);
                this.delays[n] = TickCalculation.fromDuration(animation.getDelay());
                if (this.durations[n] == Long.MAX_VALUE || this.delays[n] == Long.MAX_VALUE || add == Long.MAX_VALUE) {
                    add = Long.MAX_VALUE;
                }
                else {
                    add = TickCalculation.add(add, TickCalculation.add(this.durations[n], this.delays[n]));
                }
                this.forceChildSync[n] = true;
                ++n;
            }
            this.startTimes[this.end] = add;
            this.childrenChanged = false;
        }
        else if (b) {
            for (int length2 = this.forceChildSync.length, j = 0; j < length2; ++j) {
                this.forceChildSync[j] = true;
            }
        }
    }
    
    @Override
    void doStart(final boolean b) {
        super.doStart(b);
        this.toggledRate = false;
        this.rateProperty().addListener(this.rateListener);
        this.offsetTicks = 0L;
        final double currentRate = this.getCurrentRate();
        final long fromDuration = TickCalculation.fromDuration(this.getCurrentTime());
        if (currentRate < 0.0) {
            this.jumpToEnd();
            this.curIndex = this.end;
            if (fromDuration < this.startTimes[this.end]) {
                this.doJumpTo(fromDuration, this.startTimes[this.end], false);
            }
        }
        else {
            this.jumpToBefore();
            this.curIndex = -1;
            if (fromDuration > 0L) {
                this.doJumpTo(fromDuration, this.startTimes[this.end], false);
            }
        }
    }
    
    @Override
    void doPause() {
        super.doPause();
        if (this.curIndex != -1 && this.curIndex != this.end) {
            final Animation animation = this.cachedChildren[this.curIndex];
            if (animation.getStatus() == Status.RUNNING) {
                animation.doPause();
            }
        }
    }
    
    @Override
    void doResume() {
        super.doResume();
        if (this.curIndex != -1 && this.curIndex != this.end) {
            final Animation animation = this.cachedChildren[this.curIndex];
            if (animation.getStatus() == Status.PAUSED) {
                animation.doResume();
                animation.clipEnvelope.setRate(this.rates[this.curIndex] * Math.signum(this.getCurrentRate()));
            }
        }
    }
    
    @Override
    void doStop() {
        super.doStop();
        if (this.curIndex != -1 && this.curIndex != this.end) {
            final Animation animation = this.cachedChildren[this.curIndex];
            if (animation.getStatus() != Status.STOPPED) {
                animation.doStop();
            }
        }
        if (this.childrenChanged) {
            this.setCycleDuration(this.computeCycleDuration());
        }
        this.rateProperty().removeListener(this.rateListener);
    }
    
    private boolean startChild(final Animation animation, final int n) {
        final boolean b = this.forceChildSync[n];
        if (animation.startable(b)) {
            animation.clipEnvelope.setRate(this.rates[n] * Math.signum(this.getCurrentRate()));
            animation.doStart(b);
            this.forceChildSync[n] = false;
            return true;
        }
        return false;
    }
    
    @Override
    void doPlayTo(final long currentTicks, final long b) {
        this.setCurrentTicks(currentTicks);
        final long max = Math.max(0L, Math.min(this.getCachedInterpolator().interpolate(0L, b, this.calculateFraction(currentTicks, b)), b));
        final int newIndex = this.findNewIndex(max);
        final Animation animation = (this.curIndex == -1 || this.curIndex == this.end) ? null : this.cachedChildren[this.curIndex];
        if (this.toggledRate) {
            if (animation != null && animation.getStatus() == Status.RUNNING) {
                this.offsetTicks -= (long)(Math.signum(this.getCurrentRate()) * (this.durations[this.curIndex] - 2L * (this.oldTicks - this.delays[this.curIndex] - this.startTimes[this.curIndex])));
            }
            this.toggledRate = false;
        }
        if (this.curIndex == newIndex) {
            if (this.getCurrentRate() > 0.0) {
                final long add = TickCalculation.add(this.startTimes[this.curIndex], this.delays[this.curIndex]);
                if (max >= add) {
                    if (this.oldTicks <= add || animation.getStatus() == Status.STOPPED) {
                        final boolean b2 = this.oldTicks <= add;
                        if (b2) {
                            animation.clipEnvelope.jumpTo(0L);
                        }
                        if (!this.startChild(animation, this.curIndex)) {
                            if (b2) {
                                final EventHandler<ActionEvent> onFinished = animation.getOnFinished();
                                if (onFinished != null) {
                                    onFinished.handle(new ActionEvent(this, null));
                                }
                            }
                            this.oldTicks = max;
                            return;
                        }
                    }
                    if (max >= this.startTimes[this.curIndex + 1]) {
                        animation.doTimePulse(TickCalculation.sub(this.durations[this.curIndex], this.offsetTicks));
                        if (max == b) {
                            this.curIndex = this.end;
                        }
                    }
                    else {
                        animation.doTimePulse(TickCalculation.sub(max - add, this.offsetTicks));
                    }
                }
            }
            else {
                final long add2 = TickCalculation.add(this.startTimes[this.curIndex], this.delays[this.curIndex]);
                if (this.oldTicks >= this.startTimes[this.curIndex + 1] || (this.oldTicks >= add2 && animation.getStatus() == Status.STOPPED)) {
                    final boolean b3 = this.oldTicks >= this.startTimes[this.curIndex + 1];
                    if (b3) {
                        animation.clipEnvelope.jumpTo(Math.round(this.durations[this.curIndex] * this.rates[this.curIndex]));
                    }
                    if (!this.startChild(animation, this.curIndex)) {
                        if (b3) {
                            final EventHandler<ActionEvent> onFinished2 = animation.getOnFinished();
                            if (onFinished2 != null) {
                                onFinished2.handle(new ActionEvent(this, null));
                            }
                        }
                        this.oldTicks = max;
                        return;
                    }
                }
                if (max <= add2) {
                    animation.doTimePulse(TickCalculation.sub(this.durations[this.curIndex], this.offsetTicks));
                    if (max == 0L) {
                        this.curIndex = -1;
                    }
                }
                else {
                    animation.doTimePulse(TickCalculation.sub(this.startTimes[this.curIndex + 1] - max, this.offsetTicks));
                }
            }
        }
        else if (this.curIndex < newIndex) {
            if (animation != null) {
                final long add3 = TickCalculation.add(this.startTimes[this.curIndex], this.delays[this.curIndex]);
                if (this.oldTicks <= add3 || (animation.getStatus() == Status.STOPPED && this.oldTicks != this.startTimes[this.curIndex + 1])) {
                    final boolean b4 = this.oldTicks <= add3;
                    if (b4) {
                        animation.clipEnvelope.jumpTo(0L);
                    }
                    if (!this.startChild(animation, this.curIndex) && b4) {
                        final EventHandler<ActionEvent> onFinished3 = animation.getOnFinished();
                        if (onFinished3 != null) {
                            onFinished3.handle(new ActionEvent(this, null));
                        }
                    }
                }
                if (animation.getStatus() == Status.RUNNING) {
                    animation.doTimePulse(TickCalculation.sub(this.durations[this.curIndex], this.offsetTicks));
                }
                this.oldTicks = this.startTimes[this.curIndex + 1];
            }
            this.offsetTicks = 0L;
            ++this.curIndex;
            while (this.curIndex < newIndex) {
                final Animation animation2 = this.cachedChildren[this.curIndex];
                animation2.clipEnvelope.jumpTo(0L);
                if (this.startChild(animation2, this.curIndex)) {
                    animation2.doTimePulse(this.durations[this.curIndex]);
                }
                else {
                    final EventHandler<ActionEvent> onFinished4 = animation2.getOnFinished();
                    if (onFinished4 != null) {
                        onFinished4.handle(new ActionEvent(this, null));
                    }
                }
                this.oldTicks = this.startTimes[this.curIndex + 1];
                ++this.curIndex;
            }
            final Animation animation3 = this.cachedChildren[this.curIndex];
            animation3.clipEnvelope.jumpTo(0L);
            if (this.startChild(animation3, this.curIndex)) {
                if (max >= this.startTimes[this.curIndex + 1]) {
                    animation3.doTimePulse(this.durations[this.curIndex]);
                    if (max == b) {
                        this.curIndex = this.end;
                    }
                }
                else {
                    animation3.doTimePulse(TickCalculation.sub(max, TickCalculation.add(this.startTimes[this.curIndex], this.delays[this.curIndex])));
                }
            }
            else {
                final EventHandler<ActionEvent> onFinished5 = animation3.getOnFinished();
                if (onFinished5 != null) {
                    onFinished5.handle(new ActionEvent(this, null));
                }
            }
        }
        else {
            if (animation != null) {
                final long add4 = TickCalculation.add(this.startTimes[this.curIndex], this.delays[this.curIndex]);
                if (this.oldTicks >= this.startTimes[this.curIndex + 1] || (this.oldTicks > add4 && animation.getStatus() == Status.STOPPED)) {
                    final boolean b5 = this.oldTicks >= this.startTimes[this.curIndex + 1];
                    if (b5) {
                        animation.clipEnvelope.jumpTo(Math.round(this.durations[this.curIndex] * this.rates[this.curIndex]));
                    }
                    if (!this.startChild(animation, this.curIndex) && b5) {
                        final EventHandler<ActionEvent> onFinished6 = animation.getOnFinished();
                        if (onFinished6 != null) {
                            onFinished6.handle(new ActionEvent(this, null));
                        }
                    }
                }
                if (animation.getStatus() == Status.RUNNING) {
                    animation.doTimePulse(TickCalculation.sub(this.durations[this.curIndex], this.offsetTicks));
                }
                this.oldTicks = this.startTimes[this.curIndex];
            }
            this.offsetTicks = 0L;
            --this.curIndex;
            while (this.curIndex > newIndex) {
                final Animation animation4 = this.cachedChildren[this.curIndex];
                animation4.clipEnvelope.jumpTo(Math.round(this.durations[this.curIndex] * this.rates[this.curIndex]));
                if (this.startChild(animation4, this.curIndex)) {
                    animation4.doTimePulse(this.durations[this.curIndex]);
                }
                else {
                    final EventHandler<ActionEvent> onFinished7 = animation4.getOnFinished();
                    if (onFinished7 != null) {
                        onFinished7.handle(new ActionEvent(this, null));
                    }
                }
                this.oldTicks = this.startTimes[this.curIndex];
                --this.curIndex;
            }
            final Animation animation5 = this.cachedChildren[this.curIndex];
            animation5.clipEnvelope.jumpTo(Math.round(this.durations[this.curIndex] * this.rates[this.curIndex]));
            if (this.startChild(animation5, this.curIndex)) {
                if (max <= TickCalculation.add(this.startTimes[this.curIndex], this.delays[this.curIndex])) {
                    animation5.doTimePulse(this.durations[this.curIndex]);
                    if (max == 0L) {
                        this.curIndex = -1;
                    }
                }
                else {
                    animation5.doTimePulse(TickCalculation.sub(this.startTimes[this.curIndex + 1], max));
                }
            }
            else {
                final EventHandler<ActionEvent> onFinished8 = animation5.getOnFinished();
                if (onFinished8 != null) {
                    onFinished8.handle(new ActionEvent(this, null));
                }
            }
        }
        this.oldTicks = max;
    }
    
    @Override
    void doJumpTo(final long currentTicks, final long b, final boolean b2) {
        this.setCurrentTicks(currentTicks);
        final Status status = this.getStatus();
        if (status == Status.STOPPED && !b2) {
            return;
        }
        this.sync(false);
        final long max = Math.max(0L, Math.min(this.getCachedInterpolator().interpolate(0L, b, this.calculateFraction(currentTicks, b)), b));
        final int curIndex = this.curIndex;
        this.curIndex = this.findNewIndex(max);
        final Animation animation = this.cachedChildren[this.curIndex];
        final double currentRate = this.getCurrentRate();
        final long add = TickCalculation.add(this.startTimes[this.curIndex], this.delays[this.curIndex]);
        if (this.curIndex != curIndex && status != Status.STOPPED) {
            if (curIndex != -1 && curIndex != this.end && this.cachedChildren[curIndex].getStatus() != Status.STOPPED) {
                this.cachedChildren[curIndex].doStop();
            }
            if (this.curIndex < curIndex) {
                for (int i = (curIndex == this.end) ? (this.end - 1) : curIndex; i > this.curIndex; --i) {
                    this.cachedChildren[i].doJumpTo(0L, this.durations[i], true);
                }
            }
            else {
                for (int j = (curIndex == -1) ? 0 : curIndex; j < this.curIndex; ++j) {
                    this.cachedChildren[j].doJumpTo(this.durations[j], this.durations[j], true);
                }
            }
            if (max >= add) {
                this.startChild(animation, this.curIndex);
                if (status == Status.PAUSED) {
                    animation.doPause();
                }
            }
        }
        if (curIndex == this.curIndex) {
            if (currentRate == 0.0) {
                this.offsetTicks += (long)((max - this.oldTicks) * Math.signum(this.clipEnvelope.getCurrentRate()));
            }
            else {
                this.offsetTicks += ((currentRate > 0.0) ? (max - this.oldTicks) : (this.oldTicks - max));
            }
        }
        else if (currentRate == 0.0) {
            if (this.clipEnvelope.getCurrentRate() > 0.0) {
                this.offsetTicks = Math.max(0L, max - add);
            }
            else {
                this.offsetTicks = this.startTimes[this.curIndex] + this.durations[this.curIndex] - max;
            }
        }
        else {
            this.offsetTicks = ((currentRate > 0.0) ? Math.max(0L, max - add) : (this.startTimes[this.curIndex + 1] - max));
        }
        animation.clipEnvelope.jumpTo(Math.round(TickCalculation.sub(max, add) * this.rates[this.curIndex]));
        this.oldTicks = max;
    }
    
    private void jumpToEnd() {
        for (int i = 0; i < this.end; ++i) {
            if (this.forceChildSync[i]) {
                this.cachedChildren[i].sync(true);
            }
            this.cachedChildren[i].doJumpTo(this.durations[i], this.durations[i], true);
        }
    }
    
    private void jumpToBefore() {
        for (int i = this.end - 1; i >= 0; --i) {
            if (this.forceChildSync[i]) {
                this.cachedChildren[i].sync(true);
            }
            this.cachedChildren[i].doJumpTo(0L, this.durations[i], true);
        }
    }
    
    @Override
    protected void interpolate(final double n) {
    }
    
    static {
        EMPTY_ANIMATION_ARRAY = new Animation[0];
        DEFAULT_NODE = null;
    }
}
