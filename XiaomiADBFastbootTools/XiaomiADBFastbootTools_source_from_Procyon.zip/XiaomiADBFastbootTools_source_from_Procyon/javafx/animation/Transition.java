// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import javafx.scene.Node;
import com.sun.scenario.animation.AbstractMasterTimer;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.ObjectProperty;

public abstract class Transition extends Animation
{
    private ObjectProperty<Interpolator> interpolator;
    private static final Interpolator DEFAULT_INTERPOLATOR;
    private Interpolator cachedInterpolator;
    
    public final void setInterpolator(final Interpolator obj) {
        if (this.interpolator != null || !Transition.DEFAULT_INTERPOLATOR.equals(obj)) {
            this.interpolatorProperty().set(obj);
        }
    }
    
    public final Interpolator getInterpolator() {
        return (this.interpolator == null) ? Transition.DEFAULT_INTERPOLATOR : this.interpolator.get();
    }
    
    public final ObjectProperty<Interpolator> interpolatorProperty() {
        if (this.interpolator == null) {
            this.interpolator = new SimpleObjectProperty<Interpolator>(this, "interpolator", Transition.DEFAULT_INTERPOLATOR);
        }
        return this.interpolator;
    }
    
    protected Interpolator getCachedInterpolator() {
        return this.cachedInterpolator;
    }
    
    public Transition(final double n) {
        super(n);
    }
    
    public Transition() {
    }
    
    Transition(final AbstractMasterTimer abstractMasterTimer) {
        super(abstractMasterTimer);
    }
    
    protected Node getParentTargetNode() {
        return (this.parent != null && this.parent instanceof Transition) ? ((Transition)this.parent).getParentTargetNode() : null;
    }
    
    protected abstract void interpolate(final double p0);
    
    private double calculateFraction(final long n, final long n2) {
        return this.cachedInterpolator.interpolate(0.0, 1.0, (n2 <= 0L) ? 1.0 : (n / (double)n2));
    }
    
    @Override
    boolean startable(final boolean b) {
        return super.startable(b) && (this.getInterpolator() != null || (!b && this.cachedInterpolator != null));
    }
    
    @Override
    void sync(final boolean b) {
        super.sync(b);
        if (b || this.cachedInterpolator == null) {
            this.cachedInterpolator = this.getInterpolator();
        }
    }
    
    @Override
    void doPlayTo(final long currentTicks, final long n) {
        this.setCurrentTicks(currentTicks);
        this.interpolate(this.calculateFraction(currentTicks, n));
    }
    
    @Override
    void doJumpTo(final long currentTicks, final long n, final boolean b) {
        this.setCurrentTicks(currentTicks);
        if (this.getStatus() != Status.STOPPED || b) {
            this.sync(false);
            this.interpolate(this.calculateFraction(currentTicks, n));
        }
    }
    
    static {
        DEFAULT_INTERPOLATOR = Interpolator.EASE_BOTH;
    }
}
