// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import javafx.beans.property.ReadOnlyObjectPropertyBase;
import javafx.beans.property.ReadOnlyDoublePropertyBase;
import com.sun.javafx.tk.Toolkit;
import java.util.Map;
import javafx.collections.FXCollections;
import java.util.HashMap;
import javafx.event.EventTarget;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.IntegerPropertyBase;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.DoublePropertyBase;
import java.security.AccessController;
import com.sun.javafx.animation.TickCalculation;
import javafx.collections.ObservableMap;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.util.Duration;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.DoubleProperty;
import com.sun.scenario.animation.shared.ClipEnvelope;
import com.sun.scenario.animation.shared.PulseReceiver;
import java.security.AccessControlContext;
import com.sun.scenario.animation.AbstractMasterTimer;

public abstract class Animation
{
    public static final int INDEFINITE = -1;
    private static final double EPSILON = 1.0E-12;
    private long startTime;
    private long pauseTime;
    private boolean paused;
    private final AbstractMasterTimer timer;
    private AccessControlContext accessCtrlCtx;
    final PulseReceiver pulseReceiver;
    Animation parent;
    ClipEnvelope clipEnvelope;
    private boolean lastPlayedFinished;
    private boolean lastPlayedForward;
    private DoubleProperty rate;
    private static final double DEFAULT_RATE = 1.0;
    private double oldRate;
    private ReadOnlyDoubleProperty currentRate;
    private static final double DEFAULT_CURRENT_RATE = 0.0;
    private ReadOnlyObjectProperty<Duration> cycleDuration;
    private static final Duration DEFAULT_CYCLE_DURATION;
    private ReadOnlyObjectProperty<Duration> totalDuration;
    private static final Duration DEFAULT_TOTAL_DURATION;
    private CurrentTimeProperty currentTime;
    private long currentTicks;
    private ObjectProperty<Duration> delay;
    private static final Duration DEFAULT_DELAY;
    private IntegerProperty cycleCount;
    private static final int DEFAULT_CYCLE_COUNT = 1;
    private BooleanProperty autoReverse;
    private static final boolean DEFAULT_AUTO_REVERSE = false;
    private ReadOnlyObjectProperty<Status> status;
    private static final Status DEFAULT_STATUS;
    private final double targetFramerate;
    private final int resolution;
    private long lastPulse;
    private ObjectProperty<EventHandler<ActionEvent>> onFinished;
    private static final EventHandler<ActionEvent> DEFAULT_ON_FINISHED;
    private final ObservableMap<String, Duration> cuePoints;
    
    private long now() {
        return TickCalculation.fromNano(this.timer.nanos());
    }
    
    private void addPulseReceiver() {
        this.accessCtrlCtx = AccessController.getContext();
        this.timer.addPulseReceiver(this.pulseReceiver);
    }
    
    void startReceiver(final long n) {
        this.paused = false;
        this.startTime = this.now() + n;
        this.addPulseReceiver();
    }
    
    void pauseReceiver() {
        if (!this.paused) {
            this.pauseTime = this.now();
            this.paused = true;
            this.timer.removePulseReceiver(this.pulseReceiver);
        }
    }
    
    void resumeReceiver() {
        if (this.paused) {
            this.startTime += this.now() - this.pauseTime;
            this.paused = false;
            this.addPulseReceiver();
        }
    }
    
    public final void setRate(final double n) {
        if (this.rate != null || Math.abs(n - 1.0) > 1.0E-12) {
            this.rateProperty().set(n);
        }
    }
    
    public final double getRate() {
        return (this.rate == null) ? 1.0 : this.rate.get();
    }
    
    public final DoubleProperty rateProperty() {
        if (this.rate == null) {
            this.rate = new DoublePropertyBase(1.0) {
                public void invalidated() {
                    final double rate = Animation.this.getRate();
                    if (Animation.this.isRunningEmbedded()) {
                        if (this.isBound()) {
                            this.unbind();
                        }
                        this.set(Animation.this.oldRate);
                        throw new IllegalArgumentException("Cannot set rate of embedded animation while running.");
                    }
                    if (Math.abs(rate) < 1.0E-12) {
                        if (Animation.this.getStatus() == Status.RUNNING) {
                            Animation.this.lastPlayedForward = (Math.abs(Animation.this.getCurrentRate() - Animation.this.oldRate) < 1.0E-12);
                        }
                        Animation.this.doSetCurrentRate(0.0);
                        Animation.this.pauseReceiver();
                    }
                    else {
                        if (Animation.this.getStatus() == Status.RUNNING) {
                            final double currentRate = Animation.this.getCurrentRate();
                            if (Math.abs(currentRate) < 1.0E-12) {
                                Animation.this.doSetCurrentRate(Animation.this.lastPlayedForward ? rate : (-rate));
                                Animation.this.resumeReceiver();
                            }
                            else {
                                Animation.this.doSetCurrentRate((Math.abs(currentRate - Animation.this.oldRate) < 1.0E-12) ? rate : (-rate));
                            }
                        }
                        Animation.this.oldRate = rate;
                    }
                    Animation.this.clipEnvelope.setRate(rate);
                }
                
                @Override
                public Object getBean() {
                    return Animation.this;
                }
                
                @Override
                public String getName() {
                    return "rate";
                }
            };
        }
        return this.rate;
    }
    
    private boolean isRunningEmbedded() {
        return this.parent != null && (this.parent.getStatus() != Status.STOPPED || this.parent.isRunningEmbedded());
    }
    
    private void doSetCurrentRate(final double n) {
        if (this.currentRate != null || Math.abs(n - 0.0) > 1.0E-12) {
            ((CurrentRateProperty)this.currentRateProperty()).set(n);
        }
    }
    
    public final double getCurrentRate() {
        return (this.currentRate == null) ? 0.0 : this.currentRate.get();
    }
    
    public final ReadOnlyDoubleProperty currentRateProperty() {
        if (this.currentRate == null) {
            this.currentRate = new CurrentRateProperty();
        }
        return this.currentRate;
    }
    
    protected final void setCycleDuration(final Duration duration) {
        if (this.cycleDuration != null || !Animation.DEFAULT_CYCLE_DURATION.equals(duration)) {
            if (duration.lessThan(Duration.ZERO)) {
                throw new IllegalArgumentException("Cycle duration cannot be negative");
            }
            ((AnimationReadOnlyProperty)this.cycleDurationProperty()).set(duration);
            this.updateTotalDuration();
        }
    }
    
    public final Duration getCycleDuration() {
        return (this.cycleDuration == null) ? Animation.DEFAULT_CYCLE_DURATION : this.cycleDuration.get();
    }
    
    public final ReadOnlyObjectProperty<Duration> cycleDurationProperty() {
        if (this.cycleDuration == null) {
            this.cycleDuration = new AnimationReadOnlyProperty<Duration>("cycleDuration", (Object)Animation.DEFAULT_CYCLE_DURATION);
        }
        return this.cycleDuration;
    }
    
    public final Duration getTotalDuration() {
        return (this.totalDuration == null) ? Animation.DEFAULT_TOTAL_DURATION : this.totalDuration.get();
    }
    
    public final ReadOnlyObjectProperty<Duration> totalDurationProperty() {
        if (this.totalDuration == null) {
            this.totalDuration = new AnimationReadOnlyProperty<Duration>("totalDuration", (Object)Animation.DEFAULT_TOTAL_DURATION);
        }
        return this.totalDuration;
    }
    
    private void updateTotalDuration() {
        final int cycleCount = this.getCycleCount();
        final Duration cycleDuration = this.getCycleDuration();
        final Duration duration = Duration.ZERO.equals(cycleDuration) ? Duration.ZERO : ((cycleCount == -1) ? Duration.INDEFINITE : ((cycleCount <= 1) ? cycleDuration : cycleDuration.multiply(cycleCount)));
        if (this.totalDuration != null || !Animation.DEFAULT_TOTAL_DURATION.equals(duration)) {
            ((AnimationReadOnlyProperty)this.totalDurationProperty()).set(duration);
        }
        if (this.getStatus() == Status.STOPPED) {
            this.syncClipEnvelope();
            if (duration.lessThan(this.getCurrentTime())) {
                this.clipEnvelope.jumpTo(TickCalculation.fromDuration(duration));
            }
        }
    }
    
    public final Duration getCurrentTime() {
        return TickCalculation.toDuration(this.currentTicks);
    }
    
    public final ReadOnlyObjectProperty<Duration> currentTimeProperty() {
        if (this.currentTime == null) {
            this.currentTime = new CurrentTimeProperty();
        }
        return this.currentTime;
    }
    
    public final void setDelay(final Duration duration) {
        if (this.delay != null || !Animation.DEFAULT_DELAY.equals(duration)) {
            this.delayProperty().set(duration);
        }
    }
    
    public final Duration getDelay() {
        return (this.delay == null) ? Animation.DEFAULT_DELAY : this.delay.get();
    }
    
    public final ObjectProperty<Duration> delayProperty() {
        if (this.delay == null) {
            this.delay = new ObjectPropertyBase<Duration>(Animation.DEFAULT_DELAY) {
                @Override
                public Object getBean() {
                    return Animation.this;
                }
                
                @Override
                public String getName() {
                    return "delay";
                }
                
                @Override
                protected void invalidated() {
                    if (this.get().lessThan(Duration.ZERO)) {
                        if (this.isBound()) {
                            this.unbind();
                        }
                        this.set(Duration.ZERO);
                        throw new IllegalArgumentException("Cannot set delay to negative value. Setting to Duration.ZERO");
                    }
                }
            };
        }
        return this.delay;
    }
    
    public final void setCycleCount(final int n) {
        if (this.cycleCount != null || n != 1) {
            this.cycleCountProperty().set(n);
        }
    }
    
    public final int getCycleCount() {
        return (this.cycleCount == null) ? 1 : this.cycleCount.get();
    }
    
    public final IntegerProperty cycleCountProperty() {
        if (this.cycleCount == null) {
            this.cycleCount = new IntegerPropertyBase(1) {
                public void invalidated() {
                    Animation.this.updateTotalDuration();
                }
                
                @Override
                public Object getBean() {
                    return Animation.this;
                }
                
                @Override
                public String getName() {
                    return "cycleCount";
                }
            };
        }
        return this.cycleCount;
    }
    
    public final void setAutoReverse(final boolean b) {
        if (this.autoReverse != null || b) {
            this.autoReverseProperty().set(b);
        }
    }
    
    public final boolean isAutoReverse() {
        return this.autoReverse != null && this.autoReverse.get();
    }
    
    public final BooleanProperty autoReverseProperty() {
        if (this.autoReverse == null) {
            this.autoReverse = new SimpleBooleanProperty(this, "autoReverse", false);
        }
        return this.autoReverse;
    }
    
    protected final void setStatus(final Status other) {
        if (this.status != null || !Animation.DEFAULT_STATUS.equals(other)) {
            ((AnimationReadOnlyProperty)this.statusProperty()).set(other);
        }
    }
    
    public final Status getStatus() {
        return (this.status == null) ? Animation.DEFAULT_STATUS : this.status.get();
    }
    
    public final ReadOnlyObjectProperty<Status> statusProperty() {
        if (this.status == null) {
            this.status = new AnimationReadOnlyProperty<Status>("status", (Object)Status.STOPPED);
        }
        return this.status;
    }
    
    public final double getTargetFramerate() {
        return this.targetFramerate;
    }
    
    public final void setOnFinished(final EventHandler<ActionEvent> eventHandler) {
        if (this.onFinished != null || eventHandler != null) {
            this.onFinishedProperty().set(eventHandler);
        }
    }
    
    public final EventHandler<ActionEvent> getOnFinished() {
        return (this.onFinished == null) ? Animation.DEFAULT_ON_FINISHED : this.onFinished.get();
    }
    
    public final ObjectProperty<EventHandler<ActionEvent>> onFinishedProperty() {
        if (this.onFinished == null) {
            this.onFinished = new SimpleObjectProperty<EventHandler<ActionEvent>>(this, "onFinished", Animation.DEFAULT_ON_FINISHED);
        }
        return this.onFinished;
    }
    
    public final ObservableMap<String, Duration> getCuePoints() {
        return this.cuePoints;
    }
    
    public void jumpTo(Duration duration) {
        if (duration == null) {
            throw new NullPointerException("Time needs to be specified.");
        }
        if (duration.isUnknown()) {
            throw new IllegalArgumentException("The time is invalid");
        }
        if (this.parent != null) {
            throw new IllegalStateException("Cannot jump when embedded in another animation");
        }
        this.lastPlayedFinished = false;
        final Duration totalDuration = this.getTotalDuration();
        duration = (duration.lessThan(Duration.ZERO) ? Duration.ZERO : (duration.greaterThan(totalDuration) ? totalDuration : duration));
        final long fromDuration = TickCalculation.fromDuration(duration);
        if (this.getStatus() == Status.STOPPED) {
            this.syncClipEnvelope();
        }
        this.clipEnvelope.jumpTo(fromDuration);
    }
    
    public void jumpTo(final String s) {
        if (s == null) {
            throw new NullPointerException("CuePoint needs to be specified");
        }
        if ("start".equalsIgnoreCase(s)) {
            this.jumpTo(Duration.ZERO);
        }
        else if ("end".equalsIgnoreCase(s)) {
            this.jumpTo(this.getTotalDuration());
        }
        else {
            final Duration duration = this.getCuePoints().get(s);
            if (duration != null) {
                this.jumpTo(duration);
            }
        }
    }
    
    public void playFrom(final String s) {
        this.jumpTo(s);
        this.play();
    }
    
    public void playFrom(final Duration duration) {
        this.jumpTo(duration);
        this.play();
    }
    
    public void play() {
        if (this.parent != null) {
            throw new IllegalStateException("Cannot start when embedded in another animation");
        }
        switch (this.getStatus()) {
            case STOPPED: {
                if (this.startable(true)) {
                    final double rate = this.getRate();
                    if (this.lastPlayedFinished) {
                        this.jumpTo((rate < 0.0) ? this.getTotalDuration() : Duration.ZERO);
                    }
                    this.doStart(true);
                    this.startReceiver(TickCalculation.fromDuration(this.getDelay()));
                    if (Math.abs(rate) < 1.0E-12) {
                        this.pauseReceiver();
                    }
                    break;
                }
                final EventHandler<ActionEvent> onFinished = this.getOnFinished();
                if (onFinished != null) {
                    onFinished.handle(new ActionEvent(this, null));
                }
                break;
            }
            case PAUSED: {
                this.doResume();
                if (Math.abs(this.getRate()) >= 1.0E-12) {
                    this.resumeReceiver();
                    break;
                }
                break;
            }
        }
    }
    
    public void playFromStart() {
        this.stop();
        this.setRate(Math.abs(this.getRate()));
        this.jumpTo(Duration.ZERO);
        this.play();
    }
    
    public void stop() {
        if (this.parent != null) {
            throw new IllegalStateException("Cannot stop when embedded in another animation");
        }
        if (this.getStatus() != Status.STOPPED) {
            this.clipEnvelope.abortCurrentPulse();
            this.doStop();
            this.jumpTo(Duration.ZERO);
        }
    }
    
    public void pause() {
        if (this.parent != null) {
            throw new IllegalStateException("Cannot pause when embedded in another animation");
        }
        if (this.getStatus() == Status.RUNNING) {
            this.clipEnvelope.abortCurrentPulse();
            this.pauseReceiver();
            this.doPause();
        }
    }
    
    protected Animation(final double targetFramerate) {
        this.paused = false;
        this.accessCtrlCtx = null;
        this.pulseReceiver = new PulseReceiver() {
            @Override
            public void timePulse(final long n) {
                if (n - Animation.this.startTime < 0L) {
                    return;
                }
                if (Animation.this.accessCtrlCtx == null) {
                    throw new IllegalStateException("Error: AccessControlContext not captured");
                }
                final long n2;
                AccessController.doPrivileged(() -> {
                    Animation.this.doTimePulse(n2);
                    return null;
                }, Animation.this.accessCtrlCtx);
            }
        };
        this.parent = null;
        this.lastPlayedFinished = false;
        this.lastPlayedForward = true;
        this.oldRate = 1.0;
        this.cuePoints = FXCollections.observableMap(new HashMap<String, Duration>(0));
        this.targetFramerate = targetFramerate;
        this.resolution = (int)Math.max(1L, Math.round(6000.0 / targetFramerate));
        this.clipEnvelope = ClipEnvelope.create(this);
        this.timer = Toolkit.getToolkit().getMasterTimer();
    }
    
    protected Animation() {
        this.paused = false;
        this.accessCtrlCtx = null;
        this.pulseReceiver = new PulseReceiver() {
            @Override
            public void timePulse(final long n) {
                if (n - Animation.this.startTime < 0L) {
                    return;
                }
                if (Animation.this.accessCtrlCtx == null) {
                    throw new IllegalStateException("Error: AccessControlContext not captured");
                }
                final long n2;
                AccessController.doPrivileged(() -> {
                    Animation.this.doTimePulse(n2);
                    return null;
                }, Animation.this.accessCtrlCtx);
            }
        };
        this.parent = null;
        this.lastPlayedFinished = false;
        this.lastPlayedForward = true;
        this.oldRate = 1.0;
        this.cuePoints = FXCollections.observableMap(new HashMap<String, Duration>(0));
        this.resolution = 1;
        this.targetFramerate = 6000 / Toolkit.getToolkit().getMasterTimer().getDefaultResolution();
        this.clipEnvelope = ClipEnvelope.create(this);
        this.timer = Toolkit.getToolkit().getMasterTimer();
    }
    
    Animation(final AbstractMasterTimer timer) {
        this.paused = false;
        this.accessCtrlCtx = null;
        this.pulseReceiver = new PulseReceiver() {
            @Override
            public void timePulse(final long n) {
                if (n - Animation.this.startTime < 0L) {
                    return;
                }
                if (Animation.this.accessCtrlCtx == null) {
                    throw new IllegalStateException("Error: AccessControlContext not captured");
                }
                final long n2;
                AccessController.doPrivileged(() -> {
                    Animation.this.doTimePulse(n2);
                    return null;
                }, Animation.this.accessCtrlCtx);
            }
        };
        this.parent = null;
        this.lastPlayedFinished = false;
        this.lastPlayedForward = true;
        this.oldRate = 1.0;
        this.cuePoints = FXCollections.observableMap(new HashMap<String, Duration>(0));
        this.resolution = 1;
        this.targetFramerate = 6000 / timer.getDefaultResolution();
        this.clipEnvelope = ClipEnvelope.create(this);
        this.timer = timer;
    }
    
    Animation(final AbstractMasterTimer timer, final ClipEnvelope clipEnvelope, final int resolution) {
        this.paused = false;
        this.accessCtrlCtx = null;
        this.pulseReceiver = new PulseReceiver() {
            @Override
            public void timePulse(final long n) {
                if (n - Animation.this.startTime < 0L) {
                    return;
                }
                if (Animation.this.accessCtrlCtx == null) {
                    throw new IllegalStateException("Error: AccessControlContext not captured");
                }
                final long n2;
                AccessController.doPrivileged(() -> {
                    Animation.this.doTimePulse(n2);
                    return null;
                }, Animation.this.accessCtrlCtx);
            }
        };
        this.parent = null;
        this.lastPlayedFinished = false;
        this.lastPlayedForward = true;
        this.oldRate = 1.0;
        this.cuePoints = FXCollections.observableMap(new HashMap<String, Duration>(0));
        this.resolution = resolution;
        this.targetFramerate = 6000 / resolution;
        this.clipEnvelope = clipEnvelope;
        this.timer = timer;
    }
    
    boolean startable(final boolean b) {
        return TickCalculation.fromDuration(this.getCycleDuration()) > 0L || (!b && this.clipEnvelope.wasSynched());
    }
    
    void sync(final boolean b) {
        if (b || !this.clipEnvelope.wasSynched()) {
            this.syncClipEnvelope();
        }
    }
    
    private void syncClipEnvelope() {
        final int cycleCount = this.getCycleCount();
        (this.clipEnvelope = this.clipEnvelope.setCycleCount((cycleCount <= 0 && cycleCount != -1) ? 1 : cycleCount)).setCycleDuration(this.getCycleDuration());
        this.clipEnvelope.setAutoReverse(this.isAutoReverse());
    }
    
    void doStart(final boolean b) {
        this.sync(b);
        this.setStatus(Status.RUNNING);
        this.clipEnvelope.start();
        this.doSetCurrentRate(this.clipEnvelope.getCurrentRate());
        this.lastPulse = 0L;
    }
    
    void doPause() {
        if (Math.abs(this.getCurrentRate()) >= 1.0E-12) {
            this.lastPlayedForward = (Math.abs(this.getCurrentRate() - this.getRate()) < 1.0E-12);
        }
        this.doSetCurrentRate(0.0);
        this.setStatus(Status.PAUSED);
    }
    
    void doResume() {
        this.setStatus(Status.RUNNING);
        this.doSetCurrentRate(this.lastPlayedForward ? this.getRate() : (-this.getRate()));
    }
    
    void doStop() {
        if (!this.paused) {
            this.timer.removePulseReceiver(this.pulseReceiver);
        }
        this.setStatus(Status.STOPPED);
        this.doSetCurrentRate(0.0);
    }
    
    void doTimePulse(final long n) {
        if (this.resolution == 1) {
            this.clipEnvelope.timePulse(n);
        }
        else if (n - this.lastPulse >= this.resolution) {
            this.lastPulse = n / this.resolution * this.resolution;
            this.clipEnvelope.timePulse(n);
        }
    }
    
    abstract void doPlayTo(final long p0, final long p1);
    
    abstract void doJumpTo(final long p0, final long p1, final boolean p2);
    
    void setCurrentTicks(final long currentTicks) {
        this.currentTicks = currentTicks;
        if (this.currentTime != null) {
            this.currentTime.fireValueChangedEvent();
        }
    }
    
    void setCurrentRate(final double n) {
        this.doSetCurrentRate(n);
    }
    
    final void finished() {
        this.lastPlayedFinished = true;
        this.doStop();
        final EventHandler<ActionEvent> onFinished = this.getOnFinished();
        if (onFinished != null) {
            try {
                onFinished.handle(new ActionEvent(this, null));
            }
            catch (Exception ex) {
                Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), ex);
            }
        }
    }
    
    static {
        AnimationAccessorImpl.DEFAULT = new AnimationAccessorImpl();
        DEFAULT_CYCLE_DURATION = Duration.ZERO;
        DEFAULT_TOTAL_DURATION = Duration.ZERO;
        DEFAULT_DELAY = Duration.ZERO;
        DEFAULT_STATUS = Status.STOPPED;
        DEFAULT_ON_FINISHED = null;
    }
    
    public enum Status
    {
        PAUSED, 
        RUNNING, 
        STOPPED;
    }
    
    private class CurrentRateProperty extends ReadOnlyDoublePropertyBase
    {
        private double value;
        
        @Override
        public Object getBean() {
            return Animation.this;
        }
        
        @Override
        public String getName() {
            return "currentRate";
        }
        
        @Override
        public double get() {
            return this.value;
        }
        
        private void set(final double value) {
            this.value = value;
            this.fireValueChangedEvent();
        }
    }
    
    private class AnimationReadOnlyProperty<T> extends ReadOnlyObjectPropertyBase<T>
    {
        private final String name;
        private T value;
        
        private AnimationReadOnlyProperty(final String name, final T value) {
            this.name = name;
            this.value = value;
        }
        
        @Override
        public Object getBean() {
            return Animation.this;
        }
        
        @Override
        public String getName() {
            return this.name;
        }
        
        @Override
        public T get() {
            return this.value;
        }
        
        private void set(final T value) {
            this.value = value;
            this.fireValueChangedEvent();
        }
    }
    
    private class CurrentTimeProperty extends ReadOnlyObjectPropertyBase<Duration>
    {
        @Override
        public Object getBean() {
            return Animation.this;
        }
        
        @Override
        public String getName() {
            return "currentTime";
        }
        
        @Override
        public Duration get() {
            return Animation.this.getCurrentTime();
        }
        
        public void fireValueChangedEvent() {
            super.fireValueChangedEvent();
        }
    }
}
