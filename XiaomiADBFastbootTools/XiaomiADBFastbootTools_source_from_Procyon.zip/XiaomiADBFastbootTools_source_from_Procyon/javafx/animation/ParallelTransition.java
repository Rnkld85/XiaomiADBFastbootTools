// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import javafx.event.EventHandler;
import javafx.event.EventTarget;
import javafx.event.ActionEvent;
import com.sun.javafx.animation.TickCalculation;
import javafx.util.Duration;
import com.sun.scenario.animation.AbstractMasterTimer;
import java.util.Collection;
import java.util.List;
import com.sun.javafx.collections.VetoableListDecorator;
import java.util.Iterator;
import javafx.beans.Observable;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import java.util.HashSet;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.ObservableList;
import java.util.Set;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.InvalidationListener;

public final class ParallelTransition extends Transition
{
    private static final Animation[] EMPTY_ANIMATION_ARRAY;
    private static final double EPSILON = 1.0E-12;
    private Animation[] cachedChildren;
    private long[] durations;
    private long[] delays;
    private double[] rates;
    private long[] offsetTicks;
    private boolean[] forceChildSync;
    private long oldTicks;
    private long cycleTime;
    private boolean childrenChanged;
    private boolean toggledRate;
    private final InvalidationListener childrenListener;
    private final ChangeListener<Number> rateListener;
    private ObjectProperty<Node> node;
    private static final Node DEFAULT_NODE;
    private final Set<Animation> childrenSet;
    private final ObservableList<Animation> children;
    
    public final void setNode(final Node node) {
        if (this.node != null || node != null) {
            this.nodeProperty().set(node);
        }
    }
    
    public final Node getNode() {
        return (this.node == null) ? ParallelTransition.DEFAULT_NODE : this.node.get();
    }
    
    public final ObjectProperty<Node> nodeProperty() {
        if (this.node == null) {
            this.node = new SimpleObjectProperty<Node>(this, "node", ParallelTransition.DEFAULT_NODE);
        }
        return this.node;
    }
    
    private static boolean checkCycle(final Animation animation, final Animation animation2) {
        for (Animation parent = animation2; parent != animation; parent = parent.parent) {
            if (parent.parent == null) {
                return false;
            }
        }
        return true;
    }
    
    public final ObservableList<Animation> getChildren() {
        return this.children;
    }
    
    public ParallelTransition(final Node node, final Animation... all) {
        this.cachedChildren = ParallelTransition.EMPTY_ANIMATION_ARRAY;
        this.childrenChanged = true;
        this.childrenListener = (p0 -> {
            this.childrenChanged = true;
            if (this.getStatus() == Status.STOPPED) {
                this.setCycleDuration(this.computeCycleDuration());
            }
            return;
        });
        this.rateListener = new ChangeListener<Number>() {
            @Override
            public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
                if (n.doubleValue() * n2.doubleValue() < 0.0) {
                    for (int i = 0; i < ParallelTransition.this.cachedChildren.length; ++i) {
                        ParallelTransition.this.cachedChildren[i].clipEnvelope.setRate(ParallelTransition.this.rates[i] * Math.signum(ParallelTransition.this.getCurrentRate()));
                    }
                    ParallelTransition.this.toggledRate = true;
                }
            }
        };
        this.childrenSet = new HashSet<Animation>();
        this.children = new VetoableListDecorator<Animation>((ObservableList)new TrackableObservableList<Animation>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Animation> change) {
                while (change.next()) {
                    for (final Animation animation : change.getRemoved()) {
                        animation.parent = null;
                        animation.rateProperty().removeListener(ParallelTransition.this.childrenListener);
                        animation.totalDurationProperty().removeListener(ParallelTransition.this.childrenListener);
                        animation.delayProperty().removeListener(ParallelTransition.this.childrenListener);
                    }
                    for (final Animation animation2 : change.getAddedSubList()) {
                        animation2.parent = ParallelTransition.this;
                        animation2.rateProperty().addListener(ParallelTransition.this.childrenListener);
                        animation2.totalDurationProperty().addListener(ParallelTransition.this.childrenListener);
                        animation2.delayProperty().addListener(ParallelTransition.this.childrenListener);
                    }
                }
                ParallelTransition.this.childrenListener.invalidated(ParallelTransition.this.children);
            }
        }) {
            @Override
            protected void onProposedChange(final List<Animation> list, final int... array) {
                Object o = null;
                for (int i = 0; i < array.length; i += 2) {
                    for (int j = array[i]; j < array[i + 1]; ++j) {
                        ParallelTransition.this.childrenSet.remove(ParallelTransition.this.children.get(j));
                    }
                }
                for (final Animation animation : list) {
                    if (animation == null) {
                        o = new IllegalArgumentException("Child cannot be null");
                        break;
                    }
                    if (!ParallelTransition.this.childrenSet.add(animation)) {
                        o = new IllegalArgumentException("Attempting to add a duplicate to the list of children");
                        break;
                    }
                    if (checkCycle(animation, ParallelTransition.this)) {
                        o = new IllegalArgumentException("This change would create cycle");
                        break;
                    }
                }
                if (o != null) {
                    ParallelTransition.this.childrenSet.clear();
                    ParallelTransition.this.childrenSet.addAll(ParallelTransition.this.children);
                    throw o;
                }
            }
        };
        this.setInterpolator(Interpolator.LINEAR);
        this.setNode(node);
        this.getChildren().setAll(all);
    }
    
    public ParallelTransition(final Animation... array) {
        this((Node)null, array);
    }
    
    public ParallelTransition(final Node node) {
        this.cachedChildren = ParallelTransition.EMPTY_ANIMATION_ARRAY;
        this.childrenChanged = true;
        this.childrenListener = (p0 -> {
            this.childrenChanged = true;
            if (this.getStatus() == Status.STOPPED) {
                this.setCycleDuration(this.computeCycleDuration());
            }
            return;
        });
        this.rateListener = new ChangeListener<Number>() {
            @Override
            public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
                if (n.doubleValue() * n2.doubleValue() < 0.0) {
                    for (int i = 0; i < ParallelTransition.this.cachedChildren.length; ++i) {
                        ParallelTransition.this.cachedChildren[i].clipEnvelope.setRate(ParallelTransition.this.rates[i] * Math.signum(ParallelTransition.this.getCurrentRate()));
                    }
                    ParallelTransition.this.toggledRate = true;
                }
            }
        };
        this.childrenSet = new HashSet<Animation>();
        this.children = new VetoableListDecorator<Animation>((ObservableList)new TrackableObservableList<Animation>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Animation> change) {
                while (change.next()) {
                    for (final Animation animation : change.getRemoved()) {
                        animation.parent = null;
                        animation.rateProperty().removeListener(ParallelTransition.this.childrenListener);
                        animation.totalDurationProperty().removeListener(ParallelTransition.this.childrenListener);
                        animation.delayProperty().removeListener(ParallelTransition.this.childrenListener);
                    }
                    for (final Animation animation2 : change.getAddedSubList()) {
                        animation2.parent = ParallelTransition.this;
                        animation2.rateProperty().addListener(ParallelTransition.this.childrenListener);
                        animation2.totalDurationProperty().addListener(ParallelTransition.this.childrenListener);
                        animation2.delayProperty().addListener(ParallelTransition.this.childrenListener);
                    }
                }
                ParallelTransition.this.childrenListener.invalidated(ParallelTransition.this.children);
            }
        }) {
            @Override
            protected void onProposedChange(final List<Animation> list, final int... array) {
                Object o = null;
                for (int i = 0; i < array.length; i += 2) {
                    for (int j = array[i]; j < array[i + 1]; ++j) {
                        ParallelTransition.this.childrenSet.remove(ParallelTransition.this.children.get(j));
                    }
                }
                for (final Animation animation : list) {
                    if (animation == null) {
                        o = new IllegalArgumentException("Child cannot be null");
                        break;
                    }
                    if (!ParallelTransition.this.childrenSet.add(animation)) {
                        o = new IllegalArgumentException("Attempting to add a duplicate to the list of children");
                        break;
                    }
                    if (checkCycle(animation, ParallelTransition.this)) {
                        o = new IllegalArgumentException("This change would create cycle");
                        break;
                    }
                }
                if (o != null) {
                    ParallelTransition.this.childrenSet.clear();
                    ParallelTransition.this.childrenSet.addAll(ParallelTransition.this.children);
                    throw o;
                }
            }
        };
        this.setInterpolator(Interpolator.LINEAR);
        this.setNode(node);
    }
    
    public ParallelTransition() {
        this((Node)null);
    }
    
    ParallelTransition(final AbstractMasterTimer abstractMasterTimer) {
        super(abstractMasterTimer);
        this.cachedChildren = ParallelTransition.EMPTY_ANIMATION_ARRAY;
        this.childrenChanged = true;
        this.childrenListener = (p0 -> {
            this.childrenChanged = true;
            if (this.getStatus() == Status.STOPPED) {
                this.setCycleDuration(this.computeCycleDuration());
            }
            return;
        });
        this.rateListener = new ChangeListener<Number>() {
            @Override
            public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
                if (n.doubleValue() * n2.doubleValue() < 0.0) {
                    for (int i = 0; i < ParallelTransition.this.cachedChildren.length; ++i) {
                        ParallelTransition.this.cachedChildren[i].clipEnvelope.setRate(ParallelTransition.this.rates[i] * Math.signum(ParallelTransition.this.getCurrentRate()));
                    }
                    ParallelTransition.this.toggledRate = true;
                }
            }
        };
        this.childrenSet = new HashSet<Animation>();
        this.children = new VetoableListDecorator<Animation>((ObservableList)new TrackableObservableList<Animation>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Animation> change) {
                while (change.next()) {
                    for (final Animation animation : change.getRemoved()) {
                        animation.parent = null;
                        animation.rateProperty().removeListener(ParallelTransition.this.childrenListener);
                        animation.totalDurationProperty().removeListener(ParallelTransition.this.childrenListener);
                        animation.delayProperty().removeListener(ParallelTransition.this.childrenListener);
                    }
                    for (final Animation animation2 : change.getAddedSubList()) {
                        animation2.parent = ParallelTransition.this;
                        animation2.rateProperty().addListener(ParallelTransition.this.childrenListener);
                        animation2.totalDurationProperty().addListener(ParallelTransition.this.childrenListener);
                        animation2.delayProperty().addListener(ParallelTransition.this.childrenListener);
                    }
                }
                ParallelTransition.this.childrenListener.invalidated(ParallelTransition.this.children);
            }
        }) {
            @Override
            protected void onProposedChange(final List<Animation> list, final int... array) {
                Object o = null;
                for (int i = 0; i < array.length; i += 2) {
                    for (int j = array[i]; j < array[i + 1]; ++j) {
                        ParallelTransition.this.childrenSet.remove(ParallelTransition.this.children.get(j));
                    }
                }
                for (final Animation animation : list) {
                    if (animation == null) {
                        o = new IllegalArgumentException("Child cannot be null");
                        break;
                    }
                    if (!ParallelTransition.this.childrenSet.add(animation)) {
                        o = new IllegalArgumentException("Attempting to add a duplicate to the list of children");
                        break;
                    }
                    if (checkCycle(animation, ParallelTransition.this)) {
                        o = new IllegalArgumentException("This change would create cycle");
                        break;
                    }
                }
                if (o != null) {
                    ParallelTransition.this.childrenSet.clear();
                    ParallelTransition.this.childrenSet.addAll(ParallelTransition.this.children);
                    throw o;
                }
            }
        };
        this.setInterpolator(Interpolator.LINEAR);
    }
    
    @Override
    protected Node getParentTargetNode() {
        final Node node = this.getNode();
        return (node != null) ? node : ((this.parent != null && this.parent instanceof Transition) ? ((Transition)this.parent).getParentTargetNode() : null);
    }
    
    private Duration computeCycleDuration() {
        Duration zero = Duration.ZERO;
        for (final Animation animation : this.getChildren()) {
            final double abs = Math.abs(animation.getRate());
            final Duration add = ((abs < 1.0E-12) ? animation.getTotalDuration() : animation.getTotalDuration().divide(abs)).add(animation.getDelay());
            if (add.isIndefinite()) {
                return Duration.INDEFINITE;
            }
            if (!add.greaterThan(zero)) {
                continue;
            }
            zero = add;
        }
        return zero;
    }
    
    private double calculateFraction(final long n, final long n2) {
        final double n3 = n / (double)n2;
        return (n3 <= 0.0) ? 0.0 : ((n3 >= 1.0) ? 1.0 : n3);
    }
    
    private boolean startChild(final Animation animation, final int n) {
        final boolean b = this.forceChildSync[n];
        if (animation.startable(b)) {
            animation.clipEnvelope.setRate(this.rates[n] * Math.signum(this.getCurrentRate()));
            animation.doStart(b);
            this.forceChildSync[n] = false;
            return true;
        }
        return false;
    }
    
    @Override
    void sync(final boolean b) {
        super.sync(b);
        if ((b && this.childrenChanged) || this.durations == null) {
            this.cachedChildren = this.getChildren().toArray(ParallelTransition.EMPTY_ANIMATION_ARRAY);
            final int length = this.cachedChildren.length;
            this.durations = new long[length];
            this.delays = new long[length];
            this.rates = new double[length];
            this.offsetTicks = new long[length];
            this.forceChildSync = new boolean[length];
            this.cycleTime = 0L;
            int n = 0;
            for (final Animation animation : this.cachedChildren) {
                this.rates[n] = Math.abs(animation.getRate());
                if (this.rates[n] < 1.0E-12) {
                    this.rates[n] = 1.0;
                }
                this.durations[n] = TickCalculation.fromDuration(animation.getTotalDuration(), this.rates[n]);
                this.delays[n] = TickCalculation.fromDuration(animation.getDelay());
                this.cycleTime = Math.max(this.cycleTime, TickCalculation.add(this.durations[n], this.delays[n]));
                this.forceChildSync[n] = true;
                ++n;
            }
            this.childrenChanged = false;
        }
        else if (b) {
            for (int length3 = this.forceChildSync.length, j = 0; j < length3; ++j) {
                this.forceChildSync[j] = true;
            }
        }
    }
    
    @Override
    void doPause() {
        super.doPause();
        for (final Animation animation : this.cachedChildren) {
            if (animation.getStatus() == Status.RUNNING) {
                animation.doPause();
            }
        }
    }
    
    @Override
    void doResume() {
        super.doResume();
        int n = 0;
        for (final Animation animation : this.cachedChildren) {
            if (animation.getStatus() == Status.PAUSED) {
                animation.doResume();
                animation.clipEnvelope.setRate(this.rates[n] * Math.signum(this.getCurrentRate()));
            }
            ++n;
        }
    }
    
    @Override
    void doStart(final boolean b) {
        super.doStart(b);
        this.toggledRate = false;
        this.rateProperty().addListener(this.rateListener);
        final double currentRate = this.getCurrentRate();
        final long fromDuration = TickCalculation.fromDuration(this.getCurrentTime());
        if (currentRate < 0.0) {
            this.jumpToEnd();
            if (fromDuration < this.cycleTime) {
                this.doJumpTo(fromDuration, this.cycleTime, false);
            }
        }
        else {
            this.jumpToStart();
            if (fromDuration > 0L) {
                this.doJumpTo(fromDuration, this.cycleTime, false);
            }
        }
    }
    
    @Override
    void doStop() {
        super.doStop();
        for (final Animation animation : this.cachedChildren) {
            if (animation.getStatus() != Status.STOPPED) {
                animation.doStop();
            }
        }
        if (this.childrenChanged) {
            this.setCycleDuration(this.computeCycleDuration());
        }
        this.rateProperty().removeListener(this.rateListener);
    }
    
    @Override
    void doPlayTo(final long currentTicks, final long b) {
        this.setCurrentTicks(currentTicks);
        final long max = Math.max(0L, Math.min(this.getCachedInterpolator().interpolate(0L, b, this.calculateFraction(currentTicks, b)), b));
        if (this.toggledRate) {
            for (int i = 0; i < this.cachedChildren.length; ++i) {
                if (this.cachedChildren[i].getStatus() == Status.RUNNING) {
                    final long[] offsetTicks = this.offsetTicks;
                    final int n = i;
                    offsetTicks[n] -= (long)(Math.signum(this.getCurrentRate()) * (this.durations[i] - 2L * (this.oldTicks - this.delays[i])));
                }
            }
            this.toggledRate = false;
        }
        if (this.getCurrentRate() > 0.0) {
            int n2 = 0;
            for (final Animation animation : this.cachedChildren) {
                Label_0417: {
                    if (max >= this.delays[n2] && (this.oldTicks <= this.delays[n2] || (max < TickCalculation.add(this.delays[n2], this.durations[n2]) && animation.getStatus() == Status.STOPPED))) {
                        final boolean b2 = this.oldTicks <= this.delays[n2];
                        if (this.startChild(animation, n2)) {
                            animation.clipEnvelope.jumpTo(0L);
                        }
                        else {
                            if (b2) {
                                final EventHandler<ActionEvent> onFinished = animation.getOnFinished();
                                if (onFinished != null) {
                                    onFinished.handle(new ActionEvent(this, null));
                                }
                            }
                            break Label_0417;
                        }
                    }
                    if (max >= TickCalculation.add(this.durations[n2], this.delays[n2])) {
                        if (animation.getStatus() == Status.RUNNING) {
                            animation.doTimePulse(TickCalculation.sub(this.durations[n2], this.offsetTicks[n2]));
                            this.offsetTicks[n2] = 0L;
                        }
                    }
                    else if (max > this.delays[n2]) {
                        animation.doTimePulse(TickCalculation.sub(max - this.delays[n2], this.offsetTicks[n2]));
                    }
                    ++n2;
                }
            }
        }
        else {
            int n3 = 0;
            for (final Animation animation2 : this.cachedChildren) {
                Label_0733: {
                    if (max < TickCalculation.add(this.durations[n3], this.delays[n3])) {
                        if (this.oldTicks >= TickCalculation.add(this.durations[n3], this.delays[n3]) || (max >= this.delays[n3] && animation2.getStatus() == Status.STOPPED)) {
                            final boolean b3 = this.oldTicks >= TickCalculation.add(this.durations[n3], this.delays[n3]);
                            if (this.startChild(animation2, n3)) {
                                animation2.clipEnvelope.jumpTo(Math.round(this.durations[n3] * this.rates[n3]));
                            }
                            else {
                                if (b3) {
                                    final EventHandler<ActionEvent> onFinished2 = animation2.getOnFinished();
                                    if (onFinished2 != null) {
                                        onFinished2.handle(new ActionEvent(this, null));
                                    }
                                }
                                break Label_0733;
                            }
                        }
                        if (max <= this.delays[n3]) {
                            if (animation2.getStatus() == Status.RUNNING) {
                                animation2.doTimePulse(TickCalculation.sub(this.durations[n3], this.offsetTicks[n3]));
                                this.offsetTicks[n3] = 0L;
                            }
                        }
                        else {
                            animation2.doTimePulse(TickCalculation.sub(TickCalculation.add(this.durations[n3], this.delays[n3]) - max, this.offsetTicks[n3]));
                        }
                    }
                    ++n3;
                }
            }
        }
        this.oldTicks = max;
    }
    
    @Override
    void doJumpTo(final long currentTicks, final long b, final boolean b2) {
        this.setCurrentTicks(currentTicks);
        if (this.getStatus() == Status.STOPPED && !b2) {
            return;
        }
        this.sync(false);
        final long max = Math.max(0L, Math.min(this.getCachedInterpolator().interpolate(0L, b, this.calculateFraction(currentTicks, b)), b));
        int n = 0;
        for (final Animation animation : this.cachedChildren) {
            final Status status = animation.getStatus();
            if (max <= this.delays[n]) {
                this.offsetTicks[n] = 0L;
                if (status != Status.STOPPED) {
                    animation.clipEnvelope.jumpTo(0L);
                    animation.doStop();
                }
                else if (TickCalculation.fromDuration(animation.getCurrentTime()) != 0L) {
                    animation.doJumpTo(0L, this.durations[n], true);
                }
            }
            else if (max >= TickCalculation.add(this.durations[n], this.delays[n])) {
                this.offsetTicks[n] = 0L;
                if (status != Status.STOPPED) {
                    animation.clipEnvelope.jumpTo(Math.round(this.durations[n] * this.rates[n]));
                    animation.doStop();
                }
                else if (TickCalculation.fromDuration(animation.getCurrentTime()) != this.durations[n]) {
                    animation.doJumpTo(this.durations[n], this.durations[n], true);
                }
            }
            else {
                if (status == Status.STOPPED) {
                    this.startChild(animation, n);
                    if (this.getStatus() == Status.PAUSED) {
                        animation.doPause();
                    }
                    this.offsetTicks[n] = ((this.getCurrentRate() > 0.0) ? (max - this.delays[n]) : (TickCalculation.add(this.durations[n], this.delays[n]) - max));
                }
                else if (status == Status.PAUSED) {
                    final long[] offsetTicks = this.offsetTicks;
                    final int n2 = n;
                    offsetTicks[n2] += (long)((max - this.oldTicks) * Math.signum(this.clipEnvelope.getCurrentRate()));
                }
                else {
                    final long[] offsetTicks2 = this.offsetTicks;
                    final int n3 = n;
                    offsetTicks2[n3] += ((this.getCurrentRate() > 0.0) ? (max - this.oldTicks) : (this.oldTicks - max));
                }
                animation.clipEnvelope.jumpTo(Math.round(TickCalculation.sub(max, this.delays[n]) * this.rates[n]));
            }
            ++n;
        }
        this.oldTicks = max;
    }
    
    @Override
    protected void interpolate(final double n) {
    }
    
    private void jumpToEnd() {
        for (int i = 0; i < this.cachedChildren.length; ++i) {
            if (this.forceChildSync[i]) {
                this.cachedChildren[i].sync(true);
            }
            this.cachedChildren[i].doJumpTo(this.durations[i], this.durations[i], true);
        }
    }
    
    private void jumpToStart() {
        for (int i = this.cachedChildren.length - 1; i >= 0; --i) {
            if (this.forceChildSync[i]) {
                this.cachedChildren[i].sync(true);
            }
            this.cachedChildren[i].doJumpTo(0L, this.durations[i], true);
        }
    }
    
    static {
        EMPTY_ANIMATION_ARRAY = new Animation[0];
        DEFAULT_NODE = null;
    }
}
