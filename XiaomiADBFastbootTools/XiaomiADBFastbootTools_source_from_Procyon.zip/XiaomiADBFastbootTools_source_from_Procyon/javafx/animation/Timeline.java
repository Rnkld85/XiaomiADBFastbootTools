// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import com.sun.scenario.animation.AbstractMasterTimer;
import java.util.Iterator;
import java.util.Collection;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import javafx.collections.ObservableList;
import com.sun.scenario.animation.shared.TimelineClipCore;

public final class Timeline extends Animation
{
    final TimelineClipCore clipCore;
    private final ObservableList<KeyFrame> keyFrames;
    
    public final ObservableList<KeyFrame> getKeyFrames() {
        return this.keyFrames;
    }
    
    public Timeline(final double n, final KeyFrame... all) {
        super(n);
        this.keyFrames = new TrackableObservableList<KeyFrame>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<KeyFrame> change) {
                while (change.next()) {
                    if (!change.wasPermutated()) {
                        final Iterator<KeyFrame> iterator = change.getRemoved().iterator();
                        while (iterator.hasNext()) {
                            final String name = iterator.next().getName();
                            if (name != null) {
                                Timeline.this.getCuePoints().remove(name);
                            }
                        }
                        for (final KeyFrame keyFrame : change.getAddedSubList()) {
                            final String name2 = keyFrame.getName();
                            if (name2 != null) {
                                Timeline.this.getCuePoints().put(name2, keyFrame.getTime());
                            }
                        }
                        Timeline.this.setCycleDuration(Timeline.this.clipCore.setKeyFrames(Timeline.this.getKeyFrames()));
                    }
                }
            }
        };
        this.clipCore = new TimelineClipCore(this);
        this.getKeyFrames().setAll(all);
    }
    
    public Timeline(final KeyFrame... all) {
        this.keyFrames = new TrackableObservableList<KeyFrame>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<KeyFrame> change) {
                while (change.next()) {
                    if (!change.wasPermutated()) {
                        final Iterator<KeyFrame> iterator = change.getRemoved().iterator();
                        while (iterator.hasNext()) {
                            final String name = iterator.next().getName();
                            if (name != null) {
                                Timeline.this.getCuePoints().remove(name);
                            }
                        }
                        for (final KeyFrame keyFrame : change.getAddedSubList()) {
                            final String name2 = keyFrame.getName();
                            if (name2 != null) {
                                Timeline.this.getCuePoints().put(name2, keyFrame.getTime());
                            }
                        }
                        Timeline.this.setCycleDuration(Timeline.this.clipCore.setKeyFrames(Timeline.this.getKeyFrames()));
                    }
                }
            }
        };
        this.clipCore = new TimelineClipCore(this);
        this.getKeyFrames().setAll(all);
    }
    
    public Timeline(final double n) {
        super(n);
        this.keyFrames = new TrackableObservableList<KeyFrame>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<KeyFrame> change) {
                while (change.next()) {
                    if (!change.wasPermutated()) {
                        final Iterator<KeyFrame> iterator = change.getRemoved().iterator();
                        while (iterator.hasNext()) {
                            final String name = iterator.next().getName();
                            if (name != null) {
                                Timeline.this.getCuePoints().remove(name);
                            }
                        }
                        for (final KeyFrame keyFrame : change.getAddedSubList()) {
                            final String name2 = keyFrame.getName();
                            if (name2 != null) {
                                Timeline.this.getCuePoints().put(name2, keyFrame.getTime());
                            }
                        }
                        Timeline.this.setCycleDuration(Timeline.this.clipCore.setKeyFrames(Timeline.this.getKeyFrames()));
                    }
                }
            }
        };
        this.clipCore = new TimelineClipCore(this);
    }
    
    public Timeline() {
        this.keyFrames = new TrackableObservableList<KeyFrame>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<KeyFrame> change) {
                while (change.next()) {
                    if (!change.wasPermutated()) {
                        final Iterator<KeyFrame> iterator = change.getRemoved().iterator();
                        while (iterator.hasNext()) {
                            final String name = iterator.next().getName();
                            if (name != null) {
                                Timeline.this.getCuePoints().remove(name);
                            }
                        }
                        for (final KeyFrame keyFrame : change.getAddedSubList()) {
                            final String name2 = keyFrame.getName();
                            if (name2 != null) {
                                Timeline.this.getCuePoints().put(name2, keyFrame.getTime());
                            }
                        }
                        Timeline.this.setCycleDuration(Timeline.this.clipCore.setKeyFrames(Timeline.this.getKeyFrames()));
                    }
                }
            }
        };
        this.clipCore = new TimelineClipCore(this);
    }
    
    Timeline(final AbstractMasterTimer abstractMasterTimer) {
        super(abstractMasterTimer);
        this.keyFrames = new TrackableObservableList<KeyFrame>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<KeyFrame> change) {
                while (change.next()) {
                    if (!change.wasPermutated()) {
                        final Iterator<KeyFrame> iterator = change.getRemoved().iterator();
                        while (iterator.hasNext()) {
                            final String name = iterator.next().getName();
                            if (name != null) {
                                Timeline.this.getCuePoints().remove(name);
                            }
                        }
                        for (final KeyFrame keyFrame : change.getAddedSubList()) {
                            final String name2 = keyFrame.getName();
                            if (name2 != null) {
                                Timeline.this.getCuePoints().put(name2, keyFrame.getTime());
                            }
                        }
                        Timeline.this.setCycleDuration(Timeline.this.clipCore.setKeyFrames(Timeline.this.getKeyFrames()));
                    }
                }
            }
        };
        this.clipCore = new TimelineClipCore(this);
    }
    
    @Override
    void doPlayTo(final long n, final long n2) {
        this.clipCore.playTo(n);
    }
    
    @Override
    void doJumpTo(final long currentTicks, final long n, final boolean b) {
        this.sync(false);
        this.setCurrentTicks(currentTicks);
        this.clipCore.jumpTo(currentTicks, b);
    }
    
    @Override
    void setCurrentRate(final double currentRate) {
        super.setCurrentRate(currentRate);
        this.clipCore.notifyCurrentRateChanged();
    }
    
    @Override
    void doStart(final boolean b) {
        super.doStart(b);
        this.clipCore.start(b);
    }
    
    @Override
    public void stop() {
        if (this.parent != null) {
            throw new IllegalStateException("Cannot stop when embedded in another animation");
        }
        if (this.getStatus() == Status.RUNNING) {
            this.clipCore.abort();
        }
        super.stop();
    }
}
