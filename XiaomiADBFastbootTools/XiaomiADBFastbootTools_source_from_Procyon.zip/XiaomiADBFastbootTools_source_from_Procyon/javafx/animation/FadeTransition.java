// 
// Decompiled by Procyon v0.5.36
// 

package javafx.animation;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.DoubleProperty;
import javafx.util.Duration;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;

public final class FadeTransition extends Transition
{
    private static final double EPSILON = 1.0E-12;
    private double start;
    private double delta;
    private ObjectProperty<Node> node;
    private static final Node DEFAULT_NODE;
    private Node cachedNode;
    private ObjectProperty<Duration> duration;
    private static final Duration DEFAULT_DURATION;
    private DoubleProperty fromValue;
    private static final double DEFAULT_FROM_VALUE = Double.NaN;
    private DoubleProperty toValue;
    private static final double DEFAULT_TO_VALUE = Double.NaN;
    private DoubleProperty byValue;
    private static final double DEFAULT_BY_VALUE = 0.0;
    
    public final void setNode(final Node node) {
        if (this.node != null || node != null) {
            this.nodeProperty().set(node);
        }
    }
    
    public final Node getNode() {
        return (this.node == null) ? FadeTransition.DEFAULT_NODE : this.node.get();
    }
    
    public final ObjectProperty<Node> nodeProperty() {
        if (this.node == null) {
            this.node = new SimpleObjectProperty<Node>(this, "node", FadeTransition.DEFAULT_NODE);
        }
        return this.node;
    }
    
    public final void setDuration(final Duration duration) {
        if (this.duration != null || !FadeTransition.DEFAULT_DURATION.equals(duration)) {
            this.durationProperty().set(duration);
        }
    }
    
    public final Duration getDuration() {
        return (this.duration == null) ? FadeTransition.DEFAULT_DURATION : this.duration.get();
    }
    
    public final ObjectProperty<Duration> durationProperty() {
        if (this.duration == null) {
            this.duration = new ObjectPropertyBase<Duration>(FadeTransition.DEFAULT_DURATION) {
                public void invalidated() {
                    try {
                        FadeTransition.this.setCycleDuration(FadeTransition.this.getDuration());
                    }
                    catch (IllegalArgumentException ex) {
                        if (this.isBound()) {
                            this.unbind();
                        }
                        this.set(FadeTransition.this.getCycleDuration());
                        throw ex;
                    }
                }
                
                @Override
                public Object getBean() {
                    return FadeTransition.this;
                }
                
                @Override
                public String getName() {
                    return "duration";
                }
            };
        }
        return this.duration;
    }
    
    public final void setFromValue(final double v) {
        if (this.fromValue != null || !Double.isNaN(v)) {
            this.fromValueProperty().set(v);
        }
    }
    
    public final double getFromValue() {
        return (this.fromValue == null) ? Double.NaN : this.fromValue.get();
    }
    
    public final DoubleProperty fromValueProperty() {
        if (this.fromValue == null) {
            this.fromValue = new SimpleDoubleProperty(this, "fromValue", Double.NaN);
        }
        return this.fromValue;
    }
    
    public final void setToValue(final double v) {
        if (this.toValue != null || !Double.isNaN(v)) {
            this.toValueProperty().set(v);
        }
    }
    
    public final double getToValue() {
        return (this.toValue == null) ? Double.NaN : this.toValue.get();
    }
    
    public final DoubleProperty toValueProperty() {
        if (this.toValue == null) {
            this.toValue = new SimpleDoubleProperty(this, "toValue", Double.NaN);
        }
        return this.toValue;
    }
    
    public final void setByValue(final double n) {
        if (this.byValue != null || Math.abs(n - 0.0) > 1.0E-12) {
            this.byValueProperty().set(n);
        }
    }
    
    public final double getByValue() {
        return (this.byValue == null) ? 0.0 : this.byValue.get();
    }
    
    public final DoubleProperty byValueProperty() {
        if (this.byValue == null) {
            this.byValue = new SimpleDoubleProperty(this, "byValue", 0.0);
        }
        return this.byValue;
    }
    
    public FadeTransition(final Duration duration, final Node node) {
        this.setDuration(duration);
        this.setNode(node);
        this.setCycleDuration(duration);
    }
    
    public FadeTransition(final Duration duration) {
        this(duration, null);
    }
    
    public FadeTransition() {
        this(FadeTransition.DEFAULT_DURATION, null);
    }
    
    @Override
    protected void interpolate(final double n) {
        this.cachedNode.setOpacity(Math.max(0.0, Math.min(this.start + n * this.delta, 1.0)));
    }
    
    private Node getTargetNode() {
        final Node node = this.getNode();
        return (node != null) ? node : this.getParentTargetNode();
    }
    
    @Override
    boolean startable(final boolean b) {
        return super.startable(b) && (this.getTargetNode() != null || (!b && this.cachedNode != null));
    }
    
    @Override
    void sync(final boolean b) {
        super.sync(b);
        if (b || this.cachedNode == null) {
            this.cachedNode = this.getTargetNode();
            final double fromValue = this.getFromValue();
            final double toValue = this.getToValue();
            this.start = (Double.isNaN(fromValue) ? this.cachedNode.getOpacity() : Math.max(0.0, Math.min(fromValue, 1.0)));
            this.delta = (Double.isNaN(toValue) ? this.getByValue() : (toValue - this.start));
            if (this.start + this.delta > 1.0) {
                this.delta = 1.0 - this.start;
            }
            else if (this.start + this.delta < 0.0) {
                this.delta = -this.start;
            }
        }
    }
    
    static {
        DEFAULT_NODE = null;
        DEFAULT_DURATION = Duration.millis(400.0);
    }
}
