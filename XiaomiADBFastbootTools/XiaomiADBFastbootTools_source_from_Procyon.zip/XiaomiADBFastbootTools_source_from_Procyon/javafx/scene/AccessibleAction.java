// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

public enum AccessibleAction
{
    BLOCK_DECREMENT, 
    BLOCK_INCREMENT, 
    COLLAPSE, 
    DECREMENT, 
    EXPAND, 
    FIRE, 
    INCREMENT, 
    REQUEST_FOCUS, 
    SHOW_ITEM, 
    SHOW_TEXT_RANGE, 
    SET_SELECTED_ITEMS, 
    SET_TEXT_SELECTION, 
    SET_TEXT, 
    SET_VALUE, 
    SHOW_MENU;
}
