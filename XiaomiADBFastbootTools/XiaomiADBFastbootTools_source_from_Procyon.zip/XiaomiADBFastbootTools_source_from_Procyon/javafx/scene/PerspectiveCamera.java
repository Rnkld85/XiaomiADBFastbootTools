// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import com.sun.javafx.geom.Vec3d;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.transform.GeneralTransform3D;
import com.sun.javafx.sg.prism.NGPerspectiveCamera;
import com.sun.javafx.sg.prism.NGNode;
import com.sun.javafx.geom.PickRay;
import com.sun.javafx.logging.PlatformLogger;
import javafx.application.Platform;
import javafx.application.ConditionalFeature;
import com.sun.javafx.scene.PerspectiveCameraHelper;
import javafx.beans.property.SimpleBooleanProperty;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.geom.transform.Affine3D;

public class PerspectiveCamera extends Camera
{
    private boolean fixedEyeAtCameraZero;
    private static final Affine3D LOOK_AT_TX;
    private static final Affine3D LOOK_AT_TX_FIXED_EYE;
    private DoubleProperty fieldOfView;
    private BooleanProperty verticalFieldOfView;
    
    public final void setFieldOfView(final double n) {
        this.fieldOfViewProperty().set(n);
    }
    
    public final double getFieldOfView() {
        return (this.fieldOfView == null) ? 30.0 : this.fieldOfView.get();
    }
    
    public final DoubleProperty fieldOfViewProperty() {
        if (this.fieldOfView == null) {
            this.fieldOfView = new SimpleDoubleProperty(this, "fieldOfView", 30.0) {
                @Override
                protected void invalidated() {
                    NodeHelper.markDirty(PerspectiveCamera.this, DirtyBits.NODE_CAMERA);
                }
            };
        }
        return this.fieldOfView;
    }
    
    public final void setVerticalFieldOfView(final boolean b) {
        this.verticalFieldOfViewProperty().set(b);
    }
    
    public final boolean isVerticalFieldOfView() {
        return this.verticalFieldOfView == null || this.verticalFieldOfView.get();
    }
    
    public final BooleanProperty verticalFieldOfViewProperty() {
        if (this.verticalFieldOfView == null) {
            this.verticalFieldOfView = new SimpleBooleanProperty(this, "verticalFieldOfView", true) {
                @Override
                protected void invalidated() {
                    NodeHelper.markDirty(PerspectiveCamera.this, DirtyBits.NODE_CAMERA);
                }
            };
        }
        return this.verticalFieldOfView;
    }
    
    public PerspectiveCamera() {
        this(false);
    }
    
    public PerspectiveCamera(final boolean fixedEyeAtCameraZero) {
        this.fixedEyeAtCameraZero = false;
        PerspectiveCameraHelper.initHelper(this);
        if (!Platform.isSupported(ConditionalFeature.SCENE3D)) {
            PlatformLogger.getLogger(PerspectiveCamera.class.getName()).warning("System can't support ConditionalFeature.SCENE3D");
        }
        this.fixedEyeAtCameraZero = fixedEyeAtCameraZero;
    }
    
    public final boolean isFixedEyeAtCameraZero() {
        return this.fixedEyeAtCameraZero;
    }
    
    @Override
    final PickRay computePickRay(final double n, final double n2, final PickRay pickRay) {
        return PickRay.computePerspectivePickRay(n, n2, this.fixedEyeAtCameraZero, this.getViewWidth(), this.getViewHeight(), Math.toRadians(this.getFieldOfView()), this.isVerticalFieldOfView(), this.getCameraTransform(), this.getNearClip(), this.getFarClip(), pickRay);
    }
    
    @Override
    Camera copy() {
        final PerspectiveCamera perspectiveCamera = new PerspectiveCamera(this.fixedEyeAtCameraZero);
        perspectiveCamera.setNearClip(this.getNearClip());
        perspectiveCamera.setFarClip(this.getFarClip());
        perspectiveCamera.setFieldOfView(this.getFieldOfView());
        return perspectiveCamera;
    }
    
    private NGNode doCreatePeer() {
        final NGPerspectiveCamera ngPerspectiveCamera = new NGPerspectiveCamera(this.fixedEyeAtCameraZero);
        ngPerspectiveCamera.setNearClip((float)this.getNearClip());
        ngPerspectiveCamera.setFarClip((float)this.getFarClip());
        ngPerspectiveCamera.setFieldOfView((float)this.getFieldOfView());
        return ngPerspectiveCamera;
    }
    
    private void doUpdatePeer() {
        final NGPerspectiveCamera ngPerspectiveCamera = this.getPeer();
        if (this.isDirty(DirtyBits.NODE_CAMERA)) {
            ngPerspectiveCamera.setVerticalFieldOfView(this.isVerticalFieldOfView());
            ngPerspectiveCamera.setFieldOfView((float)this.getFieldOfView());
        }
    }
    
    @Override
    void computeProjectionTransform(final GeneralTransform3D generalTransform3D) {
        generalTransform3D.perspective(this.isVerticalFieldOfView(), Math.toRadians(this.getFieldOfView()), this.getViewWidth() / this.getViewHeight(), this.getNearClip(), this.getFarClip());
    }
    
    @Override
    void computeViewTransform(final Affine3D affine3D) {
        if (this.isFixedEyeAtCameraZero()) {
            affine3D.setTransform(PerspectiveCamera.LOOK_AT_TX_FIXED_EYE);
        }
        else {
            final double viewWidth = this.getViewWidth();
            final double viewHeight = this.getViewHeight();
            final boolean verticalFieldOfView = this.isVerticalFieldOfView();
            final double n = viewWidth / viewHeight;
            final double tan = Math.tan(Math.toRadians(this.getFieldOfView()) / 2.0);
            final double n2 = -tan * (verticalFieldOfView ? n : 1.0);
            final double n3 = tan * (verticalFieldOfView ? 1.0 : (1.0 / n));
            final double n4 = 2.0 * tan / (verticalFieldOfView ? viewHeight : viewWidth);
            affine3D.setToTranslation(n2, n3, 0.0);
            affine3D.concatenate(PerspectiveCamera.LOOK_AT_TX);
            affine3D.scale(n4, n4, n4);
        }
    }
    
    @Override
    Vec3d computePosition(Vec3d vec3d) {
        if (vec3d == null) {
            vec3d = new Vec3d();
        }
        if (this.fixedEyeAtCameraZero) {
            vec3d.set(0.0, 0.0, 0.0);
        }
        else {
            final double n = this.getViewWidth() / 2.0;
            final double n2 = this.getViewHeight() / 2.0;
            vec3d.set(n, n2, -((this.isVerticalFieldOfView() ? n2 : n) / Math.tan(Math.toRadians(this.getFieldOfView() / 2.0))));
        }
        return vec3d;
    }
    
    static {
        LOOK_AT_TX = new Affine3D();
        LOOK_AT_TX_FIXED_EYE = new Affine3D();
        PerspectiveCameraHelper.setPerspectiveCameraAccessor(new PerspectiveCameraHelper.PerspectiveCameraAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((PerspectiveCamera)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((PerspectiveCamera)node).doUpdatePeer();
            }
        });
        PerspectiveCamera.LOOK_AT_TX.setToTranslation(0.0, 0.0, -1.0);
        PerspectiveCamera.LOOK_AT_TX.rotate(3.141592653589793, 1.0, 0.0, 0.0);
        PerspectiveCamera.LOOK_AT_TX_FIXED_EYE.rotate(3.141592653589793, 1.0, 0.0, 0.0);
    }
}
