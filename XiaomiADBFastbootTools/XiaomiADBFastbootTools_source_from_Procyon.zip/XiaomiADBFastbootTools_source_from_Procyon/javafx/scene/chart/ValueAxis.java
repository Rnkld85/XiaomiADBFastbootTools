// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.BooleanConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.Styleable;
import java.util.Iterator;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.PathElement;
import javafx.geometry.Side;
import javafx.css.StyleableIntegerProperty;
import javafx.css.StyleableDoubleProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.DoublePropertyBase;
import javafx.css.CssMetaData;
import javafx.css.StyleableBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyDoubleWrapper;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import java.util.List;
import javafx.scene.shape.Path;

public abstract class ValueAxis<T extends Number> extends Axis<T>
{
    private final Path minorTickPath;
    private double offset;
    double dataMinValue;
    double dataMaxValue;
    private List<T> minorTickMarkValues;
    private boolean minorTickMarksDirty;
    protected final DoubleProperty currentLowerBound;
    private BooleanProperty minorTickVisible;
    private ReadOnlyDoubleWrapper scale;
    private DoubleProperty upperBound;
    private DoubleProperty lowerBound;
    private final ObjectProperty<StringConverter<T>> tickLabelFormatter;
    private DoubleProperty minorTickLength;
    private IntegerProperty minorTickCount;
    
    public final boolean isMinorTickVisible() {
        return this.minorTickVisible.get();
    }
    
    public final void setMinorTickVisible(final boolean b) {
        this.minorTickVisible.set(b);
    }
    
    public final BooleanProperty minorTickVisibleProperty() {
        return this.minorTickVisible;
    }
    
    public final double getScale() {
        return this.scale.get();
    }
    
    protected final void setScale(final double n) {
        this.scale.set(n);
    }
    
    public final ReadOnlyDoubleProperty scaleProperty() {
        return this.scale.getReadOnlyProperty();
    }
    
    ReadOnlyDoubleWrapper scalePropertyImpl() {
        return this.scale;
    }
    
    public final double getUpperBound() {
        return this.upperBound.get();
    }
    
    public final void setUpperBound(final double n) {
        this.upperBound.set(n);
    }
    
    public final DoubleProperty upperBoundProperty() {
        return this.upperBound;
    }
    
    public final double getLowerBound() {
        return this.lowerBound.get();
    }
    
    public final void setLowerBound(final double n) {
        this.lowerBound.set(n);
    }
    
    public final DoubleProperty lowerBoundProperty() {
        return this.lowerBound;
    }
    
    public final StringConverter<T> getTickLabelFormatter() {
        return this.tickLabelFormatter.getValue();
    }
    
    public final void setTickLabelFormatter(final StringConverter<T> value) {
        this.tickLabelFormatter.setValue(value);
    }
    
    public final ObjectProperty<StringConverter<T>> tickLabelFormatterProperty() {
        return this.tickLabelFormatter;
    }
    
    public final double getMinorTickLength() {
        return this.minorTickLength.get();
    }
    
    public final void setMinorTickLength(final double n) {
        this.minorTickLength.set(n);
    }
    
    public final DoubleProperty minorTickLengthProperty() {
        return this.minorTickLength;
    }
    
    public final int getMinorTickCount() {
        return this.minorTickCount.get();
    }
    
    public final void setMinorTickCount(final int n) {
        this.minorTickCount.set(n);
    }
    
    public final IntegerProperty minorTickCountProperty() {
        return this.minorTickCount;
    }
    
    public ValueAxis() {
        this.minorTickPath = new Path();
        this.minorTickMarkValues = null;
        this.minorTickMarksDirty = true;
        this.currentLowerBound = new SimpleDoubleProperty(this, "currentLowerBound");
        this.minorTickVisible = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                ValueAxis.this.minorTickPath.setVisible(this.get());
                ValueAxis.this.requestAxisLayout();
            }
            
            @Override
            public Object getBean() {
                return ValueAxis.this;
            }
            
            @Override
            public String getName() {
                return "minorTickVisible";
            }
            
            @Override
            public CssMetaData<ValueAxis<? extends Number>, Boolean> getCssMetaData() {
                return StyleableProperties.MINOR_TICK_VISIBLE;
            }
        };
        this.scale = new ReadOnlyDoubleWrapper((Object)this, "scale", 0.0) {
            @Override
            protected void invalidated() {
                ValueAxis.this.requestAxisLayout();
                ValueAxis.this.measureInvalid = true;
            }
        };
        this.upperBound = new DoublePropertyBase(100.0) {
            @Override
            protected void invalidated() {
                if (!ValueAxis.this.isAutoRanging()) {
                    ValueAxis.this.invalidateRange();
                    ValueAxis.this.requestAxisLayout();
                }
            }
            
            @Override
            public Object getBean() {
                return ValueAxis.this;
            }
            
            @Override
            public String getName() {
                return "upperBound";
            }
        };
        this.lowerBound = new DoublePropertyBase(0.0) {
            @Override
            protected void invalidated() {
                if (!ValueAxis.this.isAutoRanging()) {
                    ValueAxis.this.invalidateRange();
                    ValueAxis.this.requestAxisLayout();
                }
            }
            
            @Override
            public Object getBean() {
                return ValueAxis.this;
            }
            
            @Override
            public String getName() {
                return "lowerBound";
            }
        };
        this.tickLabelFormatter = new ObjectPropertyBase<StringConverter<T>>((StringConverter)null) {
            @Override
            protected void invalidated() {
                ValueAxis.this.invalidateRange();
                ValueAxis.this.requestAxisLayout();
            }
            
            @Override
            public Object getBean() {
                return ValueAxis.this;
            }
            
            @Override
            public String getName() {
                return "tickLabelFormatter";
            }
        };
        this.minorTickLength = new StyleableDoubleProperty(5.0) {
            @Override
            protected void invalidated() {
                ValueAxis.this.requestAxisLayout();
            }
            
            @Override
            public Object getBean() {
                return ValueAxis.this;
            }
            
            @Override
            public String getName() {
                return "minorTickLength";
            }
            
            @Override
            public CssMetaData<ValueAxis<? extends Number>, Number> getCssMetaData() {
                return StyleableProperties.MINOR_TICK_LENGTH;
            }
        };
        this.minorTickCount = new StyleableIntegerProperty(5) {
            @Override
            protected void invalidated() {
                ValueAxis.this.invalidateRange();
                ValueAxis.this.requestAxisLayout();
            }
            
            @Override
            public Object getBean() {
                return ValueAxis.this;
            }
            
            @Override
            public String getName() {
                return "minorTickCount";
            }
            
            @Override
            public CssMetaData<ValueAxis<? extends Number>, Number> getCssMetaData() {
                return StyleableProperties.MINOR_TICK_COUNT;
            }
        };
        this.minorTickPath.getStyleClass().add("axis-minor-tick-mark");
        this.getChildren().add(this.minorTickPath);
    }
    
    public ValueAxis(final double lowerBound, final double upperBound) {
        this();
        this.setAutoRanging(false);
        this.setLowerBound(lowerBound);
        this.setUpperBound(upperBound);
    }
    
    @Override
    protected final Object autoRange(final double n) {
        if (this.isAutoRanging()) {
            return this.autoRange(this.dataMinValue, this.dataMaxValue, n, this.getTickLabelFont().getSize() * 2.0);
        }
        return this.getRange();
    }
    
    protected final double calculateNewScale(final double offset, final double n, final double n2) {
        double n3;
        if (this.getEffectiveSide().isVertical()) {
            this.offset = offset;
            n3 = ((n2 - n == 0.0) ? (-offset) : (-(offset / (n2 - n))));
        }
        else {
            this.offset = 0.0;
            n3 = ((n2 - n == 0.0) ? offset : (offset / (n2 - n)));
        }
        return n3;
    }
    
    protected Object autoRange(final double n, final double n2, final double n3, final double n4) {
        return null;
    }
    
    protected abstract List<T> calculateMinorTickMarks();
    
    @Override
    protected void tickMarksUpdated() {
        super.tickMarksUpdated();
        this.minorTickMarkValues = this.calculateMinorTickMarks();
        this.minorTickMarksDirty = true;
    }
    
    @Override
    protected void layoutChildren() {
        final Side effectiveSide = this.getEffectiveSide();
        final double n = effectiveSide.isVertical() ? this.getHeight() : this.getWidth();
        if (!this.isAutoRanging()) {
            this.setScale(this.calculateNewScale(n, this.getLowerBound(), this.getUpperBound()));
            this.currentLowerBound.set(this.getLowerBound());
        }
        super.layoutChildren();
        if (this.minorTickMarksDirty) {
            this.minorTickMarksDirty = false;
            this.updateMinorTickPath(effectiveSide, n);
        }
    }
    
    private void updateMinorTickPath(final Side other, final double n) {
        final double n2 = (this.getTickMarks().size() + (this.getTickMarks().size() - 1) * (Math.max(1, this.getMinorTickCount()) - 1)) * 2;
        this.minorTickPath.getElements().clear();
        final double max = Math.max(0.0, this.getMinorTickLength());
        if (max > 0.0 && n > n2) {
            if (Side.LEFT.equals(other)) {
                this.minorTickPath.setLayoutX(-0.5);
                this.minorTickPath.setLayoutY(0.5);
                final Iterator<T> iterator = this.minorTickMarkValues.iterator();
                while (iterator.hasNext()) {
                    final double displayPosition = this.getDisplayPosition(iterator.next());
                    if (displayPosition >= 0.0 && displayPosition <= n) {
                        this.minorTickPath.getElements().addAll(new MoveTo(this.getWidth() - max, displayPosition), new LineTo(this.getWidth() - 1.0, displayPosition));
                    }
                }
            }
            else if (Side.RIGHT.equals(other)) {
                this.minorTickPath.setLayoutX(0.5);
                this.minorTickPath.setLayoutY(0.5);
                final Iterator<T> iterator2 = this.minorTickMarkValues.iterator();
                while (iterator2.hasNext()) {
                    final double displayPosition2 = this.getDisplayPosition(iterator2.next());
                    if (displayPosition2 >= 0.0 && displayPosition2 <= n) {
                        this.minorTickPath.getElements().addAll(new MoveTo(1.0, displayPosition2), new LineTo(max, displayPosition2));
                    }
                }
            }
            else if (Side.TOP.equals(other)) {
                this.minorTickPath.setLayoutX(0.5);
                this.minorTickPath.setLayoutY(-0.5);
                final Iterator<T> iterator3 = this.minorTickMarkValues.iterator();
                while (iterator3.hasNext()) {
                    final double displayPosition3 = this.getDisplayPosition(iterator3.next());
                    if (displayPosition3 >= 0.0 && displayPosition3 <= n) {
                        this.minorTickPath.getElements().addAll(new MoveTo(displayPosition3, this.getHeight() - 1.0), new LineTo(displayPosition3, this.getHeight() - max));
                    }
                }
            }
            else {
                this.minorTickPath.setLayoutX(0.5);
                this.minorTickPath.setLayoutY(0.5);
                final Iterator<T> iterator4 = this.minorTickMarkValues.iterator();
                while (iterator4.hasNext()) {
                    final double displayPosition4 = this.getDisplayPosition(iterator4.next());
                    if (displayPosition4 >= 0.0 && displayPosition4 <= n) {
                        this.minorTickPath.getElements().addAll(new MoveTo(displayPosition4, 1.0), new LineTo(displayPosition4, max));
                    }
                }
            }
        }
    }
    
    @Override
    public void invalidateRange(final List<T> list) {
        if (list.isEmpty()) {
            this.dataMaxValue = this.getUpperBound();
            this.dataMinValue = this.getLowerBound();
        }
        else {
            this.dataMinValue = Double.MAX_VALUE;
            this.dataMaxValue = -1.7976931348623157E308;
        }
        for (final Number n : list) {
            this.dataMinValue = Math.min(this.dataMinValue, n.doubleValue());
            this.dataMaxValue = Math.max(this.dataMaxValue, n.doubleValue());
        }
        super.invalidateRange(list);
    }
    
    @Override
    public double getDisplayPosition(final T t) {
        return this.offset + (t.doubleValue() - this.currentLowerBound.get()) * this.getScale();
    }
    
    @Override
    public T getValueForDisplay(final double n) {
        return this.toRealValue((n - this.offset) / this.getScale() + this.currentLowerBound.get());
    }
    
    @Override
    public double getZeroPosition() {
        if (0.0 < this.getLowerBound() || 0.0 > this.getUpperBound()) {
            return Double.NaN;
        }
        return this.getDisplayPosition(0.0);
    }
    
    @Override
    public boolean isValueOnAxis(final T t) {
        final double doubleValue = t.doubleValue();
        return doubleValue >= this.getLowerBound() && doubleValue <= this.getUpperBound();
    }
    
    @Override
    public double toNumericValue(final T t) {
        return (t == null) ? Double.NaN : t.doubleValue();
    }
    
    @Override
    public T toRealValue(final double value) {
        return (T)new Double(value);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<ValueAxis<? extends Number>, Number> MINOR_TICK_LENGTH;
        private static final CssMetaData<ValueAxis<? extends Number>, Number> MINOR_TICK_COUNT;
        private static final CssMetaData<ValueAxis<? extends Number>, Boolean> MINOR_TICK_VISIBLE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            MINOR_TICK_LENGTH = new CssMetaData<ValueAxis<? extends Number>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)5.0) {
                @Override
                public boolean isSettable(final ValueAxis<? extends Number> valueAxis) {
                    return ((ValueAxis<Number>)valueAxis).minorTickLength == null || !((ValueAxis<Number>)valueAxis).minorTickLength.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ValueAxis<? extends Number> valueAxis) {
                    return (StyleableProperty<Number>)valueAxis.minorTickLengthProperty();
                }
            };
            MINOR_TICK_COUNT = new CssMetaData<ValueAxis<? extends Number>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)5) {
                @Override
                public boolean isSettable(final ValueAxis<? extends Number> valueAxis) {
                    return ((ValueAxis<Number>)valueAxis).minorTickCount == null || !((ValueAxis<Number>)valueAxis).minorTickCount.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ValueAxis<? extends Number> valueAxis) {
                    return (StyleableProperty<Number>)valueAxis.minorTickCountProperty();
                }
            };
            MINOR_TICK_VISIBLE = new CssMetaData<ValueAxis<? extends Number>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final ValueAxis<? extends Number> valueAxis) {
                    return ((ValueAxis<Number>)valueAxis).minorTickVisible == null || !((ValueAxis<Number>)valueAxis).minorTickVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final ValueAxis<? extends Number> valueAxis) {
                    return (StyleableProperty<Boolean>)valueAxis.minorTickVisibleProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Axis.getClassCssMetaData());
            list.add(StyleableProperties.MINOR_TICK_COUNT);
            list.add(StyleableProperties.MINOR_TICK_LENGTH);
            list.add(StyleableProperties.MINOR_TICK_COUNT);
            list.add(StyleableProperties.MINOR_TICK_VISIBLE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
