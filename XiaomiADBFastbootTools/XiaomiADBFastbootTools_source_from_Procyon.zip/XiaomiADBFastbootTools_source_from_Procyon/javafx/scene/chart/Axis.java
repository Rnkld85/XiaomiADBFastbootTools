// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.BooleanConverter;
import javafx.css.converter.PaintConverter;
import javafx.css.FontCssMetaData;
import javafx.css.converter.SizeConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringPropertyBase;
import javafx.beans.binding.DoubleExpression;
import javafx.beans.binding.ObjectExpression;
import javafx.beans.binding.StringExpression;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.css.Styleable;
import javafx.geometry.Dimension2D;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.PathElement;
import javafx.geometry.Bounds;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Translate;
import javafx.scene.transform.Transform;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import java.util.List;
import com.sun.javafx.scene.NodeHelper;
import javafx.scene.Node;
import javafx.geometry.Pos;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.paint.Color;
import javafx.beans.property.BooleanPropertyBase;
import javafx.css.StyleableDoubleProperty;
import java.util.Iterator;
import javafx.css.StyleableBooleanProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.collections.FXCollections;
import javafx.css.PseudoClass;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.BooleanProperty;
import javafx.geometry.Side;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableList;
import java.util.BitSet;
import javafx.scene.shape.Path;
import javafx.scene.control.Label;
import javafx.geometry.Orientation;
import javafx.scene.text.Text;
import javafx.scene.layout.Region;

public abstract class Axis<T> extends Region
{
    Text measure;
    private Orientation effectiveOrientation;
    private double effectiveTickLabelRotation;
    private Label axisLabel;
    private final Path tickMarkPath;
    private double oldLength;
    boolean rangeValid;
    boolean measureInvalid;
    boolean tickLabelsVisibleInvalid;
    private BitSet labelsToSkip;
    private final ObservableList<TickMark<T>> tickMarks;
    private final ObservableList<TickMark<T>> unmodifiableTickMarks;
    private ObjectProperty<Side> side;
    private ObjectProperty<String> label;
    private BooleanProperty tickMarkVisible;
    private BooleanProperty tickLabelsVisible;
    private DoubleProperty tickLength;
    private BooleanProperty autoRanging;
    private ObjectProperty<Font> tickLabelFont;
    private ObjectProperty<Paint> tickLabelFill;
    private DoubleProperty tickLabelGap;
    private BooleanProperty animated;
    private DoubleProperty tickLabelRotation;
    private static final PseudoClass TOP_PSEUDOCLASS_STATE;
    private static final PseudoClass BOTTOM_PSEUDOCLASS_STATE;
    private static final PseudoClass LEFT_PSEUDOCLASS_STATE;
    private static final PseudoClass RIGHT_PSEUDOCLASS_STATE;
    
    public ObservableList<TickMark<T>> getTickMarks() {
        return this.unmodifiableTickMarks;
    }
    
    public final Side getSide() {
        return this.side.get();
    }
    
    public final void setSide(final Side side) {
        this.side.set(side);
    }
    
    public final ObjectProperty<Side> sideProperty() {
        return this.side;
    }
    
    final void setEffectiveOrientation(final Orientation effectiveOrientation) {
        this.effectiveOrientation = effectiveOrientation;
    }
    
    final Side getEffectiveSide() {
        final Side side = this.getSide();
        if (side == null || (side.isVertical() && this.effectiveOrientation == Orientation.HORIZONTAL) || (side.isHorizontal() && this.effectiveOrientation == Orientation.VERTICAL)) {
            return (this.effectiveOrientation == Orientation.VERTICAL) ? Side.LEFT : Side.BOTTOM;
        }
        return side;
    }
    
    public final String getLabel() {
        return this.label.get();
    }
    
    public final void setLabel(final String s) {
        this.label.set(s);
    }
    
    public final ObjectProperty<String> labelProperty() {
        return this.label;
    }
    
    public final boolean isTickMarkVisible() {
        return this.tickMarkVisible.get();
    }
    
    public final void setTickMarkVisible(final boolean b) {
        this.tickMarkVisible.set(b);
    }
    
    public final BooleanProperty tickMarkVisibleProperty() {
        return this.tickMarkVisible;
    }
    
    public final boolean isTickLabelsVisible() {
        return this.tickLabelsVisible.get();
    }
    
    public final void setTickLabelsVisible(final boolean b) {
        this.tickLabelsVisible.set(b);
    }
    
    public final BooleanProperty tickLabelsVisibleProperty() {
        return this.tickLabelsVisible;
    }
    
    public final double getTickLength() {
        return this.tickLength.get();
    }
    
    public final void setTickLength(final double n) {
        this.tickLength.set(n);
    }
    
    public final DoubleProperty tickLengthProperty() {
        return this.tickLength;
    }
    
    public final boolean isAutoRanging() {
        return this.autoRanging.get();
    }
    
    public final void setAutoRanging(final boolean b) {
        this.autoRanging.set(b);
    }
    
    public final BooleanProperty autoRangingProperty() {
        return this.autoRanging;
    }
    
    public final Font getTickLabelFont() {
        return this.tickLabelFont.get();
    }
    
    public final void setTickLabelFont(final Font font) {
        this.tickLabelFont.set(font);
    }
    
    public final ObjectProperty<Font> tickLabelFontProperty() {
        return this.tickLabelFont;
    }
    
    public final Paint getTickLabelFill() {
        return this.tickLabelFill.get();
    }
    
    public final void setTickLabelFill(final Paint paint) {
        this.tickLabelFill.set(paint);
    }
    
    public final ObjectProperty<Paint> tickLabelFillProperty() {
        return this.tickLabelFill;
    }
    
    public final double getTickLabelGap() {
        return this.tickLabelGap.get();
    }
    
    public final void setTickLabelGap(final double n) {
        this.tickLabelGap.set(n);
    }
    
    public final DoubleProperty tickLabelGapProperty() {
        return this.tickLabelGap;
    }
    
    public final boolean getAnimated() {
        return this.animated.get();
    }
    
    public final void setAnimated(final boolean b) {
        this.animated.set(b);
    }
    
    public final BooleanProperty animatedProperty() {
        return this.animated;
    }
    
    public final double getTickLabelRotation() {
        return this.tickLabelRotation.getValue();
    }
    
    public final void setTickLabelRotation(final double d) {
        this.tickLabelRotation.setValue(d);
    }
    
    public final DoubleProperty tickLabelRotationProperty() {
        return this.tickLabelRotation;
    }
    
    public Axis() {
        this.measure = new Text();
        this.effectiveTickLabelRotation = Double.NaN;
        this.axisLabel = new Label();
        this.tickMarkPath = new Path();
        this.oldLength = 0.0;
        this.rangeValid = false;
        this.measureInvalid = false;
        this.tickLabelsVisibleInvalid = false;
        this.labelsToSkip = new BitSet();
        this.tickMarks = FXCollections.observableArrayList();
        this.unmodifiableTickMarks = FXCollections.unmodifiableObservableList(this.tickMarks);
        this.side = new StyleableObjectProperty<Side>() {
            @Override
            protected void invalidated() {
                final Side side = this.get();
                Axis.this.pseudoClassStateChanged(Axis.TOP_PSEUDOCLASS_STATE, side == Side.TOP);
                Axis.this.pseudoClassStateChanged(Axis.RIGHT_PSEUDOCLASS_STATE, side == Side.RIGHT);
                Axis.this.pseudoClassStateChanged(Axis.BOTTOM_PSEUDOCLASS_STATE, side == Side.BOTTOM);
                Axis.this.pseudoClassStateChanged(Axis.LEFT_PSEUDOCLASS_STATE, side == Side.LEFT);
                Axis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<Axis<?>, Side> getCssMetaData() {
                return StyleableProperties.SIDE;
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "side";
            }
        };
        this.label = new ObjectPropertyBase<String>() {
            @Override
            protected void invalidated() {
                Axis.this.axisLabel.setText(this.get());
                Axis.this.requestAxisLayout();
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "label";
            }
        };
        this.tickMarkVisible = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                Axis.this.tickMarkPath.setVisible(this.get());
                Axis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<Axis<?>, Boolean> getCssMetaData() {
                return StyleableProperties.TICK_MARK_VISIBLE;
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "tickMarkVisible";
            }
        };
        this.tickLabelsVisible = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                final Iterator iterator = Axis.this.tickMarks.iterator();
                while (iterator.hasNext()) {
                    iterator.next().setTextVisible(this.get());
                }
                Axis.this.tickLabelsVisibleInvalid = true;
                Axis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<Axis<?>, Boolean> getCssMetaData() {
                return StyleableProperties.TICK_LABELS_VISIBLE;
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "tickLabelsVisible";
            }
        };
        this.tickLength = new StyleableDoubleProperty(8.0) {
            @Override
            protected void invalidated() {
                if (Axis.this.tickLength.get() < 0.0 && !Axis.this.tickLength.isBound()) {
                    Axis.this.tickLength.set(0.0);
                }
                Axis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<Axis<?>, Number> getCssMetaData() {
                return StyleableProperties.TICK_LENGTH;
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "tickLength";
            }
        };
        this.autoRanging = new BooleanPropertyBase(true) {
            @Override
            protected void invalidated() {
                if (this.get()) {
                    Axis.this.requestAxisLayout();
                }
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "autoRanging";
            }
        };
        this.tickLabelFont = new StyleableObjectProperty<Font>(Font.font("System", 8.0)) {
            @Override
            protected void invalidated() {
                final Font font = this.get();
                Axis.this.measure.setFont(font);
                final Iterator<TickMark> iterator = Axis.this.getTickMarks().iterator();
                while (iterator.hasNext()) {
                    iterator.next().textNode.setFont(font);
                }
                Axis.this.measureInvalid = true;
                Axis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<Axis<?>, Font> getCssMetaData() {
                return StyleableProperties.TICK_LABEL_FONT;
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "tickLabelFont";
            }
        };
        this.tickLabelFill = new StyleableObjectProperty<Paint>((Paint)Color.BLACK) {
            @Override
            protected void invalidated() {
                final Iterator iterator = Axis.this.tickMarks.iterator();
                while (iterator.hasNext()) {
                    iterator.next().textNode.setFill(Axis.this.getTickLabelFill());
                }
            }
            
            @Override
            public CssMetaData<Axis<?>, Paint> getCssMetaData() {
                return StyleableProperties.TICK_LABEL_FILL;
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "tickLabelFill";
            }
        };
        this.tickLabelGap = new StyleableDoubleProperty(3.0) {
            @Override
            protected void invalidated() {
                Axis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<Axis<?>, Number> getCssMetaData() {
                return StyleableProperties.TICK_LABEL_TICK_GAP;
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "tickLabelGap";
            }
        };
        this.animated = new SimpleBooleanProperty(this, "animated", true);
        this.tickLabelRotation = new DoublePropertyBase(0.0) {
            @Override
            protected void invalidated() {
                if (Axis.this.isAutoRanging()) {
                    Axis.this.invalidateRange();
                }
                Axis.this.requestAxisLayout();
            }
            
            @Override
            public Object getBean() {
                return Axis.this;
            }
            
            @Override
            public String getName() {
                return "tickLabelRotation";
            }
        };
        this.getStyleClass().setAll("axis");
        this.axisLabel.getStyleClass().add("axis-label");
        this.axisLabel.setAlignment(Pos.CENTER);
        this.tickMarkPath.getStyleClass().add("axis-tick-mark");
        this.getChildren().addAll(this.axisLabel, this.tickMarkPath);
    }
    
    protected final boolean isRangeValid() {
        return this.rangeValid;
    }
    
    protected final void invalidateRange() {
        this.rangeValid = false;
    }
    
    protected final boolean shouldAnimate() {
        return this.getAnimated() && NodeHelper.isTreeShowing(this);
    }
    
    @Override
    public void requestLayout() {
    }
    
    public void requestAxisLayout() {
        super.requestLayout();
    }
    
    public void invalidateRange(final List<T> list) {
        this.invalidateRange();
        this.requestAxisLayout();
    }
    
    protected abstract Object autoRange(final double p0);
    
    protected abstract void setRange(final Object p0, final boolean p1);
    
    protected abstract Object getRange();
    
    public abstract double getZeroPosition();
    
    public abstract double getDisplayPosition(final T p0);
    
    public abstract T getValueForDisplay(final double p0);
    
    public abstract boolean isValueOnAxis(final T p0);
    
    public abstract double toNumericValue(final T p0);
    
    public abstract T toRealValue(final double p0);
    
    protected abstract List<T> calculateTickValues(final double p0, final Object p1);
    
    @Override
    protected double computePrefHeight(final double n) {
        if (this.getEffectiveSide().isVertical()) {
            return 100.0;
        }
        final Object autoRange = this.autoRange(n);
        double max = 0.0;
        if (this.isTickLabelsVisible()) {
            final Iterator<T> iterator = this.calculateTickValues(n, autoRange).iterator();
            while (iterator.hasNext()) {
                max = Math.max(max, this.measureTickMarkSize(iterator.next(), autoRange).getHeight());
            }
        }
        return max + this.getTickLabelGap() + (this.isTickMarkVisible() ? ((this.getTickLength() > 0.0) ? this.getTickLength() : 0.0) : 0.0) + ((this.axisLabel.getText() == null || this.axisLabel.getText().length() == 0) ? 0.0 : this.axisLabel.prefHeight(-1.0));
    }
    
    @Override
    protected double computePrefWidth(final double n) {
        if (this.getEffectiveSide().isVertical()) {
            final Object autoRange = this.autoRange(n);
            double max = 0.0;
            if (this.isTickLabelsVisible()) {
                final Iterator<T> iterator = this.calculateTickValues(n, autoRange).iterator();
                while (iterator.hasNext()) {
                    max = Math.max(max, this.measureTickMarkSize(iterator.next(), autoRange).getWidth());
                }
            }
            return max + this.getTickLabelGap() + (this.isTickMarkVisible() ? ((this.getTickLength() > 0.0) ? this.getTickLength() : 0.0) : 0.0) + ((this.axisLabel.getText() == null || this.axisLabel.getText().length() == 0) ? 0.0 : this.axisLabel.prefHeight(-1.0));
        }
        return 100.0;
    }
    
    protected void tickMarksUpdated() {
    }
    
    @Override
    protected void layoutChildren() {
        final boolean b = this.oldLength == 0.0;
        final Side effectiveSide = this.getEffectiveSide();
        final double oldLength = effectiveSide.isVertical() ? this.getHeight() : this.getWidth();
        final boolean b2 = !this.isRangeValid();
        final boolean b3 = this.oldLength != oldLength;
        if (b3 || b2) {
            Object o;
            if (this.isAutoRanging()) {
                o = this.autoRange(oldLength);
                this.setRange(o, this.getAnimated() && !b && NodeHelper.isTreeShowing(this) && b2);
            }
            else {
                o = this.getRange();
            }
            final List<T> calculateTickValues = this.calculateTickValues(oldLength, o);
            final Iterator<Object> iterator = this.tickMarks.iterator();
            while (iterator.hasNext()) {
                final TickMark tickMark = iterator.next();
                if (this.shouldAnimate()) {
                    final FadeTransition fadeTransition = new FadeTransition(Duration.millis(250.0), tickMark.textNode);
                    fadeTransition.setToValue(0.0);
                    fadeTransition.setOnFinished(p1 -> this.getChildren().remove(tickMark.textNode));
                    fadeTransition.play();
                }
                else {
                    this.getChildren().remove(tickMark.textNode);
                }
                iterator.remove();
            }
            for (final T next : calculateTickValues) {
                final TickMark<T> tickMark2 = new TickMark<T>();
                tickMark2.setValue(next);
                tickMark2.textNode.setText(this.getTickMarkLabel(next));
                tickMark2.textNode.setFont(this.getTickLabelFont());
                tickMark2.textNode.setFill(this.getTickLabelFill());
                tickMark2.setTextVisible(this.isTickLabelsVisible());
                if (this.shouldAnimate()) {
                    tickMark2.textNode.setOpacity(0.0);
                }
                this.getChildren().add(tickMark2.textNode);
                this.tickMarks.add(tickMark2);
                if (this.shouldAnimate()) {
                    final FadeTransition fadeTransition2 = new FadeTransition(Duration.millis(750.0), tickMark2.textNode);
                    fadeTransition2.setFromValue(0.0);
                    fadeTransition2.setToValue(1.0);
                    fadeTransition2.play();
                }
            }
            this.tickMarksUpdated();
            this.oldLength = oldLength;
            this.rangeValid = true;
        }
        if (b3 || b2 || this.measureInvalid || this.tickLabelsVisibleInvalid) {
            this.measureInvalid = false;
            this.tickLabelsVisibleInvalid = false;
            this.labelsToSkip.clear();
            int n = 0;
            double n2 = 0.0;
            double a = 0.0;
            for (final TickMark<T> tickMark3 : this.tickMarks) {
                tickMark3.setPosition(this.getDisplayPosition(tickMark3.getValue()));
                if (tickMark3.isTextVisible()) {
                    final double measureTickMarkSize = this.measureTickMarkSize(tickMark3.getValue(), effectiveSide);
                    n2 += measureTickMarkSize;
                    a = (double)Math.round(Math.max(a, measureTickMarkSize));
                }
            }
            if (a > 0.0 && oldLength < n2) {
                n = (int)(this.tickMarks.size() * a / oldLength) + 1;
            }
            if (n > 0) {
                int n3 = 0;
                for (final TickMark tickMark4 : this.tickMarks) {
                    if (tickMark4.isTextVisible()) {
                        tickMark4.setTextVisible(n3++ % n == 0);
                    }
                }
            }
            if (this.tickMarks.size() > 2) {
                final TickMark<T> tickMark5 = this.tickMarks.get(0);
                final TickMark<T> tickMark6 = this.tickMarks.get(1);
                if (this.isTickLabelsOverlap(effectiveSide, tickMark5, tickMark6, this.getTickLabelGap())) {
                    tickMark6.setTextVisible(false);
                }
                final TickMark<T> tickMark7 = this.tickMarks.get(this.tickMarks.size() - 2);
                if (this.isTickLabelsOverlap(effectiveSide, tickMark7, this.tickMarks.get(this.tickMarks.size() - 1), this.getTickLabelGap())) {
                    tickMark7.setTextVisible(false);
                }
            }
            this.updateTickMarks(effectiveSide, oldLength);
        }
    }
    
    private void updateTickMarks(final Side other, final double n) {
        this.tickMarkPath.getElements().clear();
        final double width = this.getWidth();
        final double height = this.getHeight();
        final double n2 = (this.isTickMarkVisible() && this.getTickLength() > 0.0) ? this.getTickLength() : 0.0;
        final double effectiveTickLabelRotation = this.getEffectiveTickLabelRotation();
        if (Side.LEFT.equals(other)) {
            this.tickMarkPath.setLayoutX(-0.5);
            this.tickMarkPath.setLayoutY(0.5);
            if (this.getLabel() != null) {
                this.axisLabel.getTransforms().setAll(new Translate(0.0, height), new Rotate(-90.0, 0.0, 0.0));
                this.axisLabel.setLayoutX(0.0);
                this.axisLabel.setLayoutY(0.0);
                this.axisLabel.resize(height, Math.ceil(this.axisLabel.prefHeight(width)));
            }
            for (final TickMark<T> tickMark : this.tickMarks) {
                this.positionTextNode(tickMark.textNode, width - this.getTickLabelGap() - n2, tickMark.getPosition(), effectiveTickLabelRotation, other);
                this.updateTickMark(tickMark, n, width - n2, tickMark.getPosition(), width, tickMark.getPosition());
            }
        }
        else if (Side.RIGHT.equals(other)) {
            this.tickMarkPath.setLayoutX(0.5);
            this.tickMarkPath.setLayoutY(0.5);
            if (this.getLabel() != null) {
                final double ceil = Math.ceil(this.axisLabel.prefHeight(width));
                this.axisLabel.getTransforms().setAll(new Translate(0.0, height), new Rotate(-90.0, 0.0, 0.0));
                this.axisLabel.setLayoutX(width - ceil);
                this.axisLabel.setLayoutY(0.0);
                this.axisLabel.resize(height, ceil);
            }
            for (final TickMark<T> tickMark2 : this.tickMarks) {
                this.positionTextNode(tickMark2.textNode, this.getTickLabelGap() + n2, tickMark2.getPosition(), effectiveTickLabelRotation, other);
                this.updateTickMark(tickMark2, n, 0.0, tickMark2.getPosition(), n2, tickMark2.getPosition());
            }
        }
        else if (Side.TOP.equals(other)) {
            this.tickMarkPath.setLayoutX(0.5);
            this.tickMarkPath.setLayoutY(-0.5);
            if (this.getLabel() != null) {
                this.axisLabel.getTransforms().clear();
                this.axisLabel.setLayoutX(0.0);
                this.axisLabel.setLayoutY(0.0);
                this.axisLabel.resize(width, Math.ceil(this.axisLabel.prefHeight(width)));
            }
            for (final TickMark<T> tickMark3 : this.tickMarks) {
                this.positionTextNode(tickMark3.textNode, tickMark3.getPosition(), height - n2 - this.getTickLabelGap(), effectiveTickLabelRotation, other);
                this.updateTickMark(tickMark3, n, tickMark3.getPosition(), height, tickMark3.getPosition(), height - n2);
            }
        }
        else {
            this.tickMarkPath.setLayoutX(0.5);
            this.tickMarkPath.setLayoutY(0.5);
            if (this.getLabel() != null) {
                this.axisLabel.getTransforms().clear();
                final double ceil2 = Math.ceil(this.axisLabel.prefHeight(width));
                this.axisLabel.setLayoutX(0.0);
                this.axisLabel.setLayoutY(height - ceil2);
                this.axisLabel.resize(width, ceil2);
            }
            for (final TickMark<T> tickMark4 : this.tickMarks) {
                this.positionTextNode(tickMark4.textNode, tickMark4.getPosition(), n2 + this.getTickLabelGap(), effectiveTickLabelRotation, other);
                this.updateTickMark(tickMark4, n, tickMark4.getPosition(), 0.0, tickMark4.getPosition(), n2);
            }
        }
    }
    
    private boolean isTickLabelsOverlap(final Side side, final TickMark<T> tickMark, final TickMark<T> tickMark2, final double n) {
        if (!tickMark.isTextVisible() || !tickMark2.isTextVisible()) {
            return false;
        }
        final double measureTickMarkSize = this.measureTickMarkSize(tickMark.getValue(), side);
        final double measureTickMarkSize2 = this.measureTickMarkSize(tickMark2.getValue(), side);
        final double n2 = tickMark.getPosition() - measureTickMarkSize / 2.0;
        final double n3 = tickMark.getPosition() + measureTickMarkSize / 2.0;
        final double n4 = tickMark2.getPosition() - measureTickMarkSize2 / 2.0;
        final double n5 = tickMark2.getPosition() + measureTickMarkSize2 / 2.0;
        return side.isVertical() ? (n2 - n5 <= n) : (n4 - n3 <= n);
    }
    
    private void positionTextNode(final Text text, final double n, final double n2, final double rotate, final Side other) {
        text.setLayoutX(0.0);
        text.setLayoutY(0.0);
        text.setRotate(rotate);
        final Bounds boundsInParent = text.getBoundsInParent();
        if (Side.LEFT.equals(other)) {
            text.setLayoutX(n - boundsInParent.getWidth() - boundsInParent.getMinX());
            text.setLayoutY(n2 - boundsInParent.getHeight() / 2.0 - boundsInParent.getMinY());
        }
        else if (Side.RIGHT.equals(other)) {
            text.setLayoutX(n - boundsInParent.getMinX());
            text.setLayoutY(n2 - boundsInParent.getHeight() / 2.0 - boundsInParent.getMinY());
        }
        else if (Side.TOP.equals(other)) {
            text.setLayoutX(n - boundsInParent.getWidth() / 2.0 - boundsInParent.getMinX());
            text.setLayoutY(n2 - boundsInParent.getHeight() - boundsInParent.getMinY());
        }
        else {
            text.setLayoutX(n - boundsInParent.getWidth() / 2.0 - boundsInParent.getMinX());
            text.setLayoutY(n2 - boundsInParent.getMinY());
        }
    }
    
    private void updateTickMark(final TickMark<T> tickMark, final double a, final double n, final double n2, final double n3, final double n4) {
        if (tickMark.getPosition() >= 0.0 && tickMark.getPosition() <= Math.ceil(a)) {
            tickMark.textNode.setVisible(tickMark.isTextVisible());
            this.tickMarkPath.getElements().addAll(new MoveTo(n, n2), new LineTo(n3, n4));
        }
        else {
            tickMark.textNode.setVisible(false);
        }
    }
    
    protected abstract String getTickMarkLabel(final T p0);
    
    protected final Dimension2D measureTickMarkLabelSize(final String text, final double rotate) {
        this.measure.setRotate(rotate);
        this.measure.setText(text);
        final Bounds boundsInParent = this.measure.getBoundsInParent();
        return new Dimension2D(boundsInParent.getWidth(), boundsInParent.getHeight());
    }
    
    protected final Dimension2D measureTickMarkSize(final T t, final double n) {
        return this.measureTickMarkLabelSize(this.getTickMarkLabel(t), n);
    }
    
    protected Dimension2D measureTickMarkSize(final T t, final Object o) {
        return this.measureTickMarkSize(t, this.getEffectiveTickLabelRotation());
    }
    
    private double measureTickMarkSize(final T t, final Side side) {
        final Dimension2D measureTickMarkSize = this.measureTickMarkSize(t, this.getEffectiveTickLabelRotation());
        return side.isVertical() ? measureTickMarkSize.getHeight() : measureTickMarkSize.getWidth();
    }
    
    final double getEffectiveTickLabelRotation() {
        return (!this.isAutoRanging() || Double.isNaN(this.effectiveTickLabelRotation)) ? this.getTickLabelRotation() : this.effectiveTickLabelRotation;
    }
    
    final void setEffectiveTickLabelRotation(final double effectiveTickLabelRotation) {
        this.effectiveTickLabelRotation = effectiveTickLabelRotation;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    static {
        TOP_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("top");
        BOTTOM_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("bottom");
        LEFT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("left");
        RIGHT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("right");
    }
    
    public static final class TickMark<T>
    {
        private StringProperty label;
        private ObjectProperty<T> value;
        private DoubleProperty position;
        Text textNode;
        private BooleanProperty textVisible;
        
        public final String getLabel() {
            return this.label.get();
        }
        
        public final void setLabel(final String s) {
            this.label.set(s);
        }
        
        public final StringExpression labelProperty() {
            return this.label;
        }
        
        public final T getValue() {
            return this.value.get();
        }
        
        public final void setValue(final T t) {
            this.value.set(t);
        }
        
        public final ObjectExpression<T> valueProperty() {
            return this.value;
        }
        
        public final double getPosition() {
            return this.position.get();
        }
        
        public final void setPosition(final double n) {
            this.position.set(n);
        }
        
        public final DoubleExpression positionProperty() {
            return this.position;
        }
        
        public final boolean isTextVisible() {
            return this.textVisible.get();
        }
        
        public final void setTextVisible(final boolean b) {
            this.textVisible.set(b);
        }
        
        public TickMark() {
            this.label = new StringPropertyBase() {
                @Override
                protected void invalidated() {
                    TickMark.this.textNode.setText(this.getValue());
                }
                
                @Override
                public Object getBean() {
                    return TickMark.this;
                }
                
                @Override
                public String getName() {
                    return "label";
                }
            };
            this.value = new SimpleObjectProperty<T>(this, "value");
            this.position = new SimpleDoubleProperty(this, "position");
            this.textNode = new Text();
            this.textVisible = new BooleanPropertyBase(true) {
                @Override
                protected void invalidated() {
                    if (!this.get()) {
                        TickMark.this.textNode.setVisible(false);
                    }
                }
                
                @Override
                public Object getBean() {
                    return TickMark.this;
                }
                
                @Override
                public String getName() {
                    return "textVisible";
                }
            };
        }
        
        @Override
        public String toString() {
            return this.value.get().toString();
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Axis<?>, Side> SIDE;
        private static final CssMetaData<Axis<?>, Number> TICK_LENGTH;
        private static final CssMetaData<Axis<?>, Font> TICK_LABEL_FONT;
        private static final CssMetaData<Axis<?>, Paint> TICK_LABEL_FILL;
        private static final CssMetaData<Axis<?>, Number> TICK_LABEL_TICK_GAP;
        private static final CssMetaData<Axis<?>, Boolean> TICK_MARK_VISIBLE;
        private static final CssMetaData<Axis<?>, Boolean> TICK_LABELS_VISIBLE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            SIDE = new CssMetaData<Axis<?>, Side>((StyleConverter)new EnumConverter(Side.class)) {
                @Override
                public boolean isSettable(final Axis<?> axis) {
                    return ((Axis<Object>)axis).side == null || !((Axis<Object>)axis).side.isBound();
                }
                
                @Override
                public StyleableProperty<Side> getStyleableProperty(final Axis<?> axis) {
                    return (StyleableProperty<Side>)(StyleableProperty)axis.sideProperty();
                }
            };
            TICK_LENGTH = new CssMetaData<Axis<?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)8.0) {
                @Override
                public boolean isSettable(final Axis<?> axis) {
                    return ((Axis<Object>)axis).tickLength == null || !((Axis<Object>)axis).tickLength.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Axis<?> axis) {
                    return (StyleableProperty<Number>)axis.tickLengthProperty();
                }
            };
            TICK_LABEL_FONT = new FontCssMetaData<Axis<?>>(Font.font("system", 8.0)) {
                public boolean isSettable(final Axis<?> axis) {
                    return ((Axis<Object>)axis).tickLabelFont == null || !((Axis<Object>)axis).tickLabelFont.isBound();
                }
                
                public StyleableProperty<Font> getStyleableProperty(final Axis<?> axis) {
                    return (StyleableProperty<Font>)(StyleableProperty)axis.tickLabelFontProperty();
                }
            };
            TICK_LABEL_FILL = new CssMetaData<Axis<?>, Paint>((StyleConverter)PaintConverter.getInstance(), (Paint)Color.BLACK) {
                @Override
                public boolean isSettable(final Axis<?> axis) {
                    return ((Axis<Object>)axis).tickLabelFill == null | !((Axis<Object>)axis).tickLabelFill.isBound();
                }
                
                @Override
                public StyleableProperty<Paint> getStyleableProperty(final Axis<?> axis) {
                    return (StyleableProperty<Paint>)(StyleableProperty)axis.tickLabelFillProperty();
                }
            };
            TICK_LABEL_TICK_GAP = new CssMetaData<Axis<?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)3.0) {
                @Override
                public boolean isSettable(final Axis<?> axis) {
                    return ((Axis<Object>)axis).tickLabelGap == null || !((Axis<Object>)axis).tickLabelGap.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Axis<?> axis) {
                    return (StyleableProperty<Number>)axis.tickLabelGapProperty();
                }
            };
            TICK_MARK_VISIBLE = new CssMetaData<Axis<?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final Axis<?> axis) {
                    return ((Axis<Object>)axis).tickMarkVisible == null || !((Axis<Object>)axis).tickMarkVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Axis<?> axis) {
                    return (StyleableProperty<Boolean>)axis.tickMarkVisibleProperty();
                }
            };
            TICK_LABELS_VISIBLE = new CssMetaData<Axis<?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final Axis<?> axis) {
                    return ((Axis<Object>)axis).tickLabelsVisible == null || !((Axis<Object>)axis).tickLabelsVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Axis<?> axis) {
                    return (StyleableProperty<Boolean>)axis.tickLabelsVisibleProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Region.getClassCssMetaData());
            list.add(StyleableProperties.SIDE);
            list.add(StyleableProperties.TICK_LENGTH);
            list.add(StyleableProperties.TICK_LABEL_FONT);
            list.add(StyleableProperties.TICK_LABEL_FILL);
            list.add(StyleableProperties.TICK_LABEL_TICK_GAP);
            list.add(StyleableProperties.TICK_MARK_VISIBLE);
            list.add(StyleableProperties.TICK_LABELS_VISIBLE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
