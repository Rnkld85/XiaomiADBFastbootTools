// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import javafx.event.ActionEvent;
import java.util.Collection;
import com.sun.javafx.charts.Legend;
import java.util.Iterator;
import javafx.animation.ParallelTransition;
import javafx.scene.Node;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import javafx.scene.AccessibleRole;
import javafx.scene.layout.StackPane;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.beans.NamedArg;

public class ScatterChart<X, Y> extends XYChart<X, Y>
{
    public ScatterChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2) {
        this(axis, axis2, FXCollections.observableArrayList());
    }
    
    public ScatterChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2, @NamedArg("data") final ObservableList<Series<X, Y>> data) {
        super(axis, axis2);
        this.setData(data);
    }
    
    @Override
    protected void dataItemAdded(final Series<X, Y> series, final int n, final Data<X, Y> data) {
        Node node = data.getNode();
        if (node == null) {
            node = new StackPane();
            node.setAccessibleRole(AccessibleRole.TEXT);
            node.setAccessibleRoleDescription("Point");
            node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
            data.setNode(node);
        }
        node.getStyleClass().setAll(new String[] { "chart-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, this.getData().indexOf(series)), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), series.defaultColorStyleClass });
        if (this.shouldAnimate()) {
            node.setOpacity(0.0);
            this.getPlotChildren().add(node);
            final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), node);
            fadeTransition.setToValue(1.0);
            fadeTransition.play();
        }
        else {
            this.getPlotChildren().add(node);
        }
    }
    
    @Override
    protected void dataItemRemoved(final Data<X, Y> data, final Series<X, Y> series) {
        final Node node = data.getNode();
        if (node != null) {
            node.focusTraversableProperty().unbind();
        }
        if (this.shouldAnimate()) {
            final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), node);
            fadeTransition.setToValue(0.0);
            final Node node2;
            fadeTransition.setOnFinished(p3 -> {
                this.getPlotChildren().remove(node2);
                this.removeDataItemFromDisplay(series, data);
                node2.setOpacity(1.0);
                return;
            });
            fadeTransition.play();
        }
        else {
            this.getPlotChildren().remove(node);
            this.removeDataItemFromDisplay(series, data);
        }
    }
    
    @Override
    protected void dataItemChanged(final Data<X, Y> data) {
    }
    
    @Override
    protected void seriesAdded(final Series<X, Y> series, final int n) {
        for (int i = 0; i < series.getData().size(); ++i) {
            this.dataItemAdded(series, i, (Data<X, Y>)series.getData().get(i));
        }
    }
    
    @Override
    protected void seriesRemoved(final Series<X, Y> series) {
        if (this.shouldAnimate()) {
            final ParallelTransition parallelTransition = new ParallelTransition();
            parallelTransition.setOnFinished(p1 -> this.removeSeriesFromDisplay(series));
            final Iterator<Data> iterator = (Iterator<Data>)series.getData().iterator();
            while (iterator.hasNext()) {
                final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), iterator.next().getNode());
                fadeTransition.setToValue(0.0);
                final Node node;
                fadeTransition.setOnFinished(p1 -> {
                    this.getPlotChildren().remove(node);
                    node.setOpacity(1.0);
                    return;
                });
                parallelTransition.getChildren().add(fadeTransition);
            }
            parallelTransition.play();
        }
        else {
            final Iterator<Data> iterator2 = (Iterator<Data>)series.getData().iterator();
            while (iterator2.hasNext()) {
                this.getPlotChildren().remove(iterator2.next().getNode());
            }
            this.removeSeriesFromDisplay(series);
        }
    }
    
    @Override
    protected void layoutPlotChildren() {
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Iterator<Data<X, Y>> displayedDataIterator = this.getDisplayedDataIterator(this.getData().get(i));
            while (displayedDataIterator.hasNext()) {
                final Data<X, Y> data = displayedDataIterator.next();
                final double displayPosition = this.getXAxis().getDisplayPosition(data.getCurrentX());
                final double displayPosition2 = this.getYAxis().getDisplayPosition(data.getCurrentY());
                if (!Double.isNaN(displayPosition)) {
                    if (Double.isNaN(displayPosition2)) {
                        continue;
                    }
                    final Node node = data.getNode();
                    if (node == null) {
                        continue;
                    }
                    final double prefWidth = node.prefWidth(-1.0);
                    final double prefHeight = node.prefHeight(-1.0);
                    node.resizeRelocate(displayPosition - prefWidth / 2.0, displayPosition2 - prefHeight / 2.0, prefWidth, prefHeight);
                }
            }
        }
    }
    
    @Override
    Legend.LegendItem createLegendItemForSeries(final Series<X, Y> series, final int n) {
        final Legend.LegendItem legendItem = new Legend.LegendItem(series.getName());
        final Node node = series.getData().isEmpty() ? null : series.getData().get(0).getNode();
        if (node != null) {
            legendItem.getSymbol().getStyleClass().addAll((Collection<?>)node.getStyleClass());
        }
        return legendItem;
    }
}
