// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import javafx.event.ActionEvent;
import com.sun.javafx.charts.Legend;
import java.util.List;
import java.util.ArrayList;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import javafx.scene.AccessibleRole;
import javafx.scene.AccessibleAttribute;
import javafx.animation.ParallelTransition;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import javafx.scene.Node;
import java.util.Iterator;
import javafx.scene.shape.Shape;
import javafx.scene.shape.Ellipse;
import javafx.scene.layout.StackPane;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.beans.NamedArg;

public class BubbleChart<X, Y> extends XYChart<X, Y>
{
    public BubbleChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2) {
        this(axis, axis2, FXCollections.observableArrayList());
    }
    
    public BubbleChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2, @NamedArg("data") final ObservableList<Series<X, Y>> data) {
        super(axis, axis2);
        if (!(axis instanceof ValueAxis) || !(axis2 instanceof ValueAxis)) {
            throw new IllegalArgumentException("Axis type incorrect, X and Y should both be NumberAxis");
        }
        this.setData(data);
    }
    
    private static double getDoubleValue(final Object o, final double n) {
        return (o instanceof Number) ? ((Number)o).doubleValue() : n;
    }
    
    @Override
    protected void layoutPlotChildren() {
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Iterator<Data<X, Y>> displayedDataIterator = this.getDisplayedDataIterator(this.getData().get(i));
            while (displayedDataIterator.hasNext()) {
                final Data<X, Y> data = displayedDataIterator.next();
                final double displayPosition = this.getXAxis().getDisplayPosition(data.getCurrentX());
                final double displayPosition2 = this.getYAxis().getDisplayPosition(data.getCurrentY());
                if (!Double.isNaN(displayPosition)) {
                    if (Double.isNaN(displayPosition2)) {
                        continue;
                    }
                    final Node node = data.getNode();
                    if (node == null || !(node instanceof StackPane)) {
                        continue;
                    }
                    final StackPane stackPane = (StackPane)data.getNode();
                    Ellipse shape;
                    if (stackPane.getShape() == null) {
                        shape = new Ellipse(getDoubleValue(data.getExtraValue(), 1.0), getDoubleValue(data.getExtraValue(), 1.0));
                    }
                    else {
                        if (!(stackPane.getShape() instanceof Ellipse)) {
                            return;
                        }
                        shape = (Ellipse)stackPane.getShape();
                    }
                    shape.setRadiusX(getDoubleValue(data.getExtraValue(), 1.0) * ((this.getXAxis() instanceof NumberAxis) ? Math.abs(((NumberAxis)this.getXAxis()).getScale()) : 1.0));
                    shape.setRadiusY(getDoubleValue(data.getExtraValue(), 1.0) * ((this.getYAxis() instanceof NumberAxis) ? Math.abs(((NumberAxis)this.getYAxis()).getScale()) : 1.0));
                    stackPane.setShape(null);
                    stackPane.setShape(shape);
                    stackPane.setScaleShape(false);
                    stackPane.setCenterShape(false);
                    stackPane.setCacheShape(false);
                    node.setLayoutX(displayPosition);
                    node.setLayoutY(displayPosition2);
                }
            }
        }
    }
    
    @Override
    protected void dataItemAdded(final Series<X, Y> series, final int n, final Data<X, Y> data) {
        final Node bubble = this.createBubble(series, this.getData().indexOf(series), data, n);
        if (this.shouldAnimate()) {
            bubble.setOpacity(0.0);
            this.getPlotChildren().add(bubble);
            final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), bubble);
            fadeTransition.setToValue(1.0);
            fadeTransition.play();
        }
        else {
            this.getPlotChildren().add(bubble);
        }
    }
    
    @Override
    protected void dataItemRemoved(final Data<X, Y> data, final Series<X, Y> series) {
        final Node node = data.getNode();
        if (this.shouldAnimate()) {
            final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), node);
            fadeTransition.setToValue(0.0);
            final Node node2;
            fadeTransition.setOnFinished(p3 -> {
                this.getPlotChildren().remove(node2);
                this.removeDataItemFromDisplay(series, data);
                node2.setOpacity(1.0);
                return;
            });
            fadeTransition.play();
        }
        else {
            this.getPlotChildren().remove(node);
            this.removeDataItemFromDisplay(series, data);
        }
    }
    
    @Override
    protected void dataItemChanged(final Data<X, Y> data) {
    }
    
    @Override
    protected void seriesAdded(final Series<X, Y> series, final int n) {
        for (int i = 0; i < series.getData().size(); ++i) {
            final Node bubble = this.createBubble(series, n, series.getData().get(i), i);
            if (this.shouldAnimate()) {
                bubble.setOpacity(0.0);
                this.getPlotChildren().add(bubble);
                final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), bubble);
                fadeTransition.setToValue(1.0);
                fadeTransition.play();
            }
            else {
                this.getPlotChildren().add(bubble);
            }
        }
    }
    
    @Override
    protected void seriesRemoved(final Series<X, Y> series) {
        if (this.shouldAnimate()) {
            final ParallelTransition parallelTransition = new ParallelTransition();
            parallelTransition.setOnFinished(p1 -> this.removeSeriesFromDisplay(series));
            final Iterator<Data> iterator = (Iterator<Data>)series.getData().iterator();
            while (iterator.hasNext()) {
                final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), iterator.next().getNode());
                fadeTransition.setToValue(0.0);
                final Node node;
                fadeTransition.setOnFinished(p1 -> {
                    this.getPlotChildren().remove(node);
                    node.setOpacity(1.0);
                    return;
                });
                parallelTransition.getChildren().add(fadeTransition);
            }
            parallelTransition.play();
        }
        else {
            final Iterator<Data> iterator2 = (Iterator<Data>)series.getData().iterator();
            while (iterator2.hasNext()) {
                this.getPlotChildren().remove(iterator2.next().getNode());
            }
            this.removeSeriesFromDisplay(series);
        }
    }
    
    private Node createBubble(final Series<X, Y> series, final int n, final Data<X, Y> data, final int n2) {
        Node node = data.getNode();
        if (node == null) {
            node = new StackPane() {
                @Override
                public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
                    switch (accessibleAttribute) {
                        case TEXT: {
                            final String accessibleText = this.getAccessibleText();
                            if (data.getExtraValue() == null) {
                                return accessibleText;
                            }
                            return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;, accessibleText, data.getExtraValue());
                        }
                        default: {
                            return super.queryAccessibleAttribute(accessibleAttribute, array);
                        }
                    }
                }
            };
            node.setAccessibleRole(AccessibleRole.TEXT);
            node.setAccessibleRoleDescription("Bubble");
            node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
            data.setNode(node);
        }
        node.getStyleClass().setAll(new String[] { "chart-bubble", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n2), series.defaultColorStyleClass });
        return node;
    }
    
    @Override
    protected void updateAxisRange() {
        final Axis<X> xAxis = this.getXAxis();
        final Axis<Y> yAxis = this.getYAxis();
        List<X> list = null;
        List<Y> list2 = null;
        if (xAxis.isAutoRanging()) {
            list = new ArrayList<X>();
        }
        if (yAxis.isAutoRanging()) {
            list2 = new ArrayList<Y>();
        }
        final boolean b = xAxis instanceof CategoryAxis;
        final boolean b2 = yAxis instanceof CategoryAxis;
        if (list != null || list2 != null) {
            final Iterator<Series> iterator = this.getData().iterator();
            while (iterator.hasNext()) {
                for (final Data<Object, Y> data : iterator.next().getData()) {
                    if (list != null) {
                        if (b) {
                            list.add((X)data.getXValue());
                        }
                        else {
                            list.add(xAxis.toRealValue(xAxis.toNumericValue((X)data.getXValue()) + getDoubleValue(data.getExtraValue(), 0.0)));
                            list.add(xAxis.toRealValue(xAxis.toNumericValue((X)data.getXValue()) - getDoubleValue(data.getExtraValue(), 0.0)));
                        }
                    }
                    if (list2 != null) {
                        if (b2) {
                            list2.add((Y)data.getYValue());
                        }
                        else {
                            list2.add(yAxis.toRealValue(yAxis.toNumericValue((Y)data.getYValue()) + getDoubleValue(data.getExtraValue(), 0.0)));
                            list2.add(yAxis.toRealValue(yAxis.toNumericValue((Y)data.getYValue()) - getDoubleValue(data.getExtraValue(), 0.0)));
                        }
                    }
                }
            }
            if (list != null) {
                xAxis.invalidateRange(list);
            }
            if (list2 != null) {
                yAxis.invalidateRange(list2);
            }
        }
    }
    
    @Override
    Legend.LegendItem createLegendItemForSeries(final Series<X, Y> series, final int n) {
        final Legend.LegendItem legendItem = new Legend.LegendItem(series.getName());
        legendItem.getSymbol().getStyleClass().addAll(new String[] { invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), "chart-bubble", "bubble-legend-symbol", series.defaultColorStyleClass });
        return legendItem;
    }
}
