// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import javafx.beans.value.ObservableObjectValue;
import javafx.beans.value.ObservableValue;
import java.text.ParseException;
import javafx.beans.value.ChangeListener;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.Collection;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.Styleable;
import javafx.geometry.Side;
import javafx.geometry.Dimension2D;
import java.util.ArrayList;
import java.util.List;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.util.StringConverter;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.beans.property.BooleanPropertyBase;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.Parent;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.StringProperty;
import com.sun.javafx.charts.ChartLayoutAnimator;

public final class NumberAxis extends ValueAxis<Number>
{
    private Object currentAnimationID;
    private final ChartLayoutAnimator animator;
    private final StringProperty currentFormatterProperty;
    private final DefaultFormatter defaultFormatter;
    private BooleanProperty forceZeroInRange;
    private DoubleProperty tickUnit;
    
    public final boolean isForceZeroInRange() {
        return this.forceZeroInRange.getValue();
    }
    
    public final void setForceZeroInRange(final boolean b) {
        this.forceZeroInRange.setValue(b);
    }
    
    public final BooleanProperty forceZeroInRangeProperty() {
        return this.forceZeroInRange;
    }
    
    public final double getTickUnit() {
        return this.tickUnit.get();
    }
    
    public final void setTickUnit(final double n) {
        this.tickUnit.set(n);
    }
    
    public final DoubleProperty tickUnitProperty() {
        return this.tickUnit;
    }
    
    public NumberAxis() {
        this.animator = new ChartLayoutAnimator(this);
        this.currentFormatterProperty = new SimpleStringProperty(this, "currentFormatter", "");
        this.defaultFormatter = new DefaultFormatter(this);
        this.forceZeroInRange = new BooleanPropertyBase(true) {
            @Override
            protected void invalidated() {
                if (NumberAxis.this.isAutoRanging()) {
                    NumberAxis.this.requestAxisLayout();
                    NumberAxis.this.invalidateRange();
                }
            }
            
            @Override
            public Object getBean() {
                return NumberAxis.this;
            }
            
            @Override
            public String getName() {
                return "forceZeroInRange";
            }
        };
        this.tickUnit = new StyleableDoubleProperty(5.0) {
            @Override
            protected void invalidated() {
                if (!NumberAxis.this.isAutoRanging()) {
                    NumberAxis.this.invalidateRange();
                    NumberAxis.this.requestAxisLayout();
                }
            }
            
            @Override
            public CssMetaData<NumberAxis, Number> getCssMetaData() {
                return StyleableProperties.TICK_UNIT;
            }
            
            @Override
            public Object getBean() {
                return NumberAxis.this;
            }
            
            @Override
            public String getName() {
                return "tickUnit";
            }
        };
    }
    
    public NumberAxis(final double n, final double n2, final double tickUnit) {
        super(n, n2);
        this.animator = new ChartLayoutAnimator(this);
        this.currentFormatterProperty = new SimpleStringProperty(this, "currentFormatter", "");
        this.defaultFormatter = new DefaultFormatter(this);
        this.forceZeroInRange = new BooleanPropertyBase(true) {
            @Override
            protected void invalidated() {
                if (NumberAxis.this.isAutoRanging()) {
                    NumberAxis.this.requestAxisLayout();
                    NumberAxis.this.invalidateRange();
                }
            }
            
            @Override
            public Object getBean() {
                return NumberAxis.this;
            }
            
            @Override
            public String getName() {
                return "forceZeroInRange";
            }
        };
        this.tickUnit = new StyleableDoubleProperty(5.0) {
            @Override
            protected void invalidated() {
                if (!NumberAxis.this.isAutoRanging()) {
                    NumberAxis.this.invalidateRange();
                    NumberAxis.this.requestAxisLayout();
                }
            }
            
            @Override
            public CssMetaData<NumberAxis, Number> getCssMetaData() {
                return StyleableProperties.TICK_UNIT;
            }
            
            @Override
            public Object getBean() {
                return NumberAxis.this;
            }
            
            @Override
            public String getName() {
                return "tickUnit";
            }
        };
        this.setTickUnit(tickUnit);
    }
    
    public NumberAxis(final String label, final double n, final double n2, final double tickUnit) {
        super(n, n2);
        this.animator = new ChartLayoutAnimator(this);
        this.currentFormatterProperty = new SimpleStringProperty(this, "currentFormatter", "");
        this.defaultFormatter = new DefaultFormatter(this);
        this.forceZeroInRange = new BooleanPropertyBase(true) {
            @Override
            protected void invalidated() {
                if (NumberAxis.this.isAutoRanging()) {
                    NumberAxis.this.requestAxisLayout();
                    NumberAxis.this.invalidateRange();
                }
            }
            
            @Override
            public Object getBean() {
                return NumberAxis.this;
            }
            
            @Override
            public String getName() {
                return "forceZeroInRange";
            }
        };
        this.tickUnit = new StyleableDoubleProperty(5.0) {
            @Override
            protected void invalidated() {
                if (!NumberAxis.this.isAutoRanging()) {
                    NumberAxis.this.invalidateRange();
                    NumberAxis.this.requestAxisLayout();
                }
            }
            
            @Override
            public CssMetaData<NumberAxis, Number> getCssMetaData() {
                return StyleableProperties.TICK_UNIT;
            }
            
            @Override
            public Object getBean() {
                return NumberAxis.this;
            }
            
            @Override
            public String getName() {
                return "tickUnit";
            }
        };
        this.setTickUnit(tickUnit);
        this.setLabel(label);
    }
    
    @Override
    protected String getTickMarkLabel(final Number n) {
        StringConverter<Number> stringConverter = this.getTickLabelFormatter();
        if (stringConverter == null) {
            stringConverter = this.defaultFormatter;
        }
        return stringConverter.toString(n);
    }
    
    @Override
    protected Object getRange() {
        return new Object[] { this.getLowerBound(), this.getUpperBound(), this.getTickUnit(), this.getScale(), ((ObservableObjectValue<Object>)this.currentFormatterProperty).get() };
    }
    
    @Override
    protected void setRange(final Object o, final boolean b) {
        final Object[] array = (Object[])o;
        final double doubleValue = (double)array[0];
        final double doubleValue2 = (double)array[1];
        final double doubleValue3 = (double)array[2];
        final double doubleValue4 = (double)array[3];
        this.currentFormatterProperty.set((String)array[4]);
        final double lowerBound = this.getLowerBound();
        this.setLowerBound(doubleValue);
        this.setUpperBound(doubleValue2);
        this.setTickUnit(doubleValue3);
        if (b) {
            this.animator.stop(this.currentAnimationID);
            this.currentAnimationID = this.animator.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)this.currentLowerBound, (T)lowerBound), new KeyValue((WritableValue<T>)this.scalePropertyImpl(), (T)this.getScale()) }), new KeyFrame(Duration.millis(700.0), new KeyValue[] { new KeyValue((WritableValue<T>)this.currentLowerBound, (T)doubleValue), new KeyValue((WritableValue<T>)this.scalePropertyImpl(), (T)doubleValue4) }));
        }
        else {
            this.currentLowerBound.set(doubleValue);
            this.setScale(doubleValue4);
        }
    }
    
    @Override
    protected List<Number> calculateTickValues(final double n, final Object o) {
        final Object[] array = (Object[])o;
        final double doubleValue = (double)array[0];
        final double doubleValue2 = (double)array[1];
        final double doubleValue3 = (double)array[2];
        final ArrayList<Double> list = new ArrayList<Double>();
        if (doubleValue == doubleValue2) {
            list.add(doubleValue);
        }
        else if (doubleValue3 <= 0.0) {
            list.add(doubleValue);
            list.add(doubleValue2);
        }
        else if (doubleValue3 > 0.0) {
            list.add(doubleValue);
            if ((doubleValue2 - doubleValue) / doubleValue3 > 2000.0) {
                System.err.println(invokedynamic(makeConcatWithConstants:(DDD)Ljava/lang/String;, doubleValue, doubleValue2, doubleValue3));
            }
            else if (doubleValue + doubleValue3 < doubleValue2) {
                double n2 = (Math.rint(doubleValue3) == doubleValue3) ? Math.ceil(doubleValue) : (doubleValue + doubleValue3);
                for (int n3 = (int)Math.ceil((doubleValue2 - n2) / doubleValue3), n4 = 0; n2 < doubleValue2 && n4 < n3; n2 += doubleValue3, ++n4) {
                    if (!list.contains(n2)) {
                        list.add(n2);
                    }
                }
            }
            list.add(doubleValue2);
        }
        return (List<Number>)list;
    }
    
    @Override
    protected List<Number> calculateMinorTickMarks() {
        final ArrayList<Double> list = new ArrayList<Double>();
        final double lowerBound = this.getLowerBound();
        final double upperBound = this.getUpperBound();
        final double tickUnit = this.getTickUnit();
        final double n = tickUnit / Math.max(1, this.getMinorTickCount());
        if (tickUnit > 0.0) {
            if ((upperBound - lowerBound) / n > 10000.0) {
                System.err.println(invokedynamic(makeConcatWithConstants:(DDD)Ljava/lang/String;, this.getLowerBound(), this.getUpperBound(), tickUnit));
                return (List<Number>)list;
            }
            final boolean b = Math.rint(tickUnit) == tickUnit;
            if (b) {
                double d = Math.floor(lowerBound) + n;
                for (int n2 = (int)Math.ceil((Math.ceil(lowerBound) - d) / n), n3 = 0; d < Math.ceil(lowerBound) && n3 < n2; d += n, ++n3) {
                    if (d > lowerBound) {
                        list.add(d);
                    }
                }
            }
            double n4 = b ? Math.ceil(lowerBound) : lowerBound;
            for (int n5 = (int)Math.ceil((upperBound - n4) / tickUnit), n6 = 0; n4 < upperBound && n6 < n5; n4 += tickUnit, ++n6) {
                final double min = Math.min(n4 + tickUnit, upperBound);
                double d2 = n4 + n;
                for (int n7 = (int)Math.ceil((min - d2) / n), n8 = 0; d2 < min && n8 < n7; d2 += n, ++n8) {
                    list.add(d2);
                }
            }
        }
        return (List<Number>)list;
    }
    
    @Override
    protected Dimension2D measureTickMarkSize(final Number n, final Object o) {
        return this.measureTickMarkSize(n, this.getTickLabelRotation(), (String)((Object[])o)[4]);
    }
    
    private Dimension2D measureTickMarkSize(final Number n, final double n2, final String s) {
        StringConverter<Number> stringConverter = this.getTickLabelFormatter();
        if (stringConverter == null) {
            stringConverter = this.defaultFormatter;
        }
        String s2;
        if (stringConverter instanceof DefaultFormatter) {
            s2 = ((DefaultFormatter)stringConverter).toString(n, s);
        }
        else {
            s2 = stringConverter.toString(n);
        }
        return this.measureTickMarkLabelSize(s2, n2);
    }
    
    @Override
    protected Object autoRange(double n, double n2, final double n3, final double n4) {
        final Side effectiveSide = this.getEffectiveSide();
        if (this.isForceZeroInRange()) {
            if (n2 < 0.0) {
                n2 = 0.0;
            }
            else if (n > 0.0) {
                n = 0.0;
            }
        }
        final int max = Math.max((int)Math.floor(n3 / n4), 2);
        final int max2 = Math.max(this.getMinorTickCount(), 1);
        double a = n2 - n;
        if (a != 0.0 && a / (max * max2) <= Math.ulp(n)) {
            a = 0.0;
        }
        final double n5 = (a == 0.0) ? ((n == 0.0) ? 2.0 : (Math.abs(n) * 0.02)) : (Math.abs(a) * 1.02);
        final double n6 = (n5 - a) / 2.0;
        double n7 = n - n6;
        double n8 = n2 + n6;
        if ((n7 < 0.0 && n >= 0.0) || (n7 > 0.0 && n <= 0.0)) {
            n7 = 0.0;
        }
        if ((n8 < 0.0 && n2 >= 0.0) || (n8 > 0.0 && n2 <= 0.0)) {
            n8 = 0.0;
        }
        double a2 = n5 / max;
        double d = 0.0;
        double d2 = 0.0;
        double d3 = 0.0;
        int n9 = 0;
        double n10 = Double.MAX_VALUE;
        String string = "0.00000000";
        while (n10 > n3 || n9 > 20) {
            int n11 = (int)Math.floor(Math.log10(a2));
            double a3;
            final double n12 = a3 = a2 / Math.pow(10.0, n11);
            if (n12 > 5.0) {
                ++n11;
                a3 = 1.0;
            }
            else if (n12 > 1.0) {
                a3 = ((n12 > 2.5) ? 5.0 : 2.5);
            }
            if (n11 > 1) {
                string = "#,##0";
            }
            else if (n11 == 1) {
                string = "0";
            }
            else {
                final boolean b = Math.rint(a3) != a3;
                final StringBuilder sb = new StringBuilder("0");
                final int n13 = b ? (Math.abs(n11) + 1) : Math.abs(n11);
                if (n13 > 0) {
                    sb.append(".");
                }
                for (int i = 0; i < n13; ++i) {
                    sb.append("0");
                }
                string = sb.toString();
            }
            d = a3 * Math.pow(10.0, n11);
            d2 = Math.floor(n7 / d) * d;
            d3 = Math.ceil(n8 / d) * d;
            double max3 = 0.0;
            double n14 = 0.0;
            n9 = (int)Math.ceil((d3 - d2) / d);
            double d4 = d2;
            for (int n15 = 0; d4 <= d3 && n15 < n9; d4 += d, ++n15) {
                final Dimension2D measureTickMarkSize = this.measureTickMarkSize(d4, this.getTickLabelRotation(), string);
                final double n16 = effectiveSide.isVertical() ? measureTickMarkSize.getHeight() : measureTickMarkSize.getWidth();
                if (n15 == 0) {
                    n14 = n16 / 2.0;
                }
                else {
                    max3 = Math.max(max3, n14 + 6.0 + n16 / 2.0);
                }
            }
            n10 = (n9 - 1) * max3;
            a2 = d;
            if (max == 2 && n10 > n3) {
                break;
            }
            if (n10 <= n3 && n9 <= 20) {
                continue;
            }
            a2 *= 2.0;
        }
        return new Object[] { d2, d3, d, this.calculateNewScale(n3, d2, d3), string };
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<NumberAxis, Number> TICK_UNIT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            TICK_UNIT = new CssMetaData<NumberAxis, Number>((StyleConverter)SizeConverter.getInstance(), (Number)5.0) {
                @Override
                public boolean isSettable(final NumberAxis numberAxis) {
                    return numberAxis.tickUnit == null || !numberAxis.tickUnit.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final NumberAxis numberAxis) {
                    return (StyleableProperty<Number>)numberAxis.tickUnitProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(ValueAxis.getClassCssMetaData());
            list.add(StyleableProperties.TICK_UNIT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    public static class DefaultFormatter extends StringConverter<Number>
    {
        private DecimalFormat formatter;
        private String prefix;
        private String suffix;
        
        public DefaultFormatter(final NumberAxis numberAxis) {
            this.prefix = null;
            this.suffix = null;
            this.formatter = (numberAxis.isAutoRanging() ? new DecimalFormat(numberAxis.currentFormatterProperty.get()) : new DecimalFormat());
            final DecimalFormat formatter;
            final ChangeListener<? super Boolean> changeListener = (p1, p2, p3) -> {
                if (numberAxis.isAutoRanging()) {
                    // new(java.text.DecimalFormat.class)
                    new DecimalFormat(numberAxis.currentFormatterProperty.get());
                }
                else {
                    // new(java.text.DecimalFormat.class)
                    new DecimalFormat();
                }
                this.formatter = formatter;
                return;
            };
            numberAxis.currentFormatterProperty.addListener((ChangeListener<? super String>)changeListener);
            numberAxis.autoRangingProperty().addListener(changeListener);
        }
        
        public DefaultFormatter(final NumberAxis numberAxis, final String prefix, final String suffix) {
            this(numberAxis);
            this.prefix = prefix;
            this.suffix = suffix;
        }
        
        @Override
        public String toString(final Number n) {
            return this.toString(n, this.formatter);
        }
        
        private String toString(final Number n, final String pattern) {
            if (pattern == null || pattern.isEmpty()) {
                return this.toString(n, this.formatter);
            }
            return this.toString(n, new DecimalFormat(pattern));
        }
        
        private String toString(final Number n, final DecimalFormat decimalFormat) {
            if (this.prefix != null && this.suffix != null) {
                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, this.prefix, decimalFormat.format(n), this.suffix);
            }
            if (this.prefix != null) {
                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, this.prefix, decimalFormat.format(n));
            }
            if (this.suffix != null) {
                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, decimalFormat.format(n), this.suffix);
            }
            return decimalFormat.format(n);
        }
        
        @Override
        public Number fromString(final String s) {
            try {
                return this.formatter.parse(s.substring((this.prefix == null) ? 0 : this.prefix.length(), s.length() - ((this.suffix == null) ? 0 : this.suffix.length())));
            }
            catch (ParseException ex) {
                return null;
            }
        }
    }
}
