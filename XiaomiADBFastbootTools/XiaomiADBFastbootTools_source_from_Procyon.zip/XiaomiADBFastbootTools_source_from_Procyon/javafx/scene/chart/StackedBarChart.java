// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import java.util.Collections;
import java.util.Collection;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.event.ActionEvent;
import javafx.css.Styleable;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import javafx.scene.AccessibleRole;
import javafx.scene.layout.StackPane;
import javafx.animation.Interpolator;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.animation.KeyFrame;
import com.sun.javafx.charts.Legend;
import java.util.Iterator;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import javafx.animation.ParallelTransition;
import javafx.animation.Timeline;
import javafx.scene.Node;
import java.util.ArrayList;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import java.util.HashMap;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.beans.NamedArg;
import javafx.css.PseudoClass;
import javafx.beans.property.DoubleProperty;
import javafx.collections.ListChangeListener;
import javafx.geometry.Orientation;
import java.util.List;
import java.util.Map;

public class StackedBarChart<X, Y> extends XYChart<X, Y>
{
    private Map<Series<X, Y>, Map<String, List<Data<X, Y>>>> seriesCategoryMap;
    private final Orientation orientation;
    private CategoryAxis categoryAxis;
    private ValueAxis valueAxis;
    private ListChangeListener<String> categoriesListener;
    private DoubleProperty categoryGap;
    private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE;
    private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE;
    
    public double getCategoryGap() {
        return this.categoryGap.getValue();
    }
    
    public void setCategoryGap(final double d) {
        this.categoryGap.setValue(d);
    }
    
    public DoubleProperty categoryGapProperty() {
        return this.categoryGap;
    }
    
    public StackedBarChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2) {
        this(axis, axis2, FXCollections.observableArrayList());
    }
    
    public StackedBarChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2, @NamedArg("data") final ObservableList<Series<X, Y>> data) {
        super(axis, axis2);
        this.seriesCategoryMap = new HashMap<Series<X, Y>, Map<String, List<Data<X, Y>>>>();
        this.categoriesListener = new ListChangeListener<String>() {
            @Override
            public void onChanged(final Change<? extends String> p0) {
                // 
                // This method could not be decompiled.
                // 
                // Original Bytecode:
                // 
                //     1: invokevirtual   javafx/collections/ListChangeListener$Change.next:()Z
                //     4: ifeq            203
                //     7: aload_1        
                //     8: invokevirtual   javafx/collections/ListChangeListener$Change.getRemoved:()Ljava/util/List;
                //    11: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
                //    16: astore_2       
                //    17: aload_2        
                //    18: invokeinterface java/util/Iterator.hasNext:()Z
                //    23: ifeq            200
                //    26: aload_2        
                //    27: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
                //    32: checkcast       Ljava/lang/String;
                //    35: astore_3       
                //    36: aload_0        
                //    37: getfield        javafx/scene/chart/StackedBarChart$1.this$0:Ljavafx/scene/chart/StackedBarChart;
                //    40: invokevirtual   javafx/scene/chart/StackedBarChart.getData:()Ljavafx/collections/ObservableList;
                //    43: invokeinterface javafx/collections/ObservableList.iterator:()Ljava/util/Iterator;
                //    48: astore          4
                //    50: aload           4
                //    52: invokeinterface java/util/Iterator.hasNext:()Z
                //    57: ifeq            190
                //    60: aload           4
                //    62: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
                //    67: checkcast       Ljavafx/scene/chart/XYChart$Series;
                //    70: astore          5
                //    72: aload           5
                //    74: invokevirtual   javafx/scene/chart/XYChart$Series.getData:()Ljavafx/collections/ObservableList;
                //    77: invokeinterface javafx/collections/ObservableList.iterator:()Ljava/util/Iterator;
                //    82: astore          6
                //    84: aload           6
                //    86: invokeinterface java/util/Iterator.hasNext:()Z
                //    91: ifeq            187
                //    94: aload           6
                //    96: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
                //   101: checkcast       Ljavafx/scene/chart/XYChart$Data;
                //   104: astore          7
                //   106: aload_3        
                //   107: aload_0        
                //   108: getfield        javafx/scene/chart/StackedBarChart$1.this$0:Ljavafx/scene/chart/StackedBarChart;
                //   111: invokestatic    javafx/scene/chart/StackedBarChart.access$000:(Ljavafx/scene/chart/StackedBarChart;)Ljavafx/geometry/Orientation;
                //   114: aload_0        
                //   115: getfield        javafx/scene/chart/StackedBarChart$1.this$0:Ljavafx/scene/chart/StackedBarChart;
                //   118: invokestatic    javafx/scene/chart/StackedBarChart.access$000:(Ljavafx/scene/chart/StackedBarChart;)Ljavafx/geometry/Orientation;
                //   121: pop            
                //   122: getstatic       javafx/geometry/Orientation.VERTICAL:Ljavafx/geometry/Orientation;
                //   125: if_acmpne       136
                //   128: aload           7
                //   130: invokevirtual   javafx/scene/chart/XYChart$Data.getXValue:()Ljava/lang/Object;
                //   133: goto            141
                //   136: aload           7
                //   138: invokevirtual   javafx/scene/chart/XYChart$Data.getYValue:()Ljava/lang/Object;
                //   141: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
                //   144: ifeq            184
                //   147: aload_0        
                //   148: getfield        javafx/scene/chart/StackedBarChart$1.this$0:Ljavafx/scene/chart/StackedBarChart;
                //   151: invokevirtual   javafx/scene/chart/StackedBarChart.getAnimated:()Z
                //   154: istore          8
                //   156: aload_0        
                //   157: getfield        javafx/scene/chart/StackedBarChart$1.this$0:Ljavafx/scene/chart/StackedBarChart;
                //   160: iconst_0       
                //   161: invokevirtual   javafx/scene/chart/StackedBarChart.setAnimated:(Z)V
                //   164: aload_0        
                //   165: getfield        javafx/scene/chart/StackedBarChart$1.this$0:Ljavafx/scene/chart/StackedBarChart;
                //   168: aload           7
                //   170: aload           5
                //   172: invokevirtual   javafx/scene/chart/StackedBarChart.dataItemRemoved:(Ljavafx/scene/chart/XYChart$Data;Ljavafx/scene/chart/XYChart$Series;)V
                //   175: aload_0        
                //   176: getfield        javafx/scene/chart/StackedBarChart$1.this$0:Ljavafx/scene/chart/StackedBarChart;
                //   179: iload           8
                //   181: invokevirtual   javafx/scene/chart/StackedBarChart.setAnimated:(Z)V
                //   184: goto            84
                //   187: goto            50
                //   190: aload_0        
                //   191: getfield        javafx/scene/chart/StackedBarChart$1.this$0:Ljavafx/scene/chart/StackedBarChart;
                //   194: invokevirtual   javafx/scene/chart/StackedBarChart.requestChartLayout:()V
                //   197: goto            17
                //   200: goto            0
                //   203: return         
                //    Signature:
                //  (Ljavafx/collections/ListChangeListener$Change<+Ljava/lang/String;>;)V
                //    StackMapTable: 00 0B 00 FC 00 10 07 00 26 FD 00 20 07 00 08 07 00 26 FD 00 21 07 00 0B 07 00 26 FF 00 33 00 08 07 00 17 07 00 21 07 00 26 07 00 08 07 00 26 07 00 0B 07 00 26 07 00 0D 00 01 07 00 08 FF 00 04 00 08 07 00 17 07 00 21 07 00 26 07 00 08 07 00 26 07 00 0B 07 00 26 07 00 0D 00 02 07 00 08 07 00 18 FA 00 2A F9 00 02 FA 00 02 F9 00 09 02
                // 
                // The error that occurred was:
                // 
                // com.strobel.assembler.metadata.MetadataHelper$AdaptFailure
                //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.visitGenericParameter(MetadataHelper.java:2300)
                //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.visitGenericParameter(MetadataHelper.java:2221)
                //     at com.strobel.assembler.metadata.GenericParameter.accept(GenericParameter.java:85)
                //     at com.strobel.assembler.metadata.DefaultTypeVisitor.visit(DefaultTypeVisitor.java:25)
                //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.adaptRecursive(MetadataHelper.java:2255)
                //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.adaptRecursive(MetadataHelper.java:2232)
                //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.visitParameterizedType(MetadataHelper.java:2245)
                //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.visitParameterizedType(MetadataHelper.java:2221)
                //     at com.strobel.assembler.metadata.ParameterizedType.accept(ParameterizedType.java:103)
                //     at com.strobel.assembler.metadata.DefaultTypeVisitor.visit(DefaultTypeVisitor.java:25)
                //     at com.strobel.assembler.metadata.MetadataHelper.adapt(MetadataHelper.java:1312)
                //     at com.strobel.assembler.metadata.MetadataHelper.substituteGenericArguments(MetadataHelper.java:1010)
                //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:976)
                //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
                //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:778)
                //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2669)
                //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
                //     at com.strobel.decompiler.ast.TypeAnalysis.inferBinaryArguments(TypeAnalysis.java:2834)
                //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:851)
                //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
                //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
                //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
                //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
                //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
                //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypesForVariables(TypeAnalysis.java:586)
                //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:397)
                //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
                //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
                //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformCall(AstMethodBodyBuilder.java:1164)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:1009)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:294)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
        };
        this.categoryGap = new StyleableDoubleProperty(10.0) {
            @Override
            protected void invalidated() {
                this.get();
                StackedBarChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return StackedBarChart.this;
            }
            
            @Override
            public String getName() {
                return "categoryGap";
            }
            
            @Override
            public CssMetaData<StackedBarChart<?, ?>, Number> getCssMetaData() {
                return StyleableProperties.CATEGORY_GAP;
            }
        };
        this.getStyleClass().add("stacked-bar-chart");
        if ((!(axis instanceof ValueAxis) || !(axis2 instanceof CategoryAxis)) && (!(axis2 instanceof ValueAxis) || !(axis instanceof CategoryAxis))) {
            throw new IllegalArgumentException("Axis type incorrect, one of X,Y should be CategoryAxis and the other NumberAxis");
        }
        if (axis instanceof CategoryAxis) {
            this.categoryAxis = (CategoryAxis)axis;
            this.valueAxis = (ValueAxis)axis2;
            this.orientation = Orientation.VERTICAL;
        }
        else {
            this.categoryAxis = (CategoryAxis)axis2;
            this.valueAxis = (ValueAxis)axis;
            this.orientation = Orientation.HORIZONTAL;
        }
        this.pseudoClassStateChanged(StackedBarChart.HORIZONTAL_PSEUDOCLASS_STATE, this.orientation == Orientation.HORIZONTAL);
        this.pseudoClassStateChanged(StackedBarChart.VERTICAL_PSEUDOCLASS_STATE, this.orientation == Orientation.VERTICAL);
        this.setData(data);
        this.categoryAxis.getCategories().addListener(this.categoriesListener);
    }
    
    public StackedBarChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2, @NamedArg("data") final ObservableList<Series<X, Y>> data, @NamedArg("categoryGap") final double categoryGap) {
        this(axis, axis2);
        this.setData(data);
        this.setCategoryGap(categoryGap);
    }
    
    @Override
    protected void dataItemAdded(final Series<X, Y> series, final int n, final Data<X, Y> data) {
        String s;
        if (this.orientation == Orientation.VERTICAL) {
            s = (String)data.getXValue();
        }
        else {
            s = (String)data.getYValue();
        }
        Map<String, List<Data<X, Y>>> map = this.seriesCategoryMap.get(series);
        if (map == null) {
            map = new HashMap<String, List<Data<X, Y>>>();
            this.seriesCategoryMap.put(series, map);
        }
        final List<Data<X, Y>> list = (map.get(s) != null) ? map.get(s) : new ArrayList<Data<X, Y>>();
        list.add(data);
        map.put(s, list);
        final Node bar = this.createBar(series, this.getData().indexOf(series), data, n);
        if (this.shouldAnimate()) {
            this.animateDataAdd(data, bar);
        }
        else {
            this.getPlotChildren().add(bar);
        }
    }
    
    @Override
    protected void dataItemRemoved(final Data<X, Y> data, final Series<X, Y> series) {
        final Node node = data.getNode();
        if (node != null) {
            node.focusTraversableProperty().unbind();
        }
        if (this.shouldAnimate()) {
            final Timeline dataRemoveTimeline = this.createDataRemoveTimeline(data, node, series);
            dataRemoveTimeline.setOnFinished(p2 -> this.removeDataItemFromDisplay(series, data));
            dataRemoveTimeline.play();
        }
        else {
            this.processDataRemove(series, data);
            this.removeDataItemFromDisplay(series, data);
        }
    }
    
    @Override
    protected void dataItemChanged(final Data<X, Y> data) {
        double n;
        double n2;
        if (this.orientation == Orientation.VERTICAL) {
            n = ((Number)data.getYValue()).doubleValue();
            n2 = this.getCurrentDisplayedYValue((Data<X, Number>)data).doubleValue();
        }
        else {
            n = data.getXValue().doubleValue();
            n2 = this.getCurrentDisplayedXValue((Data<Number, Y>)data).doubleValue();
        }
        if (n2 > 0.0 && n < 0.0) {
            data.getNode().getStyleClass().add("negative");
        }
        else if (n2 < 0.0 && n > 0.0) {
            data.getNode().getStyleClass().remove("negative");
        }
    }
    
    @Override
    protected void seriesChanged(final ListChangeListener.Change<? extends Series> change) {
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Series series = this.getData().get(i);
            for (int j = 0; j < series.getData().size(); ++j) {
                ((Data)series.getData().get(j)).getNode().getStyleClass().setAll(new String[] { "chart-bar", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, j), series.defaultColorStyleClass });
            }
        }
    }
    
    @Override
    protected void seriesAdded(final Series<X, Y> series, final int n) {
        final HashMap<Object, List<Data<X, Y>>> hashMap = new HashMap<Object, List<Data<X, Y>>>();
        for (int i = 0; i < series.getData().size(); ++i) {
            final Data<X, Y> data = series.getData().get(i);
            final Node bar = this.createBar(series, n, data, i);
            String s;
            if (this.orientation == Orientation.VERTICAL) {
                s = (String)data.getXValue();
            }
            else {
                s = (String)data.getYValue();
            }
            final List<Data<X, Y>> list = (hashMap.get(s) != null) ? hashMap.get(s) : new ArrayList<Data<X, Y>>();
            list.add(data);
            hashMap.put(s, list);
            if (this.shouldAnimate()) {
                this.animateDataAdd(data, bar);
            }
            else {
                if (((this.orientation == Orientation.VERTICAL) ? ((Number)data.getYValue()).doubleValue() : ((Number)data.getXValue()).doubleValue()) < 0.0) {
                    bar.getStyleClass().add("negative");
                }
                this.getPlotChildren().add(bar);
            }
        }
        if (hashMap.size() > 0) {
            this.seriesCategoryMap.put(series, (Map<String, List<Data<X, Y>>>)hashMap);
        }
    }
    
    @Override
    protected void seriesRemoved(final Series<X, Y> series) {
        if (this.shouldAnimate()) {
            final ParallelTransition parallelTransition = new ParallelTransition();
            parallelTransition.setOnFinished(p1 -> {
                this.removeSeriesFromDisplay(series);
                this.requestChartLayout();
                return;
            });
            for (final Data<X, Y> data : series.getData()) {
                final Node node = data.getNode();
                if (this.getSeriesSize() > 1) {
                    parallelTransition.getChildren().add(this.createDataRemoveTimeline(data, node, series));
                }
                else {
                    final FadeTransition fadeTransition = new FadeTransition(Duration.millis(700.0), node);
                    fadeTransition.setFromValue(1.0);
                    fadeTransition.setToValue(0.0);
                    final Data<X, Y> data2;
                    final Node node2;
                    fadeTransition.setOnFinished(p3 -> {
                        this.processDataRemove(series, data2);
                        node2.setOpacity(1.0);
                        return;
                    });
                    parallelTransition.getChildren().add(fadeTransition);
                }
            }
            parallelTransition.play();
        }
        else {
            final Iterator<Data<X, Y>> iterator2 = series.getData().iterator();
            while (iterator2.hasNext()) {
                this.processDataRemove(series, iterator2.next());
            }
            this.removeSeriesFromDisplay(series);
            this.requestChartLayout();
        }
    }
    
    @Override
    protected void updateAxisRange() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        javafx/scene/chart/StackedBarChart.categoryAxis:Ljavafx/scene/chart/CategoryAxis;
        //     4: aload_0        
        //     5: invokevirtual   javafx/scene/chart/StackedBarChart.getXAxis:()Ljavafx/scene/chart/Axis;
        //     8: if_acmpne       15
        //    11: iconst_1       
        //    12: goto            16
        //    15: iconst_0       
        //    16: istore_1       
        //    17: aload_0        
        //    18: getfield        javafx/scene/chart/StackedBarChart.categoryAxis:Ljavafx/scene/chart/CategoryAxis;
        //    21: invokevirtual   javafx/scene/chart/CategoryAxis.isAutoRanging:()Z
        //    24: ifeq            142
        //    27: new             Ljava/util/ArrayList;
        //    30: dup            
        //    31: invokespecial   java/util/ArrayList.<init>:()V
        //    34: astore_2       
        //    35: aload_0        
        //    36: invokevirtual   javafx/scene/chart/StackedBarChart.getData:()Ljavafx/collections/ObservableList;
        //    39: invokeinterface javafx/collections/ObservableList.iterator:()Ljava/util/Iterator;
        //    44: astore_3       
        //    45: aload_3        
        //    46: invokeinterface java/util/Iterator.hasNext:()Z
        //    51: ifeq            134
        //    54: aload_3        
        //    55: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    60: checkcast       Ljavafx/scene/chart/XYChart$Series;
        //    63: astore          4
        //    65: aload           4
        //    67: invokevirtual   javafx/scene/chart/XYChart$Series.getData:()Ljavafx/collections/ObservableList;
        //    70: invokeinterface javafx/collections/ObservableList.iterator:()Ljava/util/Iterator;
        //    75: astore          5
        //    77: aload           5
        //    79: invokeinterface java/util/Iterator.hasNext:()Z
        //    84: ifeq            131
        //    87: aload           5
        //    89: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //    94: checkcast       Ljavafx/scene/chart/XYChart$Data;
        //    97: astore          6
        //    99: aload           6
        //   101: ifnull          128
        //   104: aload_2        
        //   105: iload_1        
        //   106: ifeq            117
        //   109: aload           6
        //   111: invokevirtual   javafx/scene/chart/XYChart$Data.getXValue:()Ljava/lang/Object;
        //   114: goto            122
        //   117: aload           6
        //   119: invokevirtual   javafx/scene/chart/XYChart$Data.getYValue:()Ljava/lang/Object;
        //   122: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   127: pop            
        //   128: goto            77
        //   131: goto            45
        //   134: aload_0        
        //   135: getfield        javafx/scene/chart/StackedBarChart.categoryAxis:Ljavafx/scene/chart/CategoryAxis;
        //   138: aload_2        
        //   139: invokevirtual   javafx/scene/chart/CategoryAxis.invalidateRange:(Ljava/util/List;)V
        //   142: aload_0        
        //   143: getfield        javafx/scene/chart/StackedBarChart.valueAxis:Ljavafx/scene/chart/ValueAxis;
        //   146: invokevirtual   javafx/scene/chart/ValueAxis.isAutoRanging:()Z
        //   149: ifeq            385
        //   152: new             Ljava/util/ArrayList;
        //   155: dup            
        //   156: invokespecial   java/util/ArrayList.<init>:()V
        //   159: astore_2       
        //   160: aload_0        
        //   161: getfield        javafx/scene/chart/StackedBarChart.categoryAxis:Ljavafx/scene/chart/CategoryAxis;
        //   164: invokevirtual   javafx/scene/chart/CategoryAxis.getAllDataCategories:()Ljava/util/List;
        //   167: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //   172: astore_3       
        //   173: aload_3        
        //   174: invokeinterface java/util/Iterator.hasNext:()Z
        //   179: ifeq            377
        //   182: aload_3        
        //   183: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   188: checkcast       Ljava/lang/String;
        //   191: astore          4
        //   193: dconst_0       
        //   194: dstore          5
        //   196: dconst_0       
        //   197: dstore          7
        //   199: aload_0        
        //   200: invokevirtual   javafx/scene/chart/StackedBarChart.getDisplayedSeriesIterator:()Ljava/util/Iterator;
        //   203: astore          9
        //   205: aload           9
        //   207: invokeinterface java/util/Iterator.hasNext:()Z
        //   212: ifeq            350
        //   215: aload           9
        //   217: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   222: checkcast       Ljavafx/scene/chart/XYChart$Series;
        //   225: astore          10
        //   227: aload_0        
        //   228: aload           10
        //   230: aload           4
        //   232: invokespecial   javafx/scene/chart/StackedBarChart.getDataItem:(Ljavafx/scene/chart/XYChart$Series;Ljava/lang/String;)Ljava/util/List;
        //   235: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //   240: astore          11
        //   242: aload           11
        //   244: invokeinterface java/util/Iterator.hasNext:()Z
        //   249: ifeq            347
        //   252: aload           11
        //   254: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   259: checkcast       Ljavafx/scene/chart/XYChart$Data;
        //   262: astore          12
        //   264: aload           12
        //   266: ifnull          344
        //   269: aload           12
        //   271: invokevirtual   javafx/scene/chart/XYChart$Data.getNode:()Ljavafx/scene/Node;
        //   274: invokevirtual   javafx/scene/Node.getStyleClass:()Ljavafx/collections/ObservableList;
        //   277: ldc             "negative"
        //   279: invokeinterface javafx/collections/ObservableList.contains:(Ljava/lang/Object;)Z
        //   284: istore          13
        //   286: iload_1        
        //   287: ifeq            298
        //   290: aload           12
        //   292: invokevirtual   javafx/scene/chart/XYChart$Data.getYValue:()Ljava/lang/Object;
        //   295: goto            303
        //   298: aload           12
        //   300: invokevirtual   javafx/scene/chart/XYChart$Data.getXValue:()Ljava/lang/Object;
        //   303: checkcast       Ljava/lang/Number;
        //   306: astore          14
        //   308: iload           13
        //   310: ifne            330
        //   313: dload           7
        //   315: aload_0        
        //   316: getfield        javafx/scene/chart/StackedBarChart.valueAxis:Ljavafx/scene/chart/ValueAxis;
        //   319: aload           14
        //   321: invokevirtual   javafx/scene/chart/ValueAxis.toNumericValue:(Ljava/lang/Number;)D
        //   324: dadd           
        //   325: dstore          7
        //   327: goto            344
        //   330: dload           5
        //   332: aload_0        
        //   333: getfield        javafx/scene/chart/StackedBarChart.valueAxis:Ljavafx/scene/chart/ValueAxis;
        //   336: aload           14
        //   338: invokevirtual   javafx/scene/chart/ValueAxis.toNumericValue:(Ljava/lang/Number;)D
        //   341: dadd           
        //   342: dstore          5
        //   344: goto            242
        //   347: goto            205
        //   350: aload_2        
        //   351: dload           7
        //   353: invokestatic    java/lang/Double.valueOf:(D)Ljava/lang/Double;
        //   356: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   361: pop            
        //   362: aload_2        
        //   363: dload           5
        //   365: invokestatic    java/lang/Double.valueOf:(D)Ljava/lang/Double;
        //   368: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   373: pop            
        //   374: goto            173
        //   377: aload_0        
        //   378: getfield        javafx/scene/chart/StackedBarChart.valueAxis:Ljavafx/scene/chart/ValueAxis;
        //   381: aload_2        
        //   382: invokevirtual   javafx/scene/chart/ValueAxis.invalidateRange:(Ljava/util/List;)V
        //   385: return         
        //    StackMapTable: 00 15 0F 40 01 FE 00 1C 01 07 00 2E 07 00 F2 FD 00 1F 07 00 4A 07 00 F2 FF 00 27 00 07 07 00 AC 01 07 00 2E 07 00 F2 07 00 4A 07 00 F2 07 00 4D 00 01 07 00 2E FF 00 04 00 07 07 00 AC 01 07 00 2E 07 00 F2 07 00 4A 07 00 F2 07 00 4D 00 02 07 00 2E 07 00 F6 FA 00 05 F9 00 02 FA 00 02 FA 00 07 FD 00 1E 07 00 2E 07 00 F2 FF 00 1F 00 08 07 00 AC 01 07 00 2E 07 00 F2 07 00 29 03 03 07 00 F2 00 00 FD 00 24 07 00 4A 07 00 F2 FD 00 37 07 00 4D 01 44 07 00 F6 FC 00 1A 07 00 41 F8 00 0D F9 00 02 02 FF 00 1A 00 03 07 00 AC 01 07 00 2E 00 00 FA 00 07
        // 
        // The error that occurred was:
        // 
        // com.strobel.assembler.metadata.MetadataHelper$AdaptFailure
        //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.visitGenericParameter(MetadataHelper.java:2300)
        //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.visitGenericParameter(MetadataHelper.java:2221)
        //     at com.strobel.assembler.metadata.GenericParameter.accept(GenericParameter.java:85)
        //     at com.strobel.assembler.metadata.DefaultTypeVisitor.visit(DefaultTypeVisitor.java:25)
        //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.adaptRecursive(MetadataHelper.java:2255)
        //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.adaptRecursive(MetadataHelper.java:2232)
        //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.visitParameterizedType(MetadataHelper.java:2245)
        //     at com.strobel.assembler.metadata.MetadataHelper$Adapter.visitParameterizedType(MetadataHelper.java:2221)
        //     at com.strobel.assembler.metadata.ParameterizedType.accept(ParameterizedType.java:103)
        //     at com.strobel.assembler.metadata.DefaultTypeVisitor.visit(DefaultTypeVisitor.java:25)
        //     at com.strobel.assembler.metadata.MetadataHelper.adapt(MetadataHelper.java:1312)
        //     at com.strobel.assembler.metadata.MetadataHelper.substituteGenericArguments(MetadataHelper.java:1010)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:976)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:778)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2669)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferBinaryArguments(TypeAnalysis.java:2834)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:851)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:766)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2515)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypesForVariables(TypeAnalysis.java:586)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:397)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    protected void layoutPlotChildren() {
        final double categorySpacing = this.categoryAxis.getCategorySpacing();
        final double n = categorySpacing - this.getCategoryGap();
        final double n2 = -((categorySpacing - this.getCategoryGap()) / 2.0);
        for (final String s : this.categoryAxis.getCategories()) {
            double d = 0.0;
            double d2 = 0.0;
            final Iterator<Series<X, Y>> displayedSeriesIterator = this.getDisplayedSeriesIterator();
            while (displayedSeriesIterator.hasNext()) {
                for (final Data<X, Y> data : this.getDataItem(displayedSeriesIterator.next(), s)) {
                    if (data != null) {
                        final Node node = data.getNode();
                        final X currentDisplayedXValue = this.getCurrentDisplayedXValue(data);
                        final Y currentDisplayedYValue = this.getCurrentDisplayedYValue(data);
                        double n3;
                        double n4;
                        if (this.orientation == Orientation.VERTICAL) {
                            n3 = this.getXAxis().getDisplayPosition(currentDisplayedXValue);
                            n4 = this.getYAxis().toNumericValue(currentDisplayedYValue);
                        }
                        else {
                            n3 = this.getYAxis().getDisplayPosition(currentDisplayedYValue);
                            n4 = this.getXAxis().toNumericValue(currentDisplayedXValue);
                        }
                        double n5;
                        double n6;
                        if (!node.getStyleClass().contains("negative")) {
                            n5 = this.valueAxis.getDisplayPosition(d);
                            n6 = this.valueAxis.getDisplayPosition(d + n4);
                            d += n4;
                        }
                        else {
                            n5 = this.valueAxis.getDisplayPosition(d2 + n4);
                            n6 = this.valueAxis.getDisplayPosition(d2);
                            d2 += n4;
                        }
                        if (this.orientation == Orientation.VERTICAL) {
                            node.resizeRelocate(n3 + n2, n6, n, n5 - n6);
                        }
                        else {
                            node.resizeRelocate(n5, n3 + n2, n6 - n5, n);
                        }
                    }
                }
            }
        }
    }
    
    @Override
    Legend.LegendItem createLegendItemForSeries(final Series<X, Y> series, final int n) {
        final Legend.LegendItem legendItem = new Legend.LegendItem(series.getName());
        legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-bar", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), "bar-legend-symbol", series.defaultColorStyleClass });
        return legendItem;
    }
    
    private void updateMap(final Series<X, Y> series, final Data<X, Y> data) {
        final String s = (String)((this.orientation == Orientation.VERTICAL) ? data.getXValue() : ((String)data.getYValue()));
        final Map<String, List<Data<X, Y>>> map = this.seriesCategoryMap.get(series);
        if (map != null) {
            map.remove(s);
            if (map.isEmpty()) {
                this.seriesCategoryMap.remove(series);
            }
        }
        if (this.seriesCategoryMap.isEmpty() && this.categoryAxis.isAutoRanging()) {
            this.categoryAxis.getCategories().clear();
        }
    }
    
    private void processDataRemove(final Series<X, Y> series, final Data<X, Y> data) {
        this.getPlotChildren().remove(data.getNode());
        this.updateMap(series, data);
    }
    
    private void animateDataAdd(final Data<X, Y> data, final Node node) {
        if (this.orientation == Orientation.VERTICAL) {
            final double doubleValue = ((Number)data.getYValue()).doubleValue();
            if (doubleValue < 0.0) {
                node.getStyleClass().add("negative");
            }
            data.setYValue(this.getYAxis().toRealValue(this.getYAxis().getZeroPosition()));
            this.setCurrentDisplayedYValue(data, this.getYAxis().toRealValue(this.getYAxis().getZeroPosition()));
            this.getPlotChildren().add(node);
            data.setYValue(this.getYAxis().toRealValue(doubleValue));
            this.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)this.currentDisplayedYValueProperty(data), (T)this.getCurrentDisplayedYValue(data)) }), new KeyFrame(Duration.millis(700.0), new KeyValue[] { new KeyValue((WritableValue<T>)this.currentDisplayedYValueProperty(data), (T)data.getYValue(), Interpolator.EASE_BOTH) }));
        }
        else {
            final double doubleValue2 = ((Number)data.getXValue()).doubleValue();
            if (doubleValue2 < 0.0) {
                node.getStyleClass().add("negative");
            }
            data.setXValue(this.getXAxis().toRealValue(this.getXAxis().getZeroPosition()));
            this.setCurrentDisplayedXValue(data, this.getXAxis().toRealValue(this.getXAxis().getZeroPosition()));
            this.getPlotChildren().add(node);
            data.setXValue(this.getXAxis().toRealValue(doubleValue2));
            this.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)this.currentDisplayedXValueProperty(data), (T)this.getCurrentDisplayedXValue(data)) }), new KeyFrame(Duration.millis(700.0), new KeyValue[] { new KeyValue((WritableValue<T>)this.currentDisplayedXValueProperty(data), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
        }
    }
    
    private Timeline createDataRemoveTimeline(final Data<X, Y> data, final Node node, final Series<X, Y> series) {
        final Timeline timeline = new Timeline();
        if (this.orientation == Orientation.VERTICAL) {
            data.setYValue(this.getYAxis().toRealValue(this.getYAxis().getZeroPosition()));
            timeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)this.currentDisplayedYValueProperty(data), (T)this.getCurrentDisplayedYValue(data)) }), new KeyFrame(Duration.millis(700.0), p2 -> this.processDataRemove(series, data), new KeyValue[] { new KeyValue((WritableValue<T>)this.currentDisplayedYValueProperty(data), (T)data.getYValue(), Interpolator.EASE_BOTH) }));
        }
        else {
            data.setXValue(this.getXAxis().toRealValue(this.getXAxis().getZeroPosition()));
            timeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)this.currentDisplayedXValueProperty(data), (T)this.getCurrentDisplayedXValue(data)) }), new KeyFrame(Duration.millis(700.0), p2 -> this.processDataRemove(series, data), new KeyValue[] { new KeyValue((WritableValue<T>)this.currentDisplayedXValueProperty(data), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
        }
        return timeline;
    }
    
    private Node createBar(final Series<X, Y> series, final int n, final Data<X, Y> data, final int n2) {
        Node node = data.getNode();
        if (node == null) {
            node = new StackPane();
            node.setAccessibleRole(AccessibleRole.TEXT);
            node.setAccessibleRoleDescription("Bar");
            node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
            data.setNode(node);
        }
        node.getStyleClass().setAll(new String[] { "chart-bar", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n2), series.defaultColorStyleClass });
        return node;
    }
    
    private List<Data<X, Y>> getDataItem(final Series<X, Y> series, final String s) {
        final Map<String, List<Data<X, Y>>> map = this.seriesCategoryMap.get(series);
        return (map != null) ? ((map.get(s) != null) ? map.get(s) : new ArrayList<Data<X, Y>>()) : new ArrayList<Data<X, Y>>();
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    static {
        VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
        HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<StackedBarChart<?, ?>, Number> CATEGORY_GAP;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            CATEGORY_GAP = new CssMetaData<StackedBarChart<?, ?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)10.0) {
                @Override
                public boolean isSettable(final StackedBarChart<?, ?> stackedBarChart) {
                    return ((StackedBarChart<Object, Object>)stackedBarChart).categoryGap == null || !((StackedBarChart<Object, Object>)stackedBarChart).categoryGap.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final StackedBarChart<?, ?> stackedBarChart) {
                    return (StyleableProperty<Number>)stackedBarChart.categoryGapProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(XYChart.getClassCssMetaData());
            list.add(StyleableProperties.CATEGORY_GAP);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
