// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.BooleanConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.css.Styleable;
import java.util.List;
import com.sun.javafx.scene.control.skin.Utils;
import com.sun.javafx.scene.NodeHelper;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.beans.property.SimpleBooleanProperty;
import com.sun.javafx.charts.Legend;
import javafx.css.StyleableBooleanProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.beans.property.StringPropertyBase;
import javafx.scene.Parent;
import javafx.collections.ObservableList;
import javafx.beans.property.BooleanProperty;
import javafx.scene.Node;
import javafx.geometry.Side;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import com.sun.javafx.charts.ChartLayoutAnimator;
import javafx.scene.layout.Pane;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;

public abstract class Chart extends Region
{
    private static final int MIN_WIDTH_TO_LEAVE_FOR_CHART_CONTENT = 200;
    private static final int MIN_HEIGHT_TO_LEAVE_FOR_CHART_CONTENT = 150;
    private final Label titleLabel;
    private final Pane chartContent;
    boolean useChartContentMirroring;
    private final ChartLayoutAnimator animator;
    private StringProperty title;
    private ObjectProperty<Side> titleSide;
    private final ObjectProperty<Node> legend;
    private final BooleanProperty legendVisible;
    private ObjectProperty<Side> legendSide;
    private BooleanProperty animated;
    
    public final String getTitle() {
        return this.title.get();
    }
    
    public final void setTitle(final String s) {
        this.title.set(s);
    }
    
    public final StringProperty titleProperty() {
        return this.title;
    }
    
    public final Side getTitleSide() {
        return this.titleSide.get();
    }
    
    public final void setTitleSide(final Side side) {
        this.titleSide.set(side);
    }
    
    public final ObjectProperty<Side> titleSideProperty() {
        return this.titleSide;
    }
    
    protected final Node getLegend() {
        return this.legend.getValue();
    }
    
    protected final void setLegend(final Node value) {
        this.legend.setValue(value);
    }
    
    protected final ObjectProperty<Node> legendProperty() {
        return this.legend;
    }
    
    public final boolean isLegendVisible() {
        return this.legendVisible.getValue();
    }
    
    public final void setLegendVisible(final boolean b) {
        this.legendVisible.setValue(b);
    }
    
    public final BooleanProperty legendVisibleProperty() {
        return this.legendVisible;
    }
    
    public final Side getLegendSide() {
        return this.legendSide.get();
    }
    
    public final void setLegendSide(final Side side) {
        this.legendSide.set(side);
    }
    
    public final ObjectProperty<Side> legendSideProperty() {
        return this.legendSide;
    }
    
    public final boolean getAnimated() {
        return this.animated.get();
    }
    
    public final void setAnimated(final boolean b) {
        this.animated.set(b);
    }
    
    public final BooleanProperty animatedProperty() {
        return this.animated;
    }
    
    protected ObservableList<Node> getChartChildren() {
        return this.chartContent.getChildren();
    }
    
    public Chart() {
        this.titleLabel = new Label();
        this.chartContent = new Pane() {
            @Override
            protected void layoutChildren() {
                final double snappedTopInset = this.snappedTopInset();
                final double snappedLeftInset = this.snappedLeftInset();
                Chart.this.layoutChartChildren(this.snapPositionY(snappedTopInset), this.snapPositionX(snappedLeftInset), this.snapSizeX(this.getWidth() - (snappedLeftInset + this.snappedRightInset())), this.snapSizeY(this.getHeight() - (snappedTopInset + this.snappedBottomInset())));
            }
            
            @Override
            public boolean usesMirroring() {
                return Chart.this.useChartContentMirroring;
            }
        };
        this.useChartContentMirroring = true;
        this.animator = new ChartLayoutAnimator(this.chartContent);
        this.title = new StringPropertyBase() {
            @Override
            protected void invalidated() {
                Chart.this.titleLabel.setText(this.get());
            }
            
            @Override
            public Object getBean() {
                return Chart.this;
            }
            
            @Override
            public String getName() {
                return "title";
            }
        };
        this.titleSide = new StyleableObjectProperty<Side>(Side.TOP) {
            @Override
            protected void invalidated() {
                Chart.this.requestLayout();
            }
            
            @Override
            public CssMetaData<Chart, Side> getCssMetaData() {
                return StyleableProperties.TITLE_SIDE;
            }
            
            @Override
            public Object getBean() {
                return Chart.this;
            }
            
            @Override
            public String getName() {
                return "titleSide";
            }
        };
        this.legend = new ObjectPropertyBase<Node>() {
            private Node old = null;
            
            @Override
            protected void invalidated() {
                final Node old = this.get();
                if (this.old != null) {
                    Parent.this.getChildren().remove(this.old);
                }
                if (old != null) {
                    Parent.this.getChildren().add(old);
                    old.setVisible(Chart.this.isLegendVisible());
                }
                this.old = old;
            }
            
            @Override
            public Object getBean() {
                return Chart.this;
            }
            
            @Override
            public String getName() {
                return "legend";
            }
        };
        this.legendVisible = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                Chart.this.requestLayout();
            }
            
            @Override
            public CssMetaData<Chart, Boolean> getCssMetaData() {
                return StyleableProperties.LEGEND_VISIBLE;
            }
            
            @Override
            public Object getBean() {
                return Chart.this;
            }
            
            @Override
            public String getName() {
                return "legendVisible";
            }
        };
        this.legendSide = new StyleableObjectProperty<Side>(Side.BOTTOM) {
            @Override
            protected void invalidated() {
                final Side side = this.get();
                final Node legend = Chart.this.getLegend();
                if (legend instanceof Legend) {
                    ((Legend)legend).setVertical(Side.LEFT.equals(side) || Side.RIGHT.equals(side));
                }
                Chart.this.requestLayout();
            }
            
            @Override
            public CssMetaData<Chart, Side> getCssMetaData() {
                return StyleableProperties.LEGEND_SIDE;
            }
            
            @Override
            public Object getBean() {
                return Chart.this;
            }
            
            @Override
            public String getName() {
                return "legendSide";
            }
        };
        this.animated = new SimpleBooleanProperty(this, "animated", true);
        this.titleLabel.setAlignment(Pos.CENTER);
        this.titleLabel.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
        this.getChildren().addAll(this.titleLabel, this.chartContent);
        this.getStyleClass().add("chart");
        this.titleLabel.getStyleClass().add("chart-title");
        this.chartContent.getStyleClass().add("chart-content");
        this.chartContent.setManaged(false);
    }
    
    void animate(final KeyFrame... array) {
        this.animator.animate(array);
    }
    
    protected void animate(final Animation animation) {
        this.animator.animate(animation);
    }
    
    protected void requestChartLayout() {
        this.chartContent.requestLayout();
    }
    
    protected final boolean shouldAnimate() {
        return this.getAnimated() && NodeHelper.isTreeShowing(this);
    }
    
    protected abstract void layoutChartChildren(final double p0, final double p1, final double p2, final double p3);
    
    @Override
    protected void layoutChildren() {
        double snappedTopInset = this.snappedTopInset();
        double snappedLeftInset = this.snappedLeftInset();
        double snappedBottomInset = this.snappedBottomInset();
        double snappedRightInset = this.snappedRightInset();
        final double width = this.getWidth();
        final double height = this.getHeight();
        if (this.getTitle() != null) {
            this.titleLabel.setVisible(true);
            if (this.getTitleSide().equals(Side.TOP)) {
                final double snapSizeY = this.snapSizeY(this.titleLabel.prefHeight(width - snappedLeftInset - snappedRightInset));
                this.titleLabel.resizeRelocate(snappedLeftInset, snappedTopInset, width - snappedLeftInset - snappedRightInset, snapSizeY);
                snappedTopInset += snapSizeY;
            }
            else if (this.getTitleSide().equals(Side.BOTTOM)) {
                final double snapSizeY2 = this.snapSizeY(this.titleLabel.prefHeight(width - snappedLeftInset - snappedRightInset));
                this.titleLabel.resizeRelocate(snappedLeftInset, height - snappedBottomInset - snapSizeY2, width - snappedLeftInset - snappedRightInset, snapSizeY2);
                snappedBottomInset += snapSizeY2;
            }
            else if (this.getTitleSide().equals(Side.LEFT)) {
                final double snapSizeX = this.snapSizeX(this.titleLabel.prefWidth(height - snappedTopInset - snappedBottomInset));
                this.titleLabel.resizeRelocate(snappedLeftInset, snappedTopInset, snapSizeX, height - snappedTopInset - snappedBottomInset);
                snappedLeftInset += snapSizeX;
            }
            else if (this.getTitleSide().equals(Side.RIGHT)) {
                final double snapSizeX2 = this.snapSizeX(this.titleLabel.prefWidth(height - snappedTopInset - snappedBottomInset));
                this.titleLabel.resizeRelocate(width - snappedRightInset - snapSizeX2, snappedTopInset, snapSizeX2, height - snappedTopInset - snappedBottomInset);
                snappedRightInset += snapSizeX2;
            }
        }
        else {
            this.titleLabel.setVisible(false);
        }
        final Node legend = this.getLegend();
        if (legend != null) {
            boolean legendVisible = this.isLegendVisible();
            if (legendVisible) {
                if (this.getLegendSide() == Side.TOP) {
                    final double snapSizeY3 = this.snapSizeY(legend.prefHeight(width - snappedLeftInset - snappedRightInset));
                    final double boundedSize = Utils.boundedSize(this.snapSizeX(legend.prefWidth(snapSizeY3)), 0.0, width - snappedLeftInset - snappedRightInset);
                    legend.resizeRelocate(snappedLeftInset + (width - snappedLeftInset - snappedRightInset - boundedSize) / 2.0, snappedTopInset, boundedSize, snapSizeY3);
                    if (height - snappedBottomInset - snappedTopInset - snapSizeY3 < 150.0) {
                        legendVisible = false;
                    }
                    else {
                        snappedTopInset += snapSizeY3;
                    }
                }
                else if (this.getLegendSide() == Side.BOTTOM) {
                    final double snapSizeY4 = this.snapSizeY(legend.prefHeight(width - snappedLeftInset - snappedRightInset));
                    final double boundedSize2 = Utils.boundedSize(this.snapSizeX(legend.prefWidth(snapSizeY4)), 0.0, width - snappedLeftInset - snappedRightInset);
                    legend.resizeRelocate(snappedLeftInset + (width - snappedLeftInset - snappedRightInset - boundedSize2) / 2.0, height - snappedBottomInset - snapSizeY4, boundedSize2, snapSizeY4);
                    if (height - snappedBottomInset - snappedTopInset - snapSizeY4 < 150.0) {
                        legendVisible = false;
                    }
                    else {
                        snappedBottomInset += snapSizeY4;
                    }
                }
                else if (this.getLegendSide() == Side.LEFT) {
                    final double snapSizeX3 = this.snapSizeX(legend.prefWidth(height - snappedTopInset - snappedBottomInset));
                    final double boundedSize3 = Utils.boundedSize(this.snapSizeY(legend.prefHeight(snapSizeX3)), 0.0, height - snappedTopInset - snappedBottomInset);
                    legend.resizeRelocate(snappedLeftInset, snappedTopInset + (height - snappedTopInset - snappedBottomInset - boundedSize3) / 2.0, snapSizeX3, boundedSize3);
                    if (width - snappedLeftInset - snappedRightInset - snapSizeX3 < 200.0) {
                        legendVisible = false;
                    }
                    else {
                        snappedLeftInset += snapSizeX3;
                    }
                }
                else if (this.getLegendSide() == Side.RIGHT) {
                    final double snapSizeX4 = this.snapSizeX(legend.prefWidth(height - snappedTopInset - snappedBottomInset));
                    final double boundedSize4 = Utils.boundedSize(this.snapSizeY(legend.prefHeight(snapSizeX4)), 0.0, height - snappedTopInset - snappedBottomInset);
                    legend.resizeRelocate(width - snappedRightInset - snapSizeX4, snappedTopInset + (height - snappedTopInset - snappedBottomInset - boundedSize4) / 2.0, snapSizeX4, boundedSize4);
                    if (width - snappedLeftInset - snappedRightInset - snapSizeX4 < 200.0) {
                        legendVisible = false;
                    }
                    else {
                        snappedRightInset += snapSizeX4;
                    }
                }
            }
            legend.setVisible(legendVisible);
        }
        this.chartContent.resizeRelocate(snappedLeftInset, snappedTopInset, width - snappedLeftInset - snappedRightInset, height - snappedTopInset - snappedBottomInset);
    }
    
    @Override
    protected double computeMinHeight(final double n) {
        return 150.0;
    }
    
    @Override
    protected double computeMinWidth(final double n) {
        return 200.0;
    }
    
    @Override
    protected double computePrefWidth(final double n) {
        return 500.0;
    }
    
    @Override
    protected double computePrefHeight(final double n) {
        return 400.0;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Chart, Side> TITLE_SIDE;
        private static final CssMetaData<Chart, Side> LEGEND_SIDE;
        private static final CssMetaData<Chart, Boolean> LEGEND_VISIBLE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            TITLE_SIDE = new CssMetaData<Chart, Side>((StyleConverter)new EnumConverter(Side.class), Side.TOP) {
                @Override
                public boolean isSettable(final Chart chart) {
                    return chart.titleSide == null || !chart.titleSide.isBound();
                }
                
                @Override
                public StyleableProperty<Side> getStyleableProperty(final Chart chart) {
                    return (StyleableProperty<Side>)(StyleableProperty)chart.titleSideProperty();
                }
            };
            LEGEND_SIDE = new CssMetaData<Chart, Side>((StyleConverter)new EnumConverter(Side.class), Side.BOTTOM) {
                @Override
                public boolean isSettable(final Chart chart) {
                    return chart.legendSide == null || !chart.legendSide.isBound();
                }
                
                @Override
                public StyleableProperty<Side> getStyleableProperty(final Chart chart) {
                    return (StyleableProperty<Side>)(StyleableProperty)chart.legendSideProperty();
                }
            };
            LEGEND_VISIBLE = new CssMetaData<Chart, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final Chart chart) {
                    return chart.legendVisible == null || !chart.legendVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Chart chart) {
                    return (StyleableProperty<Boolean>)chart.legendVisibleProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Region.getClassCssMetaData());
            list.add(StyleableProperties.TITLE_SIDE);
            list.add(StyleableProperties.LEGEND_VISIBLE);
            list.add(StyleableProperties.LEGEND_SIDE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
