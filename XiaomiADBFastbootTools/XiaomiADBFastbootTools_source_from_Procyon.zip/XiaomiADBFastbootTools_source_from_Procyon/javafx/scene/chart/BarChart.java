// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.Styleable;
import java.util.List;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import javafx.scene.AccessibleRole;
import javafx.scene.layout.StackPane;
import javafx.animation.Animation;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.animation.Interpolator;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.animation.KeyFrame;
import com.sun.javafx.charts.Legend;
import java.util.Iterator;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import javafx.collections.ListChangeListener;
import javafx.scene.Node;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import java.util.HashMap;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.beans.NamedArg;
import javafx.css.PseudoClass;
import javafx.beans.property.DoubleProperty;
import javafx.animation.ParallelTransition;
import javafx.animation.Timeline;
import javafx.geometry.Orientation;
import java.util.Map;

public class BarChart<X, Y> extends XYChart<X, Y>
{
    private Map<Series<X, Y>, Map<String, Data<X, Y>>> seriesCategoryMap;
    private final Orientation orientation;
    private CategoryAxis categoryAxis;
    private ValueAxis valueAxis;
    private Timeline dataRemoveTimeline;
    private double bottomPos;
    private static String NEGATIVE_STYLE;
    private ParallelTransition pt;
    private Map<Data<X, Y>, Double> XYValueMap;
    private DoubleProperty barGap;
    private DoubleProperty categoryGap;
    private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE;
    private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE;
    
    public final double getBarGap() {
        return this.barGap.getValue();
    }
    
    public final void setBarGap(final double d) {
        this.barGap.setValue(d);
    }
    
    public final DoubleProperty barGapProperty() {
        return this.barGap;
    }
    
    public final double getCategoryGap() {
        return this.categoryGap.getValue();
    }
    
    public final void setCategoryGap(final double d) {
        this.categoryGap.setValue(d);
    }
    
    public final DoubleProperty categoryGapProperty() {
        return this.categoryGap;
    }
    
    public BarChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2) {
        this(axis, axis2, FXCollections.observableArrayList());
    }
    
    public BarChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2, @NamedArg("data") final ObservableList<Series<X, Y>> data) {
        super(axis, axis2);
        this.seriesCategoryMap = new HashMap<Series<X, Y>, Map<String, Data<X, Y>>>();
        this.bottomPos = 0.0;
        this.XYValueMap = new HashMap<Data<X, Y>, Double>();
        this.barGap = new StyleableDoubleProperty(4.0) {
            @Override
            protected void invalidated() {
                this.get();
                BarChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return BarChart.this;
            }
            
            @Override
            public String getName() {
                return "barGap";
            }
            
            @Override
            public CssMetaData<BarChart<?, ?>, Number> getCssMetaData() {
                return StyleableProperties.BAR_GAP;
            }
        };
        this.categoryGap = new StyleableDoubleProperty(10.0) {
            @Override
            protected void invalidated() {
                this.get();
                BarChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return BarChart.this;
            }
            
            @Override
            public String getName() {
                return "categoryGap";
            }
            
            @Override
            public CssMetaData<BarChart<?, ?>, Number> getCssMetaData() {
                return StyleableProperties.CATEGORY_GAP;
            }
        };
        this.getStyleClass().add("bar-chart");
        if ((!(axis instanceof ValueAxis) || !(axis2 instanceof CategoryAxis)) && (!(axis2 instanceof ValueAxis) || !(axis instanceof CategoryAxis))) {
            throw new IllegalArgumentException("Axis type incorrect, one of X,Y should be CategoryAxis and the other NumberAxis");
        }
        if (axis instanceof CategoryAxis) {
            this.categoryAxis = (CategoryAxis)axis;
            this.valueAxis = (ValueAxis)axis2;
            this.orientation = Orientation.VERTICAL;
        }
        else {
            this.categoryAxis = (CategoryAxis)axis2;
            this.valueAxis = (ValueAxis)axis;
            this.orientation = Orientation.HORIZONTAL;
        }
        this.pseudoClassStateChanged(BarChart.HORIZONTAL_PSEUDOCLASS_STATE, this.orientation == Orientation.HORIZONTAL);
        this.pseudoClassStateChanged(BarChart.VERTICAL_PSEUDOCLASS_STATE, this.orientation == Orientation.VERTICAL);
        this.setData(data);
    }
    
    public BarChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2, @NamedArg("data") final ObservableList<Series<X, Y>> data, @NamedArg("categoryGap") final double categoryGap) {
        this(axis, axis2);
        this.setData(data);
        this.setCategoryGap(categoryGap);
    }
    
    @Override
    protected void dataItemAdded(final Series<X, Y> series, final int n, final Data<X, Y> data) {
        String s;
        if (this.orientation == Orientation.VERTICAL) {
            s = (String)data.getXValue();
        }
        else {
            s = (String)data.getYValue();
        }
        Map<String, Data<X, Y>> map = this.seriesCategoryMap.get(series);
        if (map == null) {
            map = new HashMap<String, Data<X, Y>>();
            this.seriesCategoryMap.put(series, map);
        }
        if (!this.categoryAxis.getCategories().contains(s)) {
            this.categoryAxis.getCategories().add(n, s);
        }
        else if (map.containsKey(s)) {
            final Data<X, Y> data2 = map.get(s);
            this.getPlotChildren().remove(data2.getNode());
            this.removeDataItemFromDisplay(series, data2);
            this.requestChartLayout();
            map.remove(s);
        }
        map.put(s, data);
        final Node bar = this.createBar(series, this.getData().indexOf(series), data, n);
        if (this.shouldAnimate()) {
            this.animateDataAdd(data, bar);
        }
        else {
            this.getPlotChildren().add(bar);
        }
    }
    
    @Override
    protected void dataItemRemoved(final Data<X, Y> data, final Series<X, Y> series) {
        final Node node = data.getNode();
        if (node != null) {
            node.focusTraversableProperty().unbind();
        }
        if (this.shouldAnimate()) {
            this.XYValueMap.clear();
            (this.dataRemoveTimeline = this.createDataRemoveTimeline(data, node, series)).setOnFinished(p2 -> {
                data.setSeries(null);
                this.removeDataItemFromDisplay(series, data);
                return;
            });
            this.dataRemoveTimeline.play();
        }
        else {
            this.processDataRemove(series, data);
            this.removeDataItemFromDisplay(series, data);
        }
    }
    
    @Override
    protected void dataItemChanged(final Data<X, Y> data) {
        double n;
        double n2;
        if (this.orientation == Orientation.VERTICAL) {
            n = ((Number)data.getYValue()).doubleValue();
            n2 = ((Number)data.getCurrentY()).doubleValue();
        }
        else {
            n = ((Number)data.getXValue()).doubleValue();
            n2 = ((Number)data.getCurrentX()).doubleValue();
        }
        if (n2 > 0.0 && n < 0.0) {
            data.getNode().getStyleClass().add(BarChart.NEGATIVE_STYLE);
        }
        else if (n2 < 0.0 && n > 0.0) {
            data.getNode().getStyleClass().remove(BarChart.NEGATIVE_STYLE);
        }
    }
    
    @Override
    protected void seriesChanged(final ListChangeListener.Change<? extends Series> change) {
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Series series = this.getData().get(i);
            for (int j = 0; j < series.getData().size(); ++j) {
                ((Data)series.getData().get(j)).getNode().getStyleClass().setAll(new String[] { "chart-bar", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, j), series.defaultColorStyleClass });
            }
        }
    }
    
    @Override
    protected void seriesAdded(final Series<X, Y> series, final int n) {
        final HashMap<String, Data<X, Y>> hashMap = new HashMap<String, Data<X, Y>>();
        for (int i = 0; i < series.getData().size(); ++i) {
            final Data<X, Y> data = series.getData().get(i);
            final Node bar = this.createBar(series, n, data, i);
            String s;
            if (this.orientation == Orientation.VERTICAL) {
                s = (String)data.getXValue();
            }
            else {
                s = (String)data.getYValue();
            }
            hashMap.put(s, data);
            if (this.shouldAnimate()) {
                this.animateDataAdd(data, bar);
            }
            else {
                if (((this.orientation == Orientation.VERTICAL) ? ((Number)data.getYValue()).doubleValue() : ((Number)data.getXValue()).doubleValue()) < 0.0) {
                    bar.getStyleClass().add(BarChart.NEGATIVE_STYLE);
                }
                this.getPlotChildren().add(bar);
            }
        }
        if (hashMap.size() > 0) {
            this.seriesCategoryMap.put(series, hashMap);
        }
    }
    
    @Override
    protected void seriesRemoved(final Series<X, Y> series) {
        if (this.shouldAnimate()) {
            (this.pt = new ParallelTransition()).setOnFinished(p1 -> this.removeSeriesFromDisplay(series));
            this.XYValueMap.clear();
            for (final Data<X, Y> data : series.getData()) {
                final Node node = data.getNode();
                if (this.getSeriesSize() > 1) {
                    this.pt.getChildren().add(this.createDataRemoveTimeline(data, node, series));
                }
                else {
                    final FadeTransition fadeTransition = new FadeTransition(Duration.millis(700.0), node);
                    fadeTransition.setFromValue(1.0);
                    fadeTransition.setToValue(0.0);
                    final Data<X, Y> data2;
                    final Node node2;
                    fadeTransition.setOnFinished(p3 -> {
                        this.processDataRemove(series, data2);
                        node2.setOpacity(1.0);
                        return;
                    });
                    this.pt.getChildren().add(fadeTransition);
                }
            }
            this.pt.play();
        }
        else {
            final Iterator<Data<X, Y>> iterator2 = series.getData().iterator();
            while (iterator2.hasNext()) {
                this.processDataRemove(series, iterator2.next());
            }
            this.removeSeriesFromDisplay(series);
        }
    }
    
    @Override
    protected void layoutPlotChildren() {
        final double categorySpacing = this.categoryAxis.getCategorySpacing();
        double n = (categorySpacing - (this.getCategoryGap() + this.getBarGap())) / this.getSeriesSize() - this.getBarGap();
        final double n2 = -((categorySpacing - this.getCategoryGap()) / 2.0);
        final double n3 = (this.valueAxis.getLowerBound() > 0.0) ? this.valueAxis.getDisplayPosition(this.valueAxis.getLowerBound()) : this.valueAxis.getZeroPosition();
        if (n <= 0.0) {
            n = 1.0;
        }
        int n4 = 0;
        for (final String s : this.categoryAxis.getCategories()) {
            int n5 = 0;
            final Iterator<Series<X, Y>> displayedSeriesIterator = this.getDisplayedSeriesIterator();
            while (displayedSeriesIterator.hasNext()) {
                final Data<X, Y> dataItem = this.getDataItem((Series<X, Y>)displayedSeriesIterator.next(), n5, n4, s);
                if (dataItem != null) {
                    final Node node = dataItem.getNode();
                    double v;
                    double a;
                    if (this.orientation == Orientation.VERTICAL) {
                        v = this.getXAxis().getDisplayPosition(dataItem.getCurrentX());
                        a = this.getYAxis().getDisplayPosition((Y)dataItem.getCurrentY());
                    }
                    else {
                        v = this.getYAxis().getDisplayPosition((Y)dataItem.getCurrentY());
                        a = this.getXAxis().getDisplayPosition(dataItem.getCurrentX());
                    }
                    if (Double.isNaN(v)) {
                        continue;
                    }
                    if (Double.isNaN(a)) {
                        continue;
                    }
                    final double min = Math.min(a, n3);
                    final double max = Math.max(a, n3);
                    this.bottomPos = min;
                    if (this.orientation == Orientation.VERTICAL) {
                        node.resizeRelocate(v + n2 + (n + this.getBarGap()) * n5, min, n, max - min);
                    }
                    else {
                        node.resizeRelocate(min, v + n2 + (n + this.getBarGap()) * n5, max - min, n);
                    }
                    ++n5;
                }
            }
            ++n4;
        }
    }
    
    @Override
    Legend.LegendItem createLegendItemForSeries(final Series<X, Y> series, final int n) {
        final Legend.LegendItem legendItem = new Legend.LegendItem(series.getName());
        legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-bar", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), "bar-legend-symbol", series.defaultColorStyleClass });
        return legendItem;
    }
    
    private void updateMap(final Series<X, Y> series, final Data<X, Y> data) {
        final String s = (String)((this.orientation == Orientation.VERTICAL) ? data.getXValue() : ((String)data.getYValue()));
        final Map<String, Data<X, Y>> map = this.seriesCategoryMap.get(series);
        if (map != null) {
            map.remove(s);
            if (map.isEmpty()) {
                this.seriesCategoryMap.remove(series);
            }
        }
        if (this.seriesCategoryMap.isEmpty() && this.categoryAxis.isAutoRanging()) {
            this.categoryAxis.getCategories().clear();
        }
    }
    
    private void processDataRemove(final Series<X, Y> series, final Data<X, Y> data) {
        this.getPlotChildren().remove(data.getNode());
        this.updateMap(series, data);
    }
    
    private void animateDataAdd(final Data<X, Y> data, final Node node) {
        if (this.orientation == Orientation.VERTICAL) {
            final double doubleValue = ((Number)data.getYValue()).doubleValue();
            if (doubleValue < 0.0) {
                node.getStyleClass().add(BarChart.NEGATIVE_STYLE);
            }
            data.setCurrentY(this.getYAxis().toRealValue((doubleValue < 0.0) ? (-this.bottomPos) : this.bottomPos));
            this.getPlotChildren().add(node);
            data.setYValue(this.getYAxis().toRealValue(doubleValue));
            this.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getCurrentY()) }), new KeyFrame(Duration.millis(700.0), new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getYValue(), Interpolator.EASE_BOTH) }));
        }
        else {
            final double doubleValue2 = ((Number)data.getXValue()).doubleValue();
            if (doubleValue2 < 0.0) {
                node.getStyleClass().add(BarChart.NEGATIVE_STYLE);
            }
            data.setCurrentX(this.getXAxis().toRealValue((doubleValue2 < 0.0) ? (-this.bottomPos) : this.bottomPos));
            this.getPlotChildren().add(node);
            data.setXValue(this.getXAxis().toRealValue(doubleValue2));
            this.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getCurrentX()) }), new KeyFrame(Duration.millis(700.0), new KeyValue[] { new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
        }
    }
    
    private Timeline createDataRemoveTimeline(final Data<X, Y> data, final Node node, final Series<X, Y> series) {
        final Timeline timeline = new Timeline();
        if (this.orientation == Orientation.VERTICAL) {
            this.XYValueMap.put(data, ((Number)data.getYValue()).doubleValue());
            data.setYValue(this.getYAxis().toRealValue(this.bottomPos));
            timeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getCurrentY()) }), new KeyFrame(Duration.millis(700.0), p2 -> {
                this.processDataRemove(series, data);
                this.XYValueMap.clear();
                return;
            }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getYValue(), Interpolator.EASE_BOTH) }));
        }
        else {
            this.XYValueMap.put(data, ((Number)data.getXValue()).doubleValue());
            data.setXValue(this.getXAxis().toRealValue(this.getXAxis().getZeroPosition()));
            timeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getCurrentX()) }), new KeyFrame(Duration.millis(700.0), p2 -> {
                this.processDataRemove(series, data);
                this.XYValueMap.clear();
                return;
            }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
        }
        return timeline;
    }
    
    @Override
    void dataBeingRemovedIsAdded(final Data<X, Y> data, final Series<X, Y> series) {
        if (this.dataRemoveTimeline != null) {
            this.dataRemoveTimeline.setOnFinished(null);
            this.dataRemoveTimeline.stop();
        }
        this.processDataRemove(series, data);
        data.setSeries(null);
        this.removeDataItemFromDisplay(series, data);
        this.restoreDataValues(data);
        this.XYValueMap.clear();
    }
    
    private void restoreDataValues(final Data data) {
        final Double n = this.XYValueMap.get(data);
        if (n != null) {
            if (this.orientation.equals(Orientation.VERTICAL)) {
                data.setYValue(n);
                data.setCurrentY(n);
            }
            else {
                data.setXValue(n);
                data.setCurrentX(n);
            }
        }
    }
    
    @Override
    void seriesBeingRemovedIsAdded(final Series<X, Y> series) {
        final boolean b = this.pt.getChildren().size() == 1;
        if (this.pt != null) {
            if (!this.pt.getChildren().isEmpty()) {
                final Iterator<Animation> iterator = (Iterator<Animation>)this.pt.getChildren().iterator();
                while (iterator.hasNext()) {
                    iterator.next().setOnFinished(null);
                }
            }
            for (final Data<X, Y> data : series.getData()) {
                this.processDataRemove(series, data);
                if (!b) {
                    this.restoreDataValues(data);
                }
            }
            this.XYValueMap.clear();
            this.pt.setOnFinished(null);
            this.pt.getChildren().clear();
            this.pt.stop();
            this.removeSeriesFromDisplay(series);
        }
    }
    
    private Node createBar(final Series<X, Y> series, final int n, final Data<X, Y> data, final int n2) {
        Node node = data.getNode();
        if (node == null) {
            node = new StackPane();
            node.setAccessibleRole(AccessibleRole.TEXT);
            node.setAccessibleRoleDescription("Bar");
            node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
            data.setNode(node);
        }
        node.getStyleClass().setAll(new String[] { "chart-bar", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n2), series.defaultColorStyleClass });
        return node;
    }
    
    private Data<X, Y> getDataItem(final Series<X, Y> series, final int n, final int n2, final String s) {
        final Map<String, Data<X, Y>> map = this.seriesCategoryMap.get(series);
        return (map != null) ? map.get(s) : null;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    static {
        BarChart.NEGATIVE_STYLE = "negative";
        VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
        HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<BarChart<?, ?>, Number> BAR_GAP;
        private static final CssMetaData<BarChart<?, ?>, Number> CATEGORY_GAP;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            BAR_GAP = new CssMetaData<BarChart<?, ?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)4.0) {
                @Override
                public boolean isSettable(final BarChart<?, ?> barChart) {
                    return ((BarChart<Object, Object>)barChart).barGap == null || !((BarChart<Object, Object>)barChart).barGap.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final BarChart<?, ?> barChart) {
                    return (StyleableProperty<Number>)barChart.barGapProperty();
                }
            };
            CATEGORY_GAP = new CssMetaData<BarChart<?, ?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)10.0) {
                @Override
                public boolean isSettable(final BarChart<?, ?> barChart) {
                    return ((BarChart<Object, Object>)barChart).categoryGap == null || !((BarChart<Object, Object>)barChart).categoryGap.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final BarChart<?, ?> barChart) {
                    return (StyleableProperty<Number>)barChart.categoryGapProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(XYChart.getClassCssMetaData());
            list.add(StyleableProperties.BAR_GAP);
            list.add(StyleableProperties.CATEGORY_GAP);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
