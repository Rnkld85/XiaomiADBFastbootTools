// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import java.util.Collections;
import java.util.Collection;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.css.Styleable;
import com.sun.javafx.charts.Legend;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import javafx.scene.AccessibleRole;
import javafx.scene.layout.StackPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.shape.LineTo;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.shape.Path;
import javafx.collections.ListChangeListener;
import javafx.animation.Interpolator;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.animation.KeyFrame;
import javafx.util.Duration;
import javafx.animation.Animation;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import javafx.beans.property.ObjectPropertyBase;
import javafx.css.CssMetaData;
import javafx.scene.Node;
import javafx.css.StyleableBooleanProperty;
import java.util.HashMap;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.beans.NamedArg;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.BooleanProperty;
import javafx.animation.FadeTransition;
import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import java.util.Map;

public class LineChart<X, Y> extends XYChart<X, Y>
{
    private Map<Series<X, Y>, DoubleProperty> seriesYMultiplierMap;
    private Timeline dataRemoveTimeline;
    private Series<X, Y> seriesOfDataRemoved;
    private Data<X, Y> dataItemBeingRemoved;
    private FadeTransition fadeSymbolTransition;
    private Map<Data<X, Y>, Double> XYValueMap;
    private Timeline seriesRemoveTimeline;
    private BooleanProperty createSymbols;
    private ObjectProperty<SortingPolicy> axisSortingPolicy;
    
    public final boolean getCreateSymbols() {
        return this.createSymbols.getValue();
    }
    
    public final void setCreateSymbols(final boolean b) {
        this.createSymbols.setValue(b);
    }
    
    public final BooleanProperty createSymbolsProperty() {
        return this.createSymbols;
    }
    
    public final SortingPolicy getAxisSortingPolicy() {
        return this.axisSortingPolicy.getValue();
    }
    
    public final void setAxisSortingPolicy(final SortingPolicy value) {
        this.axisSortingPolicy.setValue(value);
    }
    
    public final ObjectProperty<SortingPolicy> axisSortingPolicyProperty() {
        return this.axisSortingPolicy;
    }
    
    public LineChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2) {
        this(axis, axis2, FXCollections.observableArrayList());
    }
    
    public LineChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2, @NamedArg("data") final ObservableList<Series<X, Y>> data) {
        super(axis, axis2);
        this.seriesYMultiplierMap = new HashMap<Series<X, Y>, DoubleProperty>();
        this.seriesOfDataRemoved = null;
        this.dataItemBeingRemoved = null;
        this.fadeSymbolTransition = null;
        this.XYValueMap = new HashMap<Data<X, Y>, Double>();
        this.seriesRemoveTimeline = null;
        this.createSymbols = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                for (int i = 0; i < LineChart.this.getData().size(); ++i) {
                    final Series series = LineChart.this.getData().get(i);
                    for (int j = 0; j < series.getData().size(); ++j) {
                        final Data data = (Data)series.getData().get(j);
                        final Node node = data.getNode();
                        if (this.get() && node == null) {
                            LineChart.this.getPlotChildren().add(LineChart.this.createSymbol(series, LineChart.this.getData().indexOf(series), data, j));
                        }
                        else if (!this.get() && node != null) {
                            LineChart.this.getPlotChildren().remove(node);
                            data.setNode(null);
                        }
                    }
                }
                LineChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return LineChart.this;
            }
            
            @Override
            public String getName() {
                return "createSymbols";
            }
            
            @Override
            public CssMetaData<LineChart<?, ?>, Boolean> getCssMetaData() {
                return StyleableProperties.CREATE_SYMBOLS;
            }
        };
        this.axisSortingPolicy = new ObjectPropertyBase<SortingPolicy>(SortingPolicy.X_AXIS) {
            @Override
            protected void invalidated() {
                LineChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return LineChart.this;
            }
            
            @Override
            public String getName() {
                return "axisSortingPolicy";
            }
        };
        this.setData(data);
    }
    
    @Override
    protected void updateAxisRange() {
        final Axis<X> xAxis = this.getXAxis();
        final Axis<Y> yAxis = this.getYAxis();
        List<X> list = null;
        List<Y> list2 = null;
        if (xAxis.isAutoRanging()) {
            list = new ArrayList<X>();
        }
        if (yAxis.isAutoRanging()) {
            list2 = new ArrayList<Y>();
        }
        if (list != null || list2 != null) {
            final Iterator<Series> iterator = this.getData().iterator();
            while (iterator.hasNext()) {
                for (final Data<Object, Y> data : iterator.next().getData()) {
                    if (list != null) {
                        list.add((X)data.getXValue());
                    }
                    if (list2 != null) {
                        list2.add((Y)data.getYValue());
                    }
                }
            }
            if (list != null && (list.size() != 1 || this.getXAxis().toNumericValue(list.get(0)) != 0.0)) {
                xAxis.invalidateRange(list);
            }
            if (list2 != null && (list2.size() != 1 || this.getYAxis().toNumericValue(list2.get(0)) != 0.0)) {
                yAxis.invalidateRange(list2);
            }
        }
    }
    
    @Override
    protected void dataItemAdded(final Series<X, Y> series, final int n, final Data<X, Y> data) {
        final Node symbol = this.createSymbol(series, this.getData().indexOf(series), data, n);
        if (this.shouldAnimate()) {
            if (this.dataRemoveTimeline != null && this.dataRemoveTimeline.getStatus().equals(Animation.Status.RUNNING) && this.seriesOfDataRemoved == series) {
                this.dataRemoveTimeline.stop();
                this.dataRemoveTimeline = null;
                this.getPlotChildren().remove(this.dataItemBeingRemoved.getNode());
                this.removeDataItemFromDisplay(this.seriesOfDataRemoved, this.dataItemBeingRemoved);
                this.seriesOfDataRemoved = null;
                this.dataItemBeingRemoved = null;
            }
            boolean b = false;
            if (n > 0 && n < series.getData().size() - 1) {
                b = true;
                final Data<X, Y> data2 = series.getData().get(n - 1);
                final Data<X, Y> data3 = series.getData().get(n + 1);
                if (data2 != null && data3 != null) {
                    final double numericValue = this.getXAxis().toNumericValue(data2.getXValue());
                    final double numericValue2 = this.getYAxis().toNumericValue(data2.getYValue());
                    final double numericValue3 = this.getXAxis().toNumericValue(data3.getXValue());
                    final double numericValue4 = this.getYAxis().toNumericValue(data3.getYValue());
                    final double numericValue5 = this.getXAxis().toNumericValue(data.getXValue());
                    if (numericValue5 > numericValue && numericValue5 < numericValue3) {
                        data.setCurrentY(this.getYAxis().toRealValue((numericValue4 - numericValue2) / (numericValue3 - numericValue) * numericValue5 + (numericValue3 * numericValue2 - numericValue4 * numericValue) / (numericValue3 - numericValue)));
                        data.setCurrentX(this.getXAxis().toRealValue(numericValue5));
                    }
                    else {
                        final double n2 = (numericValue3 + numericValue) / 2.0;
                        final double n3 = (numericValue4 + numericValue2) / 2.0;
                        data.setCurrentX(this.getXAxis().toRealValue(n2));
                        data.setCurrentY(this.getYAxis().toRealValue(n3));
                    }
                }
            }
            else if (n == 0 && series.getData().size() > 1) {
                b = true;
                data.setCurrentX(series.getData().get(1).getXValue());
                data.setCurrentY(series.getData().get(1).getYValue());
            }
            else if (n == series.getData().size() - 1 && series.getData().size() > 1) {
                b = true;
                final int n4 = series.getData().size() - 2;
                data.setCurrentX(((Data<X, Y>)series.getData().get(n4)).getXValue());
                data.setCurrentY(((Data<X, Y>)series.getData().get(n4)).getYValue());
            }
            else if (symbol != null) {
                symbol.setOpacity(0.0);
                this.getPlotChildren().add(symbol);
                final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), symbol);
                fadeTransition.setToValue(1.0);
                fadeTransition.play();
            }
            if (b) {
                final Node node;
                this.animate(new KeyFrame(Duration.ZERO, p1 -> {
                    if (node != null && !this.getPlotChildren().contains(node)) {
                        this.getPlotChildren().add(node);
                    }
                }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getCurrentY()), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getCurrentX()) }), new KeyFrame(Duration.millis(700.0), new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getYValue(), Interpolator.EASE_BOTH), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
            }
        }
        else if (symbol != null) {
            this.getPlotChildren().add(symbol);
        }
    }
    
    @Override
    protected void dataItemRemoved(final Data<X, Y> dataItemBeingRemoved, final Series<X, Y> seriesOfDataRemoved) {
        final Node node = dataItemBeingRemoved.getNode();
        if (node != null) {
            node.focusTraversableProperty().unbind();
        }
        final int itemIndex = seriesOfDataRemoved.getItemIndex(dataItemBeingRemoved);
        if (this.shouldAnimate()) {
            this.XYValueMap.clear();
            boolean b = false;
            final int dataSize = seriesOfDataRemoved.getDataSize();
            final int size = seriesOfDataRemoved.getData().size();
            if (itemIndex > 0 && itemIndex < dataSize - 1) {
                b = true;
                final Data<X, Y> item = seriesOfDataRemoved.getItem(itemIndex - 1);
                final Data<X, Y> item2 = seriesOfDataRemoved.getItem(itemIndex + 1);
                final double numericValue = this.getXAxis().toNumericValue(item.getXValue());
                final double numericValue2 = this.getYAxis().toNumericValue(item.getYValue());
                final double numericValue3 = this.getXAxis().toNumericValue(item2.getXValue());
                final double numericValue4 = this.getYAxis().toNumericValue(item2.getYValue());
                final double numericValue5 = this.getXAxis().toNumericValue(dataItemBeingRemoved.getXValue());
                final double numericValue6 = this.getYAxis().toNumericValue(dataItemBeingRemoved.getYValue());
                if (numericValue5 > numericValue && numericValue5 < numericValue3) {
                    final double n = (numericValue4 - numericValue2) / (numericValue3 - numericValue) * numericValue5 + (numericValue3 * numericValue2 - numericValue4 * numericValue) / (numericValue3 - numericValue);
                    dataItemBeingRemoved.setCurrentX(this.getXAxis().toRealValue(numericValue5));
                    dataItemBeingRemoved.setCurrentY(this.getYAxis().toRealValue(numericValue6));
                    dataItemBeingRemoved.setXValue(this.getXAxis().toRealValue(numericValue5));
                    dataItemBeingRemoved.setYValue(this.getYAxis().toRealValue(n));
                }
                else {
                    final double n2 = (numericValue3 + numericValue) / 2.0;
                    final double n3 = (numericValue4 + numericValue2) / 2.0;
                    dataItemBeingRemoved.setCurrentX(this.getXAxis().toRealValue(n2));
                    dataItemBeingRemoved.setCurrentY(this.getYAxis().toRealValue(n3));
                }
            }
            else if (itemIndex == 0 && size > 1) {
                b = true;
                dataItemBeingRemoved.setXValue(((Data<X, Y>)seriesOfDataRemoved.getData().get(0)).getXValue());
                dataItemBeingRemoved.setYValue(((Data<X, Y>)seriesOfDataRemoved.getData().get(0)).getYValue());
            }
            else if (itemIndex == dataSize - 1 && size > 1) {
                b = true;
                final int n4 = size - 1;
                dataItemBeingRemoved.setXValue(((Data<X, Y>)seriesOfDataRemoved.getData().get(n4)).getXValue());
                dataItemBeingRemoved.setYValue(((Data<X, Y>)seriesOfDataRemoved.getData().get(n4)).getYValue());
            }
            else if (node != null) {
                (this.fadeSymbolTransition = new FadeTransition(Duration.millis(500.0), node)).setToValue(0.0);
                final Node node2;
                this.fadeSymbolTransition.setOnFinished(p3 -> {
                    dataItemBeingRemoved.setSeries(null);
                    this.getPlotChildren().remove(node2);
                    this.removeDataItemFromDisplay(seriesOfDataRemoved, dataItemBeingRemoved);
                    node2.setOpacity(1.0);
                    return;
                });
                this.fadeSymbolTransition.play();
            }
            else {
                dataItemBeingRemoved.setSeries(null);
                this.removeDataItemFromDisplay(seriesOfDataRemoved, dataItemBeingRemoved);
            }
            if (b) {
                this.dataRemoveTimeline = this.createDataRemoveTimeline(dataItemBeingRemoved, node, seriesOfDataRemoved);
                this.seriesOfDataRemoved = seriesOfDataRemoved;
                this.dataItemBeingRemoved = dataItemBeingRemoved;
                this.dataRemoveTimeline.play();
            }
        }
        else {
            dataItemBeingRemoved.setSeries(null);
            if (node != null) {
                this.getPlotChildren().remove(node);
            }
            this.removeDataItemFromDisplay(seriesOfDataRemoved, dataItemBeingRemoved);
        }
    }
    
    @Override
    protected void dataItemChanged(final Data<X, Y> data) {
    }
    
    @Override
    protected void seriesChanged(final ListChangeListener.Change<? extends Series> change) {
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Series series = this.getData().get(i);
            final Node node = series.getNode();
            if (node != null) {
                node.getStyleClass().setAll(new String[] { "chart-series-line", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), series.defaultColorStyleClass });
            }
            for (int j = 0; j < series.getData().size(); ++j) {
                final Node node2 = ((Data)series.getData().get(j)).getNode();
                if (node2 != null) {
                    node2.getStyleClass().setAll(new String[] { "chart-line-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, j), series.defaultColorStyleClass });
                }
            }
        }
    }
    
    @Override
    protected void seriesAdded(final Series<X, Y> series, final int n) {
        final Path node = new Path();
        node.setStrokeLineJoin(StrokeLineJoin.BEVEL);
        series.setNode(node);
        final SimpleDoubleProperty simpleDoubleProperty = new SimpleDoubleProperty(this, "seriesYMultiplier");
        this.seriesYMultiplierMap.put(series, simpleDoubleProperty);
        if (this.shouldAnimate()) {
            node.setOpacity(0.0);
            simpleDoubleProperty.setValue(0.0);
        }
        else {
            simpleDoubleProperty.setValue(1.0);
        }
        this.getPlotChildren().add(node);
        final ArrayList<KeyFrame> list = new ArrayList<KeyFrame>();
        if (this.shouldAnimate()) {
            list.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)node.opacityProperty(), (T)0), new KeyValue((WritableValue<T>)simpleDoubleProperty, (T)0) }));
            list.add(new KeyFrame(Duration.millis(200.0), new KeyValue[] { new KeyValue((WritableValue<T>)node.opacityProperty(), (T)1) }));
            list.add(new KeyFrame(Duration.millis(500.0), new KeyValue[] { new KeyValue((WritableValue<T>)simpleDoubleProperty, (T)1) }));
        }
        for (int i = 0; i < series.getData().size(); ++i) {
            final Node symbol = this.createSymbol(series, n, series.getData().get(i), i);
            if (symbol != null) {
                if (this.shouldAnimate()) {
                    symbol.setOpacity(0.0);
                }
                this.getPlotChildren().add(symbol);
                if (this.shouldAnimate()) {
                    list.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)symbol.opacityProperty(), (T)0) }));
                    list.add(new KeyFrame(Duration.millis(200.0), new KeyValue[] { new KeyValue((WritableValue<T>)symbol.opacityProperty(), (T)1) }));
                }
            }
        }
        if (this.shouldAnimate()) {
            this.animate((KeyFrame[])list.toArray(new KeyFrame[list.size()]));
        }
    }
    
    @Override
    protected void seriesRemoved(final Series<X, Y> series) {
        this.seriesYMultiplierMap.remove(series);
        if (this.shouldAnimate()) {
            (this.seriesRemoveTimeline = new Timeline(this.createSeriesRemoveTimeLine(series, 900L))).play();
        }
        else {
            this.getPlotChildren().remove(series.getNode());
            final Iterator<Data> iterator = series.getData().iterator();
            while (iterator.hasNext()) {
                this.getPlotChildren().remove(iterator.next().getNode());
            }
            this.removeSeriesFromDisplay(series);
        }
    }
    
    @Override
    protected void layoutPlotChildren() {
        final ArrayList<LineTo> list = new ArrayList<LineTo>(this.getDataSize());
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Series<Object, Object> series = this.getData().get(i);
            final DoubleProperty doubleProperty = this.seriesYMultiplierMap.get(series);
            final Node node = series.getNode();
            if (node instanceof Path) {
                AreaChart.makePaths((XYChart<Object, Object>)this, series, list, null, (Path)node, doubleProperty.get(), this.getAxisSortingPolicy());
            }
        }
    }
    
    @Override
    void dataBeingRemovedIsAdded(final Data data, final Series series) {
        if (this.fadeSymbolTransition != null) {
            this.fadeSymbolTransition.setOnFinished(null);
            this.fadeSymbolTransition.stop();
        }
        if (this.dataRemoveTimeline != null) {
            this.dataRemoveTimeline.setOnFinished(null);
            this.dataRemoveTimeline.stop();
        }
        final Node node = data.getNode();
        if (node != null) {
            this.getPlotChildren().remove(node);
        }
        data.setSeries(null);
        this.removeDataItemFromDisplay(series, data);
        final Double n = this.XYValueMap.get(data);
        if (n != null) {
            data.setYValue(n);
            data.setCurrentY(n);
        }
        this.XYValueMap.clear();
    }
    
    @Override
    void seriesBeingRemovedIsAdded(final Series<X, Y> series) {
        if (this.seriesRemoveTimeline != null) {
            this.seriesRemoveTimeline.setOnFinished(null);
            this.seriesRemoveTimeline.stop();
            this.getPlotChildren().remove(series.getNode());
            final Iterator<Data> iterator = series.getData().iterator();
            while (iterator.hasNext()) {
                this.getPlotChildren().remove(iterator.next().getNode());
            }
            this.removeSeriesFromDisplay(series);
        }
    }
    
    private Timeline createDataRemoveTimeline(final Data<X, Y> data, final Node node, final Series<X, Y> series) {
        final Timeline timeline = new Timeline();
        this.XYValueMap.put(data, ((Number)data.getYValue()).doubleValue());
        timeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getCurrentY()), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getCurrentX()) }), new KeyFrame(Duration.millis(500.0), p3 -> {
            if (node != null) {
                this.getPlotChildren().remove(node);
            }
            this.removeDataItemFromDisplay(series, data);
            this.XYValueMap.clear();
            return;
        }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getYValue(), Interpolator.EASE_BOTH), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
        return timeline;
    }
    
    private Node createSymbol(final Series<X, Y> series, final int n, final Data<X, Y> data, final int n2) {
        Node node = data.getNode();
        if (node == null && this.getCreateSymbols()) {
            node = new StackPane();
            node.setAccessibleRole(AccessibleRole.TEXT);
            node.setAccessibleRoleDescription("Point");
            node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
            data.setNode(node);
        }
        if (node != null) {
            node.getStyleClass().addAll(new String[] { "chart-line-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n2), series.defaultColorStyleClass });
        }
        return node;
    }
    
    @Override
    Legend.LegendItem createLegendItemForSeries(final Series<X, Y> series, final int n) {
        final Legend.LegendItem legendItem = new Legend.LegendItem(series.getName());
        legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-line-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), series.defaultColorStyleClass });
        return legendItem;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<LineChart<?, ?>, Boolean> CREATE_SYMBOLS;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            CREATE_SYMBOLS = new CssMetaData<LineChart<?, ?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final LineChart<?, ?> lineChart) {
                    return ((LineChart<Object, Object>)lineChart).createSymbols == null || !((LineChart<Object, Object>)lineChart).createSymbols.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final LineChart<?, ?> lineChart) {
                    return (StyleableProperty<Boolean>)lineChart.createSymbolsProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(XYChart.getClassCssMetaData());
            list.add(StyleableProperties.CREATE_SYMBOLS);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    public enum SortingPolicy
    {
        NONE, 
        X_AXIS, 
        Y_AXIS;
    }
}
