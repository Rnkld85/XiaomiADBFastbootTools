// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import javafx.beans.property.StringPropertyBase;
import javafx.collections.FXCollections;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.Observable;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.css.Styleable;
import javafx.scene.shape.ClosePath;
import javafx.scene.shape.PathElement;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.animation.Interpolator;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import java.util.Iterator;
import javafx.geometry.Orientation;
import javafx.geometry.Side;
import javafx.css.CssMetaData;
import javafx.css.StyleableBooleanProperty;
import com.sun.javafx.collections.NonIterableChange;
import java.util.Collections;
import javafx.beans.property.ObjectPropertyBase;
import java.util.Collection;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.HashMap;
import javafx.scene.Node;
import javafx.beans.property.BooleanProperty;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ListChangeListener;
import com.sun.javafx.charts.Legend;
import java.util.List;
import javafx.scene.shape.Rectangle;
import javafx.scene.Group;
import javafx.scene.layout.Region;
import javafx.scene.shape.Path;
import javafx.scene.shape.Line;
import java.util.Map;
import java.util.BitSet;

public abstract class XYChart<X, Y> extends Chart
{
    private final BitSet colorBits;
    static String DEFAULT_COLOR;
    final Map<Series<X, Y>, Integer> seriesColorMap;
    private boolean rangeValid;
    private final Line verticalZeroLine;
    private final Line horizontalZeroLine;
    private final Path verticalGridLines;
    private final Path horizontalGridLines;
    private final Path horizontalRowFill;
    private final Path verticalRowFill;
    private final Region plotBackground;
    private final Group plotArea;
    private final Group plotContent;
    private final Rectangle plotAreaClip;
    private final List<Series<X, Y>> displayedSeries;
    private Legend legend;
    private final ListChangeListener<Series<X, Y>> seriesChanged;
    private final Axis<X> xAxis;
    private final Axis<Y> yAxis;
    private ObjectProperty<ObservableList<Series<X, Y>>> data;
    private BooleanProperty verticalGridLinesVisible;
    private BooleanProperty horizontalGridLinesVisible;
    private BooleanProperty alternativeColumnFillVisible;
    private BooleanProperty alternativeRowFillVisible;
    private BooleanProperty verticalZeroLineVisible;
    private BooleanProperty horizontalZeroLineVisible;
    
    public Axis<X> getXAxis() {
        return this.xAxis;
    }
    
    public Axis<Y> getYAxis() {
        return this.yAxis;
    }
    
    public final ObservableList<Series<X, Y>> getData() {
        return this.data.getValue();
    }
    
    public final void setData(final ObservableList<Series<X, Y>> value) {
        this.data.setValue(value);
    }
    
    public final ObjectProperty<ObservableList<Series<X, Y>>> dataProperty() {
        return this.data;
    }
    
    public final boolean getVerticalGridLinesVisible() {
        return this.verticalGridLinesVisible.get();
    }
    
    public final void setVerticalGridLinesVisible(final boolean b) {
        this.verticalGridLinesVisible.set(b);
    }
    
    public final BooleanProperty verticalGridLinesVisibleProperty() {
        return this.verticalGridLinesVisible;
    }
    
    public final boolean isHorizontalGridLinesVisible() {
        return this.horizontalGridLinesVisible.get();
    }
    
    public final void setHorizontalGridLinesVisible(final boolean b) {
        this.horizontalGridLinesVisible.set(b);
    }
    
    public final BooleanProperty horizontalGridLinesVisibleProperty() {
        return this.horizontalGridLinesVisible;
    }
    
    public final boolean isAlternativeColumnFillVisible() {
        return this.alternativeColumnFillVisible.getValue();
    }
    
    public final void setAlternativeColumnFillVisible(final boolean b) {
        this.alternativeColumnFillVisible.setValue(b);
    }
    
    public final BooleanProperty alternativeColumnFillVisibleProperty() {
        return this.alternativeColumnFillVisible;
    }
    
    public final boolean isAlternativeRowFillVisible() {
        return this.alternativeRowFillVisible.getValue();
    }
    
    public final void setAlternativeRowFillVisible(final boolean b) {
        this.alternativeRowFillVisible.setValue(b);
    }
    
    public final BooleanProperty alternativeRowFillVisibleProperty() {
        return this.alternativeRowFillVisible;
    }
    
    public final boolean isVerticalZeroLineVisible() {
        return this.verticalZeroLineVisible.get();
    }
    
    public final void setVerticalZeroLineVisible(final boolean b) {
        this.verticalZeroLineVisible.set(b);
    }
    
    public final BooleanProperty verticalZeroLineVisibleProperty() {
        return this.verticalZeroLineVisible;
    }
    
    public final boolean isHorizontalZeroLineVisible() {
        return this.horizontalZeroLineVisible.get();
    }
    
    public final void setHorizontalZeroLineVisible(final boolean b) {
        this.horizontalZeroLineVisible.set(b);
    }
    
    public final BooleanProperty horizontalZeroLineVisibleProperty() {
        return this.horizontalZeroLineVisible;
    }
    
    protected ObservableList<Node> getPlotChildren() {
        return this.plotContent.getChildren();
    }
    
    public XYChart(final Axis<X> xAxis, final Axis<Y> yAxis) {
        this.colorBits = new BitSet(8);
        this.seriesColorMap = new HashMap<Series<X, Y>, Integer>();
        this.rangeValid = false;
        this.verticalZeroLine = new Line();
        this.horizontalZeroLine = new Line();
        this.verticalGridLines = new Path();
        this.horizontalGridLines = new Path();
        this.horizontalRowFill = new Path();
        this.verticalRowFill = new Path();
        this.plotBackground = new Region();
        this.plotArea = new Group() {
            @Override
            public void requestLayout() {
            }
        };
        this.plotContent = new Group();
        this.plotAreaClip = new Rectangle();
        this.displayedSeries = new ArrayList<Series<X, Y>>();
        this.legend = new Legend();
        final List list;
        HashSet<Series<X, Y>> set;
        final Iterator<Series<X, Y>> iterator;
        final Iterator<Series<X, Y>> iterator2;
        Series<X, Y> series3;
        int n = 0;
        Series<Object, Object> series4;
        final int bitIndex;
        this.seriesChanged = (change -> {
            change.getList();
            while (change.next()) {
                if (change.wasPermutated()) {
                    this.displayedSeries.sort((series, series2) -> list.indexOf(series2) - list.indexOf(series));
                }
                if (change.getRemoved().size() > 0) {
                    this.updateLegend();
                }
                set = new HashSet<Series<X, Y>>(this.displayedSeries);
                set.removeAll(change.getRemoved());
                change.getAddedSubList().iterator();
                while (iterator.hasNext()) {
                    if (!set.add(iterator.next())) {
                        throw new IllegalArgumentException("Duplicate series added");
                    }
                }
                change.getRemoved().iterator();
                while (iterator2.hasNext()) {
                    series3 = iterator2.next();
                    series3.setToRemove = true;
                    this.seriesRemoved(series3);
                }
                change.getFrom();
                while (n < change.getTo() && !change.wasPermutated()) {
                    series4 = change.getList().get(n);
                    series4.setChart(this);
                    if (series4.setToRemove) {
                        series4.setToRemove = false;
                        series4.getChart().seriesBeingRemovedIsAdded(series4);
                    }
                    this.displayedSeries.add((Series<X, Y>)series4);
                    this.colorBits.nextClearBit(0);
                    this.colorBits.set(bitIndex, true);
                    series4.defaultColorStyleClass = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;I)Ljava/lang/String;, XYChart.DEFAULT_COLOR, bitIndex % 8);
                    this.seriesColorMap.put((Series<X, Y>)series4, bitIndex % 8);
                    this.seriesAdded((Series<X, Y>)series4, n);
                    ++n;
                }
                if (change.getFrom() < change.getTo()) {
                    this.updateLegend();
                }
                this.seriesChanged(change);
            }
            this.invalidateRange();
            this.requestChartLayout();
            return;
        });
        this.data = new ObjectPropertyBase<ObservableList<Series<X, Y>>>() {
            private ObservableList<Series<X, Y>> old;
            
            @Override
            protected void invalidated() {
                final ObservableList<Series<X, Y>> old = this.getValue();
                if (old == this.old) {
                    return;
                }
                int n = -1;
                if (this.old != null) {
                    this.old.removeListener(XYChart.this.seriesChanged);
                    if (old != null && this.old.size() > 0) {
                        n = (this.old.get(0).getChart().getAnimated() ? 1 : 2);
                        this.old.get(0).getChart().setAnimated(false);
                    }
                }
                if (old != null) {
                    old.addListener(XYChart.this.seriesChanged);
                }
                if (this.old != null || old != null) {
                    final Object o = (this.old != null) ? this.old : Collections.emptyList();
                    final int n2 = (old != null) ? old.size() : 0;
                    if (n2 > 0 || !((List)o).isEmpty()) {
                        XYChart.this.seriesChanged.onChanged(new NonIterableChange<Series<X, Y>>(0, n2, old) {
                            @Override
                            public List<Series<X, Y>> getRemoved() {
                                return (List<Series<X, Y>>)o;
                            }
                            
                            @Override
                            protected int[] getPermutation() {
                                return new int[0];
                            }
                        });
                    }
                }
                else if (this.old != null && this.old.size() > 0) {
                    XYChart.this.seriesChanged.onChanged(new NonIterableChange<Series<X, Y>>(0, 0, old) {
                        @Override
                        public List<Series<X, Y>> getRemoved() {
                            return ObjectPropertyBase.this.old;
                        }
                        
                        @Override
                        protected int[] getPermutation() {
                            return new int[0];
                        }
                    });
                }
                if (old != null && old.size() > 0 && n != -1) {
                    old.get(0).getChart().setAnimated(n == 1);
                }
                this.old = old;
            }
            
            @Override
            public Object getBean() {
                return XYChart.this;
            }
            
            @Override
            public String getName() {
                return "data";
            }
        };
        this.verticalGridLinesVisible = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                XYChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return XYChart.this;
            }
            
            @Override
            public String getName() {
                return "verticalGridLinesVisible";
            }
            
            @Override
            public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
                return StyleableProperties.VERTICAL_GRID_LINE_VISIBLE;
            }
        };
        this.horizontalGridLinesVisible = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                XYChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return XYChart.this;
            }
            
            @Override
            public String getName() {
                return "horizontalGridLinesVisible";
            }
            
            @Override
            public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
                return StyleableProperties.HORIZONTAL_GRID_LINE_VISIBLE;
            }
        };
        this.alternativeColumnFillVisible = new StyleableBooleanProperty(false) {
            @Override
            protected void invalidated() {
                XYChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return XYChart.this;
            }
            
            @Override
            public String getName() {
                return "alternativeColumnFillVisible";
            }
            
            @Override
            public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
                return StyleableProperties.ALTERNATIVE_COLUMN_FILL_VISIBLE;
            }
        };
        this.alternativeRowFillVisible = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                XYChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return XYChart.this;
            }
            
            @Override
            public String getName() {
                return "alternativeRowFillVisible";
            }
            
            @Override
            public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
                return StyleableProperties.ALTERNATIVE_ROW_FILL_VISIBLE;
            }
        };
        this.verticalZeroLineVisible = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                XYChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return XYChart.this;
            }
            
            @Override
            public String getName() {
                return "verticalZeroLineVisible";
            }
            
            @Override
            public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
                return StyleableProperties.VERTICAL_ZERO_LINE_VISIBLE;
            }
        };
        this.horizontalZeroLineVisible = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                XYChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return XYChart.this;
            }
            
            @Override
            public String getName() {
                return "horizontalZeroLineVisible";
            }
            
            @Override
            public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
                return StyleableProperties.HORIZONTAL_ZERO_LINE_VISIBLE;
            }
        };
        this.xAxis = xAxis;
        if (xAxis.getSide() == null) {
            xAxis.setSide(Side.BOTTOM);
        }
        xAxis.setEffectiveOrientation(Orientation.HORIZONTAL);
        this.yAxis = yAxis;
        if (yAxis.getSide() == null) {
            yAxis.setSide(Side.LEFT);
        }
        yAxis.setEffectiveOrientation(Orientation.VERTICAL);
        xAxis.autoRangingProperty().addListener((p0, p1, p2) -> this.updateAxisRange());
        yAxis.autoRangingProperty().addListener((p0, p1, p2) -> this.updateAxisRange());
        this.getChartChildren().addAll(this.plotBackground, this.plotArea, xAxis, yAxis);
        this.plotArea.setAutoSizeChildren(false);
        this.plotContent.setAutoSizeChildren(false);
        this.plotAreaClip.setSmooth(false);
        this.plotArea.setClip(this.plotAreaClip);
        this.plotArea.getChildren().addAll(this.verticalRowFill, this.horizontalRowFill, this.verticalGridLines, this.horizontalGridLines, this.verticalZeroLine, this.horizontalZeroLine, this.plotContent);
        this.plotContent.getStyleClass().setAll("plot-content");
        this.plotBackground.getStyleClass().setAll("chart-plot-background");
        this.verticalRowFill.getStyleClass().setAll("chart-alternative-column-fill");
        this.horizontalRowFill.getStyleClass().setAll("chart-alternative-row-fill");
        this.verticalGridLines.getStyleClass().setAll("chart-vertical-grid-lines");
        this.horizontalGridLines.getStyleClass().setAll("chart-horizontal-grid-lines");
        this.verticalZeroLine.getStyleClass().setAll("chart-vertical-zero-line");
        this.horizontalZeroLine.getStyleClass().setAll("chart-horizontal-zero-line");
        this.plotContent.setManaged(false);
        this.plotArea.setManaged(false);
        this.animatedProperty().addListener((p0, p1, b) -> {
            if (this.getXAxis() != null) {
                this.getXAxis().setAnimated(b);
            }
            if (this.getYAxis() != null) {
                this.getYAxis().setAnimated(b);
            }
            return;
        });
        this.setLegend(this.legend);
    }
    
    final int getDataSize() {
        final ObservableList<Series<X, Y>> data = this.getData();
        return (data != null) ? data.size() : 0;
    }
    
    private void seriesNameChanged() {
        this.updateLegend();
        this.requestChartLayout();
    }
    
    private void dataItemsChanged(final Series<X, Y> series, final List<Data<X, Y>> list, final int n, final int n2, final boolean b) {
        final Iterator<Data<X, Y>> iterator = list.iterator();
        while (iterator.hasNext()) {
            this.dataItemRemoved(iterator.next(), series);
        }
        for (int i = n; i < n2; ++i) {
            this.dataItemAdded(series, i, (Data<X, Y>)series.getData().get(i));
        }
        this.invalidateRange();
        this.requestChartLayout();
    }
    
    private <T> void dataValueChanged(final Data<X, Y> data, final T t, final ObjectProperty<T> objectProperty) {
        if (objectProperty.get() != t) {
            this.invalidateRange();
        }
        this.dataItemChanged(data);
        if (this.shouldAnimate()) {
            this.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)objectProperty, objectProperty.get()) }), new KeyFrame(Duration.millis(700.0), new KeyValue[] { new KeyValue((WritableValue<T>)objectProperty, (T)t, Interpolator.EASE_BOTH) }));
        }
        else {
            objectProperty.set(t);
            this.requestChartLayout();
        }
    }
    
    protected void updateLegend() {
        final ArrayList<Legend.LegendItem> all = new ArrayList<Legend.LegendItem>();
        if (this.getData() != null) {
            for (int i = 0; i < this.getData().size(); ++i) {
                all.add(this.createLegendItemForSeries((Series<X, Y>)this.getData().get(i), i));
            }
        }
        this.legend.getItems().setAll(all);
        if (all.size() > 0) {
            if (this.getLegend() == null) {
                this.setLegend(this.legend);
            }
        }
        else {
            this.setLegend(null);
        }
    }
    
    Legend.LegendItem createLegendItemForSeries(final Series<X, Y> series, final int n) {
        return new Legend.LegendItem(series.getName());
    }
    
    void seriesBeingRemovedIsAdded(final Series<X, Y> series) {
    }
    
    void dataBeingRemovedIsAdded(final Data<X, Y> data, final Series<X, Y> series) {
    }
    
    protected abstract void dataItemAdded(final Series<X, Y> p0, final int p1, final Data<X, Y> p2);
    
    protected abstract void dataItemRemoved(final Data<X, Y> p0, final Series<X, Y> p1);
    
    protected abstract void dataItemChanged(final Data<X, Y> p0);
    
    protected abstract void seriesAdded(final Series<X, Y> p0, final int p1);
    
    protected abstract void seriesRemoved(final Series<X, Y> p0);
    
    protected void seriesChanged(final ListChangeListener.Change<? extends Series> change) {
    }
    
    private void invalidateRange() {
        this.rangeValid = false;
    }
    
    protected void updateAxisRange() {
        final Axis<X> xAxis = this.getXAxis();
        final Axis<Y> yAxis = this.getYAxis();
        List<X> list = null;
        List<Y> list2 = null;
        if (xAxis.isAutoRanging()) {
            list = new ArrayList<X>();
        }
        if (yAxis.isAutoRanging()) {
            list2 = new ArrayList<Y>();
        }
        if (list != null || list2 != null) {
            final Iterator<Series> iterator = this.getData().iterator();
            while (iterator.hasNext()) {
                for (final Data<Object, Y> data : iterator.next().getData()) {
                    if (list != null) {
                        list.add((X)data.getXValue());
                    }
                    if (list2 != null) {
                        list2.add((Y)data.getYValue());
                    }
                }
            }
            if (list != null) {
                xAxis.invalidateRange(list);
            }
            if (list2 != null) {
                yAxis.invalidateRange(list2);
            }
        }
    }
    
    protected abstract void layoutPlotChildren();
    
    @Override
    protected final void layoutChartChildren(double snapPositionY, double snapPositionX, final double n, final double n2) {
        if (this.getData() == null) {
            return;
        }
        if (!this.rangeValid) {
            this.rangeValid = true;
            if (this.getData() != null) {
                this.updateAxisRange();
            }
        }
        snapPositionY = this.snapPositionY(snapPositionY);
        snapPositionX = this.snapPositionX(snapPositionX);
        final Axis<X> xAxis = this.getXAxis();
        final ObservableList<Axis.TickMark<X>> tickMarks = xAxis.getTickMarks();
        final Axis<Y> yAxis = this.getYAxis();
        final ObservableList<Axis.TickMark<Y>> tickMarks2 = yAxis.getTickMarks();
        if (xAxis == null || yAxis == null) {
            return;
        }
        double snapSizeX = 0.0;
        double a = 30.0;
        double prefWidth = 0.0;
        double snapSizeY = 0.0;
        for (int i = 0; i < 5; ++i) {
            snapSizeY = this.snapSizeY(n2 - a);
            if (snapSizeY < 0.0) {
                snapSizeY = 0.0;
            }
            prefWidth = yAxis.prefWidth(snapSizeY);
            snapSizeX = this.snapSizeX(n - prefWidth);
            if (snapSizeX < 0.0) {
                snapSizeX = 0.0;
            }
            final double prefHeight = xAxis.prefHeight(snapSizeX);
            if (prefHeight == a) {
                break;
            }
            a = prefHeight;
        }
        final double ceil = Math.ceil(snapSizeX);
        final double ceil2 = Math.ceil(a);
        final double ceil3 = Math.ceil(prefWidth);
        final double ceil4 = Math.ceil(snapSizeY);
        double n3 = 0.0;
        switch (xAxis.getEffectiveSide()) {
            case TOP: {
                xAxis.setVisible(true);
                n3 = snapPositionY + 1.0;
                snapPositionY += ceil2;
                break;
            }
            case BOTTOM: {
                xAxis.setVisible(true);
                n3 = snapPositionY + ceil4;
                break;
            }
        }
        double n4 = 0.0;
        switch (yAxis.getEffectiveSide()) {
            case LEFT: {
                yAxis.setVisible(true);
                n4 = snapPositionX + 1.0;
                snapPositionX += ceil3;
                break;
            }
            case RIGHT: {
                yAxis.setVisible(true);
                n4 = snapPositionX + ceil;
                break;
            }
        }
        xAxis.resizeRelocate(snapPositionX, n3, ceil, ceil2);
        yAxis.resizeRelocate(n4, snapPositionY, ceil3, ceil4);
        xAxis.requestAxisLayout();
        xAxis.layout();
        yAxis.requestAxisLayout();
        yAxis.layout();
        this.layoutPlotChildren();
        final double zeroPosition = xAxis.getZeroPosition();
        final double zeroPosition2 = yAxis.getZeroPosition();
        if (Double.isNaN(zeroPosition) || !this.isVerticalZeroLineVisible()) {
            this.verticalZeroLine.setVisible(false);
        }
        else {
            this.verticalZeroLine.setStartX(snapPositionX + zeroPosition + 0.5);
            this.verticalZeroLine.setStartY(snapPositionY);
            this.verticalZeroLine.setEndX(snapPositionX + zeroPosition + 0.5);
            this.verticalZeroLine.setEndY(snapPositionY + ceil4);
            this.verticalZeroLine.setVisible(true);
        }
        if (Double.isNaN(zeroPosition2) || !this.isHorizontalZeroLineVisible()) {
            this.horizontalZeroLine.setVisible(false);
        }
        else {
            this.horizontalZeroLine.setStartX(snapPositionX);
            this.horizontalZeroLine.setStartY(snapPositionY + zeroPosition2 + 0.5);
            this.horizontalZeroLine.setEndX(snapPositionX + ceil);
            this.horizontalZeroLine.setEndY(snapPositionY + zeroPosition2 + 0.5);
            this.horizontalZeroLine.setVisible(true);
        }
        this.plotBackground.resizeRelocate(snapPositionX, snapPositionY, ceil, ceil4);
        this.plotAreaClip.setX(snapPositionX);
        this.plotAreaClip.setY(snapPositionY);
        this.plotAreaClip.setWidth(ceil + 1.0);
        this.plotAreaClip.setHeight(ceil4 + 1.0);
        this.plotContent.setLayoutX(snapPositionX);
        this.plotContent.setLayoutY(snapPositionY);
        this.plotContent.requestLayout();
        this.verticalGridLines.getElements().clear();
        if (this.getVerticalGridLinesVisible()) {
            for (int j = 0; j < tickMarks.size(); ++j) {
                final double displayPosition = xAxis.getDisplayPosition((X)tickMarks.get(j).getValue());
                if ((displayPosition != zeroPosition || !this.isVerticalZeroLineVisible()) && displayPosition > 0.0 && displayPosition <= ceil) {
                    this.verticalGridLines.getElements().add(new MoveTo(snapPositionX + displayPosition + 0.5, snapPositionY));
                    this.verticalGridLines.getElements().add(new LineTo(snapPositionX + displayPosition + 0.5, snapPositionY + ceil4));
                }
            }
        }
        this.horizontalGridLines.getElements().clear();
        if (this.isHorizontalGridLinesVisible()) {
            for (int k = 0; k < tickMarks2.size(); ++k) {
                final double displayPosition2 = yAxis.getDisplayPosition((Y)tickMarks2.get(k).getValue());
                if ((displayPosition2 != zeroPosition2 || !this.isHorizontalZeroLineVisible()) && displayPosition2 >= 0.0 && displayPosition2 < ceil4) {
                    this.horizontalGridLines.getElements().add(new MoveTo(snapPositionX, snapPositionY + displayPosition2 + 0.5));
                    this.horizontalGridLines.getElements().add(new LineTo(snapPositionX + ceil, snapPositionY + displayPosition2 + 0.5));
                }
            }
        }
        this.verticalRowFill.getElements().clear();
        if (this.isAlternativeColumnFillVisible()) {
            final ArrayList<Comparable> list = new ArrayList<Comparable>();
            final ArrayList<Comparable> list2 = new ArrayList<Comparable>();
            for (int l = 0; l < tickMarks.size(); ++l) {
                final double displayPosition3 = xAxis.getDisplayPosition((X)tickMarks.get(l).getValue());
                if (displayPosition3 == zeroPosition) {
                    list.add(displayPosition3);
                    list2.add(displayPosition3);
                }
                else if (displayPosition3 < zeroPosition) {
                    list.add(displayPosition3);
                }
                else {
                    list2.add(displayPosition3);
                }
            }
            Collections.sort(list);
            Collections.sort(list2);
            for (int n5 = 1; n5 < list.size(); n5 += 2) {
                if (n5 + 1 < list.size()) {
                    final double doubleValue = list.get(n5);
                    final double doubleValue2 = list.get(n5 + 1);
                    this.verticalRowFill.getElements().addAll(new MoveTo(snapPositionX + doubleValue, snapPositionY), new LineTo(snapPositionX + doubleValue, snapPositionY + ceil4), new LineTo(snapPositionX + doubleValue2, snapPositionY + ceil4), new LineTo(snapPositionX + doubleValue2, snapPositionY), new ClosePath());
                }
            }
            for (int n6 = 0; n6 < list2.size(); n6 += 2) {
                if (n6 + 1 < list2.size()) {
                    final double doubleValue3 = list2.get(n6);
                    final double doubleValue4 = list2.get(n6 + 1);
                    this.verticalRowFill.getElements().addAll(new MoveTo(snapPositionX + doubleValue3, snapPositionY), new LineTo(snapPositionX + doubleValue3, snapPositionY + ceil4), new LineTo(snapPositionX + doubleValue4, snapPositionY + ceil4), new LineTo(snapPositionX + doubleValue4, snapPositionY), new ClosePath());
                }
            }
        }
        this.horizontalRowFill.getElements().clear();
        if (this.isAlternativeRowFillVisible()) {
            final ArrayList<Comparable> list3 = new ArrayList<Comparable>();
            final ArrayList<Comparable> list4 = new ArrayList<Comparable>();
            for (int n7 = 0; n7 < tickMarks2.size(); ++n7) {
                final double displayPosition4 = yAxis.getDisplayPosition((Y)tickMarks2.get(n7).getValue());
                if (displayPosition4 == zeroPosition2) {
                    list3.add(displayPosition4);
                    list4.add(displayPosition4);
                }
                else if (displayPosition4 < zeroPosition2) {
                    list3.add(displayPosition4);
                }
                else {
                    list4.add(displayPosition4);
                }
            }
            Collections.sort(list3);
            Collections.sort(list4);
            for (int n8 = 1; n8 < list3.size(); n8 += 2) {
                if (n8 + 1 < list3.size()) {
                    final double doubleValue5 = list3.get(n8);
                    final double doubleValue6 = list3.get(n8 + 1);
                    this.horizontalRowFill.getElements().addAll(new MoveTo(snapPositionX, snapPositionY + doubleValue5), new LineTo(snapPositionX + ceil, snapPositionY + doubleValue5), new LineTo(snapPositionX + ceil, snapPositionY + doubleValue6), new LineTo(snapPositionX, snapPositionY + doubleValue6), new ClosePath());
                }
            }
            for (int n9 = 0; n9 < list4.size(); n9 += 2) {
                if (n9 + 1 < list4.size()) {
                    final double doubleValue7 = list4.get(n9);
                    final double doubleValue8 = list4.get(n9 + 1);
                    this.horizontalRowFill.getElements().addAll(new MoveTo(snapPositionX, snapPositionY + doubleValue7), new LineTo(snapPositionX + ceil, snapPositionY + doubleValue7), new LineTo(snapPositionX + ceil, snapPositionY + doubleValue8), new LineTo(snapPositionX, snapPositionY + doubleValue8), new ClosePath());
                }
            }
        }
    }
    
    int getSeriesIndex(final Series<X, Y> series) {
        return this.displayedSeries.indexOf(series);
    }
    
    int getSeriesSize() {
        return this.displayedSeries.size();
    }
    
    protected final void removeSeriesFromDisplay(final Series<X, Y> series) {
        if (series != null) {
            series.setToRemove = false;
        }
        ((Series<Object, Object>)series).setChart(null);
        this.displayedSeries.remove(series);
        this.colorBits.clear(this.seriesColorMap.remove(series));
    }
    
    protected final Iterator<Series<X, Y>> getDisplayedSeriesIterator() {
        return Collections.unmodifiableList((List<? extends Series<X, Y>>)this.displayedSeries).iterator();
    }
    
    final KeyFrame[] createSeriesRemoveTimeLine(final Series<X, Y> series, final long n) {
        final ArrayList<Node> list = new ArrayList<Node>();
        list.add(series.getNode());
        for (final Data data : series.getData()) {
            if (data.getNode() != null) {
                list.add(data.getNode());
            }
        }
        final KeyValue[] array = new KeyValue[list.size()];
        final KeyValue[] array2 = new KeyValue[list.size()];
        for (int i = 0; i < list.size(); ++i) {
            array[i] = new KeyValue((WritableValue<T>)((Node)list.get(i)).opacityProperty(), (T)1);
            array2[i] = new KeyValue((WritableValue<T>)((Node)list.get(i)).opacityProperty(), (T)0);
        }
        return new KeyFrame[] { new KeyFrame(Duration.ZERO, array), new KeyFrame(Duration.millis((double)n), p2 -> {
                this.getPlotChildren().removeAll(list);
                this.removeSeriesFromDisplay(series);
            }, array2) };
    }
    
    protected final X getCurrentDisplayedXValue(final Data<X, Y> data) {
        return data.getCurrentX();
    }
    
    protected final void setCurrentDisplayedXValue(final Data<X, Y> data, final X currentX) {
        data.setCurrentX(currentX);
    }
    
    protected final ObjectProperty<X> currentDisplayedXValueProperty(final Data<X, Y> data) {
        return data.currentXProperty();
    }
    
    protected final Y getCurrentDisplayedYValue(final Data<X, Y> data) {
        return data.getCurrentY();
    }
    
    protected final void setCurrentDisplayedYValue(final Data<X, Y> data, final Y currentY) {
        data.setCurrentY(currentY);
    }
    
    protected final ObjectProperty<Y> currentDisplayedYValueProperty(final Data<X, Y> data) {
        return data.currentYProperty();
    }
    
    protected final Object getCurrentDisplayedExtraValue(final Data<X, Y> data) {
        return data.getCurrentExtraValue();
    }
    
    protected final void setCurrentDisplayedExtraValue(final Data<X, Y> data, final Object currentExtraValue) {
        data.setCurrentExtraValue(currentExtraValue);
    }
    
    protected final ObjectProperty<Object> currentDisplayedExtraValueProperty(final Data<X, Y> data) {
        return (ObjectProperty<Object>)data.currentExtraValueProperty();
    }
    
    protected final Iterator<Data<X, Y>> getDisplayedDataIterator(final Series<X, Y> series) {
        return Collections.unmodifiableList((List<? extends Data<X, Y>>)((Series<Object, Object>)series).displayedData).iterator();
    }
    
    protected final void removeDataItemFromDisplay(final Series<X, Y> series, final Data<X, Y> data) {
        ((Series<Object, Object>)series).removeDataItemRef(data);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    static {
        XYChart.DEFAULT_COLOR = "default-color";
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<XYChart<?, ?>, Boolean> HORIZONTAL_GRID_LINE_VISIBLE;
        private static final CssMetaData<XYChart<?, ?>, Boolean> HORIZONTAL_ZERO_LINE_VISIBLE;
        private static final CssMetaData<XYChart<?, ?>, Boolean> ALTERNATIVE_ROW_FILL_VISIBLE;
        private static final CssMetaData<XYChart<?, ?>, Boolean> VERTICAL_GRID_LINE_VISIBLE;
        private static final CssMetaData<XYChart<?, ?>, Boolean> VERTICAL_ZERO_LINE_VISIBLE;
        private static final CssMetaData<XYChart<?, ?>, Boolean> ALTERNATIVE_COLUMN_FILL_VISIBLE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            HORIZONTAL_GRID_LINE_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final XYChart<?, ?> xyChart) {
                    return ((XYChart<Object, Object>)xyChart).horizontalGridLinesVisible == null || !((XYChart<Object, Object>)xyChart).horizontalGridLinesVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final XYChart<?, ?> xyChart) {
                    return (StyleableProperty<Boolean>)xyChart.horizontalGridLinesVisibleProperty();
                }
            };
            HORIZONTAL_ZERO_LINE_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final XYChart<?, ?> xyChart) {
                    return ((XYChart<Object, Object>)xyChart).horizontalZeroLineVisible == null || !((XYChart<Object, Object>)xyChart).horizontalZeroLineVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final XYChart<?, ?> xyChart) {
                    return (StyleableProperty<Boolean>)xyChart.horizontalZeroLineVisibleProperty();
                }
            };
            ALTERNATIVE_ROW_FILL_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final XYChart<?, ?> xyChart) {
                    return ((XYChart<Object, Object>)xyChart).alternativeRowFillVisible == null || !((XYChart<Object, Object>)xyChart).alternativeRowFillVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final XYChart<?, ?> xyChart) {
                    return (StyleableProperty<Boolean>)xyChart.alternativeRowFillVisibleProperty();
                }
            };
            VERTICAL_GRID_LINE_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final XYChart<?, ?> xyChart) {
                    return ((XYChart<Object, Object>)xyChart).verticalGridLinesVisible == null || !((XYChart<Object, Object>)xyChart).verticalGridLinesVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final XYChart<?, ?> xyChart) {
                    return (StyleableProperty<Boolean>)xyChart.verticalGridLinesVisibleProperty();
                }
            };
            VERTICAL_ZERO_LINE_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final XYChart<?, ?> xyChart) {
                    return ((XYChart<Object, Object>)xyChart).verticalZeroLineVisible == null || !((XYChart<Object, Object>)xyChart).verticalZeroLineVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final XYChart<?, ?> xyChart) {
                    return (StyleableProperty<Boolean>)xyChart.verticalZeroLineVisibleProperty();
                }
            };
            ALTERNATIVE_COLUMN_FILL_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final XYChart<?, ?> xyChart) {
                    return ((XYChart<Object, Object>)xyChart).alternativeColumnFillVisible == null || !((XYChart<Object, Object>)xyChart).alternativeColumnFillVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final XYChart<?, ?> xyChart) {
                    return (StyleableProperty<Boolean>)xyChart.alternativeColumnFillVisibleProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Chart.getClassCssMetaData());
            list.add(StyleableProperties.HORIZONTAL_GRID_LINE_VISIBLE);
            list.add(StyleableProperties.HORIZONTAL_ZERO_LINE_VISIBLE);
            list.add(StyleableProperties.ALTERNATIVE_ROW_FILL_VISIBLE);
            list.add(StyleableProperties.VERTICAL_GRID_LINE_VISIBLE);
            list.add(StyleableProperties.VERTICAL_ZERO_LINE_VISIBLE);
            list.add(StyleableProperties.ALTERNATIVE_COLUMN_FILL_VISIBLE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    public static final class Data<X, Y>
    {
        private boolean setToRemove;
        private Series<X, Y> series;
        private ObjectProperty<X> xValue;
        private ObjectProperty<Y> yValue;
        private ObjectProperty<Object> extraValue;
        private ObjectProperty<Node> node;
        private ObjectProperty<X> currentX;
        private ObjectProperty<Y> currentY;
        private ObjectProperty<Object> currentExtraValue;
        
        void setSeries(final Series<X, Y> series) {
            this.series = series;
        }
        
        public final X getXValue() {
            return this.xValue.get();
        }
        
        public final void setXValue(final X value) {
            this.xValue.set(value);
            if (this.currentX.get() == null || (this.series != null && this.series.getChart() == null)) {
                this.currentX.setValue(value);
            }
        }
        
        public final ObjectProperty<X> XValueProperty() {
            return this.xValue;
        }
        
        public final Y getYValue() {
            return this.yValue.get();
        }
        
        public final void setYValue(final Y value) {
            this.yValue.set(value);
            if (this.currentY.get() == null || (this.series != null && this.series.getChart() == null)) {
                this.currentY.setValue(value);
            }
        }
        
        public final ObjectProperty<Y> YValueProperty() {
            return this.yValue;
        }
        
        public final Object getExtraValue() {
            return this.extraValue.get();
        }
        
        public final void setExtraValue(final Object o) {
            this.extraValue.set(o);
        }
        
        public final ObjectProperty<Object> extraValueProperty() {
            return this.extraValue;
        }
        
        public final Node getNode() {
            return this.node.get();
        }
        
        public final void setNode(final Node node) {
            this.node.set(node);
        }
        
        public final ObjectProperty<Node> nodeProperty() {
            return this.node;
        }
        
        final X getCurrentX() {
            return this.currentX.get();
        }
        
        final void setCurrentX(final X x) {
            this.currentX.set(x);
        }
        
        final ObjectProperty<X> currentXProperty() {
            return this.currentX;
        }
        
        final Y getCurrentY() {
            return this.currentY.get();
        }
        
        final void setCurrentY(final Y y) {
            this.currentY.set(y);
        }
        
        final ObjectProperty<Y> currentYProperty() {
            return this.currentY;
        }
        
        final Object getCurrentExtraValue() {
            return this.currentExtraValue.getValue();
        }
        
        final void setCurrentExtraValue(final Object value) {
            this.currentExtraValue.setValue(value);
        }
        
        final ObjectProperty<Object> currentExtraValueProperty() {
            return this.currentExtraValue;
        }
        
        public Data() {
            this.setToRemove = false;
            this.xValue = new SimpleObjectProperty<X>((Object)this, "XValue") {
                @Override
                protected void invalidated() {
                    if (Data.this.series != null) {
                        final XYChart<Object, Object> chart = Data.this.series.getChart();
                        if (chart != null) {
                            chart.dataValueChanged(Data.this, ((ObjectPropertyBase<Object>)this).get(), Data.this.currentXProperty());
                        }
                    }
                    else {
                        Data.this.setCurrentX(this.get());
                    }
                }
            };
            this.yValue = new SimpleObjectProperty<Y>((Object)this, "YValue") {
                @Override
                protected void invalidated() {
                    if (Data.this.series != null) {
                        final XYChart<Object, Object> chart = Data.this.series.getChart();
                        if (chart != null) {
                            chart.dataValueChanged(Data.this, ((ObjectPropertyBase<Object>)this).get(), Data.this.currentYProperty());
                        }
                    }
                    else {
                        Data.this.setCurrentY(this.get());
                    }
                }
            };
            this.extraValue = new SimpleObjectProperty<Object>((Object)this, "extraValue") {
                @Override
                protected void invalidated() {
                    if (Data.this.series != null) {
                        final XYChart<Object, Object> chart = Data.this.series.getChart();
                        if (chart != null) {
                            chart.dataValueChanged(Data.this, this.get(), Data.this.currentExtraValueProperty());
                        }
                    }
                }
            };
            this.node = new SimpleObjectProperty<Node>((Object)this, "node") {
                @Override
                protected void invalidated() {
                    final Node node = this.get();
                    if (node != null) {
                        node.accessibleTextProperty().unbind();
                        node.accessibleTextProperty().bind((ObservableValue<?>)new StringBinding() {
                            {
                                this.bind(Data.this.currentXProperty(), Data.this.currentYProperty());
                            }
                            
                            @Override
                            protected String computeValue() {
                                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;, (Data.this.series != null) ? Data.this.series.getName() : "", Data.this.getCurrentX(), Data.this.getCurrentY());
                            }
                        });
                    }
                }
            };
            this.currentX = new SimpleObjectProperty<X>(this, "currentX");
            this.currentY = new SimpleObjectProperty<Y>(this, "currentY");
            this.currentExtraValue = new SimpleObjectProperty<Object>(this, "currentExtraValue");
        }
        
        public Data(final X x, final Y y) {
            this.setToRemove = false;
            this.xValue = new SimpleObjectProperty<X>((Object)this, "XValue") {
                @Override
                protected void invalidated() {
                    if (Data.this.series != null) {
                        final XYChart<Object, Object> chart = Data.this.series.getChart();
                        if (chart != null) {
                            chart.dataValueChanged(Data.this, ((ObjectPropertyBase<Object>)this).get(), Data.this.currentXProperty());
                        }
                    }
                    else {
                        Data.this.setCurrentX(this.get());
                    }
                }
            };
            this.yValue = new SimpleObjectProperty<Y>((Object)this, "YValue") {
                @Override
                protected void invalidated() {
                    if (Data.this.series != null) {
                        final XYChart<Object, Object> chart = Data.this.series.getChart();
                        if (chart != null) {
                            chart.dataValueChanged(Data.this, ((ObjectPropertyBase<Object>)this).get(), Data.this.currentYProperty());
                        }
                    }
                    else {
                        Data.this.setCurrentY(this.get());
                    }
                }
            };
            this.extraValue = new SimpleObjectProperty<Object>((Object)this, "extraValue") {
                @Override
                protected void invalidated() {
                    if (Data.this.series != null) {
                        final XYChart<Object, Object> chart = Data.this.series.getChart();
                        if (chart != null) {
                            chart.dataValueChanged(Data.this, this.get(), Data.this.currentExtraValueProperty());
                        }
                    }
                }
            };
            this.node = new SimpleObjectProperty<Node>((Object)this, "node") {
                @Override
                protected void invalidated() {
                    final Node node = this.get();
                    if (node != null) {
                        node.accessibleTextProperty().unbind();
                        node.accessibleTextProperty().bind((ObservableValue<?>)new StringBinding() {
                            {
                                this.bind(Data.this.currentXProperty(), Data.this.currentYProperty());
                            }
                            
                            @Override
                            protected String computeValue() {
                                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;, (Data.this.series != null) ? Data.this.series.getName() : "", Data.this.getCurrentX(), Data.this.getCurrentY());
                            }
                        });
                    }
                }
            };
            this.currentX = new SimpleObjectProperty<X>(this, "currentX");
            this.currentY = new SimpleObjectProperty<Y>(this, "currentY");
            this.currentExtraValue = new SimpleObjectProperty<Object>(this, "currentExtraValue");
            this.setXValue(x);
            this.setYValue(y);
            this.setCurrentX(x);
            this.setCurrentY(y);
        }
        
        public Data(final X x, final Y y, final Object o) {
            this.setToRemove = false;
            this.xValue = new SimpleObjectProperty<X>((Object)this, "XValue") {
                @Override
                protected void invalidated() {
                    if (Data.this.series != null) {
                        final XYChart<Object, Object> chart = Data.this.series.getChart();
                        if (chart != null) {
                            chart.dataValueChanged(Data.this, ((ObjectPropertyBase<Object>)this).get(), Data.this.currentXProperty());
                        }
                    }
                    else {
                        Data.this.setCurrentX(this.get());
                    }
                }
            };
            this.yValue = new SimpleObjectProperty<Y>((Object)this, "YValue") {
                @Override
                protected void invalidated() {
                    if (Data.this.series != null) {
                        final XYChart<Object, Object> chart = Data.this.series.getChart();
                        if (chart != null) {
                            chart.dataValueChanged(Data.this, ((ObjectPropertyBase<Object>)this).get(), Data.this.currentYProperty());
                        }
                    }
                    else {
                        Data.this.setCurrentY(this.get());
                    }
                }
            };
            this.extraValue = new SimpleObjectProperty<Object>((Object)this, "extraValue") {
                @Override
                protected void invalidated() {
                    if (Data.this.series != null) {
                        final XYChart<Object, Object> chart = Data.this.series.getChart();
                        if (chart != null) {
                            chart.dataValueChanged(Data.this, this.get(), Data.this.currentExtraValueProperty());
                        }
                    }
                }
            };
            this.node = new SimpleObjectProperty<Node>((Object)this, "node") {
                @Override
                protected void invalidated() {
                    final Node node = this.get();
                    if (node != null) {
                        node.accessibleTextProperty().unbind();
                        node.accessibleTextProperty().bind((ObservableValue<?>)new StringBinding() {
                            {
                                this.bind(Data.this.currentXProperty(), Data.this.currentYProperty());
                            }
                            
                            @Override
                            protected String computeValue() {
                                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;, (Data.this.series != null) ? Data.this.series.getName() : "", Data.this.getCurrentX(), Data.this.getCurrentY());
                            }
                        });
                    }
                }
            };
            this.currentX = new SimpleObjectProperty<X>(this, "currentX");
            this.currentY = new SimpleObjectProperty<Y>(this, "currentY");
            this.currentExtraValue = new SimpleObjectProperty<Object>(this, "currentExtraValue");
            this.setXValue(x);
            this.setYValue(y);
            this.setExtraValue(o);
            this.setCurrentX(x);
            this.setCurrentY(y);
            this.setCurrentExtraValue(o);
        }
        
        @Override
        public String toString() {
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;, this.getXValue(), this.getYValue(), this.getExtraValue());
        }
    }
    
    public static final class Series<X, Y>
    {
        String defaultColorStyleClass;
        boolean setToRemove;
        private List<Data<X, Y>> displayedData;
        private final ListChangeListener<Data<X, Y>> dataChangeListener;
        private final ReadOnlyObjectWrapper<XYChart<X, Y>> chart;
        private final StringProperty name;
        private ObjectProperty<Node> node;
        private final ObjectProperty<ObservableList<Data<X, Y>>> data;
        
        public final XYChart<X, Y> getChart() {
            return this.chart.get();
        }
        
        private void setChart(final XYChart<X, Y> xyChart) {
            this.chart.set(xyChart);
        }
        
        public final ReadOnlyObjectProperty<XYChart<X, Y>> chartProperty() {
            return this.chart.getReadOnlyProperty();
        }
        
        public final String getName() {
            return this.name.get();
        }
        
        public final void setName(final String s) {
            this.name.set(s);
        }
        
        public final StringProperty nameProperty() {
            return this.name;
        }
        
        public final Node getNode() {
            return this.node.get();
        }
        
        public final void setNode(final Node node) {
            this.node.set(node);
        }
        
        public final ObjectProperty<Node> nodeProperty() {
            return this.node;
        }
        
        public final ObservableList<Data<X, Y>> getData() {
            return this.data.getValue();
        }
        
        public final void setData(final ObservableList<Data<X, Y>> value) {
            this.data.setValue(value);
        }
        
        public final ObjectProperty<ObservableList<Data<X, Y>>> dataProperty() {
            return this.data;
        }
        
        public Series() {
            this(FXCollections.observableArrayList());
        }
        
        public Series(final ObservableList<Data<X, Y>> data) {
            this.setToRemove = false;
            this.displayedData = new ArrayList<Data<X, Y>>();
            this.dataChangeListener = new ListChangeListener<Data<X, Y>>() {
                @Override
                public void onChanged(final Change<? extends Data<X, Y>> change) {
                    final ObservableList<? extends Data<X, Y>> list = change.getList();
                    final XYChart<Object, Object> chart = Series.this.getChart();
                    while (change.next()) {
                        if (chart != null) {
                            if (change.wasPermutated()) {
                                final List list2;
                                Series.this.displayedData.sort((data, data2) -> list2.indexOf(data2) - list2.indexOf(data));
                                return;
                            }
                            final HashSet<Data> set = new HashSet<Data>(Series.this.displayedData);
                            set.removeAll(change.getRemoved());
                            final Iterator<? extends Data<X, Y>> iterator = change.getAddedSubList().iterator();
                            while (iterator.hasNext()) {
                                if (!set.add((Data)iterator.next())) {
                                    throw new IllegalArgumentException("Duplicate data added");
                                }
                            }
                            final Iterator<? extends Data<X, Y>> iterator2 = change.getRemoved().iterator();
                            while (iterator2.hasNext()) {
                                ((Data<Object, Object>)iterator2.next()).setToRemove = true;
                            }
                            if (change.getAddedSize() > 0) {
                                for (final Data<Object, Object> data3 : change.getAddedSubList()) {
                                    if (data3.setToRemove) {
                                        if (chart != null) {
                                            chart.dataBeingRemovedIsAdded(data3, Series.this);
                                        }
                                        data3.setToRemove = false;
                                    }
                                }
                                final Iterator<? extends Data<X, Y>> iterator4 = change.getAddedSubList().iterator();
                                while (iterator4.hasNext()) {
                                    ((Data)iterator4.next()).setSeries(Series.this);
                                }
                                if (change.getFrom() == 0) {
                                    Series.this.displayedData.addAll(0, change.getAddedSubList());
                                }
                                else {
                                    Series.this.displayedData.addAll(Series.this.displayedData.indexOf(list.get(change.getFrom() - 1)) + 1, change.getAddedSubList());
                                }
                            }
                            chart.dataItemsChanged(Series.this, change.getRemoved(), change.getFrom(), change.getTo(), change.wasPermutated());
                        }
                        else {
                            final HashSet<Data> set2 = new HashSet<Data>();
                            final Iterator<Data> iterator5 = list.iterator();
                            while (iterator5.hasNext()) {
                                if (!set2.add(iterator5.next())) {
                                    throw new IllegalArgumentException("Duplicate data added");
                                }
                            }
                            final Iterator<? extends Data<X, Y>> iterator6 = change.getAddedSubList().iterator();
                            while (iterator6.hasNext()) {
                                ((Data)iterator6.next()).setSeries(Series.this);
                            }
                        }
                    }
                }
            };
            this.chart = new ReadOnlyObjectWrapper<XYChart<X, Y>>((Object)this, "chart") {
                @Override
                protected void invalidated() {
                    if (this.get() == null) {
                        Series.this.displayedData.clear();
                    }
                    else {
                        Series.this.displayedData.addAll(Series.this.getData());
                    }
                }
            };
            this.name = new StringPropertyBase() {
                @Override
                protected void invalidated() {
                    this.get();
                    if (Series.this.getChart() != null) {
                        Series.this.getChart().seriesNameChanged();
                    }
                }
                
                @Override
                public Object getBean() {
                    return Series.this;
                }
                
                @Override
                public String getName() {
                    return "name";
                }
            };
            this.node = new SimpleObjectProperty<Node>(this, "node");
            this.data = new ObjectPropertyBase<ObservableList<Data<X, Y>>>() {
                private ObservableList<Data<X, Y>> old;
                
                @Override
                protected void invalidated() {
                    final ObservableList<Data<X, Y>> old = this.getValue();
                    if (this.old != null) {
                        this.old.removeListener(Series.this.dataChangeListener);
                    }
                    if (old != null) {
                        old.addListener(Series.this.dataChangeListener);
                    }
                    if (this.old != null || old != null) {
                        final Object o = (this.old != null) ? this.old : Collections.emptyList();
                        final int n = (old != null) ? old.size() : 0;
                        if (n > 0 || !((List)o).isEmpty()) {
                            Series.this.dataChangeListener.onChanged(new NonIterableChange<Data<X, Y>>(0, n, old) {
                                @Override
                                public List<Data<X, Y>> getRemoved() {
                                    return (List<Data<X, Y>>)o;
                                }
                                
                                @Override
                                protected int[] getPermutation() {
                                    return new int[0];
                                }
                            });
                        }
                    }
                    else if (this.old != null && this.old.size() > 0) {
                        Series.this.dataChangeListener.onChanged(new NonIterableChange<Data<X, Y>>(0, 0, old) {
                            @Override
                            public List<Data<X, Y>> getRemoved() {
                                return ObjectPropertyBase.this.old;
                            }
                            
                            @Override
                            protected int[] getPermutation() {
                                return new int[0];
                            }
                        });
                    }
                    this.old = old;
                }
                
                @Override
                public Object getBean() {
                    return Series.this;
                }
                
                @Override
                public String getName() {
                    return "data";
                }
            };
            this.setData(data);
            final Iterator<Data> iterator = data.iterator();
            while (iterator.hasNext()) {
                iterator.next().setSeries(this);
            }
        }
        
        public Series(final String name, final ObservableList<Data<X, Y>> list) {
            this(list);
            this.setName(name);
        }
        
        @Override
        public String toString() {
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.getName());
        }
        
        private void removeDataItemRef(final Data<X, Y> data) {
            if (data != null) {
                ((Data<Object, Object>)data).setToRemove = false;
            }
            this.displayedData.remove(data);
        }
        
        int getItemIndex(final Data<X, Y> data) {
            return this.displayedData.indexOf(data);
        }
        
        Data<X, Y> getItem(final int n) {
            return this.displayedData.get(n);
        }
        
        int getDataSize() {
            return this.displayedData.size();
        }
    }
}
