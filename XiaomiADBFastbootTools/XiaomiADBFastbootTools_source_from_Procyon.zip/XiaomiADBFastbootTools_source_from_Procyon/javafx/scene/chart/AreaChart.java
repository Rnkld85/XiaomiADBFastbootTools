// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.event.ActionEvent;
import javafx.css.Styleable;
import com.sun.javafx.charts.Legend;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import javafx.scene.AccessibleRole;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.PathElement;
import javafx.scene.shape.ClosePath;
import java.util.Collection;
import java.util.Collections;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.LineTo;
import javafx.animation.Timeline;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.Group;
import javafx.scene.shape.Path;
import javafx.collections.ListChangeListener;
import javafx.animation.Interpolator;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.animation.KeyFrame;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import javafx.css.CssMetaData;
import javafx.scene.Node;
import javafx.css.StyleableBooleanProperty;
import java.util.HashMap;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.beans.NamedArg;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import java.util.Map;

public class AreaChart<X, Y> extends XYChart<X, Y>
{
    private Map<Series<X, Y>, DoubleProperty> seriesYMultiplierMap;
    private BooleanProperty createSymbols;
    
    public final boolean getCreateSymbols() {
        return this.createSymbols.getValue();
    }
    
    public final void setCreateSymbols(final boolean b) {
        this.createSymbols.setValue(b);
    }
    
    public final BooleanProperty createSymbolsProperty() {
        return this.createSymbols;
    }
    
    public AreaChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2) {
        this(axis, axis2, FXCollections.observableArrayList());
    }
    
    public AreaChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2, @NamedArg("data") final ObservableList<Series<X, Y>> data) {
        super(axis, axis2);
        this.seriesYMultiplierMap = new HashMap<Series<X, Y>, DoubleProperty>();
        this.createSymbols = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                for (int i = 0; i < AreaChart.this.getData().size(); ++i) {
                    final Series series = AreaChart.this.getData().get(i);
                    for (int j = 0; j < series.getData().size(); ++j) {
                        final Data data = (Data)series.getData().get(j);
                        final Node node = data.getNode();
                        if (this.get() && node == null) {
                            final Node access$000 = AreaChart.this.createSymbol(series, AreaChart.this.getData().indexOf(series), data, j);
                            if (null != access$000) {
                                AreaChart.this.getPlotChildren().add(access$000);
                            }
                        }
                        else if (!this.get() && node != null) {
                            AreaChart.this.getPlotChildren().remove(node);
                            data.setNode(null);
                        }
                    }
                }
                AreaChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return this;
            }
            
            @Override
            public String getName() {
                return "createSymbols";
            }
            
            @Override
            public CssMetaData<AreaChart<?, ?>, Boolean> getCssMetaData() {
                return StyleableProperties.CREATE_SYMBOLS;
            }
        };
        this.setData(data);
    }
    
    private static double doubleValue(final Number n) {
        return doubleValue(n, 0.0);
    }
    
    private static double doubleValue(final Number n, final double n2) {
        return (n == null) ? n2 : n.doubleValue();
    }
    
    @Override
    protected void updateAxisRange() {
        final Axis<X> xAxis = this.getXAxis();
        final Axis<Y> yAxis = this.getYAxis();
        List<X> list = null;
        List<Y> list2 = null;
        if (xAxis.isAutoRanging()) {
            list = new ArrayList<X>();
        }
        if (yAxis.isAutoRanging()) {
            list2 = new ArrayList<Y>();
        }
        if (list != null || list2 != null) {
            final Iterator<Series> iterator = this.getData().iterator();
            while (iterator.hasNext()) {
                for (final Data<Object, Y> data : iterator.next().getData()) {
                    if (list != null) {
                        list.add((X)data.getXValue());
                    }
                    if (list2 != null) {
                        list2.add((Y)data.getYValue());
                    }
                }
            }
            if (list != null && (list.size() != 1 || this.getXAxis().toNumericValue(list.get(0)) != 0.0)) {
                xAxis.invalidateRange(list);
            }
            if (list2 != null && (list2.size() != 1 || this.getYAxis().toNumericValue(list2.get(0)) != 0.0)) {
                yAxis.invalidateRange(list2);
            }
        }
    }
    
    @Override
    protected void dataItemAdded(final Series<X, Y> series, final int n, final Data<X, Y> data) {
        final Node symbol = this.createSymbol(series, this.getData().indexOf(series), data, n);
        if (this.shouldAnimate()) {
            boolean b = false;
            if (n > 0 && n < series.getData().size() - 1) {
                b = true;
                final Data<X, Y> data2 = series.getData().get(n - 1);
                final Data<X, Y> data3 = series.getData().get(n + 1);
                final double numericValue = this.getXAxis().toNumericValue(data2.getXValue());
                final double numericValue2 = this.getYAxis().toNumericValue(data2.getYValue());
                final double numericValue3 = this.getXAxis().toNumericValue(data3.getXValue());
                final double numericValue4 = this.getYAxis().toNumericValue(data3.getYValue());
                final double numericValue5 = this.getXAxis().toNumericValue(data.getXValue());
                this.getYAxis().toNumericValue(data.getYValue());
                data.setCurrentY(this.getYAxis().toRealValue((numericValue4 - numericValue2) / (numericValue3 - numericValue) * numericValue5 + (numericValue3 * numericValue2 - numericValue4 * numericValue) / (numericValue3 - numericValue)));
                data.setCurrentX(this.getXAxis().toRealValue(numericValue5));
            }
            else if (n == 0 && series.getData().size() > 1) {
                b = true;
                data.setCurrentX(series.getData().get(1).getXValue());
                data.setCurrentY(series.getData().get(1).getYValue());
            }
            else if (n == series.getData().size() - 1 && series.getData().size() > 1) {
                b = true;
                final int n2 = series.getData().size() - 2;
                data.setCurrentX(((Data<X, Y>)series.getData().get(n2)).getXValue());
                data.setCurrentY(((Data<X, Y>)series.getData().get(n2)).getYValue());
            }
            if (symbol != null) {
                symbol.setOpacity(0.0);
                this.getPlotChildren().add(symbol);
                final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), symbol);
                fadeTransition.setToValue(1.0);
                fadeTransition.play();
            }
            if (b) {
                final Node node;
                this.animate(new KeyFrame(Duration.ZERO, p1 -> {
                    if (node != null && !this.getPlotChildren().contains(node)) {
                        this.getPlotChildren().add(node);
                    }
                }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getCurrentY()), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getCurrentX()) }), new KeyFrame(Duration.millis(800.0), new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getYValue(), Interpolator.EASE_BOTH), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
            }
        }
        else if (symbol != null) {
            this.getPlotChildren().add(symbol);
        }
    }
    
    @Override
    protected void dataItemRemoved(final Data<X, Y> data, final Series<X, Y> series) {
        final Node node = data.getNode();
        if (node != null) {
            node.focusTraversableProperty().unbind();
        }
        final int itemIndex = series.getItemIndex(data);
        if (this.shouldAnimate()) {
            boolean b = false;
            final int dataSize = series.getDataSize();
            final int size = series.getData().size();
            if (itemIndex > 0 && itemIndex < dataSize - 1) {
                b = true;
                final Data<X, Y> item = series.getItem(itemIndex - 1);
                final Data<X, Y> item2 = series.getItem(itemIndex + 1);
                final double numericValue = this.getXAxis().toNumericValue(item.getXValue());
                final double numericValue2 = this.getYAxis().toNumericValue(item.getYValue());
                final double numericValue3 = this.getXAxis().toNumericValue(item2.getXValue());
                final double numericValue4 = this.getYAxis().toNumericValue(item2.getYValue());
                final double numericValue5 = this.getXAxis().toNumericValue(data.getXValue());
                final double numericValue6 = this.getYAxis().toNumericValue(data.getYValue());
                final double n = (numericValue4 - numericValue2) / (numericValue3 - numericValue) * numericValue5 + (numericValue3 * numericValue2 - numericValue4 * numericValue) / (numericValue3 - numericValue);
                data.setCurrentX(this.getXAxis().toRealValue(numericValue5));
                data.setCurrentY(this.getYAxis().toRealValue(numericValue6));
                data.setXValue(this.getXAxis().toRealValue(numericValue5));
                data.setYValue(this.getYAxis().toRealValue(n));
            }
            else if (itemIndex == 0 && size > 1) {
                b = true;
                data.setXValue(series.getData().get(0).getXValue());
                data.setYValue(series.getData().get(0).getYValue());
            }
            else if (itemIndex == dataSize - 1 && size > 1) {
                b = true;
                final int n2 = size - 1;
                data.setXValue(((Data<X, Y>)series.getData().get(n2)).getXValue());
                data.setYValue(((Data<X, Y>)series.getData().get(n2)).getYValue());
            }
            else if (node != null) {
                node.setOpacity(0.0);
                final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), node);
                fadeTransition.setToValue(0.0);
                fadeTransition.setOnFinished(p3 -> {
                    this.getPlotChildren().remove(node);
                    this.removeDataItemFromDisplay(series, data);
                    return;
                });
                fadeTransition.play();
            }
            else {
                data.setSeries(null);
                this.removeDataItemFromDisplay(series, data);
            }
            if (b) {
                final Object o;
                this.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getCurrentY()), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getCurrentX()) }), new KeyFrame(Duration.millis(800.0), p3 -> {
                    data.setSeries(null);
                    this.getPlotChildren().remove(o);
                    this.removeDataItemFromDisplay(series, data);
                }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getYValue(), Interpolator.EASE_BOTH), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
            }
        }
        else {
            data.setSeries(null);
            this.getPlotChildren().remove(node);
            this.removeDataItemFromDisplay(series, data);
        }
    }
    
    @Override
    protected void dataItemChanged(final Data<X, Y> data) {
    }
    
    @Override
    protected void seriesChanged(final ListChangeListener.Change<? extends Series> change) {
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Series series = this.getData().get(i);
            final Path path = ((Group)series.getNode()).getChildren().get(1);
            final Path path2 = ((Group)series.getNode()).getChildren().get(0);
            path.getStyleClass().setAll(new String[] { "chart-series-area-line", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), series.defaultColorStyleClass });
            path2.getStyleClass().setAll(new String[] { "chart-series-area-fill", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), series.defaultColorStyleClass });
            for (int j = 0; j < series.getData().size(); ++j) {
                final Node node = ((Data)series.getData().get(j)).getNode();
                if (node != null) {
                    node.getStyleClass().setAll(new String[] { "chart-area-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, j), series.defaultColorStyleClass });
                }
            }
        }
    }
    
    @Override
    protected void seriesAdded(final Series<X, Y> series, final int n) {
        final Path path = new Path();
        final Path path2 = new Path();
        path.setStrokeLineJoin(StrokeLineJoin.BEVEL);
        final Group node = new Group(new Node[] { path2, path });
        series.setNode(node);
        final SimpleDoubleProperty simpleDoubleProperty = new SimpleDoubleProperty(this, "seriesYMultiplier");
        this.seriesYMultiplierMap.put(series, simpleDoubleProperty);
        if (this.shouldAnimate()) {
            simpleDoubleProperty.setValue(0.0);
        }
        else {
            simpleDoubleProperty.setValue(1.0);
        }
        this.getPlotChildren().add(node);
        final ArrayList<KeyFrame> list = new ArrayList<KeyFrame>();
        if (this.shouldAnimate()) {
            list.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)node.opacityProperty(), (T)0), new KeyValue((WritableValue<T>)simpleDoubleProperty, (T)0) }));
            list.add(new KeyFrame(Duration.millis(200.0), new KeyValue[] { new KeyValue((WritableValue<T>)node.opacityProperty(), (T)1) }));
            list.add(new KeyFrame(Duration.millis(500.0), new KeyValue[] { new KeyValue((WritableValue<T>)simpleDoubleProperty, (T)1) }));
        }
        for (int i = 0; i < series.getData().size(); ++i) {
            final Node symbol = this.createSymbol(series, n, series.getData().get(i), i);
            if (symbol != null) {
                if (this.shouldAnimate()) {
                    symbol.setOpacity(0.0);
                    this.getPlotChildren().add(symbol);
                    list.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)symbol.opacityProperty(), (T)0) }));
                    list.add(new KeyFrame(Duration.millis(200.0), new KeyValue[] { new KeyValue((WritableValue<T>)symbol.opacityProperty(), (T)1) }));
                }
                else {
                    this.getPlotChildren().add(symbol);
                }
            }
        }
        if (this.shouldAnimate()) {
            this.animate((KeyFrame[])list.toArray(new KeyFrame[list.size()]));
        }
    }
    
    @Override
    protected void seriesRemoved(final Series<X, Y> series) {
        this.seriesYMultiplierMap.remove(series);
        if (this.shouldAnimate()) {
            new Timeline(this.createSeriesRemoveTimeLine(series, 400L)).play();
        }
        else {
            this.getPlotChildren().remove(series.getNode());
            final Iterator<Data> iterator = series.getData().iterator();
            while (iterator.hasNext()) {
                this.getPlotChildren().remove(iterator.next().getNode());
            }
            this.removeSeriesFromDisplay(series);
        }
    }
    
    @Override
    protected void layoutPlotChildren() {
        final ArrayList<LineTo> list = new ArrayList<LineTo>(this.getDataSize());
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Series<Object, Object> series = this.getData().get(i);
            final DoubleProperty doubleProperty = this.seriesYMultiplierMap.get(series);
            final ObservableList<Node> children = ((Group)series.getNode()).getChildren();
            makePaths((XYChart<Object, Object>)this, series, list, (Path)children.get(0), (Path)children.get(1), doubleProperty.get(), LineChart.SortingPolicy.X_AXIS);
        }
    }
    
    static <X, Y> void makePaths(final XYChart<X, Y> xyChart, final Series<X, Y> series, final List<LineTo> list, final Path path, final Path path2, final double n, final LineChart.SortingPolicy sortingPolicy) {
        final Axis<X> xAxis = xyChart.getXAxis();
        final Axis<Y> yAxis = xyChart.getYAxis();
        final double n2 = path2.getStrokeWidth() / 2.0;
        final boolean b = sortingPolicy == LineChart.SortingPolicy.X_AXIS;
        final boolean b2 = sortingPolicy == LineChart.SortingPolicy.Y_AXIS;
        final double n3 = b ? (-n2) : Double.NEGATIVE_INFINITY;
        final double n4 = b ? (xAxis.getWidth() + n2) : Double.POSITIVE_INFINITY;
        final double n5 = b2 ? (-n2) : Double.NEGATIVE_INFINITY;
        final double n6 = b2 ? (yAxis.getHeight() + n2) : Double.POSITIVE_INFINITY;
        PathElement pathElement = null;
        PathElement pathElement2 = null;
        list.clear();
        final Iterator<Data<X, Y>> displayedDataIterator = xyChart.getDisplayedDataIterator(series);
        while (displayedDataIterator.hasNext()) {
            final Data<X, Y> data = displayedDataIterator.next();
            final double displayPosition = xAxis.getDisplayPosition(data.getCurrentX());
            final double displayPosition2 = yAxis.getDisplayPosition(yAxis.toRealValue(yAxis.toNumericValue(data.getCurrentY()) * n));
            final boolean b3 = Double.isNaN(displayPosition) || Double.isNaN(displayPosition2);
            final Node node = data.getNode();
            if (node != null) {
                final double prefWidth = node.prefWidth(-1.0);
                final double prefHeight = node.prefHeight(-1.0);
                if (b3) {
                    node.resizeRelocate(-prefWidth * 2.0, -prefHeight * 2.0, prefWidth, prefHeight);
                }
                else {
                    node.resizeRelocate(displayPosition - prefWidth / 2.0, displayPosition2 - prefHeight / 2.0, prefWidth, prefHeight);
                }
            }
            if (b3) {
                continue;
            }
            if (displayPosition < n3 || displayPosition2 < n5) {
                if (pathElement == null) {
                    pathElement = new LineTo(displayPosition, displayPosition2);
                }
                else {
                    if ((b || ((LineTo)pathElement).getX() > displayPosition) && (!b2 || ((LineTo)pathElement).getY() > displayPosition2)) {
                        continue;
                    }
                    ((LineTo)pathElement).setX(displayPosition);
                    ((LineTo)pathElement).setY(displayPosition2);
                }
            }
            else if (displayPosition <= n4 && displayPosition2 <= n6) {
                list.add((MoveTo)new LineTo(displayPosition, displayPosition2));
            }
            else if (pathElement2 == null) {
                pathElement2 = new LineTo(displayPosition, displayPosition2);
            }
            else {
                if ((b || displayPosition > ((LineTo)pathElement2).getX()) && (!b2 || displayPosition2 > ((LineTo)pathElement2).getY())) {
                    continue;
                }
                ((LineTo)pathElement2).setX(displayPosition);
                ((LineTo)pathElement2).setY(displayPosition2);
            }
        }
        if (!list.isEmpty() || pathElement != null || pathElement2 != null) {
            if (b) {
                Collections.sort((List<Object>)list, (lineTo, lineTo3) -> Double.compare(lineTo.getX(), lineTo3.getX()));
            }
            else if (b2) {
                Collections.sort((List<Object>)list, (lineTo2, lineTo4) -> Double.compare(lineTo2.getY(), lineTo4.getY()));
            }
            if (pathElement != null) {
                list.add(0, (MoveTo)pathElement);
            }
            if (pathElement2 != null) {
                list.add((MoveTo)pathElement2);
            }
            final LineTo lineTo5 = (LineTo)list.get(0);
            final LineTo lineTo6 = (LineTo)list.get(list.size() - 1);
            final double y = lineTo5.getY();
            final ObservableList<PathElement> elements = path2.getElements();
            elements.clear();
            elements.add(new MoveTo(lineTo5.getX(), y));
            elements.addAll((Collection<?>)list);
            if (path != null) {
                final ObservableList<PathElement> elements2 = path.getElements();
                elements2.clear();
                final double displayPosition3 = yAxis.getDisplayPosition(yAxis.toRealValue(0.0));
                elements2.add(new MoveTo(lineTo5.getX(), displayPosition3));
                elements2.addAll((Collection<?>)list);
                elements2.add(new LineTo(lineTo6.getX(), displayPosition3));
                elements2.add(new ClosePath());
            }
        }
    }
    
    private Node createSymbol(final Series<X, Y> series, final int n, final Data<X, Y> data, final int n2) {
        Node node = data.getNode();
        if (node == null && this.getCreateSymbols()) {
            node = new StackPane();
            node.setAccessibleRole(AccessibleRole.TEXT);
            node.setAccessibleRoleDescription("Point");
            node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
            data.setNode(node);
        }
        if (node != null) {
            node.getStyleClass().setAll(new String[] { "chart-area-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n2), series.defaultColorStyleClass });
        }
        return node;
    }
    
    @Override
    Legend.LegendItem createLegendItemForSeries(final Series<X, Y> series, final int n) {
        final Legend.LegendItem legendItem = new Legend.LegendItem(series.getName());
        legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-area-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), "area-legend-symbol", series.defaultColorStyleClass });
        return legendItem;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<AreaChart<?, ?>, Boolean> CREATE_SYMBOLS;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            CREATE_SYMBOLS = new CssMetaData<AreaChart<?, ?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final AreaChart<?, ?> areaChart) {
                    return ((AreaChart<Object, Object>)areaChart).createSymbols == null || !((AreaChart<Object, Object>)areaChart).createSymbols.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final AreaChart<?, ?> areaChart) {
                    return (StyleableProperty<Boolean>)areaChart.createSymbolsProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(XYChart.getClassCssMetaData());
            list.add(StyleableProperties.CREATE_SYMBOLS);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
