// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import javafx.css.converter.SizeConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.beans.Observable;
import javafx.beans.binding.StringBinding;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import javafx.scene.AccessibleRole;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.StringPropertyBase;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import java.util.Objects;
import javafx.css.Styleable;
import java.util.Collection;
import javafx.geometry.Side;
import javafx.scene.shape.ClosePath;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Shape;
import javafx.scene.shape.Arc;
import javafx.scene.transform.Scale;
import java.util.ArrayList;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.animation.FadeTransition;
import javafx.animation.Animation;
import javafx.scene.text.Text;
import javafx.geometry.NodeOrientation;
import javafx.scene.layout.Region;
import javafx.animation.Interpolator;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import java.util.Iterator;
import javafx.scene.Node;
import javafx.css.StyleableBooleanProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import com.sun.javafx.collections.NonIterableChange;
import java.util.Collections;
import javafx.beans.property.ObjectPropertyBase;
import javafx.collections.FXCollections;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.animation.Timeline;
import com.sun.javafx.charts.Legend;
import java.util.List;
import javafx.scene.shape.Path;
import java.util.BitSet;

public class PieChart extends Chart
{
    private static final int MIN_PIE_RADIUS = 25;
    private static final double LABEL_TICK_GAP = 6.0;
    private static final double LABEL_BALL_RADIUS = 2.0;
    private BitSet colorBits;
    private double pieRadius;
    private Data begin;
    private final Path labelLinePath;
    private List<LabelLayoutInfo> labelLayoutInfos;
    private Legend legend;
    private Data dataItemBeingRemoved;
    private Timeline dataRemoveTimeline;
    private final ListChangeListener<Data> dataChangeListener;
    private ObjectProperty<ObservableList<Data>> data;
    private DoubleProperty startAngle;
    private BooleanProperty clockwise;
    private DoubleProperty labelLineLength;
    private BooleanProperty labelsVisible;
    
    public final ObservableList<Data> getData() {
        return this.data.getValue();
    }
    
    public final void setData(final ObservableList<Data> value) {
        this.data.setValue(value);
    }
    
    public final ObjectProperty<ObservableList<Data>> dataProperty() {
        return this.data;
    }
    
    public final double getStartAngle() {
        return this.startAngle.getValue();
    }
    
    public final void setStartAngle(final double d) {
        this.startAngle.setValue(d);
    }
    
    public final DoubleProperty startAngleProperty() {
        return this.startAngle;
    }
    
    public final void setClockwise(final boolean b) {
        this.clockwise.setValue(b);
    }
    
    public final boolean isClockwise() {
        return this.clockwise.getValue();
    }
    
    public final BooleanProperty clockwiseProperty() {
        return this.clockwise;
    }
    
    public final double getLabelLineLength() {
        return this.labelLineLength.getValue();
    }
    
    public final void setLabelLineLength(final double d) {
        this.labelLineLength.setValue(d);
    }
    
    public final DoubleProperty labelLineLengthProperty() {
        return this.labelLineLength;
    }
    
    public final void setLabelsVisible(final boolean b) {
        this.labelsVisible.setValue(b);
    }
    
    public final boolean getLabelsVisible() {
        return this.labelsVisible.getValue();
    }
    
    public final BooleanProperty labelsVisibleProperty() {
        return this.labelsVisible;
    }
    
    public PieChart() {
        this(FXCollections.observableArrayList());
    }
    
    public PieChart(final ObservableList<Data> data) {
        this.colorBits = new BitSet(8);
        this.begin = null;
        this.labelLinePath = new Path() {
            @Override
            public boolean usesMirroring() {
                return false;
            }
        };
        this.labelLayoutInfos = null;
        this.legend = new Legend();
        this.dataItemBeingRemoved = null;
        this.dataRemoveTimeline = null;
        Data data2;
        int i = 0;
        Data begin;
        int j = 0;
        Data data3;
        Data begin2;
        int k = 0;
        final Iterator<Data> iterator;
        int l = 0;
        Data data4;
        int n = 0;
        this.dataChangeListener = (change -> {
            while (change.next()) {
                if (change.wasPermutated()) {
                    data2 = this.begin;
                    while (i < this.getData().size()) {
                        begin = this.getData().get(i);
                        this.updateDataItemStyleClass(begin, i);
                        if (i == 0) {
                            this.begin = begin;
                            data2 = this.begin;
                            this.begin.next = null;
                        }
                        else {
                            data2.next = begin;
                            begin.next = null;
                            data2 = begin;
                        }
                        ++i;
                    }
                    this.updateLegend();
                    this.requestChartLayout();
                    return;
                }
                else {
                    change.getFrom();
                    while (j < change.getTo()) {
                        data3 = this.getData().get(j);
                        data3.setChart(this);
                        if (this.begin == null) {
                            (this.begin = data3).next = null;
                        }
                        else if (j == 0) {
                            data3.next = this.begin;
                            this.begin = data3;
                        }
                        else {
                            begin2 = this.begin;
                            while (k < j - 1) {
                                begin2.next;
                                ++k;
                            }
                            data3.next = begin2.next;
                            begin2.next = data3;
                        }
                        ++j;
                    }
                    change.getRemoved().iterator();
                    while (iterator.hasNext()) {
                        this.dataItemRemoved(iterator.next());
                    }
                    change.getFrom();
                    while (l < change.getTo()) {
                        data4 = this.getData().get(l);
                        data4.defaultColorIndex = this.colorBits.nextClearBit(0);
                        this.colorBits.set(data4.defaultColorIndex);
                        this.dataItemAdded(data4, l);
                        ++l;
                    }
                    if (change.wasRemoved() || change.wasAdded()) {
                        while (n < this.getData().size()) {
                            this.updateDataItemStyleClass((Data)this.getData().get(n), n);
                            ++n;
                        }
                        this.updateLegend();
                    }
                    else {
                        continue;
                    }
                }
            }
            this.requestChartLayout();
            return;
        });
        this.data = new ObjectPropertyBase<ObservableList<Data>>() {
            private ObservableList<Data> old;
            
            @Override
            protected void invalidated() {
                final ObservableList<Data> old = this.getValue();
                if (this.old != null) {
                    this.old.removeListener(PieChart.this.dataChangeListener);
                }
                if (old != null) {
                    old.addListener(PieChart.this.dataChangeListener);
                }
                if (this.old != null || old != null) {
                    final Object o = (this.old != null) ? this.old : Collections.emptyList();
                    final int n = (old != null) ? old.size() : 0;
                    if (n > 0 || !((List)o).isEmpty()) {
                        PieChart.this.dataChangeListener.onChanged(new NonIterableChange<Data>(0, n, old) {
                            @Override
                            public List<Data> getRemoved() {
                                return (List<Data>)o;
                            }
                            
                            @Override
                            public boolean wasPermutated() {
                                return false;
                            }
                            
                            @Override
                            protected int[] getPermutation() {
                                return new int[0];
                            }
                        });
                    }
                }
                else if (this.old != null && this.old.size() > 0) {
                    PieChart.this.dataChangeListener.onChanged(new NonIterableChange<Data>(0, 0, old) {
                        @Override
                        public List<Data> getRemoved() {
                            return ObjectPropertyBase.this.old;
                        }
                        
                        @Override
                        public boolean wasPermutated() {
                            return false;
                        }
                        
                        @Override
                        protected int[] getPermutation() {
                            return new int[0];
                        }
                    });
                }
                this.old = old;
            }
            
            @Override
            public Object getBean() {
                return PieChart.this;
            }
            
            @Override
            public String getName() {
                return "data";
            }
        };
        this.startAngle = new StyleableDoubleProperty(0.0) {
            public void invalidated() {
                this.get();
                PieChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return PieChart.this;
            }
            
            @Override
            public String getName() {
                return "startAngle";
            }
            
            @Override
            public CssMetaData<PieChart, Number> getCssMetaData() {
                return StyleableProperties.START_ANGLE;
            }
        };
        this.clockwise = new StyleableBooleanProperty(true) {
            public void invalidated() {
                this.get();
                PieChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return PieChart.this;
            }
            
            @Override
            public String getName() {
                return "clockwise";
            }
            
            @Override
            public CssMetaData<PieChart, Boolean> getCssMetaData() {
                return StyleableProperties.CLOCKWISE;
            }
        };
        this.labelLineLength = new StyleableDoubleProperty(20.0) {
            public void invalidated() {
                this.get();
                PieChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return PieChart.this;
            }
            
            @Override
            public String getName() {
                return "labelLineLength";
            }
            
            @Override
            public CssMetaData<PieChart, Number> getCssMetaData() {
                return StyleableProperties.LABEL_LINE_LENGTH;
            }
        };
        this.labelsVisible = new StyleableBooleanProperty(true) {
            public void invalidated() {
                this.get();
                PieChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return PieChart.this;
            }
            
            @Override
            public String getName() {
                return "labelsVisible";
            }
            
            @Override
            public CssMetaData<PieChart, Boolean> getCssMetaData() {
                return StyleableProperties.LABELS_VISIBLE;
            }
        };
        this.getChartChildren().add(this.labelLinePath);
        this.labelLinePath.getStyleClass().add("chart-pie-label-line");
        this.setLegend(this.legend);
        this.setData(data);
        this.useChartContentMirroring = false;
    }
    
    private void dataNameChanged(final Data data) {
        data.textNode.setText(data.getName());
        this.requestChartLayout();
        this.updateLegend();
    }
    
    private void dataPieValueChanged(final Data data) {
        if (this.shouldAnimate()) {
            this.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentPieValueProperty(), (T)data.getCurrentPieValue()) }), new KeyFrame(Duration.millis(500.0), new KeyValue[] { new KeyValue((WritableValue<T>)data.currentPieValueProperty(), (T)data.getPieValue(), Interpolator.EASE_BOTH) }));
        }
        else {
            data.setCurrentPieValue(data.getPieValue());
            this.requestChartLayout();
        }
    }
    
    private Node createArcRegion(final Data data) {
        Node node = data.getNode();
        if (node == null) {
            node = new Region();
            node.setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
            node.setPickOnBounds(false);
            data.setNode(node);
        }
        return node;
    }
    
    private Text createPieLabel(final Data data) {
        final Text access$600 = data.textNode;
        access$600.setText(data.getName());
        return access$600;
    }
    
    private void updateDataItemStyleClass(final Data data, final int n) {
        final Node node = data.getNode();
        if (node != null) {
            node.getStyleClass().setAll(new String[] { "chart-pie", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, data.defaultColorIndex % 8) });
            if (data.getPieValue() < 0.0) {
                node.getStyleClass().add("negative");
            }
        }
    }
    
    private void dataItemAdded(final Data data, final int n) {
        final Node arcRegion = this.createArcRegion(data);
        final Text pieLabel = this.createPieLabel(data);
        data.getChart().getChartChildren().add(arcRegion);
        if (this.shouldAnimate()) {
            if (this.dataRemoveTimeline != null && this.dataRemoveTimeline.getStatus().equals(Animation.Status.RUNNING) && this.dataItemBeingRemoved == data) {
                this.dataRemoveTimeline.stop();
                this.dataRemoveTimeline = null;
                this.getChartChildren().remove(data.textNode);
                this.getChartChildren().remove(arcRegion);
                this.removeDataItemRef(data);
            }
            final Text text;
            final FadeTransition fadeTransition;
            this.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentPieValueProperty(), (T)data.getCurrentPieValue()), new KeyValue((WritableValue<T>)data.radiusMultiplierProperty(), (T)data.getRadiusMultiplier()) }), new KeyFrame(Duration.millis(500.0), p2 -> {
                text.setOpacity(0.0);
                if (data.getChart() == null) {
                    data.setChart(this);
                }
                data.getChart().getChartChildren().add(text);
                fadeTransition = new FadeTransition(Duration.millis(150.0), text);
                fadeTransition.setToValue(1.0);
                fadeTransition.play();
                return;
            }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentPieValueProperty(), (T)data.getPieValue(), Interpolator.EASE_BOTH), new KeyValue((WritableValue<T>)data.radiusMultiplierProperty(), (T)1, Interpolator.EASE_BOTH) }));
        }
        else {
            this.getChartChildren().add(pieLabel);
            data.setRadiusMultiplier(1.0);
            data.setCurrentPieValue(data.getPieValue());
        }
        for (int i = 0; i < this.getChartChildren().size(); ++i) {
            final Node node = this.getChartChildren().get(i);
            if (node instanceof Text) {
                node.toFront();
            }
        }
    }
    
    private void removeDataItemRef(final Data data) {
        if (this.begin == data) {
            this.begin = data.next;
        }
        else {
            Data data2;
            for (data2 = this.begin; data2 != null && data2.next != data; data2 = data2.next) {}
            if (data2 != null) {
                data2.next = data.next;
            }
        }
    }
    
    private Timeline createDataRemoveTimeline(final Data data) {
        data.getNode();
        final Timeline timeline = new Timeline();
        final Object o;
        final FadeTransition fadeTransition;
        timeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentPieValueProperty(), (T)data.getCurrentPieValue()), new KeyValue((WritableValue<T>)data.radiusMultiplierProperty(), (T)data.getRadiusMultiplier()) }), new KeyFrame(Duration.millis(500.0), p2 -> {
            this.colorBits.clear(data.defaultColorIndex);
            this.getChartChildren().remove(o);
            fadeTransition = new FadeTransition(Duration.millis(150.0), data.textNode);
            fadeTransition.setFromValue(1.0);
            fadeTransition.setToValue(0.0);
            fadeTransition.setOnFinished(new EventHandler<ActionEvent>() {
                final /* synthetic */ Data val$item;
                
                @Override
                public void handle(final ActionEvent actionEvent) {
                    PieChart.this.getChartChildren().remove(this.val$item.textNode);
                    this.val$item.setChart(null);
                    PieChart.this.removeDataItemRef(this.val$item);
                    this.val$item.textNode.setOpacity(1.0);
                }
            });
            fadeTransition.play();
            return;
        }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentPieValueProperty(), (T)0, Interpolator.EASE_BOTH), new KeyValue((WritableValue<T>)data.radiusMultiplierProperty(), (T)0) }));
        return timeline;
    }
    
    private void dataItemRemoved(final Data dataItemBeingRemoved) {
        final Node node = dataItemBeingRemoved.getNode();
        if (this.shouldAnimate()) {
            this.dataRemoveTimeline = this.createDataRemoveTimeline(dataItemBeingRemoved);
            this.dataItemBeingRemoved = dataItemBeingRemoved;
            this.animate(this.dataRemoveTimeline);
        }
        else {
            this.colorBits.clear(dataItemBeingRemoved.defaultColorIndex);
            this.getChartChildren().remove(dataItemBeingRemoved.textNode);
            this.getChartChildren().remove(node);
            dataItemBeingRemoved.setChart(null);
            this.removeDataItemRef(dataItemBeingRemoved);
        }
    }
    
    @Override
    protected void layoutChartChildren(final double n, final double n2, final double a, final double b) {
        double n3 = 0.0;
        for (Data data = this.begin; data != null; data = data.next) {
            n3 += Math.abs(data.getCurrentPieValue());
        }
        final double n4 = (n3 != 0.0) ? (360.0 / n3) : 0.0;
        double[] array = null;
        double[] array2 = null;
        double[] array3 = null;
        double min = 1.0;
        List<LabelLayoutInfo> labelLayoutInfos = null;
        boolean labelsVisible = this.getLabelsVisible();
        if (labelsVisible) {
            double max = 0.0;
            double n5 = 0.0;
            array = new double[this.getDataSize()];
            array2 = new double[this.getDataSize()];
            array3 = new double[this.getDataSize()];
            labelLayoutInfos = new ArrayList<LabelLayoutInfo>();
            int n6 = 0;
            double startAngle = this.getStartAngle();
            for (Data data2 = this.begin; data2 != null; data2 = data2.next) {
                data2.textNode.getTransforms().clear();
                final double n7 = this.isClockwise() ? (-n4 * Math.abs(data2.getCurrentPieValue())) : (n4 * Math.abs(data2.getCurrentPieValue()));
                array3[n6] = normalizeAngle(startAngle + n7 / 2.0);
                final double calcX = calcX(array3[n6], this.getLabelLineLength(), 0.0);
                final double calcY = calcY(array3[n6], this.getLabelLineLength(), 0.0);
                array[n6] = calcX;
                array2[n6] = calcY;
                max = Math.max(max, 2.0 * (data2.textNode.getLayoutBounds().getWidth() + 6.0 + Math.abs(calcX)));
                if (calcY > 0.0) {
                    n5 = Math.max(n5, 2.0 * Math.abs(calcY + data2.textNode.getLayoutBounds().getMaxY()));
                }
                else {
                    n5 = Math.max(n5, 2.0 * Math.abs(calcY + data2.textNode.getLayoutBounds().getMinY()));
                }
                startAngle += n7;
                ++n6;
            }
            this.pieRadius = Math.min(a - max, b - n5) / 2.0;
            if (this.pieRadius < 25.0) {
                min = Math.min((a - 25.0 - 25.0) / max, (b - 25.0 - 25.0) / n5);
                if ((this.begin == null && min < 0.7) || this.begin.textNode.getFont().getSize() * min < 9.0) {
                    labelsVisible = false;
                    min = 1.0;
                }
                else {
                    this.pieRadius = 25.0;
                    for (int i = 0; i < array.length; ++i) {
                        array[i] *= min;
                        array2[i] *= min;
                    }
                }
            }
        }
        if (!labelsVisible) {
            this.pieRadius = Math.min(a, b) / 2.0;
            this.labelLinePath.getElements().clear();
        }
        if (this.getChartChildren().size() > 0) {
            final double layoutX = a / 2.0 + n2;
            final double layoutY = b / 2.0 + n;
            int n8 = 0;
            for (Data data3 = this.begin; data3 != null; data3 = data3.next) {
                data3.textNode.setVisible(labelsVisible);
                if (labelsVisible) {
                    final double a2 = this.isClockwise() ? (-n4 * Math.abs(data3.getCurrentPieValue())) : (n4 * Math.abs(data3.getCurrentPieValue()));
                    final boolean b2 = array3[n8] <= -90.0 || array3[n8] >= 90.0;
                    final double calcX2 = calcX(array3[n8], this.pieRadius, layoutX);
                    final double calcY2 = calcY(array3[n8], this.pieRadius, layoutY);
                    labelLayoutInfos.add(new LabelLayoutInfo(calcX2, calcY2, calcX2 + array[n8], calcY2 + array2[n8], b2 ? (array[n8] + calcX2 - data3.textNode.getLayoutBounds().getMaxX() - 6.0) : (array[n8] + calcX2 - data3.textNode.getLayoutBounds().getMinX() + 6.0), array2[n8] + calcY2 - data3.textNode.getLayoutBounds().getMinY() / 2.0 - 2.0, data3.textNode, Math.abs(a2)));
                    if (min < 1.0) {
                        data3.textNode.getTransforms().add(new Scale(min, min, b2 ? data3.textNode.getLayoutBounds().getWidth() : 0.0, 0.0));
                    }
                }
                ++n8;
            }
            double startAngle2 = this.getStartAngle();
            for (Data data4 = this.begin; data4 != null; data4 = data4.next) {
                final Node node = data4.getNode();
                Arc shape = null;
                if (node != null && node instanceof Region) {
                    final Region region = (Region)node;
                    if (region.getShape() == null) {
                        shape = new Arc();
                        region.setShape(shape);
                    }
                    else {
                        shape = (Arc)region.getShape();
                    }
                    region.setScaleShape(false);
                    region.setCenterShape(false);
                    region.setCacheShape(false);
                }
                final double length = this.isClockwise() ? (-n4 * Math.abs(data4.getCurrentPieValue())) : (n4 * Math.abs(data4.getCurrentPieValue()));
                shape.setStartAngle(startAngle2);
                shape.setLength(length);
                shape.setType(ArcType.ROUND);
                shape.setRadiusX(this.pieRadius * data4.getRadiusMultiplier());
                shape.setRadiusY(this.pieRadius * data4.getRadiusMultiplier());
                node.setLayoutX(layoutX);
                node.setLayoutY(layoutY);
                startAngle2 += length;
            }
            if (labelLayoutInfos != null) {
                this.resolveCollision(labelLayoutInfos);
                if (!labelLayoutInfos.equals(this.labelLayoutInfos)) {
                    this.labelLinePath.getElements().clear();
                    for (final LabelLayoutInfo labelLayoutInfo : labelLayoutInfos) {
                        if (labelLayoutInfo.text.isVisible()) {
                            this.drawLabelLinePath(labelLayoutInfo);
                        }
                    }
                    this.labelLayoutInfos = labelLayoutInfos;
                }
            }
        }
    }
    
    private void resolveCollision(final List<LabelLayoutInfo> list) {
        final int n = (this.begin != null) ? ((int)this.begin.textNode.getLayoutBounds().getHeight()) : 0;
        for (int i = 0; i < list.size(); ++i) {
            for (int j = i + 1; j < list.size(); ++j) {
                final LabelLayoutInfo labelLayoutInfo = list.get(i);
                final LabelLayoutInfo labelLayoutInfo2 = list.get(j);
                if (labelLayoutInfo.text.isVisible() && labelLayoutInfo2.text.isVisible()) {
                    if (this.fuzzyGT(labelLayoutInfo2.textY, labelLayoutInfo.textY)) {
                        if (!this.fuzzyLT(labelLayoutInfo2.textY - n - labelLayoutInfo.textY, 2.0)) {
                            continue;
                        }
                    }
                    else if (!this.fuzzyLT(labelLayoutInfo.textY - n - labelLayoutInfo2.textY, 2.0)) {
                        continue;
                    }
                    if (this.fuzzyGT(labelLayoutInfo.textX, labelLayoutInfo2.textX)) {
                        if (!this.fuzzyLT(labelLayoutInfo.textX - labelLayoutInfo2.textX, labelLayoutInfo2.text.prefWidth(-1.0))) {
                            continue;
                        }
                    }
                    else if (!this.fuzzyLT(labelLayoutInfo2.textX - labelLayoutInfo.textX, labelLayoutInfo.text.prefWidth(-1.0))) {
                        continue;
                    }
                    if (this.fuzzyLT(labelLayoutInfo.size, labelLayoutInfo2.size)) {
                        labelLayoutInfo.text.setVisible(false);
                    }
                    else {
                        labelLayoutInfo2.text.setVisible(false);
                    }
                }
            }
        }
    }
    
    private int fuzzyCompare(final double n, final double n2) {
        return (Math.abs(n - n2) < 1.0E-5) ? 0 : ((n < n2) ? -1 : 1);
    }
    
    private boolean fuzzyGT(final double n, final double n2) {
        return this.fuzzyCompare(n, n2) == 1;
    }
    
    private boolean fuzzyLT(final double n, final double n2) {
        return this.fuzzyCompare(n, n2) == -1;
    }
    
    private void drawLabelLinePath(final LabelLayoutInfo labelLayoutInfo) {
        labelLayoutInfo.text.setLayoutX(labelLayoutInfo.textX);
        labelLayoutInfo.text.setLayoutY(labelLayoutInfo.textY);
        this.labelLinePath.getElements().add(new MoveTo(labelLayoutInfo.startX, labelLayoutInfo.startY));
        this.labelLinePath.getElements().add(new LineTo(labelLayoutInfo.endX, labelLayoutInfo.endY));
        this.labelLinePath.getElements().add(new MoveTo(labelLayoutInfo.endX - 2.0, labelLayoutInfo.endY));
        this.labelLinePath.getElements().add(new ArcTo(2.0, 2.0, 90.0, labelLayoutInfo.endX, labelLayoutInfo.endY - 2.0, false, true));
        this.labelLinePath.getElements().add(new ArcTo(2.0, 2.0, 90.0, labelLayoutInfo.endX + 2.0, labelLayoutInfo.endY, false, true));
        this.labelLinePath.getElements().add(new ArcTo(2.0, 2.0, 90.0, labelLayoutInfo.endX, labelLayoutInfo.endY + 2.0, false, true));
        this.labelLinePath.getElements().add(new ArcTo(2.0, 2.0, 90.0, labelLayoutInfo.endX - 2.0, labelLayoutInfo.endY, false, true));
        this.labelLinePath.getElements().add(new ClosePath());
    }
    
    private void updateLegend() {
        final Node legend = this.getLegend();
        if (legend != null && legend != this.legend) {
            return;
        }
        this.legend.setVertical(this.getLegendSide().equals(Side.LEFT) || this.getLegendSide().equals(Side.RIGHT));
        final ArrayList<Legend.LegendItem> all = new ArrayList<Legend.LegendItem>();
        if (this.getData() != null) {
            for (final Data data : this.getData()) {
                final Legend.LegendItem legendItem = new Legend.LegendItem(data.getName());
                legendItem.getSymbol().getStyleClass().addAll((Collection<?>)data.getNode().getStyleClass());
                legendItem.getSymbol().getStyleClass().add("pie-legend-symbol");
                all.add(legendItem);
            }
        }
        this.legend.getItems().setAll(all);
        if (all.size() > 0) {
            if (legend == null) {
                this.setLegend(this.legend);
            }
        }
        else {
            this.setLegend(null);
        }
    }
    
    private int getDataSize() {
        int n = 0;
        for (Data data = this.begin; data != null; data = data.next) {
            ++n;
        }
        return n;
    }
    
    private static double calcX(final double n, final double n2, final double n3) {
        return n3 + n2 * Math.cos(Math.toRadians(-n));
    }
    
    private static double calcY(final double n, final double n2, final double n3) {
        return n3 + n2 * Math.sin(Math.toRadians(-n));
    }
    
    private static double normalizeAngle(final double n) {
        double n2 = n % 360.0;
        if (n2 <= -180.0) {
            n2 += 360.0;
        }
        if (n2 > 180.0) {
            n2 -= 360.0;
        }
        return n2;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static final class LabelLayoutInfo
    {
        double startX;
        double startY;
        double endX;
        double endY;
        double textX;
        double textY;
        Text text;
        double size;
        
        LabelLayoutInfo(final double startX, final double startY, final double endX, final double endY, final double textX, final double textY, final Text text, final double size) {
            this.startX = startX;
            this.startY = startY;
            this.endX = endX;
            this.endY = endY;
            this.textX = textX;
            this.textY = textY;
            this.text = text;
            this.size = size;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            final LabelLayoutInfo labelLayoutInfo = (LabelLayoutInfo)o;
            return Double.compare(labelLayoutInfo.startX, this.startX) == 0 && Double.compare(labelLayoutInfo.startY, this.startY) == 0 && Double.compare(labelLayoutInfo.endX, this.endX) == 0 && Double.compare(labelLayoutInfo.endY, this.endY) == 0 && Double.compare(labelLayoutInfo.textX, this.textX) == 0 && Double.compare(labelLayoutInfo.textY, this.textY) == 0 && Double.compare(labelLayoutInfo.size, this.size) == 0;
        }
        
        @Override
        public int hashCode() {
            return Objects.hash(this.startX, this.startY, this.endX, this.endY, this.textX, this.textY, this.size);
        }
    }
    
    public static final class Data
    {
        private Text textNode;
        private Data next;
        private int defaultColorIndex;
        private ReadOnlyObjectWrapper<PieChart> chart;
        private StringProperty name;
        private DoubleProperty pieValue;
        private DoubleProperty currentPieValue;
        private DoubleProperty radiusMultiplier;
        private ReadOnlyObjectWrapper<Node> node;
        
        public final PieChart getChart() {
            return this.chart.getValue();
        }
        
        private void setChart(final PieChart value) {
            this.chart.setValue(value);
        }
        
        public final ReadOnlyObjectProperty<PieChart> chartProperty() {
            return this.chart.getReadOnlyProperty();
        }
        
        public final void setName(final String value) {
            this.name.setValue(value);
        }
        
        public final String getName() {
            return this.name.getValue();
        }
        
        public final StringProperty nameProperty() {
            return this.name;
        }
        
        public final double getPieValue() {
            return this.pieValue.getValue();
        }
        
        public final void setPieValue(final double d) {
            this.pieValue.setValue(d);
        }
        
        public final DoubleProperty pieValueProperty() {
            return this.pieValue;
        }
        
        private double getCurrentPieValue() {
            return this.currentPieValue.getValue();
        }
        
        private void setCurrentPieValue(final double d) {
            this.currentPieValue.setValue(d);
        }
        
        private DoubleProperty currentPieValueProperty() {
            return this.currentPieValue;
        }
        
        private double getRadiusMultiplier() {
            return this.radiusMultiplier.getValue();
        }
        
        private void setRadiusMultiplier(final double d) {
            this.radiusMultiplier.setValue(d);
        }
        
        private DoubleProperty radiusMultiplierProperty() {
            return this.radiusMultiplier;
        }
        
        public Node getNode() {
            return this.node.getValue();
        }
        
        private void setNode(final Node value) {
            this.node.setValue(value);
        }
        
        public ReadOnlyObjectProperty<Node> nodeProperty() {
            return this.node.getReadOnlyProperty();
        }
        
        public Data(final String name, final double pieValue) {
            this.textNode = new Text();
            this.next = null;
            this.chart = new ReadOnlyObjectWrapper<PieChart>(this, "chart");
            this.name = new StringPropertyBase() {
                @Override
                protected void invalidated() {
                    if (Data.this.getChart() != null) {
                        Data.this.getChart().dataNameChanged(Data.this);
                    }
                }
                
                @Override
                public Object getBean() {
                    return Data.this;
                }
                
                @Override
                public String getName() {
                    return "name";
                }
            };
            this.pieValue = new DoublePropertyBase() {
                @Override
                protected void invalidated() {
                    if (Data.this.getChart() != null) {
                        Data.this.getChart().dataPieValueChanged(Data.this);
                    }
                }
                
                @Override
                public Object getBean() {
                    return Data.this;
                }
                
                @Override
                public String getName() {
                    return "pieValue";
                }
            };
            this.currentPieValue = new SimpleDoubleProperty(this, "currentPieValue");
            this.radiusMultiplier = new SimpleDoubleProperty(this, "radiusMultiplier");
            this.node = new ReadOnlyObjectWrapper<Node>(this, "node");
            this.setName(name);
            this.setPieValue(pieValue);
            this.textNode.getStyleClass().addAll("text", "chart-pie-label");
            this.textNode.setAccessibleRole(AccessibleRole.TEXT);
            this.textNode.setAccessibleRoleDescription("slice");
            this.textNode.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
            this.textNode.accessibleTextProperty().bind((ObservableValue<?>)new StringBinding() {
                {
                    this.bind(Data.this.nameProperty(), Data.this.currentPieValueProperty());
                }
                
                @Override
                protected String computeValue() {
                    return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;D)Ljava/lang/String;, Data.this.getName(), Data.this.getCurrentPieValue());
                }
            });
        }
        
        @Override
        public String toString() {
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;D)Ljava/lang/String;, this.getName(), this.getPieValue());
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<PieChart, Boolean> CLOCKWISE;
        private static final CssMetaData<PieChart, Boolean> LABELS_VISIBLE;
        private static final CssMetaData<PieChart, Number> LABEL_LINE_LENGTH;
        private static final CssMetaData<PieChart, Number> START_ANGLE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            CLOCKWISE = new CssMetaData<PieChart, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final PieChart pieChart) {
                    return pieChart.clockwise == null || !pieChart.clockwise.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final PieChart pieChart) {
                    return (StyleableProperty<Boolean>)pieChart.clockwiseProperty();
                }
            };
            LABELS_VISIBLE = new CssMetaData<PieChart, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final PieChart pieChart) {
                    return pieChart.labelsVisible == null || !pieChart.labelsVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final PieChart pieChart) {
                    return (StyleableProperty<Boolean>)pieChart.labelsVisibleProperty();
                }
            };
            LABEL_LINE_LENGTH = new CssMetaData<PieChart, Number>((StyleConverter)SizeConverter.getInstance(), (Number)20.0) {
                @Override
                public boolean isSettable(final PieChart pieChart) {
                    return pieChart.labelLineLength == null || !pieChart.labelLineLength.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final PieChart pieChart) {
                    return (StyleableProperty<Number>)pieChart.labelLineLengthProperty();
                }
            };
            START_ANGLE = new CssMetaData<PieChart, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final PieChart pieChart) {
                    return pieChart.startAngle == null || !pieChart.startAngle.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final PieChart pieChart) {
                    return (StyleableProperty<Number>)pieChart.startAngleProperty();
                }
            };
            final ArrayList<CssMetaData<PieChart, Boolean>> list = new ArrayList<CssMetaData<PieChart, Boolean>>((Collection<? extends CssMetaData<PieChart, Boolean>>)Chart.getClassCssMetaData());
            list.add(StyleableProperties.CLOCKWISE);
            list.add(StyleableProperties.LABELS_VISIBLE);
            list.add((CssMetaData<PieChart, Boolean>)StyleableProperties.LABEL_LINE_LENGTH);
            list.add((CssMetaData<PieChart, Boolean>)StyleableProperties.START_ANGLE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
