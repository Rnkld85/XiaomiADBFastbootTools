// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.event.ActionEvent;
import javafx.css.Styleable;
import com.sun.javafx.charts.Legend;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import javafx.scene.AccessibleRole;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.ClosePath;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.TreeMap;
import java.util.List;
import java.util.Iterator;
import javafx.animation.Timeline;
import java.util.ArrayList;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.Group;
import javafx.scene.shape.Path;
import javafx.collections.ListChangeListener;
import javafx.animation.Interpolator;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.animation.KeyFrame;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import javafx.css.CssMetaData;
import javafx.scene.Node;
import javafx.css.StyleableBooleanProperty;
import java.util.HashMap;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.beans.NamedArg;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import java.util.Map;

public class StackedAreaChart<X, Y> extends XYChart<X, Y>
{
    private Map<Series<X, Y>, DoubleProperty> seriesYMultiplierMap;
    private BooleanProperty createSymbols;
    
    public final boolean getCreateSymbols() {
        return this.createSymbols.getValue();
    }
    
    public final void setCreateSymbols(final boolean b) {
        this.createSymbols.setValue(b);
    }
    
    public final BooleanProperty createSymbolsProperty() {
        return this.createSymbols;
    }
    
    public StackedAreaChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2) {
        this(axis, axis2, FXCollections.observableArrayList());
    }
    
    public StackedAreaChart(@NamedArg("xAxis") final Axis<X> axis, @NamedArg("yAxis") final Axis<Y> axis2, @NamedArg("data") final ObservableList<Series<X, Y>> data) {
        super(axis, axis2);
        this.seriesYMultiplierMap = new HashMap<Series<X, Y>, DoubleProperty>();
        this.createSymbols = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                for (int i = 0; i < StackedAreaChart.this.getData().size(); ++i) {
                    final Series series = StackedAreaChart.this.getData().get(i);
                    for (int j = 0; j < series.getData().size(); ++j) {
                        final Data data = (Data)series.getData().get(j);
                        final Node node = data.getNode();
                        if (this.get() && node == null) {
                            final Node access$000 = StackedAreaChart.this.createSymbol(series, StackedAreaChart.this.getData().indexOf(series), data, j);
                            if (null != access$000) {
                                StackedAreaChart.this.getPlotChildren().add(access$000);
                            }
                        }
                        else if (!this.get() && node != null) {
                            StackedAreaChart.this.getPlotChildren().remove(node);
                            data.setNode(null);
                        }
                    }
                }
                StackedAreaChart.this.requestChartLayout();
            }
            
            @Override
            public Object getBean() {
                return this;
            }
            
            @Override
            public String getName() {
                return "createSymbols";
            }
            
            @Override
            public CssMetaData<StackedAreaChart<?, ?>, Boolean> getCssMetaData() {
                return StyleableProperties.CREATE_SYMBOLS;
            }
        };
        if (!(axis2 instanceof ValueAxis)) {
            throw new IllegalArgumentException("Axis type incorrect, yAxis must be of ValueAxis type.");
        }
        this.setData(data);
    }
    
    private static double doubleValue(final Number n) {
        return doubleValue(n, 0.0);
    }
    
    private static double doubleValue(final Number n, final double n2) {
        return (n == null) ? n2 : n.doubleValue();
    }
    
    @Override
    protected void dataItemAdded(final Series<X, Y> series, final int n, final Data<X, Y> data) {
        final Node symbol = this.createSymbol(series, this.getData().indexOf(series), data, n);
        if (this.shouldAnimate()) {
            boolean b = false;
            if (n > 0 && n < series.getData().size() - 1) {
                b = true;
                final Data<X, Y> data2 = series.getData().get(n - 1);
                final Data<X, Y> data3 = series.getData().get(n + 1);
                final double numericValue = this.getXAxis().toNumericValue(data2.getXValue());
                final double numericValue2 = this.getYAxis().toNumericValue(data2.getYValue());
                final double numericValue3 = this.getXAxis().toNumericValue(data3.getXValue());
                final double numericValue4 = this.getYAxis().toNumericValue(data3.getYValue());
                final double numericValue5 = this.getXAxis().toNumericValue(data.getXValue());
                this.getYAxis().toNumericValue(data.getYValue());
                data.setCurrentY(this.getYAxis().toRealValue((numericValue4 - numericValue2) / (numericValue3 - numericValue) * numericValue5 + (numericValue3 * numericValue2 - numericValue4 * numericValue) / (numericValue3 - numericValue)));
                data.setCurrentX(this.getXAxis().toRealValue(numericValue5));
            }
            else if (n == 0 && series.getData().size() > 1) {
                b = true;
                data.setCurrentX(series.getData().get(1).getXValue());
                data.setCurrentY(series.getData().get(1).getYValue());
            }
            else if (n == series.getData().size() - 1 && series.getData().size() > 1) {
                b = true;
                final int n2 = series.getData().size() - 2;
                data.setCurrentX(((Data<X, Y>)series.getData().get(n2)).getXValue());
                data.setCurrentY(((Data<X, Y>)series.getData().get(n2)).getYValue());
            }
            else if (symbol != null) {
                symbol.setOpacity(0.0);
                this.getPlotChildren().add(symbol);
                final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), symbol);
                fadeTransition.setToValue(1.0);
                fadeTransition.play();
            }
            if (b) {
                final Node node;
                this.animate(new KeyFrame(Duration.ZERO, p1 -> {
                    if (node != null && !this.getPlotChildren().contains(node)) {
                        this.getPlotChildren().add(node);
                    }
                }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getCurrentY()), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getCurrentX()) }), new KeyFrame(Duration.millis(800.0), new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getYValue(), Interpolator.EASE_BOTH), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
            }
        }
        else if (symbol != null) {
            this.getPlotChildren().add(symbol);
        }
    }
    
    @Override
    protected void dataItemRemoved(final Data<X, Y> data, final Series<X, Y> series) {
        final Node node = data.getNode();
        if (node != null) {
            node.focusTraversableProperty().unbind();
        }
        final int itemIndex = series.getItemIndex(data);
        if (this.shouldAnimate()) {
            boolean b = false;
            final int dataSize = series.getDataSize();
            final int size = series.getData().size();
            if (itemIndex > 0 && itemIndex < dataSize - 1) {
                b = true;
                final Data<X, Y> item = series.getItem(itemIndex - 1);
                final Data<X, Y> item2 = series.getItem(itemIndex + 1);
                final double numericValue = this.getXAxis().toNumericValue(item.getXValue());
                final double numericValue2 = this.getYAxis().toNumericValue(item.getYValue());
                final double numericValue3 = this.getXAxis().toNumericValue(item2.getXValue());
                final double numericValue4 = this.getYAxis().toNumericValue(item2.getYValue());
                final double numericValue5 = this.getXAxis().toNumericValue(data.getXValue());
                final double numericValue6 = this.getYAxis().toNumericValue(data.getYValue());
                final double n = (numericValue4 - numericValue2) / (numericValue3 - numericValue) * numericValue5 + (numericValue3 * numericValue2 - numericValue4 * numericValue) / (numericValue3 - numericValue);
                data.setCurrentX(this.getXAxis().toRealValue(numericValue5));
                data.setCurrentY(this.getYAxis().toRealValue(numericValue6));
                data.setXValue(this.getXAxis().toRealValue(numericValue5));
                data.setYValue(this.getYAxis().toRealValue(n));
            }
            else if (itemIndex == 0 && size > 1) {
                b = true;
                data.setXValue(series.getData().get(0).getXValue());
                data.setYValue(series.getData().get(0).getYValue());
            }
            else if (itemIndex == dataSize - 1 && size > 1) {
                b = true;
                final int n2 = size - 1;
                data.setXValue(((Data<X, Y>)series.getData().get(n2)).getXValue());
                data.setYValue(((Data<X, Y>)series.getData().get(n2)).getYValue());
            }
            else if (node != null) {
                node.setOpacity(0.0);
                final FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0), node);
                fadeTransition.setToValue(0.0);
                final Node node2;
                fadeTransition.setOnFinished(p3 -> {
                    this.getPlotChildren().remove(node2);
                    this.removeDataItemFromDisplay(series, data);
                    node2.setOpacity(1.0);
                    return;
                });
                fadeTransition.play();
            }
            else {
                data.setSeries(null);
                this.removeDataItemFromDisplay(series, data);
            }
            if (b) {
                this.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getCurrentY()), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getCurrentX()) }), new KeyFrame(Duration.millis(800.0), p3 -> {
                    this.getPlotChildren().remove(node);
                    this.removeDataItemFromDisplay(series, data);
                }, new KeyValue[] { new KeyValue((WritableValue<T>)data.currentYProperty(), (T)data.getYValue(), Interpolator.EASE_BOTH), new KeyValue((WritableValue<T>)data.currentXProperty(), (T)data.getXValue(), Interpolator.EASE_BOTH) }));
            }
        }
        else {
            this.getPlotChildren().remove(node);
            this.removeDataItemFromDisplay(series, data);
        }
    }
    
    @Override
    protected void dataItemChanged(final Data<X, Y> data) {
    }
    
    @Override
    protected void seriesChanged(final ListChangeListener.Change<? extends Series> change) {
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Series series = this.getData().get(i);
            final Path path = ((Group)series.getNode()).getChildren().get(1);
            final Path path2 = ((Group)series.getNode()).getChildren().get(0);
            path.getStyleClass().setAll(new String[] { "chart-series-area-line", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), series.defaultColorStyleClass });
            path2.getStyleClass().setAll(new String[] { "chart-series-area-fill", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), series.defaultColorStyleClass });
            for (int j = 0; j < series.getData().size(); ++j) {
                final Node node = ((Data)series.getData().get(j)).getNode();
                if (node != null) {
                    node.getStyleClass().setAll(new String[] { "chart-area-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, j), series.defaultColorStyleClass });
                }
            }
        }
    }
    
    @Override
    protected void seriesAdded(final Series<X, Y> series, final int n) {
        final Path path = new Path();
        final Path path2 = new Path();
        path.setStrokeLineJoin(StrokeLineJoin.BEVEL);
        path2.setStrokeLineJoin(StrokeLineJoin.BEVEL);
        final Group node = new Group(new Node[] { path2, path });
        series.setNode(node);
        final SimpleDoubleProperty simpleDoubleProperty = new SimpleDoubleProperty(this, "seriesYMultiplier");
        this.seriesYMultiplierMap.put(series, simpleDoubleProperty);
        if (this.shouldAnimate()) {
            simpleDoubleProperty.setValue(0.0);
        }
        else {
            simpleDoubleProperty.setValue(1.0);
        }
        this.getPlotChildren().add(node);
        final ArrayList<KeyFrame> list = new ArrayList<KeyFrame>();
        if (this.shouldAnimate()) {
            list.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)node.opacityProperty(), (T)0), new KeyValue((WritableValue<T>)simpleDoubleProperty, (T)0) }));
            list.add(new KeyFrame(Duration.millis(200.0), new KeyValue[] { new KeyValue((WritableValue<T>)node.opacityProperty(), (T)1) }));
            list.add(new KeyFrame(Duration.millis(500.0), new KeyValue[] { new KeyValue((WritableValue<T>)simpleDoubleProperty, (T)1) }));
        }
        for (int i = 0; i < series.getData().size(); ++i) {
            final Node symbol = this.createSymbol(series, n, series.getData().get(i), i);
            if (symbol != null) {
                if (this.shouldAnimate()) {
                    symbol.setOpacity(0.0);
                }
                this.getPlotChildren().add(symbol);
                if (this.shouldAnimate()) {
                    list.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)symbol.opacityProperty(), (T)0) }));
                    list.add(new KeyFrame(Duration.millis(200.0), new KeyValue[] { new KeyValue((WritableValue<T>)symbol.opacityProperty(), (T)1) }));
                }
            }
        }
        if (this.shouldAnimate()) {
            this.animate((KeyFrame[])list.toArray(new KeyFrame[list.size()]));
        }
    }
    
    @Override
    protected void seriesRemoved(final Series<X, Y> series) {
        this.seriesYMultiplierMap.remove(series);
        if (this.shouldAnimate()) {
            new Timeline(this.createSeriesRemoveTimeLine(series, 400L)).play();
        }
        else {
            this.getPlotChildren().remove(series.getNode());
            final Iterator<Data> iterator = series.getData().iterator();
            while (iterator.hasNext()) {
                this.getPlotChildren().remove(iterator.next().getNode());
            }
            this.removeSeriesFromDisplay(series);
        }
    }
    
    @Override
    protected void updateAxisRange() {
        final Axis<Object> xAxis = (Axis<Object>)this.getXAxis();
        final Axis<Y> yAxis = this.getYAxis();
        if (xAxis.isAutoRanging()) {
            final ArrayList<Object> list = new ArrayList<Object>();
            final Iterator<Series> iterator = (Iterator<Series>)this.getData().iterator();
            while (iterator.hasNext()) {
                final Iterator iterator2 = iterator.next().getData().iterator();
                while (iterator2.hasNext()) {
                    list.add(iterator2.next().getXValue());
                }
            }
            xAxis.invalidateRange(list);
        }
        if (yAxis.isAutoRanging()) {
            double min = Double.MAX_VALUE;
            final Iterator<Series<X, Y>> displayedSeriesIterator = this.getDisplayedSeriesIterator();
            int n = 1;
            final TreeMap<Double, Double> treeMap = new TreeMap<Double, Double>();
            final TreeMap<Double, Object> treeMap2 = new TreeMap<Double, Object>();
            final TreeMap<Double, Double> treeMap3 = new TreeMap<Double, Double>();
            while (displayedSeriesIterator.hasNext()) {
                treeMap3.clear();
                for (final Data<Object, Y> data : displayedSeriesIterator.next().getData()) {
                    if (data != null) {
                        final double numericValue = xAxis.toNumericValue(data.getXValue());
                        final double numericValue2 = yAxis.toNumericValue((Y)data.getYValue());
                        treeMap3.put(numericValue, numericValue2);
                        if (n != 0) {
                            treeMap.put((Object)numericValue, (Object)numericValue2);
                            min = Math.min(min, numericValue2);
                        }
                        else if (treeMap2.containsKey(numericValue)) {
                            treeMap.put((Object)numericValue, (Object)(treeMap2.get(numericValue) + numericValue2));
                        }
                        else {
                            final Map.Entry<Double, Double> higherEntry = treeMap2.higherEntry(numericValue);
                            final Map.Entry<Double, Double> lowerEntry = treeMap2.lowerEntry(numericValue);
                            if (higherEntry != null && lowerEntry != null) {
                                treeMap.put((Object)numericValue, (Object)((numericValue - lowerEntry.getKey()) / (higherEntry.getKey() - lowerEntry.getKey()) * (lowerEntry.getValue() + higherEntry.getValue()) + numericValue2));
                            }
                            else if (higherEntry != null) {
                                treeMap.put((Object)numericValue, (Object)(higherEntry.getValue() + numericValue2));
                            }
                            else if (lowerEntry != null) {
                                treeMap.put((Object)numericValue, (Object)(lowerEntry.getValue() + numericValue2));
                            }
                            else {
                                treeMap.put((Object)numericValue, (Object)numericValue2);
                            }
                        }
                    }
                }
                for (final Map.Entry<Double, ? extends T> entry : treeMap2.entrySet()) {
                    if (treeMap.keySet().contains(entry.getKey())) {
                        continue;
                    }
                    final Double n2 = entry.getKey();
                    final Double n3 = (Double)entry.getValue();
                    final Map.Entry<Double, Object> higherEntry2 = treeMap3.higherEntry(n2);
                    final Map.Entry<Double, Object> lowerEntry2 = treeMap3.lowerEntry(n2);
                    if (higherEntry2 != null && lowerEntry2 != null) {
                        treeMap.put((Object)n2, Double.valueOf((n2 - lowerEntry2.getKey()) / (higherEntry2.getKey() - lowerEntry2.getKey()) * (lowerEntry2.getValue() + higherEntry2.getValue()) + n3));
                    }
                    else if (higherEntry2 != null) {
                        treeMap.put((Object)n2, Double.valueOf(higherEntry2.getValue() + n3));
                    }
                    else if (lowerEntry2 != null) {
                        treeMap.put((Object)n2, Double.valueOf(lowerEntry2.getValue() + n3));
                    }
                    else {
                        treeMap.put((Object)n2, n3);
                    }
                }
                treeMap2.clear();
                treeMap2.putAll((Map<?, ?>)treeMap);
                treeMap.clear();
                n = ((min == Double.MAX_VALUE) ? 1 : 0);
            }
            if (min != Double.MAX_VALUE) {
                yAxis.invalidateRange((List<Y>)Arrays.asList(yAxis.toRealValue(min), yAxis.toRealValue((double)Collections.max((Collection<?>)treeMap2.values()))));
            }
        }
    }
    
    @Override
    protected void layoutPlotChildren() {
        final ArrayList list = new ArrayList<DataPointInfo<X, Double>>();
        final ArrayList list2 = new ArrayList<DataPointInfo<X, Y>>();
        for (int i = 0; i < this.getDataSize(); ++i) {
            final Series<X, Y> series = this.getData().get(i);
            list2.clear();
            for (final DataPointInfo<X, Integer> e : list) {
                e.partOf = PartOf.PREVIOUS;
                list2.add(e);
            }
            list.clear();
            final Iterator<Data<X, Y>> displayedDataIterator = this.getDisplayedDataIterator(series);
            while (displayedDataIterator.hasNext()) {
                final Data<X, Y> data = displayedDataIterator.next();
                list2.add(new DataPointInfo<X, Y>((Data<Object, Object>)data, data.getXValue(), data.getYValue(), PartOf.CURRENT));
            }
            final DoubleProperty doubleProperty = this.seriesYMultiplierMap.get(series);
            final Path path = ((Group)series.getNode()).getChildren().get(1);
            final Path path2 = ((Group)series.getNode()).getChildren().get(0);
            path.getElements().clear();
            path2.getElements().clear();
            int n = 0;
            this.sortAggregateList(list2);
            final Axis<Y> yAxis = this.getYAxis();
            final Axis<X> xAxis = this.getXAxis();
            int n2 = 0;
            int n3 = 0;
            final int nextCurrent = this.findNextCurrent(list2, -1);
            final int previousCurrent = this.findPreviousCurrent(list2, list2.size());
            double v = yAxis.getZeroPosition();
            if (Double.isNaN(v)) {
                final ValueAxis<Double> valueAxis = (ValueAxis<Double>)yAxis;
                if (valueAxis.getLowerBound() > 0.0) {
                    v = valueAxis.getDisplayPosition(valueAxis.getLowerBound());
                }
                else {
                    v = valueAxis.getDisplayPosition(valueAxis.getUpperBound());
                }
            }
            for (final DataPointInfo dataPointInfo : list2) {
                if (n == previousCurrent) {
                    n3 = 1;
                }
                if (n == nextCurrent) {
                    n2 = 1;
                }
                final Data<X, Y> dataItem = dataPointInfo.dataItem;
                if (dataPointInfo.partOf.equals(PartOf.CURRENT)) {
                    final int previousPrevious = this.findPreviousPrevious(list2, n);
                    final int nextPrevious = this.findNextPrevious(list2, n);
                    if (previousPrevious == -1 || (nextPrevious == -1 && !list2.get(previousPrevious).x.equals(dataPointInfo.x))) {
                        if (n2 != 0) {
                            final Data data2 = new Data<X, Y>(dataPointInfo.x, 0);
                            this.addDropDown(list, (Data<X, Y>)data2, data2.getXValue(), data2.getYValue(), xAxis.getDisplayPosition(data2.getCurrentX()), v);
                        }
                        this.addPoint(list, (Data<X, Double>)dataItem, dataItem.getXValue(), (Double)dataItem.getYValue(), xAxis.getDisplayPosition(dataItem.getCurrentX()), yAxis.getDisplayPosition(yAxis.toRealValue(yAxis.toNumericValue(dataItem.getCurrentY()) * doubleProperty.getValue())), PartOf.CURRENT, false, n2 == 0);
                        if (n == previousCurrent) {
                            final Data data3 = new Data<X, Integer>(dataPointInfo.x, 0);
                            this.addDropDown(list, (Data<X, Integer>)data3, data3.getXValue(), data3.getYValue(), xAxis.getDisplayPosition(data3.getCurrentX()), v);
                        }
                    }
                    else {
                        DataPointInfo dataPointInfo2 = list2.get(previousPrevious);
                        if (dataPointInfo2.x.equals(dataPointInfo.x)) {
                            if (dataPointInfo2.dropDown) {
                                dataPointInfo2 = list2.get(this.findPreviousPrevious(list2, previousPrevious));
                            }
                            if (dataPointInfo2.x.equals(dataPointInfo.x)) {
                                final double displayPosition = xAxis.getDisplayPosition(dataItem.getCurrentX());
                                final double n4 = yAxis.toNumericValue(dataItem.getCurrentY()) + yAxis.toNumericValue((Y)dataPointInfo2.y);
                                this.addPoint((ArrayList<DataPointInfo<X, Double>>)list, (Data<X, Double>)dataItem, dataPointInfo.x, (Double)yAxis.toRealValue(n4), displayPosition, yAxis.getDisplayPosition(yAxis.toRealValue(n4 * doubleProperty.getValue())), PartOf.CURRENT, false, n2 == 0);
                            }
                            if (n3 != 0) {
                                this.addDropDown((ArrayList<DataPointInfo<X, Y>>)list, dataItem, dataPointInfo2.x, dataPointInfo2.y, dataPointInfo2.displayX, dataPointInfo2.displayY);
                            }
                        }
                        else {
                            final DataPointInfo dataPointInfo3 = (nextPrevious == -1) ? null : list2.get(nextPrevious);
                            final DataPointInfo dataPointInfo4 = (previousPrevious == -1) ? null : list2.get(previousPrevious);
                            final double numericValue = yAxis.toNumericValue(dataItem.getCurrentY());
                            if (dataPointInfo4 != null && dataPointInfo3 != null) {
                                final double displayPosition2 = xAxis.getDisplayPosition(dataItem.getCurrentX());
                                final double interpolate = this.interpolate(dataPointInfo4.displayX, dataPointInfo4.displayY, dataPointInfo3.displayX, dataPointInfo3.displayY, displayPosition2);
                                final double interpolate2 = this.interpolate(xAxis.toNumericValue((X)dataPointInfo4.x), yAxis.toNumericValue((Y)dataPointInfo4.y), xAxis.toNumericValue((X)dataPointInfo3.x), yAxis.toNumericValue((Y)dataPointInfo3.y), xAxis.toNumericValue((X)dataPointInfo.x));
                                if (n2 != 0) {
                                    this.addDropDown((ArrayList<DataPointInfo<X, Y>>)list, (Data<X, Y>)new Data<X, Y>(dataPointInfo.x, interpolate2), dataPointInfo.x, (Y)yAxis.toRealValue(interpolate2), displayPosition2, interpolate);
                                }
                                this.addPoint((ArrayList<DataPointInfo<X, Double>>)list, (Data<X, Double>)dataItem, dataPointInfo.x, (Double)yAxis.toRealValue(numericValue + interpolate2), displayPosition2, yAxis.getDisplayPosition(yAxis.toRealValue((numericValue + interpolate2) * doubleProperty.getValue())), PartOf.CURRENT, false, n2 == 0);
                                if (n == previousCurrent) {
                                    this.addDropDown((ArrayList<DataPointInfo<X, Y>>)list, (Data<X, Y>)new Data<X, Y>(dataPointInfo.x, interpolate2), dataPointInfo.x, (Y)yAxis.toRealValue(interpolate2), displayPosition2, interpolate);
                                }
                            }
                        }
                    }
                }
                else {
                    final int previousCurrent2 = this.findPreviousCurrent(list2, n);
                    final int nextCurrent2 = this.findNextCurrent(list2, n);
                    if (dataPointInfo.dropDown) {
                        if (xAxis.toNumericValue((X)dataPointInfo.x) <= xAxis.toNumericValue((X)list2.get(nextCurrent).x) || xAxis.toNumericValue((X)dataPointInfo.x) > xAxis.toNumericValue((X)list2.get(previousCurrent).x)) {
                            this.addDropDown((ArrayList<DataPointInfo<X, Y>>)list, dataItem, dataPointInfo.x, dataPointInfo.y, dataPointInfo.displayX, dataPointInfo.displayY);
                        }
                    }
                    else if (previousCurrent2 == -1 || nextCurrent2 == -1) {
                        this.addPoint((ArrayList<DataPointInfo<X, Y>>)list, dataItem, dataPointInfo.x, dataPointInfo.y, dataPointInfo.displayX, dataPointInfo.displayY, PartOf.CURRENT, true, false);
                    }
                    else {
                        final DataPointInfo dataPointInfo5 = list2.get(nextCurrent2);
                        if (!dataPointInfo5.x.equals(dataPointInfo.x)) {
                            final DataPointInfo dataPointInfo6 = list2.get(previousCurrent2);
                            final double displayPosition3 = xAxis.getDisplayPosition(dataItem.getCurrentX());
                            final double interpolate3 = this.interpolate(xAxis.toNumericValue((X)dataPointInfo6.x), yAxis.toNumericValue((Y)dataPointInfo6.y), xAxis.toNumericValue((X)dataPointInfo5.x), yAxis.toNumericValue((Y)dataPointInfo5.y), xAxis.toNumericValue((X)dataPointInfo.x));
                            final double n5 = yAxis.toNumericValue((Y)dataPointInfo.y) + interpolate3;
                            this.addPoint((ArrayList<DataPointInfo<X, Y>>)list, (Data<X, Y>)new Data<X, Y>(dataPointInfo.x, (Y)interpolate3), dataPointInfo.x, (Y)yAxis.toRealValue(n5), displayPosition3, yAxis.getDisplayPosition(yAxis.toRealValue(n5 * doubleProperty.getValue())), PartOf.CURRENT, true, true);
                        }
                    }
                }
                ++n;
                if (n2 != 0) {
                    n2 = 0;
                }
                if (n3 != 0) {
                    n3 = 0;
                }
            }
            if (!list.isEmpty()) {
                path.getElements().add(new MoveTo(list.get(0).displayX, list.get(0).displayY));
                path2.getElements().add(new MoveTo(list.get(0).displayX, list.get(0).displayY));
            }
            for (final DataPointInfo<X, Integer> dataPointInfo7 : list) {
                if (dataPointInfo7.lineTo) {
                    path.getElements().add(new LineTo(dataPointInfo7.displayX, dataPointInfo7.displayY));
                }
                else {
                    path.getElements().add(new MoveTo(dataPointInfo7.displayX, dataPointInfo7.displayY));
                }
                path2.getElements().add(new LineTo(dataPointInfo7.displayX, dataPointInfo7.displayY));
                if (!dataPointInfo7.skipSymbol) {
                    final Node node = dataPointInfo7.dataItem.getNode();
                    if (node == null) {
                        continue;
                    }
                    final double prefWidth = node.prefWidth(-1.0);
                    final double prefHeight = node.prefHeight(-1.0);
                    node.resizeRelocate(dataPointInfo7.displayX - prefWidth / 2.0, dataPointInfo7.displayY - prefHeight / 2.0, prefWidth, prefHeight);
                }
            }
            for (int j = list2.size() - 1; j > 0; --j) {
                final DataPointInfo dataPointInfo8 = list2.get(j);
                if (PartOf.PREVIOUS.equals(dataPointInfo8.partOf)) {
                    path2.getElements().add(new LineTo(dataPointInfo8.displayX, dataPointInfo8.displayY));
                }
            }
            if (!path2.getElements().isEmpty()) {
                path2.getElements().add(new ClosePath());
            }
        }
    }
    
    private void addDropDown(final ArrayList<DataPointInfo<X, Y>> list, final Data<X, Y> data, final X x, final Y y, final double n, final double n2) {
        final DataPointInfo<X, Y> e = new DataPointInfo<X, Y>(true);
        e.setValues(data, x, y, n, n2, PartOf.CURRENT, true, false);
        list.add(e);
    }
    
    private void addPoint(final ArrayList<DataPointInfo<X, Y>> list, final Data<X, Y> data, final X x, final Y y, final double n, final double n2, final PartOf partOf, final boolean b, final boolean b2) {
        final DataPointInfo<X, Y> e = new DataPointInfo<X, Y>();
        e.setValues(data, x, y, n, n2, partOf, b, b2);
        list.add(e);
    }
    
    private int findNextCurrent(final ArrayList<DataPointInfo<X, Y>> list, final int n) {
        for (int i = n + 1; i < list.size(); ++i) {
            if (list.get(i).partOf.equals(PartOf.CURRENT)) {
                return i;
            }
        }
        return -1;
    }
    
    private int findPreviousCurrent(final ArrayList<DataPointInfo<X, Y>> list, final int n) {
        for (int i = n - 1; i >= 0; --i) {
            if (list.get(i).partOf.equals(PartOf.CURRENT)) {
                return i;
            }
        }
        return -1;
    }
    
    private int findPreviousPrevious(final ArrayList<DataPointInfo<X, Y>> list, final int n) {
        for (int i = n - 1; i >= 0; --i) {
            if (list.get(i).partOf.equals(PartOf.PREVIOUS)) {
                return i;
            }
        }
        return -1;
    }
    
    private int findNextPrevious(final ArrayList<DataPointInfo<X, Y>> list, final int n) {
        for (int i = n + 1; i < list.size(); ++i) {
            if (list.get(i).partOf.equals(PartOf.PREVIOUS)) {
                return i;
            }
        }
        return -1;
    }
    
    private void sortAggregateList(final ArrayList<DataPointInfo<X, Y>> list) {
        final Data<X, Y> dataItem;
        final Data<X, Y> dataItem2;
        final double n;
        final double n2;
        Collections.sort((List<Object>)list, (dataPointInfo, dataPointInfo2) -> {
            dataItem = dataPointInfo.dataItem;
            dataItem2 = dataPointInfo2.dataItem;
            this.getXAxis().toNumericValue((X)dataItem.getXValue());
            this.getXAxis().toNumericValue((X)dataItem2.getXValue());
            return (n < n2) ? -1 : ((n == n2) ? 0 : 1);
        });
    }
    
    private double interpolate(final double n, final double n2, final double n3, final double n4, final double n5) {
        return (n4 - n2) / (n3 - n) * (n5 - n) + n2;
    }
    
    private Node createSymbol(final Series<X, Y> series, final int n, final Data<X, Y> data, final int n2) {
        Node node = data.getNode();
        if (node == null && this.getCreateSymbols()) {
            node = new StackPane();
            node.setAccessibleRole(AccessibleRole.TEXT);
            node.setAccessibleRoleDescription("Point");
            node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
            data.setNode(node);
        }
        if (node != null) {
            node.getStyleClass().setAll(new String[] { "chart-area-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n2), series.defaultColorStyleClass });
        }
        return node;
    }
    
    @Override
    Legend.LegendItem createLegendItemForSeries(final Series<X, Y> series, final int n) {
        final Legend.LegendItem legendItem = new Legend.LegendItem(series.getName());
        legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-area-symbol", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, n), "area-legend-symbol", series.defaultColorStyleClass });
        return legendItem;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    static final class DataPointInfo<X, Y>
    {
        X x;
        Y y;
        double displayX;
        double displayY;
        Data<X, Y> dataItem;
        PartOf partOf;
        boolean skipSymbol;
        boolean lineTo;
        boolean dropDown;
        
        DataPointInfo() {
            this.skipSymbol = false;
            this.lineTo = false;
            this.dropDown = false;
        }
        
        DataPointInfo(final Data<X, Y> dataItem, final X x, final Y y, final PartOf partOf) {
            this.skipSymbol = false;
            this.lineTo = false;
            this.dropDown = false;
            this.dataItem = dataItem;
            this.x = x;
            this.y = y;
            this.partOf = partOf;
        }
        
        DataPointInfo(final boolean dropDown) {
            this.skipSymbol = false;
            this.lineTo = false;
            this.dropDown = false;
            this.dropDown = dropDown;
        }
        
        void setValues(final Data<X, Y> dataItem, final X x, final Y y, final double displayX, final double displayY, final PartOf partOf, final boolean skipSymbol, final boolean lineTo) {
            this.dataItem = dataItem;
            this.x = x;
            this.y = y;
            this.displayX = displayX;
            this.displayY = displayY;
            this.partOf = partOf;
            this.skipSymbol = skipSymbol;
            this.lineTo = lineTo;
        }
        
        public final X getX() {
            return this.x;
        }
        
        public final Y getY() {
            return this.y;
        }
    }
    
    private enum PartOf
    {
        CURRENT, 
        PREVIOUS;
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<StackedAreaChart<?, ?>, Boolean> CREATE_SYMBOLS;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            CREATE_SYMBOLS = new CssMetaData<StackedAreaChart<?, ?>, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final StackedAreaChart<?, ?> stackedAreaChart) {
                    return ((StackedAreaChart<Object, Object>)stackedAreaChart).createSymbols == null || !((StackedAreaChart<Object, Object>)stackedAreaChart).createSymbols.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final StackedAreaChart<?, ?> stackedAreaChart) {
                    return (StyleableProperty<Boolean>)stackedAreaChart.createSymbolsProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(XYChart.getClassCssMetaData());
            list.add(StyleableProperties.CREATE_SYMBOLS);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
