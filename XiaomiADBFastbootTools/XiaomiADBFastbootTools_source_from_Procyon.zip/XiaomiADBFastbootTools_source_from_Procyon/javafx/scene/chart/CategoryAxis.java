// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.chart;

import java.util.Collections;
import javafx.css.converter.BooleanConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.Styleable;
import javafx.geometry.Dimension2D;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.geometry.Side;
import java.util.Iterator;
import javafx.collections.FXCollections;
import javafx.beans.property.ObjectPropertyBase;
import javafx.css.StyleableBooleanProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.scene.Parent;
import javafx.beans.property.SimpleDoubleProperty;
import java.util.ArrayList;
import javafx.beans.property.ReadOnlyDoubleProperty;
import java.util.Collection;
import javafx.beans.property.ReadOnlyDoubleWrapper;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.BooleanProperty;
import javafx.collections.ListChangeListener;
import com.sun.javafx.charts.ChartLayoutAnimator;
import javafx.beans.property.DoubleProperty;
import java.util.List;

public final class CategoryAxis extends Axis<String>
{
    private List<String> allDataCategories;
    private boolean changeIsLocal;
    private final DoubleProperty firstCategoryPos;
    private Object currentAnimationID;
    private final ChartLayoutAnimator animator;
    private ListChangeListener<String> itemsListener;
    private DoubleProperty startMargin;
    private DoubleProperty endMargin;
    private BooleanProperty gapStartAndEnd;
    private ObjectProperty<ObservableList<String>> categories;
    private final ReadOnlyDoubleWrapper categorySpacing;
    
    public final double getStartMargin() {
        return this.startMargin.getValue();
    }
    
    public final void setStartMargin(final double d) {
        this.startMargin.setValue(d);
    }
    
    public final DoubleProperty startMarginProperty() {
        return this.startMargin;
    }
    
    public final double getEndMargin() {
        return this.endMargin.getValue();
    }
    
    public final void setEndMargin(final double d) {
        this.endMargin.setValue(d);
    }
    
    public final DoubleProperty endMarginProperty() {
        return this.endMargin;
    }
    
    public final boolean isGapStartAndEnd() {
        return this.gapStartAndEnd.getValue();
    }
    
    public final void setGapStartAndEnd(final boolean b) {
        this.gapStartAndEnd.setValue(b);
    }
    
    public final BooleanProperty gapStartAndEndProperty() {
        return this.gapStartAndEnd;
    }
    
    public final void setCategories(final ObservableList<String> list) {
        this.categories.set(list);
        if (!this.changeIsLocal) {
            this.setAutoRanging(false);
            this.allDataCategories.clear();
            this.allDataCategories.addAll(this.getCategories());
        }
        this.requestAxisLayout();
    }
    
    private void checkAndRemoveDuplicates(final String s) {
        if (this.getDuplicate() != null) {
            this.getCategories().remove(s);
            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
        }
    }
    
    private String getDuplicate() {
        if (this.getCategories() != null) {
            for (int i = 0; i < this.getCategories().size(); ++i) {
                for (int j = 0; j < this.getCategories().size(); ++j) {
                    if (this.getCategories().get(i).equals(this.getCategories().get(j)) && i != j) {
                        return (String)this.getCategories().get(i);
                    }
                }
            }
        }
        return null;
    }
    
    public final ObservableList<String> getCategories() {
        return this.categories.get();
    }
    
    public final double getCategorySpacing() {
        return this.categorySpacing.get();
    }
    
    public final ReadOnlyDoubleProperty categorySpacingProperty() {
        return this.categorySpacing.getReadOnlyProperty();
    }
    
    public CategoryAxis() {
        this.allDataCategories = new ArrayList<String>();
        this.changeIsLocal = false;
        this.firstCategoryPos = new SimpleDoubleProperty(this, "firstCategoryPos", 0.0);
        this.animator = new ChartLayoutAnimator(this);
        final Iterator<String> iterator;
        this.itemsListener = (change -> {
            while (change.next()) {
                if (!change.getAddedSubList().isEmpty()) {
                    change.getAddedSubList().iterator();
                    while (iterator.hasNext()) {
                        this.checkAndRemoveDuplicates(iterator.next());
                    }
                }
                if (!this.isAutoRanging()) {
                    this.allDataCategories.clear();
                    this.allDataCategories.addAll(this.getCategories());
                    this.rangeValid = false;
                }
                this.requestAxisLayout();
            }
            return;
        });
        this.startMargin = new StyleableDoubleProperty(5.0) {
            @Override
            protected void invalidated() {
                CategoryAxis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<CategoryAxis, Number> getCssMetaData() {
                return StyleableProperties.START_MARGIN;
            }
            
            @Override
            public Object getBean() {
                return CategoryAxis.this;
            }
            
            @Override
            public String getName() {
                return "startMargin";
            }
        };
        this.endMargin = new StyleableDoubleProperty(5.0) {
            @Override
            protected void invalidated() {
                CategoryAxis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<CategoryAxis, Number> getCssMetaData() {
                return StyleableProperties.END_MARGIN;
            }
            
            @Override
            public Object getBean() {
                return CategoryAxis.this;
            }
            
            @Override
            public String getName() {
                return "endMargin";
            }
        };
        this.gapStartAndEnd = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                CategoryAxis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<CategoryAxis, Boolean> getCssMetaData() {
                return StyleableProperties.GAP_START_AND_END;
            }
            
            @Override
            public Object getBean() {
                return CategoryAxis.this;
            }
            
            @Override
            public String getName() {
                return "gapStartAndEnd";
            }
        };
        this.categories = new ObjectPropertyBase<ObservableList<String>>() {
            ObservableList<String> old;
            
            @Override
            protected void invalidated() {
                if (CategoryAxis.this.getDuplicate() != null) {
                    throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, CategoryAxis.this.getDuplicate()));
                }
                final ObservableList<String> old = this.get();
                if (this.old != old) {
                    if (this.old != null) {
                        this.old.removeListener(CategoryAxis.this.itemsListener);
                    }
                    if (old != null) {
                        old.addListener(CategoryAxis.this.itemsListener);
                    }
                    this.old = old;
                }
            }
            
            @Override
            public Object getBean() {
                return CategoryAxis.this;
            }
            
            @Override
            public String getName() {
                return "categories";
            }
        };
        this.categorySpacing = new ReadOnlyDoubleWrapper(this, "categorySpacing", 1.0);
        this.changeIsLocal = true;
        this.setCategories(FXCollections.observableArrayList());
        this.changeIsLocal = false;
    }
    
    public CategoryAxis(final ObservableList<String> categories) {
        this.allDataCategories = new ArrayList<String>();
        this.changeIsLocal = false;
        this.firstCategoryPos = new SimpleDoubleProperty(this, "firstCategoryPos", 0.0);
        this.animator = new ChartLayoutAnimator(this);
        final Iterator<String> iterator;
        this.itemsListener = (change -> {
            while (change.next()) {
                if (!change.getAddedSubList().isEmpty()) {
                    change.getAddedSubList().iterator();
                    while (iterator.hasNext()) {
                        this.checkAndRemoveDuplicates(iterator.next());
                    }
                }
                if (!this.isAutoRanging()) {
                    this.allDataCategories.clear();
                    this.allDataCategories.addAll(this.getCategories());
                    this.rangeValid = false;
                }
                this.requestAxisLayout();
            }
            return;
        });
        this.startMargin = new StyleableDoubleProperty(5.0) {
            @Override
            protected void invalidated() {
                CategoryAxis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<CategoryAxis, Number> getCssMetaData() {
                return StyleableProperties.START_MARGIN;
            }
            
            @Override
            public Object getBean() {
                return CategoryAxis.this;
            }
            
            @Override
            public String getName() {
                return "startMargin";
            }
        };
        this.endMargin = new StyleableDoubleProperty(5.0) {
            @Override
            protected void invalidated() {
                CategoryAxis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<CategoryAxis, Number> getCssMetaData() {
                return StyleableProperties.END_MARGIN;
            }
            
            @Override
            public Object getBean() {
                return CategoryAxis.this;
            }
            
            @Override
            public String getName() {
                return "endMargin";
            }
        };
        this.gapStartAndEnd = new StyleableBooleanProperty(true) {
            @Override
            protected void invalidated() {
                CategoryAxis.this.requestAxisLayout();
            }
            
            @Override
            public CssMetaData<CategoryAxis, Boolean> getCssMetaData() {
                return StyleableProperties.GAP_START_AND_END;
            }
            
            @Override
            public Object getBean() {
                return CategoryAxis.this;
            }
            
            @Override
            public String getName() {
                return "gapStartAndEnd";
            }
        };
        this.categories = new ObjectPropertyBase<ObservableList<String>>() {
            ObservableList<String> old;
            
            @Override
            protected void invalidated() {
                if (CategoryAxis.this.getDuplicate() != null) {
                    throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, CategoryAxis.this.getDuplicate()));
                }
                final ObservableList<String> old = this.get();
                if (this.old != old) {
                    if (this.old != null) {
                        this.old.removeListener(CategoryAxis.this.itemsListener);
                    }
                    if (old != null) {
                        old.addListener(CategoryAxis.this.itemsListener);
                    }
                    this.old = old;
                }
            }
            
            @Override
            public Object getBean() {
                return CategoryAxis.this;
            }
            
            @Override
            public String getName() {
                return "categories";
            }
        };
        this.categorySpacing = new ReadOnlyDoubleWrapper(this, "categorySpacing", 1.0);
        this.setCategories(categories);
    }
    
    private double calculateNewSpacing(final double n, final List<String> list) {
        this.getEffectiveSide();
        double n2 = 1.0;
        if (list != null) {
            final double n3 = this.isGapStartAndEnd() ? list.size() : (list.size() - 1);
            n2 = ((n3 == 0.0) ? 1.0 : ((n - this.getStartMargin() - this.getEndMargin()) / n3));
        }
        if (!this.isAutoRanging()) {
            this.categorySpacing.set(n2);
        }
        return n2;
    }
    
    private double calculateNewFirstPos(final double n, final double n2) {
        final Side effectiveSide = this.getEffectiveSide();
        final double n3 = this.isGapStartAndEnd() ? (n2 / 2.0) : 0.0;
        double n4;
        if (effectiveSide.isHorizontal()) {
            n4 = 0.0 + this.getStartMargin() + n3;
        }
        else {
            n4 = n - this.getStartMargin() - n3;
        }
        if (!this.isAutoRanging()) {
            this.firstCategoryPos.set(n4);
        }
        return n4;
    }
    
    @Override
    protected Object getRange() {
        return new Object[] { this.getCategories(), this.categorySpacing.get(), this.firstCategoryPos.get(), this.getEffectiveTickLabelRotation() };
    }
    
    @Override
    protected void setRange(final Object o, final boolean b) {
        final Object[] array = (Object[])o;
        final List list = (List)array[0];
        final double doubleValue = (double)array[1];
        final double doubleValue2 = (double)array[2];
        this.setEffectiveTickLabelRotation((double)array[3]);
        this.changeIsLocal = true;
        this.setCategories(FXCollections.observableArrayList((Collection<? extends String>)list));
        this.changeIsLocal = false;
        if (b) {
            this.animator.stop(this.currentAnimationID);
            this.currentAnimationID = this.animator.animate(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue<T>)this.firstCategoryPos, (T)this.firstCategoryPos.get()), new KeyValue((WritableValue<T>)this.categorySpacing, (T)this.categorySpacing.get()) }), new KeyFrame(Duration.millis(1000.0), new KeyValue[] { new KeyValue((WritableValue<T>)this.firstCategoryPos, (T)doubleValue2), new KeyValue((WritableValue<T>)this.categorySpacing, (T)doubleValue) }));
        }
        else {
            this.categorySpacing.set(doubleValue);
            this.firstCategoryPos.set(doubleValue2);
        }
    }
    
    @Override
    protected Object autoRange(final double n) {
        final Side effectiveSide = this.getEffectiveSide();
        final double calculateNewSpacing = this.calculateNewSpacing(n, this.allDataCategories);
        final double calculateNewFirstPos = this.calculateNewFirstPos(n, calculateNewSpacing);
        double tickLabelRotation = this.getTickLabelRotation();
        if (n >= 0.0 && this.calculateRequiredSize(effectiveSide.isVertical(), tickLabelRotation) > n) {
            if (effectiveSide.isHorizontal() && tickLabelRotation != 90.0) {
                tickLabelRotation = 90.0;
            }
            if (effectiveSide.isVertical() && tickLabelRotation != 0.0) {
                tickLabelRotation = 0.0;
            }
        }
        return new Object[] { this.allDataCategories, calculateNewSpacing, calculateNewFirstPos, tickLabelRotation };
    }
    
    private double calculateRequiredSize(final boolean b, final double n) {
        double max = 0.0;
        double n2 = 0.0;
        int n3 = 1;
        final Iterator<String> iterator = this.allDataCategories.iterator();
        while (iterator.hasNext()) {
            final Dimension2D measureTickMarkSize = this.measureTickMarkSize(iterator.next(), n);
            final double n4 = (b || n != 0.0) ? measureTickMarkSize.getHeight() : measureTickMarkSize.getWidth();
            if (n3 != 0) {
                n3 = 0;
                n2 = n4 / 2.0;
            }
            else {
                max = Math.max(max, n2 + 6.0 + n4 / 2.0);
            }
        }
        return this.getStartMargin() + max * this.allDataCategories.size() + this.getEndMargin();
    }
    
    @Override
    protected List<String> calculateTickValues(final double n, final Object o) {
        return (List<String>)((Object[])o)[0];
    }
    
    @Override
    protected String getTickMarkLabel(final String s) {
        return s;
    }
    
    @Override
    protected Dimension2D measureTickMarkSize(final String s, final Object o) {
        return this.measureTickMarkSize(s, (double)((Object[])o)[3]);
    }
    
    @Override
    public void invalidateRange(final List<String> list) {
        super.invalidateRange(list);
        final ArrayList<Object> list2 = new ArrayList<Object>();
        list2.addAll(this.allDataCategories);
        for (final String s : this.allDataCategories) {
            if (!list.contains(s)) {
                list2.remove(s);
            }
        }
        for (int i = 0; i < list.size(); ++i) {
            final int size = list2.size();
            if (!list2.contains(list.get(i))) {
                list2.add((i > size) ? size : i, list.get(i));
            }
        }
        this.allDataCategories.clear();
        this.allDataCategories.addAll((Collection<? extends String>)list2);
    }
    
    final List<String> getAllDataCategories() {
        return this.allDataCategories;
    }
    
    @Override
    public double getDisplayPosition(final String s) {
        final ObservableList<String> categories = this.getCategories();
        if (!categories.contains(s)) {
            return Double.NaN;
        }
        if (this.getEffectiveSide().isHorizontal()) {
            return this.firstCategoryPos.get() + categories.indexOf(s) * this.categorySpacing.get();
        }
        return this.firstCategoryPos.get() + categories.indexOf(s) * this.categorySpacing.get() * -1.0;
    }
    
    @Override
    public String getValueForDisplay(final double n) {
        if (this.getEffectiveSide().isHorizontal()) {
            if (n < 0.0 || n > this.getWidth()) {
                return null;
            }
            return this.toRealValue((n - this.firstCategoryPos.get()) / this.categorySpacing.get());
        }
        else {
            if (n < 0.0 || n > this.getHeight()) {
                return null;
            }
            return this.toRealValue((n - this.firstCategoryPos.get()) / (this.categorySpacing.get() * -1.0));
        }
    }
    
    @Override
    public boolean isValueOnAxis(final String s) {
        return this.getCategories().indexOf(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s)) != -1;
    }
    
    @Override
    public double toNumericValue(final String s) {
        return this.getCategories().indexOf(s);
    }
    
    @Override
    public String toRealValue(final double a) {
        final int n = (int)Math.round(a);
        final ObservableList<String> categories = this.getCategories();
        if (n >= 0 && n < categories.size()) {
            return (String)this.getCategories().get(n);
        }
        return null;
    }
    
    @Override
    public double getZeroPosition() {
        return Double.NaN;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<CategoryAxis, Number> START_MARGIN;
        private static final CssMetaData<CategoryAxis, Number> END_MARGIN;
        private static final CssMetaData<CategoryAxis, Boolean> GAP_START_AND_END;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            START_MARGIN = new CssMetaData<CategoryAxis, Number>((StyleConverter)SizeConverter.getInstance(), (Number)5.0) {
                @Override
                public boolean isSettable(final CategoryAxis categoryAxis) {
                    return categoryAxis.startMargin == null || !categoryAxis.startMargin.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final CategoryAxis categoryAxis) {
                    return (StyleableProperty<Number>)categoryAxis.startMarginProperty();
                }
            };
            END_MARGIN = new CssMetaData<CategoryAxis, Number>((StyleConverter)SizeConverter.getInstance(), (Number)5.0) {
                @Override
                public boolean isSettable(final CategoryAxis categoryAxis) {
                    return categoryAxis.endMargin == null || !categoryAxis.endMargin.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final CategoryAxis categoryAxis) {
                    return (StyleableProperty<Number>)categoryAxis.endMarginProperty();
                }
            };
            GAP_START_AND_END = new CssMetaData<CategoryAxis, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final CategoryAxis categoryAxis) {
                    return categoryAxis.gapStartAndEnd == null || !categoryAxis.gapStartAndEnd.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final CategoryAxis categoryAxis) {
                    return (StyleableProperty<Boolean>)categoryAxis.gapStartAndEndProperty();
                }
            };
            final ArrayList<CssMetaData<CategoryAxis, Number>> list = new ArrayList<CssMetaData<CategoryAxis, Number>>((Collection<? extends CssMetaData<CategoryAxis, Number>>)Axis.getClassCssMetaData());
            list.add(StyleableProperties.START_MARGIN);
            list.add(StyleableProperties.END_MARGIN);
            list.add((CssMetaData<CategoryAxis, Number>)StyleableProperties.GAP_START_AND_END);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
