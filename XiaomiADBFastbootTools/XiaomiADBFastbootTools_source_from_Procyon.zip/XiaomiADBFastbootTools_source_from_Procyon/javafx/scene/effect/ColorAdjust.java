// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.util.Utils;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class ColorAdjust extends Effect
{
    private ObjectProperty<Effect> input;
    private DoubleProperty hue;
    private DoubleProperty saturation;
    private DoubleProperty brightness;
    private DoubleProperty contrast;
    
    public ColorAdjust() {
    }
    
    public ColorAdjust(final double hue, final double saturation, final double brightness, final double contrast) {
        this.setBrightness(brightness);
        this.setContrast(contrast);
        this.setHue(hue);
        this.setSaturation(saturation);
    }
    
    @Override
    com.sun.scenario.effect.ColorAdjust createPeer() {
        return new com.sun.scenario.effect.ColorAdjust();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setHue(final double n) {
        this.hueProperty().set(n);
    }
    
    public final double getHue() {
        return (this.hue == null) ? 0.0 : this.hue.get();
    }
    
    public final DoubleProperty hueProperty() {
        if (this.hue == null) {
            this.hue = new DoublePropertyBase() {
                public void invalidated() {
                    ColorAdjust.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ColorAdjust.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ColorAdjust.this;
                }
                
                @Override
                public String getName() {
                    return "hue";
                }
            };
        }
        return this.hue;
    }
    
    public final void setSaturation(final double n) {
        this.saturationProperty().set(n);
    }
    
    public final double getSaturation() {
        return (this.saturation == null) ? 0.0 : this.saturation.get();
    }
    
    public final DoubleProperty saturationProperty() {
        if (this.saturation == null) {
            this.saturation = new DoublePropertyBase() {
                public void invalidated() {
                    ColorAdjust.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ColorAdjust.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ColorAdjust.this;
                }
                
                @Override
                public String getName() {
                    return "saturation";
                }
            };
        }
        return this.saturation;
    }
    
    public final void setBrightness(final double n) {
        this.brightnessProperty().set(n);
    }
    
    public final double getBrightness() {
        return (this.brightness == null) ? 0.0 : this.brightness.get();
    }
    
    public final DoubleProperty brightnessProperty() {
        if (this.brightness == null) {
            this.brightness = new DoublePropertyBase() {
                public void invalidated() {
                    ColorAdjust.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ColorAdjust.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ColorAdjust.this;
                }
                
                @Override
                public String getName() {
                    return "brightness";
                }
            };
        }
        return this.brightness;
    }
    
    public final void setContrast(final double n) {
        this.contrastProperty().set(n);
    }
    
    public final double getContrast() {
        return (this.contrast == null) ? 0.0 : this.contrast.get();
    }
    
    public final DoubleProperty contrastProperty() {
        if (this.contrast == null) {
            this.contrast = new DoublePropertyBase() {
                public void invalidated() {
                    ColorAdjust.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ColorAdjust.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ColorAdjust.this;
                }
                
                @Override
                public String getName() {
                    return "contrast";
                }
            };
        }
        return this.contrast;
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.ColorAdjust colorAdjust = (com.sun.scenario.effect.ColorAdjust)this.getPeer();
        colorAdjust.setInput((input == null) ? null : input.getPeer());
        colorAdjust.setHue((float)Utils.clamp(-1.0, this.getHue(), 1.0));
        colorAdjust.setSaturation((float)Utils.clamp(-1.0, this.getSaturation(), 1.0));
        colorAdjust.setBrightness((float)Utils.clamp(-1.0, this.getBrightness(), 1.0));
        colorAdjust.setContrast((float)Utils.clamp(-1.0, this.getContrast(), 1.0));
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        return Effect.getInputBounds(baseBounds, baseTransform, node, boundsAccessor, this.getInput());
    }
    
    @Override
    Effect copy() {
        final ColorAdjust colorAdjust = new ColorAdjust(this.getHue(), this.getSaturation(), this.getBrightness(), this.getContrast());
        colorAdjust.setInput(colorAdjust.getInput());
        return colorAdjust;
    }
}
