// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import javafx.beans.property.BooleanPropertyBase;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class DisplacementMap extends Effect
{
    private ObjectProperty<Effect> input;
    private final FloatMap defaultMap;
    private ObjectProperty<FloatMap> mapData;
    private final MapDataChangeListener mapDataChangeListener;
    private DoubleProperty scaleX;
    private DoubleProperty scaleY;
    private DoubleProperty offsetX;
    private DoubleProperty offsetY;
    private BooleanProperty wrap;
    
    @Override
    com.sun.scenario.effect.DisplacementMap createPeer() {
        return new com.sun.scenario.effect.DisplacementMap(new com.sun.scenario.effect.FloatMap(1, 1), com.sun.scenario.effect.Effect.DefaultInput);
    }
    
    public DisplacementMap() {
        this.defaultMap = new FloatMap(1, 1);
        this.mapDataChangeListener = new MapDataChangeListener();
        this.setMapData(new FloatMap(1, 1));
    }
    
    public DisplacementMap(final FloatMap mapData) {
        this.defaultMap = new FloatMap(1, 1);
        this.mapDataChangeListener = new MapDataChangeListener();
        this.setMapData(mapData);
    }
    
    public DisplacementMap(final FloatMap mapData, final double offsetX, final double offsetY, final double scaleX, final double scaleY) {
        this.defaultMap = new FloatMap(1, 1);
        this.mapDataChangeListener = new MapDataChangeListener();
        this.setMapData(mapData);
        this.setOffsetX(offsetX);
        this.setOffsetY(offsetY);
        this.setScaleX(scaleX);
        this.setScaleY(scaleY);
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setMapData(final FloatMap floatMap) {
        this.mapDataProperty().set(floatMap);
    }
    
    public final FloatMap getMapData() {
        return (this.mapData == null) ? null : this.mapData.get();
    }
    
    public final ObjectProperty<FloatMap> mapDataProperty() {
        if (this.mapData == null) {
            this.mapData = new ObjectPropertyBase<FloatMap>() {
                public void invalidated() {
                    DisplacementMap.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    DisplacementMap.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return DisplacementMap.this;
                }
                
                @Override
                public String getName() {
                    return "mapData";
                }
            };
        }
        return this.mapData;
    }
    
    public final void setScaleX(final double n) {
        this.scaleXProperty().set(n);
    }
    
    public final double getScaleX() {
        return (this.scaleX == null) ? 1.0 : this.scaleX.get();
    }
    
    public final DoubleProperty scaleXProperty() {
        if (this.scaleX == null) {
            this.scaleX = new DoublePropertyBase(1.0) {
                public void invalidated() {
                    DisplacementMap.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return DisplacementMap.this;
                }
                
                @Override
                public String getName() {
                    return "scaleX";
                }
            };
        }
        return this.scaleX;
    }
    
    public final void setScaleY(final double n) {
        this.scaleYProperty().set(n);
    }
    
    public final double getScaleY() {
        return (this.scaleY == null) ? 1.0 : this.scaleY.get();
    }
    
    public final DoubleProperty scaleYProperty() {
        if (this.scaleY == null) {
            this.scaleY = new DoublePropertyBase(1.0) {
                public void invalidated() {
                    DisplacementMap.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return DisplacementMap.this;
                }
                
                @Override
                public String getName() {
                    return "scaleY";
                }
            };
        }
        return this.scaleY;
    }
    
    public final void setOffsetX(final double n) {
        this.offsetXProperty().set(n);
    }
    
    public final double getOffsetX() {
        return (this.offsetX == null) ? 0.0 : this.offsetX.get();
    }
    
    public final DoubleProperty offsetXProperty() {
        if (this.offsetX == null) {
            this.offsetX = new DoublePropertyBase() {
                public void invalidated() {
                    DisplacementMap.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return DisplacementMap.this;
                }
                
                @Override
                public String getName() {
                    return "offsetX";
                }
            };
        }
        return this.offsetX;
    }
    
    public final void setOffsetY(final double n) {
        this.offsetYProperty().set(n);
    }
    
    public final double getOffsetY() {
        return (this.offsetY == null) ? 0.0 : this.offsetY.get();
    }
    
    public final DoubleProperty offsetYProperty() {
        if (this.offsetY == null) {
            this.offsetY = new DoublePropertyBase() {
                public void invalidated() {
                    DisplacementMap.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return DisplacementMap.this;
                }
                
                @Override
                public String getName() {
                    return "offsetY";
                }
            };
        }
        return this.offsetY;
    }
    
    public final void setWrap(final boolean b) {
        this.wrapProperty().set(b);
    }
    
    public final boolean isWrap() {
        return this.wrap != null && this.wrap.get();
    }
    
    public final BooleanProperty wrapProperty() {
        if (this.wrap == null) {
            this.wrap = new BooleanPropertyBase() {
                public void invalidated() {
                    DisplacementMap.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return DisplacementMap.this;
                }
                
                @Override
                public String getName() {
                    return "wrap";
                }
            };
        }
        return this.wrap;
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.DisplacementMap displacementMap = (com.sun.scenario.effect.DisplacementMap)this.getPeer();
        displacementMap.setContentInput((input == null) ? null : input.getPeer());
        final FloatMap mapData = this.getMapData();
        this.mapDataChangeListener.register(mapData);
        if (mapData != null) {
            mapData.sync();
            displacementMap.setMapData(mapData.getImpl());
        }
        else {
            this.defaultMap.sync();
            displacementMap.setMapData(this.defaultMap.getImpl());
        }
        displacementMap.setScaleX((float)this.getScaleX());
        displacementMap.setScaleY((float)this.getScaleY());
        displacementMap.setOffsetX((float)this.getOffsetX());
        displacementMap.setOffsetY((float)this.getOffsetY());
        displacementMap.setWrap(this.isWrap());
    }
    
    @Override
    BaseBounds getBounds(BaseBounds inputBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        inputBounds = Effect.getInputBounds(inputBounds, BaseTransform.IDENTITY_TRANSFORM, node, boundsAccessor, this.getInput());
        return Effect.transformBounds(baseTransform, inputBounds);
    }
    
    @Override
    Effect copy() {
        final DisplacementMap displacementMap = new DisplacementMap(this.getMapData().copy(), this.getOffsetX(), this.getOffsetY(), this.getScaleX(), this.getScaleY());
        displacementMap.setInput(this.getInput());
        return displacementMap;
    }
    
    private class MapDataChangeListener extends EffectChangeListener
    {
        FloatMap mapData;
        
        public void register(final FloatMap mapData) {
            this.mapData = mapData;
            super.register((this.mapData == null) ? null : this.mapData.effectDirtyProperty());
        }
        
        @Override
        public void invalidated(final Observable observable) {
            if (this.mapData.isEffectDirty()) {
                DisplacementMap.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                DisplacementMap.this.effectBoundsChanged();
            }
        }
    }
}
