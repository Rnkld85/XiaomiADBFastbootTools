// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.util.Utils;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class Bloom extends Effect
{
    private ObjectProperty<Effect> input;
    private DoubleProperty threshold;
    
    public Bloom() {
    }
    
    public Bloom(final double threshold) {
        this.setThreshold(threshold);
    }
    
    @Override
    com.sun.scenario.effect.Bloom createPeer() {
        return new com.sun.scenario.effect.Bloom();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setThreshold(final double n) {
        this.thresholdProperty().set(n);
    }
    
    public final double getThreshold() {
        return (this.threshold == null) ? 0.3 : this.threshold.get();
    }
    
    public final DoubleProperty thresholdProperty() {
        if (this.threshold == null) {
            this.threshold = new DoublePropertyBase(0.3) {
                public void invalidated() {
                    Bloom.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Bloom.this;
                }
                
                @Override
                public String getName() {
                    return "threshold";
                }
            };
        }
        return this.threshold;
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.Bloom bloom = (com.sun.scenario.effect.Bloom)this.getPeer();
        bloom.setInput((input == null) ? null : input.getPeer());
        bloom.setThreshold((float)Utils.clamp(0.0, this.getThreshold(), 1.0));
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        return Effect.getInputBounds(baseBounds, baseTransform, node, boundsAccessor, this.getInput());
    }
    
    @Override
    Effect copy() {
        final Bloom bloom = new Bloom(this.getThreshold());
        bloom.setInput(this.getInput());
        return bloom;
    }
}
