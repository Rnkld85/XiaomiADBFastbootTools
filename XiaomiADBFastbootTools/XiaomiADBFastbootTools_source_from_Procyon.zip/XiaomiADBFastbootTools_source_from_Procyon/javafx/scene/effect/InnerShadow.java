// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.tk.Toolkit;
import com.sun.javafx.util.Utils;
import javafx.beans.property.ObjectPropertyBase;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.scene.paint.Color;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class InnerShadow extends Effect
{
    private boolean changeIsLocal;
    private ObjectProperty<Effect> input;
    private DoubleProperty radius;
    private DoubleProperty width;
    private DoubleProperty height;
    private ObjectProperty<BlurType> blurType;
    private DoubleProperty choke;
    private ObjectProperty<Color> color;
    private DoubleProperty offsetX;
    private DoubleProperty offsetY;
    
    public InnerShadow() {
    }
    
    public InnerShadow(final double radius, final Color color) {
        this.setRadius(radius);
        this.setColor(color);
    }
    
    public InnerShadow(final double radius, final double offsetX, final double offsetY, final Color color) {
        this.setRadius(radius);
        this.setOffsetX(offsetX);
        this.setOffsetY(offsetY);
        this.setColor(color);
    }
    
    public InnerShadow(final BlurType blurType, final Color color, final double radius, final double choke, final double offsetX, final double offsetY) {
        this.setBlurType(blurType);
        this.setColor(color);
        this.setRadius(radius);
        this.setChoke(choke);
        this.setOffsetX(offsetX);
        this.setOffsetY(offsetY);
    }
    
    @Override
    com.sun.scenario.effect.InnerShadow createPeer() {
        return new com.sun.scenario.effect.InnerShadow();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setRadius(final double n) {
        this.radiusProperty().set(n);
    }
    
    public final double getRadius() {
        return (this.radius == null) ? 10.0 : this.radius.get();
    }
    
    public final DoubleProperty radiusProperty() {
        if (this.radius == null) {
            this.radius = new DoublePropertyBase(10.0) {
                public void invalidated() {
                    final double radius = InnerShadow.this.getRadius();
                    if (!InnerShadow.this.changeIsLocal) {
                        InnerShadow.this.changeIsLocal = true;
                        InnerShadow.this.updateRadius(radius);
                        InnerShadow.this.changeIsLocal = false;
                        InnerShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                        InnerShadow.this.effectBoundsChanged();
                    }
                }
                
                @Override
                public Object getBean() {
                    return InnerShadow.this;
                }
                
                @Override
                public String getName() {
                    return "radius";
                }
            };
        }
        return this.radius;
    }
    
    private void updateRadius(final double n) {
        final double n2 = n * 2.0 + 1.0;
        if (this.width != null && this.width.isBound()) {
            if (this.height == null || !this.height.isBound()) {
                this.setHeight(n2 * 2.0 - this.getWidth());
            }
        }
        else if (this.height != null && this.height.isBound()) {
            this.setWidth(n2 * 2.0 - this.getHeight());
        }
        else {
            this.setWidth(n2);
            this.setHeight(n2);
        }
    }
    
    public final void setWidth(final double n) {
        this.widthProperty().set(n);
    }
    
    public final double getWidth() {
        return (this.width == null) ? 21.0 : this.width.get();
    }
    
    public final DoubleProperty widthProperty() {
        if (this.width == null) {
            this.width = new DoublePropertyBase(21.0) {
                public void invalidated() {
                    final double width = InnerShadow.this.getWidth();
                    if (!InnerShadow.this.changeIsLocal) {
                        InnerShadow.this.changeIsLocal = true;
                        InnerShadow.this.updateWidth(width);
                        InnerShadow.this.changeIsLocal = false;
                        InnerShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                        InnerShadow.this.effectBoundsChanged();
                    }
                }
                
                @Override
                public Object getBean() {
                    return InnerShadow.this;
                }
                
                @Override
                public String getName() {
                    return "width";
                }
            };
        }
        return this.width;
    }
    
    private void updateWidth(final double n) {
        if (this.radius == null || !this.radius.isBound()) {
            double radius = ((n + this.getHeight()) / 2.0 - 1.0) / 2.0;
            if (radius < 0.0) {
                radius = 0.0;
            }
            this.setRadius(radius);
        }
        else if (this.height == null || !this.height.isBound()) {
            this.setHeight((this.getRadius() * 2.0 + 1.0) * 2.0 - n);
        }
    }
    
    public final void setHeight(final double n) {
        this.heightProperty().set(n);
    }
    
    public final double getHeight() {
        return (this.height == null) ? 21.0 : this.height.get();
    }
    
    public final DoubleProperty heightProperty() {
        if (this.height == null) {
            this.height = new DoublePropertyBase(21.0) {
                public void invalidated() {
                    final double height = InnerShadow.this.getHeight();
                    if (!InnerShadow.this.changeIsLocal) {
                        InnerShadow.this.changeIsLocal = true;
                        InnerShadow.this.updateHeight(height);
                        InnerShadow.this.changeIsLocal = false;
                        InnerShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                        InnerShadow.this.effectBoundsChanged();
                    }
                }
                
                @Override
                public Object getBean() {
                    return InnerShadow.this;
                }
                
                @Override
                public String getName() {
                    return "height";
                }
            };
        }
        return this.height;
    }
    
    private void updateHeight(final double n) {
        if (this.radius == null || !this.radius.isBound()) {
            double radius = ((this.getWidth() + n) / 2.0 - 1.0) / 2.0;
            if (radius < 0.0) {
                radius = 0.0;
            }
            this.setRadius(radius);
        }
        else if (this.width == null || !this.width.isBound()) {
            this.setWidth((this.getRadius() * 2.0 + 1.0) * 2.0 - n);
        }
    }
    
    public final void setBlurType(final BlurType blurType) {
        this.blurTypeProperty().set(blurType);
    }
    
    public final BlurType getBlurType() {
        return (this.blurType == null) ? BlurType.THREE_PASS_BOX : this.blurType.get();
    }
    
    public final ObjectProperty<BlurType> blurTypeProperty() {
        if (this.blurType == null) {
            this.blurType = new ObjectPropertyBase<BlurType>(BlurType.THREE_PASS_BOX) {
                public void invalidated() {
                    InnerShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return InnerShadow.this;
                }
                
                @Override
                public String getName() {
                    return "blurType";
                }
            };
        }
        return this.blurType;
    }
    
    public final void setChoke(final double n) {
        this.chokeProperty().set(n);
    }
    
    public final double getChoke() {
        return (this.choke == null) ? 0.0 : this.choke.get();
    }
    
    public final DoubleProperty chokeProperty() {
        if (this.choke == null) {
            this.choke = new DoublePropertyBase() {
                public void invalidated() {
                    InnerShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return InnerShadow.this;
                }
                
                @Override
                public String getName() {
                    return "choke";
                }
            };
        }
        return this.choke;
    }
    
    public final void setColor(final Color color) {
        this.colorProperty().set(color);
    }
    
    public final Color getColor() {
        return (this.color == null) ? Color.BLACK : this.color.get();
    }
    
    public final ObjectProperty<Color> colorProperty() {
        if (this.color == null) {
            this.color = new ObjectPropertyBase<Color>(Color.BLACK) {
                public void invalidated() {
                    InnerShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return InnerShadow.this;
                }
                
                @Override
                public String getName() {
                    return "color";
                }
            };
        }
        return this.color;
    }
    
    public final void setOffsetX(final double n) {
        this.offsetXProperty().set(n);
    }
    
    public final double getOffsetX() {
        return (this.offsetX == null) ? 0.0 : this.offsetX.get();
    }
    
    public final DoubleProperty offsetXProperty() {
        if (this.offsetX == null) {
            this.offsetX = new DoublePropertyBase() {
                public void invalidated() {
                    InnerShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    InnerShadow.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return InnerShadow.this;
                }
                
                @Override
                public String getName() {
                    return "offsetX";
                }
            };
        }
        return this.offsetX;
    }
    
    public final void setOffsetY(final double n) {
        this.offsetYProperty().set(n);
    }
    
    public final double getOffsetY() {
        return (this.offsetY == null) ? 0.0 : this.offsetY.get();
    }
    
    public final DoubleProperty offsetYProperty() {
        if (this.offsetY == null) {
            this.offsetY = new DoublePropertyBase() {
                public void invalidated() {
                    InnerShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    InnerShadow.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return InnerShadow.this;
                }
                
                @Override
                public String getName() {
                    return "offsetY";
                }
            };
        }
        return this.offsetY;
    }
    
    private Color getColorInternal() {
        final Color color = this.getColor();
        return (color == null) ? Color.BLACK : color;
    }
    
    private BlurType getBlurTypeInternal() {
        final BlurType blurType = this.getBlurType();
        return (blurType == null) ? BlurType.THREE_PASS_BOX : blurType;
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.InnerShadow innerShadow = (com.sun.scenario.effect.InnerShadow)this.getPeer();
        innerShadow.setShadowSourceInput((input == null) ? null : input.getPeer());
        innerShadow.setContentInput((input == null) ? null : input.getPeer());
        innerShadow.setGaussianWidth((float)Utils.clamp(0.0, this.getWidth(), 255.0));
        innerShadow.setGaussianHeight((float)Utils.clamp(0.0, this.getHeight(), 255.0));
        innerShadow.setShadowMode(Toolkit.getToolkit().toShadowMode(this.getBlurTypeInternal()));
        innerShadow.setColor(Toolkit.getToolkit().toColor4f(this.getColorInternal()));
        innerShadow.setChoke((float)Utils.clamp(0.0, this.getChoke(), 1.0));
        innerShadow.setOffsetX((int)this.getOffsetX());
        innerShadow.setOffsetY((int)this.getOffsetY());
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        return Effect.getInputBounds(baseBounds, baseTransform, node, boundsAccessor, this.getInput());
    }
    
    @Override
    Effect copy() {
        final InnerShadow innerShadow = new InnerShadow(this.getBlurType(), this.getColor(), this.getRadius(), this.getChoke(), this.getOffsetX(), this.getOffsetY());
        innerShadow.setInput(this.getInput());
        innerShadow.setWidth(this.getWidth());
        innerShadow.setHeight(this.getHeight());
        return innerShadow;
    }
}
