// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.util.Utils;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class Glow extends Effect
{
    private ObjectProperty<Effect> input;
    private DoubleProperty level;
    
    public Glow() {
    }
    
    public Glow(final double level) {
        this.setLevel(level);
    }
    
    @Override
    com.sun.scenario.effect.Glow createPeer() {
        return new com.sun.scenario.effect.Glow();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setLevel(final double n) {
        this.levelProperty().set(n);
    }
    
    public final double getLevel() {
        return (this.level == null) ? 0.3 : this.level.get();
    }
    
    public final DoubleProperty levelProperty() {
        if (this.level == null) {
            this.level = new DoublePropertyBase(0.3) {
                public void invalidated() {
                    Glow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Glow.this;
                }
                
                @Override
                public String getName() {
                    return "level";
                }
            };
        }
        return this.level;
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.Glow glow = (com.sun.scenario.effect.Glow)this.getPeer();
        glow.setInput((input == null) ? null : input.getPeer());
        glow.setLevel((float)Utils.clamp(0.0, this.getLevel(), 1.0));
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        return Effect.getInputBounds(baseBounds, baseTransform, node, boundsAccessor, this.getInput());
    }
    
    @Override
    Effect copy() {
        return new Glow(this.getLevel());
    }
}
