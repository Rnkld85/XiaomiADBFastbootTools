// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.geom.RectBounds;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.ObjectPropertyBase;
import javafx.scene.paint.Color;
import com.sun.javafx.tk.Toolkit;
import com.sun.scenario.effect.Flood;
import javafx.beans.property.DoubleProperty;
import javafx.scene.paint.Paint;
import javafx.beans.property.ObjectProperty;

public class ColorInput extends Effect
{
    private ObjectProperty<Paint> paint;
    private DoubleProperty x;
    private DoubleProperty y;
    private DoubleProperty width;
    private DoubleProperty height;
    
    public ColorInput() {
    }
    
    public ColorInput(final double x, final double y, final double width, final double height, final Paint paint) {
        this.setX(x);
        this.setY(y);
        this.setWidth(width);
        this.setHeight(height);
        this.setPaint(paint);
    }
    
    @Override
    Flood createPeer() {
        return new Flood(Toolkit.getPaintAccessor().getPlatformPaint(Color.RED));
    }
    
    public final void setPaint(final Paint paint) {
        this.paintProperty().set(paint);
    }
    
    public final Paint getPaint() {
        return (this.paint == null) ? Color.RED : this.paint.get();
    }
    
    public final ObjectProperty<Paint> paintProperty() {
        if (this.paint == null) {
            this.paint = new ObjectPropertyBase<Paint>(Color.RED) {
                public void invalidated() {
                    ColorInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return ColorInput.this;
                }
                
                @Override
                public String getName() {
                    return "paint";
                }
            };
        }
        return this.paint;
    }
    
    public final void setX(final double n) {
        this.xProperty().set(n);
    }
    
    public final double getX() {
        return (this.x == null) ? 0.0 : this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        if (this.x == null) {
            this.x = new DoublePropertyBase() {
                public void invalidated() {
                    ColorInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ColorInput.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ColorInput.this;
                }
                
                @Override
                public String getName() {
                    return "x";
                }
            };
        }
        return this.x;
    }
    
    public final void setY(final double n) {
        this.yProperty().set(n);
    }
    
    public final double getY() {
        return (this.y == null) ? 0.0 : this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        if (this.y == null) {
            this.y = new DoublePropertyBase() {
                public void invalidated() {
                    ColorInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ColorInput.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ColorInput.this;
                }
                
                @Override
                public String getName() {
                    return "y";
                }
            };
        }
        return this.y;
    }
    
    public final void setWidth(final double n) {
        this.widthProperty().set(n);
    }
    
    public final double getWidth() {
        return (this.width == null) ? 0.0 : this.width.get();
    }
    
    public final DoubleProperty widthProperty() {
        if (this.width == null) {
            this.width = new DoublePropertyBase() {
                public void invalidated() {
                    ColorInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ColorInput.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ColorInput.this;
                }
                
                @Override
                public String getName() {
                    return "width";
                }
            };
        }
        return this.width;
    }
    
    public final void setHeight(final double n) {
        this.heightProperty().set(n);
    }
    
    public final double getHeight() {
        return (this.height == null) ? 0.0 : this.height.get();
    }
    
    public final DoubleProperty heightProperty() {
        if (this.height == null) {
            this.height = new DoublePropertyBase() {
                public void invalidated() {
                    ColorInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ColorInput.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ColorInput.this;
                }
                
                @Override
                public String getName() {
                    return "height";
                }
            };
        }
        return this.height;
    }
    
    private Paint getPaintInternal() {
        final Paint paint = this.getPaint();
        return (paint == null) ? Color.RED : paint;
    }
    
    @Override
    void update() {
        final Flood flood = (Flood)this.getPeer();
        flood.setPaint(Toolkit.getPaintAccessor().getPlatformPaint(this.getPaintInternal()));
        flood.setFloodBounds(new RectBounds((float)this.getX(), (float)this.getY(), (float)(this.getX() + this.getWidth()), (float)(this.getY() + this.getHeight())));
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        return false;
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        return Effect.transformBounds(baseTransform, new RectBounds((float)this.getX(), (float)this.getY(), (float)(this.getX() + this.getWidth()), (float)(this.getY() + this.getHeight())));
    }
    
    @Override
    Effect copy() {
        return new ColorInput(this.getX(), this.getY(), this.getWidth(), this.getHeight(), this.getPaint());
    }
}
