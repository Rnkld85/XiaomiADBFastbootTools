// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.util.Utils;
import javafx.beans.property.IntegerPropertyBase;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class BoxBlur extends Effect
{
    private ObjectProperty<Effect> input;
    private DoubleProperty width;
    private DoubleProperty height;
    private IntegerProperty iterations;
    
    public BoxBlur() {
    }
    
    public BoxBlur(final double width, final double height, final int iterations) {
        this.setWidth(width);
        this.setHeight(height);
        this.setIterations(iterations);
    }
    
    @Override
    com.sun.scenario.effect.BoxBlur createPeer() {
        return new com.sun.scenario.effect.BoxBlur();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setWidth(final double n) {
        this.widthProperty().set(n);
    }
    
    public final double getWidth() {
        return (this.width == null) ? 5.0 : this.width.get();
    }
    
    public final DoubleProperty widthProperty() {
        if (this.width == null) {
            this.width = new DoublePropertyBase(5.0) {
                public void invalidated() {
                    BoxBlur.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    BoxBlur.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return BoxBlur.this;
                }
                
                @Override
                public String getName() {
                    return "width";
                }
            };
        }
        return this.width;
    }
    
    public final void setHeight(final double n) {
        this.heightProperty().set(n);
    }
    
    public final double getHeight() {
        return (this.height == null) ? 5.0 : this.height.get();
    }
    
    public final DoubleProperty heightProperty() {
        if (this.height == null) {
            this.height = new DoublePropertyBase(5.0) {
                public void invalidated() {
                    BoxBlur.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    BoxBlur.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return BoxBlur.this;
                }
                
                @Override
                public String getName() {
                    return "height";
                }
            };
        }
        return this.height;
    }
    
    public final void setIterations(final int n) {
        this.iterationsProperty().set(n);
    }
    
    public final int getIterations() {
        return (this.iterations == null) ? 1 : this.iterations.get();
    }
    
    public final IntegerProperty iterationsProperty() {
        if (this.iterations == null) {
            this.iterations = new IntegerPropertyBase(1) {
                public void invalidated() {
                    BoxBlur.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    BoxBlur.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return BoxBlur.this;
                }
                
                @Override
                public String getName() {
                    return "iterations";
                }
            };
        }
        return this.iterations;
    }
    
    private int getClampedWidth() {
        return Utils.clamp(0, (int)this.getWidth(), 255);
    }
    
    private int getClampedHeight() {
        return Utils.clamp(0, (int)this.getHeight(), 255);
    }
    
    private int getClampedIterations() {
        return Utils.clamp(0, this.getIterations(), 3);
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.BoxBlur boxBlur = (com.sun.scenario.effect.BoxBlur)this.getPeer();
        boxBlur.setInput((input == null) ? null : input.getPeer());
        boxBlur.setHorizontalSize(this.getClampedWidth());
        boxBlur.setVerticalSize(this.getClampedHeight());
        boxBlur.setPasses(this.getClampedIterations());
    }
    
    @Override
    BaseBounds getBounds(BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        baseBounds = Effect.getInputBounds(baseBounds, BaseTransform.IDENTITY_TRANSFORM, node, boundsAccessor, this.getInput());
        final int clampedIterations = this.getClampedIterations();
        baseBounds = baseBounds.deriveWithPadding((float)Effect.getKernelSize((float)this.getClampedWidth(), clampedIterations), (float)Effect.getKernelSize((float)this.getClampedHeight(), clampedIterations), 0.0f);
        return Effect.transformBounds(baseTransform, baseBounds);
    }
    
    @Override
    Effect copy() {
        final BoxBlur boxBlur = new BoxBlur(this.getWidth(), this.getHeight(), this.getIterations());
        boxBlur.setInput(this.getInput());
        return boxBlur;
    }
}
