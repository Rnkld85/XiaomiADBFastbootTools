// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.util.Utils;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class GaussianBlur extends Effect
{
    private ObjectProperty<Effect> input;
    private DoubleProperty radius;
    
    public GaussianBlur() {
    }
    
    public GaussianBlur(final double radius) {
        this.setRadius(radius);
    }
    
    @Override
    com.sun.scenario.effect.GaussianBlur createPeer() {
        return new com.sun.scenario.effect.GaussianBlur();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setRadius(final double n) {
        this.radiusProperty().set(n);
    }
    
    public final double getRadius() {
        return (this.radius == null) ? 10.0 : this.radius.get();
    }
    
    public final DoubleProperty radiusProperty() {
        if (this.radius == null) {
            this.radius = new DoublePropertyBase(10.0) {
                public void invalidated() {
                    GaussianBlur.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    GaussianBlur.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return GaussianBlur.this;
                }
                
                @Override
                public String getName() {
                    return "radius";
                }
            };
        }
        return this.radius;
    }
    
    private float getClampedRadius() {
        return (float)Utils.clamp(0.0, this.getRadius(), 63.0);
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.GaussianBlur gaussianBlur = (com.sun.scenario.effect.GaussianBlur)this.getPeer();
        gaussianBlur.setRadius(this.getClampedRadius());
        gaussianBlur.setInput((input == null) ? null : input.getPeer());
    }
    
    @Override
    BaseBounds getBounds(BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        baseBounds = Effect.getInputBounds(baseBounds, BaseTransform.IDENTITY_TRANSFORM, node, boundsAccessor, this.getInput());
        final float clampedRadius = this.getClampedRadius();
        baseBounds = baseBounds.deriveWithPadding(clampedRadius, clampedRadius, 0.0f);
        return Effect.transformBounds(baseTransform, baseBounds);
    }
    
    @Override
    Effect copy() {
        return new GaussianBlur(this.getRadius());
    }
}
