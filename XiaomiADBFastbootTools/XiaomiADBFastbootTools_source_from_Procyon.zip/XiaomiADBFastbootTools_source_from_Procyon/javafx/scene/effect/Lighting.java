// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.util.Utils;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.ObjectPropertyBase;
import com.sun.scenario.effect.PhongLighting;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class Lighting extends Effect
{
    private final Light defaultLight;
    private ObjectProperty<Light> light;
    private final LightChangeListener lightChangeListener;
    private ObjectProperty<Effect> bumpInput;
    private ObjectProperty<Effect> contentInput;
    private DoubleProperty diffuseConstant;
    private DoubleProperty specularConstant;
    private DoubleProperty specularExponent;
    private DoubleProperty surfaceScale;
    
    @Override
    PhongLighting createPeer() {
        return new PhongLighting(this.getLightInternal().getPeer());
    }
    
    public Lighting() {
        this.defaultLight = new Light.Distant();
        this.light = new ObjectPropertyBase<Light>((Light)new Light.Distant()) {
            public void invalidated() {
                Lighting.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                Lighting.this.effectBoundsChanged();
            }
            
            @Override
            public Object getBean() {
                return Lighting.this;
            }
            
            @Override
            public String getName() {
                return "light";
            }
        };
        this.lightChangeListener = new LightChangeListener();
        final Shadow bumpInput = new Shadow();
        bumpInput.setRadius(10.0);
        this.setBumpInput(bumpInput);
    }
    
    public Lighting(final Light light) {
        this.defaultLight = new Light.Distant();
        this.light = new ObjectPropertyBase<Light>((Light)new Light.Distant()) {
            public void invalidated() {
                Lighting.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                Lighting.this.effectBoundsChanged();
            }
            
            @Override
            public Object getBean() {
                return Lighting.this;
            }
            
            @Override
            public String getName() {
                return "light";
            }
        };
        this.lightChangeListener = new LightChangeListener();
        final Shadow bumpInput = new Shadow();
        bumpInput.setRadius(10.0);
        this.setBumpInput(bumpInput);
        this.setLight(light);
    }
    
    public final void setLight(final Light light) {
        this.lightProperty().set(light);
    }
    
    public final Light getLight() {
        return this.light.get();
    }
    
    public final ObjectProperty<Light> lightProperty() {
        return this.light;
    }
    
    @Override
    Effect copy() {
        final Lighting lighting = new Lighting(this.getLight());
        lighting.setBumpInput(this.getBumpInput());
        lighting.setContentInput(this.getContentInput());
        lighting.setDiffuseConstant(this.getDiffuseConstant());
        lighting.setSpecularConstant(this.getSpecularConstant());
        lighting.setSpecularExponent(this.getSpecularExponent());
        lighting.setSurfaceScale(this.getSurfaceScale());
        return lighting;
    }
    
    public final void setBumpInput(final Effect effect) {
        this.bumpInputProperty().set(effect);
    }
    
    public final Effect getBumpInput() {
        return (this.bumpInput == null) ? null : this.bumpInput.get();
    }
    
    public final ObjectProperty<Effect> bumpInputProperty() {
        if (this.bumpInput == null) {
            this.bumpInput = new EffectInputProperty("bumpInput");
        }
        return this.bumpInput;
    }
    
    public final void setContentInput(final Effect effect) {
        this.contentInputProperty().set(effect);
    }
    
    public final Effect getContentInput() {
        return (this.contentInput == null) ? null : this.contentInput.get();
    }
    
    public final ObjectProperty<Effect> contentInputProperty() {
        if (this.contentInput == null) {
            this.contentInput = new EffectInputProperty("contentInput");
        }
        return this.contentInput;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect bumpInput = this.getBumpInput();
        final Effect contentInput = this.getContentInput();
        return contentInput == effect || bumpInput == effect || (contentInput != null && contentInput.checkChainContains(effect)) || (bumpInput != null && bumpInput.checkChainContains(effect));
    }
    
    public final void setDiffuseConstant(final double n) {
        this.diffuseConstantProperty().set(n);
    }
    
    public final double getDiffuseConstant() {
        return (this.diffuseConstant == null) ? 1.0 : this.diffuseConstant.get();
    }
    
    public final DoubleProperty diffuseConstantProperty() {
        if (this.diffuseConstant == null) {
            this.diffuseConstant = new DoublePropertyBase(1.0) {
                public void invalidated() {
                    Lighting.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Lighting.this;
                }
                
                @Override
                public String getName() {
                    return "diffuseConstant";
                }
            };
        }
        return this.diffuseConstant;
    }
    
    public final void setSpecularConstant(final double n) {
        this.specularConstantProperty().set(n);
    }
    
    public final double getSpecularConstant() {
        return (this.specularConstant == null) ? 0.3 : this.specularConstant.get();
    }
    
    public final DoubleProperty specularConstantProperty() {
        if (this.specularConstant == null) {
            this.specularConstant = new DoublePropertyBase(0.3) {
                public void invalidated() {
                    Lighting.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Lighting.this;
                }
                
                @Override
                public String getName() {
                    return "specularConstant";
                }
            };
        }
        return this.specularConstant;
    }
    
    public final void setSpecularExponent(final double n) {
        this.specularExponentProperty().set(n);
    }
    
    public final double getSpecularExponent() {
        return (this.specularExponent == null) ? 20.0 : this.specularExponent.get();
    }
    
    public final DoubleProperty specularExponentProperty() {
        if (this.specularExponent == null) {
            this.specularExponent = new DoublePropertyBase(20.0) {
                public void invalidated() {
                    Lighting.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Lighting.this;
                }
                
                @Override
                public String getName() {
                    return "specularExponent";
                }
            };
        }
        return this.specularExponent;
    }
    
    public final void setSurfaceScale(final double n) {
        this.surfaceScaleProperty().set(n);
    }
    
    public final double getSurfaceScale() {
        return (this.surfaceScale == null) ? 1.5 : this.surfaceScale.get();
    }
    
    public final DoubleProperty surfaceScaleProperty() {
        if (this.surfaceScale == null) {
            this.surfaceScale = new DoublePropertyBase(1.5) {
                public void invalidated() {
                    Lighting.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Lighting.this;
                }
                
                @Override
                public String getName() {
                    return "surfaceScale";
                }
            };
        }
        return this.surfaceScale;
    }
    
    private Light getLightInternal() {
        final Light light = this.getLight();
        return (light == null) ? this.defaultLight : light;
    }
    
    @Override
    void update() {
        final Effect bumpInput = this.getBumpInput();
        if (bumpInput != null) {
            bumpInput.sync();
        }
        final Effect contentInput = this.getContentInput();
        if (contentInput != null) {
            contentInput.sync();
        }
        final PhongLighting phongLighting = (PhongLighting)this.getPeer();
        phongLighting.setBumpInput((bumpInput == null) ? null : bumpInput.getPeer());
        phongLighting.setContentInput((contentInput == null) ? null : contentInput.getPeer());
        phongLighting.setDiffuseConstant((float)Utils.clamp(0.0, this.getDiffuseConstant(), 2.0));
        phongLighting.setSpecularConstant((float)Utils.clamp(0.0, this.getSpecularConstant(), 2.0));
        phongLighting.setSpecularExponent((float)Utils.clamp(0.0, this.getSpecularExponent(), 40.0));
        phongLighting.setSurfaceScale((float)Utils.clamp(0.0, this.getSurfaceScale(), 10.0));
        this.lightChangeListener.register(this.getLight());
        this.getLightInternal().sync();
        phongLighting.setLight(this.getLightInternal().getPeer());
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        return Effect.getInputBounds(baseBounds, baseTransform, node, boundsAccessor, this.getContentInput());
    }
    
    private class LightChangeListener extends EffectChangeListener
    {
        Light light;
        
        public void register(final Light light) {
            this.light = light;
            super.register((this.light == null) ? null : this.light.effectDirtyProperty());
        }
        
        @Override
        public void invalidated(final Observable observable) {
            if (this.light.isEffectDirty()) {
                Lighting.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                Lighting.this.effectBoundsChanged();
            }
        }
    }
}
