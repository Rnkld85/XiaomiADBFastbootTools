// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.util.Utils;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class SepiaTone extends Effect
{
    private ObjectProperty<Effect> input;
    private DoubleProperty level;
    
    public SepiaTone() {
    }
    
    public SepiaTone(final double level) {
        this.setLevel(level);
    }
    
    @Override
    com.sun.scenario.effect.SepiaTone createPeer() {
        return new com.sun.scenario.effect.SepiaTone();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setLevel(final double n) {
        this.levelProperty().set(n);
    }
    
    public final double getLevel() {
        return (this.level == null) ? 1.0 : this.level.get();
    }
    
    public final DoubleProperty levelProperty() {
        if (this.level == null) {
            this.level = new DoublePropertyBase(1.0) {
                public void invalidated() {
                    SepiaTone.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return SepiaTone.this;
                }
                
                @Override
                public String getName() {
                    return "level";
                }
            };
        }
        return this.level;
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.SepiaTone sepiaTone = (com.sun.scenario.effect.SepiaTone)this.getPeer();
        sepiaTone.setInput((input == null) ? null : input.getPeer());
        sepiaTone.setLevel((float)Utils.clamp(0.0, this.getLevel(), 1.0));
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        return Effect.getInputBounds(baseBounds, baseTransform, node, boundsAccessor, this.getInput());
    }
    
    @Override
    Effect copy() {
        final SepiaTone sepiaTone = new SepiaTone(this.getLevel());
        sepiaTone.setInput(this.getInput());
        return sepiaTone;
    }
}
