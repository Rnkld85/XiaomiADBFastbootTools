// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.geom.RectBounds;
import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class PerspectiveTransform extends Effect
{
    private ObjectProperty<Effect> input;
    private DoubleProperty ulx;
    private DoubleProperty uly;
    private DoubleProperty urx;
    private DoubleProperty ury;
    private DoubleProperty lrx;
    private DoubleProperty lry;
    private DoubleProperty llx;
    private DoubleProperty lly;
    private float[] devcoords;
    
    public PerspectiveTransform() {
        this.devcoords = new float[8];
    }
    
    public PerspectiveTransform(final double ulx, final double uly, final double urx, final double ury, final double lrx, final double lry, final double llx, final double lly) {
        this.devcoords = new float[8];
        this.setUlx(ulx);
        this.setUly(uly);
        this.setUrx(urx);
        this.setUry(ury);
        this.setLlx(llx);
        this.setLly(lly);
        this.setLrx(lrx);
        this.setLry(lry);
    }
    
    private void updateXform() {
        ((com.sun.scenario.effect.PerspectiveTransform)this.getPeer()).setQuadMapping((float)this.getUlx(), (float)this.getUly(), (float)this.getUrx(), (float)this.getUry(), (float)this.getLrx(), (float)this.getLry(), (float)this.getLlx(), (float)this.getLly());
    }
    
    @Override
    com.sun.scenario.effect.PerspectiveTransform createPeer() {
        return new com.sun.scenario.effect.PerspectiveTransform();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setUlx(final double n) {
        this.ulxProperty().set(n);
    }
    
    public final double getUlx() {
        return (this.ulx == null) ? 0.0 : this.ulx.get();
    }
    
    public final DoubleProperty ulxProperty() {
        if (this.ulx == null) {
            this.ulx = new DoublePropertyBase() {
                public void invalidated() {
                    PerspectiveTransform.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    PerspectiveTransform.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return PerspectiveTransform.this;
                }
                
                @Override
                public String getName() {
                    return "ulx";
                }
            };
        }
        return this.ulx;
    }
    
    public final void setUly(final double n) {
        this.ulyProperty().set(n);
    }
    
    public final double getUly() {
        return (this.uly == null) ? 0.0 : this.uly.get();
    }
    
    public final DoubleProperty ulyProperty() {
        if (this.uly == null) {
            this.uly = new DoublePropertyBase() {
                public void invalidated() {
                    PerspectiveTransform.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    PerspectiveTransform.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return PerspectiveTransform.this;
                }
                
                @Override
                public String getName() {
                    return "uly";
                }
            };
        }
        return this.uly;
    }
    
    public final void setUrx(final double n) {
        this.urxProperty().set(n);
    }
    
    public final double getUrx() {
        return (this.urx == null) ? 0.0 : this.urx.get();
    }
    
    public final DoubleProperty urxProperty() {
        if (this.urx == null) {
            this.urx = new DoublePropertyBase() {
                public void invalidated() {
                    PerspectiveTransform.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    PerspectiveTransform.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return PerspectiveTransform.this;
                }
                
                @Override
                public String getName() {
                    return "urx";
                }
            };
        }
        return this.urx;
    }
    
    public final void setUry(final double n) {
        this.uryProperty().set(n);
    }
    
    public final double getUry() {
        return (this.ury == null) ? 0.0 : this.ury.get();
    }
    
    public final DoubleProperty uryProperty() {
        if (this.ury == null) {
            this.ury = new DoublePropertyBase() {
                public void invalidated() {
                    PerspectiveTransform.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    PerspectiveTransform.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return PerspectiveTransform.this;
                }
                
                @Override
                public String getName() {
                    return "ury";
                }
            };
        }
        return this.ury;
    }
    
    public final void setLrx(final double n) {
        this.lrxProperty().set(n);
    }
    
    public final double getLrx() {
        return (this.lrx == null) ? 0.0 : this.lrx.get();
    }
    
    public final DoubleProperty lrxProperty() {
        if (this.lrx == null) {
            this.lrx = new DoublePropertyBase() {
                public void invalidated() {
                    PerspectiveTransform.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    PerspectiveTransform.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return PerspectiveTransform.this;
                }
                
                @Override
                public String getName() {
                    return "lrx";
                }
            };
        }
        return this.lrx;
    }
    
    public final void setLry(final double n) {
        this.lryProperty().set(n);
    }
    
    public final double getLry() {
        return (this.lry == null) ? 0.0 : this.lry.get();
    }
    
    public final DoubleProperty lryProperty() {
        if (this.lry == null) {
            this.lry = new DoublePropertyBase() {
                public void invalidated() {
                    PerspectiveTransform.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    PerspectiveTransform.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return PerspectiveTransform.this;
                }
                
                @Override
                public String getName() {
                    return "lry";
                }
            };
        }
        return this.lry;
    }
    
    public final void setLlx(final double n) {
        this.llxProperty().set(n);
    }
    
    public final double getLlx() {
        return (this.llx == null) ? 0.0 : this.llx.get();
    }
    
    public final DoubleProperty llxProperty() {
        if (this.llx == null) {
            this.llx = new DoublePropertyBase() {
                public void invalidated() {
                    PerspectiveTransform.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    PerspectiveTransform.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return PerspectiveTransform.this;
                }
                
                @Override
                public String getName() {
                    return "llx";
                }
            };
        }
        return this.llx;
    }
    
    public final void setLly(final double n) {
        this.llyProperty().set(n);
    }
    
    public final double getLly() {
        return (this.lly == null) ? 0.0 : this.lly.get();
    }
    
    public final DoubleProperty llyProperty() {
        if (this.lly == null) {
            this.lly = new DoublePropertyBase() {
                public void invalidated() {
                    PerspectiveTransform.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    PerspectiveTransform.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return PerspectiveTransform.this;
                }
                
                @Override
                public String getName() {
                    return "lly";
                }
            };
        }
        return this.lly;
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        ((com.sun.scenario.effect.PerspectiveTransform)this.getPeer()).setInput((input == null) ? null : input.getPeer());
        this.updateXform();
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        this.setupDevCoords(baseTransform);
        float n2;
        float n = n2 = this.devcoords[0];
        float n4;
        float n3 = n4 = this.devcoords[1];
        for (int i = 2; i < this.devcoords.length; i += 2) {
            if (n2 > this.devcoords[i]) {
                n2 = this.devcoords[i];
            }
            else if (n < this.devcoords[i]) {
                n = this.devcoords[i];
            }
            if (n4 > this.devcoords[i + 1]) {
                n4 = this.devcoords[i + 1];
            }
            else if (n3 < this.devcoords[i + 1]) {
                n3 = this.devcoords[i + 1];
            }
        }
        return new RectBounds(n2, n4, n, n3);
    }
    
    private void setupDevCoords(final BaseTransform baseTransform) {
        this.devcoords[0] = (float)this.getUlx();
        this.devcoords[1] = (float)this.getUly();
        this.devcoords[2] = (float)this.getUrx();
        this.devcoords[3] = (float)this.getUry();
        this.devcoords[4] = (float)this.getLrx();
        this.devcoords[5] = (float)this.getLry();
        this.devcoords[6] = (float)this.getLlx();
        this.devcoords[7] = (float)this.getLly();
        baseTransform.transform(this.devcoords, 0, this.devcoords, 0, 4);
    }
    
    @Override
    Effect copy() {
        return new PerspectiveTransform(this.getUlx(), this.getUly(), this.getUrx(), this.getUry(), this.getLrx(), this.getLry(), this.getLlx(), this.getLly());
    }
}
