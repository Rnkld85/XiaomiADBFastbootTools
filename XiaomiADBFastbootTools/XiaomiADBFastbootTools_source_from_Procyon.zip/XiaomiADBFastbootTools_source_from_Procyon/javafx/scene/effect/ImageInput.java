// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.geom.RectBounds;
import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.geom.Point2D;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.property.ObjectPropertyBase;
import com.sun.scenario.effect.Filterable;
import com.sun.scenario.effect.Identity;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.Observable;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.beans.event.AbstractNotifyListener;
import javafx.scene.image.Image;
import javafx.beans.property.ObjectProperty;

public class ImageInput extends Effect
{
    private ObjectProperty<Image> source;
    private final AbstractNotifyListener platformImageChangeListener;
    private Image oldImage;
    private DoubleProperty x;
    private DoubleProperty y;
    
    public ImageInput() {
        this.platformImageChangeListener = new AbstractNotifyListener() {
            @Override
            public void invalidated(final Observable observable) {
                ImageInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                ImageInput.this.effectBoundsChanged();
            }
        };
    }
    
    public ImageInput(final Image source) {
        this.platformImageChangeListener = new AbstractNotifyListener() {
            @Override
            public void invalidated(final Observable observable) {
                ImageInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                ImageInput.this.effectBoundsChanged();
            }
        };
        this.setSource(source);
    }
    
    public ImageInput(final Image source, final double x, final double y) {
        this.platformImageChangeListener = new AbstractNotifyListener() {
            @Override
            public void invalidated(final Observable observable) {
                ImageInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                ImageInput.this.effectBoundsChanged();
            }
        };
        this.setSource(source);
        this.setX(x);
        this.setY(y);
    }
    
    @Override
    Identity createPeer() {
        return new Identity((Filterable)null);
    }
    
    public final void setSource(final Image image) {
        this.sourceProperty().set(image);
    }
    
    public final Image getSource() {
        return (this.source == null) ? null : this.source.get();
    }
    
    public final ObjectProperty<Image> sourceProperty() {
        if (this.source == null) {
            this.source = new ObjectPropertyBase<Image>() {
                private boolean needsListeners = false;
                
                public void invalidated() {
                    final Image image = this.get();
                    final Toolkit.ImageAccessor imageAccessor = Toolkit.getImageAccessor();
                    if (this.needsListeners) {
                        imageAccessor.getImageProperty(ImageInput.this.oldImage).removeListener(ImageInput.this.platformImageChangeListener.getWeakListener());
                    }
                    this.needsListeners = (image != null && (imageAccessor.isAnimation(image) || image.getProgress() < 1.0));
                    ImageInput.this.oldImage = image;
                    if (this.needsListeners) {
                        imageAccessor.getImageProperty(image).addListener(ImageInput.this.platformImageChangeListener.getWeakListener());
                    }
                    ImageInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ImageInput.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ImageInput.this;
                }
                
                @Override
                public String getName() {
                    return "source";
                }
            };
        }
        return this.source;
    }
    
    public final void setX(final double n) {
        this.xProperty().set(n);
    }
    
    public final double getX() {
        return (this.x == null) ? 0.0 : this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        if (this.x == null) {
            this.x = new DoublePropertyBase() {
                public void invalidated() {
                    ImageInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ImageInput.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ImageInput.this;
                }
                
                @Override
                public String getName() {
                    return "x";
                }
            };
        }
        return this.x;
    }
    
    public final void setY(final double n) {
        this.yProperty().set(n);
    }
    
    public final double getY() {
        return (this.y == null) ? 0.0 : this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        if (this.y == null) {
            this.y = new DoublePropertyBase() {
                public void invalidated() {
                    ImageInput.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    ImageInput.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return ImageInput.this;
                }
                
                @Override
                public String getName() {
                    return "y";
                }
            };
        }
        return this.y;
    }
    
    @Override
    void update() {
        final Identity identity = (Identity)this.getPeer();
        final Image source = this.getSource();
        if (source != null && Toolkit.getImageAccessor().getPlatformImage(source) != null) {
            identity.setSource(Toolkit.getToolkit().toFilterable(source));
        }
        else {
            identity.setSource(null);
        }
        identity.setLocation(new Point2D((float)this.getX(), (float)this.getY()));
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        return false;
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        final Image source = this.getSource();
        if (source != null && Toolkit.getImageAccessor().getPlatformImage(source) != null) {
            final float n = (float)this.getX();
            final float n2 = (float)this.getY();
            return Effect.transformBounds(baseTransform, new RectBounds(n, n2, n + (float)source.getWidth(), n2 + (float)source.getHeight()));
        }
        return new RectBounds();
    }
    
    @Override
    Effect copy() {
        return new ImageInput(this.getSource(), this.getX(), this.getY());
    }
}
