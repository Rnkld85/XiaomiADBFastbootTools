// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.tk.Toolkit;
import com.sun.javafx.util.Utils;
import javafx.beans.property.ObjectPropertyBase;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.scene.paint.Color;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class DropShadow extends Effect
{
    private boolean changeIsLocal;
    private ObjectProperty<Effect> input;
    private DoubleProperty radius;
    private DoubleProperty width;
    private DoubleProperty height;
    private ObjectProperty<BlurType> blurType;
    private DoubleProperty spread;
    private ObjectProperty<Color> color;
    private DoubleProperty offsetX;
    private DoubleProperty offsetY;
    
    public DropShadow() {
    }
    
    public DropShadow(final double radius, final Color color) {
        this.setRadius(radius);
        this.setColor(color);
    }
    
    public DropShadow(final double radius, final double offsetX, final double offsetY, final Color color) {
        this.setRadius(radius);
        this.setOffsetX(offsetX);
        this.setOffsetY(offsetY);
        this.setColor(color);
    }
    
    public DropShadow(final BlurType blurType, final Color color, final double radius, final double spread, final double offsetX, final double offsetY) {
        this.setBlurType(blurType);
        this.setColor(color);
        this.setRadius(radius);
        this.setSpread(spread);
        this.setOffsetX(offsetX);
        this.setOffsetY(offsetY);
    }
    
    @Override
    com.sun.scenario.effect.DropShadow createPeer() {
        return new com.sun.scenario.effect.DropShadow();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setRadius(final double n) {
        this.radiusProperty().set(n);
    }
    
    public final double getRadius() {
        return (this.radius == null) ? 10.0 : this.radius.get();
    }
    
    public final DoubleProperty radiusProperty() {
        if (this.radius == null) {
            this.radius = new DoublePropertyBase(10.0) {
                public void invalidated() {
                    final double radius = DropShadow.this.getRadius();
                    if (!DropShadow.this.changeIsLocal) {
                        DropShadow.this.changeIsLocal = true;
                        DropShadow.this.updateRadius(radius);
                        DropShadow.this.changeIsLocal = false;
                        DropShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                        DropShadow.this.effectBoundsChanged();
                    }
                }
                
                @Override
                public Object getBean() {
                    return DropShadow.this;
                }
                
                @Override
                public String getName() {
                    return "radius";
                }
            };
        }
        return this.radius;
    }
    
    private void updateRadius(final double n) {
        final double n2 = n * 2.0 + 1.0;
        if (this.width != null && this.width.isBound()) {
            if (this.height == null || !this.height.isBound()) {
                this.setHeight(n2 * 2.0 - this.getWidth());
            }
        }
        else if (this.height != null && this.height.isBound()) {
            this.setWidth(n2 * 2.0 - this.getHeight());
        }
        else {
            this.setWidth(n2);
            this.setHeight(n2);
        }
    }
    
    public final void setWidth(final double n) {
        this.widthProperty().set(n);
    }
    
    public final double getWidth() {
        return (this.width == null) ? 21.0 : this.width.get();
    }
    
    public final DoubleProperty widthProperty() {
        if (this.width == null) {
            this.width = new DoublePropertyBase(21.0) {
                public void invalidated() {
                    final double width = DropShadow.this.getWidth();
                    if (!DropShadow.this.changeIsLocal) {
                        DropShadow.this.changeIsLocal = true;
                        DropShadow.this.updateWidth(width);
                        DropShadow.this.changeIsLocal = false;
                        DropShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                        DropShadow.this.effectBoundsChanged();
                    }
                }
                
                @Override
                public Object getBean() {
                    return DropShadow.this;
                }
                
                @Override
                public String getName() {
                    return "width";
                }
            };
        }
        return this.width;
    }
    
    private void updateWidth(final double n) {
        if (this.radius == null || !this.radius.isBound()) {
            double radius = ((n + this.getHeight()) / 2.0 - 1.0) / 2.0;
            if (radius < 0.0) {
                radius = 0.0;
            }
            this.setRadius(radius);
        }
        else if (this.height == null || !this.height.isBound()) {
            this.setHeight((this.getRadius() * 2.0 + 1.0) * 2.0 - n);
        }
    }
    
    public final void setHeight(final double n) {
        this.heightProperty().set(n);
    }
    
    public final double getHeight() {
        return (this.height == null) ? 21.0 : this.height.get();
    }
    
    public final DoubleProperty heightProperty() {
        if (this.height == null) {
            this.height = new DoublePropertyBase(21.0) {
                public void invalidated() {
                    final double height = DropShadow.this.getHeight();
                    if (!DropShadow.this.changeIsLocal) {
                        DropShadow.this.changeIsLocal = true;
                        DropShadow.this.updateHeight(height);
                        DropShadow.this.changeIsLocal = false;
                        DropShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                        DropShadow.this.effectBoundsChanged();
                    }
                }
                
                @Override
                public Object getBean() {
                    return DropShadow.this;
                }
                
                @Override
                public String getName() {
                    return "height";
                }
            };
        }
        return this.height;
    }
    
    private void updateHeight(final double n) {
        if (this.radius == null || !this.radius.isBound()) {
            double radius = ((this.getWidth() + n) / 2.0 - 1.0) / 2.0;
            if (radius < 0.0) {
                radius = 0.0;
            }
            this.setRadius(radius);
        }
        else if (this.width == null || !this.width.isBound()) {
            this.setWidth((this.getRadius() * 2.0 + 1.0) * 2.0 - n);
        }
    }
    
    public final void setBlurType(final BlurType blurType) {
        this.blurTypeProperty().set(blurType);
    }
    
    public final BlurType getBlurType() {
        return (this.blurType == null) ? BlurType.THREE_PASS_BOX : this.blurType.get();
    }
    
    public final ObjectProperty<BlurType> blurTypeProperty() {
        if (this.blurType == null) {
            this.blurType = new ObjectPropertyBase<BlurType>(BlurType.THREE_PASS_BOX) {
                public void invalidated() {
                    DropShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    DropShadow.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return DropShadow.this;
                }
                
                @Override
                public String getName() {
                    return "blurType";
                }
            };
        }
        return this.blurType;
    }
    
    public final void setSpread(final double n) {
        this.spreadProperty().set(n);
    }
    
    public final double getSpread() {
        return (this.spread == null) ? 0.0 : this.spread.get();
    }
    
    public final DoubleProperty spreadProperty() {
        if (this.spread == null) {
            this.spread = new DoublePropertyBase() {
                public void invalidated() {
                    DropShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return DropShadow.this;
                }
                
                @Override
                public String getName() {
                    return "spread";
                }
            };
        }
        return this.spread;
    }
    
    public final void setColor(final Color color) {
        this.colorProperty().set(color);
    }
    
    public final Color getColor() {
        return (this.color == null) ? Color.BLACK : this.color.get();
    }
    
    public final ObjectProperty<Color> colorProperty() {
        if (this.color == null) {
            this.color = new ObjectPropertyBase<Color>(Color.BLACK) {
                public void invalidated() {
                    DropShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return DropShadow.this;
                }
                
                @Override
                public String getName() {
                    return "color";
                }
            };
        }
        return this.color;
    }
    
    public final void setOffsetX(final double n) {
        this.offsetXProperty().set(n);
    }
    
    public final double getOffsetX() {
        return (this.offsetX == null) ? 0.0 : this.offsetX.get();
    }
    
    public final DoubleProperty offsetXProperty() {
        if (this.offsetX == null) {
            this.offsetX = new DoublePropertyBase() {
                public void invalidated() {
                    DropShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    DropShadow.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return DropShadow.this;
                }
                
                @Override
                public String getName() {
                    return "offsetX";
                }
            };
        }
        return this.offsetX;
    }
    
    public final void setOffsetY(final double n) {
        this.offsetYProperty().set(n);
    }
    
    public final double getOffsetY() {
        return (this.offsetY == null) ? 0.0 : this.offsetY.get();
    }
    
    public final DoubleProperty offsetYProperty() {
        if (this.offsetY == null) {
            this.offsetY = new DoublePropertyBase() {
                public void invalidated() {
                    DropShadow.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    DropShadow.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return DropShadow.this;
                }
                
                @Override
                public String getName() {
                    return "offsetY";
                }
            };
        }
        return this.offsetY;
    }
    
    private float getClampedWidth() {
        return (float)Utils.clamp(0.0, this.getWidth(), 255.0);
    }
    
    private float getClampedHeight() {
        return (float)Utils.clamp(0.0, this.getHeight(), 255.0);
    }
    
    private float getClampedSpread() {
        return (float)Utils.clamp(0.0, this.getSpread(), 1.0);
    }
    
    private Color getColorInternal() {
        final Color color = this.getColor();
        return (color == null) ? Color.BLACK : color;
    }
    
    private BlurType getBlurTypeInternal() {
        final BlurType blurType = this.getBlurType();
        return (blurType == null) ? BlurType.THREE_PASS_BOX : blurType;
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.DropShadow dropShadow = (com.sun.scenario.effect.DropShadow)this.getPeer();
        dropShadow.setShadowSourceInput((input == null) ? null : input.getPeer());
        dropShadow.setContentInput((input == null) ? null : input.getPeer());
        dropShadow.setGaussianWidth(this.getClampedWidth());
        dropShadow.setGaussianHeight(this.getClampedHeight());
        dropShadow.setSpread(this.getClampedSpread());
        dropShadow.setShadowMode(Toolkit.getToolkit().toShadowMode(this.getBlurTypeInternal()));
        dropShadow.setColor(Toolkit.getToolkit().toColor4f(this.getColorInternal()));
        dropShadow.setOffsetX((int)this.getOffsetX());
        dropShadow.setOffsetY((int)this.getOffsetY());
    }
    
    @Override
    BaseBounds getBounds(BaseBounds inputBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        inputBounds = Effect.getInputBounds(inputBounds, BaseTransform.IDENTITY_TRANSFORM, node, boundsAccessor, this.getInput());
        final int n = (int)this.getOffsetX();
        final int n2 = (int)this.getOffsetY();
        return Effect.transformBounds(baseTransform, inputBounds).deriveWithUnion(Effect.getShadowBounds(BaseBounds.getInstance(inputBounds.getMinX() + n, inputBounds.getMinY() + n2, inputBounds.getMinZ(), inputBounds.getMaxX() + n, inputBounds.getMaxY() + n2, inputBounds.getMaxZ()), baseTransform, this.getClampedWidth(), this.getClampedHeight(), this.getBlurTypeInternal()));
    }
    
    @Override
    Effect copy() {
        final DropShadow dropShadow = new DropShadow(this.getBlurType(), this.getColor(), this.getRadius(), this.getSpread(), this.getOffsetX(), this.getOffsetY());
        dropShadow.setInput(this.getInput());
        dropShadow.setWidth(this.getWidth());
        dropShadow.setHeight(this.getHeight());
        return dropShadow;
    }
}
