// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.geom.RectBounds;
import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.util.Utils;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class Blend extends Effect
{
    private ObjectProperty<BlendMode> mode;
    private DoubleProperty opacity;
    private ObjectProperty<Effect> bottomInput;
    private ObjectProperty<Effect> topInput;
    
    private static com.sun.scenario.effect.Blend.Mode toPGMode(final BlendMode blendMode) {
        if (blendMode == null) {
            return com.sun.scenario.effect.Blend.Mode.SRC_OVER;
        }
        if (blendMode == BlendMode.SRC_OVER) {
            return com.sun.scenario.effect.Blend.Mode.SRC_OVER;
        }
        if (blendMode == BlendMode.SRC_ATOP) {
            return com.sun.scenario.effect.Blend.Mode.SRC_ATOP;
        }
        if (blendMode == BlendMode.ADD) {
            return com.sun.scenario.effect.Blend.Mode.ADD;
        }
        if (blendMode == BlendMode.MULTIPLY) {
            return com.sun.scenario.effect.Blend.Mode.MULTIPLY;
        }
        if (blendMode == BlendMode.SCREEN) {
            return com.sun.scenario.effect.Blend.Mode.SCREEN;
        }
        if (blendMode == BlendMode.OVERLAY) {
            return com.sun.scenario.effect.Blend.Mode.OVERLAY;
        }
        if (blendMode == BlendMode.DARKEN) {
            return com.sun.scenario.effect.Blend.Mode.DARKEN;
        }
        if (blendMode == BlendMode.LIGHTEN) {
            return com.sun.scenario.effect.Blend.Mode.LIGHTEN;
        }
        if (blendMode == BlendMode.COLOR_DODGE) {
            return com.sun.scenario.effect.Blend.Mode.COLOR_DODGE;
        }
        if (blendMode == BlendMode.COLOR_BURN) {
            return com.sun.scenario.effect.Blend.Mode.COLOR_BURN;
        }
        if (blendMode == BlendMode.HARD_LIGHT) {
            return com.sun.scenario.effect.Blend.Mode.HARD_LIGHT;
        }
        if (blendMode == BlendMode.SOFT_LIGHT) {
            return com.sun.scenario.effect.Blend.Mode.SOFT_LIGHT;
        }
        if (blendMode == BlendMode.DIFFERENCE) {
            return com.sun.scenario.effect.Blend.Mode.DIFFERENCE;
        }
        if (blendMode == BlendMode.EXCLUSION) {
            return com.sun.scenario.effect.Blend.Mode.EXCLUSION;
        }
        if (blendMode == BlendMode.RED) {
            return com.sun.scenario.effect.Blend.Mode.RED;
        }
        if (blendMode == BlendMode.GREEN) {
            return com.sun.scenario.effect.Blend.Mode.GREEN;
        }
        if (blendMode == BlendMode.BLUE) {
            return com.sun.scenario.effect.Blend.Mode.BLUE;
        }
        throw new AssertionError((Object)"Unrecognized blend mode: {mode}");
    }
    
    static com.sun.scenario.effect.Blend.Mode getToolkitMode(final BlendMode blendMode) {
        return toPGMode(blendMode);
    }
    
    public Blend() {
    }
    
    public Blend(final BlendMode mode) {
        this.setMode(mode);
    }
    
    public Blend(final BlendMode mode, final Effect bottomInput, final Effect topInput) {
        this.setMode(mode);
        this.setBottomInput(bottomInput);
        this.setTopInput(topInput);
    }
    
    @Override
    com.sun.scenario.effect.Blend createPeer() {
        return new com.sun.scenario.effect.Blend(toPGMode(BlendMode.SRC_OVER), com.sun.scenario.effect.Effect.DefaultInput, com.sun.scenario.effect.Effect.DefaultInput);
    }
    
    public final void setMode(final BlendMode blendMode) {
        this.modeProperty().set(blendMode);
    }
    
    public final BlendMode getMode() {
        return (this.mode == null) ? BlendMode.SRC_OVER : this.mode.get();
    }
    
    public final ObjectProperty<BlendMode> modeProperty() {
        if (this.mode == null) {
            this.mode = new ObjectPropertyBase<BlendMode>(BlendMode.SRC_OVER) {
                public void invalidated() {
                    Blend.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Blend.this;
                }
                
                @Override
                public String getName() {
                    return "mode";
                }
            };
        }
        return this.mode;
    }
    
    public final void setOpacity(final double n) {
        this.opacityProperty().set(n);
    }
    
    public final double getOpacity() {
        return (this.opacity == null) ? 1.0 : this.opacity.get();
    }
    
    public final DoubleProperty opacityProperty() {
        if (this.opacity == null) {
            this.opacity = new DoublePropertyBase(1.0) {
                public void invalidated() {
                    Blend.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Blend.this;
                }
                
                @Override
                public String getName() {
                    return "opacity";
                }
            };
        }
        return this.opacity;
    }
    
    public final void setBottomInput(final Effect effect) {
        this.bottomInputProperty().set(effect);
    }
    
    public final Effect getBottomInput() {
        return (this.bottomInput == null) ? null : this.bottomInput.get();
    }
    
    public final ObjectProperty<Effect> bottomInputProperty() {
        if (this.bottomInput == null) {
            this.bottomInput = new EffectInputProperty("bottomInput");
        }
        return this.bottomInput;
    }
    
    public final void setTopInput(final Effect effect) {
        this.topInputProperty().set(effect);
    }
    
    public final Effect getTopInput() {
        return (this.topInput == null) ? null : this.topInput.get();
    }
    
    public final ObjectProperty<Effect> topInputProperty() {
        if (this.topInput == null) {
            this.topInput = new EffectInputProperty("topInput");
        }
        return this.topInput;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect topInput = this.getTopInput();
        final Effect bottomInput = this.getBottomInput();
        return topInput == effect || bottomInput == effect || (topInput != null && topInput.checkChainContains(effect)) || (bottomInput != null && bottomInput.checkChainContains(effect));
    }
    
    @Override
    void update() {
        final Effect bottomInput = this.getBottomInput();
        final Effect topInput = this.getTopInput();
        if (topInput != null) {
            topInput.sync();
        }
        if (bottomInput != null) {
            bottomInput.sync();
        }
        final com.sun.scenario.effect.Blend blend = (com.sun.scenario.effect.Blend)this.getPeer();
        blend.setTopInput((topInput == null) ? null : topInput.getPeer());
        blend.setBottomInput((bottomInput == null) ? null : bottomInput.getPeer());
        blend.setOpacity((float)Utils.clamp(0.0, this.getOpacity(), 1.0));
        blend.setMode(toPGMode(this.getMode()));
    }
    
    @Override
    BaseBounds getBounds(final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        return Effect.getInputBounds(new RectBounds(), baseTransform, node, boundsAccessor, this.getTopInput()).deriveWithUnion(Effect.getInputBounds(new RectBounds(), baseTransform, node, boundsAccessor, this.getBottomInput()));
    }
    
    @Override
    Effect copy() {
        return new Blend(this.getMode(), this.getBottomInput(), this.getTopInput());
    }
}
