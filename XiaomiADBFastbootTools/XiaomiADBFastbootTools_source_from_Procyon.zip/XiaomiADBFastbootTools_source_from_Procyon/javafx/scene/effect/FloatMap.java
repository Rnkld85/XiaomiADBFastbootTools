// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import javafx.beans.property.IntegerPropertyBase;
import javafx.beans.property.SimpleBooleanProperty;
import com.sun.javafx.util.Utils;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.BooleanProperty;

public class FloatMap
{
    private com.sun.scenario.effect.FloatMap map;
    private float[] buf;
    private boolean mapBufferDirty;
    private BooleanProperty effectDirty;
    private IntegerProperty width;
    private IntegerProperty height;
    
    com.sun.scenario.effect.FloatMap getImpl() {
        return this.map;
    }
    
    private void updateBuffer() {
        if (this.getWidth() > 0 && this.getHeight() > 0) {
            this.buf = new float[Utils.clampMax(this.getWidth(), 4096) * Utils.clampMax(this.getHeight(), 4096) * 4];
            this.mapBufferDirty = true;
        }
    }
    
    private void update() {
        if (this.mapBufferDirty) {
            this.map = new com.sun.scenario.effect.FloatMap(Utils.clamp(1, this.getWidth(), 4096), Utils.clamp(1, this.getHeight(), 4096));
            this.mapBufferDirty = false;
        }
        this.map.put(this.buf);
    }
    
    void sync() {
        if (this.isEffectDirty()) {
            this.update();
            this.clearDirty();
        }
    }
    
    private void setEffectDirty(final boolean b) {
        this.effectDirtyProperty().set(b);
    }
    
    final BooleanProperty effectDirtyProperty() {
        if (this.effectDirty == null) {
            this.effectDirty = new SimpleBooleanProperty(this, "effectDirty");
        }
        return this.effectDirty;
    }
    
    boolean isEffectDirty() {
        return this.effectDirty != null && this.effectDirty.get();
    }
    
    private void markDirty() {
        this.setEffectDirty(true);
    }
    
    private void clearDirty() {
        this.setEffectDirty(false);
    }
    
    public FloatMap() {
        this.mapBufferDirty = true;
        this.updateBuffer();
        this.markDirty();
    }
    
    public FloatMap(final int width, final int height) {
        this.mapBufferDirty = true;
        this.setWidth(width);
        this.setHeight(height);
        this.updateBuffer();
        this.markDirty();
    }
    
    public final void setWidth(final int n) {
        this.widthProperty().set(n);
    }
    
    public final int getWidth() {
        return (this.width == null) ? 1 : this.width.get();
    }
    
    public final IntegerProperty widthProperty() {
        if (this.width == null) {
            this.width = new IntegerPropertyBase(1) {
                public void invalidated() {
                    FloatMap.this.updateBuffer();
                    FloatMap.this.markDirty();
                }
                
                @Override
                public Object getBean() {
                    return FloatMap.this;
                }
                
                @Override
                public String getName() {
                    return "width";
                }
            };
        }
        return this.width;
    }
    
    public final void setHeight(final int n) {
        this.heightProperty().set(n);
    }
    
    public final int getHeight() {
        return (this.height == null) ? 1 : this.height.get();
    }
    
    public final IntegerProperty heightProperty() {
        if (this.height == null) {
            this.height = new IntegerPropertyBase(1) {
                public void invalidated() {
                    FloatMap.this.updateBuffer();
                    FloatMap.this.markDirty();
                }
                
                @Override
                public Object getBean() {
                    return FloatMap.this;
                }
                
                @Override
                public String getName() {
                    return "height";
                }
            };
        }
        return this.height;
    }
    
    public void setSample(final int n, final int n2, final int n3, final float n4) {
        this.buf[(n + n2 * this.getWidth()) * 4 + n3] = n4;
        this.markDirty();
    }
    
    public void setSamples(final int n, final int n2, final float n3) {
        this.buf[(n + n2 * this.getWidth()) * 4 + 0] = n3;
        this.markDirty();
    }
    
    public void setSamples(final int n, final int n2, final float n3, final float n4) {
        final int n5 = (n + n2 * this.getWidth()) * 4;
        this.buf[n5 + 0] = n3;
        this.buf[n5 + 1] = n4;
        this.markDirty();
    }
    
    public void setSamples(final int n, final int n2, final float n3, final float n4, final float n5) {
        final int n6 = (n + n2 * this.getWidth()) * 4;
        this.buf[n6 + 0] = n3;
        this.buf[n6 + 1] = n4;
        this.buf[n6 + 2] = n5;
        this.markDirty();
    }
    
    public void setSamples(final int n, final int n2, final float n3, final float n4, final float n5, final float n6) {
        final int n7 = (n + n2 * this.getWidth()) * 4;
        this.buf[n7 + 0] = n3;
        this.buf[n7 + 1] = n4;
        this.buf[n7 + 2] = n5;
        this.buf[n7 + 3] = n6;
        this.markDirty();
    }
    
    FloatMap copy() {
        final FloatMap floatMap = new FloatMap(this.getWidth(), this.getHeight());
        System.arraycopy(this.buf, 0, floatMap.buf, 0, this.buf.length);
        return floatMap;
    }
}
