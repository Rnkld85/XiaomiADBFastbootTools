// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import com.sun.scenario.effect.Blend;
import com.sun.scenario.effect.EffectHelper;
import com.sun.javafx.geom.RectBounds;
import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.IntegerProperty;

public abstract class Effect
{
    private com.sun.scenario.effect.Effect peer;
    private IntegerProperty effectDirty;
    
    protected Effect() {
        this.effectDirty = new SimpleIntegerProperty(this, "effectDirty");
        this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
    }
    
    void effectBoundsChanged() {
        this.toggleDirty(EffectDirtyBits.BOUNDS_CHANGED);
    }
    
    abstract com.sun.scenario.effect.Effect createPeer();
    
    com.sun.scenario.effect.Effect getPeer() {
        if (this.peer == null) {
            this.peer = this.createPeer();
        }
        return this.peer;
    }
    
    private void setEffectDirty(final int n) {
        this.effectDirtyProperty().set(n);
    }
    
    private final IntegerProperty effectDirtyProperty() {
        return this.effectDirty;
    }
    
    private final boolean isEffectDirty() {
        return this.isEffectDirty(EffectDirtyBits.EFFECT_DIRTY);
    }
    
    final void markDirty(final EffectDirtyBits effectDirtyBits) {
        this.setEffectDirty(this.effectDirty.get() | effectDirtyBits.getMask());
    }
    
    private void toggleDirty(final EffectDirtyBits effectDirtyBits) {
        this.setEffectDirty(this.effectDirty.get() ^ effectDirtyBits.getMask());
    }
    
    private boolean isEffectDirty(final EffectDirtyBits effectDirtyBits) {
        return (this.effectDirty.get() & effectDirtyBits.getMask()) != 0x0;
    }
    
    private void clearEffectDirty(final EffectDirtyBits effectDirtyBits) {
        this.setEffectDirty(this.effectDirty.get() & ~effectDirtyBits.getMask());
    }
    
    final void sync() {
        if (this.isEffectDirty(EffectDirtyBits.EFFECT_DIRTY)) {
            this.update();
            this.clearEffectDirty(EffectDirtyBits.EFFECT_DIRTY);
        }
    }
    
    abstract void update();
    
    abstract boolean checkChainContains(final Effect p0);
    
    boolean containsCycles(final Effect effect) {
        return effect != null && (effect == this || effect.checkChainContains(this));
    }
    
    abstract BaseBounds getBounds(final BaseBounds p0, final BaseTransform p1, final Node p2, final BoundsAccessor p3);
    
    abstract Effect copy();
    
    static BaseBounds transformBounds(final BaseTransform baseTransform, final BaseBounds baseBounds) {
        if (baseTransform == null || baseTransform.isIdentity()) {
            return baseBounds;
        }
        return baseTransform.transform(baseBounds, new RectBounds());
    }
    
    static int getKernelSize(final float n, final int n2) {
        int n3 = (int)Math.ceil(n);
        if (n3 < 1) {
            n3 = 1;
        }
        return ((n3 - 1) * n2 + 1 | 0x1) / 2;
    }
    
    static BaseBounds getShadowBounds(BaseBounds deriveWithPadding, final BaseTransform baseTransform, final float n, final float n2, final BlurType blurType) {
        int n3 = 0;
        int n4 = 0;
        switch (blurType) {
            case GAUSSIAN: {
                final float n5 = (n < 1.0f) ? 0.0f : ((n - 1.0f) / 2.0f);
                final float n6 = (n2 < 1.0f) ? 0.0f : ((n2 - 1.0f) / 2.0f);
                n3 = (int)Math.ceil(n5);
                n4 = (int)Math.ceil(n6);
                break;
            }
            case ONE_PASS_BOX: {
                n3 = getKernelSize((float)Math.round(n / 3.0f), 1);
                n4 = getKernelSize((float)Math.round(n2 / 3.0f), 1);
                break;
            }
            case TWO_PASS_BOX: {
                n3 = getKernelSize((float)Math.round(n / 3.0f), 2);
                n4 = getKernelSize((float)Math.round(n2 / 3.0f), 2);
                break;
            }
            case THREE_PASS_BOX: {
                n3 = getKernelSize((float)Math.round(n / 3.0f), 3);
                n4 = getKernelSize((float)Math.round(n2 / 3.0f), 3);
                break;
            }
        }
        deriveWithPadding = deriveWithPadding.deriveWithPadding((float)n3, (float)n4, 0.0f);
        return transformBounds(baseTransform, deriveWithPadding);
    }
    
    static BaseBounds getInputBounds(BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor, final Effect effect) {
        if (effect != null) {
            baseBounds = effect.getBounds(baseBounds, baseTransform, node, boundsAccessor);
        }
        else {
            baseBounds = boundsAccessor.getGeomBounds(baseBounds, baseTransform, node);
        }
        return baseBounds;
    }
    
    static {
        EffectHelper.setEffectAccessor(new EffectHelper.EffectAccessor() {
            @Override
            public com.sun.scenario.effect.Effect getPeer(final Effect effect) {
                return effect.getPeer();
            }
            
            @Override
            public void sync(final Effect effect) {
                effect.sync();
            }
            
            @Override
            public IntegerProperty effectDirtyProperty(final Effect effect) {
                return effect.effectDirtyProperty();
            }
            
            @Override
            public boolean isEffectDirty(final Effect effect) {
                return effect.isEffectDirty();
            }
            
            @Override
            public BaseBounds getBounds(final Effect effect, final BaseBounds baseBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
                return effect.getBounds(baseBounds, baseTransform, node, boundsAccessor);
            }
            
            @Override
            public Effect copy(final Effect effect) {
                return effect.copy();
            }
            
            @Override
            public Blend.Mode getToolkitBlendMode(final BlendMode blendMode) {
                return javafx.scene.effect.Blend.getToolkitMode(blendMode);
            }
        });
    }
    
    class EffectInputChangeListener extends EffectChangeListener
    {
        private int oldBits;
        
        public void register(final Effect effect) {
            super.register((effect == null) ? null : effect.effectDirtyProperty());
            if (effect != null) {
                this.oldBits = effect.effectDirtyProperty().get();
            }
        }
        
        @Override
        public void invalidated(final Observable observable) {
            final int value = ((IntegerProperty)observable).get();
            final int n = value ^ this.oldBits;
            this.oldBits = value;
            if (EffectDirtyBits.isSet(n, EffectDirtyBits.EFFECT_DIRTY) && EffectDirtyBits.isSet(value, EffectDirtyBits.EFFECT_DIRTY)) {
                Effect.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
            }
            if (EffectDirtyBits.isSet(n, EffectDirtyBits.BOUNDS_CHANGED)) {
                Effect.this.toggleDirty(EffectDirtyBits.BOUNDS_CHANGED);
            }
        }
    }
    
    class EffectInputProperty extends ObjectPropertyBase<Effect>
    {
        private final String propertyName;
        private Effect validInput;
        private final EffectInputChangeListener effectChangeListener;
        
        public EffectInputProperty(final String propertyName) {
            this.validInput = null;
            this.effectChangeListener = new EffectInputChangeListener();
            this.propertyName = propertyName;
        }
        
        public void invalidated() {
            final Effect validInput = super.get();
            if (!Effect.this.containsCycles(validInput)) {
                this.validInput = validInput;
                this.effectChangeListener.register(validInput);
                Effect.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                Effect.this.effectBoundsChanged();
                return;
            }
            if (this.isBound()) {
                this.unbind();
                this.set(this.validInput);
                throw new IllegalArgumentException("Cycle in effect chain detected, binding was set to incorrect value, unbinding the input property");
            }
            this.set(this.validInput);
            throw new IllegalArgumentException("Cycle in effect chain detected");
        }
        
        @Override
        public Object getBean() {
            return Effect.this;
        }
        
        @Override
        public String getName() {
            return this.propertyName;
        }
    }
}
