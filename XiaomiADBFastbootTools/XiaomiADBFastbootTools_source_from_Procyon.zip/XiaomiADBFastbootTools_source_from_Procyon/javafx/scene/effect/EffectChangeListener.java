// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import javafx.beans.value.ObservableValue;
import com.sun.javafx.beans.event.AbstractNotifyListener;

abstract class EffectChangeListener extends AbstractNotifyListener
{
    protected ObservableValue registredOn;
    
    public void register(final ObservableValue registredOn) {
        if (this.registredOn == registredOn) {
            return;
        }
        if (this.registredOn != null) {
            this.registredOn.removeListener(this.getWeakListener());
        }
        this.registredOn = registredOn;
        if (this.registredOn != null) {
            this.registredOn.addListener(this.getWeakListener());
        }
    }
}
