// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.util.Utils;
import com.sun.scenario.effect.light.SpotLight;
import com.sun.scenario.effect.light.PointLight;
import javafx.beans.property.DoublePropertyBase;
import com.sun.scenario.effect.light.DistantLight;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.BooleanProperty;
import javafx.scene.paint.Color;
import javafx.beans.property.ObjectProperty;

public abstract class Light
{
    private com.sun.scenario.effect.light.Light peer;
    private ObjectProperty<Color> color;
    private BooleanProperty effectDirty;
    
    protected Light() {
        this.markDirty();
    }
    
    abstract com.sun.scenario.effect.light.Light createPeer();
    
    com.sun.scenario.effect.light.Light getPeer() {
        if (this.peer == null) {
            this.peer = this.createPeer();
        }
        return this.peer;
    }
    
    public final void setColor(final Color color) {
        this.colorProperty().set(color);
    }
    
    public final Color getColor() {
        return (this.color == null) ? Color.WHITE : this.color.get();
    }
    
    public final ObjectProperty<Color> colorProperty() {
        if (this.color == null) {
            this.color = new ObjectPropertyBase<Color>(Color.WHITE) {
                public void invalidated() {
                    Light.this.markDirty();
                }
                
                @Override
                public Object getBean() {
                    return Light.this;
                }
                
                @Override
                public String getName() {
                    return "color";
                }
            };
        }
        return this.color;
    }
    
    void sync() {
        if (this.isEffectDirty()) {
            this.update();
            this.clearDirty();
        }
    }
    
    private Color getColorInternal() {
        final Color color = this.getColor();
        return (color == null) ? Color.WHITE : color;
    }
    
    void update() {
        this.getPeer().setColor(Toolkit.getToolkit().toColor4f(this.getColorInternal()));
    }
    
    private void setEffectDirty(final boolean b) {
        this.effectDirtyProperty().set(b);
    }
    
    final BooleanProperty effectDirtyProperty() {
        if (this.effectDirty == null) {
            this.effectDirty = new SimpleBooleanProperty(this, "effectDirty");
        }
        return this.effectDirty;
    }
    
    boolean isEffectDirty() {
        return this.effectDirty != null && this.effectDirty.get();
    }
    
    final void markDirty() {
        this.setEffectDirty(true);
    }
    
    final void clearDirty() {
        this.setEffectDirty(false);
    }
    
    public static class Distant extends Light
    {
        private DoubleProperty azimuth;
        private DoubleProperty elevation;
        
        public Distant() {
        }
        
        public Distant(final double azimuth, final double elevation, final Color color) {
            this.setAzimuth(azimuth);
            this.setElevation(elevation);
            this.setColor(color);
        }
        
        @Override
        DistantLight createPeer() {
            return new DistantLight();
        }
        
        public final void setAzimuth(final double n) {
            this.azimuthProperty().set(n);
        }
        
        public final double getAzimuth() {
            return (this.azimuth == null) ? 45.0 : this.azimuth.get();
        }
        
        public final DoubleProperty azimuthProperty() {
            if (this.azimuth == null) {
                this.azimuth = new DoublePropertyBase(45.0) {
                    public void invalidated() {
                        Distant.this.markDirty();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Distant.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "azimuth";
                    }
                };
            }
            return this.azimuth;
        }
        
        public final void setElevation(final double n) {
            this.elevationProperty().set(n);
        }
        
        public final double getElevation() {
            return (this.elevation == null) ? 45.0 : this.elevation.get();
        }
        
        public final DoubleProperty elevationProperty() {
            if (this.elevation == null) {
                this.elevation = new DoublePropertyBase(45.0) {
                    public void invalidated() {
                        Distant.this.markDirty();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Distant.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "elevation";
                    }
                };
            }
            return this.elevation;
        }
        
        @Override
        void update() {
            super.update();
            final DistantLight distantLight = (DistantLight)this.getPeer();
            distantLight.setAzimuth((float)this.getAzimuth());
            distantLight.setElevation((float)this.getElevation());
        }
    }
    
    public static class Point extends Light
    {
        private DoubleProperty x;
        private DoubleProperty y;
        private DoubleProperty z;
        
        public Point() {
        }
        
        public Point(final double x, final double y, final double z, final Color color) {
            this.setX(x);
            this.setY(y);
            this.setZ(z);
            this.setColor(color);
        }
        
        @Override
        PointLight createPeer() {
            return new PointLight();
        }
        
        public final void setX(final double n) {
            this.xProperty().set(n);
        }
        
        public final double getX() {
            return (this.x == null) ? 0.0 : this.x.get();
        }
        
        public final DoubleProperty xProperty() {
            if (this.x == null) {
                this.x = new DoublePropertyBase() {
                    public void invalidated() {
                        Point.this.markDirty();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Point.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "x";
                    }
                };
            }
            return this.x;
        }
        
        public final void setY(final double n) {
            this.yProperty().set(n);
        }
        
        public final double getY() {
            return (this.y == null) ? 0.0 : this.y.get();
        }
        
        public final DoubleProperty yProperty() {
            if (this.y == null) {
                this.y = new DoublePropertyBase() {
                    public void invalidated() {
                        Point.this.markDirty();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Point.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "y";
                    }
                };
            }
            return this.y;
        }
        
        public final void setZ(final double n) {
            this.zProperty().set(n);
        }
        
        public final double getZ() {
            return (this.z == null) ? 0.0 : this.z.get();
        }
        
        public final DoubleProperty zProperty() {
            if (this.z == null) {
                this.z = new DoublePropertyBase() {
                    public void invalidated() {
                        Point.this.markDirty();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Point.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "z";
                    }
                };
            }
            return this.z;
        }
        
        @Override
        void update() {
            super.update();
            final PointLight pointLight = (PointLight)this.getPeer();
            pointLight.setX((float)this.getX());
            pointLight.setY((float)this.getY());
            pointLight.setZ((float)this.getZ());
        }
    }
    
    public static class Spot extends Point
    {
        private DoubleProperty pointsAtX;
        private DoubleProperty pointsAtY;
        private DoubleProperty pointsAtZ;
        private DoubleProperty specularExponent;
        
        public Spot() {
        }
        
        public Spot(final double x, final double y, final double z, final double specularExponent, final Color color) {
            this.setX(x);
            this.setY(y);
            this.setZ(z);
            this.setSpecularExponent(specularExponent);
            this.setColor(color);
        }
        
        @Override
        SpotLight createPeer() {
            return new SpotLight();
        }
        
        public final void setPointsAtX(final double n) {
            this.pointsAtXProperty().set(n);
        }
        
        public final double getPointsAtX() {
            return (this.pointsAtX == null) ? 0.0 : this.pointsAtX.get();
        }
        
        public final DoubleProperty pointsAtXProperty() {
            if (this.pointsAtX == null) {
                this.pointsAtX = new DoublePropertyBase() {
                    public void invalidated() {
                        Spot.this.markDirty();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Spot.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "pointsAtX";
                    }
                };
            }
            return this.pointsAtX;
        }
        
        public final void setPointsAtY(final double n) {
            this.pointsAtYProperty().set(n);
        }
        
        public final double getPointsAtY() {
            return (this.pointsAtY == null) ? 0.0 : this.pointsAtY.get();
        }
        
        public final DoubleProperty pointsAtYProperty() {
            if (this.pointsAtY == null) {
                this.pointsAtY = new DoublePropertyBase() {
                    public void invalidated() {
                        Spot.this.markDirty();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Spot.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "pointsAtY";
                    }
                };
            }
            return this.pointsAtY;
        }
        
        public final void setPointsAtZ(final double n) {
            this.pointsAtZProperty().set(n);
        }
        
        public final double getPointsAtZ() {
            return (this.pointsAtZ == null) ? 0.0 : this.pointsAtZ.get();
        }
        
        public final DoubleProperty pointsAtZProperty() {
            if (this.pointsAtZ == null) {
                this.pointsAtZ = new DoublePropertyBase() {
                    public void invalidated() {
                        Spot.this.markDirty();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Spot.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "pointsAtZ";
                    }
                };
            }
            return this.pointsAtZ;
        }
        
        public final void setSpecularExponent(final double n) {
            this.specularExponentProperty().set(n);
        }
        
        public final double getSpecularExponent() {
            return (this.specularExponent == null) ? 1.0 : this.specularExponent.get();
        }
        
        public final DoubleProperty specularExponentProperty() {
            if (this.specularExponent == null) {
                this.specularExponent = new DoublePropertyBase(1.0) {
                    public void invalidated() {
                        Spot.this.markDirty();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Spot.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "specularExponent";
                    }
                };
            }
            return this.specularExponent;
        }
        
        @Override
        void update() {
            super.update();
            final SpotLight spotLight = (SpotLight)this.getPeer();
            spotLight.setPointsAtX((float)this.getPointsAtX());
            spotLight.setPointsAtY((float)this.getPointsAtY());
            spotLight.setPointsAtZ((float)this.getPointsAtZ());
            spotLight.setSpecularExponent((float)Utils.clamp(0.0, this.getSpecularExponent(), 4.0));
        }
    }
}
