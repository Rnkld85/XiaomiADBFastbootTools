// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.effect;

import com.sun.javafx.scene.BoundsAccessor;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.util.Utils;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class Reflection extends Effect
{
    private ObjectProperty<Effect> input;
    private DoubleProperty topOffset;
    private DoubleProperty topOpacity;
    private DoubleProperty bottomOpacity;
    private DoubleProperty fraction;
    
    public Reflection() {
    }
    
    public Reflection(final double topOffset, final double fraction, final double topOpacity, final double bottomOpacity) {
        this.setBottomOpacity(bottomOpacity);
        this.setTopOffset(topOffset);
        this.setTopOpacity(topOpacity);
        this.setFraction(fraction);
    }
    
    @Override
    com.sun.scenario.effect.Reflection createPeer() {
        return new com.sun.scenario.effect.Reflection();
    }
    
    public final void setInput(final Effect effect) {
        this.inputProperty().set(effect);
    }
    
    public final Effect getInput() {
        return (this.input == null) ? null : this.input.get();
    }
    
    public final ObjectProperty<Effect> inputProperty() {
        if (this.input == null) {
            this.input = new EffectInputProperty("input");
        }
        return this.input;
    }
    
    @Override
    boolean checkChainContains(final Effect effect) {
        final Effect input = this.getInput();
        return input != null && (input == effect || input.checkChainContains(effect));
    }
    
    public final void setTopOffset(final double n) {
        this.topOffsetProperty().set(n);
    }
    
    public final double getTopOffset() {
        return (this.topOffset == null) ? 0.0 : this.topOffset.get();
    }
    
    public final DoubleProperty topOffsetProperty() {
        if (this.topOffset == null) {
            this.topOffset = new DoublePropertyBase() {
                public void invalidated() {
                    Reflection.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    Reflection.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return Reflection.this;
                }
                
                @Override
                public String getName() {
                    return "topOffset";
                }
            };
        }
        return this.topOffset;
    }
    
    public final void setTopOpacity(final double n) {
        this.topOpacityProperty().set(n);
    }
    
    public final double getTopOpacity() {
        return (this.topOpacity == null) ? 0.5 : this.topOpacity.get();
    }
    
    public final DoubleProperty topOpacityProperty() {
        if (this.topOpacity == null) {
            this.topOpacity = new DoublePropertyBase(0.5) {
                public void invalidated() {
                    Reflection.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Reflection.this;
                }
                
                @Override
                public String getName() {
                    return "topOpacity";
                }
            };
        }
        return this.topOpacity;
    }
    
    public final void setBottomOpacity(final double n) {
        this.bottomOpacityProperty().set(n);
    }
    
    public final double getBottomOpacity() {
        return (this.bottomOpacity == null) ? 0.0 : this.bottomOpacity.get();
    }
    
    public final DoubleProperty bottomOpacityProperty() {
        if (this.bottomOpacity == null) {
            this.bottomOpacity = new DoublePropertyBase() {
                public void invalidated() {
                    Reflection.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Reflection.this;
                }
                
                @Override
                public String getName() {
                    return "bottomOpacity";
                }
            };
        }
        return this.bottomOpacity;
    }
    
    public final void setFraction(final double n) {
        this.fractionProperty().set(n);
    }
    
    public final double getFraction() {
        return (this.fraction == null) ? 0.75 : this.fraction.get();
    }
    
    public final DoubleProperty fractionProperty() {
        if (this.fraction == null) {
            this.fraction = new DoublePropertyBase(0.75) {
                public void invalidated() {
                    Reflection.this.markDirty(EffectDirtyBits.EFFECT_DIRTY);
                    Reflection.this.effectBoundsChanged();
                }
                
                @Override
                public Object getBean() {
                    return Reflection.this;
                }
                
                @Override
                public String getName() {
                    return "fraction";
                }
            };
        }
        return this.fraction;
    }
    
    private float getClampedFraction() {
        return (float)Utils.clamp(0.0, this.getFraction(), 1.0);
    }
    
    private float getClampedBottomOpacity() {
        return (float)Utils.clamp(0.0, this.getBottomOpacity(), 1.0);
    }
    
    private float getClampedTopOpacity() {
        return (float)Utils.clamp(0.0, this.getTopOpacity(), 1.0);
    }
    
    @Override
    void update() {
        final Effect input = this.getInput();
        if (input != null) {
            input.sync();
        }
        final com.sun.scenario.effect.Reflection reflection = (com.sun.scenario.effect.Reflection)this.getPeer();
        reflection.setInput((input == null) ? null : input.getPeer());
        reflection.setFraction(this.getClampedFraction());
        reflection.setTopOffset((float)this.getTopOffset());
        reflection.setBottomOpacity(this.getClampedBottomOpacity());
        reflection.setTopOpacity(this.getClampedTopOpacity());
    }
    
    @Override
    BaseBounds getBounds(BaseBounds inputBounds, final BaseTransform baseTransform, final Node node, final BoundsAccessor boundsAccessor) {
        inputBounds = Effect.getInputBounds(inputBounds, BaseTransform.IDENTITY_TRANSFORM, node, boundsAccessor, this.getInput());
        inputBounds.roundOut();
        final float minX = inputBounds.getMinX();
        final float n = inputBounds.getMaxY() + (float)this.getTopOffset();
        return Effect.transformBounds(baseTransform, BaseBounds.getInstance(minX, n, inputBounds.getMinZ(), inputBounds.getMaxX(), n + this.getClampedFraction() * inputBounds.getHeight(), inputBounds.getMaxZ()).deriveWithUnion(inputBounds));
    }
    
    @Override
    Effect copy() {
        final Reflection reflection = new Reflection(this.getTopOffset(), this.getFraction(), this.getTopOpacity(), this.getBottomOpacity());
        reflection.setInput(reflection.getInput());
        return reflection;
    }
}
