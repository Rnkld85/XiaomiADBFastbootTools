// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.paint;

import com.sun.javafx.scene.paint.GradientUtils;
import java.util.Iterator;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.NamedArg;
import java.util.List;

public final class LinearGradient extends Paint
{
    private double startX;
    private double startY;
    private double endX;
    private double endY;
    private boolean proportional;
    private CycleMethod cycleMethod;
    private List<Stop> stops;
    private final boolean opaque;
    private Object platformPaint;
    private int hash;
    
    public final double getStartX() {
        return this.startX;
    }
    
    public final double getStartY() {
        return this.startY;
    }
    
    public final double getEndX() {
        return this.endX;
    }
    
    public final double getEndY() {
        return this.endY;
    }
    
    public final boolean isProportional() {
        return this.proportional;
    }
    
    public final CycleMethod getCycleMethod() {
        return this.cycleMethod;
    }
    
    public final List<Stop> getStops() {
        return this.stops;
    }
    
    @Override
    public final boolean isOpaque() {
        return this.opaque;
    }
    
    public LinearGradient(@NamedArg("startX") final double startX, @NamedArg("startY") final double startY, @NamedArg(value = "endX", defaultValue = "1") final double endX, @NamedArg(value = "endY", defaultValue = "1") final double endY, @NamedArg(value = "proportional", defaultValue = "true") final boolean proportional, @NamedArg("cycleMethod") final CycleMethod cycleMethod, @NamedArg("stops") final Stop... array) {
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        this.proportional = proportional;
        this.cycleMethod = ((cycleMethod == null) ? CycleMethod.NO_CYCLE : cycleMethod);
        this.stops = Stop.normalize(array);
        this.opaque = this.determineOpacity();
    }
    
    public LinearGradient(@NamedArg("startX") final double startX, @NamedArg("startY") final double startY, @NamedArg(value = "endX", defaultValue = "1") final double endX, @NamedArg(value = "endY", defaultValue = "1") final double endY, @NamedArg(value = "proportional", defaultValue = "true") final boolean proportional, @NamedArg("cycleMethod") final CycleMethod cycleMethod, @NamedArg("stops") final List<Stop> list) {
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        this.proportional = proportional;
        this.cycleMethod = ((cycleMethod == null) ? CycleMethod.NO_CYCLE : cycleMethod);
        this.stops = Stop.normalize(list);
        this.opaque = this.determineOpacity();
    }
    
    private boolean determineOpacity() {
        for (int size = this.stops.size(), i = 0; i < size; ++i) {
            if (!this.stops.get(i).getColor().isOpaque()) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    Object acc_getPlatformPaint() {
        if (this.platformPaint == null) {
            this.platformPaint = Toolkit.getToolkit().getPaint((Paint)this);
        }
        return this.platformPaint;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == null) {
            return false;
        }
        if (o == this) {
            return true;
        }
        if (o instanceof LinearGradient) {
            final LinearGradient linearGradient = (LinearGradient)o;
            return this.startX == linearGradient.startX && this.startY == linearGradient.startY && this.endX == linearGradient.endX && this.endY == linearGradient.endY && this.proportional == linearGradient.proportional && this.cycleMethod == linearGradient.cycleMethod && this.stops.equals(linearGradient.stops);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            long n = 37L * (37L * (37L * (37L * (37L * (37L * 17L + Double.doubleToLongBits(this.startX)) + Double.doubleToLongBits(this.startY)) + Double.doubleToLongBits(this.endX)) + Double.doubleToLongBits(this.endY)) + (this.proportional ? 1231L : 1237L)) + this.cycleMethod.hashCode();
            final Iterator<Stop> iterator = this.stops.iterator();
            while (iterator.hasNext()) {
                n = 37L * n + iterator.next().hashCode();
            }
            this.hash = (int)(n ^ n >> 32);
        }
        return this.hash;
    }
    
    @Override
    public String toString() {
        final StringBuilder append = new StringBuilder("linear-gradient(from ").append(GradientUtils.lengthToString(this.startX, this.proportional)).append(" ").append(GradientUtils.lengthToString(this.startY, this.proportional)).append(" to ").append(GradientUtils.lengthToString(this.endX, this.proportional)).append(" ").append(GradientUtils.lengthToString(this.endY, this.proportional)).append(", ");
        switch (this.cycleMethod) {
            case REFLECT: {
                append.append("reflect").append(", ");
                break;
            }
            case REPEAT: {
                append.append("repeat").append(", ");
                break;
            }
        }
        final Iterator<Stop> iterator = this.stops.iterator();
        while (iterator.hasNext()) {
            append.append(iterator.next()).append(", ");
        }
        append.delete(append.length() - 2, append.length());
        append.append(")");
        return append.toString();
    }
    
    public static LinearGradient valueOf(String substring) {
        if (substring == null) {
            throw new NullPointerException("gradient must be specified");
        }
        final String prefix = "linear-gradient(";
        final String suffix = ")";
        if (substring.startsWith(prefix)) {
            if (!substring.endsWith(suffix)) {
                throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, suffix));
            }
            substring = substring.substring(prefix.length(), substring.length() - suffix.length());
        }
        final GradientUtils.Parser parser = new GradientUtils.Parser(substring);
        if (parser.getSize() < 2) {
            throw new IllegalArgumentException("Invalid gradient specification");
        }
        GradientUtils.Point point = GradientUtils.Point.MIN;
        GradientUtils.Point point2 = GradientUtils.Point.MIN;
        GradientUtils.Point point3 = GradientUtils.Point.MIN;
        GradientUtils.Point point4 = GradientUtils.Point.MIN;
        final String[] splitCurrentToken = parser.splitCurrentToken();
        if ("from".equals(splitCurrentToken[0])) {
            GradientUtils.Parser.checkNumberOfArguments(splitCurrentToken, 5);
            point = parser.parsePoint(splitCurrentToken[1]);
            point2 = parser.parsePoint(splitCurrentToken[2]);
            if (!"to".equals(splitCurrentToken[3])) {
                throw new IllegalArgumentException("Invalid gradient specification, \"to\" expected");
            }
            point3 = parser.parsePoint(splitCurrentToken[4]);
            point4 = parser.parsePoint(splitCurrentToken[5]);
            parser.shift();
        }
        else if ("to".equals(splitCurrentToken[0])) {
            int n = 0;
            int n2 = 0;
            for (int n3 = 1; n3 < 3 && n3 < splitCurrentToken.length; ++n3) {
                if ("left".equals(splitCurrentToken[n3])) {
                    point = GradientUtils.Point.MAX;
                    point3 = GradientUtils.Point.MIN;
                    ++n;
                }
                else if ("right".equals(splitCurrentToken[n3])) {
                    point = GradientUtils.Point.MIN;
                    point3 = GradientUtils.Point.MAX;
                    ++n;
                }
                else if ("top".equals(splitCurrentToken[n3])) {
                    point2 = GradientUtils.Point.MAX;
                    point4 = GradientUtils.Point.MIN;
                    ++n2;
                }
                else {
                    if (!"bottom".equals(splitCurrentToken[n3])) {
                        throw new IllegalArgumentException("Invalid gradient specification, unknown value after 'to'");
                    }
                    point2 = GradientUtils.Point.MIN;
                    point4 = GradientUtils.Point.MAX;
                    ++n2;
                }
            }
            if (n2 > 1) {
                throw new IllegalArgumentException("Invalid gradient specification, vertical direction set twice after 'to'");
            }
            if (n > 1) {
                throw new IllegalArgumentException("Invalid gradient specification, horizontal direction set twice after 'to'");
            }
            parser.shift();
        }
        else {
            point2 = GradientUtils.Point.MIN;
            point4 = GradientUtils.Point.MAX;
        }
        CycleMethod cycleMethod = CycleMethod.NO_CYCLE;
        final String currentToken = parser.getCurrentToken();
        if ("repeat".equals(currentToken)) {
            cycleMethod = CycleMethod.REPEAT;
            parser.shift();
        }
        else if ("reflect".equals(currentToken)) {
            cycleMethod = CycleMethod.REFLECT;
            parser.shift();
        }
        double sqrt = 0.0;
        if (!point.proportional) {
            final double n4 = point3.value - point.value;
            final double n5 = point4.value - point2.value;
            sqrt = Math.sqrt(n4 * n4 + n5 * n5);
        }
        return new LinearGradient(point.value, point2.value, point3.value, point4.value, point.proportional, cycleMethod, parser.parseStops(point.proportional, sqrt));
    }
}
