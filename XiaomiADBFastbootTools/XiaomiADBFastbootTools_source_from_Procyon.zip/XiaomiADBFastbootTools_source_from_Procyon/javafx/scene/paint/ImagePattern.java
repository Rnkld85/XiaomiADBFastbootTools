// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.paint;

import javafx.beans.InvalidationListener;
import com.sun.javafx.beans.event.AbstractNotifyListener;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.NamedArg;
import javafx.scene.image.Image;

public final class ImagePattern extends Paint
{
    private Image image;
    private double x;
    private double y;
    private double width;
    private double height;
    private boolean proportional;
    private Object platformPaint;
    
    public final Image getImage() {
        return this.image;
    }
    
    public final double getX() {
        return this.x;
    }
    
    public final double getY() {
        return this.y;
    }
    
    public final double getWidth() {
        return this.width;
    }
    
    public final double getHeight() {
        return this.height;
    }
    
    public final boolean isProportional() {
        return this.proportional;
    }
    
    @Override
    public final boolean isOpaque() {
        return ((com.sun.prism.paint.ImagePattern)this.acc_getPlatformPaint()).isOpaque();
    }
    
    public ImagePattern(@NamedArg("image") final Image image) {
        this.width = 1.0;
        this.height = 1.0;
        this.proportional = true;
        if (image == null) {
            throw new NullPointerException("Image must be non-null.");
        }
        if (image.getProgress() < 1.0) {
            throw new IllegalArgumentException("Image not yet loaded");
        }
        this.image = image;
    }
    
    public ImagePattern(@NamedArg("image") final Image image, @NamedArg("x") final double x, @NamedArg("y") final double y, @NamedArg("width") final double width, @NamedArg("height") final double height, @NamedArg("proportional") final boolean proportional) {
        this.width = 1.0;
        this.height = 1.0;
        this.proportional = true;
        if (image == null) {
            throw new NullPointerException("Image must be non-null.");
        }
        if (image.getProgress() < 1.0) {
            throw new IllegalArgumentException("Image not yet loaded");
        }
        this.image = image;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.proportional = proportional;
    }
    
    @Override
    boolean acc_isMutable() {
        return Toolkit.getImageAccessor().isAnimation(this.image);
    }
    
    @Override
    void acc_addListener(final AbstractNotifyListener abstractNotifyListener) {
        Toolkit.getImageAccessor().getImageProperty(this.image).addListener(abstractNotifyListener);
    }
    
    @Override
    void acc_removeListener(final AbstractNotifyListener abstractNotifyListener) {
        Toolkit.getImageAccessor().getImageProperty(this.image).removeListener(abstractNotifyListener);
    }
    
    @Override
    Object acc_getPlatformPaint() {
        if (this.acc_isMutable() || this.platformPaint == null) {
            this.platformPaint = Toolkit.getToolkit().getPaint(this);
            assert this.platformPaint != null;
        }
        return this.platformPaint;
    }
}
