// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.paint;

import com.sun.javafx.scene.paint.MaterialHelper;
import com.sun.javafx.sg.prism.NGPhongMaterial;
import com.sun.javafx.logging.PlatformLogger;
import javafx.application.Platform;
import javafx.application.ConditionalFeature;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.BooleanProperty;

public abstract class Material
{
    private final BooleanProperty dirty;
    
    protected Material() {
        this.dirty = new SimpleBooleanProperty(true);
        if (!Platform.isSupported(ConditionalFeature.SCENE3D)) {
            PlatformLogger.getLogger(Material.class.getName()).warning("System can't support ConditionalFeature.SCENE3D");
        }
    }
    
    final boolean isDirty() {
        return this.dirty.getValue();
    }
    
    void setDirty(final boolean b) {
        this.dirty.setValue(b);
    }
    
    final BooleanProperty dirtyProperty() {
        return this.dirty;
    }
    
    abstract void updatePG();
    
    abstract NGPhongMaterial getNGMaterial();
    
    static {
        MaterialHelper.setMaterialAccessor(new MaterialHelper.MaterialAccessor() {
            @Override
            public BooleanProperty dirtyProperty(final Material material) {
                return material.dirtyProperty();
            }
            
            @Override
            public void updatePG(final Material material) {
                material.updatePG();
            }
            
            @Override
            public NGPhongMaterial getNGMaterial(final Material material) {
                return material.getNGMaterial();
            }
        });
    }
}
