// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.paint;

import com.sun.javafx.scene.paint.MaterialHelper;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.Observable;
import com.sun.javafx.sg.prism.NGPhongMaterial;
import javafx.scene.image.Image;
import com.sun.javafx.beans.event.AbstractNotifyListener;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;

public class PhongMaterial extends Material
{
    private boolean diffuseColorDirty;
    private boolean specularColorDirty;
    private boolean specularPowerDirty;
    private boolean diffuseMapDirty;
    private boolean specularMapDirty;
    private boolean bumpMapDirty;
    private boolean selfIlluminationMapDirty;
    private ObjectProperty<Color> diffuseColor;
    private ObjectProperty<Color> specularColor;
    private DoubleProperty specularPower;
    private final AbstractNotifyListener platformImageChangeListener;
    private ObjectProperty<Image> diffuseMap;
    private Image oldDiffuseMap;
    private ObjectProperty<Image> specularMap;
    private Image oldSpecularMap;
    private ObjectProperty<Image> bumpMap;
    private Image oldBumpMap;
    private ObjectProperty<Image> selfIlluminationMap;
    private Image oldSelfIlluminationMap;
    private NGPhongMaterial peer;
    
    public PhongMaterial() {
        this.diffuseColorDirty = true;
        this.specularColorDirty = true;
        this.specularPowerDirty = true;
        this.diffuseMapDirty = true;
        this.specularMapDirty = true;
        this.bumpMapDirty = true;
        this.selfIlluminationMapDirty = true;
        this.platformImageChangeListener = new AbstractNotifyListener() {
            @Override
            public void invalidated(final Observable observable) {
                if (PhongMaterial.this.oldDiffuseMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldDiffuseMap)) {
                    PhongMaterial.this.diffuseMapDirty = true;
                }
                else if (PhongMaterial.this.oldSpecularMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldSpecularMap)) {
                    PhongMaterial.this.specularMapDirty = true;
                }
                else if (PhongMaterial.this.oldBumpMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldBumpMap)) {
                    PhongMaterial.this.bumpMapDirty = true;
                }
                else if (PhongMaterial.this.oldSelfIlluminationMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldSelfIlluminationMap)) {
                    PhongMaterial.this.selfIlluminationMapDirty = true;
                }
                PhongMaterial.this.setDirty(true);
            }
        };
        this.setDiffuseColor(Color.WHITE);
    }
    
    public PhongMaterial(final Color diffuseColor) {
        this.diffuseColorDirty = true;
        this.specularColorDirty = true;
        this.specularPowerDirty = true;
        this.diffuseMapDirty = true;
        this.specularMapDirty = true;
        this.bumpMapDirty = true;
        this.selfIlluminationMapDirty = true;
        this.platformImageChangeListener = new AbstractNotifyListener() {
            @Override
            public void invalidated(final Observable observable) {
                if (PhongMaterial.this.oldDiffuseMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldDiffuseMap)) {
                    PhongMaterial.this.diffuseMapDirty = true;
                }
                else if (PhongMaterial.this.oldSpecularMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldSpecularMap)) {
                    PhongMaterial.this.specularMapDirty = true;
                }
                else if (PhongMaterial.this.oldBumpMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldBumpMap)) {
                    PhongMaterial.this.bumpMapDirty = true;
                }
                else if (PhongMaterial.this.oldSelfIlluminationMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldSelfIlluminationMap)) {
                    PhongMaterial.this.selfIlluminationMapDirty = true;
                }
                PhongMaterial.this.setDirty(true);
            }
        };
        this.setDiffuseColor(diffuseColor);
    }
    
    public PhongMaterial(final Color diffuseColor, final Image diffuseMap, final Image specularMap, final Image bumpMap, final Image selfIlluminationMap) {
        this.diffuseColorDirty = true;
        this.specularColorDirty = true;
        this.specularPowerDirty = true;
        this.diffuseMapDirty = true;
        this.specularMapDirty = true;
        this.bumpMapDirty = true;
        this.selfIlluminationMapDirty = true;
        this.platformImageChangeListener = new AbstractNotifyListener() {
            @Override
            public void invalidated(final Observable observable) {
                if (PhongMaterial.this.oldDiffuseMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldDiffuseMap)) {
                    PhongMaterial.this.diffuseMapDirty = true;
                }
                else if (PhongMaterial.this.oldSpecularMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldSpecularMap)) {
                    PhongMaterial.this.specularMapDirty = true;
                }
                else if (PhongMaterial.this.oldBumpMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldBumpMap)) {
                    PhongMaterial.this.bumpMapDirty = true;
                }
                else if (PhongMaterial.this.oldSelfIlluminationMap != null && observable == Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldSelfIlluminationMap)) {
                    PhongMaterial.this.selfIlluminationMapDirty = true;
                }
                PhongMaterial.this.setDirty(true);
            }
        };
        this.setDiffuseColor(diffuseColor);
        this.setDiffuseMap(diffuseMap);
        this.setSpecularMap(specularMap);
        this.setBumpMap(bumpMap);
        this.setSelfIlluminationMap(selfIlluminationMap);
    }
    
    public final void setDiffuseColor(final Color color) {
        this.diffuseColorProperty().set(color);
    }
    
    public final Color getDiffuseColor() {
        return (this.diffuseColor == null) ? null : this.diffuseColor.get();
    }
    
    public final ObjectProperty<Color> diffuseColorProperty() {
        if (this.diffuseColor == null) {
            this.diffuseColor = new SimpleObjectProperty<Color>(this, "diffuseColor") {
                @Override
                protected void invalidated() {
                    PhongMaterial.this.diffuseColorDirty = true;
                    PhongMaterial.this.setDirty(true);
                }
            };
        }
        return this.diffuseColor;
    }
    
    public final void setSpecularColor(final Color color) {
        this.specularColorProperty().set(color);
    }
    
    public final Color getSpecularColor() {
        return (this.specularColor == null) ? null : this.specularColor.get();
    }
    
    public final ObjectProperty<Color> specularColorProperty() {
        if (this.specularColor == null) {
            this.specularColor = new SimpleObjectProperty<Color>(this, "specularColor") {
                @Override
                protected void invalidated() {
                    PhongMaterial.this.specularColorDirty = true;
                    PhongMaterial.this.setDirty(true);
                }
            };
        }
        return this.specularColor;
    }
    
    public final void setSpecularPower(final double n) {
        this.specularPowerProperty().set(n);
    }
    
    public final double getSpecularPower() {
        return (this.specularPower == null) ? 32.0 : this.specularPower.get();
    }
    
    public final DoubleProperty specularPowerProperty() {
        if (this.specularPower == null) {
            this.specularPower = new SimpleDoubleProperty(this, "specularPower", 32.0) {
                public void invalidated() {
                    PhongMaterial.this.specularPowerDirty = true;
                    PhongMaterial.this.setDirty(true);
                }
            };
        }
        return this.specularPower;
    }
    
    public final void setDiffuseMap(final Image image) {
        this.diffuseMapProperty().set(image);
    }
    
    public final Image getDiffuseMap() {
        return (this.diffuseMap == null) ? null : this.diffuseMap.get();
    }
    
    public final ObjectProperty<Image> diffuseMapProperty() {
        if (this.diffuseMap == null) {
            this.diffuseMap = new SimpleObjectProperty<Image>(this, "diffuseMap") {
                private boolean needsListeners = false;
                
                public void invalidated() {
                    final Image image = this.get();
                    if (this.needsListeners) {
                        Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldDiffuseMap).removeListener(PhongMaterial.this.platformImageChangeListener.getWeakListener());
                    }
                    this.needsListeners = (image != null && (Toolkit.getImageAccessor().isAnimation(image) || image.getProgress() < 1.0));
                    if (this.needsListeners) {
                        Toolkit.getImageAccessor().getImageProperty(image).addListener(PhongMaterial.this.platformImageChangeListener.getWeakListener());
                    }
                    PhongMaterial.this.oldDiffuseMap = image;
                    PhongMaterial.this.diffuseMapDirty = true;
                    PhongMaterial.this.setDirty(true);
                }
            };
        }
        return this.diffuseMap;
    }
    
    public final void setSpecularMap(final Image image) {
        this.specularMapProperty().set(image);
    }
    
    public final Image getSpecularMap() {
        return (this.specularMap == null) ? null : this.specularMap.get();
    }
    
    public final ObjectProperty<Image> specularMapProperty() {
        if (this.specularMap == null) {
            this.specularMap = new SimpleObjectProperty<Image>(this, "specularMap") {
                private boolean needsListeners = false;
                
                public void invalidated() {
                    final Image image = this.get();
                    if (this.needsListeners) {
                        Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldSpecularMap).removeListener(PhongMaterial.this.platformImageChangeListener.getWeakListener());
                    }
                    this.needsListeners = (image != null && (Toolkit.getImageAccessor().isAnimation(image) || image.getProgress() < 1.0));
                    if (this.needsListeners) {
                        Toolkit.getImageAccessor().getImageProperty(image).addListener(PhongMaterial.this.platformImageChangeListener.getWeakListener());
                    }
                    PhongMaterial.this.oldSpecularMap = image;
                    PhongMaterial.this.specularMapDirty = true;
                    PhongMaterial.this.setDirty(true);
                }
            };
        }
        return this.specularMap;
    }
    
    public final void setBumpMap(final Image image) {
        this.bumpMapProperty().set(image);
    }
    
    public final Image getBumpMap() {
        return (this.bumpMap == null) ? null : this.bumpMap.get();
    }
    
    public final ObjectProperty<Image> bumpMapProperty() {
        if (this.bumpMap == null) {
            this.bumpMap = new SimpleObjectProperty<Image>(this, "bumpMap") {
                private boolean needsListeners = false;
                
                public void invalidated() {
                    final Image image = this.get();
                    if (this.needsListeners) {
                        Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldBumpMap).removeListener(PhongMaterial.this.platformImageChangeListener.getWeakListener());
                    }
                    this.needsListeners = (image != null && (Toolkit.getImageAccessor().isAnimation(image) || image.getProgress() < 1.0));
                    if (this.needsListeners) {
                        Toolkit.getImageAccessor().getImageProperty(image).addListener(PhongMaterial.this.platformImageChangeListener.getWeakListener());
                    }
                    PhongMaterial.this.oldBumpMap = image;
                    PhongMaterial.this.bumpMapDirty = true;
                    PhongMaterial.this.setDirty(true);
                }
            };
        }
        return this.bumpMap;
    }
    
    public final void setSelfIlluminationMap(final Image image) {
        this.selfIlluminationMapProperty().set(image);
    }
    
    public final Image getSelfIlluminationMap() {
        return (this.selfIlluminationMap == null) ? null : this.selfIlluminationMap.get();
    }
    
    public final ObjectProperty<Image> selfIlluminationMapProperty() {
        if (this.selfIlluminationMap == null) {
            this.selfIlluminationMap = new SimpleObjectProperty<Image>(this, "selfIlluminationMap") {
                private boolean needsListeners = false;
                
                public void invalidated() {
                    final Image image = this.get();
                    if (this.needsListeners) {
                        Toolkit.getImageAccessor().getImageProperty(PhongMaterial.this.oldSelfIlluminationMap).removeListener(PhongMaterial.this.platformImageChangeListener.getWeakListener());
                    }
                    this.needsListeners = (image != null && (Toolkit.getImageAccessor().isAnimation(image) || image.getProgress() < 1.0));
                    if (this.needsListeners) {
                        Toolkit.getImageAccessor().getImageProperty(image).addListener(PhongMaterial.this.platformImageChangeListener.getWeakListener());
                    }
                    PhongMaterial.this.oldSelfIlluminationMap = image;
                    PhongMaterial.this.selfIlluminationMapDirty = true;
                    PhongMaterial.this.setDirty(true);
                }
            };
        }
        return this.selfIlluminationMap;
    }
    
    @Override
    void setDirty(final boolean dirty) {
        super.setDirty(dirty);
        if (!dirty) {
            this.diffuseColorDirty = false;
            this.specularColorDirty = false;
            this.specularPowerDirty = false;
            this.diffuseMapDirty = false;
            this.specularMapDirty = false;
            this.bumpMapDirty = false;
            this.selfIlluminationMapDirty = false;
        }
    }
    
    @Override
    NGPhongMaterial getNGMaterial() {
        if (this.peer == null) {
            this.peer = new NGPhongMaterial();
        }
        return this.peer;
    }
    
    @Override
    void updatePG() {
        if (!this.isDirty()) {
            return;
        }
        final NGPhongMaterial ngMaterial = MaterialHelper.getNGMaterial(this);
        if (this.diffuseColorDirty) {
            ngMaterial.setDiffuseColor((this.getDiffuseColor() == null) ? null : Toolkit.getPaintAccessor().getPlatformPaint(this.getDiffuseColor()));
        }
        if (this.specularColorDirty) {
            ngMaterial.setSpecularColor((this.getSpecularColor() == null) ? null : Toolkit.getPaintAccessor().getPlatformPaint(this.getSpecularColor()));
        }
        if (this.specularPowerDirty) {
            ngMaterial.setSpecularPower((float)this.getSpecularPower());
        }
        if (this.diffuseMapDirty) {
            ngMaterial.setDiffuseMap((this.getDiffuseMap() == null) ? null : Toolkit.getImageAccessor().getPlatformImage(this.getDiffuseMap()));
        }
        if (this.specularMapDirty) {
            ngMaterial.setSpecularMap((this.getSpecularMap() == null) ? null : Toolkit.getImageAccessor().getPlatformImage(this.getSpecularMap()));
        }
        if (this.bumpMapDirty) {
            ngMaterial.setBumpMap((this.getBumpMap() == null) ? null : Toolkit.getImageAccessor().getPlatformImage(this.getBumpMap()));
        }
        if (this.selfIlluminationMapDirty) {
            ngMaterial.setSelfIllumMap((this.getSelfIlluminationMap() == null) ? null : Toolkit.getImageAccessor().getPlatformImage(this.getSelfIlluminationMap()));
        }
        this.setDirty(false);
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljavafx/scene/paint/Color;Ljavafx/scene/paint/Color;DLjavafx/scene/image/Image;Ljavafx/scene/image/Image;Ljavafx/scene/image/Image;Ljavafx/scene/image/Image;)Ljava/lang/String;, this.getDiffuseColor(), this.getSpecularColor(), this.getSpecularPower(), this.getDiffuseMap(), this.getSpecularMap(), this.getBumpMap(), this.getSelfIlluminationMap());
    }
}
