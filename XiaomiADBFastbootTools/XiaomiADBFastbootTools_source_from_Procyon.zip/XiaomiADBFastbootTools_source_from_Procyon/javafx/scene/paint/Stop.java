// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.paint;

import javafx.beans.NamedArg;
import java.util.Iterator;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class Stop
{
    static final List<Stop> NO_STOPS;
    private double offset;
    private Color color;
    private int hash;
    
    static List<Stop> normalize(final Stop[] a) {
        return normalize((a == null) ? null : Arrays.asList(a));
    }
    
    static List<Stop> normalize(final List<Stop> list) {
        if (list == null) {
            return Stop.NO_STOPS;
        }
        Stop stop = null;
        Object o = null;
        final ArrayList<Stop> list2 = new ArrayList<Stop>(list.size());
        for (Stop stop2 : list) {
            if (stop2 != null) {
                if (stop2.getColor() == null) {
                    continue;
                }
                final double offset = stop2.getOffset();
                if (offset <= 0.0) {
                    if (stop != null && offset < stop.getOffset()) {
                        continue;
                    }
                    stop = stop2;
                }
                else if (offset >= 1.0) {
                    if (o != null && offset >= ((Stop)o).getOffset()) {
                        continue;
                    }
                    o = stop2;
                }
                else {
                    if (offset != offset) {
                        continue;
                    }
                    for (int i = list2.size() - 1; i >= 0; --i) {
                        final Stop stop3 = list2.get(i);
                        if (stop3.getOffset() <= offset) {
                            if (stop3.getOffset() == offset) {
                                if (i > 0 && ((Stop)list2.get(i - 1)).getOffset() == offset) {
                                    list2.set(i, stop2);
                                }
                                else {
                                    list2.add(i + 1, stop2);
                                }
                            }
                            else {
                                list2.add(i + 1, stop2);
                            }
                            stop2 = null;
                            break;
                        }
                    }
                    if (stop2 == null) {
                        continue;
                    }
                    list2.add(0, stop2);
                }
            }
        }
        if (stop == null) {
            Color color;
            if (list2.isEmpty()) {
                if (o == null) {
                    return Stop.NO_STOPS;
                }
                color = ((Stop)o).getColor();
            }
            else {
                color = list2.get(0).getColor();
                if (o == null && list2.size() == 1) {
                    list2.clear();
                }
            }
            stop = new Stop(0.0, color);
        }
        else if (stop.getOffset() < 0.0) {
            stop = new Stop(0.0, stop.getColor());
        }
        list2.add(0, stop);
        if (o == null) {
            o = new Stop(1.0, ((Stop)list2.get(list2.size() - 1)).getColor());
        }
        else if (((Stop)o).getOffset() > 1.0) {
            o = new Stop(1.0, ((Stop)o).getColor());
        }
        list2.add((Stop)o);
        return (List<Stop>)Collections.unmodifiableList((List<?>)list2);
    }
    
    public final double getOffset() {
        return this.offset;
    }
    
    public final Color getColor() {
        return this.color;
    }
    
    public Stop(@NamedArg("offset") final double offset, @NamedArg(value = "color", defaultValue = "BLACK") final Color color) {
        this.hash = 0;
        this.offset = offset;
        this.color = color;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == null) {
            return false;
        }
        if (o == this) {
            return true;
        }
        if (o instanceof Stop) {
            final Stop stop = (Stop)o;
            return this.offset == stop.offset && ((this.color != null) ? this.color.equals(stop.color) : (stop.color == null));
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            final long n = 37L * (37L * 17L + Double.doubleToLongBits(this.offset)) + this.color.hashCode();
            this.hash = (int)(n ^ n >> 32);
        }
        return this.hash;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljavafx/scene/paint/Color;D)Ljava/lang/String;, this.color, this.offset * 100.0);
    }
    
    static {
        NO_STOPS = Collections.unmodifiableList((List<? extends Stop>)Arrays.asList(new Stop(0.0, Color.TRANSPARENT), new Stop(1.0, Color.TRANSPARENT)));
    }
}
