// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.paint;

import com.sun.javafx.tk.Toolkit;
import com.sun.javafx.beans.event.AbstractNotifyListener;

public abstract class Paint
{
    Paint() {
    }
    
    boolean acc_isMutable() {
        return false;
    }
    
    abstract Object acc_getPlatformPaint();
    
    void acc_addListener(final AbstractNotifyListener abstractNotifyListener) {
        throw new UnsupportedOperationException("Not Supported.");
    }
    
    void acc_removeListener(final AbstractNotifyListener abstractNotifyListener) {
        throw new UnsupportedOperationException("Not Supported.");
    }
    
    public abstract boolean isOpaque();
    
    public static Paint valueOf(final String s) {
        if (s == null) {
            throw new NullPointerException("paint must be specified");
        }
        if (s.startsWith("linear-gradient(")) {
            return LinearGradient.valueOf(s);
        }
        if (s.startsWith("radial-gradient(")) {
            return RadialGradient.valueOf(s);
        }
        return Color.valueOf(s);
    }
    
    static {
        Toolkit.setPaintAccessor(new Toolkit.PaintAccessor() {
            @Override
            public boolean isMutable(final Paint paint) {
                return paint.acc_isMutable();
            }
            
            @Override
            public Object getPlatformPaint(final Paint paint) {
                return paint.acc_getPlatformPaint();
            }
            
            @Override
            public void addListener(final Paint paint, final AbstractNotifyListener abstractNotifyListener) {
                paint.acc_addListener(abstractNotifyListener);
            }
            
            @Override
            public void removeListener(final Paint paint, final AbstractNotifyListener abstractNotifyListener) {
                paint.acc_removeListener(abstractNotifyListener);
            }
        });
    }
}
