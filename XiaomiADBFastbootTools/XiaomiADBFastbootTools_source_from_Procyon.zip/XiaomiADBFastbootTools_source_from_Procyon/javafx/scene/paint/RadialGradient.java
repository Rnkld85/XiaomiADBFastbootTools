// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.paint;

import com.sun.javafx.scene.paint.GradientUtils;
import java.util.Iterator;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.NamedArg;
import java.util.List;

public final class RadialGradient extends Paint
{
    private double focusAngle;
    private double focusDistance;
    private double centerX;
    private double centerY;
    private double radius;
    private boolean proportional;
    private CycleMethod cycleMethod;
    private List<Stop> stops;
    private final boolean opaque;
    private Object platformPaint;
    private int hash;
    
    public final double getFocusAngle() {
        return this.focusAngle;
    }
    
    public final double getFocusDistance() {
        return this.focusDistance;
    }
    
    public final double getCenterX() {
        return this.centerX;
    }
    
    public final double getCenterY() {
        return this.centerY;
    }
    
    public final double getRadius() {
        return this.radius;
    }
    
    public final boolean isProportional() {
        return this.proportional;
    }
    
    public final CycleMethod getCycleMethod() {
        return this.cycleMethod;
    }
    
    public final List<Stop> getStops() {
        return this.stops;
    }
    
    @Override
    public final boolean isOpaque() {
        return this.opaque;
    }
    
    public RadialGradient(@NamedArg("focusAngle") final double focusAngle, @NamedArg("focusDistance") final double focusDistance, @NamedArg("centerX") final double centerX, @NamedArg("centerY") final double centerY, @NamedArg(value = "radius", defaultValue = "1") final double radius, @NamedArg(value = "proportional", defaultValue = "true") final boolean proportional, @NamedArg("cycleMethod") final CycleMethod cycleMethod, @NamedArg("stops") final Stop... array) {
        this.focusAngle = focusAngle;
        this.focusDistance = focusDistance;
        this.centerX = centerX;
        this.centerY = centerY;
        this.radius = radius;
        this.proportional = proportional;
        this.cycleMethod = ((cycleMethod == null) ? CycleMethod.NO_CYCLE : cycleMethod);
        this.stops = Stop.normalize(array);
        this.opaque = this.determineOpacity();
    }
    
    public RadialGradient(@NamedArg("focusAngle") final double focusAngle, @NamedArg("focusDistance") final double focusDistance, @NamedArg("centerX") final double centerX, @NamedArg("centerY") final double centerY, @NamedArg(value = "radius", defaultValue = "1") final double radius, @NamedArg(value = "proportional", defaultValue = "true") final boolean proportional, @NamedArg("cycleMethod") final CycleMethod cycleMethod, @NamedArg("stops") final List<Stop> list) {
        this.focusAngle = focusAngle;
        this.focusDistance = focusDistance;
        this.centerX = centerX;
        this.centerY = centerY;
        this.radius = radius;
        this.proportional = proportional;
        this.cycleMethod = ((cycleMethod == null) ? CycleMethod.NO_CYCLE : cycleMethod);
        this.stops = Stop.normalize(list);
        this.opaque = this.determineOpacity();
    }
    
    private boolean determineOpacity() {
        for (int size = this.stops.size(), i = 0; i < size; ++i) {
            if (!this.stops.get(i).getColor().isOpaque()) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    Object acc_getPlatformPaint() {
        if (this.platformPaint == null) {
            this.platformPaint = Toolkit.getToolkit().getPaint((Paint)this);
        }
        return this.platformPaint;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof RadialGradient) {
            final RadialGradient radialGradient = (RadialGradient)o;
            return this.focusAngle == radialGradient.focusAngle && this.focusDistance == radialGradient.focusDistance && this.centerX == radialGradient.centerX && this.centerY == radialGradient.centerY && this.radius == radialGradient.radius && this.proportional == radialGradient.proportional && this.cycleMethod == radialGradient.cycleMethod && this.stops.equals(radialGradient.stops);
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        if (this.hash == 0) {
            long n = 37L * (37L * (37L * (37L * (37L * (37L * (37L * 17L + Double.doubleToLongBits(this.focusAngle)) + Double.doubleToLongBits(this.focusDistance)) + Double.doubleToLongBits(this.centerX)) + Double.doubleToLongBits(this.centerY)) + Double.doubleToLongBits(this.radius)) + (this.proportional ? 1231 : 1237)) + this.cycleMethod.hashCode();
            final Iterator<Stop> iterator = this.stops.iterator();
            while (iterator.hasNext()) {
                n = 37L * n + iterator.next().hashCode();
            }
            this.hash = (int)(n ^ n >> 32);
        }
        return this.hash;
    }
    
    @Override
    public String toString() {
        final StringBuilder append = new StringBuilder("radial-gradient(focus-angle ").append(this.focusAngle).append("deg, focus-distance ").append(this.focusDistance * 100.0).append("% , center ").append(GradientUtils.lengthToString(this.centerX, this.proportional)).append(" ").append(GradientUtils.lengthToString(this.centerY, this.proportional)).append(", radius ").append(GradientUtils.lengthToString(this.radius, this.proportional)).append(", ");
        switch (this.cycleMethod) {
            case REFLECT: {
                append.append("reflect").append(", ");
                break;
            }
            case REPEAT: {
                append.append("repeat").append(", ");
                break;
            }
        }
        final Iterator<Stop> iterator = this.stops.iterator();
        while (iterator.hasNext()) {
            append.append(iterator.next()).append(", ");
        }
        append.delete(append.length() - 2, append.length());
        append.append(")");
        return append.toString();
    }
    
    public static RadialGradient valueOf(String substring) {
        if (substring == null) {
            throw new NullPointerException("gradient must be specified");
        }
        final String prefix = "radial-gradient(";
        final String suffix = ")";
        if (substring.startsWith(prefix)) {
            if (!substring.endsWith(suffix)) {
                throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, suffix));
            }
            substring = substring.substring(prefix.length(), substring.length() - suffix.length());
        }
        final GradientUtils.Parser parser = new GradientUtils.Parser(substring);
        if (parser.getSize() < 2) {
            throw new IllegalArgumentException("Invalid gradient specification");
        }
        double angle = 0.0;
        double percentage = 0.0;
        final String[] splitCurrentToken = parser.splitCurrentToken();
        if ("focus-angle".equals(splitCurrentToken[0])) {
            GradientUtils.Parser.checkNumberOfArguments(splitCurrentToken, 1);
            angle = GradientUtils.Parser.parseAngle(splitCurrentToken[1]);
            parser.shift();
        }
        final String[] splitCurrentToken2 = parser.splitCurrentToken();
        if ("focus-distance".equals(splitCurrentToken2[0])) {
            GradientUtils.Parser.checkNumberOfArguments(splitCurrentToken2, 1);
            percentage = GradientUtils.Parser.parsePercentage(splitCurrentToken2[1]);
            parser.shift();
        }
        final String[] splitCurrentToken3 = parser.splitCurrentToken();
        GradientUtils.Point point;
        GradientUtils.Point point2;
        if ("center".equals(splitCurrentToken3[0])) {
            GradientUtils.Parser.checkNumberOfArguments(splitCurrentToken3, 2);
            point = parser.parsePoint(splitCurrentToken3[1]);
            point2 = parser.parsePoint(splitCurrentToken3[2]);
            parser.shift();
        }
        else {
            point = GradientUtils.Point.MIN;
            point2 = GradientUtils.Point.MIN;
        }
        final String[] splitCurrentToken4 = parser.splitCurrentToken();
        if ("radius".equals(splitCurrentToken4[0])) {
            GradientUtils.Parser.checkNumberOfArguments(splitCurrentToken4, 1);
            final GradientUtils.Point point3 = parser.parsePoint(splitCurrentToken4[1]);
            parser.shift();
            CycleMethod cycleMethod = CycleMethod.NO_CYCLE;
            final String currentToken = parser.getCurrentToken();
            if ("repeat".equals(currentToken)) {
                cycleMethod = CycleMethod.REPEAT;
                parser.shift();
            }
            else if ("reflect".equals(currentToken)) {
                cycleMethod = CycleMethod.REFLECT;
                parser.shift();
            }
            return new RadialGradient(angle, percentage, point.value, point2.value, point3.value, point3.proportional, cycleMethod, parser.parseStops(point3.proportional, point3.value));
        }
        throw new IllegalArgumentException("Invalid gradient specification: radius must be specified");
    }
}
