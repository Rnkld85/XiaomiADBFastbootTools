// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.paint;

public enum CycleMethod
{
    NO_CYCLE, 
    REFLECT, 
    REPEAT;
}
