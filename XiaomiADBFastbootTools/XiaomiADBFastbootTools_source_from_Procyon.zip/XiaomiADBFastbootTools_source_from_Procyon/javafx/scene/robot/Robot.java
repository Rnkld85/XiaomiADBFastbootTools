// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.robot;

import javafx.geometry.Rectangle2D;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.scene.input.MouseButton;
import javafx.geometry.Point2D;
import java.util.Objects;
import javafx.scene.input.KeyCode;
import com.sun.javafx.tk.Toolkit;
import java.security.Permission;
import com.sun.javafx.FXPermissions;
import com.sun.glass.ui.Application;
import com.sun.glass.ui.GlassRobot;

public final class Robot
{
    private final GlassRobot peer;
    
    public Robot() {
        Application.checkEventThread();
        final SecurityManager securityManager = System.getSecurityManager();
        if (securityManager != null) {
            securityManager.checkPermission(FXPermissions.CREATE_ROBOT_PERMISSION);
        }
        (this.peer = Toolkit.getToolkit().createRobot()).create();
    }
    
    public void keyPress(final KeyCode obj) {
        Objects.requireNonNull(obj, "keyCode must not be null");
        this.peer.keyPress(obj);
    }
    
    public void keyRelease(final KeyCode obj) {
        Objects.requireNonNull(obj, "keyCode must not be null");
        this.peer.keyRelease(obj);
    }
    
    public void keyType(final KeyCode obj) {
        Objects.requireNonNull(obj, "keyCode must not be null");
        this.keyPress(obj);
        this.keyRelease(obj);
    }
    
    public double getMouseX() {
        return this.peer.getMouseX();
    }
    
    public double getMouseY() {
        return this.peer.getMouseY();
    }
    
    public Point2D getMousePosition() {
        return new Point2D(this.getMouseX(), this.getMouseY());
    }
    
    public void mouseMove(final double n, final double n2) {
        this.peer.mouseMove(n, n2);
    }
    
    public final void mouseMove(final Point2D obj) {
        Objects.requireNonNull(obj);
        this.mouseMove(obj.getX(), obj.getY());
    }
    
    public void mousePress(final MouseButton... obj) {
        Objects.requireNonNull(obj, "buttons must not be null");
        this.peer.mousePress(obj);
    }
    
    public void mouseRelease(final MouseButton... obj) {
        Objects.requireNonNull(obj, "buttons must not be null");
        this.peer.mouseRelease(obj);
    }
    
    public void mouseClick(final MouseButton... obj) {
        Objects.requireNonNull(obj, "buttons must not be null");
        this.mousePress(obj);
        this.mouseRelease(obj);
    }
    
    public void mouseWheel(final int n) {
        this.peer.mouseWheel(n);
    }
    
    public Color getPixelColor(final double n, final double n2) {
        return this.peer.getPixelColor(n, n2);
    }
    
    public Color getPixelColor(final Point2D point2D) {
        return this.getPixelColor(point2D.getX(), point2D.getY());
    }
    
    public WritableImage getScreenCapture(final WritableImage writableImage, final double n, final double n2, final double n3, final double n4, final boolean b) {
        return this.peer.getScreenCapture(writableImage, n, n2, n3, n4, b);
    }
    
    public WritableImage getScreenCapture(final WritableImage writableImage, final double n, final double n2, final double n3, final double n4) {
        return this.getScreenCapture(writableImage, n, n2, n3, n4, true);
    }
    
    public WritableImage getScreenCapture(final WritableImage writableImage, final Rectangle2D obj) {
        Objects.requireNonNull(obj);
        return this.getScreenCapture(writableImage, obj.getMinX(), obj.getMinY(), obj.getWidth(), obj.getHeight(), true);
    }
    
    public WritableImage getScreenCapture(final WritableImage writableImage, final Rectangle2D obj, final boolean b) {
        Objects.requireNonNull(obj);
        return this.getScreenCapture(writableImage, obj.getMinX(), obj.getMinY(), obj.getWidth(), obj.getHeight(), b);
    }
}
