// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import com.sun.javafx.geom.Point2D;
import com.sun.javafx.geom.transform.NoninvertibleTransformException;
import com.sun.javafx.util.TempState;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.RectBounds;
import javafx.collections.FXCollections;
import javafx.stage.Window;
import com.sun.javafx.stage.WindowHelper;
import com.sun.javafx.collections.VetoableListDecorator;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import java.util.HashSet;
import com.sun.javafx.scene.CssFlags;
import com.sun.javafx.scene.ParentHelper;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.css.Selector;
import com.sun.javafx.scene.input.PickResultChooser;
import com.sun.javafx.geom.PickRay;
import com.sun.javafx.css.StyleManager;
import java.util.Collections;
import java.util.Collection;
import com.sun.javafx.scene.NodeHelper;
import java.util.Iterator;
import com.sun.javafx.sg.prism.NGNode;
import com.sun.javafx.scene.DirtyBits;
import com.sun.javafx.util.Utils;
import com.sun.javafx.sg.prism.NGGroup;
import java.util.ArrayList;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.scene.LayoutFlags;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import com.sun.javafx.scene.traversal.ParentTraversalEngine;
import javafx.collections.ObservableList;
import java.util.List;
import java.util.Set;

public abstract class Parent extends Node
{
    static final int DIRTY_CHILDREN_THRESHOLD = 10;
    private static final boolean warnOnAutoMove;
    private static final int REMOVED_CHILDREN_THRESHOLD = 20;
    private boolean removedChildrenOptimizationDisabled;
    private final Set<Node> childSet;
    private int startIdx;
    private int pgChildrenSize;
    private final List<Node> viewOrderChildren;
    private boolean childrenTriggerPermutation;
    private List<Node> removed;
    private boolean geomChanged;
    private boolean childSetModified;
    private final ObservableList<Node> children;
    private final ObservableList<Node> unmodifiableChildren;
    private List<Node> unmodifiableManagedChildren;
    private ParentTraversalEngine traversalEngine;
    private ReadOnlyBooleanWrapper needsLayout;
    LayoutFlags layoutFlag;
    private boolean performingLayout;
    private boolean sizeCacheClear;
    private double prefWidthCache;
    private double prefHeightCache;
    private double minWidthCache;
    private double minHeightCache;
    private boolean forceParentLayout;
    private Node currentLayoutChild;
    private boolean sceneRoot;
    boolean layoutRoot;
    private final ObservableList<String> stylesheets;
    private BaseBounds tmp;
    private BaseBounds cachedBounds;
    private boolean cachedBoundsInvalid;
    private int dirtyChildrenCount;
    private ArrayList<Node> dirtyChildren;
    private Node top;
    private Node left;
    private Node bottom;
    private Node right;
    private Node near;
    private Node far;
    private final int LEFT_INVALID = 1;
    private final int TOP_INVALID = 2;
    private final int NEAR_INVALID = 4;
    private final int RIGHT_INVALID = 8;
    private final int BOTTOM_INVALID = 16;
    private final int FAR_INVALID = 32;
    private Node currentlyProcessedChild;
    
    private void doUpdatePeer() {
        final NGGroup ngGroup = this.getPeer();
        if (Utils.assertionEnabled()) {
            final List<NGNode> children = ngGroup.getChildren();
            if (children.size() != this.pgChildrenSize) {
                System.err.println(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, children.size(), this.pgChildrenSize));
            }
        }
        if (this.isDirty(DirtyBits.PARENT_CHILDREN)) {
            ngGroup.clearFrom(this.startIdx);
            for (int i = this.startIdx; i < this.children.size(); ++i) {
                ngGroup.add(i, ((Node)this.children.get(i)).getPeer());
            }
            if (this.removedChildrenOptimizationDisabled) {
                ngGroup.markDirty();
                this.removedChildrenOptimizationDisabled = false;
            }
            else if (this.removed != null && !this.removed.isEmpty()) {
                for (int j = 0; j < this.removed.size(); ++j) {
                    ngGroup.addToRemoved(this.removed.get(j).getPeer());
                }
            }
            if (this.removed != null) {
                this.removed.clear();
            }
            this.pgChildrenSize = this.children.size();
            this.startIdx = this.pgChildrenSize;
        }
        if (this.isDirty(DirtyBits.PARENT_CHILDREN_VIEW_ORDER)) {
            this.computeViewOrderChidrenAndUpdatePeer();
        }
        if (Utils.assertionEnabled()) {
            this.validatePG();
        }
    }
    
    void validatePG() {
        boolean b = false;
        final List<NGNode> children = this.getPeer().getChildren();
        if (children.size() != this.children.size()) {
            System.err.println(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, children.size(), this.children.size()));
            b = true;
        }
        else {
            for (int i = 0; i < this.children.size(); ++i) {
                final Node node = this.children.get(i);
                if (node.getParent() != this) {
                    System.err.println(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Parent;ILjavafx/scene/Parent;)Ljava/lang/String;, this, i, node.getParent()));
                    b = true;
                }
                if (node.getPeer() != children.get(i)) {
                    System.err.println(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, i, i));
                    b = true;
                }
            }
        }
        if (b) {
            throw new AssertionError((Object)"validation of PGGroup children failed");
        }
    }
    
    void printSeq(final String s, final List<Node> list) {
        String x = s;
        final Iterator<Node> iterator = list.iterator();
        while (iterator.hasNext()) {
            x = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/Node;)Ljava/lang/String;, x, (Node)iterator.next());
        }
        System.out.println(x);
    }
    
    void markViewOrderChildrenDirty() {
        NodeHelper.markDirty(this, DirtyBits.PARENT_CHILDREN_VIEW_ORDER);
    }
    
    private void computeViewOrderChidrenAndUpdatePeer() {
        int n = 0;
        final Iterator<Node> iterator = this.children.iterator();
        while (iterator.hasNext()) {
            final double viewOrder = iterator.next().getViewOrder();
            if (n == 0 && viewOrder != 0.0) {
                n = 1;
            }
        }
        this.viewOrderChildren.clear();
        if (n != 0) {
            this.viewOrderChildren.addAll(this.children);
            Collections.sort(this.viewOrderChildren, (node, node2) -> (node.getViewOrder() < node2.getViewOrder()) ? 1 : ((node.getViewOrder() == node2.getViewOrder()) ? 0 : -1));
        }
        this.getPeer().setViewOrderChildren(this.viewOrderChildren);
    }
    
    private List<Node> getOrderedChildren() {
        if (!this.viewOrderChildren.isEmpty()) {
            return this.viewOrderChildren;
        }
        return this.children;
    }
    
    protected ObservableList<Node> getChildren() {
        return this.children;
    }
    
    public ObservableList<Node> getChildrenUnmodifiable() {
        return this.unmodifiableChildren;
    }
    
    protected <E extends Node> List<E> getManagedChildren() {
        if (this.unmodifiableManagedChildren == null) {
            this.unmodifiableManagedChildren = new ArrayList<Node>();
            for (int i = 0; i < this.children.size(); ++i) {
                final Node node = this.children.get(i);
                if (node.isManaged()) {
                    this.unmodifiableManagedChildren.add(node);
                }
            }
        }
        return (List<E>)this.unmodifiableManagedChildren;
    }
    
    final void managedChildChanged() {
        this.requestLayout();
        this.unmodifiableManagedChildren = null;
    }
    
    final void toFront(final Node node) {
        if (Utils.assertionEnabled() && !this.childSet.contains(node)) {
            throw new AssertionError((Object)"specified node is not in the list of children");
        }
        if (this.children.get(this.children.size() - 1) != node) {
            this.childrenTriggerPermutation = true;
            try {
                this.children.remove(node);
                this.children.add(node);
            }
            finally {
                this.childrenTriggerPermutation = false;
            }
        }
    }
    
    final void toBack(final Node node) {
        if (Utils.assertionEnabled() && !this.childSet.contains(node)) {
            throw new AssertionError((Object)"specified node is not in the list of children");
        }
        if (this.children.get(0) != node) {
            this.childrenTriggerPermutation = true;
            try {
                this.children.remove(node);
                this.children.add(0, node);
            }
            finally {
                this.childrenTriggerPermutation = false;
            }
        }
    }
    
    @Override
    void scenesChanged(final Scene scene, final SubScene subScene, final Scene scene2, final SubScene subScene2) {
        if (scene2 != null && scene == null) {
            StyleManager.getInstance().forget(this);
            if (this.removed != null) {
                this.removed.clear();
            }
        }
        for (int i = 0; i < this.children.size(); ++i) {
            ((Node)this.children.get(i)).setScenes(scene, subScene);
        }
        final boolean b = this.layoutFlag != LayoutFlags.CLEAN;
        this.sceneRoot = ((subScene != null && subScene.getRoot() == this) || (scene != null && scene.getRoot() == this));
        this.layoutRoot = (!this.isManaged() || this.sceneRoot);
        if (b && scene != null && this.layoutRoot && subScene != null) {
            subScene.setDirtyLayout(this);
        }
    }
    
    @Override
    void setDerivedDepthTest(final boolean derivedDepthTest) {
        super.setDerivedDepthTest(derivedDepthTest);
        for (int i = 0; i < this.children.size(); ++i) {
            ((Node)this.children.get(i)).computeDerivedDepthTest();
        }
    }
    
    boolean pickChildrenNode(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        final List<Node> orderedChildren = this.getOrderedChildren();
        for (int i = orderedChildren.size() - 1; i >= 0; --i) {
            orderedChildren.get(i).pickNode(pickRay, pickResultChooser);
            if (pickResultChooser.isClosed()) {
                return false;
            }
        }
        return true;
    }
    
    private void doPickNodeLocal(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        final double intersectsBounds = this.intersectsBounds(pickRay);
        if (!Double.isNaN(intersectsBounds) && this.pickChildrenNode(pickRay, pickResultChooser) && this.isPickOnBounds()) {
            pickResultChooser.offer(this, intersectsBounds, PickResultChooser.computePoint(pickRay, intersectsBounds));
        }
    }
    
    @Override
    boolean isConnected() {
        return super.isConnected() || this.sceneRoot;
    }
    
    @Override
    public Node lookup(final String s) {
        Node node = super.lookup(s);
        if (node == null) {
            for (int i = 0; i < this.children.size(); ++i) {
                node = ((Node)this.children.get(i)).lookup(s);
                if (node != null) {
                    return node;
                }
            }
        }
        return node;
    }
    
    @Override
    List<Node> lookupAll(final Selector selector, final List<Node> list) {
        List<Node> list2 = super.lookupAll(selector, list);
        for (int i = 0; i < this.children.size(); ++i) {
            list2 = ((Node)this.children.get(i)).lookupAll(selector, list2);
        }
        return list2;
    }
    
    private final void setTraversalEngine(final ParentTraversalEngine traversalEngine) {
        this.traversalEngine = traversalEngine;
    }
    
    private final ParentTraversalEngine getTraversalEngine() {
        return this.traversalEngine;
    }
    
    protected final void setNeedsLayout(final boolean b) {
        if (b) {
            this.markDirtyLayout(true, false);
        }
        else if (this.layoutFlag == LayoutFlags.NEEDS_LAYOUT) {
            boolean b2 = false;
            for (int i = 0; i < this.children.size(); ++i) {
                final Node node = this.children.get(i);
                if (node instanceof Parent && ((Parent)node).layoutFlag != LayoutFlags.CLEAN) {
                    b2 = true;
                    break;
                }
            }
            this.setLayoutFlag(b2 ? LayoutFlags.DIRTY_BRANCH : LayoutFlags.CLEAN);
        }
    }
    
    public final boolean isNeedsLayout() {
        return this.layoutFlag == LayoutFlags.NEEDS_LAYOUT;
    }
    
    public final ReadOnlyBooleanProperty needsLayoutProperty() {
        if (this.needsLayout == null) {
            this.needsLayout = new ReadOnlyBooleanWrapper(this, "needsLayout", this.layoutFlag == LayoutFlags.NEEDS_LAYOUT);
        }
        return this.needsLayout;
    }
    
    boolean isPerformingLayout() {
        return this.performingLayout;
    }
    
    void setLayoutFlag(final LayoutFlags layoutFlag) {
        if (this.needsLayout != null) {
            this.needsLayout.set(layoutFlag == LayoutFlags.NEEDS_LAYOUT);
        }
        this.layoutFlag = layoutFlag;
    }
    
    private void markDirtyLayout(final boolean b, final boolean b2) {
        this.setLayoutFlag(LayoutFlags.NEEDS_LAYOUT);
        if (b || this.layoutRoot) {
            if (this.sceneRoot) {
                Toolkit.getToolkit().requestNextPulse();
                if (this.getSubScene() != null) {
                    this.getSubScene().setDirtyLayout(this);
                }
            }
            else {
                this.markDirtyLayoutBranch();
            }
        }
        else {
            this.requestParentLayout(b2);
        }
    }
    
    public void requestLayout() {
        this.clearSizeCache();
        this.markDirtyLayout(false, this.forceParentLayout);
    }
    
    void requestLayout(final boolean forceParentLayout) {
        final boolean forceParentLayout2 = this.forceParentLayout;
        this.forceParentLayout = forceParentLayout;
        this.requestLayout();
        this.forceParentLayout = forceParentLayout2;
    }
    
    protected final void requestParentLayout() {
        this.requestParentLayout(false);
    }
    
    void requestParentLayout(final boolean b) {
        if (!this.layoutRoot) {
            final Parent parent = this.getParent();
            if (parent != null && (!parent.performingLayout || b)) {
                parent.requestLayout();
            }
        }
    }
    
    void clearSizeCache() {
        if (this.sizeCacheClear) {
            return;
        }
        this.sizeCacheClear = true;
        this.prefWidthCache = -1.0;
        this.prefHeightCache = -1.0;
        this.minWidthCache = -1.0;
        this.minHeightCache = -1.0;
    }
    
    @Override
    public double prefWidth(final double n) {
        if (n == -1.0) {
            if (this.prefWidthCache == -1.0) {
                this.prefWidthCache = this.computePrefWidth(-1.0);
                if (Double.isNaN(this.prefWidthCache) || this.prefWidthCache < 0.0) {
                    this.prefWidthCache = 0.0;
                }
                this.sizeCacheClear = false;
            }
            return this.prefWidthCache;
        }
        final double computePrefWidth = this.computePrefWidth(n);
        return (Double.isNaN(computePrefWidth) || computePrefWidth < 0.0) ? 0.0 : computePrefWidth;
    }
    
    @Override
    public double prefHeight(final double n) {
        if (n == -1.0) {
            if (this.prefHeightCache == -1.0) {
                this.prefHeightCache = this.computePrefHeight(-1.0);
                if (Double.isNaN(this.prefHeightCache) || this.prefHeightCache < 0.0) {
                    this.prefHeightCache = 0.0;
                }
                this.sizeCacheClear = false;
            }
            return this.prefHeightCache;
        }
        final double computePrefHeight = this.computePrefHeight(n);
        return (Double.isNaN(computePrefHeight) || computePrefHeight < 0.0) ? 0.0 : computePrefHeight;
    }
    
    @Override
    public double minWidth(final double n) {
        if (n == -1.0) {
            if (this.minWidthCache == -1.0) {
                this.minWidthCache = this.computeMinWidth(-1.0);
                if (Double.isNaN(this.minWidthCache) || this.minWidthCache < 0.0) {
                    this.minWidthCache = 0.0;
                }
                this.sizeCacheClear = false;
            }
            return this.minWidthCache;
        }
        final double computeMinWidth = this.computeMinWidth(n);
        return (Double.isNaN(computeMinWidth) || computeMinWidth < 0.0) ? 0.0 : computeMinWidth;
    }
    
    @Override
    public double minHeight(final double n) {
        if (n == -1.0) {
            if (this.minHeightCache == -1.0) {
                this.minHeightCache = this.computeMinHeight(-1.0);
                if (Double.isNaN(this.minHeightCache) || this.minHeightCache < 0.0) {
                    this.minHeightCache = 0.0;
                }
                this.sizeCacheClear = false;
            }
            return this.minHeightCache;
        }
        final double computeMinHeight = this.computeMinHeight(n);
        return (Double.isNaN(computeMinHeight) || computeMinHeight < 0.0) ? 0.0 : computeMinHeight;
    }
    
    protected double computePrefWidth(final double n) {
        double min = 0.0;
        double max = 0.0;
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            if (node.isManaged()) {
                final double b = node.getLayoutBounds().getMinX() + node.getLayoutX();
                min = Math.min(min, b);
                max = Math.max(max, b + this.boundedSize(node.prefWidth(-1.0), node.minWidth(-1.0), node.maxWidth(-1.0)));
            }
        }
        return max - min;
    }
    
    protected double computePrefHeight(final double n) {
        double min = 0.0;
        double max = 0.0;
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            if (node.isManaged()) {
                final double b = node.getLayoutBounds().getMinY() + node.getLayoutY();
                min = Math.min(min, b);
                max = Math.max(max, b + this.boundedSize(node.prefHeight(-1.0), node.minHeight(-1.0), node.maxHeight(-1.0)));
            }
        }
        return max - min;
    }
    
    protected double computeMinWidth(final double n) {
        return this.prefWidth(n);
    }
    
    protected double computeMinHeight(final double n) {
        return this.prefHeight(n);
    }
    
    @Override
    public double getBaselineOffset() {
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            if (node.isManaged()) {
                final double baselineOffset = node.getBaselineOffset();
                if (baselineOffset != Double.NEGATIVE_INFINITY) {
                    return node.getLayoutBounds().getMinY() + node.getLayoutY() + baselineOffset;
                }
            }
        }
        return super.getBaselineOffset();
    }
    
    boolean isCurrentLayoutChild(final Node node) {
        return node == this.currentLayoutChild;
    }
    
    public final void layout() {
        final LayoutFlags layoutFlag = this.layoutFlag;
        this.setLayoutFlag(LayoutFlags.CLEAN);
        switch (layoutFlag) {
            case NEEDS_LAYOUT: {
                if (this.performingLayout) {
                    break;
                }
                this.performingLayout = true;
                this.layoutChildren();
            }
            case DIRTY_BRANCH: {
                for (int i = 0; i < this.children.size(); ++i) {
                    final Node currentLayoutChild = this.children.get(i);
                    this.currentLayoutChild = currentLayoutChild;
                    if (currentLayoutChild instanceof Parent) {
                        ((Parent)currentLayoutChild).layout();
                    }
                    else if (currentLayoutChild instanceof SubScene) {
                        ((SubScene)currentLayoutChild).layoutPass();
                    }
                }
                this.currentLayoutChild = null;
                this.performingLayout = false;
                break;
            }
        }
    }
    
    protected void layoutChildren() {
        for (int i = 0; i < this.children.size(); ++i) {
            final Node currentLayoutChild = this.children.get(i);
            this.currentLayoutChild = currentLayoutChild;
            if (currentLayoutChild.isResizable() && currentLayoutChild.isManaged()) {
                currentLayoutChild.autosize();
            }
        }
        this.currentLayoutChild = null;
    }
    
    @Override
    final void notifyManagedChanged() {
        this.layoutRoot = (!this.isManaged() || this.sceneRoot);
    }
    
    final boolean isSceneRoot() {
        return this.sceneRoot;
    }
    
    public final ObservableList<String> getStylesheets() {
        return this.stylesheets;
    }
    
    private List<String> doGetAllParentStylesheets() {
        List<String> allParentStylesheets = null;
        final Parent parent = this.getParent();
        if (parent != null) {
            allParentStylesheets = ParentHelper.getAllParentStylesheets(parent);
        }
        if (this.stylesheets != null && !this.stylesheets.isEmpty()) {
            if (allParentStylesheets == null) {
                allParentStylesheets = new ArrayList<String>(this.stylesheets.size());
            }
            for (int i = 0; i < this.stylesheets.size(); ++i) {
                allParentStylesheets.add((String)this.stylesheets.get(i));
            }
        }
        return allParentStylesheets;
    }
    
    private void doProcessCSS() {
        if (this.cssFlag == CssFlags.CLEAN) {
            return;
        }
        if (this.cssFlag == CssFlags.DIRTY_BRANCH) {
            super.processCSS();
            return;
        }
        ParentHelper.superProcessCSS(this);
        if (this.children.isEmpty()) {
            return;
        }
        final Node[] array = this.children.toArray(new Node[this.children.size()]);
        for (int i = 0; i < array.length; ++i) {
            final Node node = array[i];
            final Parent parent = node.getParent();
            if (parent != null) {
                if (parent == this) {
                    if (CssFlags.UPDATE.compareTo(node.cssFlag) > 0) {
                        node.cssFlag = CssFlags.UPDATE;
                    }
                    NodeHelper.processCSS(node);
                }
            }
        }
    }
    
    protected Parent() {
        this.removedChildrenOptimizationDisabled = false;
        this.childSet = new HashSet<Node>();
        this.startIdx = 0;
        this.pgChildrenSize = 0;
        this.viewOrderChildren = new ArrayList<Node>(1);
        this.childrenTriggerPermutation = false;
        this.children = new VetoableListDecorator<Node>((ObservableList)new TrackableObservableList<Node>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Node> change) {
                Parent.this.unmodifiableManagedChildren = null;
                boolean b = false;
                boolean b2 = false;
                Label_0638: {
                    if (Parent.this.childSetModified) {
                        while (change.next()) {
                            final int from = change.getFrom();
                            final int to = change.getTo();
                            for (int i = from; i < to; ++i) {
                                final Node node = (Node)Parent.this.children.get(i);
                                if (node.getParent() != null && node.getParent() != Parent.this) {
                                    if (Parent.warnOnAutoMove) {
                                        System.err.println("WARNING added to a new parent without first removing it from its current");
                                        System.err.println("    parent. It will be automatically removed from its current parent.");
                                        System.err.println(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Node;Ljavafx/scene/Parent;Ljavafx/scene/Parent$2;)Ljava/lang/String;, node, node.getParent(), this));
                                    }
                                    node.getParent().children.remove(node);
                                    if (Parent.warnOnAutoMove) {
                                        Thread.dumpStack();
                                    }
                                }
                            }
                            final List<Node> removed = change.getRemoved();
                            final int size = removed.size();
                            for (int j = 0; j < size; ++j) {
                                if (removed.get(j).isManaged()) {
                                    b = true;
                                }
                            }
                            if ((size > 0 || to - from > 0) && !Parent.this.viewOrderChildren.isEmpty()) {
                                b2 = true;
                            }
                            for (int k = from; k < to; ++k) {
                                final Node node2 = (Node)Parent.this.children.get(k);
                                if (node2.getViewOrder() != 0.0) {
                                    b2 = true;
                                }
                                if (node2.isManaged() || (node2 instanceof Parent && ((Parent)node2).layoutFlag != LayoutFlags.CLEAN)) {
                                    b = true;
                                }
                                node2.setParent(Parent.this);
                                node2.setScenes(Parent.this.getScene(), Parent.this.getSubScene());
                                if (node2.isVisible()) {
                                    Parent.this.geomChanged = true;
                                    Parent.this.childIncluded(node2);
                                }
                            }
                        }
                        if (Parent.this.dirtyChildren == null && Parent.this.children.size() > 10) {
                            Parent.this.dirtyChildren = (ArrayList<Node>)new ArrayList(20);
                            if (Parent.this.dirtyChildrenCount > 0) {
                                for (int size2 = Parent.this.children.size(), l = 0; l < size2; ++l) {
                                    final Node e = (Node)Parent.this.children.get(l);
                                    if (e.isVisible() && e.boundsChanged) {
                                        Parent.this.dirtyChildren.add(e);
                                    }
                                }
                            }
                        }
                    }
                    else {
                        while (change.next()) {
                            final List<Node> removed2 = change.getRemoved();
                            for (int n = 0; n < removed2.size(); ++n) {
                                if (removed2.get(n).isManaged()) {
                                    b = true;
                                    break Label_0638;
                                }
                            }
                            for (int from2 = change.getFrom(); from2 < change.getTo(); ++from2) {
                                if (((Node)Parent.this.children.get(from2)).isManaged()) {
                                    b = true;
                                    break Label_0638;
                                }
                            }
                        }
                    }
                }
                if (b) {
                    Parent.this.requestLayout();
                }
                if (Parent.this.geomChanged) {
                    NodeHelper.geomChanged(Parent.this);
                }
                change.reset();
                change.next();
                if (Parent.this.startIdx > change.getFrom()) {
                    Parent.this.startIdx = change.getFrom();
                }
                NodeHelper.markDirty(Parent.this, DirtyBits.PARENT_CHILDREN);
                NodeHelper.markDirty(Parent.this, DirtyBits.NODE_FORCE_SYNC);
                if (b2) {
                    NodeHelper.markDirty(Parent.this, DirtyBits.PARENT_CHILDREN_VIEW_ORDER);
                }
            }
        }) {
            @Override
            protected void onProposedChange(final List<Node> list, final int[] array) {
                final Scene scene = Parent.this.getScene();
                if (scene != null) {
                    final Window window = scene.getWindow();
                    if (window != null && WindowHelper.getPeer(window) != null) {
                        Toolkit.getToolkit().checkFxUserThread();
                    }
                }
                Parent.this.geomChanged = false;
                final long n = Parent.this.children.size() + list.size();
                int n2 = 0;
                for (int i = 0; i < array.length; i += 2) {
                    n2 += array[i + 1] - array[i];
                }
                final long n3 = n - n2;
                if (Parent.this.childrenTriggerPermutation) {
                    Parent.this.childSetModified = false;
                    return;
                }
                Parent.this.childSetModified = true;
                if (n3 == Parent.this.childSet.size()) {
                    Parent.this.childSetModified = false;
                    for (int j = list.size() - 1; j >= 0; --j) {
                        if (!Parent.this.childSet.contains(list.get(j))) {
                            Parent.this.childSetModified = true;
                            break;
                        }
                    }
                }
                for (int k = 0; k < array.length; k += 2) {
                    for (int l = array[k]; l < array[k + 1]; ++l) {
                        Parent.this.childSet.remove(Parent.this.children.get(l));
                    }
                }
                try {
                    if (Parent.this.childSetModified) {
                        for (int n4 = list.size() - 1; n4 >= 0; --n4) {
                            final Node node = list.get(n4);
                            if (node == null) {
                                throw new NullPointerException(this.constructExceptionMessage("child node is null", null));
                            }
                            if (node.getClipParent() != null) {
                                throw new IllegalArgumentException(this.constructExceptionMessage("node already used as a clip", node));
                            }
                            if (Parent.this.wouldCreateCycle(Parent.this, node)) {
                                throw new IllegalArgumentException(this.constructExceptionMessage("cycle detected", node));
                            }
                        }
                    }
                    Parent.this.childSet.addAll(list);
                    if (Parent.this.childSet.size() != n3) {
                        throw new IllegalArgumentException(this.constructExceptionMessage("duplicate children added", null));
                    }
                }
                catch (RuntimeException ex) {
                    Parent.this.childSet.clear();
                    Parent.this.childSet.addAll(Parent.this.children);
                    throw ex;
                }
                if (!Parent.this.childSetModified) {
                    return;
                }
                if (Parent.this.removed == null) {
                    Parent.this.removed = (List<Node>)new ArrayList();
                }
                if (Parent.this.removed.size() + n2 > 20 || !Parent.this.isTreeVisible()) {
                    Parent.this.removedChildrenOptimizationDisabled = true;
                }
                for (int n5 = 0; n5 < array.length; n5 += 2) {
                    for (int n6 = array[n5]; n6 < array[n5 + 1]; ++n6) {
                        final Node o = (Node)Parent.this.children.get(n6);
                        final Scene scene2 = o.getScene();
                        if (scene2 != null) {
                            scene2.generateMouseExited(o);
                        }
                        if (Parent.this.dirtyChildren != null) {
                            Parent.this.dirtyChildren.remove(o);
                        }
                        if (o.isVisible()) {
                            Parent.this.geomChanged = true;
                            Parent.this.childExcluded(o);
                        }
                        if (o.getParent() == Parent.this) {
                            o.setParent(null);
                            o.setScenes(null, null);
                        }
                        if (scene != null && !Parent.this.removedChildrenOptimizationDisabled) {
                            Parent.this.removed.add(o);
                        }
                    }
                }
            }
            
            private String constructExceptionMessage(final String str, final Node obj) {
                final StringBuilder sb = new StringBuilder("Children: ");
                sb.append(str);
                sb.append(": parent = ").append(Parent.this);
                if (obj != null) {
                    sb.append(", node = ").append(obj);
                }
                return sb.toString();
            }
        };
        this.unmodifiableChildren = FXCollections.unmodifiableObservableList(this.children);
        this.unmodifiableManagedChildren = null;
        this.layoutFlag = LayoutFlags.CLEAN;
        this.performingLayout = false;
        this.sizeCacheClear = true;
        this.prefWidthCache = -1.0;
        this.prefHeightCache = -1.0;
        this.minWidthCache = -1.0;
        this.minHeightCache = -1.0;
        this.forceParentLayout = false;
        this.currentLayoutChild = null;
        this.sceneRoot = false;
        this.layoutRoot = false;
        this.stylesheets = new TrackableObservableList<String>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<String> change) {
                if (Parent.this.getScene() != null) {
                    StyleManager.getInstance().stylesheetsChanged(Parent.this, change);
                    change.reset();
                    while (change.next() && !change.wasRemoved()) {}
                    Parent.this.reapplyCSS();
                }
            }
        };
        ParentHelper.initHelper(this);
        this.tmp = new RectBounds();
        this.cachedBounds = new RectBounds();
        this.layoutFlag = LayoutFlags.NEEDS_LAYOUT;
        this.setAccessibleRole(AccessibleRole.PARENT);
    }
    
    private NGNode doCreatePeer() {
        return new NGGroup();
    }
    
    @Override
    void nodeResolvedOrientationChanged() {
        for (int i = 0; i < this.children.size(); ++i) {
            ((Node)this.children.get(i)).parentResolvedOrientationInvalidated();
        }
    }
    
    private BaseBounds doComputeGeomBounds(BaseBounds baseBounds, final BaseTransform baseTransform) {
        if (this.children.isEmpty()) {
            return baseBounds.makeEmpty();
        }
        if (baseTransform.isTranslateOrIdentity()) {
            if (this.cachedBoundsInvalid) {
                this.recomputeBounds();
                if (this.dirtyChildren != null) {
                    this.dirtyChildren.clear();
                }
                this.cachedBoundsInvalid = false;
                this.dirtyChildrenCount = 0;
            }
            if (!baseTransform.isIdentity()) {
                baseBounds = baseBounds.deriveWithNewBounds((float)(this.cachedBounds.getMinX() + baseTransform.getMxt()), (float)(this.cachedBounds.getMinY() + baseTransform.getMyt()), (float)(this.cachedBounds.getMinZ() + baseTransform.getMzt()), (float)(this.cachedBounds.getMaxX() + baseTransform.getMxt()), (float)(this.cachedBounds.getMaxY() + baseTransform.getMyt()), (float)(this.cachedBounds.getMaxZ() + baseTransform.getMzt()));
            }
            else {
                baseBounds = baseBounds.deriveWithNewBounds(this.cachedBounds);
            }
            return baseBounds;
        }
        double min = Double.MAX_VALUE;
        double min2 = Double.MAX_VALUE;
        double min3 = Double.MAX_VALUE;
        double max = Double.MIN_VALUE;
        double max2 = Double.MIN_VALUE;
        double max3 = Double.MIN_VALUE;
        int n = 1;
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            if (node.isVisible()) {
                baseBounds = this.getChildTransformedBounds(node, baseTransform, baseBounds);
                if (!baseBounds.isEmpty()) {
                    if (n != 0) {
                        min = baseBounds.getMinX();
                        min2 = baseBounds.getMinY();
                        min3 = baseBounds.getMinZ();
                        max = baseBounds.getMaxX();
                        max2 = baseBounds.getMaxY();
                        max3 = baseBounds.getMaxZ();
                        n = 0;
                    }
                    else {
                        min = Math.min(baseBounds.getMinX(), min);
                        min2 = Math.min(baseBounds.getMinY(), min2);
                        min3 = Math.min(baseBounds.getMinZ(), min3);
                        max = Math.max(baseBounds.getMaxX(), max);
                        max2 = Math.max(baseBounds.getMaxY(), max2);
                        max3 = Math.max(baseBounds.getMaxZ(), max3);
                    }
                }
            }
        }
        if (n != 0) {
            baseBounds.makeEmpty();
        }
        else {
            baseBounds = baseBounds.deriveWithNewBounds((float)min, (float)min2, (float)min3, (float)max, (float)max2, (float)max3);
        }
        return baseBounds;
    }
    
    private void setChildDirty(final Node node, final boolean boundsChanged) {
        if (node.boundsChanged == boundsChanged) {
            return;
        }
        node.boundsChanged = boundsChanged;
        if (boundsChanged) {
            if (this.dirtyChildren != null) {
                this.dirtyChildren.add(node);
            }
            ++this.dirtyChildrenCount;
        }
        else {
            if (this.dirtyChildren != null) {
                this.dirtyChildren.remove(node);
            }
            --this.dirtyChildrenCount;
        }
    }
    
    private void childIncluded(final Node node) {
        this.setChildDirty(node, this.cachedBoundsInvalid = true);
    }
    
    private void childExcluded(final Node node) {
        if (node == this.left) {
            this.left = null;
            this.cachedBoundsInvalid = true;
        }
        if (node == this.top) {
            this.top = null;
            this.cachedBoundsInvalid = true;
        }
        if (node == this.near) {
            this.near = null;
            this.cachedBoundsInvalid = true;
        }
        if (node == this.right) {
            this.right = null;
            this.cachedBoundsInvalid = true;
        }
        if (node == this.bottom) {
            this.bottom = null;
            this.cachedBoundsInvalid = true;
        }
        if (node == this.far) {
            this.far = null;
            this.cachedBoundsInvalid = true;
        }
        this.setChildDirty(node, false);
    }
    
    private void recomputeBounds() {
        if (this.children.isEmpty()) {
            this.cachedBounds.makeEmpty();
            return;
        }
        if (this.children.size() == 1) {
            final Node node = this.children.get(0);
            node.boundsChanged = false;
            if (node.isVisible()) {
                this.cachedBounds = this.getChildTransformedBounds(node, BaseTransform.IDENTITY_TRANSFORM, this.cachedBounds);
                final Node node2 = node;
                this.far = node2;
                this.near = node2;
                this.right = node2;
                this.bottom = node2;
                this.left = node2;
                this.top = node2;
            }
            else {
                this.cachedBounds.makeEmpty();
            }
            return;
        }
        if (this.dirtyChildrenCount == 0 || !this.updateCachedBounds((List<Node>)((this.dirtyChildren != null) ? this.dirtyChildren : this.children), this.dirtyChildrenCount)) {
            this.createCachedBounds(this.children);
        }
    }
    
    private boolean updateCachedBounds(final List<Node> list, int i) {
        if (this.cachedBounds.isEmpty()) {
            this.createCachedBounds(list);
            return true;
        }
        int n = 0;
        if (this.left == null || this.left.boundsChanged) {
            n |= 0x1;
        }
        if (this.top == null || this.top.boundsChanged) {
            n |= 0x2;
        }
        if (this.near == null || this.near.boundsChanged) {
            n |= 0x4;
        }
        if (this.right == null || this.right.boundsChanged) {
            n |= 0x8;
        }
        if (this.bottom == null || this.bottom.boundsChanged) {
            n |= 0x10;
        }
        if (this.far == null || this.far.boundsChanged) {
            n |= 0x20;
        }
        float minX = this.cachedBounds.getMinX();
        float minY = this.cachedBounds.getMinY();
        float minZ = this.cachedBounds.getMinZ();
        float maxX = this.cachedBounds.getMaxX();
        float maxY = this.cachedBounds.getMaxY();
        float maxZ = this.cachedBounds.getMaxZ();
        int n2 = list.size() - 1;
        while (i > 0) {
            final Node node = list.get(n2);
            if (node.boundsChanged) {
                node.boundsChanged = false;
                --i;
                this.tmp = this.getChildTransformedBounds(node, BaseTransform.IDENTITY_TRANSFORM, this.tmp);
                if (!this.tmp.isEmpty()) {
                    final float minX2 = this.tmp.getMinX();
                    final float minY2 = this.tmp.getMinY();
                    final float minZ2 = this.tmp.getMinZ();
                    final float maxX2 = this.tmp.getMaxX();
                    final float maxY2 = this.tmp.getMaxY();
                    final float maxZ2 = this.tmp.getMaxZ();
                    if (minX2 <= minX) {
                        minX = minX2;
                        this.left = node;
                        n &= 0xFFFFFFFE;
                    }
                    if (minY2 <= minY) {
                        minY = minY2;
                        this.top = node;
                        n &= 0xFFFFFFFD;
                    }
                    if (minZ2 <= minZ) {
                        minZ = minZ2;
                        this.near = node;
                        n &= 0xFFFFFFFB;
                    }
                    if (maxX2 >= maxX) {
                        maxX = maxX2;
                        this.right = node;
                        n &= 0xFFFFFFF7;
                    }
                    if (maxY2 >= maxY) {
                        maxY = maxY2;
                        this.bottom = node;
                        n &= 0xFFFFFFEF;
                    }
                    if (maxZ2 >= maxZ) {
                        maxZ = maxZ2;
                        this.far = node;
                        n &= 0xFFFFFFDF;
                    }
                }
            }
            --n2;
        }
        if (n != 0) {
            return false;
        }
        this.cachedBounds = this.cachedBounds.deriveWithNewBounds(minX, minY, minZ, maxX, maxY, maxZ);
        return true;
    }
    
    private void createCachedBounds(final List<Node> list) {
        int size;
        int i;
        for (size = list.size(), i = 0; i < size; ++i) {
            final Node node = list.get(i);
            node.boundsChanged = false;
            if (node.isVisible()) {
                this.tmp = node.getTransformedBounds(this.tmp, BaseTransform.IDENTITY_TRANSFORM);
                if (!this.tmp.isEmpty()) {
                    final Node node2 = node;
                    this.far = node2;
                    this.bottom = node2;
                    this.right = node2;
                    this.near = node2;
                    this.top = node2;
                    this.left = node2;
                    break;
                }
            }
        }
        if (i == size) {
            final Node node3 = null;
            this.far = node3;
            this.bottom = node3;
            this.right = node3;
            this.near = node3;
            this.top = node3;
            this.left = node3;
            this.cachedBounds.makeEmpty();
            return;
        }
        float minX = this.tmp.getMinX();
        float minY = this.tmp.getMinY();
        float minZ = this.tmp.getMinZ();
        float maxX = this.tmp.getMaxX();
        float maxY = this.tmp.getMaxY();
        float maxZ = this.tmp.getMaxZ();
        ++i;
        while (i < size) {
            final Node node4 = list.get(i);
            node4.boundsChanged = false;
            if (node4.isVisible()) {
                this.tmp = node4.getTransformedBounds(this.tmp, BaseTransform.IDENTITY_TRANSFORM);
                if (!this.tmp.isEmpty()) {
                    final float minX2 = this.tmp.getMinX();
                    final float minY2 = this.tmp.getMinY();
                    final float minZ2 = this.tmp.getMinZ();
                    final float maxX2 = this.tmp.getMaxX();
                    final float maxY2 = this.tmp.getMaxY();
                    final float maxZ2 = this.tmp.getMaxZ();
                    if (minX2 < minX) {
                        minX = minX2;
                        this.left = node4;
                    }
                    if (minY2 < minY) {
                        minY = minY2;
                        this.top = node4;
                    }
                    if (minZ2 < minZ) {
                        minZ = minZ2;
                        this.near = node4;
                    }
                    if (maxX2 > maxX) {
                        maxX = maxX2;
                        this.right = node4;
                    }
                    if (maxY2 > maxY) {
                        maxY = maxY2;
                        this.bottom = node4;
                    }
                    if (maxZ2 > maxZ) {
                        maxZ = maxZ2;
                        this.far = node4;
                    }
                }
            }
            ++i;
        }
        this.cachedBounds = this.cachedBounds.deriveWithNewBounds(minX, minY, minZ, maxX, maxY, maxZ);
    }
    
    protected void updateBounds() {
        for (int i = 0; i < this.children.size(); ++i) {
            ((Node)this.children.get(i)).updateBounds();
        }
        super.updateBounds();
    }
    
    private BaseBounds getChildTransformedBounds(final Node currentlyProcessedChild, final BaseTransform baseTransform, BaseBounds transformedBounds) {
        this.currentlyProcessedChild = currentlyProcessedChild;
        transformedBounds = currentlyProcessedChild.getTransformedBounds(transformedBounds, baseTransform);
        this.currentlyProcessedChild = null;
        return transformedBounds;
    }
    
    void childBoundsChanged(final Node node) {
        if (node == this.currentlyProcessedChild) {
            return;
        }
        this.setChildDirty(node, this.cachedBoundsInvalid = true);
        NodeHelper.geomChanged(this);
    }
    
    void childVisibilityChanged(final Node node) {
        if (node.isVisible()) {
            this.childIncluded(node);
        }
        else {
            this.childExcluded(node);
        }
        NodeHelper.geomChanged(this);
    }
    
    private boolean doComputeContains(final double n, final double n2) {
        final Point2D point = TempState.getInstance().point;
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            point.x = (float)n;
            point.y = (float)n2;
            try {
                node.parentToLocal(point);
            }
            catch (NoninvertibleTransformException ex) {
                continue;
            }
            if (node.contains(point.x, point.y)) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case CHILDREN: {
                return this.getChildrenUnmodifiable();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    void releaseAccessible() {
        for (int i = 0; i < this.children.size(); ++i) {
            ((Node)this.children.get(i)).releaseAccessible();
        }
        super.releaseAccessible();
    }
    
    List<Node> test_getRemoved() {
        return this.removed;
    }
    
    List<Node> test_getViewOrderChildren() {
        return this.viewOrderChildren;
    }
    
    static {
        warnOnAutoMove = PropertyHelper.getBooleanProperty("javafx.sg.warn");
        ParentHelper.setParentAccessor(new ParentHelper.ParentAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((Parent)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((Parent)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Parent)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public boolean doComputeContains(final Node node, final double n, final double n2) {
                return ((Parent)node).doComputeContains(n, n2);
            }
            
            @Override
            public void doProcessCSS(final Node node) {
                ((Parent)node).doProcessCSS();
            }
            
            @Override
            public void doPickNodeLocal(final Node node, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                ((Parent)node).doPickNodeLocal(pickRay, pickResultChooser);
            }
            
            @Override
            public boolean pickChildrenNode(final Parent parent, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                return parent.pickChildrenNode(pickRay, pickResultChooser);
            }
            
            @Override
            public void setTraversalEngine(final Parent parent, final ParentTraversalEngine parentTraversalEngine) {
                parent.setTraversalEngine(parentTraversalEngine);
            }
            
            @Override
            public ParentTraversalEngine getTraversalEngine(final Parent parent) {
                return parent.getTraversalEngine();
            }
            
            @Override
            public List<String> doGetAllParentStylesheets(final Parent parent) {
                return parent.doGetAllParentStylesheets();
            }
        });
    }
}
