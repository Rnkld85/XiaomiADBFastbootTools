// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import javafx.beans.property.ReadOnlyObjectPropertyBase;
import java.util.LinkedList;
import com.sun.javafx.scene.input.ExtendedInputMethodRequests;
import javafx.beans.Observable;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.InvalidationListener;
import com.sun.javafx.scene.input.PickResultChooser;
import com.sun.javafx.event.EventQueue;
import com.sun.javafx.cursor.CursorFrame;
import java.util.EnumMap;
import javafx.event.ActionEvent;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.Timeline;
import javafx.scene.input.KeyCode;
import java.util.Collection;
import com.sun.javafx.tk.TKDragSourceListener;
import javafx.scene.input.Clipboard;
import com.sun.javafx.scene.input.ClipboardHelper;
import com.sun.javafx.tk.TKDragGestureListener;
import com.sun.javafx.scene.input.DragboardHelper;
import com.sun.javafx.tk.TKClipboard;
import javafx.scene.input.InputMethodTextRun;
import javafx.scene.input.MouseButton;
import com.sun.prism.impl.PrismSettings;
import com.sun.javafx.logging.PulseLogger;
import com.sun.javafx.scene.SceneHelper;
import com.sun.glass.ui.Application;
import javafx.stage.PopupWindow;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.collections.FXCollections;
import java.util.Set;
import com.sun.javafx.scene.input.InputEventUtils;
import java.util.EnumSet;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.event.EventDispatchChain;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.Mnemonic;
import com.sun.javafx.scene.LayoutFlags;
import com.sun.javafx.scene.traversal.Direction;
import com.sun.javafx.geom.Vec3d;
import javafx.geometry.Point3D;
import javafx.stage.StageStyle;
import javafx.stage.Stage;
import com.sun.javafx.geom.PickRay;
import javafx.event.EventType;
import com.sun.javafx.scene.input.TouchPointHelper;
import java.util.Arrays;
import java.lang.ref.WeakReference;
import javafx.scene.input.GestureEvent;
import javafx.scene.input.PickResult;
import javafx.geometry.Bounds;
import javafx.event.Event;
import javafx.geometry.Orientation;
import javafx.beans.property.SimpleObjectProperty;
import javafx.util.Callback;
import java.util.Iterator;
import com.sun.javafx.sg.prism.NGLightBase;
import javafx.scene.image.WritableImage;
import com.sun.javafx.geom.transform.BaseTransform;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.ReadOnlyDoubleProperty;
import com.sun.javafx.tk.TKStage;
import javafx.scene.input.InputMethodRequests;
import com.sun.javafx.tk.TKDropTargetListener;
import com.sun.javafx.sg.prism.NGCamera;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.tk.TKScenePaintListener;
import com.sun.javafx.tk.TKSceneListener;
import com.sun.javafx.application.PlatformImpl;
import com.sun.javafx.stage.WindowHelper;
import javafx.beans.property.ReadOnlyObjectProperty;
import java.util.concurrent.CopyOnWriteArrayList;
import com.sun.javafx.scene.DirtyBits;
import com.sun.javafx.scene.CssFlags;
import com.sun.javafx.util.Utils;
import javafx.application.Platform;
import javafx.application.ConditionalFeature;
import java.util.ArrayList;
import com.sun.javafx.util.Logging;
import com.sun.javafx.scene.traversal.SceneTraversalEngine;
import java.util.HashMap;
import com.sun.javafx.css.StyleManager;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import java.security.AccessController;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.tk.Toolkit;
import javafx.scene.paint.Color;
import javafx.beans.NamedArg;
import com.sun.glass.ui.Accessible;
import javafx.geometry.NodeOrientation;
import javafx.collections.ObservableMap;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.SwipeEvent;
import javafx.scene.input.ZoomEvent;
import javafx.scene.input.RotateEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ContextMenuEvent;
import javafx.event.EventHandler;
import com.sun.javafx.scene.SceneEventDispatcher;
import javafx.event.EventDispatcher;
import com.sun.javafx.scene.traversal.TopMostTraversalEngine;
import java.util.Map;
import javafx.scene.input.TouchPoint;
import javafx.scene.input.TouchEvent;
import javafx.geometry.Point2D;
import com.sun.javafx.perf.PerformanceTracker;
import javafx.collections.ObservableList;
import com.sun.javafx.tk.TKPulseListener;
import javafx.scene.paint.Paint;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyDoubleWrapper;
import javafx.stage.Window;
import javafx.beans.property.ReadOnlyObjectWrapper;
import java.util.List;
import com.sun.javafx.tk.TKScene;
import java.security.AccessControlContext;
import javafx.beans.DefaultProperty;
import javafx.event.EventTarget;

@DefaultProperty("root")
public class Scene implements EventTarget
{
    private double widthSetByUser;
    private double heightSetByUser;
    private boolean sizeInitialized;
    private final boolean depthBuffer;
    private final SceneAntialiasing antiAliasing;
    private int dirtyBits;
    final AccessControlContext acc;
    private Camera defaultCamera;
    private Node transientFocusContainer;
    private static final int MIN_DIRTY_CAPACITY = 30;
    private static boolean inSynchronizer;
    private static boolean inMousePick;
    private static boolean allowPGAccess;
    private static int pgAccessCount;
    private static final boolean PLATFORM_DRAG_GESTURE_INITIATION = false;
    private Node[] dirtyNodes;
    private int dirtyNodesSize;
    private TKScene peer;
    ScenePulseListener scenePulseListener;
    private List<Runnable> preLayoutPulseListeners;
    private List<Runnable> postLayoutPulseListeners;
    private ReadOnlyObjectWrapper<Window> window;
    DnDGesture dndGesture;
    DragGestureListener dragGestureListener;
    private ReadOnlyDoubleWrapper x;
    private ReadOnlyDoubleWrapper y;
    private ReadOnlyDoubleWrapper width;
    private ReadOnlyDoubleWrapper height;
    private TargetWrapper tmpTargetWrapper;
    private ObjectProperty<Camera> camera;
    private ObjectProperty<Paint> fill;
    private ObjectProperty<Parent> root;
    Parent oldRoot;
    private static TKPulseListener snapshotPulseListener;
    private static List<Runnable> snapshotRunnableListA;
    private static List<Runnable> snapshotRunnableListB;
    private static List<Runnable> snapshotRunnableList;
    private ObjectProperty<Cursor> cursor;
    private final ObservableList<String> stylesheets;
    private ObjectProperty<String> userAgentStylesheet;
    private PerformanceTracker tracker;
    private static final Object trackerMonitor;
    private MouseHandler mouseHandler;
    private ClickGenerator clickGenerator;
    private Point2D cursorScreenPos;
    private Point2D cursorScenePos;
    private final TouchGesture scrollGesture;
    private final TouchGesture zoomGesture;
    private final TouchGesture rotateGesture;
    private final TouchGesture swipeGesture;
    private TouchMap touchMap;
    private TouchEvent nextTouchEvent;
    private TouchPoint[] touchPoints;
    private int touchEventSetId;
    private int touchPointIndex;
    private Map<Integer, EventTarget> touchTargets;
    private KeyHandler keyHandler;
    private boolean focusDirty;
    private TopMostTraversalEngine traversalEngine;
    private Node oldFocusOwner;
    private ReadOnlyObjectWrapper<Node> focusOwner;
    Runnable testPulseListener;
    private List<LightBase> lights;
    private ObjectProperty<EventDispatcher> eventDispatcher;
    private SceneEventDispatcher internalEventDispatcher;
    private ObjectProperty<EventHandler<? super ContextMenuEvent>> onContextMenuRequested;
    private ObjectProperty<EventHandler<? super MouseEvent>> onMouseClicked;
    private ObjectProperty<EventHandler<? super MouseEvent>> onMouseDragged;
    private ObjectProperty<EventHandler<? super MouseEvent>> onMouseEntered;
    private ObjectProperty<EventHandler<? super MouseEvent>> onMouseExited;
    private ObjectProperty<EventHandler<? super MouseEvent>> onMouseMoved;
    private ObjectProperty<EventHandler<? super MouseEvent>> onMousePressed;
    private ObjectProperty<EventHandler<? super MouseEvent>> onMouseReleased;
    private ObjectProperty<EventHandler<? super MouseEvent>> onDragDetected;
    private ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragOver;
    private ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragReleased;
    private ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragEntered;
    private ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragExited;
    private ObjectProperty<EventHandler<? super ScrollEvent>> onScrollStarted;
    private ObjectProperty<EventHandler<? super ScrollEvent>> onScroll;
    private ObjectProperty<EventHandler<? super ScrollEvent>> onScrollFinished;
    private ObjectProperty<EventHandler<? super RotateEvent>> onRotationStarted;
    private ObjectProperty<EventHandler<? super RotateEvent>> onRotate;
    private ObjectProperty<EventHandler<? super RotateEvent>> onRotationFinished;
    private ObjectProperty<EventHandler<? super ZoomEvent>> onZoomStarted;
    private ObjectProperty<EventHandler<? super ZoomEvent>> onZoom;
    private ObjectProperty<EventHandler<? super ZoomEvent>> onZoomFinished;
    private ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeUp;
    private ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeDown;
    private ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeLeft;
    private ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeRight;
    private ObjectProperty<EventHandler<? super TouchEvent>> onTouchPressed;
    private ObjectProperty<EventHandler<? super TouchEvent>> onTouchMoved;
    private ObjectProperty<EventHandler<? super TouchEvent>> onTouchReleased;
    private ObjectProperty<EventHandler<? super TouchEvent>> onTouchStationary;
    private ObjectProperty<EventHandler<? super DragEvent>> onDragEntered;
    private ObjectProperty<EventHandler<? super DragEvent>> onDragExited;
    private ObjectProperty<EventHandler<? super DragEvent>> onDragOver;
    private ObjectProperty<EventHandler<? super DragEvent>> onDragDropped;
    private ObjectProperty<EventHandler<? super DragEvent>> onDragDone;
    private ObjectProperty<EventHandler<? super KeyEvent>> onKeyPressed;
    private ObjectProperty<EventHandler<? super KeyEvent>> onKeyReleased;
    private ObjectProperty<EventHandler<? super KeyEvent>> onKeyTyped;
    private ObjectProperty<EventHandler<? super InputMethodEvent>> onInputMethodTextChanged;
    private static final Object USER_DATA_KEY;
    private ObservableMap<Object, Object> properties;
    private static final NodeOrientation defaultNodeOrientation;
    private ObjectProperty<NodeOrientation> nodeOrientation;
    private EffectiveOrientationProperty effectiveNodeOrientationProperty;
    private NodeOrientation effectiveNodeOrientation;
    private Map<Node, Accessible> accMap;
    private Accessible accessible;
    
    public Scene(@NamedArg("root") final Parent parent) {
        this(parent, -1.0, -1.0, Color.WHITE, false, SceneAntialiasing.DISABLED);
    }
    
    public Scene(@NamedArg("root") final Parent parent, @NamedArg("width") final double n, @NamedArg("height") final double n2) {
        this(parent, n, n2, Color.WHITE, false, SceneAntialiasing.DISABLED);
    }
    
    public Scene(@NamedArg("root") final Parent parent, @NamedArg(value = "fill", defaultValue = "WHITE") final Paint paint) {
        this(parent, -1.0, -1.0, paint, false, SceneAntialiasing.DISABLED);
    }
    
    public Scene(@NamedArg("root") final Parent parent, @NamedArg("width") final double n, @NamedArg("height") final double n2, @NamedArg(value = "fill", defaultValue = "WHITE") final Paint paint) {
        this(parent, n, n2, paint, false, SceneAntialiasing.DISABLED);
    }
    
    public Scene(@NamedArg("root") final Parent parent, @NamedArg(value = "width", defaultValue = "-1") final double n, @NamedArg(value = "height", defaultValue = "-1") final double n2, @NamedArg("depthBuffer") final boolean b) {
        this(parent, n, n2, Color.WHITE, b, SceneAntialiasing.DISABLED);
    }
    
    public Scene(@NamedArg("root") final Parent parent, @NamedArg(value = "width", defaultValue = "-1") final double n, @NamedArg(value = "height", defaultValue = "-1") final double n2, @NamedArg("depthBuffer") final boolean b, @NamedArg(value = "antiAliasing", defaultValue = "DISABLED") final SceneAntialiasing sceneAntialiasing) {
        this(parent, n, n2, Color.WHITE, b, sceneAntialiasing);
        if (sceneAntialiasing != null && sceneAntialiasing != SceneAntialiasing.DISABLED && !Toolkit.getToolkit().isMSAASupported()) {
            PlatformLogger.getLogger(Scene.class.getName()).warning("System can't support antiAliasing");
        }
    }
    
    private Scene(final Parent root, final double n, final double n2, final Paint fill, final boolean depthBuffer, final SceneAntialiasing antiAliasing) {
        this.widthSetByUser = -1.0;
        this.heightSetByUser = -1.0;
        this.sizeInitialized = false;
        this.acc = AccessController.getContext();
        this.scenePulseListener = new ScenePulseListener();
        this.dndGesture = null;
        this.tmpTargetWrapper = new TargetWrapper();
        this.stylesheets = new TrackableObservableList<String>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<String> change) {
                StyleManager.getInstance().stylesheetsChanged(Scene.this, change);
                change.reset();
                while (change.next() && !change.wasRemoved()) {}
                Scene.this.getRoot().reapplyCSS();
            }
        };
        this.userAgentStylesheet = null;
        this.scrollGesture = new TouchGesture();
        this.zoomGesture = new TouchGesture();
        this.rotateGesture = new TouchGesture();
        this.swipeGesture = new TouchGesture();
        this.touchMap = new TouchMap();
        this.nextTouchEvent = null;
        this.touchPoints = null;
        this.touchEventSetId = 0;
        this.touchPointIndex = 0;
        this.touchTargets = new HashMap<Integer, EventTarget>();
        this.keyHandler = null;
        this.focusDirty = true;
        this.traversalEngine = new SceneTraversalEngine(this);
        this.focusOwner = new ReadOnlyObjectWrapper<Node>((Object)this, "focusOwner") {
            @Override
            protected void invalidated() {
                if (Scene.this.oldFocusOwner != null) {
                    ((Node.FocusedProperty)Scene.this.oldFocusOwner.focusedProperty()).store(false);
                }
                final Node node = this.get();
                if (node != null) {
                    ((Node.FocusedProperty)node.focusedProperty()).store(Scene.this.keyHandler.windowFocused);
                    if (node != Scene.this.oldFocusOwner) {
                        node.getScene().enableInputMethodEvents(node.getInputMethodRequests() != null && node.getOnInputMethodTextChanged() != null);
                    }
                }
                final Node access$1700 = Scene.this.oldFocusOwner;
                Scene.this.oldFocusOwner = node;
                if (access$1700 != null) {
                    ((Node.FocusedProperty)access$1700.focusedProperty()).notifyListeners();
                }
                if (node != null) {
                    ((Node.FocusedProperty)node.focusedProperty()).notifyListeners();
                }
                final PlatformLogger focusLogger = Logging.getFocusLogger();
                if (focusLogger.isLoggable(PlatformLogger.Level.FINE)) {
                    if (node == this.get()) {
                        focusLogger.fine(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Node;Ljavafx/scene/Node;)Ljava/lang/String;, access$1700, node));
                    }
                    else {
                        focusLogger.fine(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Node;Ljavafx/scene/Node;)Ljava/lang/String;, access$1700, node));
                    }
                }
                if (Scene.this.accessible != null) {
                    Scene.this.accessible.sendNotification(AccessibleAttribute.FOCUS_NODE);
                }
            }
        };
        this.testPulseListener = null;
        this.lights = new ArrayList<LightBase>();
        this.depthBuffer = depthBuffer;
        this.antiAliasing = antiAliasing;
        if (root == null) {
            throw new NullPointerException("Root cannot be null");
        }
        if ((depthBuffer || (antiAliasing != null && antiAliasing != SceneAntialiasing.DISABLED)) && !Platform.isSupported(ConditionalFeature.SCENE3D)) {
            PlatformLogger.getLogger(Scene.class.getName()).warning("System can't support ConditionalFeature.SCENE3D");
        }
        this.init();
        this.setRoot(root);
        this.init(n, n2);
        this.setFill(fill);
    }
    
    static boolean isPGAccessAllowed() {
        return Scene.inSynchronizer || Scene.inMousePick || Scene.allowPGAccess;
    }
    
    static void setAllowPGAccess(final boolean b) {
        if (Utils.assertionEnabled()) {
            if (b) {
                ++Scene.pgAccessCount;
                Scene.allowPGAccess = true;
            }
            else {
                if (Scene.pgAccessCount <= 0) {
                    throw new AssertionError((Object)"*** pgAccessCount underflow");
                }
                if (--Scene.pgAccessCount == 0) {
                    Scene.allowPGAccess = false;
                }
            }
        }
    }
    
    void addToDirtyList(final Node node) {
        if ((this.dirtyNodes == null || this.dirtyNodesSize == 0) && this.peer != null) {
            Toolkit.getToolkit().requestNextPulse();
        }
        if (this.dirtyNodes != null) {
            if (this.dirtyNodesSize == this.dirtyNodes.length) {
                final Node[] dirtyNodes = new Node[this.dirtyNodesSize + (this.dirtyNodesSize >> 1)];
                System.arraycopy(this.dirtyNodes, 0, dirtyNodes, 0, this.dirtyNodesSize);
                this.dirtyNodes = dirtyNodes;
            }
            this.dirtyNodes[this.dirtyNodesSize++] = node;
        }
    }
    
    private void doCSSPass() {
        final Parent root = this.getRoot();
        if (root.cssFlag != CssFlags.CLEAN) {
            root.clearDirty(com.sun.javafx.scene.DirtyBits.NODE_CSS);
            root.processCSS();
        }
    }
    
    void doLayoutPass() {
        final Parent root = this.getRoot();
        if (root != null) {
            root.layout();
        }
    }
    
    TKScene getPeer() {
        return this.peer;
    }
    
    public final void addPreLayoutPulseListener(final Runnable runnable) {
        Toolkit.getToolkit().checkFxUserThread();
        if (runnable == null) {
            throw new NullPointerException("Scene pulse listener should not be null");
        }
        if (this.preLayoutPulseListeners == null) {
            this.preLayoutPulseListeners = new CopyOnWriteArrayList<Runnable>();
        }
        this.preLayoutPulseListeners.add(runnable);
    }
    
    public final void removePreLayoutPulseListener(final Runnable runnable) {
        Toolkit.getToolkit().checkFxUserThread();
        if (this.preLayoutPulseListeners == null) {
            return;
        }
        this.preLayoutPulseListeners.remove(runnable);
    }
    
    public final void addPostLayoutPulseListener(final Runnable runnable) {
        Toolkit.getToolkit().checkFxUserThread();
        if (runnable == null) {
            throw new NullPointerException("Scene pulse listener should not be null");
        }
        if (this.postLayoutPulseListeners == null) {
            this.postLayoutPulseListeners = new CopyOnWriteArrayList<Runnable>();
        }
        this.postLayoutPulseListeners.add(runnable);
    }
    
    public final void removePostLayoutPulseListener(final Runnable runnable) {
        Toolkit.getToolkit().checkFxUserThread();
        if (this.postLayoutPulseListeners == null) {
            return;
        }
        this.postLayoutPulseListeners.remove(runnable);
    }
    
    public final SceneAntialiasing getAntiAliasing() {
        return this.antiAliasing;
    }
    
    private boolean getAntiAliasingInternal() {
        return this.antiAliasing != null && Toolkit.getToolkit().isMSAASupported() && Platform.isSupported(ConditionalFeature.SCENE3D) && this.antiAliasing != SceneAntialiasing.DISABLED;
    }
    
    void setWindow(final Window window) {
        this.windowPropertyImpl().set(window);
    }
    
    public final Window getWindow() {
        return (this.window == null) ? null : this.window.get();
    }
    
    public final ReadOnlyObjectProperty<Window> windowProperty() {
        return this.windowPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<Window> windowPropertyImpl() {
        if (this.window == null) {
            this.window = new ReadOnlyObjectWrapper<Window>() {
                private Window oldWindow;
                
                @Override
                protected void invalidated() {
                    final Window oldWindow = this.get();
                    Scene.this.getKeyHandler().windowForSceneChanged(this.oldWindow, oldWindow);
                    if (this.oldWindow != null) {
                        Scene.this.disposePeer();
                    }
                    if (oldWindow != null) {
                        Scene.this.initPeer();
                    }
                    Scene.this.parentEffectiveOrientationInvalidated();
                    this.oldWindow = oldWindow;
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "window";
                }
            };
        }
        return this.window;
    }
    
    void initPeer() {
        assert this.peer == null;
        final Window window = this.getWindow();
        assert window != null;
        final TKStage peer = WindowHelper.getPeer(window);
        if (peer == null) {
            return;
        }
        if (!Platform.isSupported(ConditionalFeature.TRANSPARENT_WINDOW)) {
            PlatformImpl.addNoTransparencyStylesheetToScene(this);
        }
        PerformanceTracker.logEvent("Scene.initPeer started");
        setAllowPGAccess(true);
        final Toolkit toolkit = Toolkit.getToolkit();
        this.peer = peer.createTKScene(this.isDepthBufferInternal(), this.getAntiAliasingInternal(), this.acc);
        PerformanceTracker.logEvent("Scene.initPeer TKScene created");
        this.peer.setTKSceneListener(new ScenePeerListener());
        this.peer.setTKScenePaintListener(new ScenePeerPaintListener());
        PerformanceTracker.logEvent("Scene.initPeer TKScene set");
        this.peer.setRoot(this.getRoot().getPeer());
        this.peer.setFillPaint((this.getFill() == null) ? null : toolkit.getPaint(this.getFill()));
        NodeHelper.updatePeer(this.getEffectiveCamera());
        this.peer.setCamera(this.getEffectiveCamera().getPeer());
        this.peer.markDirty();
        PerformanceTracker.logEvent("Scene.initPeer TKScene initialized");
        setAllowPGAccess(false);
        toolkit.addSceneTkPulseListener(this.scenePulseListener);
        toolkit.enableDrop(this.peer, new DropTargetListener());
        toolkit.installInputMethodRequests(this.peer, new InputMethodRequestsDelegate());
        PerformanceTracker.logEvent("Scene.initPeer finished");
    }
    
    public void disposePeer() {
        if (this.peer == null) {
            return;
        }
        PerformanceTracker.logEvent("Scene.disposePeer started");
        Toolkit.getToolkit().removeSceneTkPulseListener(this.scenePulseListener);
        if (this.accessible != null) {
            this.disposeAccessibles();
            final Parent root = this.getRoot();
            if (root != null) {
                root.releaseAccessible();
            }
            this.accessible.dispose();
            this.accessible = null;
        }
        this.peer.dispose();
        this.peer = null;
        PerformanceTracker.logEvent("Scene.disposePeer finished");
    }
    
    private final void setX(final double n) {
        this.xPropertyImpl().set(n);
    }
    
    public final double getX() {
        return (this.x == null) ? 0.0 : this.x.get();
    }
    
    public final ReadOnlyDoubleProperty xProperty() {
        return this.xPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyDoubleWrapper xPropertyImpl() {
        if (this.x == null) {
            this.x = new ReadOnlyDoubleWrapper(this, "x");
        }
        return this.x;
    }
    
    private final void setY(final double n) {
        this.yPropertyImpl().set(n);
    }
    
    public final double getY() {
        return (this.y == null) ? 0.0 : this.y.get();
    }
    
    public final ReadOnlyDoubleProperty yProperty() {
        return this.yPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyDoubleWrapper yPropertyImpl() {
        if (this.y == null) {
            this.y = new ReadOnlyDoubleWrapper(this, "y");
        }
        return this.y;
    }
    
    private final void setWidth(final double n) {
        this.widthPropertyImpl().set(n);
    }
    
    public final double getWidth() {
        return (this.width == null) ? 0.0 : this.width.get();
    }
    
    public final ReadOnlyDoubleProperty widthProperty() {
        return this.widthPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyDoubleWrapper widthPropertyImpl() {
        if (this.width == null) {
            this.width = new ReadOnlyDoubleWrapper() {
                @Override
                protected void invalidated() {
                    final Parent root = Scene.this.getRoot();
                    if (root.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) {
                        NodeHelper.transformsChanged(root);
                    }
                    if (root.isResizable()) {
                        Scene.this.resizeRootOnSceneSizeChange(this.get() - root.getLayoutX() - root.getTranslateX(), root.getLayoutBounds().getHeight());
                    }
                    Scene.this.getEffectiveCamera().setViewWidth(this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "width";
                }
            };
        }
        return this.width;
    }
    
    private final void setHeight(final double n) {
        this.heightPropertyImpl().set(n);
    }
    
    public final double getHeight() {
        return (this.height == null) ? 0.0 : this.height.get();
    }
    
    public final ReadOnlyDoubleProperty heightProperty() {
        return this.heightPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyDoubleWrapper heightPropertyImpl() {
        if (this.height == null) {
            this.height = new ReadOnlyDoubleWrapper() {
                @Override
                protected void invalidated() {
                    final Parent root = Scene.this.getRoot();
                    if (root.isResizable()) {
                        Scene.this.resizeRootOnSceneSizeChange(root.getLayoutBounds().getWidth(), this.get() - root.getLayoutY() - root.getTranslateY());
                    }
                    Scene.this.getEffectiveCamera().setViewHeight(this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "height";
                }
            };
        }
        return this.height;
    }
    
    void resizeRootOnSceneSizeChange(final double n, final double n2) {
        this.getRoot().resize(n, n2);
    }
    
    public final void setCamera(final Camera camera) {
        this.cameraProperty().set(camera);
    }
    
    public final Camera getCamera() {
        return (this.camera == null) ? null : this.camera.get();
    }
    
    public final ObjectProperty<Camera> cameraProperty() {
        if (this.camera == null) {
            this.camera = new ObjectPropertyBase<Camera>() {
                Camera oldCamera = null;
                
                @Override
                protected void invalidated() {
                    final Camera oldCamera = this.get();
                    if (oldCamera != null) {
                        if (oldCamera instanceof PerspectiveCamera && !Platform.isSupported(ConditionalFeature.SCENE3D)) {
                            PlatformLogger.getLogger(Scene.class.getName()).warning("System can't support ConditionalFeature.SCENE3D");
                        }
                        if ((oldCamera.getScene() != null && oldCamera.getScene() != Scene.this) || oldCamera.getSubScene() != null) {
                            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Camera;)Ljava/lang/String;, oldCamera));
                        }
                        oldCamera.setOwnerScene(Scene.this);
                        oldCamera.setViewWidth(Scene.this.getWidth());
                        oldCamera.setViewHeight(Scene.this.getHeight());
                    }
                    if (this.oldCamera != null && this.oldCamera != oldCamera) {
                        this.oldCamera.setOwnerScene(null);
                    }
                    this.oldCamera = oldCamera;
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "camera";
                }
            };
        }
        return this.camera;
    }
    
    Camera getEffectiveCamera() {
        final Camera camera = this.getCamera();
        if (camera == null || (camera instanceof PerspectiveCamera && !Platform.isSupported(ConditionalFeature.SCENE3D))) {
            if (this.defaultCamera == null) {
                (this.defaultCamera = new ParallelCamera()).setOwnerScene(this);
                this.defaultCamera.setViewWidth(this.getWidth());
                this.defaultCamera.setViewHeight(this.getHeight());
            }
            return this.defaultCamera;
        }
        return camera;
    }
    
    void markCameraDirty() {
        this.markDirty(DirtyBits.CAMERA_DIRTY);
        this.setNeedsRepaint();
    }
    
    void markCursorDirty() {
        this.markDirty(DirtyBits.CURSOR_DIRTY);
    }
    
    public final void setFill(final Paint paint) {
        this.fillProperty().set(paint);
    }
    
    public final Paint getFill() {
        return (this.fill == null) ? Color.WHITE : this.fill.get();
    }
    
    public final ObjectProperty<Paint> fillProperty() {
        if (this.fill == null) {
            this.fill = new ObjectPropertyBase<Paint>(Color.WHITE) {
                @Override
                protected void invalidated() {
                    Scene.this.markDirty(DirtyBits.FILL_DIRTY);
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "fill";
                }
            };
        }
        return this.fill;
    }
    
    public final void setRoot(final Parent parent) {
        this.rootProperty().set(parent);
    }
    
    public final Parent getRoot() {
        return (this.root == null) ? null : this.root.get();
    }
    
    public final ObjectProperty<Parent> rootProperty() {
        if (this.root == null) {
            this.root = new ObjectPropertyBase<Parent>() {
                private void forceUnbind() {
                    System.err.println("Unbinding illegal root.");
                    this.unbind();
                }
                
                @Override
                protected void invalidated() {
                    final Parent oldRoot = this.get();
                    if (oldRoot == null) {
                        if (this.isBound()) {
                            this.forceUnbind();
                        }
                        throw new NullPointerException("Scene's root cannot be null");
                    }
                    if (oldRoot.getParent() != null) {
                        if (this.isBound()) {
                            this.forceUnbind();
                        }
                        throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Parent;)Ljava/lang/String;, oldRoot));
                    }
                    if (oldRoot.getClipParent() != null) {
                        if (this.isBound()) {
                            this.forceUnbind();
                        }
                        throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Parent;)Ljava/lang/String;, oldRoot));
                    }
                    if (oldRoot.getScene() != null && oldRoot.getScene().getRoot() == oldRoot && oldRoot.getScene() != Scene.this) {
                        if (this.isBound()) {
                            this.forceUnbind();
                        }
                        throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Parent;)Ljava/lang/String;, oldRoot));
                    }
                    if (Scene.this.oldRoot != null) {
                        Scene.this.oldRoot.setScenes(null, null);
                    }
                    Scene.this.oldRoot = oldRoot;
                    oldRoot.getStyleClass().add(0, "root");
                    oldRoot.setScenes(Scene.this, null);
                    Scene.this.markDirty(DirtyBits.ROOT_DIRTY);
                    oldRoot.resize(Scene.this.getWidth(), Scene.this.getHeight());
                    oldRoot.requestLayout();
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "root";
                }
            };
        }
        return this.root;
    }
    
    void setNeedsRepaint() {
        if (this.peer != null) {
            this.peer.entireSceneNeedsRepaint();
        }
    }
    
    void doCSSLayoutSyncForSnapshot(final Node node) {
        if (!this.sizeInitialized) {
            this.preferredSize();
        }
        else {
            this.doCSSPass();
        }
        this.doLayoutPass();
        this.getRoot().updateBounds();
        if (this.peer != null) {
            this.peer.waitForRenderingToComplete();
            this.peer.waitForSynchronization();
            try {
                this.scenePulseListener.synchronizeSceneNodes();
            }
            finally {
                this.peer.releaseSynchronization(false);
            }
        }
        else {
            this.scenePulseListener.synchronizeSceneNodes();
        }
    }
    
    static WritableImage doSnapshot(final Scene scene, final double a, final double a2, final double n, final double n2, final Node node, final BaseTransform transform, final boolean depthBuffer, final Paint paint, final Camera camera, WritableImage writableImage) {
        final Toolkit toolkit = Toolkit.getToolkit();
        final Toolkit.ImageRenderingContext imageRenderingContext = new Toolkit.ImageRenderingContext();
        final int x = (int)Math.floor(a);
        final int y = (int)Math.floor(a2);
        final int n3 = (int)Math.ceil(a + n);
        final int n4 = (int)Math.ceil(a2 + n2);
        int max = Math.max(n3 - x, 1);
        int max2 = Math.max(n4 - y, 1);
        if (writableImage == null) {
            writableImage = new WritableImage(max, max2);
        }
        else {
            max = (int)writableImage.getWidth();
            max2 = (int)writableImage.getHeight();
        }
        setAllowPGAccess(true);
        imageRenderingContext.x = x;
        imageRenderingContext.y = y;
        imageRenderingContext.width = max;
        imageRenderingContext.height = max2;
        imageRenderingContext.transform = transform;
        imageRenderingContext.depthBuffer = depthBuffer;
        imageRenderingContext.root = node.getPeer();
        imageRenderingContext.platformPaint = ((paint == null) ? null : toolkit.getPaint(paint));
        double viewWidth = 1.0;
        double viewHeight = 1.0;
        if (camera != null) {
            viewWidth = camera.getViewWidth();
            viewHeight = camera.getViewHeight();
            camera.setViewWidth(max);
            camera.setViewHeight(max2);
            NodeHelper.updatePeer(camera);
            imageRenderingContext.camera = camera.getPeer();
        }
        else {
            imageRenderingContext.camera = null;
        }
        imageRenderingContext.lights = null;
        if (scene != null && !scene.lights.isEmpty()) {
            imageRenderingContext.lights = new NGLightBase[scene.lights.size()];
            for (int i = 0; i < scene.lights.size(); ++i) {
                imageRenderingContext.lights[i] = (NGLightBase)scene.lights.get(i).getPeer();
            }
        }
        final Toolkit.WritableImageAccessor writableImageAccessor = Toolkit.getWritableImageAccessor();
        imageRenderingContext.platformImage = writableImageAccessor.getTkImageLoader(writableImage);
        setAllowPGAccess(false);
        writableImageAccessor.loadTkImage(writableImage, toolkit.renderToImage(imageRenderingContext));
        if (camera != null) {
            setAllowPGAccess(true);
            camera.setViewWidth(viewWidth);
            camera.setViewHeight(viewHeight);
            NodeHelper.updatePeer(camera);
            setAllowPGAccess(false);
        }
        if (scene != null && scene.peer != null) {
            scene.setNeedsRepaint();
        }
        return writableImage;
    }
    
    private WritableImage doSnapshot(final WritableImage writableImage) {
        this.doCSSLayoutSyncForSnapshot(this.getRoot());
        return doSnapshot(this, 0.0, 0.0, this.getWidth(), this.getHeight(), this.getRoot(), BaseTransform.IDENTITY_TRANSFORM, this.isDepthBufferInternal(), this.getFill(), this.getEffectiveCamera(), writableImage);
    }
    
    static void addSnapshotRunnable(final Runnable runnable) {
        Toolkit.getToolkit().checkFxUserThread();
        if (Scene.snapshotPulseListener == null) {
            Scene.snapshotRunnableListA = new ArrayList<Runnable>();
            Scene.snapshotRunnableListB = new ArrayList<Runnable>();
            Scene.snapshotRunnableList = Scene.snapshotRunnableListA;
            List<Runnable> snapshotRunnableList;
            final Iterator<Runnable> iterator;
            Runnable runnable2;
            Scene.snapshotPulseListener = (() -> {
                if (Scene.snapshotRunnableList.size() > 0) {
                    snapshotRunnableList = Scene.snapshotRunnableList;
                    if (Scene.snapshotRunnableList == Scene.snapshotRunnableListA) {
                        Scene.snapshotRunnableList = Scene.snapshotRunnableListB;
                    }
                    else {
                        Scene.snapshotRunnableList = Scene.snapshotRunnableListA;
                    }
                    snapshotRunnableList.iterator();
                    while (iterator.hasNext()) {
                        runnable2 = iterator.next();
                        try {
                            runnable2.run();
                        }
                        catch (Throwable t) {
                            System.err.println("Exception in snapshot runnable");
                            t.printStackTrace(System.err);
                        }
                    }
                    snapshotRunnableList.clear();
                }
                return;
            });
            Toolkit.getToolkit().addPostSceneTkPulseListener(Scene.snapshotPulseListener);
        }
        Scene.snapshotRunnableList.add(() -> AccessController.doPrivileged(() -> {
            runnable.run();
            return null;
        }, AccessController.getContext()));
        Toolkit.getToolkit().requestNextPulse();
    }
    
    public WritableImage snapshot(final WritableImage writableImage) {
        Toolkit.getToolkit().checkFxUserThread();
        return this.doSnapshot(writableImage);
    }
    
    public void snapshot(final Callback<SnapshotResult, Void> callback, final WritableImage writableImage) {
        Toolkit.getToolkit().checkFxUserThread();
        if (callback == null) {
            throw new NullPointerException("The callback must not be null");
        }
        final SnapshotResult snapshotResult;
        Void void1;
        addSnapshotRunnable(() -> {
            snapshotResult = new SnapshotResult(this.doSnapshot(writableImage), this, null);
            try {
                void1 = callback.call(snapshotResult);
            }
            catch (Throwable t) {
                System.err.println("Exception in snapshot callback");
                t.printStackTrace(System.err);
            }
        });
    }
    
    public final void setCursor(final Cursor cursor) {
        this.cursorProperty().set(cursor);
    }
    
    public final Cursor getCursor() {
        return (this.cursor == null) ? null : this.cursor.get();
    }
    
    public final ObjectProperty<Cursor> cursorProperty() {
        if (this.cursor == null) {
            this.cursor = new ObjectPropertyBase<Cursor>() {
                @Override
                protected void invalidated() {
                    Scene.this.markCursorDirty();
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "cursor";
                }
            };
        }
        return this.cursor;
    }
    
    public Node lookup(final String s) {
        return this.getRoot().lookup(s);
    }
    
    public final ObservableList<String> getStylesheets() {
        return this.stylesheets;
    }
    
    public final ObjectProperty<String> userAgentStylesheetProperty() {
        if (this.userAgentStylesheet == null) {
            this.userAgentStylesheet = new SimpleObjectProperty<String>(this, "userAgentStylesheet", null) {
                @Override
                protected void invalidated() {
                    StyleManager.getInstance().forget(Scene.this);
                    Scene.this.getRoot().reapplyCSS();
                }
            };
        }
        return this.userAgentStylesheet;
    }
    
    public final String getUserAgentStylesheet() {
        return (this.userAgentStylesheet == null) ? null : this.userAgentStylesheet.get();
    }
    
    public final void setUserAgentStylesheet(final String s) {
        this.userAgentStylesheetProperty().set(s);
    }
    
    public final boolean isDepthBuffer() {
        return this.depthBuffer;
    }
    
    boolean isDepthBufferInternal() {
        return Platform.isSupported(ConditionalFeature.SCENE3D) && this.depthBuffer;
    }
    
    private void init(final double widthSetByUser, final double heightSetByUser) {
        if (widthSetByUser >= 0.0) {
            this.widthSetByUser = widthSetByUser;
            this.setWidth((float)widthSetByUser);
        }
        if (heightSetByUser >= 0.0) {
            this.heightSetByUser = heightSetByUser;
            this.setHeight((float)heightSetByUser);
        }
        this.sizeInitialized = (this.widthSetByUser >= 0.0 && this.heightSetByUser >= 0.0);
    }
    
    private void init() {
        if (PerformanceTracker.isLoggingEnabled()) {
            PerformanceTracker.logEvent(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Scene;)Ljava/lang/String;, this));
        }
        this.mouseHandler = new MouseHandler();
        this.clickGenerator = new ClickGenerator();
        if (PerformanceTracker.isLoggingEnabled()) {
            PerformanceTracker.logEvent(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Scene;)Ljava/lang/String;, this));
        }
    }
    
    void preferredSize() {
        final Parent root = this.getRoot();
        this.doCSSPass();
        this.resizeRootToPreferredSize(root);
        this.doLayoutPass();
        if (this.widthSetByUser < 0.0) {
            this.setWidth(root.isResizable() ? (root.getLayoutX() + root.getTranslateX() + root.getLayoutBounds().getWidth()) : root.getBoundsInParent().getMaxX());
        }
        else {
            this.setWidth(this.widthSetByUser);
        }
        if (this.heightSetByUser < 0.0) {
            this.setHeight(root.isResizable() ? (root.getLayoutY() + root.getTranslateY() + root.getLayoutBounds().getHeight()) : root.getBoundsInParent().getMaxY());
        }
        else {
            this.setHeight(this.heightSetByUser);
        }
        this.sizeInitialized = (this.getWidth() > 0.0 && this.getHeight() > 0.0);
        PerformanceTracker.logEvent("Scene preferred bounds computation complete");
    }
    
    final void resizeRootToPreferredSize(final Parent parent) {
        final Orientation contentBias = parent.getContentBias();
        double n;
        double n2;
        if (contentBias == null) {
            n = getPreferredWidth(parent, this.widthSetByUser, -1.0);
            n2 = getPreferredHeight(parent, this.heightSetByUser, -1.0);
        }
        else if (contentBias == Orientation.HORIZONTAL) {
            n = getPreferredWidth(parent, this.widthSetByUser, -1.0);
            n2 = getPreferredHeight(parent, this.heightSetByUser, n);
        }
        else {
            n2 = getPreferredHeight(parent, this.heightSetByUser, -1.0);
            n = getPreferredWidth(parent, this.widthSetByUser, n2);
        }
        parent.resize(n, n2);
    }
    
    private static double getPreferredWidth(final Parent parent, final double n, final double n2) {
        if (n >= 0.0) {
            return n;
        }
        final double n3 = (n2 >= 0.0) ? n2 : -1.0;
        return parent.boundedSize(parent.prefWidth(n3), parent.minWidth(n3), parent.maxWidth(n3));
    }
    
    private static double getPreferredHeight(final Parent parent, final double n, final double n2) {
        if (n >= 0.0) {
            return n;
        }
        final double n3 = (n2 >= 0.0) ? n2 : -1.0;
        return parent.boundedSize(parent.prefHeight(n3), parent.minHeight(n3), parent.maxHeight(n3));
    }
    
    void processMouseEvent(final MouseEvent mouseEvent) {
        this.mouseHandler.process(mouseEvent, false);
    }
    
    private void processMenuEvent(double n, double n2, double n3, double n4, final boolean b) {
        EventTarget intersectedNode = null;
        Scene.inMousePick = true;
        if (b) {
            final Node focusOwner = this.getFocusOwner();
            final double n5 = n3 - n;
            final double n6 = n4 - n2;
            if (focusOwner != null) {
                final Bounds localToScene = focusOwner.localToScene(focusOwner.getBoundsInLocal());
                n = localToScene.getMinX() + localToScene.getWidth() / 4.0;
                n2 = localToScene.getMinY() + localToScene.getHeight() / 2.0;
                intersectedNode = focusOwner;
            }
            else {
                n = this.getWidth() / 4.0;
                n2 = this.getWidth() / 2.0;
                intersectedNode = this;
            }
            n3 = n + n5;
            n4 = n2 + n6;
        }
        final PickResult pick = this.pick(n, n2);
        if (!b) {
            intersectedNode = pick.getIntersectedNode();
            if (intersectedNode == null) {
                intersectedNode = this;
            }
        }
        if (intersectedNode != null) {
            Event.fireEvent(intersectedNode, new ContextMenuEvent(ContextMenuEvent.CONTEXT_MENU_REQUESTED, n, n2, n3, n4, b, pick));
        }
        Scene.inMousePick = false;
    }
    
    private void processGestureEvent(final GestureEvent gestureEvent, final TouchGesture touchGesture) {
        if (gestureEvent.getEventType() == ZoomEvent.ZOOM_STARTED || gestureEvent.getEventType() == RotateEvent.ROTATION_STARTED || gestureEvent.getEventType() == ScrollEvent.SCROLL_STARTED) {
            touchGesture.target = null;
            touchGesture.finished = false;
        }
        EventTarget intersectedNode;
        if (touchGesture.target != null && (!touchGesture.finished || gestureEvent.isInertia())) {
            intersectedNode = touchGesture.target.get();
        }
        else {
            intersectedNode = gestureEvent.getPickResult().getIntersectedNode();
            if (intersectedNode == null) {
                intersectedNode = this;
            }
        }
        if (gestureEvent.getEventType() == ZoomEvent.ZOOM_STARTED || gestureEvent.getEventType() == RotateEvent.ROTATION_STARTED || gestureEvent.getEventType() == ScrollEvent.SCROLL_STARTED) {
            touchGesture.target = new WeakReference<EventTarget>(intersectedNode);
        }
        if (gestureEvent.getEventType() != ZoomEvent.ZOOM_FINISHED && gestureEvent.getEventType() != RotateEvent.ROTATION_FINISHED && gestureEvent.getEventType() != ScrollEvent.SCROLL_FINISHED && !gestureEvent.isInertia()) {
            touchGesture.sceneCoords = new Point2D(gestureEvent.getSceneX(), gestureEvent.getSceneY());
            touchGesture.screenCoords = new Point2D(gestureEvent.getScreenX(), gestureEvent.getScreenY());
        }
        if (intersectedNode != null) {
            Event.fireEvent(intersectedNode, gestureEvent);
        }
        if (gestureEvent.getEventType() == ZoomEvent.ZOOM_FINISHED || gestureEvent.getEventType() == RotateEvent.ROTATION_FINISHED || gestureEvent.getEventType() == ScrollEvent.SCROLL_FINISHED) {
            touchGesture.finished = true;
        }
    }
    
    private void processTouchEvent(final TouchEvent touchEvent, final TouchPoint[] a) {
        Scene.inMousePick = true;
        ++this.touchEventSetId;
        final List<TouchPoint> list = Arrays.asList(a);
        for (final TouchPoint touchPoint : a) {
            if (touchPoint.getTarget() != null) {
                EventType<TouchEvent> eventType = null;
                switch (touchPoint.getState()) {
                    case MOVED: {
                        eventType = TouchEvent.TOUCH_MOVED;
                        break;
                    }
                    case PRESSED: {
                        eventType = TouchEvent.TOUCH_PRESSED;
                        break;
                    }
                    case RELEASED: {
                        eventType = TouchEvent.TOUCH_RELEASED;
                        break;
                    }
                    case STATIONARY: {
                        eventType = TouchEvent.TOUCH_STATIONARY;
                        break;
                    }
                }
                for (int length2 = a.length, j = 0; j < length2; ++j) {
                    TouchPointHelper.reset(a[j]);
                }
                Event.fireEvent(touchPoint.getTarget(), new TouchEvent(eventType, touchPoint, list, this.touchEventSetId, touchEvent.isShiftDown(), touchEvent.isControlDown(), touchEvent.isAltDown(), touchEvent.isMetaDown()));
            }
        }
        for (final TouchPoint touchPoint2 : a) {
            final EventTarget grabbed = touchPoint2.getGrabbed();
            if (grabbed != null) {
                this.touchTargets.put(touchPoint2.getId(), grabbed);
            }
            if (grabbed == null || touchPoint2.getState() == TouchPoint.State.RELEASED) {
                this.touchTargets.remove(touchPoint2.getId());
            }
        }
        Scene.inMousePick = false;
    }
    
    Node test_pick(final double n, final double n2) {
        Scene.inMousePick = true;
        final PickResult access$1300 = this.mouseHandler.pickNode(new PickRay(n, n2, 1.0, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY));
        Scene.inMousePick = false;
        if (access$1300 != null) {
            return access$1300.getIntersectedNode();
        }
        return null;
    }
    
    private PickResult pick(final double n, final double n2) {
        this.pick(this.tmpTargetWrapper, n, n2);
        return this.tmpTargetWrapper.getResult();
    }
    
    private boolean isInScene(final double n, final double n2) {
        if (n < 0.0 || n2 < 0.0 || n > this.getWidth() || n2 > this.getHeight()) {
            return false;
        }
        final Window window = this.getWindow();
        return !(window instanceof Stage) || ((Stage)window).getStyle() != StageStyle.TRANSPARENT || this.getFill() != null;
    }
    
    private void pick(final TargetWrapper targetWrapper, final double n, final double n2) {
        final PickRay computePickRay = this.getEffectiveCamera().computePickRay(n, n2, null);
        final double length = computePickRay.getDirectionNoClone().length();
        computePickRay.getDirectionNoClone().normalize();
        final PickResult access$1300 = this.mouseHandler.pickNode(computePickRay);
        if (access$1300 != null) {
            targetWrapper.setNodeResult(access$1300);
        }
        else {
            final Vec3d originNoClone = computePickRay.getOriginNoClone();
            final Vec3d directionNoClone = computePickRay.getDirectionNoClone();
            targetWrapper.setSceneResult(new PickResult(null, new Point3D(originNoClone.x + length * directionNoClone.x, originNoClone.y + length * directionNoClone.y, originNoClone.z + length * directionNoClone.z), length), this.isInScene(n, n2) ? this : null);
        }
    }
    
    private KeyHandler getKeyHandler() {
        if (this.keyHandler == null) {
            this.keyHandler = new KeyHandler();
        }
        return this.keyHandler;
    }
    
    final void setFocusDirty(final boolean focusDirty) {
        if (!this.focusDirty) {
            Toolkit.getToolkit().requestNextPulse();
        }
        this.focusDirty = focusDirty;
    }
    
    final boolean isFocusDirty() {
        return this.focusDirty;
    }
    
    boolean traverse(final Node node, final Direction direction) {
        if (node.getSubScene() != null) {
            return node.getSubScene().traverse(node, direction);
        }
        return this.traversalEngine.trav(node, direction) != null;
    }
    
    private void focusInitial() {
        this.traversalEngine.traverseToFirst();
    }
    
    private void focusIneligible(final Node node) {
        this.traverse(node, Direction.NEXT);
    }
    
    public void processKeyEvent(final KeyEvent keyEvent) {
        if (this.dndGesture != null && !this.dndGesture.processKey(keyEvent)) {
            this.dndGesture = null;
        }
        this.getKeyHandler().process(keyEvent);
    }
    
    void requestFocus(final Node node) {
        this.getKeyHandler().requestFocus(node);
    }
    
    public final Node getFocusOwner() {
        return this.focusOwner.get();
    }
    
    public final ReadOnlyObjectProperty<Node> focusOwnerProperty() {
        return this.focusOwner.getReadOnlyProperty();
    }
    
    void focusCleanup() {
        this.scenePulseListener.focusCleanup();
    }
    
    private void processInputMethodEvent(final InputMethodEvent inputMethodEvent) {
        final Node focusOwner = this.getFocusOwner();
        if (focusOwner != null) {
            focusOwner.fireEvent(inputMethodEvent);
        }
    }
    
    public void enableInputMethodEvents(final boolean b) {
        if (this.peer != null) {
            this.peer.enableInputMethodEvents(b);
        }
    }
    
    boolean isQuiescent() {
        final Parent root = this.getRoot();
        return !this.isFocusDirty() && (root == null || (root.cssFlag == CssFlags.CLEAN && root.layoutFlag == LayoutFlags.CLEAN));
    }
    
    private void markDirty(final DirtyBits dirty) {
        this.setDirty(dirty);
        if (this.peer != null) {
            Toolkit.getToolkit().requestNextPulse();
        }
    }
    
    private void setDirty(final DirtyBits dirtyBits) {
        this.dirtyBits |= dirtyBits.getMask();
    }
    
    private boolean isDirty(final DirtyBits dirtyBits) {
        return (this.dirtyBits & dirtyBits.getMask()) != 0x0;
    }
    
    private boolean isDirtyEmpty() {
        return this.dirtyBits == 0;
    }
    
    private void clearDirty() {
        this.dirtyBits = 0;
    }
    
    final void addLight(final LightBase lightBase) {
        if (!this.lights.contains(lightBase)) {
            this.lights.add(lightBase);
            this.markDirty(DirtyBits.LIGHTS_DIRTY);
        }
    }
    
    final void removeLight(final LightBase lightBase) {
        if (this.lights.remove(lightBase)) {
            this.markDirty(DirtyBits.LIGHTS_DIRTY);
        }
    }
    
    private void syncLights() {
        if (!this.isDirty(DirtyBits.LIGHTS_DIRTY)) {
            return;
        }
        Scene.inSynchronizer = true;
        NGLightBase[] lights = this.peer.getLights();
        if (!this.lights.isEmpty() || lights != null) {
            if (this.lights.isEmpty()) {
                this.peer.setLights(null);
            }
            else {
                if (lights == null || lights.length < this.lights.size()) {
                    lights = new NGLightBase[this.lights.size()];
                }
                int i;
                for (i = 0; i < this.lights.size(); ++i) {
                    lights[i] = (NGLightBase)this.lights.get(i).getPeer();
                }
                while (i < lights.length && lights[i] != null) {
                    lights[i++] = null;
                }
                this.peer.setLights(lights);
            }
        }
        Scene.inSynchronizer = false;
    }
    
    void generateMouseExited(final Node node) {
        this.mouseHandler.handleNodeRemoval(node);
    }
    
    public final void setEventDispatcher(final EventDispatcher eventDispatcher) {
        this.eventDispatcherProperty().set(eventDispatcher);
    }
    
    public final EventDispatcher getEventDispatcher() {
        return this.eventDispatcherProperty().get();
    }
    
    public final ObjectProperty<EventDispatcher> eventDispatcherProperty() {
        this.initializeInternalEventDispatcher();
        return this.eventDispatcher;
    }
    
    public final <T extends Event> void addEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().addEventHandler(eventType, eventHandler);
    }
    
    public final <T extends Event> void removeEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().removeEventHandler(eventType, eventHandler);
    }
    
    public final <T extends Event> void addEventFilter(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().addEventFilter(eventType, eventHandler);
    }
    
    public final <T extends Event> void removeEventFilter(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().removeEventFilter(eventType, eventHandler);
    }
    
    protected final <T extends Event> void setEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().setEventHandler(eventType, eventHandler);
    }
    
    private SceneEventDispatcher getInternalEventDispatcher() {
        this.initializeInternalEventDispatcher();
        return this.internalEventDispatcher;
    }
    
    final void initializeInternalEventDispatcher() {
        if (this.internalEventDispatcher == null) {
            this.internalEventDispatcher = this.createInternalEventDispatcher();
            this.eventDispatcher = new SimpleObjectProperty<EventDispatcher>(this, "eventDispatcher", this.internalEventDispatcher);
        }
    }
    
    private SceneEventDispatcher createInternalEventDispatcher() {
        return new SceneEventDispatcher(this);
    }
    
    public void addMnemonic(final Mnemonic mnemonic) {
        this.getInternalEventDispatcher().getKeyboardShortcutsHandler().addMnemonic(mnemonic);
    }
    
    public void removeMnemonic(final Mnemonic mnemonic) {
        this.getInternalEventDispatcher().getKeyboardShortcutsHandler().removeMnemonic(mnemonic);
    }
    
    final void clearNodeMnemonics(final Node node) {
        this.getInternalEventDispatcher().getKeyboardShortcutsHandler().clearNodeMnemonics(node);
    }
    
    public ObservableMap<KeyCombination, ObservableList<Mnemonic>> getMnemonics() {
        return this.getInternalEventDispatcher().getKeyboardShortcutsHandler().getMnemonics();
    }
    
    public ObservableMap<KeyCombination, Runnable> getAccelerators() {
        return this.getInternalEventDispatcher().getKeyboardShortcutsHandler().getAccelerators();
    }
    
    @Override
    public EventDispatchChain buildEventDispatchChain(EventDispatchChain eventDispatchChain) {
        if (this.eventDispatcher != null) {
            final EventDispatcher eventDispatcher = this.eventDispatcher.get();
            if (eventDispatcher != null) {
                eventDispatchChain = eventDispatchChain.prepend(eventDispatcher);
            }
        }
        if (this.getWindow() != null) {
            eventDispatchChain = this.getWindow().buildEventDispatchChain(eventDispatchChain);
        }
        return eventDispatchChain;
    }
    
    public final void setOnContextMenuRequested(final EventHandler<? super ContextMenuEvent> eventHandler) {
        this.onContextMenuRequestedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ContextMenuEvent> getOnContextMenuRequested() {
        return (this.onContextMenuRequested == null) ? null : this.onContextMenuRequested.get();
    }
    
    public final ObjectProperty<EventHandler<? super ContextMenuEvent>> onContextMenuRequestedProperty() {
        if (this.onContextMenuRequested == null) {
            this.onContextMenuRequested = new ObjectPropertyBase<EventHandler<? super ContextMenuEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(ContextMenuEvent.CONTEXT_MENU_REQUESTED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onContextMenuRequested";
                }
            };
        }
        return this.onContextMenuRequested;
    }
    
    public final void setOnMouseClicked(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseClickedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseClicked() {
        return (this.onMouseClicked == null) ? null : this.onMouseClicked.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseClickedProperty() {
        if (this.onMouseClicked == null) {
            this.onMouseClicked = new ObjectPropertyBase<EventHandler<? super MouseEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseEvent.MOUSE_CLICKED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseClicked";
                }
            };
        }
        return this.onMouseClicked;
    }
    
    public final void setOnMouseDragged(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseDraggedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseDragged() {
        return (this.onMouseDragged == null) ? null : this.onMouseDragged.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseDraggedProperty() {
        if (this.onMouseDragged == null) {
            this.onMouseDragged = new ObjectPropertyBase<EventHandler<? super MouseEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseEvent.MOUSE_DRAGGED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseDragged";
                }
            };
        }
        return this.onMouseDragged;
    }
    
    public final void setOnMouseEntered(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseEnteredProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseEntered() {
        return (this.onMouseEntered == null) ? null : this.onMouseEntered.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseEnteredProperty() {
        if (this.onMouseEntered == null) {
            this.onMouseEntered = new ObjectPropertyBase<EventHandler<? super MouseEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseEvent.MOUSE_ENTERED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseEntered";
                }
            };
        }
        return this.onMouseEntered;
    }
    
    public final void setOnMouseExited(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseExitedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseExited() {
        return (this.onMouseExited == null) ? null : this.onMouseExited.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseExitedProperty() {
        if (this.onMouseExited == null) {
            this.onMouseExited = new ObjectPropertyBase<EventHandler<? super MouseEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseEvent.MOUSE_EXITED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseExited";
                }
            };
        }
        return this.onMouseExited;
    }
    
    public final void setOnMouseMoved(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseMovedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseMoved() {
        return (this.onMouseMoved == null) ? null : this.onMouseMoved.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseMovedProperty() {
        if (this.onMouseMoved == null) {
            this.onMouseMoved = new ObjectPropertyBase<EventHandler<? super MouseEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseEvent.MOUSE_MOVED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseMoved";
                }
            };
        }
        return this.onMouseMoved;
    }
    
    public final void setOnMousePressed(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMousePressedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMousePressed() {
        return (this.onMousePressed == null) ? null : this.onMousePressed.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMousePressedProperty() {
        if (this.onMousePressed == null) {
            this.onMousePressed = new ObjectPropertyBase<EventHandler<? super MouseEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseEvent.MOUSE_PRESSED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMousePressed";
                }
            };
        }
        return this.onMousePressed;
    }
    
    public final void setOnMouseReleased(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseReleasedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseReleased() {
        return (this.onMouseReleased == null) ? null : this.onMouseReleased.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseReleasedProperty() {
        if (this.onMouseReleased == null) {
            this.onMouseReleased = new ObjectPropertyBase<EventHandler<? super MouseEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseEvent.MOUSE_RELEASED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseReleased";
                }
            };
        }
        return this.onMouseReleased;
    }
    
    public final void setOnDragDetected(final EventHandler<? super MouseEvent> eventHandler) {
        this.onDragDetectedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnDragDetected() {
        return (this.onDragDetected == null) ? null : this.onDragDetected.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onDragDetectedProperty() {
        if (this.onDragDetected == null) {
            this.onDragDetected = new ObjectPropertyBase<EventHandler<? super MouseEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseEvent.DRAG_DETECTED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onDragDetected";
                }
            };
        }
        return this.onDragDetected;
    }
    
    public final void setOnMouseDragOver(final EventHandler<? super MouseDragEvent> eventHandler) {
        this.onMouseDragOverProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseDragEvent> getOnMouseDragOver() {
        return (this.onMouseDragOver == null) ? null : this.onMouseDragOver.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragOverProperty() {
        if (this.onMouseDragOver == null) {
            this.onMouseDragOver = new ObjectPropertyBase<EventHandler<? super MouseDragEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseDragEvent.MOUSE_DRAG_OVER, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseDragOver";
                }
            };
        }
        return this.onMouseDragOver;
    }
    
    public final void setOnMouseDragReleased(final EventHandler<? super MouseDragEvent> eventHandler) {
        this.onMouseDragReleasedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseDragEvent> getOnMouseDragReleased() {
        return (this.onMouseDragReleased == null) ? null : this.onMouseDragReleased.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragReleasedProperty() {
        if (this.onMouseDragReleased == null) {
            this.onMouseDragReleased = new ObjectPropertyBase<EventHandler<? super MouseDragEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseDragEvent.MOUSE_DRAG_RELEASED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseDragReleased";
                }
            };
        }
        return this.onMouseDragReleased;
    }
    
    public final void setOnMouseDragEntered(final EventHandler<? super MouseDragEvent> eventHandler) {
        this.onMouseDragEnteredProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseDragEvent> getOnMouseDragEntered() {
        return (this.onMouseDragEntered == null) ? null : this.onMouseDragEntered.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragEnteredProperty() {
        if (this.onMouseDragEntered == null) {
            this.onMouseDragEntered = new ObjectPropertyBase<EventHandler<? super MouseDragEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseDragEvent.MOUSE_DRAG_ENTERED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseDragEntered";
                }
            };
        }
        return this.onMouseDragEntered;
    }
    
    public final void setOnMouseDragExited(final EventHandler<? super MouseDragEvent> eventHandler) {
        this.onMouseDragExitedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseDragEvent> getOnMouseDragExited() {
        return (this.onMouseDragExited == null) ? null : this.onMouseDragExited.get();
    }
    
    public final ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragExitedProperty() {
        if (this.onMouseDragExited == null) {
            this.onMouseDragExited = new ObjectPropertyBase<EventHandler<? super MouseDragEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(MouseDragEvent.MOUSE_DRAG_EXITED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onMouseDragExited";
                }
            };
        }
        return this.onMouseDragExited;
    }
    
    public final void setOnScrollStarted(final EventHandler<? super ScrollEvent> eventHandler) {
        this.onScrollStartedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ScrollEvent> getOnScrollStarted() {
        return (this.onScrollStarted == null) ? null : this.onScrollStarted.get();
    }
    
    public final ObjectProperty<EventHandler<? super ScrollEvent>> onScrollStartedProperty() {
        if (this.onScrollStarted == null) {
            this.onScrollStarted = new ObjectPropertyBase<EventHandler<? super ScrollEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(ScrollEvent.SCROLL_STARTED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onScrollStarted";
                }
            };
        }
        return this.onScrollStarted;
    }
    
    public final void setOnScroll(final EventHandler<? super ScrollEvent> eventHandler) {
        this.onScrollProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ScrollEvent> getOnScroll() {
        return (this.onScroll == null) ? null : this.onScroll.get();
    }
    
    public final ObjectProperty<EventHandler<? super ScrollEvent>> onScrollProperty() {
        if (this.onScroll == null) {
            this.onScroll = new ObjectPropertyBase<EventHandler<? super ScrollEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(ScrollEvent.SCROLL, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onScroll";
                }
            };
        }
        return this.onScroll;
    }
    
    public final void setOnScrollFinished(final EventHandler<? super ScrollEvent> eventHandler) {
        this.onScrollFinishedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ScrollEvent> getOnScrollFinished() {
        return (this.onScrollFinished == null) ? null : this.onScrollFinished.get();
    }
    
    public final ObjectProperty<EventHandler<? super ScrollEvent>> onScrollFinishedProperty() {
        if (this.onScrollFinished == null) {
            this.onScrollFinished = new ObjectPropertyBase<EventHandler<? super ScrollEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(ScrollEvent.SCROLL_FINISHED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onScrollFinished";
                }
            };
        }
        return this.onScrollFinished;
    }
    
    public final void setOnRotationStarted(final EventHandler<? super RotateEvent> eventHandler) {
        this.onRotationStartedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super RotateEvent> getOnRotationStarted() {
        return (this.onRotationStarted == null) ? null : this.onRotationStarted.get();
    }
    
    public final ObjectProperty<EventHandler<? super RotateEvent>> onRotationStartedProperty() {
        if (this.onRotationStarted == null) {
            this.onRotationStarted = new ObjectPropertyBase<EventHandler<? super RotateEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(RotateEvent.ROTATION_STARTED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onRotationStarted";
                }
            };
        }
        return this.onRotationStarted;
    }
    
    public final void setOnRotate(final EventHandler<? super RotateEvent> eventHandler) {
        this.onRotateProperty().set(eventHandler);
    }
    
    public final EventHandler<? super RotateEvent> getOnRotate() {
        return (this.onRotate == null) ? null : this.onRotate.get();
    }
    
    public final ObjectProperty<EventHandler<? super RotateEvent>> onRotateProperty() {
        if (this.onRotate == null) {
            this.onRotate = new ObjectPropertyBase<EventHandler<? super RotateEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(RotateEvent.ROTATE, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onRotate";
                }
            };
        }
        return this.onRotate;
    }
    
    public final void setOnRotationFinished(final EventHandler<? super RotateEvent> eventHandler) {
        this.onRotationFinishedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super RotateEvent> getOnRotationFinished() {
        return (this.onRotationFinished == null) ? null : this.onRotationFinished.get();
    }
    
    public final ObjectProperty<EventHandler<? super RotateEvent>> onRotationFinishedProperty() {
        if (this.onRotationFinished == null) {
            this.onRotationFinished = new ObjectPropertyBase<EventHandler<? super RotateEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(RotateEvent.ROTATION_FINISHED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onRotationFinished";
                }
            };
        }
        return this.onRotationFinished;
    }
    
    public final void setOnZoomStarted(final EventHandler<? super ZoomEvent> eventHandler) {
        this.onZoomStartedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ZoomEvent> getOnZoomStarted() {
        return (this.onZoomStarted == null) ? null : this.onZoomStarted.get();
    }
    
    public final ObjectProperty<EventHandler<? super ZoomEvent>> onZoomStartedProperty() {
        if (this.onZoomStarted == null) {
            this.onZoomStarted = new ObjectPropertyBase<EventHandler<? super ZoomEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(ZoomEvent.ZOOM_STARTED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onZoomStarted";
                }
            };
        }
        return this.onZoomStarted;
    }
    
    public final void setOnZoom(final EventHandler<? super ZoomEvent> eventHandler) {
        this.onZoomProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ZoomEvent> getOnZoom() {
        return (this.onZoom == null) ? null : this.onZoom.get();
    }
    
    public final ObjectProperty<EventHandler<? super ZoomEvent>> onZoomProperty() {
        if (this.onZoom == null) {
            this.onZoom = new ObjectPropertyBase<EventHandler<? super ZoomEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(ZoomEvent.ZOOM, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onZoom";
                }
            };
        }
        return this.onZoom;
    }
    
    public final void setOnZoomFinished(final EventHandler<? super ZoomEvent> eventHandler) {
        this.onZoomFinishedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ZoomEvent> getOnZoomFinished() {
        return (this.onZoomFinished == null) ? null : this.onZoomFinished.get();
    }
    
    public final ObjectProperty<EventHandler<? super ZoomEvent>> onZoomFinishedProperty() {
        if (this.onZoomFinished == null) {
            this.onZoomFinished = new ObjectPropertyBase<EventHandler<? super ZoomEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(ZoomEvent.ZOOM_FINISHED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onZoomFinished";
                }
            };
        }
        return this.onZoomFinished;
    }
    
    public final void setOnSwipeUp(final EventHandler<? super SwipeEvent> eventHandler) {
        this.onSwipeUpProperty().set(eventHandler);
    }
    
    public final EventHandler<? super SwipeEvent> getOnSwipeUp() {
        return (this.onSwipeUp == null) ? null : this.onSwipeUp.get();
    }
    
    public final ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeUpProperty() {
        if (this.onSwipeUp == null) {
            this.onSwipeUp = new ObjectPropertyBase<EventHandler<? super SwipeEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(SwipeEvent.SWIPE_UP, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onSwipeUp";
                }
            };
        }
        return this.onSwipeUp;
    }
    
    public final void setOnSwipeDown(final EventHandler<? super SwipeEvent> eventHandler) {
        this.onSwipeDownProperty().set(eventHandler);
    }
    
    public final EventHandler<? super SwipeEvent> getOnSwipeDown() {
        return (this.onSwipeDown == null) ? null : this.onSwipeDown.get();
    }
    
    public final ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeDownProperty() {
        if (this.onSwipeDown == null) {
            this.onSwipeDown = new ObjectPropertyBase<EventHandler<? super SwipeEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(SwipeEvent.SWIPE_DOWN, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onSwipeDown";
                }
            };
        }
        return this.onSwipeDown;
    }
    
    public final void setOnSwipeLeft(final EventHandler<? super SwipeEvent> eventHandler) {
        this.onSwipeLeftProperty().set(eventHandler);
    }
    
    public final EventHandler<? super SwipeEvent> getOnSwipeLeft() {
        return (this.onSwipeLeft == null) ? null : this.onSwipeLeft.get();
    }
    
    public final ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeLeftProperty() {
        if (this.onSwipeLeft == null) {
            this.onSwipeLeft = new ObjectPropertyBase<EventHandler<? super SwipeEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(SwipeEvent.SWIPE_LEFT, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onSwipeLeft";
                }
            };
        }
        return this.onSwipeLeft;
    }
    
    public final void setOnSwipeRight(final EventHandler<? super SwipeEvent> eventHandler) {
        this.onSwipeRightProperty().set(eventHandler);
    }
    
    public final EventHandler<? super SwipeEvent> getOnSwipeRight() {
        return (this.onSwipeRight == null) ? null : this.onSwipeRight.get();
    }
    
    public final ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeRightProperty() {
        if (this.onSwipeRight == null) {
            this.onSwipeRight = new ObjectPropertyBase<EventHandler<? super SwipeEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(SwipeEvent.SWIPE_RIGHT, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onSwipeRight";
                }
            };
        }
        return this.onSwipeRight;
    }
    
    public final void setOnTouchPressed(final EventHandler<? super TouchEvent> eventHandler) {
        this.onTouchPressedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super TouchEvent> getOnTouchPressed() {
        return (this.onTouchPressed == null) ? null : this.onTouchPressed.get();
    }
    
    public final ObjectProperty<EventHandler<? super TouchEvent>> onTouchPressedProperty() {
        if (this.onTouchPressed == null) {
            this.onTouchPressed = new ObjectPropertyBase<EventHandler<? super TouchEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(TouchEvent.TOUCH_PRESSED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onTouchPressed";
                }
            };
        }
        return this.onTouchPressed;
    }
    
    public final void setOnTouchMoved(final EventHandler<? super TouchEvent> eventHandler) {
        this.onTouchMovedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super TouchEvent> getOnTouchMoved() {
        return (this.onTouchMoved == null) ? null : this.onTouchMoved.get();
    }
    
    public final ObjectProperty<EventHandler<? super TouchEvent>> onTouchMovedProperty() {
        if (this.onTouchMoved == null) {
            this.onTouchMoved = new ObjectPropertyBase<EventHandler<? super TouchEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(TouchEvent.TOUCH_MOVED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onTouchMoved";
                }
            };
        }
        return this.onTouchMoved;
    }
    
    public final void setOnTouchReleased(final EventHandler<? super TouchEvent> eventHandler) {
        this.onTouchReleasedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super TouchEvent> getOnTouchReleased() {
        return (this.onTouchReleased == null) ? null : this.onTouchReleased.get();
    }
    
    public final ObjectProperty<EventHandler<? super TouchEvent>> onTouchReleasedProperty() {
        if (this.onTouchReleased == null) {
            this.onTouchReleased = new ObjectPropertyBase<EventHandler<? super TouchEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(TouchEvent.TOUCH_RELEASED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onTouchReleased";
                }
            };
        }
        return this.onTouchReleased;
    }
    
    public final void setOnTouchStationary(final EventHandler<? super TouchEvent> eventHandler) {
        this.onTouchStationaryProperty().set(eventHandler);
    }
    
    public final EventHandler<? super TouchEvent> getOnTouchStationary() {
        return (this.onTouchStationary == null) ? null : this.onTouchStationary.get();
    }
    
    public final ObjectProperty<EventHandler<? super TouchEvent>> onTouchStationaryProperty() {
        if (this.onTouchStationary == null) {
            this.onTouchStationary = new ObjectPropertyBase<EventHandler<? super TouchEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(TouchEvent.TOUCH_STATIONARY, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onTouchStationary";
                }
            };
        }
        return this.onTouchStationary;
    }
    
    public final void setOnDragEntered(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragEnteredProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragEntered() {
        return (this.onDragEntered == null) ? null : this.onDragEntered.get();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragEnteredProperty() {
        if (this.onDragEntered == null) {
            this.onDragEntered = new ObjectPropertyBase<EventHandler<? super DragEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(DragEvent.DRAG_ENTERED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onDragEntered";
                }
            };
        }
        return this.onDragEntered;
    }
    
    public final void setOnDragExited(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragExitedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragExited() {
        return (this.onDragExited == null) ? null : this.onDragExited.get();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragExitedProperty() {
        if (this.onDragExited == null) {
            this.onDragExited = new ObjectPropertyBase<EventHandler<? super DragEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(DragEvent.DRAG_EXITED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onDragExited";
                }
            };
        }
        return this.onDragExited;
    }
    
    public final void setOnDragOver(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragOverProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragOver() {
        return (this.onDragOver == null) ? null : this.onDragOver.get();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragOverProperty() {
        if (this.onDragOver == null) {
            this.onDragOver = new ObjectPropertyBase<EventHandler<? super DragEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(DragEvent.DRAG_OVER, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onDragOver";
                }
            };
        }
        return this.onDragOver;
    }
    
    public final void setOnDragDropped(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragDroppedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragDropped() {
        return (this.onDragDropped == null) ? null : this.onDragDropped.get();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragDroppedProperty() {
        if (this.onDragDropped == null) {
            this.onDragDropped = new ObjectPropertyBase<EventHandler<? super DragEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(DragEvent.DRAG_DROPPED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onDragDropped";
                }
            };
        }
        return this.onDragDropped;
    }
    
    public final void setOnDragDone(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragDoneProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragDone() {
        return (this.onDragDone == null) ? null : this.onDragDone.get();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragDoneProperty() {
        if (this.onDragDone == null) {
            this.onDragDone = new ObjectPropertyBase<EventHandler<? super DragEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(DragEvent.DRAG_DONE, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onDragDone";
                }
            };
        }
        return this.onDragDone;
    }
    
    public Dragboard startDragAndDrop(final TransferMode... array) {
        return this.startDragAndDrop(this, array);
    }
    
    public void startFullDrag() {
        this.startFullDrag(this);
    }
    
    Dragboard startDragAndDrop(final EventTarget eventTarget, final TransferMode... array) {
        Toolkit.getToolkit().checkFxUserThread();
        if (this.dndGesture == null || this.dndGesture.dragDetected != DragDetectedState.PROCESSING) {
            throw new IllegalStateException("Cannot start drag and drop outside of DRAG_DETECTED event handler");
        }
        final EnumSet<TransferMode> none = EnumSet.noneOf(TransferMode.class);
        final Iterator<TransferMode> iterator = InputEventUtils.safeTransferModes(array).iterator();
        while (iterator.hasNext()) {
            none.add(iterator.next());
        }
        return this.dndGesture.startDrag(eventTarget, none);
    }
    
    void startFullDrag(final EventTarget eventTarget) {
        Toolkit.getToolkit().checkFxUserThread();
        if (this.dndGesture.dragDetected != DragDetectedState.PROCESSING) {
            throw new IllegalStateException("Cannot start full drag outside of DRAG_DETECTED event handler");
        }
        if (this.dndGesture != null) {
            this.dndGesture.startFullPDR(eventTarget);
            return;
        }
        throw new IllegalStateException("Cannot start full drag when mouse button is not pressed");
    }
    
    public final void setOnKeyPressed(final EventHandler<? super KeyEvent> eventHandler) {
        this.onKeyPressedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super KeyEvent> getOnKeyPressed() {
        return (this.onKeyPressed == null) ? null : this.onKeyPressed.get();
    }
    
    public final ObjectProperty<EventHandler<? super KeyEvent>> onKeyPressedProperty() {
        if (this.onKeyPressed == null) {
            this.onKeyPressed = new ObjectPropertyBase<EventHandler<? super KeyEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(KeyEvent.KEY_PRESSED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onKeyPressed";
                }
            };
        }
        return this.onKeyPressed;
    }
    
    public final void setOnKeyReleased(final EventHandler<? super KeyEvent> eventHandler) {
        this.onKeyReleasedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super KeyEvent> getOnKeyReleased() {
        return (this.onKeyReleased == null) ? null : this.onKeyReleased.get();
    }
    
    public final ObjectProperty<EventHandler<? super KeyEvent>> onKeyReleasedProperty() {
        if (this.onKeyReleased == null) {
            this.onKeyReleased = new ObjectPropertyBase<EventHandler<? super KeyEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(KeyEvent.KEY_RELEASED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onKeyReleased";
                }
            };
        }
        return this.onKeyReleased;
    }
    
    public final void setOnKeyTyped(final EventHandler<? super KeyEvent> eventHandler) {
        this.onKeyTypedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super KeyEvent> getOnKeyTyped() {
        return (this.onKeyTyped == null) ? null : this.onKeyTyped.get();
    }
    
    public final ObjectProperty<EventHandler<? super KeyEvent>> onKeyTypedProperty() {
        if (this.onKeyTyped == null) {
            this.onKeyTyped = new ObjectPropertyBase<EventHandler<? super KeyEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(KeyEvent.KEY_TYPED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onKeyTyped";
                }
            };
        }
        return this.onKeyTyped;
    }
    
    public final void setOnInputMethodTextChanged(final EventHandler<? super InputMethodEvent> eventHandler) {
        this.onInputMethodTextChangedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super InputMethodEvent> getOnInputMethodTextChanged() {
        return (this.onInputMethodTextChanged == null) ? null : this.onInputMethodTextChanged.get();
    }
    
    public final ObjectProperty<EventHandler<? super InputMethodEvent>> onInputMethodTextChangedProperty() {
        if (this.onInputMethodTextChanged == null) {
            this.onInputMethodTextChanged = new ObjectPropertyBase<EventHandler<? super InputMethodEvent>>() {
                @Override
                protected void invalidated() {
                    Scene.this.setEventHandler(InputMethodEvent.INPUT_METHOD_TEXT_CHANGED, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "onInputMethodTextChanged";
                }
            };
        }
        return this.onInputMethodTextChanged;
    }
    
    public final ObservableMap<Object, Object> getProperties() {
        if (this.properties == null) {
            this.properties = FXCollections.observableMap(new HashMap<Object, Object>());
        }
        return this.properties;
    }
    
    public boolean hasProperties() {
        return this.properties != null && !this.properties.isEmpty();
    }
    
    public void setUserData(final Object o) {
        this.getProperties().put(Scene.USER_DATA_KEY, o);
    }
    
    public Object getUserData() {
        return this.getProperties().get(Scene.USER_DATA_KEY);
    }
    
    public final void setNodeOrientation(final NodeOrientation nodeOrientation) {
        this.nodeOrientationProperty().set(nodeOrientation);
    }
    
    public final NodeOrientation getNodeOrientation() {
        return (this.nodeOrientation == null) ? Scene.defaultNodeOrientation : this.nodeOrientation.get();
    }
    
    public final ObjectProperty<NodeOrientation> nodeOrientationProperty() {
        if (this.nodeOrientation == null) {
            this.nodeOrientation = new StyleableObjectProperty<NodeOrientation>(Scene.defaultNodeOrientation) {
                @Override
                protected void invalidated() {
                    Scene.this.sceneEffectiveOrientationInvalidated();
                    Scene.this.getRoot().applyCss();
                }
                
                @Override
                public Object getBean() {
                    return Scene.this;
                }
                
                @Override
                public String getName() {
                    return "nodeOrientation";
                }
                
                @Override
                public CssMetaData getCssMetaData() {
                    throw new UnsupportedOperationException("Not supported yet.");
                }
            };
        }
        return this.nodeOrientation;
    }
    
    public final NodeOrientation getEffectiveNodeOrientation() {
        if (this.effectiveNodeOrientation == null) {
            this.effectiveNodeOrientation = this.calcEffectiveNodeOrientation();
        }
        return this.effectiveNodeOrientation;
    }
    
    public final ReadOnlyObjectProperty<NodeOrientation> effectiveNodeOrientationProperty() {
        if (this.effectiveNodeOrientationProperty == null) {
            this.effectiveNodeOrientationProperty = new EffectiveOrientationProperty();
        }
        return this.effectiveNodeOrientationProperty;
    }
    
    private void parentEffectiveOrientationInvalidated() {
        if (this.getNodeOrientation() == NodeOrientation.INHERIT) {
            this.sceneEffectiveOrientationInvalidated();
        }
    }
    
    private void sceneEffectiveOrientationInvalidated() {
        this.effectiveNodeOrientation = null;
        if (this.effectiveNodeOrientationProperty != null) {
            this.effectiveNodeOrientationProperty.invalidate();
        }
        this.getRoot().parentResolvedOrientationInvalidated();
    }
    
    private NodeOrientation calcEffectiveNodeOrientation() {
        final NodeOrientation nodeOrientation = this.getNodeOrientation();
        if (nodeOrientation == NodeOrientation.INHERIT) {
            final Window window = this.getWindow();
            if (window != null) {
                Window window2 = null;
                if (window instanceof Stage) {
                    window2 = ((Stage)window).getOwner();
                }
                else if (window instanceof PopupWindow) {
                    window2 = ((PopupWindow)window).getOwnerWindow();
                }
                if (window2 != null) {
                    final Scene scene = window2.getScene();
                    if (scene != null) {
                        return scene.getEffectiveNodeOrientation();
                    }
                }
            }
            return NodeOrientation.LEFT_TO_RIGHT;
        }
        return nodeOrientation;
    }
    
    Accessible removeAccessible(final Node node) {
        if (this.accMap == null) {
            return null;
        }
        return this.accMap.remove(node);
    }
    
    void addAccessible(final Node node, final Accessible accessible) {
        if (this.accMap == null) {
            this.accMap = new HashMap<Node, Accessible>();
        }
        this.accMap.put(node, accessible);
    }
    
    private void disposeAccessibles() {
        if (this.accMap != null) {
            for (final Map.Entry<Node, Accessible> entry : this.accMap.entrySet()) {
                final Node node = entry.getKey();
                final Accessible accessible = entry.getValue();
                if (node.accessible != null) {
                    if (node.accessible == accessible) {
                        System.err.println("[A11y] 'node.accessible == acc' should never happen.");
                    }
                    if (node.getScene() == this) {
                        System.err.println("[A11y] 'node.getScene() == this' should never happen.");
                    }
                    accessible.dispose();
                }
                else if (node.getScene() == this) {
                    node.accessible = accessible;
                }
                else {
                    accessible.dispose();
                }
            }
            this.accMap.clear();
        }
    }
    
    Accessible getAccessible() {
        if (this.peer == null) {
            return null;
        }
        if (this.accessible == null) {
            (this.accessible = Application.GetApplication().createAccessible()).setEventHandler(new Accessible.EventHandler() {
                @Override
                public AccessControlContext getAccessControlContext() {
                    return Scene.this.getPeer().getAccessControlContext();
                }
                
                @Override
                public Object getAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
                    switch (accessibleAttribute) {
                        case CHILDREN: {
                            final Parent root = Scene.this.getRoot();
                            if (root != null) {
                                return FXCollections.observableArrayList(root);
                            }
                            break;
                        }
                        case TEXT: {
                            final Window window = Scene.this.getWindow();
                            if (window instanceof Stage) {
                                return ((Stage)window).getTitle();
                            }
                            break;
                        }
                        case NODE_AT_POINT: {
                            final Window window2 = Scene.this.getWindow();
                            final Point2D point2D = (Point2D)array[0];
                            final PickResult access$4900 = Scene.this.pick(point2D.getX() - Scene.this.getX() - window2.getX(), point2D.getY() - Scene.this.getY() - window2.getY());
                            if (access$4900 != null) {
                                final Node intersectedNode = access$4900.getIntersectedNode();
                                if (intersectedNode != null) {
                                    return intersectedNode;
                                }
                            }
                            return Scene.this.getRoot();
                        }
                        case ROLE: {
                            return AccessibleRole.PARENT;
                        }
                        case SCENE: {
                            return Scene.this;
                        }
                        case FOCUS_NODE: {
                            if (Scene.this.transientFocusContainer != null) {
                                return Scene.this.transientFocusContainer.queryAccessibleAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
                            }
                            return Scene.this.getFocusOwner();
                        }
                    }
                    return super.getAttribute(accessibleAttribute, array);
                }
            });
            PlatformImpl.accessibilityActiveProperty().set(true);
        }
        return this.accessible;
    }
    
    static {
        PerformanceTracker.setSceneAccessor(new PerformanceTracker.SceneAccessor() {
            @Override
            public void setPerfTracker(final Scene scene, final PerformanceTracker performanceTracker) {
                synchronized (Scene.trackerMonitor) {
                    scene.tracker = performanceTracker;
                }
            }
            
            @Override
            public PerformanceTracker getPerfTracker(final Scene scene) {
                synchronized (Scene.trackerMonitor) {
                    return scene.tracker;
                }
            }
        });
        SceneHelper.setSceneAccessor(new SceneHelper.SceneAccessor() {
            @Override
            public void enableInputMethodEvents(final Scene scene, final boolean b) {
                scene.enableInputMethodEvents(b);
            }
            
            @Override
            public void processKeyEvent(final Scene scene, final KeyEvent keyEvent) {
                scene.processKeyEvent(keyEvent);
            }
            
            @Override
            public void processMouseEvent(final Scene scene, final MouseEvent mouseEvent) {
                scene.processMouseEvent(mouseEvent);
            }
            
            @Override
            public void preferredSize(final Scene scene) {
                scene.preferredSize();
            }
            
            @Override
            public void disposePeer(final Scene scene) {
                scene.disposePeer();
            }
            
            @Override
            public void initPeer(final Scene scene) {
                scene.initPeer();
            }
            
            @Override
            public void setWindow(final Scene scene, final Window window) {
                scene.setWindow(window);
            }
            
            @Override
            public TKScene getPeer(final Scene scene) {
                return scene.getPeer();
            }
            
            @Override
            public void setAllowPGAccess(final boolean allowPGAccess) {
                Scene.setAllowPGAccess(allowPGAccess);
            }
            
            @Override
            public void parentEffectiveOrientationInvalidated(final Scene scene) {
                scene.parentEffectiveOrientationInvalidated();
            }
            
            @Override
            public Camera getEffectiveCamera(final Scene scene) {
                return scene.getEffectiveCamera();
            }
            
            @Override
            public Scene createPopupScene(final Parent parent) {
                return new Scene(parent) {
                    @Override
                    void doLayoutPass() {
                        this.resizeRootToPreferredSize(this.getRoot());
                        super.doLayoutPass();
                    }
                    
                    @Override
                    void resizeRootOnSceneSizeChange(final double n, final double n2) {
                    }
                };
            }
            
            @Override
            public void setTransientFocusContainer(final Scene scene, final Node node) {
                if (scene != null) {
                    scene.transientFocusContainer = node;
                }
            }
            
            @Override
            public Accessible getAccessible(final Scene scene) {
                return scene.getAccessible();
            }
        });
        Scene.inSynchronizer = false;
        Scene.inMousePick = false;
        Scene.allowPGAccess = false;
        Scene.pgAccessCount = 0;
        Scene.snapshotPulseListener = null;
        trackerMonitor = new Object();
        USER_DATA_KEY = new Object();
        defaultNodeOrientation = (AccessController.doPrivileged(() -> Boolean.getBoolean("javafx.scene.nodeOrientation.RTL")) ? NodeOrientation.RIGHT_TO_LEFT : NodeOrientation.INHERIT);
    }
    
    private static class TouchGesture
    {
        WeakReference<EventTarget> target;
        Point2D sceneCoords;
        Point2D screenCoords;
        boolean finished;
    }
    
    private enum DirtyBits
    {
        FILL_DIRTY, 
        ROOT_DIRTY, 
        CAMERA_DIRTY, 
        LIGHTS_DIRTY, 
        CURSOR_DIRTY;
        
        private int mask;
        
        private DirtyBits() {
            this.mask = 1 << this.ordinal();
        }
        
        public final int getMask() {
            return this.mask;
        }
    }
    
    class ScenePulseListener implements TKPulseListener
    {
        private boolean firstPulse;
        
        ScenePulseListener() {
            this.firstPulse = true;
        }
        
        private void synchronizeSceneNodes() {
            Toolkit.getToolkit().checkFxUserThread();
            Scene.inSynchronizer = true;
            if (Scene.this.dirtyNodes == null) {
                this.syncAll(Scene.this.getRoot());
                Scene.this.dirtyNodes = new Node[30];
            }
            else {
                for (int i = 0; i < Scene.this.dirtyNodesSize; ++i) {
                    final Node node = Scene.this.dirtyNodes[i];
                    Scene.this.dirtyNodes[i] = null;
                    if (node.getScene() == Scene.this) {
                        node.syncPeer();
                    }
                }
                Scene.this.dirtyNodesSize = 0;
            }
            Scene.inSynchronizer = false;
        }
        
        private int syncAll(final Node node) {
            node.syncPeer();
            int n = 1;
            if (node instanceof Parent) {
                final Parent parent = (Parent)node;
                for (int size = parent.getChildren().size(), i = 0; i < size; ++i) {
                    final Node node2 = parent.getChildren().get(i);
                    if (node2 != null) {
                        n += this.syncAll(node2);
                    }
                }
            }
            else if (node instanceof SubScene) {
                n += this.syncAll(((SubScene)node).getRoot());
            }
            if (node.getClip() != null) {
                n += this.syncAll(node.getClip());
            }
            return n;
        }
        
        private void synchronizeSceneProperties() {
            Scene.inSynchronizer = true;
            if (Scene.this.isDirty(DirtyBits.ROOT_DIRTY)) {
                Scene.this.peer.setRoot(Scene.this.getRoot().getPeer());
            }
            if (Scene.this.isDirty(DirtyBits.FILL_DIRTY)) {
                final Toolkit toolkit = Toolkit.getToolkit();
                Scene.this.peer.setFillPaint((Scene.this.getFill() == null) ? null : toolkit.getPaint(Scene.this.getFill()));
            }
            final Camera effectiveCamera = Scene.this.getEffectiveCamera();
            if (Scene.this.isDirty(DirtyBits.CAMERA_DIRTY)) {
                NodeHelper.updatePeer(effectiveCamera);
                Scene.this.peer.setCamera((NGCamera)effectiveCamera.getPeer());
            }
            if (Scene.this.isDirty(DirtyBits.CURSOR_DIRTY)) {
                Scene.this.mouseHandler.updateCursor(Scene.this.getCursor());
                Scene.this.mouseHandler.updateCursorFrame();
            }
            Scene.this.clearDirty();
            Scene.inSynchronizer = false;
        }
        
        private void focusCleanup() {
            if (Scene.this.isFocusDirty()) {
                final Node focusOwner = Scene.this.getFocusOwner();
                if (focusOwner == null) {
                    Scene.this.focusInitial();
                }
                else if (focusOwner.getScene() != Scene.this) {
                    Scene.this.requestFocus(null);
                    Scene.this.focusInitial();
                }
                else if (!focusOwner.isCanReceiveFocus()) {
                    Scene.this.requestFocus(null);
                    Scene.this.focusIneligible(focusOwner);
                }
                Scene.this.setFocusDirty(false);
            }
        }
        
        @Override
        public void pulse() {
            if (Scene.this.tracker != null) {
                Scene.this.tracker.pulse();
            }
            if (this.firstPulse) {
                PerformanceTracker.logEvent("Scene - first repaint");
            }
            this.focusCleanup();
            Scene.this.disposeAccessibles();
            if (Scene.this.preLayoutPulseListeners != null) {
                final Iterator<Runnable> iterator = Scene.this.preLayoutPulseListeners.iterator();
                while (iterator.hasNext()) {
                    iterator.next().run();
                }
            }
            if (PulseLogger.PULSE_LOGGING_ENABLED) {
                PulseLogger.newPhase("CSS Pass");
            }
            Scene.this.doCSSPass();
            if (PulseLogger.PULSE_LOGGING_ENABLED) {
                PulseLogger.newPhase("Layout Pass");
            }
            Scene.this.doLayoutPass();
            if (Scene.this.postLayoutPulseListeners != null) {
                final Iterator<Runnable> iterator2 = Scene.this.postLayoutPulseListeners.iterator();
                while (iterator2.hasNext()) {
                    iterator2.next().run();
                }
            }
            if (Scene.this.dirtyNodes == null || Scene.this.dirtyNodesSize != 0 || !Scene.this.isDirtyEmpty()) {
                if (PulseLogger.PULSE_LOGGING_ENABLED) {
                    PulseLogger.newPhase("Update bounds");
                }
                Scene.this.getRoot().updateBounds();
                if (Scene.this.peer != null) {
                    try {
                        if (PulseLogger.PULSE_LOGGING_ENABLED) {
                            PulseLogger.newPhase("Waiting for previous rendering");
                        }
                        Scene.this.peer.waitForRenderingToComplete();
                        Scene.this.peer.waitForSynchronization();
                        if (PulseLogger.PULSE_LOGGING_ENABLED) {
                            PulseLogger.newPhase("Copy state to render graph");
                        }
                        Scene.this.syncLights();
                        this.synchronizeSceneProperties();
                        this.synchronizeSceneNodes();
                        Scene.this.mouseHandler.pulse();
                        Scene.this.peer.markDirty();
                    }
                    finally {
                        Scene.this.peer.releaseSynchronization(true);
                    }
                }
                else {
                    if (PulseLogger.PULSE_LOGGING_ENABLED) {
                        PulseLogger.newPhase("Synchronize with null peer");
                    }
                    this.synchronizeSceneNodes();
                    Scene.this.mouseHandler.pulse();
                }
                if (Scene.this.getRoot().cssFlag != CssFlags.CLEAN) {
                    NodeHelper.markDirty(Scene.this.getRoot(), com.sun.javafx.scene.DirtyBits.NODE_CSS);
                }
            }
            Scene.this.mouseHandler.updateCursorFrame();
            if (this.firstPulse) {
                if (PerformanceTracker.isLoggingEnabled()) {
                    PerformanceTracker.logEvent("Scene - first repaint - layout complete");
                    if (PrismSettings.perfLogFirstPaintFlush) {
                        PerformanceTracker.outputLog();
                    }
                    if (PrismSettings.perfLogFirstPaintExit) {
                        System.exit(0);
                    }
                }
                this.firstPulse = false;
            }
            if (Scene.this.testPulseListener != null) {
                Scene.this.testPulseListener.run();
            }
        }
    }
    
    class ScenePeerListener implements TKSceneListener
    {
        @Override
        public void changedLocation(final float n, final float n2) {
            if (n != Scene.this.getX()) {
                Scene.this.setX(n);
            }
            if (n2 != Scene.this.getY()) {
                Scene.this.setY(n2);
            }
        }
        
        @Override
        public void changedSize(final float n, final float n2) {
            if (n != Scene.this.getWidth()) {
                Scene.this.setWidth(n);
            }
            if (n2 != Scene.this.getHeight()) {
                Scene.this.setHeight(n2);
            }
        }
        
        @Override
        public void mouseEvent(final EventType<MouseEvent> eventType, final double n, final double n2, final double n3, final double n4, final MouseButton mouseButton, final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5, final boolean b6, final boolean b7, final boolean b8, final boolean b9) {
            Scene.this.processMouseEvent(new MouseEvent(eventType, n, n2, n3, n4, mouseButton, 0, b3, b4, b5, b6, b7, b8, b9, b2, b, false, null));
        }
        
        @Override
        public void keyEvent(final KeyEvent keyEvent) {
            Scene.this.processKeyEvent(keyEvent);
        }
        
        @Override
        public void inputMethodEvent(final EventType<InputMethodEvent> eventType, final ObservableList<InputMethodTextRun> list, final String s, final int n) {
            Scene.this.processInputMethodEvent(new InputMethodEvent(eventType, list, s, n));
        }
        
        @Override
        public void menuEvent(final double n, final double n2, final double n3, final double n4, final boolean b) {
            Scene.this.processMenuEvent(n, n2, n3, n4, b);
        }
        
        @Override
        public void scrollEvent(final EventType<ScrollEvent> eventType, final double n, final double n2, final double n3, final double n4, double n5, double n6, final int n7, final int n8, final int n9, final int n10, final int n11, double v, double v2, double v3, double v4, final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5, final boolean b6) {
            final ScrollEvent.HorizontalTextScrollUnits horizontalTextScrollUnits = (n8 > 0) ? ScrollEvent.HorizontalTextScrollUnits.CHARACTERS : ScrollEvent.HorizontalTextScrollUnits.NONE;
            final double n12 = (n8 < 0) ? 0.0 : (n8 * n);
            final ScrollEvent.VerticalTextScrollUnits verticalTextScrollUnits = (n9 > 0) ? ScrollEvent.VerticalTextScrollUnits.LINES : ((n9 < 0) ? ScrollEvent.VerticalTextScrollUnits.PAGES : ScrollEvent.VerticalTextScrollUnits.NONE);
            final double n13 = (n9 < 0) ? n2 : (n9 * n2);
            n5 = ((n10 > 0 && n8 >= 0) ? ((double)Math.round(n5 * n8 / n10)) : n5);
            n6 = ((n11 > 0 && n9 >= 0) ? ((double)Math.round(n6 * n9 / n11)) : n6);
            if (eventType == ScrollEvent.SCROLL_FINISHED) {
                v = Scene.this.scrollGesture.sceneCoords.getX();
                v2 = Scene.this.scrollGesture.sceneCoords.getY();
                v3 = Scene.this.scrollGesture.screenCoords.getX();
                v4 = Scene.this.scrollGesture.screenCoords.getY();
            }
            else if (Double.isNaN(v) || Double.isNaN(v2) || Double.isNaN(v3) || Double.isNaN(v4)) {
                if (Scene.this.cursorScenePos == null || Scene.this.cursorScreenPos == null) {
                    return;
                }
                v = Scene.this.cursorScenePos.getX();
                v2 = Scene.this.cursorScenePos.getY();
                v3 = Scene.this.cursorScreenPos.getX();
                v4 = Scene.this.cursorScreenPos.getY();
            }
            Scene.inMousePick = true;
            Scene.this.processGestureEvent(new ScrollEvent(eventType, v, v2, v3, v4, b, b2, b3, b4, b5, b6, n * n5, n2 * n6, n3 * n5, n4 * n6, n5, n6, horizontalTextScrollUnits, n12, verticalTextScrollUnits, n13, n7, Scene.this.pick(v, v2)), Scene.this.scrollGesture);
            Scene.inMousePick = false;
        }
        
        @Override
        public void zoomEvent(final EventType<ZoomEvent> eventType, final double n, final double n2, double v, double v2, double v3, double v4, final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5, final boolean b6) {
            if (eventType == ZoomEvent.ZOOM_FINISHED) {
                v = Scene.this.zoomGesture.sceneCoords.getX();
                v2 = Scene.this.zoomGesture.sceneCoords.getY();
                v3 = Scene.this.zoomGesture.screenCoords.getX();
                v4 = Scene.this.zoomGesture.screenCoords.getY();
            }
            else if (Double.isNaN(v) || Double.isNaN(v2) || Double.isNaN(v3) || Double.isNaN(v4)) {
                if (Scene.this.cursorScenePos == null || Scene.this.cursorScreenPos == null) {
                    return;
                }
                v = Scene.this.cursorScenePos.getX();
                v2 = Scene.this.cursorScenePos.getY();
                v3 = Scene.this.cursorScreenPos.getX();
                v4 = Scene.this.cursorScreenPos.getY();
            }
            Scene.inMousePick = true;
            Scene.this.processGestureEvent(new ZoomEvent(eventType, v, v2, v3, v4, b, b2, b3, b4, b5, b6, n, n2, Scene.this.pick(v, v2)), Scene.this.zoomGesture);
            Scene.inMousePick = false;
        }
        
        @Override
        public void rotateEvent(final EventType<RotateEvent> eventType, final double n, final double n2, double v, double v2, double v3, double v4, final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5, final boolean b6) {
            if (eventType == RotateEvent.ROTATION_FINISHED) {
                v = Scene.this.rotateGesture.sceneCoords.getX();
                v2 = Scene.this.rotateGesture.sceneCoords.getY();
                v3 = Scene.this.rotateGesture.screenCoords.getX();
                v4 = Scene.this.rotateGesture.screenCoords.getY();
            }
            else if (Double.isNaN(v) || Double.isNaN(v2) || Double.isNaN(v3) || Double.isNaN(v4)) {
                if (Scene.this.cursorScenePos == null || Scene.this.cursorScreenPos == null) {
                    return;
                }
                v = Scene.this.cursorScenePos.getX();
                v2 = Scene.this.cursorScenePos.getY();
                v3 = Scene.this.cursorScreenPos.getX();
                v4 = Scene.this.cursorScreenPos.getY();
            }
            Scene.inMousePick = true;
            Scene.this.processGestureEvent(new RotateEvent(eventType, v, v2, v3, v4, b, b2, b3, b4, b5, b6, n, n2, Scene.this.pick(v, v2)), Scene.this.rotateGesture);
            Scene.inMousePick = false;
        }
        
        @Override
        public void swipeEvent(final EventType<SwipeEvent> eventType, final int n, double x, double y, double x2, double y2, final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5) {
            if (Double.isNaN(x) || Double.isNaN(y) || Double.isNaN(x2) || Double.isNaN(y2)) {
                if (Scene.this.cursorScenePos == null || Scene.this.cursorScreenPos == null) {
                    return;
                }
                x = Scene.this.cursorScenePos.getX();
                y = Scene.this.cursorScenePos.getY();
                x2 = Scene.this.cursorScreenPos.getX();
                y2 = Scene.this.cursorScreenPos.getY();
            }
            Scene.inMousePick = true;
            Scene.this.processGestureEvent(new SwipeEvent(eventType, x, y, x2, y2, b, b2, b3, b4, b5, n, Scene.this.pick(x, y)), Scene.this.swipeGesture);
            Scene.inMousePick = false;
        }
        
        @Override
        public void touchEventBegin(final long n, final int n2, final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5) {
            if (!b) {
                Scene.this.nextTouchEvent = null;
                return;
            }
            Scene.this.nextTouchEvent = new TouchEvent(TouchEvent.ANY, null, null, 0, b2, b3, b4, b5);
            if (Scene.this.touchPoints == null || Scene.this.touchPoints.length != n2) {
                Scene.this.touchPoints = new TouchPoint[n2];
            }
            Scene.this.touchPointIndex = 0;
        }
        
        @Override
        public void touchEventNext(final TouchPoint.State state, final long n, final double n2, final double n3, final double n4, final double n5) {
            Scene.inMousePick = true;
            if (Scene.this.nextTouchEvent == null) {
                return;
            }
            Scene.this.touchPointIndex++;
            final int i = (state == TouchPoint.State.PRESSED) ? Scene.this.touchMap.add(n) : Scene.this.touchMap.get(n);
            if (state == TouchPoint.State.RELEASED) {
                Scene.this.touchMap.remove(n);
            }
            final int order = Scene.this.touchMap.getOrder(i);
            if (order >= Scene.this.touchPoints.length) {
                throw new RuntimeException("Too many touch points reported");
            }
            boolean b = false;
            final PickResult access$4900 = Scene.this.pick(n2, n3);
            EventTarget eventTarget = Scene.this.touchTargets.get(i);
            if (eventTarget == null) {
                eventTarget = access$4900.getIntersectedNode();
                if (eventTarget == null) {
                    eventTarget = Scene.this;
                }
            }
            else {
                b = true;
            }
            final TouchPoint touchPoint = new TouchPoint(i, state, n2, n3, n4, n5, eventTarget, access$4900);
            Scene.this.touchPoints[order] = touchPoint;
            if (b) {
                touchPoint.grab(eventTarget);
            }
            if (touchPoint.getState() == TouchPoint.State.PRESSED) {
                touchPoint.grab(eventTarget);
                Scene.this.touchTargets.put(touchPoint.getId(), eventTarget);
            }
            else if (touchPoint.getState() == TouchPoint.State.RELEASED) {
                Scene.this.touchTargets.remove(touchPoint.getId());
            }
            Scene.inMousePick = false;
        }
        
        @Override
        public void touchEventEnd() {
            if (Scene.this.nextTouchEvent == null) {
                return;
            }
            if (Scene.this.touchPointIndex != Scene.this.touchPoints.length) {
                throw new RuntimeException("Wrong number of touch points reported");
            }
            Scene.this.processTouchEvent(Scene.this.nextTouchEvent, Scene.this.touchPoints);
            if (Scene.this.touchMap.cleanup()) {
                Scene.this.touchEventSetId = 0;
            }
        }
        
        @Override
        public Accessible getSceneAccessible() {
            return Scene.this.getAccessible();
        }
    }
    
    private class ScenePeerPaintListener implements TKScenePaintListener
    {
        @Override
        public void frameRendered() {
            synchronized (Scene.trackerMonitor) {
                if (Scene.this.tracker != null) {
                    Scene.this.tracker.frameRendered();
                }
            }
        }
    }
    
    class DropTargetListener implements TKDropTargetListener
    {
        @Override
        public TransferMode dragEnter(final double n, final double n2, final double n3, final double n4, final TransferMode transferMode, final TKClipboard tkClipboard) {
            if (Scene.this.dndGesture == null) {
                Scene.this.dndGesture = new DnDGesture();
            }
            Scene.this.dndGesture.dragboard = DragboardHelper.createDragboard(tkClipboard);
            return Scene.this.dndGesture.processTargetEnterOver(new DragEvent(DragEvent.ANY, Scene.this.dndGesture.dragboard, n, n2, n3, n4, transferMode, null, null, Scene.this.pick(n, n2)));
        }
        
        @Override
        public TransferMode dragOver(final double n, final double n2, final double n3, final double n4, final TransferMode transferMode) {
            if (Scene.this.dndGesture == null) {
                System.err.println("GOT A dragOver when dndGesture is null!");
                return null;
            }
            if (Scene.this.dndGesture.dragboard == null) {
                throw new RuntimeException("dndGesture.dragboard is null in dragOver");
            }
            return Scene.this.dndGesture.processTargetEnterOver(new DragEvent(DragEvent.ANY, Scene.this.dndGesture.dragboard, n, n2, n3, n4, transferMode, null, null, Scene.this.pick(n, n2)));
        }
        
        @Override
        public void dragExit(final double n, final double n2, final double n3, final double n4) {
            if (Scene.this.dndGesture == null) {
                System.err.println("GOT A dragExit when dndGesture is null!");
            }
            else {
                if (Scene.this.dndGesture.dragboard == null) {
                    throw new RuntimeException("dndGesture.dragboard is null in dragExit");
                }
                Scene.this.dndGesture.processTargetExit(new DragEvent(DragEvent.ANY, Scene.this.dndGesture.dragboard, n, n2, n3, n4, null, null, null, Scene.this.pick(n, n2)));
                if (Scene.this.dndGesture.source == null) {
                    Scene.this.dndGesture.dragboard = null;
                    Scene.this.dndGesture = null;
                }
            }
        }
        
        @Override
        public TransferMode drop(final double n, final double n2, final double n3, final double n4, final TransferMode transferMode) {
            if (Scene.this.dndGesture == null) {
                System.err.println("GOT A drop when dndGesture is null!");
                return null;
            }
            if (Scene.this.dndGesture.dragboard == null) {
                throw new RuntimeException("dndGesture.dragboard is null in dragDrop");
            }
            final DragEvent dragEvent = new DragEvent(DragEvent.ANY, Scene.this.dndGesture.dragboard, n, n2, n3, n4, transferMode, null, null, Scene.this.pick(n, n2));
            DragboardHelper.setDataAccessRestriction(Scene.this.dndGesture.dragboard, false);
            TransferMode access$6500;
            try {
                access$6500 = Scene.this.dndGesture.processTargetDrop(dragEvent);
            }
            finally {
                DragboardHelper.setDataAccessRestriction(Scene.this.dndGesture.dragboard, true);
            }
            if (Scene.this.dndGesture.source == null) {
                Scene.this.dndGesture.dragboard = null;
                Scene.this.dndGesture = null;
            }
            return access$6500;
        }
    }
    
    class DragGestureListener implements TKDragGestureListener
    {
        @Override
        public void dragGestureRecognized(final double n, final double n2, final double n3, final double n4, final int n5, final TKClipboard tkClipboard) {
            final Dragboard dragboard = DragboardHelper.createDragboard(tkClipboard);
            (Scene.this.dndGesture = new DnDGesture()).dragboard = dragboard;
            Scene.this.dndGesture.processRecognized(new DragEvent(DragEvent.ANY, dragboard, n, n2, n3, n4, null, null, null, Scene.this.pick(n, n2)));
            Scene.this.dndGesture = null;
        }
    }
    
    class DnDGesture
    {
        private final double hysteresisSizeX;
        private final double hysteresisSizeY;
        private EventTarget source;
        private Set<TransferMode> sourceTransferModes;
        private TransferMode acceptedTransferMode;
        private Dragboard dragboard;
        private EventTarget potentialTarget;
        private EventTarget target;
        private DragDetectedState dragDetected;
        private double pressedX;
        private double pressedY;
        private List<EventTarget> currentTargets;
        private List<EventTarget> newTargets;
        private EventTarget fullPDRSource;
        
        DnDGesture() {
            this.hysteresisSizeX = Toolkit.getToolkit().getMultiClickMaxX();
            this.hysteresisSizeY = Toolkit.getToolkit().getMultiClickMaxY();
            this.source = null;
            this.sourceTransferModes = null;
            this.acceptedTransferMode = null;
            this.dragboard = null;
            this.potentialTarget = null;
            this.target = null;
            this.dragDetected = DragDetectedState.NOT_YET;
            this.currentTargets = new ArrayList<EventTarget>();
            this.newTargets = new ArrayList<EventTarget>();
            this.fullPDRSource = null;
        }
        
        private void fireEvent(final EventTarget eventTarget, final Event event) {
            if (eventTarget != null) {
                Event.fireEvent(eventTarget, event);
            }
        }
        
        private void processingDragDetected() {
            this.dragDetected = DragDetectedState.PROCESSING;
        }
        
        private void dragDetectedProcessed() {
            this.dragDetected = DragDetectedState.DONE;
            if (this.dragboard != null && ClipboardHelper.contentPut(this.dragboard)) {
                Toolkit.getToolkit().startDrag(Scene.this.peer, this.sourceTransferModes, new DragSourceListener(), this.dragboard);
            }
            else if (this.fullPDRSource != null) {
                Scene.this.mouseHandler.enterFullPDR(this.fullPDRSource);
            }
            this.fullPDRSource = null;
        }
        
        private void processDragDetection(final MouseEvent mouseEvent) {
            if (this.dragDetected != DragDetectedState.NOT_YET) {
                mouseEvent.setDragDetect(false);
                return;
            }
            if (mouseEvent.getEventType() == MouseEvent.MOUSE_PRESSED) {
                this.pressedX = mouseEvent.getSceneX();
                this.pressedY = mouseEvent.getSceneY();
                mouseEvent.setDragDetect(false);
            }
            else if (mouseEvent.getEventType() == MouseEvent.MOUSE_DRAGGED) {
                final double abs = Math.abs(mouseEvent.getSceneX() - this.pressedX);
                final double abs2 = Math.abs(mouseEvent.getSceneY() - this.pressedY);
                mouseEvent.setDragDetect(abs > this.hysteresisSizeX || abs2 > this.hysteresisSizeY);
            }
        }
        
        private boolean process(final MouseEvent mouseEvent, final EventTarget eventTarget) {
            boolean b = true;
            if (this.dragDetected != DragDetectedState.DONE && (mouseEvent.getEventType() == MouseEvent.MOUSE_PRESSED || mouseEvent.getEventType() == MouseEvent.MOUSE_DRAGGED) && mouseEvent.isDragDetect()) {
                this.processingDragDetected();
                if (eventTarget != null) {
                    final MouseEvent copy = mouseEvent.copyFor(mouseEvent.getSource(), eventTarget, MouseEvent.DRAG_DETECTED);
                    try {
                        this.fireEvent(eventTarget, copy);
                    }
                    finally {
                        if (this.dragboard != null) {
                            DragboardHelper.setDataAccessRestriction(this.dragboard, true);
                        }
                    }
                }
                this.dragDetectedProcessed();
            }
            if (mouseEvent.getEventType() == MouseEvent.MOUSE_RELEASED) {
                b = false;
            }
            return b;
        }
        
        private boolean processRecognized(final DragEvent dragEvent) {
            final MouseEvent mouseEvent = new MouseEvent(MouseEvent.DRAG_DETECTED, dragEvent.getX(), dragEvent.getY(), dragEvent.getSceneX(), dragEvent.getScreenY(), MouseButton.PRIMARY, 1, false, false, false, false, false, true, false, false, false, false, dragEvent.getPickResult());
            this.processingDragDetected();
            final Node intersectedNode = dragEvent.getPickResult().getIntersectedNode();
            try {
                this.fireEvent((intersectedNode != null) ? intersectedNode : Scene.this, mouseEvent);
            }
            finally {
                if (this.dragboard != null) {
                    DragboardHelper.setDataAccessRestriction(this.dragboard, true);
                }
            }
            this.dragDetectedProcessed();
            return this.dragboard != null && !this.dragboard.getContentTypes().isEmpty();
        }
        
        private void processDropEnd(DragEvent dragEvent) {
            if (this.source == null) {
                System.out.println("Scene.DnDGesture.processDropEnd() - UNEXPECTD - source is NULL");
                return;
            }
            dragEvent = new DragEvent(dragEvent.getSource(), this.source, DragEvent.DRAG_DONE, dragEvent.getDragboard(), dragEvent.getSceneX(), dragEvent.getSceneY(), dragEvent.getScreenX(), dragEvent.getScreenY(), dragEvent.getTransferMode(), this.source, this.target, dragEvent.getPickResult());
            Event.fireEvent(this.source, dragEvent);
            Scene.this.tmpTargetWrapper.clear();
            this.handleExitEnter(dragEvent, Scene.this.tmpTargetWrapper);
            Toolkit.getToolkit().stopDrag(this.dragboard);
        }
        
        private TransferMode processTargetEnterOver(DragEvent dragEvent) {
            Scene.this.pick(Scene.this.tmpTargetWrapper, dragEvent.getSceneX(), dragEvent.getSceneY());
            final EventTarget eventTarget = Scene.this.tmpTargetWrapper.getEventTarget();
            if (this.dragboard == null) {
                this.dragboard = this.createDragboard(dragEvent, false);
            }
            dragEvent = new DragEvent(dragEvent.getSource(), eventTarget, dragEvent.getEventType(), this.dragboard, dragEvent.getSceneX(), dragEvent.getSceneY(), dragEvent.getScreenX(), dragEvent.getScreenY(), dragEvent.getTransferMode(), this.source, this.potentialTarget, dragEvent.getPickResult());
            this.handleExitEnter(dragEvent, Scene.this.tmpTargetWrapper);
            dragEvent = new DragEvent(dragEvent.getSource(), eventTarget, DragEvent.DRAG_OVER, dragEvent.getDragboard(), dragEvent.getSceneX(), dragEvent.getSceneY(), dragEvent.getScreenX(), dragEvent.getScreenY(), dragEvent.getTransferMode(), this.source, this.potentialTarget, dragEvent.getPickResult());
            this.fireEvent(eventTarget, dragEvent);
            final Object acceptingObject = dragEvent.getAcceptingObject();
            this.potentialTarget = ((acceptingObject instanceof EventTarget) ? ((EventTarget)acceptingObject) : null);
            return this.acceptedTransferMode = dragEvent.getAcceptedTransferMode();
        }
        
        private void processTargetActionChanged(final DragEvent dragEvent) {
        }
        
        private void processTargetExit(final DragEvent dragEvent) {
            if (this.dragboard == null) {
                throw new NullPointerException("dragboard is null in processTargetExit()");
            }
            if (this.currentTargets.size() > 0) {
                this.potentialTarget = null;
                Scene.this.tmpTargetWrapper.clear();
                this.handleExitEnter(dragEvent, Scene.this.tmpTargetWrapper);
            }
        }
        
        private TransferMode processTargetDrop(DragEvent dragEvent) {
            Scene.this.pick(Scene.this.tmpTargetWrapper, dragEvent.getSceneX(), dragEvent.getSceneY());
            final EventTarget eventTarget = Scene.this.tmpTargetWrapper.getEventTarget();
            dragEvent = new DragEvent(dragEvent.getSource(), eventTarget, DragEvent.DRAG_DROPPED, dragEvent.getDragboard(), dragEvent.getSceneX(), dragEvent.getSceneY(), dragEvent.getScreenX(), dragEvent.getScreenY(), this.acceptedTransferMode, this.source, this.potentialTarget, dragEvent.getPickResult());
            if (this.dragboard == null) {
                throw new NullPointerException("dragboard is null in processTargetDrop()");
            }
            this.handleExitEnter(dragEvent, Scene.this.tmpTargetWrapper);
            this.fireEvent(eventTarget, dragEvent);
            final Object acceptingObject = dragEvent.getAcceptingObject();
            this.potentialTarget = ((acceptingObject instanceof EventTarget) ? ((EventTarget)acceptingObject) : null);
            this.target = this.potentialTarget;
            final TransferMode transferMode = dragEvent.isDropCompleted() ? dragEvent.getAcceptedTransferMode() : null;
            Scene.this.tmpTargetWrapper.clear();
            this.handleExitEnter(dragEvent, Scene.this.tmpTargetWrapper);
            return transferMode;
        }
        
        private void handleExitEnter(DragEvent dragEvent, final TargetWrapper targetWrapper) {
            if (targetWrapper.getEventTarget() != ((this.currentTargets.size() > 0) ? this.currentTargets.get(0) : null)) {
                targetWrapper.fillHierarchy(this.newTargets);
                int i;
                int j;
                for (i = this.currentTargets.size() - 1, j = this.newTargets.size() - 1; i >= 0 && j >= 0 && this.currentTargets.get(i) == this.newTargets.get(j); --i, --j) {}
                while (i >= 0) {
                    final EventTarget eventTarget = this.currentTargets.get(i);
                    if (this.potentialTarget == eventTarget) {
                        this.potentialTarget = null;
                    }
                    dragEvent = dragEvent.copyFor(dragEvent.getSource(), eventTarget, this.source, this.potentialTarget, DragEvent.DRAG_EXITED_TARGET);
                    Event.fireEvent(eventTarget, dragEvent);
                    --i;
                }
                this.potentialTarget = null;
                while (j >= 0) {
                    final EventTarget eventTarget2 = this.newTargets.get(j);
                    dragEvent = dragEvent.copyFor(dragEvent.getSource(), eventTarget2, this.source, this.potentialTarget, DragEvent.DRAG_ENTERED_TARGET);
                    final Object acceptingObject = dragEvent.getAcceptingObject();
                    if (acceptingObject instanceof EventTarget) {
                        this.potentialTarget = (EventTarget)acceptingObject;
                    }
                    Event.fireEvent(eventTarget2, dragEvent);
                    --j;
                }
                this.currentTargets.clear();
                this.currentTargets.addAll(this.newTargets);
                this.newTargets.clear();
            }
        }
        
        private boolean processKey(final KeyEvent keyEvent) {
            if (keyEvent.getEventType() == KeyEvent.KEY_PRESSED && keyEvent.getCode() == KeyCode.ESCAPE) {
                final DragEvent dragEvent = new DragEvent(this.source, this.source, DragEvent.DRAG_DONE, this.dragboard, 0.0, 0.0, 0.0, 0.0, null, this.source, null, null);
                if (this.source != null) {
                    Event.fireEvent(this.source, dragEvent);
                }
                Scene.this.tmpTargetWrapper.clear();
                this.handleExitEnter(dragEvent, Scene.this.tmpTargetWrapper);
                return false;
            }
            return true;
        }
        
        private Dragboard startDrag(final EventTarget eventTarget, final Set<TransferMode> sourceTransferModes) {
            if (this.dragDetected != DragDetectedState.PROCESSING) {
                throw new IllegalStateException("Cannot start drag and drop outside of DRAG_DETECTED event handler");
            }
            if (sourceTransferModes.isEmpty()) {
                this.dragboard = null;
            }
            else if (this.dragboard == null) {
                this.dragboard = this.createDragboard(null, true);
            }
            DragboardHelper.setDataAccessRestriction(this.dragboard, false);
            this.source = eventTarget;
            this.potentialTarget = eventTarget;
            this.sourceTransferModes = sourceTransferModes;
            return this.dragboard;
        }
        
        private void startFullPDR(final EventTarget fullPDRSource) {
            this.fullPDRSource = fullPDRSource;
        }
        
        private Dragboard createDragboard(final DragEvent dragEvent, final boolean b) {
            if (dragEvent != null) {
                final Dragboard dragboard = dragEvent.getDragboard();
                if (dragboard != null) {
                    return dragboard;
                }
            }
            return DragboardHelper.createDragboard(Scene.this.peer.createDragboard(b));
        }
    }
    
    private enum DragDetectedState
    {
        NOT_YET, 
        PROCESSING, 
        DONE;
    }
    
    class DragSourceListener implements TKDragSourceListener
    {
        @Override
        public void dragDropEnd(final double n, final double n2, final double n3, final double n4, final TransferMode transferMode) {
            if (Scene.this.dndGesture != null) {
                if (Scene.this.dndGesture.dragboard == null) {
                    throw new RuntimeException("dndGesture.dragboard is null in dragDropEnd");
                }
                final DragEvent dragEvent = new DragEvent(DragEvent.ANY, Scene.this.dndGesture.dragboard, n, n2, n3, n4, transferMode, null, null, null);
                DragboardHelper.setDataAccessRestriction(Scene.this.dndGesture.dragboard, false);
                try {
                    Scene.this.dndGesture.processDropEnd(dragEvent);
                }
                finally {
                    DragboardHelper.setDataAccessRestriction(Scene.this.dndGesture.dragboard, true);
                }
                Scene.this.dndGesture = null;
            }
        }
    }
    
    static class ClickCounter
    {
        Toolkit toolkit;
        private int count;
        private boolean out;
        private boolean still;
        private Timeline timeout;
        private double pressedX;
        private double pressedY;
        
        ClickCounter() {
            this.toolkit = Toolkit.getToolkit();
        }
        
        private void inc() {
            ++this.count;
        }
        
        private int get() {
            return this.count;
        }
        
        private boolean isStill() {
            return this.still;
        }
        
        private void clear() {
            this.count = 0;
            this.stopTimeout();
        }
        
        private void out() {
            this.out = true;
            this.stopTimeout();
        }
        
        private void applyOut() {
            if (this.out) {
                this.clear();
            }
            this.out = false;
        }
        
        private void moved(final double n, final double n2) {
            if (Math.abs(n - this.pressedX) > this.toolkit.getMultiClickMaxX() || Math.abs(n2 - this.pressedY) > this.toolkit.getMultiClickMaxY()) {
                this.out();
                this.still = false;
            }
        }
        
        private void start(final double pressedX, final double pressedY) {
            this.pressedX = pressedX;
            this.pressedY = pressedY;
            this.out = false;
            if (this.timeout != null) {
                this.timeout.stop();
            }
            this.timeout = new Timeline();
            this.timeout.getKeyFrames().add(new KeyFrame(new Duration((double)this.toolkit.getMultiClickTime()), p0 -> {
                this.out = true;
                this.timeout = null;
                return;
            }, new KeyValue[0]));
            this.timeout.play();
            this.still = true;
        }
        
        private void stopTimeout() {
            if (this.timeout != null) {
                this.timeout.stop();
                this.timeout = null;
            }
        }
    }
    
    static class ClickGenerator
    {
        private ClickCounter lastPress;
        private Map<MouseButton, ClickCounter> counters;
        private List<EventTarget> pressedTargets;
        private List<EventTarget> releasedTargets;
        
        public ClickGenerator() {
            this.lastPress = null;
            this.counters = new EnumMap<MouseButton, ClickCounter>(MouseButton.class);
            this.pressedTargets = new ArrayList<EventTarget>();
            this.releasedTargets = new ArrayList<EventTarget>();
            for (final MouseButton mouseButton : MouseButton.values()) {
                if (mouseButton != MouseButton.NONE) {
                    this.counters.put(mouseButton, new ClickCounter());
                }
            }
        }
        
        private MouseEvent preProcess(final MouseEvent mouseEvent) {
            final Iterator<ClickCounter> iterator = this.counters.values().iterator();
            while (iterator.hasNext()) {
                iterator.next().moved(mouseEvent.getSceneX(), mouseEvent.getSceneY());
            }
            final ClickCounter lastPress = this.counters.get(mouseEvent.getButton());
            final boolean b = this.lastPress != null && this.lastPress.isStill();
            if (mouseEvent.getEventType() == MouseEvent.MOUSE_PRESSED) {
                if (!mouseEvent.isPrimaryButtonDown()) {
                    this.counters.get(MouseButton.PRIMARY).clear();
                }
                if (!mouseEvent.isSecondaryButtonDown()) {
                    this.counters.get(MouseButton.SECONDARY).clear();
                }
                if (!mouseEvent.isMiddleButtonDown()) {
                    this.counters.get(MouseButton.MIDDLE).clear();
                }
                lastPress.applyOut();
                lastPress.inc();
                lastPress.start(mouseEvent.getSceneX(), mouseEvent.getSceneY());
                this.lastPress = lastPress;
            }
            return new MouseEvent(mouseEvent.getEventType(), mouseEvent.getSceneX(), mouseEvent.getSceneY(), mouseEvent.getScreenX(), mouseEvent.getScreenY(), mouseEvent.getButton(), (lastPress != null && mouseEvent.getEventType() != MouseEvent.MOUSE_MOVED) ? lastPress.get() : 0, mouseEvent.isShiftDown(), mouseEvent.isControlDown(), mouseEvent.isAltDown(), mouseEvent.isMetaDown(), mouseEvent.isPrimaryButtonDown(), mouseEvent.isMiddleButtonDown(), mouseEvent.isSecondaryButtonDown(), mouseEvent.isSynthesized(), mouseEvent.isPopupTrigger(), b, mouseEvent.getPickResult());
        }
        
        private void postProcess(final MouseEvent mouseEvent, final TargetWrapper targetWrapper, final TargetWrapper targetWrapper2) {
            if (mouseEvent.getEventType() == MouseEvent.MOUSE_RELEASED) {
                final ClickCounter clickCounter = this.counters.get(mouseEvent.getButton());
                targetWrapper.fillHierarchy(this.pressedTargets);
                targetWrapper2.fillHierarchy(this.releasedTargets);
                int n = this.pressedTargets.size() - 1;
                int n2 = this.releasedTargets.size() - 1;
                EventTarget eventTarget = null;
                while (n >= 0 && n2 >= 0 && this.pressedTargets.get(n) == this.releasedTargets.get(n2)) {
                    eventTarget = this.pressedTargets.get(n);
                    --n;
                    --n2;
                }
                this.pressedTargets.clear();
                this.releasedTargets.clear();
                if (eventTarget != null && this.lastPress != null) {
                    Event.fireEvent(eventTarget, new MouseEvent(null, eventTarget, MouseEvent.MOUSE_CLICKED, mouseEvent.getSceneX(), mouseEvent.getSceneY(), mouseEvent.getScreenX(), mouseEvent.getScreenY(), mouseEvent.getButton(), clickCounter.get(), mouseEvent.isShiftDown(), mouseEvent.isControlDown(), mouseEvent.isAltDown(), mouseEvent.isMetaDown(), mouseEvent.isPrimaryButtonDown(), mouseEvent.isMiddleButtonDown(), mouseEvent.isSecondaryButtonDown(), mouseEvent.isSynthesized(), mouseEvent.isPopupTrigger(), this.lastPress.isStill(), mouseEvent.getPickResult()));
                }
            }
        }
    }
    
    class MouseHandler
    {
        private TargetWrapper pdrEventTarget;
        private boolean pdrInProgress;
        private boolean fullPDREntered;
        private EventTarget currentEventTarget;
        private MouseEvent lastEvent;
        private boolean hover;
        private boolean primaryButtonDown;
        private boolean secondaryButtonDown;
        private boolean middleButtonDown;
        private EventTarget fullPDRSource;
        private TargetWrapper fullPDRTmpTargetWrapper;
        private final List<EventTarget> pdrEventTargets;
        private final List<EventTarget> currentEventTargets;
        private final List<EventTarget> newEventTargets;
        private final List<EventTarget> fullPDRCurrentEventTargets;
        private final List<EventTarget> fullPDRNewEventTargets;
        private EventTarget fullPDRCurrentTarget;
        private Cursor currCursor;
        private CursorFrame currCursorFrame;
        private EventQueue queue;
        private Runnable pickProcess;
        
        MouseHandler() {
            this.pdrEventTarget = new TargetWrapper();
            this.pdrInProgress = false;
            this.fullPDREntered = false;
            this.currentEventTarget = null;
            this.hover = false;
            this.primaryButtonDown = false;
            this.secondaryButtonDown = false;
            this.middleButtonDown = false;
            this.fullPDRSource = null;
            this.fullPDRTmpTargetWrapper = new TargetWrapper();
            this.pdrEventTargets = new ArrayList<EventTarget>();
            this.currentEventTargets = new ArrayList<EventTarget>();
            this.newEventTargets = new ArrayList<EventTarget>();
            this.fullPDRCurrentEventTargets = new ArrayList<EventTarget>();
            this.fullPDRNewEventTargets = new ArrayList<EventTarget>();
            this.fullPDRCurrentTarget = null;
            this.queue = new EventQueue();
            this.pickProcess = new Runnable() {
                @Override
                public void run() {
                    if (Scene.this.peer != null && MouseHandler.this.lastEvent != null) {
                        MouseHandler.this.process(MouseHandler.this.lastEvent, true);
                    }
                }
            };
        }
        
        private void pulse() {
            if (this.hover && this.lastEvent != null) {
                Platform.runLater(this.pickProcess);
            }
        }
        
        private void clearPDREventTargets() {
            this.pdrInProgress = false;
            this.currentEventTarget = ((this.currentEventTargets.size() > 0) ? this.currentEventTargets.get(0) : null);
            this.pdrEventTarget.clear();
        }
        
        public void enterFullPDR(final EventTarget fullPDRSource) {
            this.fullPDREntered = true;
            this.fullPDRSource = fullPDRSource;
            this.fullPDRCurrentTarget = null;
            this.fullPDRCurrentEventTargets.clear();
        }
        
        public void exitFullPDR(final MouseEvent mouseEvent) {
            if (!this.fullPDREntered) {
                return;
            }
            this.fullPDREntered = false;
            for (int i = this.fullPDRCurrentEventTargets.size() - 1; i >= 0; --i) {
                final EventTarget eventTarget = this.fullPDRCurrentEventTargets.get(i);
                Event.fireEvent(eventTarget, MouseEvent.copyForMouseDragEvent(mouseEvent, eventTarget, eventTarget, MouseDragEvent.MOUSE_DRAG_EXITED_TARGET, this.fullPDRSource, mouseEvent.getPickResult()));
            }
            this.fullPDRSource = null;
            this.fullPDRCurrentEventTargets.clear();
            this.fullPDRCurrentTarget = null;
        }
        
        private void handleNodeRemoval(final Node node) {
            if (this.lastEvent == null) {
                return;
            }
            if (this.currentEventTargets.contains(node)) {
                int n = 0;
                EventTarget eventTarget = null;
                while (eventTarget != node) {
                    eventTarget = this.currentEventTargets.get(n++);
                    this.queue.postEvent(this.lastEvent.copyFor(eventTarget, eventTarget, MouseEvent.MOUSE_EXITED_TARGET));
                }
                this.currentEventTargets.subList(0, n).clear();
            }
            if (this.fullPDREntered && this.fullPDRCurrentEventTargets.contains(node)) {
                int n2 = 0;
                EventTarget eventTarget2 = null;
                while (eventTarget2 != node) {
                    eventTarget2 = this.fullPDRCurrentEventTargets.get(n2++);
                    this.queue.postEvent(MouseEvent.copyForMouseDragEvent(this.lastEvent, eventTarget2, eventTarget2, MouseDragEvent.MOUSE_DRAG_EXITED_TARGET, this.fullPDRSource, this.lastEvent.getPickResult()));
                }
                this.fullPDRCurrentEventTargets.subList(0, n2).clear();
            }
            this.queue.fire();
            if (this.pdrInProgress && this.pdrEventTargets.contains(node)) {
                int n3 = 0;
                EventTarget eventTarget3 = null;
                while (eventTarget3 != node) {
                    eventTarget3 = this.pdrEventTargets.get(n3++);
                    ((Node)eventTarget3).setPressed(false);
                }
                this.pdrEventTargets.subList(0, n3).clear();
                final EventTarget eventTarget4 = this.pdrEventTargets.get(0);
                final PickResult result = this.pdrEventTarget.getResult();
                if (eventTarget4 instanceof Node) {
                    this.pdrEventTarget.setNodeResult(new PickResult((Node)eventTarget4, result.getIntersectedPoint(), result.getIntersectedDistance()));
                }
                else {
                    this.pdrEventTarget.setSceneResult(new PickResult(null, result.getIntersectedPoint(), result.getIntersectedDistance()), (Scene)eventTarget4);
                }
            }
        }
        
        private void handleEnterExit(final MouseEvent mouseEvent, final TargetWrapper targetWrapper) {
            if (targetWrapper.getEventTarget() != this.currentEventTarget || mouseEvent.getEventType() == MouseEvent.MOUSE_EXITED) {
                if (mouseEvent.getEventType() == MouseEvent.MOUSE_EXITED) {
                    this.newEventTargets.clear();
                }
                else {
                    targetWrapper.fillHierarchy(this.newEventTargets);
                }
                final int size = this.newEventTargets.size();
                int i;
                int j;
                int n;
                for (i = this.currentEventTargets.size() - 1, j = size - 1, n = this.pdrEventTargets.size() - 1; i >= 0 && j >= 0 && this.currentEventTargets.get(i) == this.newEventTargets.get(j); --i, --j, --n) {}
                final int n2 = n;
                while (i >= 0) {
                    final EventTarget eventTarget = this.currentEventTargets.get(i);
                    if (this.pdrInProgress) {
                        if (n < 0) {
                            break;
                        }
                        if (eventTarget != this.pdrEventTargets.get(n)) {
                            break;
                        }
                    }
                    this.queue.postEvent(mouseEvent.copyFor(eventTarget, eventTarget, MouseEvent.MOUSE_EXITED_TARGET));
                    --i;
                    --n;
                }
                for (int n3 = n2; j >= 0; --j, --n3) {
                    final EventTarget eventTarget2 = this.newEventTargets.get(j);
                    if (this.pdrInProgress) {
                        if (n3 < 0) {
                            break;
                        }
                        if (eventTarget2 != this.pdrEventTargets.get(n3)) {
                            break;
                        }
                    }
                    this.queue.postEvent(mouseEvent.copyFor(eventTarget2, eventTarget2, MouseEvent.MOUSE_ENTERED_TARGET));
                }
                this.currentEventTarget = targetWrapper.getEventTarget();
                this.currentEventTargets.clear();
                ++j;
                while (j < size) {
                    this.currentEventTargets.add(this.newEventTargets.get(j));
                    ++j;
                }
            }
            this.queue.fire();
        }
        
        private void process(MouseEvent access$8000, final boolean b) {
            Toolkit.getToolkit().checkFxUserThread();
            Scene.inMousePick = true;
            Scene.this.cursorScreenPos = new Point2D(access$8000.getScreenX(), access$8000.getScreenY());
            Scene.this.cursorScenePos = new Point2D(access$8000.getSceneX(), access$8000.getSceneY());
            boolean b2 = false;
            if (!b) {
                if (access$8000.getEventType() == MouseEvent.MOUSE_PRESSED) {
                    if (!this.primaryButtonDown && !this.secondaryButtonDown && !this.middleButtonDown) {
                        b2 = true;
                        Scene.this.dndGesture = new DnDGesture();
                        this.clearPDREventTargets();
                    }
                }
                else if (access$8000.getEventType() == MouseEvent.MOUSE_MOVED) {
                    this.clearPDREventTargets();
                }
                else if (access$8000.getEventType() == MouseEvent.MOUSE_ENTERED) {
                    this.hover = true;
                }
                else if (access$8000.getEventType() == MouseEvent.MOUSE_EXITED) {
                    this.hover = false;
                }
                this.primaryButtonDown = access$8000.isPrimaryButtonDown();
                this.secondaryButtonDown = access$8000.isSecondaryButtonDown();
                this.middleButtonDown = access$8000.isMiddleButtonDown();
            }
            Scene.this.pick(Scene.this.tmpTargetWrapper, access$8000.getSceneX(), access$8000.getSceneY());
            final PickResult result = Scene.this.tmpTargetWrapper.getResult();
            if (result != null) {
                access$8000 = new MouseEvent(access$8000.getEventType(), access$8000.getSceneX(), access$8000.getSceneY(), access$8000.getScreenX(), access$8000.getScreenY(), access$8000.getButton(), access$8000.getClickCount(), access$8000.isShiftDown(), access$8000.isControlDown(), access$8000.isAltDown(), access$8000.isMetaDown(), access$8000.isPrimaryButtonDown(), access$8000.isMiddleButtonDown(), access$8000.isSecondaryButtonDown(), access$8000.isSynthesized(), access$8000.isPopupTrigger(), access$8000.isStillSincePress(), result);
            }
            if (access$8000.getEventType() == MouseEvent.MOUSE_EXITED) {
                Scene.this.tmpTargetWrapper.clear();
            }
            TargetWrapper targetWrapper;
            if (this.pdrInProgress) {
                targetWrapper = this.pdrEventTarget;
            }
            else {
                targetWrapper = Scene.this.tmpTargetWrapper;
            }
            if (b2) {
                this.pdrEventTarget.copy(targetWrapper);
                this.pdrEventTarget.fillHierarchy(this.pdrEventTargets);
            }
            if (!b) {
                access$8000 = Scene.this.clickGenerator.preProcess(access$8000);
            }
            this.handleEnterExit(access$8000, Scene.this.tmpTargetWrapper);
            if (Scene.this.dndGesture != null) {
                Scene.this.dndGesture.processDragDetection(access$8000);
            }
            if (this.fullPDREntered && access$8000.getEventType() == MouseEvent.MOUSE_RELEASED) {
                this.processFullPDR(access$8000, b);
            }
            if (targetWrapper.getEventTarget() != null && access$8000.getEventType() != MouseEvent.MOUSE_ENTERED && access$8000.getEventType() != MouseEvent.MOUSE_EXITED && !b) {
                Event.fireEvent(targetWrapper.getEventTarget(), access$8000);
            }
            if (this.fullPDREntered && access$8000.getEventType() != MouseEvent.MOUSE_RELEASED) {
                this.processFullPDR(access$8000, b);
            }
            if (!b) {
                Scene.this.clickGenerator.postProcess(access$8000, targetWrapper, Scene.this.tmpTargetWrapper);
            }
            if (!b && Scene.this.dndGesture != null && !Scene.this.dndGesture.process(access$8000, targetWrapper.getEventTarget())) {
                Scene.this.dndGesture = null;
            }
            Cursor cursor = targetWrapper.getCursor();
            if (access$8000.getEventType() != MouseEvent.MOUSE_EXITED) {
                if (cursor == null && this.hover) {
                    cursor = Scene.this.getCursor();
                }
                this.updateCursor(cursor);
                this.updateCursorFrame();
            }
            if (b2) {
                this.pdrInProgress = true;
            }
            if (this.pdrInProgress && !this.primaryButtonDown && !this.secondaryButtonDown && !this.middleButtonDown) {
                this.clearPDREventTargets();
                this.exitFullPDR(access$8000);
                Scene.this.pick(Scene.this.tmpTargetWrapper, access$8000.getSceneX(), access$8000.getSceneY());
                this.handleEnterExit(access$8000, Scene.this.tmpTargetWrapper);
            }
            this.lastEvent = ((access$8000.getEventType() == MouseEvent.MOUSE_EXITED) ? null : access$8000);
            Scene.inMousePick = false;
        }
        
        private void processFullPDR(final MouseEvent mouseEvent, final boolean b) {
            Scene.this.pick(this.fullPDRTmpTargetWrapper, mouseEvent.getSceneX(), mouseEvent.getSceneY());
            final PickResult result = this.fullPDRTmpTargetWrapper.getResult();
            final EventTarget eventTarget = this.fullPDRTmpTargetWrapper.getEventTarget();
            if (eventTarget != this.fullPDRCurrentTarget) {
                this.fullPDRTmpTargetWrapper.fillHierarchy(this.fullPDRNewEventTargets);
                final int size = this.fullPDRNewEventTargets.size();
                int i;
                int j;
                for (i = this.fullPDRCurrentEventTargets.size() - 1, j = size - 1; i >= 0 && j >= 0 && this.fullPDRCurrentEventTargets.get(i) == this.fullPDRNewEventTargets.get(j); --i, --j) {}
                while (i >= 0) {
                    final EventTarget eventTarget2 = this.fullPDRCurrentEventTargets.get(i);
                    Event.fireEvent(eventTarget2, MouseEvent.copyForMouseDragEvent(mouseEvent, eventTarget2, eventTarget2, MouseDragEvent.MOUSE_DRAG_EXITED_TARGET, this.fullPDRSource, result));
                    --i;
                }
                while (j >= 0) {
                    final EventTarget eventTarget3 = this.fullPDRNewEventTargets.get(j);
                    Event.fireEvent(eventTarget3, MouseEvent.copyForMouseDragEvent(mouseEvent, eventTarget3, eventTarget3, MouseDragEvent.MOUSE_DRAG_ENTERED_TARGET, this.fullPDRSource, result));
                    --j;
                }
                this.fullPDRCurrentTarget = eventTarget;
                this.fullPDRCurrentEventTargets.clear();
                this.fullPDRCurrentEventTargets.addAll(this.fullPDRNewEventTargets);
                this.fullPDRNewEventTargets.clear();
            }
            if (eventTarget != null && !b) {
                if (mouseEvent.getEventType() == MouseEvent.MOUSE_DRAGGED) {
                    Event.fireEvent(eventTarget, MouseEvent.copyForMouseDragEvent(mouseEvent, eventTarget, eventTarget, MouseDragEvent.MOUSE_DRAG_OVER, this.fullPDRSource, result));
                }
                if (mouseEvent.getEventType() == MouseEvent.MOUSE_RELEASED) {
                    Event.fireEvent(eventTarget, MouseEvent.copyForMouseDragEvent(mouseEvent, eventTarget, eventTarget, MouseDragEvent.MOUSE_DRAG_RELEASED, this.fullPDRSource, result));
                }
            }
        }
        
        private void updateCursor(final Cursor currCursor) {
            if (this.currCursor != currCursor) {
                if (this.currCursor != null) {
                    this.currCursor.deactivate();
                }
                if (currCursor != null) {
                    currCursor.activate();
                }
                this.currCursor = currCursor;
            }
        }
        
        public void updateCursorFrame() {
            final CursorFrame cursorFrame = (this.currCursor != null) ? this.currCursor.getCurrentFrame() : Cursor.DEFAULT.getCurrentFrame();
            if (this.currCursorFrame != cursorFrame) {
                if (Scene.this.peer != null) {
                    Scene.this.peer.setCursor(cursorFrame);
                }
                this.currCursorFrame = cursorFrame;
            }
        }
        
        private PickResult pickNode(final PickRay pickRay) {
            final PickResultChooser pickResultChooser = new PickResultChooser();
            Scene.this.getRoot().pickNode(pickRay, pickResultChooser);
            return pickResultChooser.toPickResult();
        }
    }
    
    class KeyHandler
    {
        private boolean windowFocused;
        private final InvalidationListener sceneWindowFocusedListener;
        
        KeyHandler() {
            this.sceneWindowFocusedListener = (readOnlyBooleanProperty -> this.setWindowFocused(readOnlyBooleanProperty.get()));
        }
        
        private void setFocusOwner(final Node node) {
            if (Scene.this.oldFocusOwner != null) {
                final Scene scene = Scene.this.oldFocusOwner.getScene();
                if (scene != null) {
                    final TKScene peer = scene.getPeer();
                    if (peer != null) {
                        peer.finishInputMethodComposition();
                    }
                }
            }
            Scene.this.focusOwner.set(node);
        }
        
        protected boolean isWindowFocused() {
            return this.windowFocused;
        }
        
        protected void setWindowFocused(final boolean windowFocused) {
            this.windowFocused = windowFocused;
            if (Scene.this.getFocusOwner() != null) {
                Scene.this.getFocusOwner().setFocused(this.windowFocused);
            }
            if (this.windowFocused && Scene.this.accessible != null) {
                Scene.this.accessible.sendNotification(AccessibleAttribute.FOCUS_NODE);
            }
        }
        
        private void windowForSceneChanged(final Window window, final Window window2) {
            if (window != null) {
                window.focusedProperty().removeListener(this.sceneWindowFocusedListener);
            }
            if (window2 != null) {
                window2.focusedProperty().addListener(this.sceneWindowFocusedListener);
                this.setWindowFocused(window2.isFocused());
            }
            else {
                this.setWindowFocused(false);
            }
        }
        
        private void process(final KeyEvent keyEvent) {
            final Node focusOwner = Scene.this.getFocusOwner();
            Event.fireEvent((focusOwner != null && focusOwner.getScene() == Scene.this) ? focusOwner : Scene.this, keyEvent);
        }
        
        private void requestFocus(final Node focusOwner) {
            if (Scene.this.getFocusOwner() == focusOwner || (focusOwner != null && !focusOwner.isCanReceiveFocus())) {
                return;
            }
            this.setFocusOwner(focusOwner);
        }
    }
    
    class InputMethodRequestsDelegate implements ExtendedInputMethodRequests
    {
        @Override
        public Point2D getTextLocation(final int n) {
            final InputMethodRequests clientRequests = this.getClientRequests();
            if (clientRequests != null) {
                return clientRequests.getTextLocation(n);
            }
            return new Point2D(0.0, 0.0);
        }
        
        @Override
        public int getLocationOffset(final int n, final int n2) {
            final InputMethodRequests clientRequests = this.getClientRequests();
            if (clientRequests != null) {
                return clientRequests.getLocationOffset(n, n2);
            }
            return 0;
        }
        
        @Override
        public void cancelLatestCommittedText() {
            final InputMethodRequests clientRequests = this.getClientRequests();
            if (clientRequests != null) {
                clientRequests.cancelLatestCommittedText();
            }
        }
        
        @Override
        public String getSelectedText() {
            final InputMethodRequests clientRequests = this.getClientRequests();
            if (clientRequests != null) {
                return clientRequests.getSelectedText();
            }
            return null;
        }
        
        @Override
        public int getInsertPositionOffset() {
            final InputMethodRequests clientRequests = this.getClientRequests();
            if (clientRequests != null && clientRequests instanceof ExtendedInputMethodRequests) {
                return ((ExtendedInputMethodRequests)clientRequests).getInsertPositionOffset();
            }
            return 0;
        }
        
        @Override
        public String getCommittedText(final int n, final int n2) {
            final InputMethodRequests clientRequests = this.getClientRequests();
            if (clientRequests != null && clientRequests instanceof ExtendedInputMethodRequests) {
                return ((ExtendedInputMethodRequests)clientRequests).getCommittedText(n, n2);
            }
            return null;
        }
        
        @Override
        public int getCommittedTextLength() {
            final InputMethodRequests clientRequests = this.getClientRequests();
            if (clientRequests != null && clientRequests instanceof ExtendedInputMethodRequests) {
                return ((ExtendedInputMethodRequests)clientRequests).getCommittedTextLength();
            }
            return 0;
        }
        
        private InputMethodRequests getClientRequests() {
            final Node focusOwner = Scene.this.getFocusOwner();
            if (focusOwner != null) {
                return focusOwner.getInputMethodRequests();
            }
            return null;
        }
    }
    
    private static class TouchMap
    {
        private static final int FAST_THRESHOLD = 10;
        int[] fastMap;
        Map<Long, Integer> slowMap;
        List<Integer> order;
        List<Long> removed;
        int counter;
        int active;
        
        private TouchMap() {
            this.fastMap = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            this.slowMap = new HashMap<Long, Integer>();
            this.order = new LinkedList<Integer>();
            this.removed = new ArrayList<Long>(10);
            this.counter = 0;
            this.active = 0;
        }
        
        public int add(final long l) {
            ++this.counter;
            ++this.active;
            if (l < 10L) {
                this.fastMap[(int)l] = this.counter;
            }
            else {
                this.slowMap.put(l, this.counter);
            }
            this.order.add(this.counter);
            return this.counter;
        }
        
        public void remove(final long l) {
            this.removed.add(l);
        }
        
        public int get(final long l) {
            if (l < 10L) {
                final int n = this.fastMap[(int)l];
                if (n == 0) {
                    throw new RuntimeException("Platform reported wrong touch point ID");
                }
                return n;
            }
            else {
                try {
                    return this.slowMap.get(l);
                }
                catch (NullPointerException ex) {
                    throw new RuntimeException("Platform reported wrong touch point ID");
                }
            }
        }
        
        public int getOrder(final int i) {
            return this.order.indexOf(i);
        }
        
        public boolean cleanup() {
            for (final long longValue : this.removed) {
                --this.active;
                this.order.remove((Object)this.get(longValue));
                if (longValue < 10L) {
                    this.fastMap[(int)longValue] = 0;
                }
                else {
                    this.slowMap.remove(longValue);
                }
                if (this.active == 0) {
                    this.counter = 0;
                }
            }
            this.removed.clear();
            return this.active == 0;
        }
    }
    
    private static class TargetWrapper
    {
        private Scene scene;
        private Node node;
        private PickResult result;
        
        public void fillHierarchy(final List<EventTarget> list) {
            list.clear();
            Parent parent;
            for (Node node = this.node; node != null; node = ((parent != null) ? parent : node.getSubScene())) {
                list.add(node);
                parent = node.getParent();
            }
            if (this.scene != null) {
                list.add(this.scene);
            }
        }
        
        public EventTarget getEventTarget() {
            return (this.node != null) ? this.node : this.scene;
        }
        
        public Cursor getCursor() {
            Cursor cursor = null;
            if (this.node != null) {
                cursor = this.node.getCursor();
                Parent parent2;
                for (Node parent = this.node.getParent(); cursor == null && parent != null; cursor = parent.getCursor(), parent2 = parent.getParent(), parent = ((parent2 != null) ? parent2 : parent.getSubScene())) {}
            }
            return cursor;
        }
        
        public void clear() {
            this.set(null, null);
            this.result = null;
        }
        
        public void setNodeResult(final PickResult result) {
            if (result != null) {
                this.result = result;
                final Node intersectedNode = result.getIntersectedNode();
                this.set(intersectedNode, intersectedNode.getScene());
            }
        }
        
        public void setSceneResult(final PickResult result, final Scene scene) {
            if (result != null) {
                this.result = result;
                this.set(null, scene);
            }
        }
        
        public PickResult getResult() {
            return this.result;
        }
        
        public void copy(final TargetWrapper targetWrapper) {
            this.node = targetWrapper.node;
            this.scene = targetWrapper.scene;
            this.result = targetWrapper.result;
        }
        
        private void set(final Node node, final Scene scene) {
            this.node = node;
            this.scene = scene;
        }
    }
    
    private final class EffectiveOrientationProperty extends ReadOnlyObjectPropertyBase<NodeOrientation>
    {
        @Override
        public NodeOrientation get() {
            return Scene.this.getEffectiveNodeOrientation();
        }
        
        @Override
        public Object getBean() {
            return Scene.this;
        }
        
        @Override
        public String getName() {
            return "effectiveNodeOrientation";
        }
        
        public void invalidate() {
            this.fireValueChangedEvent();
        }
    }
}
