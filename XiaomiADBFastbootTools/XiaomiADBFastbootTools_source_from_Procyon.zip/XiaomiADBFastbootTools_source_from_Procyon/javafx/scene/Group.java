// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import javafx.geometry.Bounds;
import javafx.collections.ObservableList;
import javafx.beans.property.BooleanPropertyBase;
import java.util.Collection;
import com.sun.javafx.scene.GroupHelper;
import javafx.beans.property.BooleanProperty;
import javafx.beans.DefaultProperty;

@DefaultProperty("children")
public class Group extends Parent
{
    private BooleanProperty autoSizeChildren;
    
    public Group() {
        GroupHelper.initHelper(this);
    }
    
    public Group(final Node... array) {
        GroupHelper.initHelper(this);
        this.getChildren().addAll(array);
    }
    
    public Group(final Collection<Node> collection) {
        GroupHelper.initHelper(this);
        this.getChildren().addAll((Collection<?>)collection);
    }
    
    public final void setAutoSizeChildren(final boolean b) {
        this.autoSizeChildrenProperty().set(b);
    }
    
    public final boolean isAutoSizeChildren() {
        return this.autoSizeChildren == null || this.autoSizeChildren.get();
    }
    
    public final BooleanProperty autoSizeChildrenProperty() {
        if (this.autoSizeChildren == null) {
            this.autoSizeChildren = new BooleanPropertyBase(true) {
                @Override
                protected void invalidated() {
                    Group.this.requestLayout();
                }
                
                @Override
                public Object getBean() {
                    return Group.this;
                }
                
                @Override
                public String getName() {
                    return "autoSizeChildren";
                }
            };
        }
        return this.autoSizeChildren;
    }
    
    public ObservableList<Node> getChildren() {
        return super.getChildren();
    }
    
    private Bounds doComputeLayoutBounds() {
        this.layout();
        return null;
    }
    
    @Override
    public double prefWidth(final double n) {
        if (this.isAutoSizeChildren()) {
            this.layout();
        }
        final double width = this.getLayoutBounds().getWidth();
        return (Double.isNaN(width) || width < 0.0) ? 0.0 : width;
    }
    
    @Override
    public double prefHeight(final double n) {
        if (this.isAutoSizeChildren()) {
            this.layout();
        }
        final double height = this.getLayoutBounds().getHeight();
        return (Double.isNaN(height) || height < 0.0) ? 0.0 : height;
    }
    
    @Override
    public double minHeight(final double n) {
        return this.prefHeight(n);
    }
    
    @Override
    public double minWidth(final double n) {
        return this.prefWidth(n);
    }
    
    @Override
    protected void layoutChildren() {
        if (this.isAutoSizeChildren()) {
            super.layoutChildren();
        }
    }
    
    static {
        GroupHelper.setGroupAccessor(new GroupHelper.GroupAccessor() {
            @Override
            public Bounds doComputeLayoutBounds(final Node node) {
                return ((Group)node).doComputeLayoutBounds();
            }
        });
    }
}
