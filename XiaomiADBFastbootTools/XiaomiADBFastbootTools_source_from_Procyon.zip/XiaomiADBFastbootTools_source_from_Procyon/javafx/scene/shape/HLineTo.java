// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.geom.Path2D;
import com.sun.javafx.sg.prism.NGPath;
import com.sun.javafx.scene.shape.HLineToHelper;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;

public class HLineTo extends PathElement
{
    private DoubleProperty x;
    
    public HLineTo() {
        this.x = new DoublePropertyBase() {
            public void invalidated() {
                HLineTo.this.u();
            }
            
            @Override
            public Object getBean() {
                return HLineTo.this;
            }
            
            @Override
            public String getName() {
                return "x";
            }
        };
        HLineToHelper.initHelper(this);
    }
    
    public HLineTo(final double x) {
        this.x = new DoublePropertyBase() {
            public void invalidated() {
                HLineTo.this.u();
            }
            
            @Override
            public Object getBean() {
                return HLineTo.this;
            }
            
            @Override
            public String getName() {
                return "x";
            }
        };
        this.setX(x);
        HLineToHelper.initHelper(this);
    }
    
    public final void setX(final double n) {
        this.x.set(n);
    }
    
    public final double getX() {
        return this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        return this.x;
    }
    
    @Override
    void addTo(final NGPath ngPath) {
        if (this.isAbsolute()) {
            ngPath.addLineTo((float)this.getX(), ngPath.getCurrentY());
        }
        else {
            ngPath.addLineTo((float)(ngPath.getCurrentX() + this.getX()), ngPath.getCurrentY());
        }
    }
    
    private void doAddTo(final Path2D path2D) {
        if (this.isAbsolute()) {
            path2D.lineTo((float)this.getX(), path2D.getCurrentY());
        }
        else {
            path2D.lineTo((float)(path2D.getCurrentX() + this.getX()), path2D.getCurrentY());
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("HLineTo[");
        sb.append("x=").append(this.getX());
        return sb.append("]").toString();
    }
    
    static {
        HLineToHelper.setHLineToAccessor(new HLineToHelper.HLineToAccessor() {
            @Override
            public void doAddTo(final PathElement pathElement, final Path2D path2D) {
                ((HLineTo)pathElement).doAddTo(path2D);
            }
        });
    }
}
