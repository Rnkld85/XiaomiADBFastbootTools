// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.scene.shape.Shape3DHelper;
import com.sun.javafx.sg.prism.NGShape3D;
import com.sun.javafx.geom.BoxBounds;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.paint.MaterialHelper;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.value.WeakChangeListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.property.SimpleObjectProperty;
import com.sun.javafx.logging.PlatformLogger;
import javafx.application.Platform;
import javafx.application.ConditionalFeature;
import javafx.scene.paint.Material;
import javafx.beans.property.ObjectProperty;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.Node;

public abstract class Shape3D extends Node
{
    private static final PhongMaterial DEFAULT_MATERIAL;
    PredefinedMeshManager manager;
    Key key;
    private ObjectProperty<Material> material;
    private ObjectProperty<DrawMode> drawMode;
    private ObjectProperty<CullFace> cullFace;
    
    protected Shape3D() {
        this.manager = PredefinedMeshManager.getInstance();
        if (!Platform.isSupported(ConditionalFeature.SCENE3D)) {
            PlatformLogger.getLogger(Shape3D.class.getName()).warning("System can't support ConditionalFeature.SCENE3D");
        }
    }
    
    public final void setMaterial(final Material material) {
        this.materialProperty().set(material);
    }
    
    public final Material getMaterial() {
        return (this.material == null) ? null : this.material.get();
    }
    
    public final ObjectProperty<Material> materialProperty() {
        if (this.material == null) {
            this.material = new SimpleObjectProperty<Material>(this, "material") {
                private Material old = null;
                private final ChangeListener<Boolean> materialChangeListener = (p0, p1, b) -> {
                    if (b) {
                        NodeHelper.markDirty(Shape3D.this, DirtyBits.MATERIAL);
                    }
                    return;
                };
                private final WeakChangeListener<Boolean> weakMaterialChangeListener = new WeakChangeListener<Boolean>(this.materialChangeListener);
                
                @Override
                protected void invalidated() {
                    if (this.old != null) {
                        MaterialHelper.dirtyProperty(this.old).removeListener(this.weakMaterialChangeListener);
                    }
                    final Material old = this.get();
                    if (old != null) {
                        MaterialHelper.dirtyProperty(old).addListener(this.weakMaterialChangeListener);
                    }
                    NodeHelper.markDirty(Shape3D.this, DirtyBits.MATERIAL);
                    NodeHelper.geomChanged(Shape3D.this);
                    this.old = old;
                }
            };
        }
        return this.material;
    }
    
    public final void setDrawMode(final DrawMode drawMode) {
        this.drawModeProperty().set(drawMode);
    }
    
    public final DrawMode getDrawMode() {
        return (this.drawMode == null) ? DrawMode.FILL : this.drawMode.get();
    }
    
    public final ObjectProperty<DrawMode> drawModeProperty() {
        if (this.drawMode == null) {
            this.drawMode = new SimpleObjectProperty<DrawMode>(this, "drawMode", DrawMode.FILL) {
                @Override
                protected void invalidated() {
                    NodeHelper.markDirty(Shape3D.this, DirtyBits.NODE_DRAWMODE);
                }
            };
        }
        return this.drawMode;
    }
    
    public final void setCullFace(final CullFace cullFace) {
        this.cullFaceProperty().set(cullFace);
    }
    
    public final CullFace getCullFace() {
        return (this.cullFace == null) ? CullFace.BACK : this.cullFace.get();
    }
    
    public final ObjectProperty<CullFace> cullFaceProperty() {
        if (this.cullFace == null) {
            this.cullFace = new SimpleObjectProperty<CullFace>(this, "cullFace", CullFace.BACK) {
                @Override
                protected void invalidated() {
                    NodeHelper.markDirty(Shape3D.this, DirtyBits.NODE_CULLFACE);
                }
            };
        }
        return this.cullFace;
    }
    
    private BaseBounds doComputeGeomBounds(final BaseBounds baseBounds, final BaseTransform baseTransform) {
        return new BoxBounds(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
    }
    
    private boolean doComputeContains(final double n, final double n2) {
        return false;
    }
    
    private void doUpdatePeer() {
        final NGShape3D ngShape3D = NodeHelper.getPeer(this);
        if (NodeHelper.isDirty(this, DirtyBits.MATERIAL)) {
            final Material material = (this.getMaterial() == null) ? Shape3D.DEFAULT_MATERIAL : this.getMaterial();
            MaterialHelper.updatePG(material);
            ngShape3D.setMaterial(MaterialHelper.getNGMaterial(material));
        }
        if (NodeHelper.isDirty(this, DirtyBits.NODE_DRAWMODE)) {
            ngShape3D.setDrawMode((this.getDrawMode() == null) ? DrawMode.FILL : this.getDrawMode());
        }
        if (NodeHelper.isDirty(this, DirtyBits.NODE_CULLFACE)) {
            ngShape3D.setCullFace((this.getCullFace() == null) ? CullFace.BACK : this.getCullFace());
        }
    }
    
    static {
        Shape3DHelper.setShape3DAccessor(new Shape3DHelper.Shape3DAccessor() {
            @Override
            public void doUpdatePeer(final Node node) {
                ((Shape3D)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Shape3D)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public boolean doComputeContains(final Node node, final double n, final double n2) {
                return ((Shape3D)node).doComputeContains(n, n2);
            }
        });
        DEFAULT_MATERIAL = new PhongMaterial();
    }
    
    abstract static class Key
    {
        @Override
        public abstract boolean equals(final Object p0);
        
        @Override
        public abstract int hashCode();
    }
}
