// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.geom.PathIterator;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.Arc2D;
import com.sun.javafx.geom.Path2D;
import com.sun.javafx.sg.prism.NGPath;
import javafx.beans.property.BooleanPropertyBase;
import com.sun.javafx.scene.shape.ArcToHelper;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;

public class ArcTo extends PathElement
{
    private DoubleProperty radiusX;
    private DoubleProperty radiusY;
    private DoubleProperty xAxisRotation;
    private BooleanProperty largeArcFlag;
    private BooleanProperty sweepFlag;
    private DoubleProperty x;
    private DoubleProperty y;
    
    public ArcTo() {
        this.radiusX = new DoublePropertyBase() {
            public void invalidated() {
                ArcTo.this.u();
            }
            
            @Override
            public Object getBean() {
                return ArcTo.this;
            }
            
            @Override
            public String getName() {
                return "radiusX";
            }
        };
        this.radiusY = new DoublePropertyBase() {
            public void invalidated() {
                ArcTo.this.u();
            }
            
            @Override
            public Object getBean() {
                return ArcTo.this;
            }
            
            @Override
            public String getName() {
                return "radiusY";
            }
        };
        ArcToHelper.initHelper(this);
    }
    
    public ArcTo(final double radiusX, final double radiusY, final double xAxisRotation, final double x, final double y, final boolean largeArcFlag, final boolean sweepFlag) {
        this.radiusX = new DoublePropertyBase() {
            public void invalidated() {
                ArcTo.this.u();
            }
            
            @Override
            public Object getBean() {
                return ArcTo.this;
            }
            
            @Override
            public String getName() {
                return "radiusX";
            }
        };
        this.radiusY = new DoublePropertyBase() {
            public void invalidated() {
                ArcTo.this.u();
            }
            
            @Override
            public Object getBean() {
                return ArcTo.this;
            }
            
            @Override
            public String getName() {
                return "radiusY";
            }
        };
        this.setRadiusX(radiusX);
        this.setRadiusY(radiusY);
        this.setXAxisRotation(xAxisRotation);
        this.setX(x);
        this.setY(y);
        this.setLargeArcFlag(largeArcFlag);
        this.setSweepFlag(sweepFlag);
        ArcToHelper.initHelper(this);
    }
    
    public final void setRadiusX(final double n) {
        this.radiusX.set(n);
    }
    
    public final double getRadiusX() {
        return this.radiusX.get();
    }
    
    public final DoubleProperty radiusXProperty() {
        return this.radiusX;
    }
    
    public final void setRadiusY(final double n) {
        this.radiusY.set(n);
    }
    
    public final double getRadiusY() {
        return this.radiusY.get();
    }
    
    public final DoubleProperty radiusYProperty() {
        return this.radiusY;
    }
    
    public final void setXAxisRotation(final double n) {
        if (this.xAxisRotation != null || n != 0.0) {
            this.XAxisRotationProperty().set(n);
        }
    }
    
    public final double getXAxisRotation() {
        return (this.xAxisRotation == null) ? 0.0 : this.xAxisRotation.get();
    }
    
    public final DoubleProperty XAxisRotationProperty() {
        if (this.xAxisRotation == null) {
            this.xAxisRotation = new DoublePropertyBase() {
                public void invalidated() {
                    ArcTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return ArcTo.this;
                }
                
                @Override
                public String getName() {
                    return "XAxisRotation";
                }
            };
        }
        return this.xAxisRotation;
    }
    
    public final void setLargeArcFlag(final boolean b) {
        if (this.largeArcFlag != null || b) {
            this.largeArcFlagProperty().set(b);
        }
    }
    
    public final boolean isLargeArcFlag() {
        return this.largeArcFlag != null && this.largeArcFlag.get();
    }
    
    public final BooleanProperty largeArcFlagProperty() {
        if (this.largeArcFlag == null) {
            this.largeArcFlag = new BooleanPropertyBase() {
                public void invalidated() {
                    ArcTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return ArcTo.this;
                }
                
                @Override
                public String getName() {
                    return "largeArcFlag";
                }
            };
        }
        return this.largeArcFlag;
    }
    
    public final void setSweepFlag(final boolean b) {
        if (this.sweepFlag != null || b) {
            this.sweepFlagProperty().set(b);
        }
    }
    
    public final boolean isSweepFlag() {
        return this.sweepFlag != null && this.sweepFlag.get();
    }
    
    public final BooleanProperty sweepFlagProperty() {
        if (this.sweepFlag == null) {
            this.sweepFlag = new BooleanPropertyBase() {
                public void invalidated() {
                    ArcTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return ArcTo.this;
                }
                
                @Override
                public String getName() {
                    return "sweepFlag";
                }
            };
        }
        return this.sweepFlag;
    }
    
    public final void setX(final double n) {
        if (this.x != null || n != 0.0) {
            this.xProperty().set(n);
        }
    }
    
    public final double getX() {
        return (this.x == null) ? 0.0 : this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        if (this.x == null) {
            this.x = new DoublePropertyBase() {
                public void invalidated() {
                    ArcTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return ArcTo.this;
                }
                
                @Override
                public String getName() {
                    return "x";
                }
            };
        }
        return this.x;
    }
    
    public final void setY(final double n) {
        if (this.y != null || n != 0.0) {
            this.yProperty().set(n);
        }
    }
    
    public final double getY() {
        return (this.y == null) ? 0.0 : this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        if (this.y == null) {
            this.y = new DoublePropertyBase() {
                public void invalidated() {
                    ArcTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return ArcTo.this;
                }
                
                @Override
                public String getName() {
                    return "y";
                }
            };
        }
        return this.y;
    }
    
    @Override
    void addTo(final NGPath ngPath) {
        this.addArcTo(ngPath, null, ngPath.getCurrentX(), ngPath.getCurrentY());
    }
    
    private void doAddTo(final Path2D path2D) {
        this.addArcTo(null, path2D, path2D.getCurrentX(), path2D.getCurrentY());
    }
    
    private void addArcTo(final NGPath ngPath, final Path2D path2D, final double n, final double n2) {
        final double x = this.getX();
        final double y = this.getY();
        final boolean sweepFlag = this.isSweepFlag();
        final boolean largeArcFlag = this.isLargeArcFlag();
        final double n3 = this.isAbsolute() ? x : (x + n);
        final double n4 = this.isAbsolute() ? y : (y + n2);
        final double n5 = (n - n3) / 2.0;
        final double n6 = (n2 - n4) / 2.0;
        final double radians = Math.toRadians(this.getXAxisRotation());
        final double cos = Math.cos(radians);
        final double sin = Math.sin(radians);
        final double n7 = cos * n5 + sin * n6;
        final double n8 = -sin * n5 + cos * n6;
        double abs = Math.abs(this.getRadiusX());
        double abs2 = Math.abs(this.getRadiusY());
        double n9 = abs * abs;
        double n10 = abs2 * abs2;
        final double n11 = n7 * n7;
        final double n12 = n8 * n8;
        final double n13 = n11 / n9 + n12 / n10;
        if (n13 > 1.0) {
            abs *= Math.sqrt(n13);
            abs2 *= Math.sqrt(n13);
            if (abs != abs || abs2 != abs2) {
                if (ngPath == null) {
                    path2D.lineTo((float)n3, (float)n4);
                }
                else {
                    ngPath.addLineTo((float)n3, (float)n4);
                }
                return;
            }
            n9 = abs * abs;
            n10 = abs2 * abs2;
        }
        final double n14 = (largeArcFlag == sweepFlag) ? -1.0 : 1.0;
        final double n15 = (n9 * n10 - n9 * n12 - n10 * n11) / (n9 * n12 + n10 * n11);
        final double n16 = n14 * Math.sqrt((n15 < 0.0) ? 0.0 : n15);
        final double n17 = n16 * (abs * n8 / abs2);
        final double n18 = n16 * -(abs2 * n7 / abs);
        final double n19 = (n + n3) / 2.0;
        final double n20 = (n2 + n4) / 2.0;
        final double n21 = n19 + (cos * n17 - sin * n18);
        final double n22 = n20 + (sin * n17 + cos * n18);
        final double n23 = (n7 - n17) / abs;
        final double n24 = (n8 - n18) / abs2;
        final double n25 = (-n7 - n17) / abs;
        final double n26 = (-n8 - n18) / abs2;
        final double degrees = Math.toDegrees(((n24 < 0.0) ? -1.0 : 1.0) * Math.acos(n23 / Math.sqrt(n23 * n23 + n24 * n24)));
        double degrees2 = Math.toDegrees(((n23 * n26 - n24 * n25 < 0.0) ? -1.0 : 1.0) * Math.acos((n23 * n25 + n24 * n26) / Math.sqrt((n23 * n23 + n24 * n24) * (n25 * n25 + n26 * n26))));
        if (!sweepFlag && degrees2 > 0.0) {
            degrees2 -= 360.0;
        }
        else if (sweepFlag && degrees2 < 0.0) {
            degrees2 += 360.0;
        }
        final double n27 = degrees2 % 360.0;
        final double n28 = degrees % 360.0;
        final float n29 = (float)(n21 - abs);
        final float n30 = (float)(n22 - abs2);
        final float n31 = (float)(abs * 2.0);
        final float n32 = (float)(abs2 * 2.0);
        final float n33 = (float)(-n28);
        final float n34 = (float)(-n27);
        if (ngPath == null) {
            final PathIterator pathIterator = new Arc2D(n29, n30, n31, n32, n33, n34, 0).getPathIterator((radians == 0.0) ? null : BaseTransform.getRotateInstance(radians, n21, n22));
            pathIterator.next();
            path2D.append(pathIterator, true);
        }
        else {
            ngPath.addArcTo(n29, n30, n31, n32, n33, n34, (float)radians);
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ArcTo[");
        sb.append("x=").append(this.getX());
        sb.append(", y=").append(this.getY());
        sb.append(", radiusX=").append(this.getRadiusX());
        sb.append(", radiusY=").append(this.getRadiusY());
        sb.append(", xAxisRotation=").append(this.getXAxisRotation());
        if (this.isLargeArcFlag()) {
            sb.append(", lartArcFlag");
        }
        if (this.isSweepFlag()) {
            sb.append(", sweepFlag");
        }
        return sb.append("]").toString();
    }
    
    static {
        ArcToHelper.setArcToAccessor(new ArcToHelper.ArcToAccessor() {
            @Override
            public void doAddTo(final PathElement pathElement, final Path2D path2D) {
                ((ArcTo)pathElement).doAddTo(path2D);
            }
        });
    }
}
