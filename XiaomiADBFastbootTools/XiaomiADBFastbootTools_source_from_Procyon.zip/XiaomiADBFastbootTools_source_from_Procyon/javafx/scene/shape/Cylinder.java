// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.geom.Vec3d;
import javafx.scene.transform.Rotate;
import javafx.geometry.Point3D;
import javafx.geometry.Point2D;
import com.sun.javafx.scene.shape.MeshHelper;
import com.sun.javafx.scene.input.PickResultChooser;
import com.sun.javafx.geom.PickRay;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.sg.prism.NGNode;
import com.sun.javafx.sg.prism.NGTriangleMesh;
import com.sun.javafx.sg.prism.NGCylinder;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.property.SimpleDoubleProperty;
import com.sun.javafx.scene.shape.CylinderHelper;
import javafx.beans.property.DoubleProperty;

public class Cylinder extends Shape3D
{
    static final int DEFAULT_DIVISIONS = 64;
    static final double DEFAULT_RADIUS = 1.0;
    static final double DEFAULT_HEIGHT = 2.0;
    private int divisions;
    private TriangleMesh mesh;
    private DoubleProperty height;
    private DoubleProperty radius;
    
    public Cylinder() {
        this(1.0, 2.0, 64);
    }
    
    public Cylinder(final double n, final double n2) {
        this(n, n2, 64);
    }
    
    public Cylinder(final double radius, final double height, final int n) {
        this.divisions = 64;
        CylinderHelper.initHelper(this);
        this.divisions = ((n < 3) ? 3 : n);
        this.setRadius(radius);
        this.setHeight(height);
    }
    
    public final void setHeight(final double n) {
        this.heightProperty().set(n);
    }
    
    public final double getHeight() {
        return (this.height == null) ? 2.0 : this.height.get();
    }
    
    public final DoubleProperty heightProperty() {
        if (this.height == null) {
            this.height = new SimpleDoubleProperty(this, "height", 2.0) {
                public void invalidated() {
                    NodeHelper.markDirty(Cylinder.this, DirtyBits.MESH_GEOM);
                    Cylinder.this.manager.invalidateCylinderMesh(Cylinder.this.key);
                    Cylinder.this.key = null;
                    NodeHelper.geomChanged(Cylinder.this);
                }
            };
        }
        return this.height;
    }
    
    public final void setRadius(final double n) {
        this.radiusProperty().set(n);
    }
    
    public final double getRadius() {
        return (this.radius == null) ? 1.0 : this.radius.get();
    }
    
    public final DoubleProperty radiusProperty() {
        if (this.radius == null) {
            this.radius = new SimpleDoubleProperty(this, "radius", 1.0) {
                public void invalidated() {
                    NodeHelper.markDirty(Cylinder.this, DirtyBits.MESH_GEOM);
                    Cylinder.this.manager.invalidateCylinderMesh(Cylinder.this.key);
                    Cylinder.this.key = null;
                    NodeHelper.geomChanged(Cylinder.this);
                }
            };
        }
        return this.radius;
    }
    
    public int getDivisions() {
        return this.divisions;
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.MESH_GEOM)) {
            final NGCylinder ngCylinder = NodeHelper.getPeer(this);
            final float n = (float)this.getHeight();
            final float n2 = (float)this.getRadius();
            if (n < 0.0f || n2 < 0.0f) {
                ngCylinder.updateMesh(null);
            }
            else {
                if (this.key == null) {
                    this.key = new CylinderKey((double)n, (double)n2, this.divisions);
                }
                (this.mesh = this.manager.getCylinderMesh(n, n2, this.divisions, this.key)).updatePG();
                ngCylinder.updateMesh(this.mesh.getPGTriangleMesh());
            }
        }
    }
    
    private NGNode doCreatePeer() {
        return new NGCylinder();
    }
    
    private BaseBounds doComputeGeomBounds(BaseBounds baseBounds, final BaseTransform baseTransform) {
        final float n = (float)this.getHeight();
        final float n2 = (float)this.getRadius();
        if (n2 < 0.0f || n < 0.0f) {
            return baseBounds.makeEmpty();
        }
        final float n3 = n * 0.5f;
        baseBounds = baseBounds.deriveWithNewBounds(-n2, -n3, -n2, n2, n3, n2);
        baseBounds = baseTransform.transform(baseBounds, baseBounds);
        return baseBounds;
    }
    
    private boolean doComputeContains(final double n, final double n2) {
        final double radius = this.getRadius();
        final double n3 = this.getHeight() * 0.5;
        return -radius <= n && n <= radius && -n3 <= n2 && n2 <= n3;
    }
    
    private boolean doComputeIntersects(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        final boolean b = this.divisions < 64 && this.mesh != null;
        final double radius = this.getRadius();
        final Vec3d directionNoClone = pickRay.getDirectionNoClone();
        final double x = directionNoClone.x;
        final double y = directionNoClone.y;
        final double z = directionNoClone.z;
        final Vec3d originNoClone = pickRay.getOriginNoClone();
        final double x2 = originNoClone.x;
        final double y2 = originNoClone.y;
        final double z2 = originNoClone.z;
        final double height = this.getHeight();
        final double n = height / 2.0;
        final CullFace cullFace = this.getCullFace();
        final double n2 = x * x + z * z;
        final double n3 = 2.0 * (x * x2 + z * z2);
        final double n4 = x2 * x2 + z2 * z2 - radius * radius;
        final double a = n3 * n3 - 4.0 * n2 * n4;
        double n5 = Double.POSITIVE_INFINITY;
        final double nearClip = pickRay.getNearClip();
        final double farClip = pickRay.getFarClip();
        if (a >= 0.0 && (x != 0.0 || z != 0.0)) {
            final double sqrt = Math.sqrt(a);
            final double n6 = (n3 < 0.0) ? ((-n3 - sqrt) / 2.0) : ((-n3 + sqrt) / 2.0);
            double n7 = n6 / n2;
            double n8 = n4 / n6;
            if (n7 > n8) {
                final double n9 = n7;
                n7 = n8;
                n8 = n9;
            }
            final double n10 = y2 + n7 * y;
            if (n7 < nearClip || n10 < -n || n10 > n || cullFace == CullFace.FRONT) {
                final double n11 = y2 + n8 * y;
                if (n8 >= nearClip && n8 <= farClip && n11 >= -n && n11 <= n && (cullFace != CullFace.BACK || b)) {
                    n5 = n8;
                }
            }
            else if (n7 <= farClip) {
                n5 = n7;
            }
        }
        int n12 = 0;
        int n13 = 0;
        if (n5 == Double.POSITIVE_INFINITY || !b) {
            final double n14 = (-n - y2) / y;
            final double n15 = (n - y2) / y;
            int n16 = 0;
            double n17;
            double n18;
            if (n14 < n15) {
                n17 = n14;
                n18 = n15;
                n16 = 1;
            }
            else {
                n17 = n15;
                n18 = n14;
            }
            if (n17 >= nearClip && n17 <= farClip && n17 < n5 && cullFace != CullFace.FRONT) {
                final double n19 = x2 + x * n17;
                final double n20 = z2 + z * n17;
                if (n19 * n19 + n20 * n20 <= radius * radius) {
                    n13 = n16;
                    n12 = ((n16 == 0) ? 1 : 0);
                    n5 = n17;
                }
            }
            if (n18 >= nearClip && n18 <= farClip && n18 < n5 && (cullFace != CullFace.BACK || b)) {
                final double n21 = x2 + x * n18;
                final double n22 = z2 + z * n18;
                if (n21 * n21 + n22 * n22 <= radius * radius) {
                    n12 = n16;
                    n13 = ((n16 == 0) ? 1 : 0);
                    n5 = n18;
                }
            }
        }
        if (Double.isInfinite(n5) || Double.isNaN(n5)) {
            return false;
        }
        if (b) {
            return MeshHelper.computeIntersects(this.mesh, pickRay, pickResultChooser, this, cullFace, false);
        }
        if (pickResultChooser != null && pickResultChooser.isCloser(n5)) {
            final Point3D computePoint = PickResultChooser.computePoint(pickRay, n5);
            Point2D point2D;
            if (n12 != 0) {
                point2D = new Point2D(0.5 + computePoint.getX() / (2.0 * radius), 0.5 + computePoint.getZ() / (2.0 * radius));
            }
            else if (n13 != 0) {
                point2D = new Point2D(0.5 + computePoint.getX() / (2.0 * radius), 0.5 - computePoint.getZ() / (2.0 * radius));
            }
            else {
                final Point3D point3D = new Point3D(computePoint.getX(), 0.0, computePoint.getZ());
                final Point3D crossProduct = point3D.crossProduct(Rotate.Z_AXIS);
                double angle = point3D.angle(Rotate.Z_AXIS);
                if (crossProduct.getY() > 0.0) {
                    angle = 360.0 - angle;
                }
                point2D = new Point2D(1.0 - angle / 360.0, 0.5 + computePoint.getY() / height);
            }
            pickResultChooser.offer(this, n5, -1, computePoint, point2D);
        }
        return true;
    }
    
    static TriangleMesh createMesh(final int n, float n2, final float n3) {
        final int n4 = n * 2 + 2;
        final int n5 = (n + 1) * 4 + 1;
        final int n6 = n * 4;
        final float n7 = 0.00390625f;
        final float n8 = 1.0f / n;
        n2 *= 0.5f;
        final float[] all = new float[n4 * 3];
        final float[] all2 = new float[n5 * 2];
        final int[] all3 = new int[n6 * 6];
        final int[] all4 = new int[n6];
        int n9 = 0;
        int n10 = 0;
        for (int i = 0; i < n; ++i) {
            final double n11 = n8 * i * 2.0f * 3.141592653589793;
            all[n9 + 0] = (float)(Math.sin(n11) * n3);
            all[n9 + 2] = (float)(Math.cos(n11) * n3);
            all[n9 + 1] = n2;
            all2[n10 + 0] = 1.0f - n8 * i;
            all2[n10 + 1] = 1.0f - n7;
            n9 += 3;
            n10 += 2;
        }
        all2[n10 + 0] = 0.0f;
        all2[n10 + 1] = 1.0f - n7;
        n10 += 2;
        for (int j = 0; j < n; ++j) {
            final double n12 = n8 * j * 2.0f * 3.141592653589793;
            all[n9 + 0] = (float)(Math.sin(n12) * n3);
            all[n9 + 2] = (float)(Math.cos(n12) * n3);
            all[n9 + 1] = -n2;
            all2[n10 + 0] = 1.0f - n8 * j;
            all2[n10 + 1] = n7;
            n9 += 3;
            n10 += 2;
        }
        all2[n10 + 0] = 0.0f;
        all2[n10 + 1] = n7;
        n10 += 2;
        all[n9 + 0] = 0.0f;
        all[n9 + 1] = n2;
        all[n9 + 3] = (all[n9 + 2] = 0.0f);
        all[n9 + 4] = -n2;
        all[n9 + 5] = 0.0f;
        n9 += 6;
        for (int k = 0; k <= n; ++k) {
            final double n13 = (k < n) ? (n8 * k * 2.0f * 3.141592653589793) : 0.0;
            all2[n10 + 0] = (float)(Math.sin(n13) * 0.5) + 0.5f;
            all2[n10 + 1] = (float)(Math.cos(n13) * 0.5) + 0.5f;
            n10 += 2;
        }
        for (int l = 0; l <= n; ++l) {
            final double n14 = (l < n) ? (n8 * l * 2.0f * 3.141592653589793) : 0.0;
            all2[n10 + 0] = 0.5f + (float)(Math.sin(n14) * 0.5);
            all2[n10 + 1] = 0.5f - (float)(Math.cos(n14) * 0.5);
            n10 += 2;
        }
        all2[n10 + 1] = (all2[n10 + 0] = 0.5f);
        n10 += 2;
        int n15 = 0;
        for (int n16 = 0; n16 < n; ++n16) {
            final int n17 = n16 + 1;
            final int n18 = n16 + n;
            final int n19 = n17 + n;
            all3[n15 + 1] = (all3[n15 + 0] = n16);
            all3[n15 + 3] = (all3[n15 + 2] = n18) + 1;
            all3[n15 + 4] = ((n17 == n) ? 0 : n17);
            all3[n15 + 5] = n17;
            n15 += 6;
            all3[n15 + 0] = ((n19 % n == 0) ? (n19 - n) : n19);
            all3[n15 + 1] = n19 + 1;
            all3[n15 + 2] = ((n17 == n) ? 0 : n17);
            all3[n15 + 3] = n17;
            all3[n15 + 5] = (all3[n15 + 4] = n18) + 1;
            n15 += 6;
        }
        final int n20 = (n + 1) * 2;
        final int n21 = (n + 1) * 4;
        final int n22 = n * 2;
        for (int n23 = 0; n23 < n; ++n23) {
            final int n24 = n23 + 1;
            final int n25 = n20 + n23;
            final int n26 = n25 + 1;
            all3[n15 + 0] = n23;
            all3[n15 + 1] = n25;
            all3[n15 + 2] = ((n24 == n) ? 0 : n24);
            all3[n15 + 3] = n26;
            all3[n15 + 4] = n22;
            all3[n15 + 5] = n21;
            n15 += 6;
        }
        final int n27 = n * 2 + 1;
        final int n28 = (n + 1) * 3;
        for (int n29 = 0; n29 < n; ++n29) {
            final int n30 = n29 + 1 + n;
            final int n31 = n28 + n29;
            final int n32 = n31 + 1;
            all3[n15 + 0] = n29 + n;
            all3[n15 + 1] = n31;
            all3[n15 + 2] = n27;
            all3[n15 + 3] = n21;
            all3[n15 + 4] = ((n30 % n == 0) ? (n30 - n) : n30);
            all3[n15 + 5] = n32;
            n15 += 6;
        }
        for (int n33 = 0; n33 < n * 2; ++n33) {
            all4[n33] = 1;
        }
        for (int n34 = n * 2; n34 < n * 4; ++n34) {
            all4[n34] = 2;
        }
        final TriangleMesh triangleMesh = new TriangleMesh(true);
        triangleMesh.getPoints().setAll(all);
        triangleMesh.getTexCoords().setAll(all2);
        triangleMesh.getFaces().setAll(all3);
        triangleMesh.getFaceSmoothingGroups().setAll(all4);
        return triangleMesh;
    }
    
    static {
        CylinderHelper.setCylinderAccessor(new CylinderHelper.CylinderAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((Cylinder)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((Cylinder)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Cylinder)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public boolean doComputeContains(final Node node, final double n, final double n2) {
                return ((Cylinder)node).doComputeContains(n, n2);
            }
            
            @Override
            public boolean doComputeIntersects(final Node node, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                return ((Cylinder)node).doComputeIntersects(pickRay, pickResultChooser);
            }
        });
    }
    
    private static class CylinderKey extends Key
    {
        final double radius;
        final double height;
        final int divisions;
        
        private CylinderKey(final double radius, final double height, final int divisions) {
            this.radius = radius;
            this.height = height;
            this.divisions = divisions;
        }
        
        @Override
        public int hashCode() {
            return Long.hashCode(31L * (31L * (31L * 7L + Double.doubleToLongBits(this.radius)) + Double.doubleToLongBits(this.height)) + this.divisions);
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null) {
                return false;
            }
            if (!(o instanceof CylinderKey)) {
                return false;
            }
            final CylinderKey cylinderKey = (CylinderKey)o;
            return this.divisions == cylinderKey.divisions && Double.compare(this.radius, cylinderKey.radius) == 0 && Double.compare(this.height, cylinderKey.height) == 0;
        }
    }
}
