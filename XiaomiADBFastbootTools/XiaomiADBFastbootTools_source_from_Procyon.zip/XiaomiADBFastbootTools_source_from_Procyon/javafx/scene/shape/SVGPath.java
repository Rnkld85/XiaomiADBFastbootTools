// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.util.Logging;
import com.sun.javafx.tk.Toolkit;
import javafx.scene.paint.Paint;
import com.sun.javafx.scene.shape.ShapeHelper;
import com.sun.javafx.sg.prism.NGSVGPath;
import com.sun.javafx.sg.prism.NGNode;
import javafx.beans.property.StringPropertyBase;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.property.ObjectPropertyBase;
import com.sun.javafx.scene.shape.SVGPathHelper;
import javafx.beans.property.StringProperty;
import com.sun.javafx.geom.Path2D;
import javafx.beans.property.ObjectProperty;

public class SVGPath extends Shape
{
    private ObjectProperty<FillRule> fillRule;
    private Path2D path2d;
    private StringProperty content;
    private Object svgPathObject;
    
    public SVGPath() {
        SVGPathHelper.initHelper(this);
    }
    
    public final void setFillRule(final FillRule fillRule) {
        if (this.fillRule != null || fillRule != FillRule.NON_ZERO) {
            this.fillRuleProperty().set(fillRule);
        }
    }
    
    public final FillRule getFillRule() {
        return (this.fillRule == null) ? FillRule.NON_ZERO : this.fillRule.get();
    }
    
    public final ObjectProperty<FillRule> fillRuleProperty() {
        if (this.fillRule == null) {
            this.fillRule = new ObjectPropertyBase<FillRule>(FillRule.NON_ZERO) {
                public void invalidated() {
                    NodeHelper.markDirty(SVGPath.this, DirtyBits.SHAPE_FILLRULE);
                    NodeHelper.geomChanged(SVGPath.this);
                }
                
                @Override
                public Object getBean() {
                    return SVGPath.this;
                }
                
                @Override
                public String getName() {
                    return "fillRule";
                }
            };
        }
        return this.fillRule;
    }
    
    public final void setContent(final String s) {
        this.contentProperty().set(s);
    }
    
    public final String getContent() {
        return (this.content == null) ? "" : this.content.get();
    }
    
    public final StringProperty contentProperty() {
        if (this.content == null) {
            this.content = new StringPropertyBase("") {
                public void invalidated() {
                    NodeHelper.markDirty(SVGPath.this, DirtyBits.NODE_CONTENTS);
                    NodeHelper.geomChanged(SVGPath.this);
                    SVGPath.this.path2d = null;
                }
                
                @Override
                public Object getBean() {
                    return SVGPath.this;
                }
                
                @Override
                public String getName() {
                    return "content";
                }
            };
        }
        return this.content;
    }
    
    private NGNode doCreatePeer() {
        return new NGSVGPath();
    }
    
    private Path2D doConfigShape() {
        if (this.path2d == null) {
            this.path2d = this.createSVGPath2D();
        }
        else {
            this.path2d.setWindingRule((this.getFillRule() == FillRule.NON_ZERO) ? 1 : 0);
        }
        return this.path2d;
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.SHAPE_FILLRULE) || NodeHelper.isDirty(this, DirtyBits.NODE_CONTENTS)) {
            final NGSVGPath ngsvgPath = NodeHelper.getPeer(this);
            if (ngsvgPath.acceptsPath2dOnUpdate()) {
                if (this.svgPathObject == null) {
                    this.svgPathObject = new Path2D();
                }
                ((Path2D)this.svgPathObject).setTo((Path2D)ShapeHelper.configShape(this));
            }
            else {
                this.svgPathObject = this.createSVGPathObject();
            }
            ngsvgPath.setContent(this.svgPathObject);
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SVGPath[");
        final String id = this.getId();
        if (id != null) {
            sb.append("id=").append(id).append(", ");
        }
        sb.append("content=\"").append(this.getContent()).append("\"");
        sb.append(", fill=").append(this.getFill());
        sb.append(", fillRule=").append(this.getFillRule());
        final Paint stroke = this.getStroke();
        if (stroke != null) {
            sb.append(", stroke=").append(stroke);
            sb.append(", strokeWidth=").append(this.getStrokeWidth());
        }
        return sb.append("]").toString();
    }
    
    private Path2D createSVGPath2D() {
        try {
            return Toolkit.getToolkit().createSVGPath2D(this);
        }
        catch (RuntimeException ex) {
            Logging.getJavaFXLogger().warning("Failed to configure svg path \"{0}\": {1}", this.getContent(), ex.getMessage());
            return Toolkit.getToolkit().createSVGPath2D(new SVGPath());
        }
    }
    
    private Object createSVGPathObject() {
        try {
            return Toolkit.getToolkit().createSVGPathObject(this);
        }
        catch (RuntimeException ex) {
            Logging.getJavaFXLogger().warning("Failed to configure svg path \"{0}\": {1}", this.getContent(), ex.getMessage());
            return Toolkit.getToolkit().createSVGPathObject(new SVGPath());
        }
    }
    
    static {
        SVGPathHelper.setSVGPathAccessor(new SVGPathHelper.SVGPathAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((SVGPath)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((SVGPath)node).doUpdatePeer();
            }
            
            @Override
            public com.sun.javafx.geom.Shape doConfigShape(final Shape shape) {
                return ((SVGPath)shape).doConfigShape();
            }
        });
    }
}
