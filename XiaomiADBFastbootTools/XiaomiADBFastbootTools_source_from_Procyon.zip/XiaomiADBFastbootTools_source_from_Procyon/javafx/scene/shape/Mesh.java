// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.sg.prism.NGTriangleMesh;
import com.sun.javafx.logging.PlatformLogger;
import javafx.application.Platform;
import javafx.application.ConditionalFeature;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.BooleanProperty;
import com.sun.javafx.scene.shape.MeshHelper;

public abstract class Mesh
{
    private MeshHelper meshHelper;
    private final BooleanProperty dirty;
    
    protected Mesh() {
        this.meshHelper = null;
        this.dirty = new SimpleBooleanProperty(true);
        if (!Platform.isSupported(ConditionalFeature.SCENE3D)) {
            PlatformLogger.getLogger(Mesh.class.getName()).warning("System can't support ConditionalFeature.SCENE3D");
        }
    }
    
    final boolean isDirty() {
        return this.dirty.getValue();
    }
    
    void setDirty(final boolean b) {
        this.dirty.setValue(b);
    }
    
    final BooleanProperty dirtyProperty() {
        return this.dirty;
    }
    
    abstract NGTriangleMesh getPGMesh();
    
    abstract void updatePG();
    
    abstract BaseBounds computeBounds(final BaseBounds p0);
    
    static {
        MeshHelper.setMeshAccessor(new MeshHelper.MeshAccessor() {
            @Override
            public MeshHelper getHelper(final Mesh mesh) {
                return mesh.meshHelper;
            }
            
            @Override
            public void setHelper(final Mesh mesh, final MeshHelper meshHelper) {
                mesh.meshHelper = meshHelper;
            }
        });
    }
}
