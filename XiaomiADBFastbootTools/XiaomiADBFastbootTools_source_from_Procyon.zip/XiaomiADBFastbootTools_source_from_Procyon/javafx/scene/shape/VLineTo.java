// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.geom.Path2D;
import com.sun.javafx.sg.prism.NGPath;
import com.sun.javafx.scene.shape.VLineToHelper;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;

public class VLineTo extends PathElement
{
    private DoubleProperty y;
    
    public VLineTo() {
        this.y = new DoublePropertyBase() {
            public void invalidated() {
                VLineTo.this.u();
            }
            
            @Override
            public Object getBean() {
                return VLineTo.this;
            }
            
            @Override
            public String getName() {
                return "y";
            }
        };
        VLineToHelper.initHelper(this);
    }
    
    public VLineTo(final double y) {
        this.y = new DoublePropertyBase() {
            public void invalidated() {
                VLineTo.this.u();
            }
            
            @Override
            public Object getBean() {
                return VLineTo.this;
            }
            
            @Override
            public String getName() {
                return "y";
            }
        };
        this.setY(y);
        VLineToHelper.initHelper(this);
    }
    
    public final void setY(final double n) {
        this.y.set(n);
    }
    
    public final double getY() {
        return this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        return this.y;
    }
    
    @Override
    void addTo(final NGPath ngPath) {
        if (this.isAbsolute()) {
            ngPath.addLineTo(ngPath.getCurrentX(), (float)this.getY());
        }
        else {
            ngPath.addLineTo(ngPath.getCurrentX(), (float)(ngPath.getCurrentY() + this.getY()));
        }
    }
    
    private void doAddTo(final Path2D path2D) {
        if (this.isAbsolute()) {
            path2D.lineTo(path2D.getCurrentX(), (float)this.getY());
        }
        else {
            path2D.lineTo(path2D.getCurrentX(), (float)(path2D.getCurrentY() + this.getY()));
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("VLineTo[");
        sb.append("y=").append(this.getY());
        return sb.append("]").toString();
    }
    
    static {
        VLineToHelper.setVLineToAccessor(new VLineToHelper.VLineToAccessor() {
            @Override
            public void doAddTo(final PathElement pathElement, final Path2D path2D) {
                ((VLineTo)pathElement).doAddTo(path2D);
            }
        });
    }
}
