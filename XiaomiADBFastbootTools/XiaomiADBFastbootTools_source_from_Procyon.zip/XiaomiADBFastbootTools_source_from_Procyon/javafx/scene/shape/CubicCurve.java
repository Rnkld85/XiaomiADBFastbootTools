// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import javafx.scene.paint.Paint;
import com.sun.javafx.sg.prism.NGCubicCurve;
import com.sun.javafx.sg.prism.NGNode;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.scene.shape.CubicCurveHelper;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.geom.CubicCurve2D;

public class CubicCurve extends Shape
{
    private final CubicCurve2D shape;
    private DoubleProperty startX;
    private DoubleProperty startY;
    private DoubleProperty controlX1;
    private DoubleProperty controlY1;
    private DoubleProperty controlX2;
    private DoubleProperty controlY2;
    private DoubleProperty endX;
    private DoubleProperty endY;
    
    public CubicCurve() {
        this.shape = new CubicCurve2D();
        CubicCurveHelper.initHelper(this);
    }
    
    public CubicCurve(final double startX, final double startY, final double controlX1, final double controlY1, final double controlX2, final double controlY2, final double endX, final double endY) {
        this.shape = new CubicCurve2D();
        CubicCurveHelper.initHelper(this);
        this.setStartX(startX);
        this.setStartY(startY);
        this.setControlX1(controlX1);
        this.setControlY1(controlY1);
        this.setControlX2(controlX2);
        this.setControlY2(controlY2);
        this.setEndX(endX);
        this.setEndY(endY);
    }
    
    public final void setStartX(final double n) {
        if (this.startX != null || n != 0.0) {
            this.startXProperty().set(n);
        }
    }
    
    public final double getStartX() {
        return (this.startX == null) ? 0.0 : this.startX.get();
    }
    
    public final DoubleProperty startXProperty() {
        if (this.startX == null) {
            this.startX = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(CubicCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(CubicCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return CubicCurve.this;
                }
                
                @Override
                public String getName() {
                    return "startX";
                }
            };
        }
        return this.startX;
    }
    
    public final void setStartY(final double n) {
        if (this.startY != null || n != 0.0) {
            this.startYProperty().set(n);
        }
    }
    
    public final double getStartY() {
        return (this.startY == null) ? 0.0 : this.startY.get();
    }
    
    public final DoubleProperty startYProperty() {
        if (this.startY == null) {
            this.startY = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(CubicCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(CubicCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return CubicCurve.this;
                }
                
                @Override
                public String getName() {
                    return "startY";
                }
            };
        }
        return this.startY;
    }
    
    public final void setControlX1(final double n) {
        if (this.controlX1 != null || n != 0.0) {
            this.controlX1Property().set(n);
        }
    }
    
    public final double getControlX1() {
        return (this.controlX1 == null) ? 0.0 : this.controlX1.get();
    }
    
    public final DoubleProperty controlX1Property() {
        if (this.controlX1 == null) {
            this.controlX1 = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(CubicCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(CubicCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return CubicCurve.this;
                }
                
                @Override
                public String getName() {
                    return "controlX1";
                }
            };
        }
        return this.controlX1;
    }
    
    public final void setControlY1(final double n) {
        if (this.controlY1 != null || n != 0.0) {
            this.controlY1Property().set(n);
        }
    }
    
    public final double getControlY1() {
        return (this.controlY1 == null) ? 0.0 : this.controlY1.get();
    }
    
    public final DoubleProperty controlY1Property() {
        if (this.controlY1 == null) {
            this.controlY1 = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(CubicCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(CubicCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return CubicCurve.this;
                }
                
                @Override
                public String getName() {
                    return "controlY1";
                }
            };
        }
        return this.controlY1;
    }
    
    public final void setControlX2(final double n) {
        if (this.controlX2 != null || n != 0.0) {
            this.controlX2Property().set(n);
        }
    }
    
    public final double getControlX2() {
        return (this.controlX2 == null) ? 0.0 : this.controlX2.get();
    }
    
    public final DoubleProperty controlX2Property() {
        if (this.controlX2 == null) {
            this.controlX2 = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(CubicCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(CubicCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return CubicCurve.this;
                }
                
                @Override
                public String getName() {
                    return "controlX2";
                }
            };
        }
        return this.controlX2;
    }
    
    public final void setControlY2(final double n) {
        if (this.controlY2 != null || n != 0.0) {
            this.controlY2Property().set(n);
        }
    }
    
    public final double getControlY2() {
        return (this.controlY2 == null) ? 0.0 : this.controlY2.get();
    }
    
    public final DoubleProperty controlY2Property() {
        if (this.controlY2 == null) {
            this.controlY2 = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(CubicCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(CubicCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return CubicCurve.this;
                }
                
                @Override
                public String getName() {
                    return "controlY2";
                }
            };
        }
        return this.controlY2;
    }
    
    public final void setEndX(final double n) {
        if (this.endX != null || n != 0.0) {
            this.endXProperty().set(n);
        }
    }
    
    public final double getEndX() {
        return (this.endX == null) ? 0.0 : this.endX.get();
    }
    
    public final DoubleProperty endXProperty() {
        if (this.endX == null) {
            this.endX = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(CubicCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(CubicCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return CubicCurve.this;
                }
                
                @Override
                public String getName() {
                    return "endX";
                }
            };
        }
        return this.endX;
    }
    
    public final void setEndY(final double n) {
        if (this.endY != null || n != 0.0) {
            this.endYProperty().set(n);
        }
    }
    
    public final double getEndY() {
        return (this.endY == null) ? 0.0 : this.endY.get();
    }
    
    public final DoubleProperty endYProperty() {
        if (this.endY == null) {
            this.endY = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(CubicCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(CubicCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return CubicCurve.this;
                }
                
                @Override
                public String getName() {
                    return "endY";
                }
            };
        }
        return this.endY;
    }
    
    private CubicCurve2D doConfigShape() {
        this.shape.x1 = (float)this.getStartX();
        this.shape.y1 = (float)this.getStartY();
        this.shape.ctrlx1 = (float)this.getControlX1();
        this.shape.ctrly1 = (float)this.getControlY1();
        this.shape.ctrlx2 = (float)this.getControlX2();
        this.shape.ctrly2 = (float)this.getControlY2();
        this.shape.x2 = (float)this.getEndX();
        this.shape.y2 = (float)this.getEndY();
        return this.shape;
    }
    
    private NGNode doCreatePeer() {
        return new NGCubicCurve();
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.NODE_GEOMETRY)) {
            NodeHelper.getPeer(this).updateCubicCurve((float)this.getStartX(), (float)this.getStartY(), (float)this.getEndX(), (float)this.getEndY(), (float)this.getControlX1(), (float)this.getControlY1(), (float)this.getControlX2(), (float)this.getControlY2());
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CubicCurve[");
        final String id = this.getId();
        if (id != null) {
            sb.append("id=").append(id).append(", ");
        }
        sb.append("startX=").append(this.getStartX());
        sb.append(", startY=").append(this.getStartY());
        sb.append(", controlX1=").append(this.getControlX1());
        sb.append(", controlY1=").append(this.getControlY1());
        sb.append(", controlX2=").append(this.getControlX2());
        sb.append(", controlY2=").append(this.getControlY2());
        sb.append(", endX=").append(this.getEndX());
        sb.append(", endY=").append(this.getEndY());
        sb.append(", fill=").append(this.getFill());
        final Paint stroke = this.getStroke();
        if (stroke != null) {
            sb.append(", stroke=").append(stroke);
            sb.append(", strokeWidth=").append(this.getStrokeWidth());
        }
        return sb.append("]").toString();
    }
    
    static {
        CubicCurveHelper.setCubicCurveAccessor(new CubicCurveHelper.CubicCurveAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((CubicCurve)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((CubicCurve)node).doUpdatePeer();
            }
            
            @Override
            public com.sun.javafx.geom.Shape doConfigShape(final Shape shape) {
                return ((CubicCurve)shape).doConfigShape();
            }
        });
    }
}
