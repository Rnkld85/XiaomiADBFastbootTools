// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import javafx.scene.paint.Paint;
import com.sun.javafx.scene.shape.ShapeHelper;
import com.sun.javafx.sg.prism.NGShape;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.sg.prism.NGPolyline;
import com.sun.javafx.sg.prism.NGNode;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import javafx.scene.paint.Color;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import com.sun.javafx.scene.shape.PolylineHelper;
import javafx.collections.ObservableList;
import com.sun.javafx.geom.Path2D;

public class Polyline extends Shape
{
    private final Path2D shape;
    private final ObservableList<Double> points;
    
    public Polyline() {
        this.shape = new Path2D();
        PolylineHelper.initHelper(this);
        ((StyleableProperty)this.fillProperty()).applyStyle(null, null);
        ((StyleableProperty)this.strokeProperty()).applyStyle(null, Color.BLACK);
        this.points = new TrackableObservableList<Double>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Double> change) {
                NodeHelper.markDirty(Polyline.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Polyline.this);
            }
        };
    }
    
    public Polyline(final double... array) {
        this.shape = new Path2D();
        PolylineHelper.initHelper(this);
        ((StyleableProperty)this.fillProperty()).applyStyle(null, null);
        ((StyleableProperty)this.strokeProperty()).applyStyle(null, Color.BLACK);
        this.points = new TrackableObservableList<Double>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Double> change) {
                NodeHelper.markDirty(Polyline.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Polyline.this);
            }
        };
        if (array != null) {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.getPoints().add(array[i]);
            }
        }
    }
    
    public final ObservableList<Double> getPoints() {
        return this.points;
    }
    
    private NGNode doCreatePeer() {
        return new NGPolyline();
    }
    
    private BaseBounds doComputeGeomBounds(final BaseBounds baseBounds, final BaseTransform baseTransform) {
        if (this.getMode() == NGShape.Mode.EMPTY || this.getPoints().size() <= 1) {
            return baseBounds.makeEmpty();
        }
        if (this.getPoints().size() != 2) {
            return this.computeShapeBounds(baseBounds, baseTransform, ShapeHelper.configShape(this));
        }
        if (this.getMode() == NGShape.Mode.FILL || this.getStrokeType() == StrokeType.INSIDE) {
            return baseBounds.makeEmpty();
        }
        double strokeWidth = this.getStrokeWidth();
        if (this.getStrokeType() == StrokeType.CENTERED) {
            strokeWidth /= 2.0;
        }
        return this.computeBounds(baseBounds, baseTransform, strokeWidth, 0.5, this.getPoints().get(0), this.getPoints().get(1), 0.0, 0.0);
    }
    
    private Path2D doConfigShape() {
        final double doubleValue = this.getPoints().get(0);
        final double doubleValue2 = this.getPoints().get(1);
        this.shape.reset();
        this.shape.moveTo((float)doubleValue, (float)doubleValue2);
        for (int n = this.getPoints().size() & 0xFFFFFFFE, i = 2; i < n; i += 2) {
            this.shape.lineTo((float)(double)this.getPoints().get(i), (float)(double)this.getPoints().get(i + 1));
        }
        return this.shape;
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.NODE_GEOMETRY)) {
            final int n = this.getPoints().size() & 0xFFFFFFFE;
            final float[] array = new float[n];
            for (int i = 0; i < n; ++i) {
                array[i] = (float)(double)this.getPoints().get(i);
            }
            NodeHelper.getPeer(this).updatePolyline(array);
        }
    }
    
    private Paint doCssGetFillInitialValue() {
        return null;
    }
    
    private Paint doCssGetStrokeInitialValue() {
        return Color.BLACK;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Polyline[");
        final String id = this.getId();
        if (id != null) {
            sb.append("id=").append(id).append(", ");
        }
        sb.append("points=").append(this.getPoints());
        sb.append(", fill=").append(this.getFill());
        final Paint stroke = this.getStroke();
        if (stroke != null) {
            sb.append(", stroke=").append(stroke);
            sb.append(", strokeWidth=").append(this.getStrokeWidth());
        }
        return sb.append("]").toString();
    }
    
    static {
        PolylineHelper.setPolylineAccessor(new PolylineHelper.PolylineAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((Polyline)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((Polyline)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Polyline)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public Paint doCssGetFillInitialValue(final Shape shape) {
                return ((Polyline)shape).doCssGetFillInitialValue();
            }
            
            @Override
            public Paint doCssGetStrokeInitialValue(final Shape shape) {
                return ((Polyline)shape).doCssGetStrokeInitialValue();
            }
            
            @Override
            public com.sun.javafx.geom.Shape doConfigShape(final Shape shape) {
                return ((Polyline)shape).doConfigShape();
            }
        });
    }
}
