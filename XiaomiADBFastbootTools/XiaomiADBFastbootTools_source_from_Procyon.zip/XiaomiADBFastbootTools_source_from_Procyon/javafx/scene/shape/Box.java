// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import javafx.geometry.Point3D;
import com.sun.javafx.geom.Vec3d;
import javafx.geometry.Point2D;
import com.sun.javafx.scene.input.PickResultChooser;
import com.sun.javafx.geom.PickRay;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.sg.prism.NGTriangleMesh;
import com.sun.javafx.sg.prism.NGBox;
import com.sun.javafx.sg.prism.NGNode;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.property.SimpleDoubleProperty;
import com.sun.javafx.scene.shape.BoxHelper;
import javafx.beans.property.DoubleProperty;

public class Box extends Shape3D
{
    private TriangleMesh mesh;
    public static final double DEFAULT_SIZE = 2.0;
    private DoubleProperty depth;
    private DoubleProperty height;
    private DoubleProperty width;
    
    public Box() {
        this(2.0, 2.0, 2.0);
    }
    
    public Box(final double width, final double height, final double depth) {
        BoxHelper.initHelper(this);
        this.setWidth(width);
        this.setHeight(height);
        this.setDepth(depth);
    }
    
    public final void setDepth(final double n) {
        this.depthProperty().set(n);
    }
    
    public final double getDepth() {
        return (this.depth == null) ? 2.0 : this.depth.get();
    }
    
    public final DoubleProperty depthProperty() {
        if (this.depth == null) {
            this.depth = new SimpleDoubleProperty(this, "depth", 2.0) {
                public void invalidated() {
                    NodeHelper.markDirty(Box.this, DirtyBits.MESH_GEOM);
                    Box.this.manager.invalidateBoxMesh(Box.this.key);
                    Box.this.key = null;
                    NodeHelper.geomChanged(Box.this);
                }
            };
        }
        return this.depth;
    }
    
    public final void setHeight(final double n) {
        this.heightProperty().set(n);
    }
    
    public final double getHeight() {
        return (this.height == null) ? 2.0 : this.height.get();
    }
    
    public final DoubleProperty heightProperty() {
        if (this.height == null) {
            this.height = new SimpleDoubleProperty(this, "height", 2.0) {
                public void invalidated() {
                    NodeHelper.markDirty(Box.this, DirtyBits.MESH_GEOM);
                    Box.this.manager.invalidateBoxMesh(Box.this.key);
                    Box.this.key = null;
                    NodeHelper.geomChanged(Box.this);
                }
            };
        }
        return this.height;
    }
    
    public final void setWidth(final double n) {
        this.widthProperty().set(n);
    }
    
    public final double getWidth() {
        return (this.width == null) ? 2.0 : this.width.get();
    }
    
    public final DoubleProperty widthProperty() {
        if (this.width == null) {
            this.width = new SimpleDoubleProperty(this, "width", 2.0) {
                public void invalidated() {
                    NodeHelper.markDirty(Box.this, DirtyBits.MESH_GEOM);
                    Box.this.manager.invalidateBoxMesh(Box.this.key);
                    Box.this.key = null;
                    NodeHelper.geomChanged(Box.this);
                }
            };
        }
        return this.width;
    }
    
    private NGNode doCreatePeer() {
        return new NGBox();
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.MESH_GEOM)) {
            final NGBox ngBox = NodeHelper.getPeer(this);
            final float n = (float)this.getWidth();
            final float n2 = (float)this.getHeight();
            final float n3 = (float)this.getDepth();
            if (n < 0.0f || n2 < 0.0f || n3 < 0.0f) {
                ngBox.updateMesh(null);
            }
            else {
                if (this.key == null) {
                    this.key = new BoxKey((double)n, (double)n2, (double)n3);
                }
                (this.mesh = this.manager.getBoxMesh(n, n2, n3, this.key)).updatePG();
                ngBox.updateMesh(this.mesh.getPGTriangleMesh());
            }
        }
    }
    
    private BaseBounds doComputeGeomBounds(BaseBounds baseBounds, final BaseTransform baseTransform) {
        final float n = (float)this.getWidth();
        final float n2 = (float)this.getHeight();
        final float n3 = (float)this.getDepth();
        if (n < 0.0f || n2 < 0.0f || n3 < 0.0f) {
            return baseBounds.makeEmpty();
        }
        final float n4 = n * 0.5f;
        final float n5 = n2 * 0.5f;
        final float n6 = n3 * 0.5f;
        baseBounds = baseBounds.deriveWithNewBounds(-n4, -n5, -n6, n4, n5, n6);
        baseBounds = baseTransform.transform(baseBounds, baseBounds);
        return baseBounds;
    }
    
    private boolean doComputeContains(final double n, final double n2) {
        final double width = this.getWidth();
        final double height = this.getHeight();
        return -width <= n && n <= width && -height <= n2 && n2 <= height;
    }
    
    private boolean doComputeIntersects(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        final double width = this.getWidth();
        final double height = this.getHeight();
        final double depth = this.getDepth();
        final double n = width / 2.0;
        final double n2 = height / 2.0;
        final double n3 = depth / 2.0;
        final Vec3d directionNoClone = pickRay.getDirectionNoClone();
        final double v = (directionNoClone.x == 0.0) ? Double.POSITIVE_INFINITY : (1.0 / directionNoClone.x);
        final double v2 = (directionNoClone.y == 0.0) ? Double.POSITIVE_INFINITY : (1.0 / directionNoClone.y);
        final double v3 = (directionNoClone.z == 0.0) ? Double.POSITIVE_INFINITY : (1.0 / directionNoClone.z);
        final Vec3d originNoClone = pickRay.getOriginNoClone();
        final double x = originNoClone.x;
        final double y = originNoClone.y;
        final double z = originNoClone.z;
        final boolean b = v < 0.0;
        final boolean b2 = v2 < 0.0;
        final boolean b3 = v3 < 0.0;
        double n4 = Double.NEGATIVE_INFINITY;
        double n5 = Double.POSITIVE_INFINITY;
        int n6 = 48;
        int n7 = 48;
        if (Double.isInfinite(v)) {
            if (-n > x || n < x) {
                return false;
            }
        }
        else {
            n4 = ((b ? n : (-n)) - x) * v;
            n5 = ((b ? (-n) : n) - x) * v;
            n6 = (b ? 88 : 120);
            n7 = (b ? 120 : 88);
        }
        if (Double.isInfinite(v2)) {
            if (-n2 > y || n2 < y) {
                return false;
            }
        }
        else {
            final double n8 = ((b2 ? n2 : (-n2)) - y) * v2;
            final double n9 = ((b2 ? (-n2) : n2) - y) * v2;
            if (n4 > n9 || n8 > n5) {
                return false;
            }
            if (n8 > n4) {
                n6 = (b2 ? 89 : 121);
                n4 = n8;
            }
            if (n9 < n5) {
                n7 = (b2 ? 121 : 89);
                n5 = n9;
            }
        }
        if (Double.isInfinite(v3)) {
            if (-n3 > z || n3 < z) {
                return false;
            }
        }
        else {
            final double n10 = ((b3 ? n3 : (-n3)) - z) * v3;
            final double n11 = ((b3 ? (-n3) : n3) - z) * v3;
            if (n4 > n11 || n10 > n5) {
                return false;
            }
            if (n10 > n4) {
                n6 = (b3 ? 90 : 122);
                n4 = n10;
            }
            if (n11 < n5) {
                n7 = (b3 ? 122 : 90);
                n5 = n11;
            }
        }
        int n12 = n6;
        double n13 = n4;
        final CullFace cullFace = this.getCullFace();
        final double nearClip = pickRay.getNearClip();
        final double farClip = pickRay.getFarClip();
        if (n4 > farClip) {
            return false;
        }
        if (n4 < nearClip || cullFace == CullFace.FRONT) {
            if (n5 < nearClip || n5 > farClip || cullFace == CullFace.BACK) {
                return false;
            }
            n12 = n7;
            n13 = n5;
        }
        if (Double.isInfinite(n13) || Double.isNaN(n13)) {
            return false;
        }
        if (pickResultChooser != null && pickResultChooser.isCloser(n13)) {
            final Point3D computePoint = PickResultChooser.computePoint(pickRay, n13);
            Point2D point2D = null;
            switch (n12) {
                case 120: {
                    point2D = new Point2D(0.5 - computePoint.getZ() / depth, 0.5 + computePoint.getY() / height);
                    break;
                }
                case 88: {
                    point2D = new Point2D(0.5 + computePoint.getZ() / depth, 0.5 + computePoint.getY() / height);
                    break;
                }
                case 121: {
                    point2D = new Point2D(0.5 + computePoint.getX() / width, 0.5 - computePoint.getZ() / depth);
                    break;
                }
                case 89: {
                    point2D = new Point2D(0.5 + computePoint.getX() / width, 0.5 + computePoint.getZ() / depth);
                    break;
                }
                case 122: {
                    point2D = new Point2D(0.5 + computePoint.getX() / width, 0.5 + computePoint.getY() / height);
                    break;
                }
                case 90: {
                    point2D = new Point2D(0.5 - computePoint.getX() / width, 0.5 + computePoint.getY() / height);
                    break;
                }
                default: {
                    return false;
                }
            }
            pickResultChooser.offer(this, n13, -1, computePoint, point2D);
        }
        return true;
    }
    
    static TriangleMesh createMesh(final float n, final float n2, final float n3) {
        final float n4 = n / 2.0f;
        final float n5 = n2 / 2.0f;
        final float n6 = n3 / 2.0f;
        final float[] all = { -n4, -n5, -n6, n4, -n5, -n6, n4, n5, -n6, -n4, n5, -n6, -n4, -n5, n6, n4, -n5, n6, n4, n5, n6, -n4, n5, n6 };
        final float[] all2 = { 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f };
        final int[] all3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        final int[] all4 = { 0, 0, 2, 2, 1, 1, 2, 2, 0, 0, 3, 3, 1, 0, 6, 2, 5, 1, 6, 2, 1, 0, 2, 3, 5, 0, 7, 2, 4, 1, 7, 2, 5, 0, 6, 3, 4, 0, 3, 2, 0, 1, 3, 2, 4, 0, 7, 3, 3, 0, 6, 2, 2, 1, 6, 2, 3, 0, 7, 3, 4, 0, 1, 2, 5, 1, 1, 2, 4, 0, 0, 3 };
        final TriangleMesh triangleMesh = new TriangleMesh(true);
        triangleMesh.getPoints().setAll(all);
        triangleMesh.getTexCoords().setAll(all2);
        triangleMesh.getFaces().setAll(all4);
        triangleMesh.getFaceSmoothingGroups().setAll(all3);
        return triangleMesh;
    }
    
    static {
        BoxHelper.setBoxAccessor(new BoxHelper.BoxAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((Box)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((Box)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Box)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public boolean doComputeContains(final Node node, final double n, final double n2) {
                return ((Box)node).doComputeContains(n, n2);
            }
            
            @Override
            public boolean doComputeIntersects(final Node node, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                return ((Box)node).doComputeIntersects(pickRay, pickResultChooser);
            }
        });
    }
    
    private static class BoxKey extends Key
    {
        final double width;
        final double height;
        final double depth;
        
        private BoxKey(final double width, final double height, final double depth) {
            this.width = width;
            this.height = height;
            this.depth = depth;
        }
        
        @Override
        public int hashCode() {
            return Long.hashCode(31L * (31L * (31L * 7L + Double.doubleToLongBits(this.depth)) + Double.doubleToLongBits(this.height)) + Double.doubleToLongBits(this.width));
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null) {
                return false;
            }
            if (!(o instanceof BoxKey)) {
                return false;
            }
            final BoxKey boxKey = (BoxKey)o;
            return Double.compare(this.depth, boxKey.depth) == 0 && Double.compare(this.height, boxKey.height) == 0 && Double.compare(this.width, boxKey.width) == 0;
        }
    }
}
