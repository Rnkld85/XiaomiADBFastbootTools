// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import javafx.scene.paint.Paint;
import com.sun.javafx.sg.prism.NGQuadCurve;
import com.sun.javafx.sg.prism.NGNode;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.scene.shape.QuadCurveHelper;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.geom.QuadCurve2D;

public class QuadCurve extends Shape
{
    private final QuadCurve2D shape;
    private DoubleProperty startX;
    private DoubleProperty startY;
    private DoubleProperty controlX;
    private DoubleProperty controlY;
    private DoubleProperty endX;
    private DoubleProperty endY;
    
    public QuadCurve() {
        this.shape = new QuadCurve2D();
        QuadCurveHelper.initHelper(this);
        this.controlX = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(QuadCurve.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(QuadCurve.this);
            }
            
            @Override
            public Object getBean() {
                return QuadCurve.this;
            }
            
            @Override
            public String getName() {
                return "controlX";
            }
        };
        this.controlY = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(QuadCurve.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(QuadCurve.this);
            }
            
            @Override
            public Object getBean() {
                return QuadCurve.this;
            }
            
            @Override
            public String getName() {
                return "controlY";
            }
        };
    }
    
    public QuadCurve(final double startX, final double startY, final double controlX, final double controlY, final double endX, final double endY) {
        this.shape = new QuadCurve2D();
        QuadCurveHelper.initHelper(this);
        this.controlX = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(QuadCurve.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(QuadCurve.this);
            }
            
            @Override
            public Object getBean() {
                return QuadCurve.this;
            }
            
            @Override
            public String getName() {
                return "controlX";
            }
        };
        this.controlY = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(QuadCurve.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(QuadCurve.this);
            }
            
            @Override
            public Object getBean() {
                return QuadCurve.this;
            }
            
            @Override
            public String getName() {
                return "controlY";
            }
        };
        this.setStartX(startX);
        this.setStartY(startY);
        this.setControlX(controlX);
        this.setControlY(controlY);
        this.setEndX(endX);
        this.setEndY(endY);
    }
    
    public final void setStartX(final double n) {
        if (this.startX != null || n != 0.0) {
            this.startXProperty().set(n);
        }
    }
    
    public final double getStartX() {
        return (this.startX == null) ? 0.0 : this.startX.get();
    }
    
    public final DoubleProperty startXProperty() {
        if (this.startX == null) {
            this.startX = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(QuadCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(QuadCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return QuadCurve.this;
                }
                
                @Override
                public String getName() {
                    return "startX";
                }
            };
        }
        return this.startX;
    }
    
    public final void setStartY(final double n) {
        if (this.startY != null || n != 0.0) {
            this.startYProperty().set(n);
        }
    }
    
    public final double getStartY() {
        return (this.startY == null) ? 0.0 : this.startY.get();
    }
    
    public final DoubleProperty startYProperty() {
        if (this.startY == null) {
            this.startY = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(QuadCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(QuadCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return QuadCurve.this;
                }
                
                @Override
                public String getName() {
                    return "startY";
                }
            };
        }
        return this.startY;
    }
    
    public final void setControlX(final double n) {
        this.controlX.set(n);
    }
    
    public final double getControlX() {
        return this.controlX.get();
    }
    
    public final DoubleProperty controlXProperty() {
        return this.controlX;
    }
    
    public final void setControlY(final double n) {
        this.controlY.set(n);
    }
    
    public final double getControlY() {
        return this.controlY.get();
    }
    
    public final DoubleProperty controlYProperty() {
        return this.controlY;
    }
    
    public final void setEndX(final double n) {
        if (this.endX != null || n != 0.0) {
            this.endXProperty().set(n);
        }
    }
    
    public final double getEndX() {
        return (this.endX == null) ? 0.0 : this.endX.get();
    }
    
    public final DoubleProperty endXProperty() {
        if (this.endX == null) {
            this.endX = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(QuadCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(QuadCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return QuadCurve.this;
                }
                
                @Override
                public String getName() {
                    return "endX";
                }
            };
        }
        return this.endX;
    }
    
    public final void setEndY(final double n) {
        if (this.endY != null || n != 0.0) {
            this.endYProperty().set(n);
        }
    }
    
    public final double getEndY() {
        return (this.endY == null) ? 0.0 : this.endY.get();
    }
    
    public final DoubleProperty endYProperty() {
        if (this.endY == null) {
            this.endY = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(QuadCurve.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(QuadCurve.this);
                }
                
                @Override
                public Object getBean() {
                    return QuadCurve.this;
                }
                
                @Override
                public String getName() {
                    return "endY";
                }
            };
        }
        return this.endY;
    }
    
    private NGNode doCreatePeer() {
        return new NGQuadCurve();
    }
    
    private QuadCurve2D doConfigShape() {
        this.shape.x1 = (float)this.getStartX();
        this.shape.y1 = (float)this.getStartY();
        this.shape.ctrlx = (float)this.getControlX();
        this.shape.ctrly = (float)this.getControlY();
        this.shape.x2 = (float)this.getEndX();
        this.shape.y2 = (float)this.getEndY();
        return this.shape;
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.NODE_GEOMETRY)) {
            NodeHelper.getPeer(this).updateQuadCurve((float)this.getStartX(), (float)this.getStartY(), (float)this.getEndX(), (float)this.getEndY(), (float)this.getControlX(), (float)this.getControlY());
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("QuadCurve[");
        final String id = this.getId();
        if (id != null) {
            sb.append("id=").append(id).append(", ");
        }
        sb.append("startX=").append(this.getStartX());
        sb.append(", startY=").append(this.getStartY());
        sb.append(", controlX=").append(this.getControlX());
        sb.append(", controlY=").append(this.getControlY());
        sb.append(", endX=").append(this.getEndX());
        sb.append(", endY=").append(this.getEndY());
        sb.append(", fill=").append(this.getFill());
        final Paint stroke = this.getStroke();
        if (stroke != null) {
            sb.append(", stroke=").append(stroke);
            sb.append(", strokeWidth=").append(this.getStrokeWidth());
        }
        return sb.append("]").toString();
    }
    
    static {
        QuadCurveHelper.setQuadCurveAccessor(new QuadCurveHelper.QuadCurveAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((QuadCurve)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((QuadCurve)node).doUpdatePeer();
            }
            
            @Override
            public com.sun.javafx.geom.Shape doConfigShape(final Shape shape) {
                return ((QuadCurve)shape).doConfigShape();
            }
        });
    }
}
