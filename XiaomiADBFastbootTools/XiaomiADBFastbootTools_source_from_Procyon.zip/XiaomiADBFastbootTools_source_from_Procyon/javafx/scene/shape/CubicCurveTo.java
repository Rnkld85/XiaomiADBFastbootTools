// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.geom.Path2D;
import com.sun.javafx.sg.prism.NGPath;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.scene.shape.CubicCurveToHelper;
import javafx.beans.property.DoubleProperty;

public class CubicCurveTo extends PathElement
{
    private DoubleProperty controlX1;
    private DoubleProperty controlY1;
    private DoubleProperty controlX2;
    private DoubleProperty controlY2;
    private DoubleProperty x;
    private DoubleProperty y;
    
    public CubicCurveTo() {
        CubicCurveToHelper.initHelper(this);
    }
    
    public CubicCurveTo(final double controlX1, final double controlY1, final double controlX2, final double controlY2, final double x, final double y) {
        this.setControlX1(controlX1);
        this.setControlY1(controlY1);
        this.setControlX2(controlX2);
        this.setControlY2(controlY2);
        this.setX(x);
        this.setY(y);
        CubicCurveToHelper.initHelper(this);
    }
    
    public final void setControlX1(final double n) {
        if (this.controlX1 != null || n != 0.0) {
            this.controlX1Property().set(n);
        }
    }
    
    public final double getControlX1() {
        return (this.controlX1 == null) ? 0.0 : this.controlX1.get();
    }
    
    public final DoubleProperty controlX1Property() {
        if (this.controlX1 == null) {
            this.controlX1 = new DoublePropertyBase() {
                public void invalidated() {
                    CubicCurveTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return CubicCurveTo.this;
                }
                
                @Override
                public String getName() {
                    return "controlX1";
                }
            };
        }
        return this.controlX1;
    }
    
    public final void setControlY1(final double n) {
        if (this.controlY1 != null || n != 0.0) {
            this.controlY1Property().set(n);
        }
    }
    
    public final double getControlY1() {
        return (this.controlY1 == null) ? 0.0 : this.controlY1.get();
    }
    
    public final DoubleProperty controlY1Property() {
        if (this.controlY1 == null) {
            this.controlY1 = new DoublePropertyBase() {
                public void invalidated() {
                    CubicCurveTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return CubicCurveTo.this;
                }
                
                @Override
                public String getName() {
                    return "controlY1";
                }
            };
        }
        return this.controlY1;
    }
    
    public final void setControlX2(final double n) {
        if (this.controlX2 != null || n != 0.0) {
            this.controlX2Property().set(n);
        }
    }
    
    public final double getControlX2() {
        return (this.controlX2 == null) ? 0.0 : this.controlX2.get();
    }
    
    public final DoubleProperty controlX2Property() {
        if (this.controlX2 == null) {
            this.controlX2 = new DoublePropertyBase() {
                public void invalidated() {
                    CubicCurveTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return CubicCurveTo.this;
                }
                
                @Override
                public String getName() {
                    return "controlX2";
                }
            };
        }
        return this.controlX2;
    }
    
    public final void setControlY2(final double n) {
        if (this.controlY2 != null || n != 0.0) {
            this.controlY2Property().set(n);
        }
    }
    
    public final double getControlY2() {
        return (this.controlY2 == null) ? 0.0 : this.controlY2.get();
    }
    
    public final DoubleProperty controlY2Property() {
        if (this.controlY2 == null) {
            this.controlY2 = new DoublePropertyBase() {
                public void invalidated() {
                    CubicCurveTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return CubicCurveTo.this;
                }
                
                @Override
                public String getName() {
                    return "controlY2";
                }
            };
        }
        return this.controlY2;
    }
    
    public final void setX(final double n) {
        if (this.x != null || n != 0.0) {
            this.xProperty().set(n);
        }
    }
    
    public final double getX() {
        return (this.x == null) ? 0.0 : this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        if (this.x == null) {
            this.x = new DoublePropertyBase() {
                public void invalidated() {
                    CubicCurveTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return CubicCurveTo.this;
                }
                
                @Override
                public String getName() {
                    return "x";
                }
            };
        }
        return this.x;
    }
    
    public final void setY(final double n) {
        if (this.y != null || n != 0.0) {
            this.yProperty().set(n);
        }
    }
    
    public final double getY() {
        return (this.y == null) ? 0.0 : this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        if (this.y == null) {
            this.y = new DoublePropertyBase() {
                public void invalidated() {
                    CubicCurveTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return CubicCurveTo.this;
                }
                
                @Override
                public String getName() {
                    return "y";
                }
            };
        }
        return this.y;
    }
    
    @Override
    void addTo(final NGPath ngPath) {
        if (this.isAbsolute()) {
            ngPath.addCubicTo((float)this.getControlX1(), (float)this.getControlY1(), (float)this.getControlX2(), (float)this.getControlY2(), (float)this.getX(), (float)this.getY());
        }
        else {
            final double n = ngPath.getCurrentX();
            final double n2 = ngPath.getCurrentY();
            ngPath.addCubicTo((float)(this.getControlX1() + n), (float)(this.getControlY1() + n2), (float)(this.getControlX2() + n), (float)(this.getControlY2() + n2), (float)(this.getX() + n), (float)(this.getY() + n2));
        }
    }
    
    private void doAddTo(final Path2D path2D) {
        if (this.isAbsolute()) {
            path2D.curveTo((float)this.getControlX1(), (float)this.getControlY1(), (float)this.getControlX2(), (float)this.getControlY2(), (float)this.getX(), (float)this.getY());
        }
        else {
            final double n = path2D.getCurrentX();
            final double n2 = path2D.getCurrentY();
            path2D.curveTo((float)(this.getControlX1() + n), (float)(this.getControlY1() + n2), (float)(this.getControlX2() + n), (float)(this.getControlY2() + n2), (float)(this.getX() + n), (float)(this.getY() + n2));
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CubicCurveTo[");
        sb.append("x=").append(this.getX());
        sb.append(", y=").append(this.getY());
        sb.append(", controlX1=").append(this.getControlX1());
        sb.append(", controlY1=").append(this.getControlY1());
        sb.append(", controlX2=").append(this.getControlX2());
        sb.append(", controlY2=").append(this.getControlY2());
        return sb.append("]").toString();
    }
    
    static {
        CubicCurveToHelper.setCubicCurveToAccessor(new CubicCurveToHelper.CubicCurveToAccessor() {
            @Override
            public void doAddTo(final PathElement pathElement, final Path2D path2D) {
                ((CubicCurveTo)pathElement).doAddTo(path2D);
            }
        });
    }
}
