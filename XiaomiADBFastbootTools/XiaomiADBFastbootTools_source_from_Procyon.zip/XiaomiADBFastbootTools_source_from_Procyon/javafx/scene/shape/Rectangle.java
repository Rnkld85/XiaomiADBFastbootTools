// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import com.sun.javafx.scene.shape.ShapeHelper;
import com.sun.javafx.sg.prism.NGShape;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import javafx.css.Styleable;
import java.util.List;
import com.sun.javafx.sg.prism.NGRectangle;
import com.sun.javafx.sg.prism.NGNode;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.scene.paint.Paint;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.scene.shape.RectangleHelper;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.geom.RoundRectangle2D;

public class Rectangle extends Shape
{
    private final RoundRectangle2D shape;
    private static final int NON_RECTILINEAR_TYPE_MASK = -80;
    private DoubleProperty x;
    private DoubleProperty y;
    private final DoubleProperty width;
    private final DoubleProperty height;
    private DoubleProperty arcWidth;
    private DoubleProperty arcHeight;
    
    public Rectangle() {
        this.shape = new RoundRectangle2D();
        RectangleHelper.initHelper(this);
        this.width = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Rectangle.this);
            }
            
            @Override
            public Object getBean() {
                return Rectangle.this;
            }
            
            @Override
            public String getName() {
                return "width";
            }
        };
        this.height = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Rectangle.this);
            }
            
            @Override
            public Object getBean() {
                return Rectangle.this;
            }
            
            @Override
            public String getName() {
                return "height";
            }
        };
    }
    
    public Rectangle(final double width, final double height) {
        this.shape = new RoundRectangle2D();
        RectangleHelper.initHelper(this);
        this.width = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Rectangle.this);
            }
            
            @Override
            public Object getBean() {
                return Rectangle.this;
            }
            
            @Override
            public String getName() {
                return "width";
            }
        };
        this.height = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Rectangle.this);
            }
            
            @Override
            public Object getBean() {
                return Rectangle.this;
            }
            
            @Override
            public String getName() {
                return "height";
            }
        };
        this.setWidth(width);
        this.setHeight(height);
    }
    
    public Rectangle(final double width, final double height, final Paint fill) {
        this.shape = new RoundRectangle2D();
        RectangleHelper.initHelper(this);
        this.width = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Rectangle.this);
            }
            
            @Override
            public Object getBean() {
                return Rectangle.this;
            }
            
            @Override
            public String getName() {
                return "width";
            }
        };
        this.height = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Rectangle.this);
            }
            
            @Override
            public Object getBean() {
                return Rectangle.this;
            }
            
            @Override
            public String getName() {
                return "height";
            }
        };
        this.setWidth(width);
        this.setHeight(height);
        this.setFill(fill);
    }
    
    public Rectangle(final double x, final double y, final double n, final double n2) {
        this(n, n2);
        this.setX(x);
        this.setY(y);
    }
    
    public final void setX(final double n) {
        if (this.x != null || n != 0.0) {
            this.xProperty().set(n);
        }
    }
    
    public final double getX() {
        return (this.x == null) ? 0.0 : this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        if (this.x == null) {
            this.x = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(Rectangle.this);
                }
                
                @Override
                public Object getBean() {
                    return Rectangle.this;
                }
                
                @Override
                public String getName() {
                    return "x";
                }
            };
        }
        return this.x;
    }
    
    public final void setY(final double n) {
        if (this.y != null || n != 0.0) {
            this.yProperty().set(n);
        }
    }
    
    public final double getY() {
        return (this.y == null) ? 0.0 : this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        if (this.y == null) {
            this.y = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(Rectangle.this);
                }
                
                @Override
                public Object getBean() {
                    return Rectangle.this;
                }
                
                @Override
                public String getName() {
                    return "y";
                }
            };
        }
        return this.y;
    }
    
    public final void setWidth(final double n) {
        this.width.set(n);
    }
    
    public final double getWidth() {
        return this.width.get();
    }
    
    public final DoubleProperty widthProperty() {
        return this.width;
    }
    
    public final void setHeight(final double n) {
        this.height.set(n);
    }
    
    public final double getHeight() {
        return this.height.get();
    }
    
    public final DoubleProperty heightProperty() {
        return this.height;
    }
    
    public final void setArcWidth(final double n) {
        if (this.arcWidth != null || n != 0.0) {
            this.arcWidthProperty().set(n);
        }
    }
    
    public final double getArcWidth() {
        return (this.arcWidth == null) ? 0.0 : this.arcWidth.get();
    }
    
    public final DoubleProperty arcWidthProperty() {
        if (this.arcWidth == null) {
            this.arcWidth = new StyleableDoubleProperty() {
                public void invalidated() {
                    NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                }
                
                @Override
                public CssMetaData<Rectangle, Number> getCssMetaData() {
                    return StyleableProperties.ARC_WIDTH;
                }
                
                @Override
                public Object getBean() {
                    return Rectangle.this;
                }
                
                @Override
                public String getName() {
                    return "arcWidth";
                }
            };
        }
        return this.arcWidth;
    }
    
    public final void setArcHeight(final double n) {
        if (this.arcHeight != null || n != 0.0) {
            this.arcHeightProperty().set(n);
        }
    }
    
    public final double getArcHeight() {
        return (this.arcHeight == null) ? 0.0 : this.arcHeight.get();
    }
    
    public final DoubleProperty arcHeightProperty() {
        if (this.arcHeight == null) {
            this.arcHeight = new StyleableDoubleProperty() {
                public void invalidated() {
                    NodeHelper.markDirty(Rectangle.this, DirtyBits.NODE_GEOMETRY);
                }
                
                @Override
                public CssMetaData<Rectangle, Number> getCssMetaData() {
                    return StyleableProperties.ARC_HEIGHT;
                }
                
                @Override
                public Object getBean() {
                    return Rectangle.this;
                }
                
                @Override
                public String getName() {
                    return "arcHeight";
                }
            };
        }
        return this.arcHeight;
    }
    
    private NGNode doCreatePeer() {
        return new NGRectangle();
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    StrokeLineJoin convertLineJoin(final StrokeLineJoin strokeLineJoin) {
        if (this.getArcWidth() > 0.0 && this.getArcHeight() > 0.0) {
            return StrokeLineJoin.BEVEL;
        }
        return strokeLineJoin;
    }
    
    private BaseBounds doComputeGeomBounds(final BaseBounds baseBounds, final BaseTransform baseTransform) {
        if (this.getMode() == NGShape.Mode.EMPTY) {
            return baseBounds.makeEmpty();
        }
        if (this.getArcWidth() > 0.0 && this.getArcHeight() > 0.0 && (baseTransform.getType() & 0xFFFFFFB0) != 0x0) {
            return this.computeShapeBounds(baseBounds, baseTransform, ShapeHelper.configShape(this));
        }
        double strokeWidth;
        double n;
        if (this.getMode() == NGShape.Mode.FILL || this.getStrokeType() == StrokeType.INSIDE) {
            n = (strokeWidth = 0.0);
        }
        else {
            strokeWidth = this.getStrokeWidth();
            if (this.getStrokeType() == StrokeType.CENTERED) {
                strokeWidth /= 2.0;
            }
            n = 0.0;
        }
        return this.computeBounds(baseBounds, baseTransform, strokeWidth, n, this.getX(), this.getY(), this.getWidth(), this.getHeight());
    }
    
    private RoundRectangle2D doConfigShape() {
        if (this.getArcWidth() > 0.0 && this.getArcHeight() > 0.0) {
            this.shape.setRoundRect((float)this.getX(), (float)this.getY(), (float)this.getWidth(), (float)this.getHeight(), (float)this.getArcWidth(), (float)this.getArcHeight());
        }
        else {
            this.shape.setRoundRect((float)this.getX(), (float)this.getY(), (float)this.getWidth(), (float)this.getHeight(), 0.0f, 0.0f);
        }
        return this.shape;
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.NODE_GEOMETRY)) {
            NodeHelper.getPeer(this).updateRectangle((float)this.getX(), (float)this.getY(), (float)this.getWidth(), (float)this.getHeight(), (float)this.getArcWidth(), (float)this.getArcHeight());
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Rectangle[");
        final String id = this.getId();
        if (id != null) {
            sb.append("id=").append(id).append(", ");
        }
        sb.append("x=").append(this.getX());
        sb.append(", y=").append(this.getY());
        sb.append(", width=").append(this.getWidth());
        sb.append(", height=").append(this.getHeight());
        sb.append(", fill=").append(this.getFill());
        final Paint stroke = this.getStroke();
        if (stroke != null) {
            sb.append(", stroke=").append(stroke);
            sb.append(", strokeWidth=").append(this.getStrokeWidth());
        }
        return sb.append("]").toString();
    }
    
    static {
        RectangleHelper.setRectangleAccessor(new RectangleHelper.RectangleAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((Rectangle)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((Rectangle)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Rectangle)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public com.sun.javafx.geom.Shape doConfigShape(final Shape shape) {
                return ((Rectangle)shape).doConfigShape();
            }
        });
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Rectangle, Number> ARC_HEIGHT;
        private static final CssMetaData<Rectangle, Number> ARC_WIDTH;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            ARC_HEIGHT = new CssMetaData<Rectangle, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final Rectangle rectangle) {
                    return rectangle.arcHeight == null || !rectangle.arcHeight.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Rectangle rectangle) {
                    return (StyleableProperty<Number>)rectangle.arcHeightProperty();
                }
            };
            ARC_WIDTH = new CssMetaData<Rectangle, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final Rectangle rectangle) {
                    return rectangle.arcWidth == null || !rectangle.arcWidth.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Rectangle rectangle) {
                    return (StyleableProperty<Number>)rectangle.arcWidthProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Shape.getClassCssMetaData());
            list.add(StyleableProperties.ARC_HEIGHT);
            list.add(StyleableProperties.ARC_WIDTH);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
