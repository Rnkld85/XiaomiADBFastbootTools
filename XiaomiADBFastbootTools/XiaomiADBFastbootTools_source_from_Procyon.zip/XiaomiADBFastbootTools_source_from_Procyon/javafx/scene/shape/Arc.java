// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import javafx.scene.paint.Paint;
import com.sun.javafx.sg.prism.NGArc;
import com.sun.javafx.sg.prism.NGNode;
import javafx.beans.property.ObjectPropertyBase;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.scene.shape.ArcHelper;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.geom.Arc2D;

public class Arc extends Shape
{
    private final Arc2D shape;
    private DoubleProperty centerX;
    private DoubleProperty centerY;
    private final DoubleProperty radiusX;
    private final DoubleProperty radiusY;
    private DoubleProperty startAngle;
    private final DoubleProperty length;
    private ObjectProperty<ArcType> type;
    
    public Arc() {
        this.shape = new Arc2D();
        ArcHelper.initHelper(this);
        this.radiusX = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Arc.this);
            }
            
            @Override
            public Object getBean() {
                return Arc.this;
            }
            
            @Override
            public String getName() {
                return "radiusX";
            }
        };
        this.radiusY = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Arc.this);
            }
            
            @Override
            public Object getBean() {
                return Arc.this;
            }
            
            @Override
            public String getName() {
                return "radiusY";
            }
        };
        this.length = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Arc.this);
            }
            
            @Override
            public Object getBean() {
                return Arc.this;
            }
            
            @Override
            public String getName() {
                return "length";
            }
        };
    }
    
    public Arc(final double centerX, final double centerY, final double radiusX, final double radiusY, final double startAngle, final double length) {
        this.shape = new Arc2D();
        ArcHelper.initHelper(this);
        this.radiusX = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Arc.this);
            }
            
            @Override
            public Object getBean() {
                return Arc.this;
            }
            
            @Override
            public String getName() {
                return "radiusX";
            }
        };
        this.radiusY = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Arc.this);
            }
            
            @Override
            public Object getBean() {
                return Arc.this;
            }
            
            @Override
            public String getName() {
                return "radiusY";
            }
        };
        this.length = new DoublePropertyBase() {
            public void invalidated() {
                NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Arc.this);
            }
            
            @Override
            public Object getBean() {
                return Arc.this;
            }
            
            @Override
            public String getName() {
                return "length";
            }
        };
        this.setCenterX(centerX);
        this.setCenterY(centerY);
        this.setRadiusX(radiusX);
        this.setRadiusY(radiusY);
        this.setStartAngle(startAngle);
        this.setLength(length);
    }
    
    public final void setCenterX(final double n) {
        if (this.centerX != null || n != 0.0) {
            this.centerXProperty().set(n);
        }
    }
    
    public final double getCenterX() {
        return (this.centerX == null) ? 0.0 : this.centerX.get();
    }
    
    public final DoubleProperty centerXProperty() {
        if (this.centerX == null) {
            this.centerX = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(Arc.this);
                }
                
                @Override
                public Object getBean() {
                    return Arc.this;
                }
                
                @Override
                public String getName() {
                    return "centerX";
                }
            };
        }
        return this.centerX;
    }
    
    public final void setCenterY(final double n) {
        if (this.centerY != null || n != 0.0) {
            this.centerYProperty().set(n);
        }
    }
    
    public final double getCenterY() {
        return (this.centerY == null) ? 0.0 : this.centerY.get();
    }
    
    public final DoubleProperty centerYProperty() {
        if (this.centerY == null) {
            this.centerY = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(Arc.this);
                }
                
                @Override
                public Object getBean() {
                    return Arc.this;
                }
                
                @Override
                public String getName() {
                    return "centerY";
                }
            };
        }
        return this.centerY;
    }
    
    public final void setRadiusX(final double n) {
        this.radiusX.set(n);
    }
    
    public final double getRadiusX() {
        return this.radiusX.get();
    }
    
    public final DoubleProperty radiusXProperty() {
        return this.radiusX;
    }
    
    public final void setRadiusY(final double n) {
        this.radiusY.set(n);
    }
    
    public final double getRadiusY() {
        return this.radiusY.get();
    }
    
    public final DoubleProperty radiusYProperty() {
        return this.radiusY;
    }
    
    public final void setStartAngle(final double n) {
        if (this.startAngle != null || n != 0.0) {
            this.startAngleProperty().set(n);
        }
    }
    
    public final double getStartAngle() {
        return (this.startAngle == null) ? 0.0 : this.startAngle.get();
    }
    
    public final DoubleProperty startAngleProperty() {
        if (this.startAngle == null) {
            this.startAngle = new DoublePropertyBase() {
                public void invalidated() {
                    NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(Arc.this);
                }
                
                @Override
                public Object getBean() {
                    return Arc.this;
                }
                
                @Override
                public String getName() {
                    return "startAngle";
                }
            };
        }
        return this.startAngle;
    }
    
    public final void setLength(final double n) {
        this.length.set(n);
    }
    
    public final double getLength() {
        return this.length.get();
    }
    
    public final DoubleProperty lengthProperty() {
        return this.length;
    }
    
    public final void setType(final ArcType arcType) {
        if (this.type != null || arcType != ArcType.OPEN) {
            this.typeProperty().set(arcType);
        }
    }
    
    public final ArcType getType() {
        return (this.type == null) ? ArcType.OPEN : this.type.get();
    }
    
    public final ObjectProperty<ArcType> typeProperty() {
        if (this.type == null) {
            this.type = new ObjectPropertyBase<ArcType>(ArcType.OPEN) {
                public void invalidated() {
                    NodeHelper.markDirty(Arc.this, DirtyBits.NODE_GEOMETRY);
                    NodeHelper.geomChanged(Arc.this);
                }
                
                @Override
                public Object getBean() {
                    return Arc.this;
                }
                
                @Override
                public String getName() {
                    return "type";
                }
            };
        }
        return this.type;
    }
    
    private NGNode doCreatePeer() {
        return new NGArc();
    }
    
    private Arc2D doConfigShape() {
        int n = 0;
        switch (this.getTypeInternal()) {
            case OPEN: {
                n = 0;
                break;
            }
            case CHORD: {
                n = 1;
                break;
            }
            default: {
                n = 2;
                break;
            }
        }
        this.shape.setArc((float)(this.getCenterX() - this.getRadiusX()), (float)(this.getCenterY() - this.getRadiusY()), (float)(this.getRadiusX() * 2.0), (float)(this.getRadiusY() * 2.0), (float)this.getStartAngle(), (float)this.getLength(), n);
        return this.shape;
    }
    
    private final ArcType getTypeInternal() {
        final ArcType type = this.getType();
        return (type == null) ? ArcType.OPEN : type;
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.NODE_GEOMETRY)) {
            NodeHelper.getPeer(this).updateArc((float)this.getCenterX(), (float)this.getCenterY(), (float)this.getRadiusX(), (float)this.getRadiusY(), (float)this.getStartAngle(), (float)this.getLength(), this.getTypeInternal());
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Arc[");
        final String id = this.getId();
        if (id != null) {
            sb.append("id=").append(id).append(", ");
        }
        sb.append("centerX=").append(this.getCenterX());
        sb.append(", centerY=").append(this.getCenterY());
        sb.append(", radiusX=").append(this.getRadiusX());
        sb.append(", radiusY=").append(this.getRadiusY());
        sb.append(", startAngle=").append(this.getStartAngle());
        sb.append(", length=").append(this.getLength());
        sb.append(", type=").append(this.getType());
        sb.append(", fill=").append(this.getFill());
        final Paint stroke = this.getStroke();
        if (stroke != null) {
            sb.append(", stroke=").append(stroke);
            sb.append(", strokeWidth=").append(this.getStrokeWidth());
        }
        return sb.append("]").toString();
    }
    
    static {
        ArcHelper.setArcAccessor(new ArcHelper.ArcAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((Arc)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((Arc)node).doUpdatePeer();
            }
            
            @Override
            public com.sun.javafx.geom.Shape doConfigShape(final Shape shape) {
                return ((Arc)shape).doConfigShape();
            }
        });
    }
}
