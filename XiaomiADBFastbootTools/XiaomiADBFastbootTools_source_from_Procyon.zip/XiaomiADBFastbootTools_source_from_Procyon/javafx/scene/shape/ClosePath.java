// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.geom.Path2D;
import com.sun.javafx.sg.prism.NGPath;
import com.sun.javafx.scene.shape.ClosePathHelper;

public class ClosePath extends PathElement
{
    public ClosePath() {
        ClosePathHelper.initHelper(this);
    }
    
    @Override
    void addTo(final NGPath ngPath) {
        ngPath.addClosePath();
    }
    
    private void doAddTo(final Path2D path2D) {
        path2D.closePath();
    }
    
    @Override
    public String toString() {
        return "ClosePath";
    }
    
    static {
        ClosePathHelper.setClosePathAccessor(new ClosePathHelper.ClosePathAccessor() {
            @Override
            public void doAddTo(final PathElement pathElement, final Path2D path2D) {
                ((ClosePath)pathElement).doAddTo(path2D);
            }
        });
    }
}
