// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import javafx.scene.paint.Paint;
import com.sun.javafx.scene.shape.ShapeHelper;
import com.sun.javafx.sg.prism.NGShape;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.sg.prism.NGPolygon;
import com.sun.javafx.sg.prism.NGNode;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import com.sun.javafx.scene.shape.PolygonHelper;
import javafx.collections.ObservableList;
import com.sun.javafx.geom.Path2D;

public class Polygon extends Shape
{
    private final Path2D shape;
    private final ObservableList<Double> points;
    
    public Polygon() {
        this.shape = new Path2D();
        PolygonHelper.initHelper(this);
        this.points = new TrackableObservableList<Double>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Double> change) {
                NodeHelper.markDirty(Polygon.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Polygon.this);
            }
        };
    }
    
    public Polygon(final double... array) {
        this.shape = new Path2D();
        PolygonHelper.initHelper(this);
        this.points = new TrackableObservableList<Double>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Double> change) {
                NodeHelper.markDirty(Polygon.this, DirtyBits.NODE_GEOMETRY);
                NodeHelper.geomChanged(Polygon.this);
            }
        };
        if (array != null) {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.getPoints().add(array[i]);
            }
        }
    }
    
    public final ObservableList<Double> getPoints() {
        return this.points;
    }
    
    private NGNode doCreatePeer() {
        return new NGPolygon();
    }
    
    private BaseBounds doComputeGeomBounds(final BaseBounds baseBounds, final BaseTransform baseTransform) {
        if (this.getMode() == NGShape.Mode.EMPTY || this.getPoints().size() <= 1) {
            return baseBounds.makeEmpty();
        }
        if (this.getPoints().size() != 2) {
            return this.computeShapeBounds(baseBounds, baseTransform, ShapeHelper.configShape(this));
        }
        if (this.getMode() == NGShape.Mode.FILL || this.getStrokeType() == StrokeType.INSIDE) {
            return baseBounds.makeEmpty();
        }
        double strokeWidth = this.getStrokeWidth();
        if (this.getStrokeType() == StrokeType.CENTERED) {
            strokeWidth /= 2.0;
        }
        return this.computeBounds(baseBounds, baseTransform, strokeWidth, 0.5, this.getPoints().get(0), this.getPoints().get(1), 0.0, 0.0);
    }
    
    private Path2D doConfigShape() {
        final double doubleValue = this.getPoints().get(0);
        final double doubleValue2 = this.getPoints().get(1);
        this.shape.reset();
        this.shape.moveTo((float)doubleValue, (float)doubleValue2);
        for (int n = this.getPoints().size() & 0xFFFFFFFE, i = 2; i < n; i += 2) {
            this.shape.lineTo((float)(double)this.getPoints().get(i), (float)(double)this.getPoints().get(i + 1));
        }
        this.shape.closePath();
        return this.shape;
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.NODE_GEOMETRY)) {
            final int n = this.getPoints().size() & 0xFFFFFFFE;
            final float[] array = new float[n];
            for (int i = 0; i < n; ++i) {
                array[i] = (float)(double)this.getPoints().get(i);
            }
            NodeHelper.getPeer(this).updatePolygon(array);
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Polygon[");
        final String id = this.getId();
        if (id != null) {
            sb.append("id=").append(id).append(", ");
        }
        sb.append("points=").append(this.getPoints());
        sb.append(", fill=").append(this.getFill());
        final Paint stroke = this.getStroke();
        if (stroke != null) {
            sb.append(", stroke=").append(stroke);
            sb.append(", strokeWidth=").append(this.getStrokeWidth());
        }
        return sb.append("]").toString();
    }
    
    static {
        PolygonHelper.setPolygonAccessor(new PolygonHelper.PolygonAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((Polygon)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((Polygon)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Polygon)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public com.sun.javafx.geom.Shape doConfigShape(final Shape shape) {
                return ((Polygon)shape).doConfigShape();
            }
        });
    }
}
