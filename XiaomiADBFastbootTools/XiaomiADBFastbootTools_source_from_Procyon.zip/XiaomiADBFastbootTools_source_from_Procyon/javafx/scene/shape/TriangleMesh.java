// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import javafx.collections.ArrayChangeListener;
import javafx.collections.ObservableArray;
import javafx.scene.transform.NonInvertibleTransformException;
import javafx.scene.transform.Transform;
import javafx.scene.transform.Affine;
import javafx.scene.transform.Rotate;
import com.sun.javafx.scene.input.PickResultChooser;
import javafx.scene.Node;
import com.sun.javafx.geom.Vec3d;
import com.sun.javafx.geom.PickRay;
import javafx.geometry.Point2D;
import javafx.geometry.Point3D;
import com.sun.javafx.geom.BoxBounds;
import com.sun.javafx.collections.IntegerArraySyncer;
import com.sun.javafx.collections.FloatArraySyncer;
import com.sun.javafx.logging.PlatformLogger;
import javafx.beans.property.SimpleObjectProperty;
import com.sun.javafx.scene.shape.ObservableFaceArrayImpl;
import javafx.collections.FXCollections;
import com.sun.javafx.scene.shape.TriangleMeshHelper;
import com.sun.javafx.sg.prism.NGTriangleMesh;
import javafx.beans.property.ObjectProperty;
import com.sun.javafx.geom.BaseBounds;
import javafx.collections.ObservableIntegerArray;
import javafx.collections.ObservableFloatArray;

public class TriangleMesh extends Mesh
{
    private final ObservableFloatArray points;
    private final ObservableFloatArray normals;
    private final ObservableFloatArray texCoords;
    private final ObservableFaceArray faces;
    private final ObservableIntegerArray faceSmoothingGroups;
    private final Listener pointsSyncer;
    private final Listener normalsSyncer;
    private final Listener texCoordsSyncer;
    private final Listener facesSyncer;
    private final Listener faceSmoothingGroupsSyncer;
    private final boolean isPredefinedShape;
    private boolean isValidDirty;
    private boolean isPointsValid;
    private boolean isNormalsValid;
    private boolean isTexCoordsValid;
    private boolean isFacesValid;
    private boolean isFaceSmoothingGroupValid;
    private int refCount;
    private BaseBounds cachedBounds;
    private ObjectProperty<VertexFormat> vertexFormat;
    private NGTriangleMesh peer;
    
    public TriangleMesh() {
        this(false);
        TriangleMeshHelper.initHelper(this);
    }
    
    public TriangleMesh(final VertexFormat vertexFormat) {
        this(false);
        this.setVertexFormat(vertexFormat);
        TriangleMeshHelper.initHelper(this);
    }
    
    TriangleMesh(final boolean isPredefinedShape) {
        this.points = FXCollections.observableFloatArray();
        this.normals = FXCollections.observableFloatArray();
        this.texCoords = FXCollections.observableFloatArray();
        this.faces = new ObservableFaceArrayImpl();
        this.faceSmoothingGroups = FXCollections.observableIntegerArray();
        this.pointsSyncer = new Listener((T)this.points);
        this.normalsSyncer = new Listener((T)this.normals);
        this.texCoordsSyncer = new Listener((T)this.texCoords);
        this.facesSyncer = new Listener((T)this.faces);
        this.faceSmoothingGroupsSyncer = new Listener((T)this.faceSmoothingGroups);
        this.isValidDirty = true;
        this.refCount = 1;
        this.isPredefinedShape = isPredefinedShape;
        if (isPredefinedShape) {
            this.isPointsValid = true;
            this.isNormalsValid = true;
            this.isTexCoordsValid = true;
            this.isFacesValid = true;
            this.isFaceSmoothingGroupValid = true;
        }
        else {
            this.isPointsValid = false;
            this.isNormalsValid = false;
            this.isTexCoordsValid = false;
            this.isFacesValid = false;
            this.isFaceSmoothingGroupValid = false;
        }
        TriangleMeshHelper.initHelper(this);
    }
    
    public final void setVertexFormat(final VertexFormat vertexFormat) {
        this.vertexFormatProperty().set(vertexFormat);
    }
    
    public final VertexFormat getVertexFormat() {
        return (this.vertexFormat == null) ? VertexFormat.POINT_TEXCOORD : this.vertexFormat.get();
    }
    
    public final ObjectProperty<VertexFormat> vertexFormatProperty() {
        if (this.vertexFormat == null) {
            this.vertexFormat = new SimpleObjectProperty<VertexFormat>(this, "vertexFormat") {
                @Override
                protected void invalidated() {
                    TriangleMesh.this.setDirty(true);
                    TriangleMesh.this.facesSyncer.setDirty(true);
                    TriangleMesh.this.faceSmoothingGroupsSyncer.setDirty(true);
                }
            };
        }
        return this.vertexFormat;
    }
    
    public final int getPointElementSize() {
        return this.getVertexFormat().getPointElementSize();
    }
    
    public final int getNormalElementSize() {
        return this.getVertexFormat().getNormalElementSize();
    }
    
    public final int getTexCoordElementSize() {
        return this.getVertexFormat().getTexCoordElementSize();
    }
    
    public final int getFaceElementSize() {
        return this.getVertexFormat().getVertexIndexSize() * 3;
    }
    
    public final ObservableFloatArray getPoints() {
        return this.points;
    }
    
    public final ObservableFloatArray getNormals() {
        return this.normals;
    }
    
    public final ObservableFloatArray getTexCoords() {
        return this.texCoords;
    }
    
    public final ObservableFaceArray getFaces() {
        return this.faces;
    }
    
    public final ObservableIntegerArray getFaceSmoothingGroups() {
        return this.faceSmoothingGroups;
    }
    
    @Override
    void setDirty(final boolean dirty) {
        super.setDirty(dirty);
        if (!dirty) {
            this.pointsSyncer.setDirty(false);
            this.normalsSyncer.setDirty(false);
            this.texCoordsSyncer.setDirty(false);
            this.facesSyncer.setDirty(false);
            this.faceSmoothingGroupsSyncer.setDirty(false);
        }
    }
    
    int getRefCount() {
        return this.refCount;
    }
    
    synchronized void incRef() {
        ++this.refCount;
    }
    
    synchronized void decRef() {
        --this.refCount;
    }
    
    NGTriangleMesh getPGTriangleMesh() {
        if (this.peer == null) {
            this.peer = new NGTriangleMesh();
        }
        return this.peer;
    }
    
    @Override
    NGTriangleMesh getPGMesh() {
        return this.getPGTriangleMesh();
    }
    
    private boolean validatePoints() {
        if (this.points.size() == 0) {
            return false;
        }
        if (this.points.size() % this.getVertexFormat().getPointElementSize() != 0) {
            PlatformLogger.getLogger(TriangleMesh.class.getName()).warning("points.size() has to be divisible by getPointElementSize(). It is to store multiple x, y, and z coordinates of this mesh");
            return false;
        }
        return true;
    }
    
    private boolean validateNormals() {
        if (this.getVertexFormat() != VertexFormat.POINT_NORMAL_TEXCOORD) {
            return true;
        }
        if (this.normals.size() == 0) {
            return false;
        }
        if (this.normals.size() % this.getVertexFormat().getNormalElementSize() != 0) {
            PlatformLogger.getLogger(TriangleMesh.class.getName()).warning("normals.size() has to be divisible by getNormalElementSize(). It is to store multiple nx, ny, and nz coordinates of this mesh");
            return false;
        }
        return true;
    }
    
    private boolean validateTexCoords() {
        if (this.texCoords.size() == 0) {
            return false;
        }
        if (this.texCoords.size() % this.getVertexFormat().getTexCoordElementSize() != 0) {
            PlatformLogger.getLogger(TriangleMesh.class.getName()).warning("texCoords.size() has to be divisible by getTexCoordElementSize(). It is to store multiple u and v texture coordinates of this mesh");
            return false;
        }
        return true;
    }
    
    private boolean validateFaces() {
        if (this.faces.size() == 0) {
            return false;
        }
        final String name = TriangleMesh.class.getName();
        if (this.faces.size() % this.getFaceElementSize() != 0) {
            PlatformLogger.getLogger(name).warning("faces.size() has to be divisible by getFaceElementSize().");
            return false;
        }
        if (this.getVertexFormat() == VertexFormat.POINT_TEXCOORD) {
            final int n = this.points.size() / this.getVertexFormat().getPointElementSize();
            final int n2 = this.texCoords.size() / this.getVertexFormat().getTexCoordElementSize();
            for (int i = 0; i < this.faces.size(); ++i) {
                if ((i % 2 == 0 && (this.faces.get(i) >= n || this.faces.get(i) < 0)) || (i % 2 != 0 && (this.faces.get(i) >= n2 || this.faces.get(i) < 0))) {
                    PlatformLogger.getLogger(name).warning("The values in the faces array must be within the range of the number of vertices in the points array (0 to points.length / 3 - 1) for the point indices and within the range of the number of the vertices in the texCoords array (0 to texCoords.length / 2 - 1) for the texture coordinate indices.");
                    return false;
                }
            }
        }
        else {
            if (this.getVertexFormat() != VertexFormat.POINT_NORMAL_TEXCOORD) {
                PlatformLogger.getLogger(name).warning(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.getVertexFormat().toString()));
                return false;
            }
            final int n3 = this.points.size() / this.getVertexFormat().getPointElementSize();
            final int n4 = this.normals.size() / this.getVertexFormat().getNormalElementSize();
            final int n5 = this.texCoords.size() / this.getVertexFormat().getTexCoordElementSize();
            for (int j = 0; j < this.faces.size(); j += 3) {
                if (this.faces.get(j) >= n3 || this.faces.get(j) < 0 || this.faces.get(j + 1) >= n4 || this.faces.get(j + 1) < 0 || this.faces.get(j + 2) >= n5 || this.faces.get(j + 2) < 0) {
                    PlatformLogger.getLogger(name).warning("The values in the faces array must be within the range of the number of vertices in the points array (0 to points.length / 3 - 1) for the point indices, and within the range of the number of the vertices in the normals array (0 to normals.length / 3 - 1) for the normals indices, and number of the vertices in the texCoords array (0 to texCoords.length / 2 - 1) for the texture coordinate indices.");
                    return false;
                }
            }
        }
        return true;
    }
    
    private boolean validateFaceSmoothingGroups() {
        if (this.faceSmoothingGroups.size() != 0 && this.faceSmoothingGroups.size() != this.faces.size() / this.getFaceElementSize()) {
            PlatformLogger.getLogger(TriangleMesh.class.getName()).warning("faceSmoothingGroups.size() has to equal to number of faces.");
            return false;
        }
        return true;
    }
    
    private boolean validate() {
        if (this.isPredefinedShape) {
            return true;
        }
        if (this.isValidDirty) {
            if (this.pointsSyncer.dirtyInFull) {
                this.isPointsValid = this.validatePoints();
            }
            if (this.normalsSyncer.dirtyInFull) {
                this.isNormalsValid = this.validateNormals();
            }
            if (this.texCoordsSyncer.dirtyInFull) {
                this.isTexCoordsValid = this.validateTexCoords();
            }
            if (this.facesSyncer.dirty || this.pointsSyncer.dirtyInFull || this.normalsSyncer.dirtyInFull || this.texCoordsSyncer.dirtyInFull) {
                this.isFacesValid = (this.isPointsValid && this.isNormalsValid && this.isTexCoordsValid && this.validateFaces());
            }
            if (this.faceSmoothingGroupsSyncer.dirtyInFull || this.facesSyncer.dirtyInFull) {
                this.isFaceSmoothingGroupValid = (this.isFacesValid && this.validateFaceSmoothingGroups());
            }
            this.isValidDirty = false;
        }
        return this.isPointsValid && this.isNormalsValid && this.isTexCoordsValid && this.isFaceSmoothingGroupValid && this.isFacesValid;
    }
    
    @Override
    void updatePG() {
        if (!this.isDirty()) {
            return;
        }
        final NGTriangleMesh pgTriangleMesh = this.getPGTriangleMesh();
        if (this.validate()) {
            pgTriangleMesh.setUserDefinedNormals(this.getVertexFormat() == VertexFormat.POINT_NORMAL_TEXCOORD);
            pgTriangleMesh.syncPoints(this.pointsSyncer);
            pgTriangleMesh.syncNormals(this.normalsSyncer);
            pgTriangleMesh.syncTexCoords(this.texCoordsSyncer);
            pgTriangleMesh.syncFaces(this.facesSyncer);
            pgTriangleMesh.syncFaceSmoothingGroups(this.faceSmoothingGroupsSyncer);
        }
        else {
            pgTriangleMesh.setUserDefinedNormals(false);
            pgTriangleMesh.syncPoints(null);
            pgTriangleMesh.syncNormals(null);
            pgTriangleMesh.syncTexCoords(null);
            pgTriangleMesh.syncFaces(null);
            pgTriangleMesh.syncFaceSmoothingGroups(null);
        }
        this.setDirty(false);
    }
    
    @Override
    BaseBounds computeBounds(final BaseBounds baseBounds) {
        if (this.isDirty() || this.cachedBounds == null) {
            this.cachedBounds = new BoxBounds();
            if (this.validate()) {
                for (int size = this.points.size(), pointElementSize = this.getVertexFormat().getPointElementSize(), i = 0; i < size; i += pointElementSize) {
                    this.cachedBounds.add(this.points.get(i), this.points.get(i + 1), this.points.get(i + 2));
                }
            }
        }
        return baseBounds.deriveWithNewBounds(this.cachedBounds);
    }
    
    private Point3D computeCentroid(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final double n8, final double n9) {
        return new Point3D(n + (n7 + (n4 - n7) / 2.0 - n) / 3.0, n2 + (n8 + (n5 - n8) / 2.0 - n2) / 3.0, n3 + (n9 + (n6 - n9) / 2.0 - n3) / 3.0);
    }
    
    private Point2D computeCentroid(final Point2D point2D, final Point2D point2D2, final Point2D point2D3) {
        final Point2D subtract = point2D2.midpoint(point2D3).subtract(point2D);
        return point2D.add(new Point2D(subtract.getX() / 3.0, subtract.getY() / 3.0));
    }
    
    private boolean computeIntersectsFace(final PickRay pickRay, final Vec3d vec3d, final Vec3d vec3d2, final int n, final CullFace cullFace, final Node node, final boolean b, final PickResultChooser pickResultChooser) {
        final int vertexIndexSize = this.getVertexFormat().getVertexIndexSize();
        final int pointElementSize = this.getVertexFormat().getPointElementSize();
        final int n2 = this.faces.get(n) * pointElementSize;
        final int n3 = this.faces.get(n + vertexIndexSize) * pointElementSize;
        final int n4 = this.faces.get(n + 2 * vertexIndexSize) * pointElementSize;
        final float value = this.points.get(n2);
        final float value2 = this.points.get(n2 + 1);
        final float value3 = this.points.get(n2 + 2);
        final float value4 = this.points.get(n3);
        final float value5 = this.points.get(n3 + 1);
        final float value6 = this.points.get(n3 + 2);
        final float value7 = this.points.get(n4);
        final float value8 = this.points.get(n4 + 1);
        final float value9 = this.points.get(n4 + 2);
        final float n5 = value4 - value;
        final float n6 = value5 - value2;
        final float n7 = value6 - value3;
        final float n8 = value7 - value;
        final float n9 = value8 - value2;
        final float n10 = value9 - value3;
        final double n11 = vec3d2.y * n10 - vec3d2.z * n9;
        final double n12 = vec3d2.z * n8 - vec3d2.x * n10;
        final double n13 = vec3d2.x * n9 - vec3d2.y * n8;
        final double n14 = n5 * n11 + n6 * n12 + n7 * n13;
        if (n14 == 0.0) {
            return false;
        }
        final double n15 = 1.0 / n14;
        final double n16 = vec3d.x - value;
        final double n17 = vec3d.y - value2;
        final double n18 = vec3d.z - value3;
        final double n19 = n15 * (n16 * n11 + n17 * n12 + n18 * n13);
        if (n19 < 0.0 || n19 > 1.0) {
            return false;
        }
        final double n20 = n17 * n7 - n18 * n6;
        final double n21 = n18 * n5 - n16 * n7;
        final double n22 = n16 * n6 - n17 * n5;
        final double n23 = n15 * (vec3d2.x * n20 + vec3d2.y * n21 + vec3d2.z * n22);
        if (n23 < 0.0 || n19 + n23 > 1.0) {
            return false;
        }
        final double n24 = n15 * (n8 * n20 + n9 * n21 + n10 * n22);
        if (n24 < pickRay.getNearClip() || n24 > pickRay.getFarClip()) {
            return false;
        }
        if (cullFace != CullFace.NONE) {
            final double angle = new Point3D(n6 * n10 - n7 * n9, n7 * n8 - n5 * n10, n5 * n9 - n6 * n8).angle(new Point3D(-vec3d2.x, -vec3d2.y, -vec3d2.z));
            if ((angle >= 90.0 || cullFace != CullFace.BACK) && (angle <= 90.0 || cullFace != CullFace.FRONT)) {
                return false;
            }
        }
        if (Double.isInfinite(n24) || Double.isNaN(n24)) {
            return false;
        }
        if (pickResultChooser == null || !pickResultChooser.isCloser(n24)) {
            return true;
        }
        final Point3D computePoint = PickResultChooser.computePoint(pickRay, n24);
        final Point3D computeCentroid = this.computeCentroid(value, value2, value3, value4, value5, value6, value7, value8, value9);
        final Point3D point3D = new Point3D(value - computeCentroid.getX(), value2 - computeCentroid.getY(), value3 - computeCentroid.getZ());
        final Point3D point3D2 = new Point3D(value4 - computeCentroid.getX(), value5 - computeCentroid.getY(), value6 - computeCentroid.getZ());
        final Point3D point3D3 = new Point3D(value7 - computeCentroid.getX(), value8 - computeCentroid.getY(), value9 - computeCentroid.getZ());
        Point3D crossProduct = point3D2.subtract(point3D).crossProduct(point3D3.subtract(point3D));
        if (crossProduct.getZ() < 0.0) {
            crossProduct = new Point3D(-crossProduct.getX(), -crossProduct.getY(), -crossProduct.getZ());
        }
        final Point3D crossProduct2 = crossProduct.crossProduct(Rotate.Z_AXIS);
        final Rotate rotate = new Rotate(Math.toDegrees(Math.atan2(crossProduct2.magnitude(), crossProduct.dotProduct(Rotate.Z_AXIS))), crossProduct2);
        final Point3D transform = rotate.transform(point3D);
        final Point3D transform2 = rotate.transform(point3D2);
        final Point3D transform3 = rotate.transform(point3D3);
        final Point3D transform4 = rotate.transform(computePoint.subtract(computeCentroid));
        final Point2D point2D = new Point2D(transform.getX(), transform.getY());
        final Point2D point2D2 = new Point2D(transform2.getX(), transform2.getY());
        final Point2D point2D3 = new Point2D(transform3.getX(), transform3.getY());
        final Point2D point2D4 = new Point2D(transform4.getX(), transform4.getY());
        final int texCoordElementSize = this.getVertexFormat().getTexCoordElementSize();
        final int texCoordIndexOffset = this.getVertexFormat().getTexCoordIndexOffset();
        final int n25 = this.faces.get(n + texCoordIndexOffset) * texCoordElementSize;
        final int n26 = this.faces.get(n + vertexIndexSize + texCoordIndexOffset) * texCoordElementSize;
        final int n27 = this.faces.get(n + vertexIndexSize * 2 + texCoordIndexOffset) * texCoordElementSize;
        final Point2D point2D5 = new Point2D(this.texCoords.get(n25), this.texCoords.get(n25 + 1));
        final Point2D point2D6 = new Point2D(this.texCoords.get(n26), this.texCoords.get(n26 + 1));
        final Point2D point2D7 = new Point2D(this.texCoords.get(n27), this.texCoords.get(n27 + 1));
        final Point2D computeCentroid2 = this.computeCentroid(point2D5, point2D6, point2D7);
        final Point2D subtract = point2D5.subtract(computeCentroid2);
        final Point2D subtract2 = point2D6.subtract(computeCentroid2);
        final Point2D subtract3 = point2D7.subtract(computeCentroid2);
        final Affine affine = new Affine(point2D.getX(), point2D2.getX(), point2D3.getX(), point2D.getY(), point2D2.getY(), point2D3.getY());
        final Affine affine2 = new Affine(subtract.getX(), subtract2.getX(), subtract3.getX(), subtract.getY(), subtract2.getY(), subtract3.getY());
        Point2D add = null;
        try {
            affine.invert();
            affine2.append(affine);
            add = computeCentroid2.add(affine2.transform(point2D4));
        }
        catch (NonInvertibleTransformException ex) {}
        pickResultChooser.offer(node, n24, b ? (n / this.getFaceElementSize()) : -1, computePoint, add);
        return true;
    }
    
    private boolean doComputeIntersects(final PickRay pickRay, final PickResultChooser pickResultChooser, final Node node, final CullFace cullFace, final boolean b) {
        boolean b2 = false;
        if (this.validate()) {
            final int size = this.faces.size();
            final Vec3d originNoClone = pickRay.getOriginNoClone();
            final Vec3d directionNoClone = pickRay.getDirectionNoClone();
            for (int i = 0; i < size; i += this.getFaceElementSize()) {
                if (this.computeIntersectsFace(pickRay, originNoClone, directionNoClone, i, cullFace, node, b, pickResultChooser)) {
                    b2 = true;
                }
            }
        }
        return b2;
    }
    
    static {
        TriangleMeshHelper.setTriangleMeshAccessor(new TriangleMeshHelper.TriangleMeshAccessor() {
            @Override
            public boolean doComputeIntersects(final Mesh mesh, final PickRay pickRay, final PickResultChooser pickResultChooser, final Node node, final CullFace cullFace, final boolean b) {
                return ((TriangleMesh)mesh).doComputeIntersects(pickRay, pickResultChooser, node, cullFace, b);
            }
        });
    }
    
    private class Listener<T extends ObservableArray<T>> implements ArrayChangeListener<T>, FloatArraySyncer, IntegerArraySyncer
    {
        protected final T array;
        protected boolean dirty;
        protected boolean dirtyInFull;
        protected int dirtyRangeFrom;
        protected int dirtyRangeLength;
        
        public Listener(final T array) {
            this.dirty = true;
            this.dirtyInFull = true;
            (this.array = array).addListener(this);
        }
        
        protected final void addDirtyRange(final int n, final int dirtyRangeLength) {
            if (dirtyRangeLength > 0 && !this.dirtyInFull) {
                this.markDirty();
                if (this.dirtyRangeLength == 0) {
                    this.dirtyRangeFrom = n;
                    this.dirtyRangeLength = dirtyRangeLength;
                }
                else {
                    final int min = Math.min(this.dirtyRangeFrom, n);
                    final int max = Math.max(this.dirtyRangeFrom + this.dirtyRangeLength, n + dirtyRangeLength);
                    this.dirtyRangeFrom = min;
                    this.dirtyRangeLength = max - min;
                }
            }
        }
        
        protected void markDirty() {
            this.dirty = true;
            TriangleMesh.this.setDirty(true);
        }
        
        @Override
        public void onChanged(final T t, final boolean b, final int n, final int n2) {
            if (b) {
                this.setDirty(true);
            }
            else {
                this.addDirtyRange(n, n2 - n);
            }
            TriangleMesh.this.isValidDirty = true;
        }
        
        public final void setDirty(final boolean dirtyInFull) {
            this.dirtyInFull = dirtyInFull;
            if (dirtyInFull) {
                this.markDirty();
                this.dirtyRangeFrom = 0;
                this.dirtyRangeLength = this.array.size();
            }
            else {
                this.dirty = false;
                final int n = 0;
                this.dirtyRangeLength = n;
                this.dirtyRangeFrom = n;
            }
        }
        
        @Override
        public float[] syncTo(final float[] array, final int[] array2) {
            assert array2 != null && array2.length == 2;
            final ObservableFloatArray observableFloatArray = (ObservableFloatArray)this.array;
            if (this.dirtyInFull || array == null || array.length != observableFloatArray.size()) {
                array2[0] = 0;
                array2[1] = observableFloatArray.size();
                return observableFloatArray.toArray(null);
            }
            array2[0] = this.dirtyRangeFrom;
            array2[1] = this.dirtyRangeLength;
            observableFloatArray.copyTo(this.dirtyRangeFrom, array, this.dirtyRangeFrom, this.dirtyRangeLength);
            return array;
        }
        
        @Override
        public int[] syncTo(final int[] array, final int[] array2) {
            assert array2 != null && array2.length == 2;
            final ObservableIntegerArray observableIntegerArray = (ObservableIntegerArray)this.array;
            if (this.dirtyInFull || array == null || array.length != observableIntegerArray.size()) {
                array2[0] = 0;
                array2[1] = observableIntegerArray.size();
                return observableIntegerArray.toArray(null);
            }
            array2[0] = this.dirtyRangeFrom;
            array2[1] = this.dirtyRangeLength;
            observableIntegerArray.copyTo(this.dirtyRangeFrom, array, this.dirtyRangeFrom, this.dirtyRangeLength);
            return array;
        }
    }
}
