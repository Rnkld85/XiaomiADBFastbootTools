// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.scene.shape.MeshHelper;
import com.sun.javafx.scene.input.PickResultChooser;
import com.sun.javafx.geom.PickRay;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.sg.prism.NGNode;
import com.sun.javafx.sg.prism.NGMeshView;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.value.WeakChangeListener;
import javafx.beans.value.ChangeListener;
import javafx.beans.property.SimpleObjectProperty;
import com.sun.javafx.scene.shape.MeshViewHelper;
import javafx.beans.property.ObjectProperty;

public class MeshView extends Shape3D
{
    private ObjectProperty<Mesh> mesh;
    
    public MeshView() {
        MeshViewHelper.initHelper(this);
    }
    
    public MeshView(final Mesh mesh) {
        MeshViewHelper.initHelper(this);
        this.setMesh(mesh);
    }
    
    public final void setMesh(final Mesh mesh) {
        this.meshProperty().set(mesh);
    }
    
    public final Mesh getMesh() {
        return (this.mesh == null) ? null : this.mesh.get();
    }
    
    public final ObjectProperty<Mesh> meshProperty() {
        if (this.mesh == null) {
            this.mesh = new SimpleObjectProperty<Mesh>(this, "mesh") {
                private Mesh old = null;
                private final ChangeListener<Boolean> meshChangeListener = (p0, p1, b) -> {
                    if (b) {
                        NodeHelper.markDirty(MeshView.this, DirtyBits.MESH_GEOM);
                        NodeHelper.geomChanged(MeshView.this);
                    }
                    return;
                };
                private final WeakChangeListener<Boolean> weakMeshChangeListener = new WeakChangeListener<Boolean>(this.meshChangeListener);
                
                @Override
                protected void invalidated() {
                    if (this.old != null) {
                        this.old.dirtyProperty().removeListener(this.weakMeshChangeListener);
                    }
                    final Mesh old = this.get();
                    if (old != null) {
                        old.dirtyProperty().addListener(this.weakMeshChangeListener);
                    }
                    NodeHelper.markDirty(MeshView.this, DirtyBits.MESH);
                    NodeHelper.markDirty(MeshView.this, DirtyBits.MESH_GEOM);
                    NodeHelper.geomChanged(MeshView.this);
                    this.old = old;
                }
            };
        }
        return this.mesh;
    }
    
    private void doUpdatePeer() {
        final NGMeshView ngMeshView = NodeHelper.getPeer(this);
        if (NodeHelper.isDirty(this, DirtyBits.MESH_GEOM) && this.getMesh() != null) {
            this.getMesh().updatePG();
        }
        if (NodeHelper.isDirty(this, DirtyBits.MESH)) {
            ngMeshView.setMesh((this.getMesh() == null) ? null : this.getMesh().getPGMesh());
        }
    }
    
    private NGNode doCreatePeer() {
        return new NGMeshView();
    }
    
    private BaseBounds doComputeGeomBounds(BaseBounds baseBounds, final BaseTransform baseTransform) {
        if (this.getMesh() != null) {
            baseBounds = this.getMesh().computeBounds(baseBounds);
            baseBounds = baseTransform.transform(baseBounds, baseBounds);
        }
        else {
            baseBounds.makeEmpty();
        }
        return baseBounds;
    }
    
    private boolean doComputeContains(final double n, final double n2) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    private boolean doComputeIntersects(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        return MeshHelper.computeIntersects(this.getMesh(), pickRay, pickResultChooser, this, this.getCullFace(), true);
    }
    
    static {
        MeshViewHelper.setMeshViewAccessor(new MeshViewHelper.MeshViewAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((MeshView)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((MeshView)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((MeshView)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public boolean doComputeContains(final Node node, final double n, final double n2) {
                return ((MeshView)node).doComputeContains(n, n2);
            }
            
            @Override
            public boolean doComputeIntersects(final Node node, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                return ((MeshView)node).doComputeIntersects(pickRay, pickResultChooser);
            }
        });
    }
}
