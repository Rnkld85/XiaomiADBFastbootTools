// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import javafx.beans.property.BooleanPropertyBase;
import com.sun.javafx.sg.prism.NGPath;
import java.util.Iterator;
import javafx.scene.Node;
import javafx.beans.property.BooleanProperty;
import com.sun.javafx.util.WeakReferenceQueue;
import com.sun.javafx.scene.shape.PathElementHelper;

public abstract class PathElement
{
    private PathElementHelper pathElementHelper;
    WeakReferenceQueue nodes;
    private BooleanProperty absolute;
    
    public PathElement() {
        this.pathElementHelper = null;
        this.nodes = new WeakReferenceQueue();
    }
    
    void addNode(final Node node) {
        this.nodes.add(node);
    }
    
    void removeNode(final Node node) {
        this.nodes.remove(node);
    }
    
    void u() {
        final Iterator iterator = this.nodes.iterator();
        while (iterator.hasNext()) {
            iterator.next().markPathDirty();
        }
    }
    
    abstract void addTo(final NGPath p0);
    
    public final void setAbsolute(final boolean b) {
        this.absoluteProperty().set(b);
    }
    
    public final boolean isAbsolute() {
        return this.absolute == null || this.absolute.get();
    }
    
    public final BooleanProperty absoluteProperty() {
        if (this.absolute == null) {
            this.absolute = new BooleanPropertyBase(true) {
                @Override
                protected void invalidated() {
                    PathElement.this.u();
                }
                
                @Override
                public Object getBean() {
                    return PathElement.this;
                }
                
                @Override
                public String getName() {
                    return "absolute";
                }
            };
        }
        return this.absolute;
    }
    
    static {
        PathElementHelper.setPathElementAccessor(new PathElementHelper.PathElementAccessor() {
            @Override
            public PathElementHelper getHelper(final PathElement pathElement) {
                return pathElement.pathElementHelper;
            }
            
            @Override
            public void setHelper(final PathElement pathElement, final PathElementHelper pathElementHelper) {
                pathElement.pathElementHelper = pathElementHelper;
            }
        });
    }
}
