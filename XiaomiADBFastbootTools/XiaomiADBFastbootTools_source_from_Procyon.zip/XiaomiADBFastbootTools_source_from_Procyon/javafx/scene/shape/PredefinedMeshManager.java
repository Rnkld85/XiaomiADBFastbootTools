// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import java.util.HashMap;
import java.lang.ref.SoftReference;
import java.util.Map;

final class PredefinedMeshManager
{
    private static final int INITAL_CAPACITY = 17;
    private static final float LOAD_FACTOR = 0.75f;
    private static final PredefinedMeshManager INSTANCE;
    private TriangleMeshCache boxCache;
    private TriangleMeshCache sphereCache;
    private TriangleMeshCache cylinderCache;
    
    private PredefinedMeshManager() {
        this.boxCache = null;
        this.sphereCache = null;
        this.cylinderCache = null;
    }
    
    static PredefinedMeshManager getInstance() {
        return PredefinedMeshManager.INSTANCE;
    }
    
    synchronized TriangleMesh getBoxMesh(final float n, final float n2, final float n3, final Shape3D.Key key) {
        if (this.boxCache == null) {
            this.boxCache = BoxCacheLoader.INSTANCE;
        }
        TriangleMesh triangleMesh = this.boxCache.get(key);
        if (triangleMesh == null) {
            triangleMesh = Box.createMesh(n, n2, n3);
            this.boxCache.put(key, triangleMesh);
        }
        else {
            triangleMesh.incRef();
        }
        return triangleMesh;
    }
    
    synchronized TriangleMesh getSphereMesh(final float n, final int n2, final Shape3D.Key key) {
        if (this.sphereCache == null) {
            this.sphereCache = SphereCacheLoader.INSTANCE;
        }
        TriangleMesh triangleMesh = this.sphereCache.get(key);
        if (triangleMesh == null) {
            triangleMesh = Sphere.createMesh(n2, n);
            this.sphereCache.put(key, triangleMesh);
        }
        else {
            triangleMesh.incRef();
        }
        return triangleMesh;
    }
    
    synchronized TriangleMesh getCylinderMesh(final float n, final float n2, final int n3, final Shape3D.Key key) {
        if (this.cylinderCache == null) {
            this.cylinderCache = CylinderCacheLoader.INSTANCE;
        }
        TriangleMesh triangleMesh = this.cylinderCache.get(key);
        if (triangleMesh == null) {
            triangleMesh = Cylinder.createMesh(n3, n, n2);
            this.cylinderCache.put(key, triangleMesh);
        }
        else {
            triangleMesh.incRef();
        }
        return triangleMesh;
    }
    
    synchronized void invalidateBoxMesh(final Shape3D.Key key) {
        if (this.boxCache != null) {
            this.boxCache.invalidateMesh(key);
        }
    }
    
    synchronized void invalidateSphereMesh(final Shape3D.Key key) {
        if (this.sphereCache != null) {
            this.sphereCache.invalidateMesh(key);
        }
    }
    
    synchronized void invalidateCylinderMesh(final Shape3D.Key key) {
        if (this.cylinderCache != null) {
            this.cylinderCache.invalidateMesh(key);
        }
    }
    
    synchronized void dispose() {
        if (this.boxCache != null) {
            this.boxCache.clear();
        }
        if (this.sphereCache != null) {
            this.sphereCache.clear();
        }
        if (this.cylinderCache != null) {
            this.cylinderCache.clear();
        }
    }
    
    synchronized void printStats() {
        if (this.boxCache != null) {
            this.boxCache.printStats("BoxCache");
        }
        if (this.sphereCache != null) {
            this.sphereCache.printStats("SphereCache");
        }
        if (this.cylinderCache != null) {
            this.cylinderCache.printStats("CylinderCache");
        }
    }
    
    void test_clearCaches() {
        PredefinedMeshManager.INSTANCE.dispose();
    }
    
    int test_getBoxCacheSize() {
        return PredefinedMeshManager.INSTANCE.boxCache.size();
    }
    
    int test_getSphereCacheSize() {
        return PredefinedMeshManager.INSTANCE.sphereCache.size();
    }
    
    int test_getCylinderCacheSize() {
        return PredefinedMeshManager.INSTANCE.cylinderCache.size();
    }
    
    static {
        INSTANCE = new PredefinedMeshManager();
    }
    
    private static class TriangleMeshCache
    {
        Map<Shape3D.Key, SoftReference<TriangleMesh>> cache;
        
        private TriangleMeshCache() {
            this.cache = new HashMap<Shape3D.Key, SoftReference<TriangleMesh>>(17, 0.75f);
        }
        
        private TriangleMesh get(final Shape3D.Key key) {
            this.cleanCache();
            return this.cache.containsKey(key) ? this.cache.get(key).get() : null;
        }
        
        private void put(final Shape3D.Key key, final TriangleMesh referent) {
            this.cleanCache();
            if (referent != null) {
                this.cache.put(key, new SoftReference<TriangleMesh>(referent));
            }
        }
        
        private void cleanCache() {
            this.cache.values().removeIf(softReference -> softReference.get() == null);
        }
        
        private void clear() {
            this.cache.clear();
        }
        
        private int size() {
            this.cleanCache();
            return this.cache.size();
        }
        
        private void printStats(final String s) {
            System.out.println(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;I)Ljava/lang/String;, s, this.size()));
        }
        
        private void invalidateMesh(final Shape3D.Key key) {
            if (this.cache.containsKey(key)) {
                final TriangleMesh triangleMesh = this.cache.get(key).get();
                if (triangleMesh != null) {
                    triangleMesh.decRef();
                    if (triangleMesh.getRefCount() == 0) {
                        this.cache.remove(key);
                    }
                }
                else {
                    this.cache.remove(key);
                }
            }
        }
    }
    
    private static final class BoxCacheLoader
    {
        private static final TriangleMeshCache INSTANCE;
        
        static {
            INSTANCE = new TriangleMeshCache();
        }
    }
    
    private static final class SphereCacheLoader
    {
        private static final TriangleMeshCache INSTANCE;
        
        static {
            INSTANCE = new TriangleMeshCache();
        }
    }
    
    private static final class CylinderCacheLoader
    {
        private static final TriangleMeshCache INSTANCE;
        
        static {
            INSTANCE = new TriangleMeshCache();
        }
    }
}
