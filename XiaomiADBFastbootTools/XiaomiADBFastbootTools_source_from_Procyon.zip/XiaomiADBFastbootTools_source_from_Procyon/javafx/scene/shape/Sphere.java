// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.geom.Vec3d;
import javafx.geometry.Point2D;
import javafx.scene.transform.Rotate;
import javafx.geometry.Point3D;
import com.sun.javafx.scene.shape.MeshHelper;
import com.sun.javafx.scene.input.PickResultChooser;
import com.sun.javafx.geom.PickRay;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.sg.prism.NGTriangleMesh;
import com.sun.javafx.sg.prism.NGSphere;
import com.sun.javafx.sg.prism.NGNode;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.property.SimpleDoubleProperty;
import com.sun.javafx.scene.shape.SphereHelper;
import javafx.beans.property.DoubleProperty;

public class Sphere extends Shape3D
{
    static final int DEFAULT_DIVISIONS = 64;
    static final double DEFAULT_RADIUS = 1.0;
    private int divisions;
    private TriangleMesh mesh;
    private DoubleProperty radius;
    
    public Sphere() {
        this(1.0, 64);
    }
    
    public Sphere(final double n) {
        this(n, 64);
    }
    
    public Sphere(final double radius, final int n) {
        this.divisions = 64;
        SphereHelper.initHelper(this);
        this.divisions = ((n < 1) ? 1 : n);
        this.setRadius(radius);
    }
    
    public final void setRadius(final double n) {
        this.radiusProperty().set(n);
    }
    
    public final double getRadius() {
        return (this.radius == null) ? 1.0 : this.radius.get();
    }
    
    public final DoubleProperty radiusProperty() {
        if (this.radius == null) {
            this.radius = new SimpleDoubleProperty(this, "radius", 1.0) {
                public void invalidated() {
                    NodeHelper.markDirty(Sphere.this, DirtyBits.MESH_GEOM);
                    Sphere.this.manager.invalidateSphereMesh(Sphere.this.key);
                    Sphere.this.key = null;
                    NodeHelper.geomChanged(Sphere.this);
                }
            };
        }
        return this.radius;
    }
    
    public int getDivisions() {
        return this.divisions;
    }
    
    private NGNode doCreatePeer() {
        return new NGSphere();
    }
    
    private void doUpdatePeer() {
        if (NodeHelper.isDirty(this, DirtyBits.MESH_GEOM)) {
            final NGSphere ngSphere = NodeHelper.getPeer(this);
            final float n = (float)this.getRadius();
            if (n < 0.0f) {
                ngSphere.updateMesh(null);
            }
            else {
                if (this.key == null) {
                    this.key = new SphereKey((double)n, this.divisions);
                }
                (this.mesh = this.manager.getSphereMesh(n, this.divisions, this.key)).updatePG();
                ngSphere.updateMesh(this.mesh.getPGTriangleMesh());
            }
        }
    }
    
    private BaseBounds doComputeGeomBounds(BaseBounds baseBounds, final BaseTransform baseTransform) {
        final float n = (float)this.getRadius();
        if (n < 0.0f) {
            return baseBounds.makeEmpty();
        }
        baseBounds = baseBounds.deriveWithNewBounds(-n, -n, -n, n, n, n);
        baseBounds = baseTransform.transform(baseBounds, baseBounds);
        return baseBounds;
    }
    
    private boolean doComputeContains(final double n, final double n2) {
        final double radius = this.getRadius();
        return n * n + n2 * n2 <= radius * radius;
    }
    
    private boolean doComputeIntersects(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        final boolean b = this.divisions < 64 && this.mesh != null;
        final double radius = this.getRadius();
        final Vec3d directionNoClone = pickRay.getDirectionNoClone();
        final double x = directionNoClone.x;
        final double y = directionNoClone.y;
        final double z = directionNoClone.z;
        final Vec3d originNoClone = pickRay.getOriginNoClone();
        final double x2 = originNoClone.x;
        final double y2 = originNoClone.y;
        final double z2 = originNoClone.z;
        final double n = x * x + y * y + z * z;
        final double n2 = 2.0 * (x * x2 + y * y2 + z * z2);
        final double n3 = x2 * x2 + y2 * y2 + z2 * z2 - radius * radius;
        final double a = n2 * n2 - 4.0 * n * n3;
        if (a < 0.0) {
            return false;
        }
        final double sqrt = Math.sqrt(a);
        final double n4 = (n2 < 0.0) ? ((-n2 - sqrt) / 2.0) : ((-n2 + sqrt) / 2.0);
        double n5 = n4 / n;
        double n6 = n3 / n4;
        if (n5 > n6) {
            final double n7 = n5;
            n5 = n6;
            n6 = n7;
        }
        final double nearClip = pickRay.getNearClip();
        final double farClip = pickRay.getFarClip();
        if (n6 < nearClip || n5 > farClip) {
            return false;
        }
        double n8 = n5;
        final CullFace cullFace = this.getCullFace();
        if (n5 < nearClip || cullFace == CullFace.FRONT) {
            if (n6 <= farClip && this.getCullFace() != CullFace.BACK) {
                n8 = n6;
            }
            else if (!b) {
                return false;
            }
        }
        if (Double.isInfinite(n8) || Double.isNaN(n8)) {
            return false;
        }
        if (b) {
            return MeshHelper.computeIntersects(this.mesh, pickRay, pickResultChooser, this, cullFace, false);
        }
        if (pickResultChooser != null && pickResultChooser.isCloser(n8)) {
            final Point3D computePoint = PickResultChooser.computePoint(pickRay, n8);
            final Point3D point3D = new Point3D(computePoint.getX(), 0.0, computePoint.getZ());
            final Point3D crossProduct = point3D.crossProduct(Rotate.Z_AXIS);
            double angle = point3D.angle(Rotate.Z_AXIS);
            if (crossProduct.getY() > 0.0) {
                angle = 360.0 - angle;
            }
            pickResultChooser.offer(this, n8, -1, computePoint, new Point2D(1.0 - angle / 360.0, 0.5 + computePoint.getY() / (2.0 * radius)));
        }
        return true;
    }
    
    private static int correctDivisions(final int n) {
        return (n + 3) / 4 * 4;
    }
    
    static TriangleMesh createMesh(int correctDivisions, final float n) {
        correctDivisions = correctDivisions(correctDivisions);
        final int n2 = correctDivisions / 2;
        final int n3 = correctDivisions * (n2 - 1) + 2;
        final int n4 = (correctDivisions + 1) * (n2 - 1) + correctDivisions * 2;
        final int n5 = correctDivisions * (n2 - 2) * 2 + correctDivisions * 2;
        final float n6 = 1.0f / correctDivisions;
        final float[] all = new float[n3 * 3];
        final float[] all2 = new float[n4 * 2];
        final int[] all3 = new int[n5 * 6];
        int n7 = 0;
        int n8 = 0;
        for (int i = 0; i < n2 - 1; ++i) {
            final float n9 = n6 * (i + 1 - n2 / 2) * 2.0f * 3.1415927f;
            final float n10 = (float)Math.sin(n9);
            final float n11 = (float)Math.cos(n9);
            final float n12 = 0.5f + n10 * 0.5f;
            for (int j = 0; j < correctDivisions; ++j) {
                final double n13 = n6 * j * 2.0f * 3.1415927f;
                final float n14 = (float)Math.sin(n13);
                final float n15 = (float)Math.cos(n13);
                all[n7 + 0] = n14 * n11 * n;
                all[n7 + 2] = n15 * n11 * n;
                all[n7 + 1] = n10 * n;
                all2[n8 + 0] = 1.0f - n6 * j;
                all2[n8 + 1] = n12;
                n7 += 3;
                n8 += 2;
            }
            all2[n8 + 0] = 0.0f;
            all2[n8 + 1] = n12;
            n8 += 2;
        }
        all[n7 + 0] = 0.0f;
        all[n7 + 1] = -n;
        all[n7 + 3] = (all[n7 + 2] = 0.0f);
        all[n7 + 4] = n;
        all[n7 + 5] = 0.0f;
        n7 += 6;
        final int n16 = (n2 - 1) * correctDivisions;
        final float n17 = 0.00390625f;
        for (int k = 0; k < correctDivisions; ++k) {
            all2[n8 + 0] = 1.0f - n6 * (0.5f + k);
            all2[n8 + 1] = n17;
            n8 += 2;
        }
        for (int l = 0; l < correctDivisions; ++l) {
            all2[n8 + 0] = 1.0f - n6 * (0.5f + l);
            all2[n8 + 1] = 1.0f - n17;
            n8 += 2;
        }
        int n18 = 0;
        for (int n19 = 0; n19 < n2 - 2; ++n19) {
            for (int n20 = 0; n20 < correctDivisions; ++n20) {
                final int n21 = n19 * correctDivisions + n20;
                final int n22 = n21 + 1;
                final int n23 = n21 + correctDivisions;
                final int n24 = n22 + correctDivisions;
                final int n25 = n21 + n19;
                final int n26 = n25 + 1;
                final int n27 = n25 + (correctDivisions + 1);
                final int n28 = n26 + (correctDivisions + 1);
                all3[n18 + 0] = n21;
                all3[n18 + 1] = n25;
                all3[n18 + 2] = ((n22 % correctDivisions == 0) ? (n22 - correctDivisions) : n22);
                all3[n18 + 3] = n26;
                all3[n18 + 4] = n23;
                all3[n18 + 5] = n27;
                n18 += 6;
                all3[n18 + 0] = ((n24 % correctDivisions == 0) ? (n24 - correctDivisions) : n24);
                all3[n18 + 1] = n28;
                all3[n18 + 2] = n23;
                all3[n18 + 3] = n27;
                all3[n18 + 4] = ((n22 % correctDivisions == 0) ? (n22 - correctDivisions) : n22);
                all3[n18 + 5] = n26;
                n18 += 6;
            }
        }
        final int n29 = n16;
        final int n30 = (n2 - 1) * (correctDivisions + 1);
        for (int n31 = 0; n31 < correctDivisions; ++n31) {
            final int n32 = n31;
            final int n33 = n31 + 1;
            final int n34 = n30 + n31;
            all3[n18 + 0] = n29;
            all3[n18 + 1] = n34;
            all3[n18 + 2] = ((n33 == correctDivisions) ? 0 : n33);
            all3[n18 + 3] = n33;
            all3[n18 + 5] = (all3[n18 + 4] = n32);
            n18 += 6;
        }
        final int n35 = n29 + 1;
        final int n36 = n30 + correctDivisions;
        final int n37 = (n2 - 2) * correctDivisions;
        for (int n38 = 0; n38 < correctDivisions; ++n38) {
            final int n39 = n37 + n38;
            final int n40 = n37 + n38 + 1;
            final int n41 = n36 + n38;
            final int n42 = (n2 - 2) * (correctDivisions + 1) + n38;
            final int n43 = n42 + 1;
            all3[n18 + 0] = n35;
            all3[n18 + 1] = n41;
            all3[n18 + 2] = n39;
            all3[n18 + 3] = n42;
            all3[n18 + 4] = ((n40 % correctDivisions == 0) ? (n40 - correctDivisions) : n40);
            all3[n18 + 5] = n43;
            n18 += 6;
        }
        final TriangleMesh triangleMesh = new TriangleMesh(true);
        triangleMesh.getPoints().setAll(all);
        triangleMesh.getTexCoords().setAll(all2);
        triangleMesh.getFaces().setAll(all3);
        return triangleMesh;
    }
    
    static {
        SphereHelper.setSphereAccessor(new SphereHelper.SphereAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((Sphere)node).doCreatePeer();
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((Sphere)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Sphere)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public boolean doComputeContains(final Node node, final double n, final double n2) {
                return ((Sphere)node).doComputeContains(n, n2);
            }
            
            @Override
            public boolean doComputeIntersects(final Node node, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                return ((Sphere)node).doComputeIntersects(pickRay, pickResultChooser);
            }
        });
    }
    
    private static class SphereKey extends Key
    {
        final double radius;
        final int divisions;
        
        private SphereKey(final double radius, final int divisions) {
            this.radius = radius;
            this.divisions = divisions;
        }
        
        @Override
        public int hashCode() {
            return Long.hashCode(31L * (31L * 7L + Double.doubleToLongBits(this.radius)) + this.divisions);
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null) {
                return false;
            }
            if (!(o instanceof SphereKey)) {
                return false;
            }
            final SphereKey sphereKey = (SphereKey)o;
            return this.divisions == sphereKey.divisions && Double.compare(this.radius, sphereKey.radius) == 0;
        }
    }
}
