// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import javafx.css.StyleableDoubleProperty;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.EnumConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.converter.BooleanConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.PaintConverter;
import com.sun.javafx.geom.PathIterator;
import com.sun.javafx.geom.transform.Affine3D;
import com.sun.javafx.geom.Area;
import java.lang.ref.WeakReference;
import com.sun.javafx.util.Utils;
import com.sun.javafx.scene.shape.ShapeHelper;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import javafx.css.Styleable;
import java.util.List;
import javafx.css.StyleableBooleanProperty;
import javafx.css.CssMetaData;
import com.sun.javafx.tk.Toolkit;
import javafx.css.StyleableObjectProperty;
import javafx.scene.paint.Color;
import javafx.collections.ObservableList;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import javafx.beans.Observable;
import java.lang.ref.Reference;
import javafx.beans.property.BooleanProperty;
import com.sun.javafx.beans.event.AbstractNotifyListener;
import javafx.scene.paint.Paint;
import javafx.beans.property.ObjectProperty;
import com.sun.javafx.sg.prism.NGShape;
import javafx.scene.Node;

public abstract class Shape extends Node
{
    private NGShape.Mode mode;
    private ObjectProperty<Paint> fill;
    Paint old_fill;
    private ObjectProperty<Paint> stroke;
    private final AbstractNotifyListener platformImageChangeListener;
    Paint old_stroke;
    private BooleanProperty smooth;
    private static final double MIN_STROKE_WIDTH = 0.0;
    private static final double MIN_STROKE_MITER_LIMIT = 1.0;
    private Reference<Runnable> shapeChangeListener;
    private boolean strokeAttributesDirty;
    private StrokeAttributes strokeAttributes;
    private static final StrokeType DEFAULT_STROKE_TYPE;
    private static final double DEFAULT_STROKE_WIDTH = 1.0;
    private static final StrokeLineJoin DEFAULT_STROKE_LINE_JOIN;
    private static final StrokeLineCap DEFAULT_STROKE_LINE_CAP;
    private static final double DEFAULT_STROKE_MITER_LIMIT = 10.0;
    private static final double DEFAULT_STROKE_DASH_OFFSET = 0.0;
    private static final float[] DEFAULT_PG_STROKE_DASH_ARRAY;
    
    public Shape() {
        this.mode = NGShape.Mode.FILL;
        this.platformImageChangeListener = new AbstractNotifyListener() {
            @Override
            public void invalidated(final Observable observable) {
                NodeHelper.markDirty(Shape.this, DirtyBits.SHAPE_FILL);
                NodeHelper.markDirty(Shape.this, DirtyBits.SHAPE_STROKE);
                NodeHelper.geomChanged(Shape.this);
                Shape.this.checkModeChanged();
            }
        };
        this.strokeAttributesDirty = true;
    }
    
    StrokeLineJoin convertLineJoin(final StrokeLineJoin strokeLineJoin) {
        return strokeLineJoin;
    }
    
    public final void setStrokeType(final StrokeType strokeType) {
        this.strokeTypeProperty().set(strokeType);
    }
    
    public final StrokeType getStrokeType() {
        return (this.strokeAttributes == null) ? Shape.DEFAULT_STROKE_TYPE : this.strokeAttributes.getType();
    }
    
    public final ObjectProperty<StrokeType> strokeTypeProperty() {
        return this.getStrokeAttributes().typeProperty();
    }
    
    public final void setStrokeWidth(final double n) {
        this.strokeWidthProperty().set(n);
    }
    
    public final double getStrokeWidth() {
        return (this.strokeAttributes == null) ? 1.0 : this.strokeAttributes.getWidth();
    }
    
    public final DoubleProperty strokeWidthProperty() {
        return this.getStrokeAttributes().widthProperty();
    }
    
    public final void setStrokeLineJoin(final StrokeLineJoin strokeLineJoin) {
        this.strokeLineJoinProperty().set(strokeLineJoin);
    }
    
    public final StrokeLineJoin getStrokeLineJoin() {
        return (this.strokeAttributes == null) ? Shape.DEFAULT_STROKE_LINE_JOIN : this.strokeAttributes.getLineJoin();
    }
    
    public final ObjectProperty<StrokeLineJoin> strokeLineJoinProperty() {
        return this.getStrokeAttributes().lineJoinProperty();
    }
    
    public final void setStrokeLineCap(final StrokeLineCap strokeLineCap) {
        this.strokeLineCapProperty().set(strokeLineCap);
    }
    
    public final StrokeLineCap getStrokeLineCap() {
        return (this.strokeAttributes == null) ? Shape.DEFAULT_STROKE_LINE_CAP : this.strokeAttributes.getLineCap();
    }
    
    public final ObjectProperty<StrokeLineCap> strokeLineCapProperty() {
        return this.getStrokeAttributes().lineCapProperty();
    }
    
    public final void setStrokeMiterLimit(final double n) {
        this.strokeMiterLimitProperty().set(n);
    }
    
    public final double getStrokeMiterLimit() {
        return (this.strokeAttributes == null) ? 10.0 : this.strokeAttributes.getMiterLimit();
    }
    
    public final DoubleProperty strokeMiterLimitProperty() {
        return this.getStrokeAttributes().miterLimitProperty();
    }
    
    public final void setStrokeDashOffset(final double n) {
        this.strokeDashOffsetProperty().set(n);
    }
    
    public final double getStrokeDashOffset() {
        return (this.strokeAttributes == null) ? 0.0 : this.strokeAttributes.getDashOffset();
    }
    
    public final DoubleProperty strokeDashOffsetProperty() {
        return this.getStrokeAttributes().dashOffsetProperty();
    }
    
    public final ObservableList<Double> getStrokeDashArray() {
        return this.getStrokeAttributes().dashArrayProperty();
    }
    
    private NGShape.Mode computeMode() {
        if (this.getFill() != null && this.getStroke() != null) {
            return NGShape.Mode.STROKE_FILL;
        }
        if (this.getFill() != null) {
            return NGShape.Mode.FILL;
        }
        if (this.getStroke() != null) {
            return NGShape.Mode.STROKE;
        }
        return NGShape.Mode.EMPTY;
    }
    
    NGShape.Mode getMode() {
        return this.mode;
    }
    
    void setMode(NGShape.Mode mode) {
        mode = mode;
    }
    
    private void checkModeChanged() {
        final NGShape.Mode computeMode = this.computeMode();
        if (this.mode != computeMode) {
            this.mode = computeMode;
            NodeHelper.markDirty(this, DirtyBits.SHAPE_MODE);
            NodeHelper.geomChanged(this);
        }
    }
    
    public final void setFill(final Paint paint) {
        this.fillProperty().set(paint);
    }
    
    public final Paint getFill() {
        return (this.fill == null) ? Color.BLACK : this.fill.get();
    }
    
    public final ObjectProperty<Paint> fillProperty() {
        if (this.fill == null) {
            this.fill = new StyleableObjectProperty<Paint>(Color.BLACK) {
                boolean needsListener = false;
                
                public void invalidated() {
                    final Paint old_fill = this.get();
                    if (this.needsListener) {
                        Toolkit.getPaintAccessor().removeListener(Shape.this.old_fill, Shape.this.platformImageChangeListener);
                    }
                    this.needsListener = (old_fill != null && Toolkit.getPaintAccessor().isMutable(old_fill));
                    Shape.this.old_fill = old_fill;
                    if (this.needsListener) {
                        Toolkit.getPaintAccessor().addListener(old_fill, Shape.this.platformImageChangeListener);
                    }
                    NodeHelper.markDirty(Shape.this, DirtyBits.SHAPE_FILL);
                    Shape.this.checkModeChanged();
                }
                
                @Override
                public CssMetaData<Shape, Paint> getCssMetaData() {
                    return StyleableProperties.FILL;
                }
                
                @Override
                public Object getBean() {
                    return Shape.this;
                }
                
                @Override
                public String getName() {
                    return "fill";
                }
            };
        }
        return this.fill;
    }
    
    public final void setStroke(final Paint paint) {
        this.strokeProperty().set(paint);
    }
    
    public final Paint getStroke() {
        return (this.stroke == null) ? null : this.stroke.get();
    }
    
    public final ObjectProperty<Paint> strokeProperty() {
        if (this.stroke == null) {
            this.stroke = new StyleableObjectProperty<Paint>() {
                boolean needsListener = false;
                
                public void invalidated() {
                    final Paint old_stroke = this.get();
                    if (this.needsListener) {
                        Toolkit.getPaintAccessor().removeListener(Shape.this.old_stroke, Shape.this.platformImageChangeListener);
                    }
                    this.needsListener = (old_stroke != null && Toolkit.getPaintAccessor().isMutable(old_stroke));
                    Shape.this.old_stroke = old_stroke;
                    if (this.needsListener) {
                        Toolkit.getPaintAccessor().addListener(old_stroke, Shape.this.platformImageChangeListener);
                    }
                    NodeHelper.markDirty(Shape.this, DirtyBits.SHAPE_STROKE);
                    Shape.this.checkModeChanged();
                }
                
                @Override
                public CssMetaData<Shape, Paint> getCssMetaData() {
                    return StyleableProperties.STROKE;
                }
                
                @Override
                public Object getBean() {
                    return Shape.this;
                }
                
                @Override
                public String getName() {
                    return "stroke";
                }
            };
        }
        return this.stroke;
    }
    
    public final void setSmooth(final boolean b) {
        this.smoothProperty().set(b);
    }
    
    public final boolean isSmooth() {
        return this.smooth == null || this.smooth.get();
    }
    
    public final BooleanProperty smoothProperty() {
        if (this.smooth == null) {
            this.smooth = new StyleableBooleanProperty(true) {
                public void invalidated() {
                    NodeHelper.markDirty(Shape.this, DirtyBits.NODE_SMOOTH);
                }
                
                @Override
                public CssMetaData<Shape, Boolean> getCssMetaData() {
                    return StyleableProperties.SMOOTH;
                }
                
                @Override
                public Object getBean() {
                    return Shape.this;
                }
                
                @Override
                public String getName() {
                    return "smooth";
                }
            };
        }
        return this.smooth;
    }
    
    private Paint doCssGetFillInitialValue() {
        return Color.BLACK;
    }
    
    private Paint doCssGetStrokeInitialValue() {
        return null;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private BaseBounds doComputeGeomBounds(final BaseBounds baseBounds, final BaseTransform baseTransform) {
        return this.computeShapeBounds(baseBounds, baseTransform, ShapeHelper.configShape(this));
    }
    
    private boolean doComputeContains(final double n, final double n2) {
        return this.computeShapeContains(n, n2, ShapeHelper.configShape(this));
    }
    
    private void updatePGShape() {
        final NGShape ngShape = NodeHelper.getPeer(this);
        if (this.strokeAttributesDirty && this.getStroke() != null) {
            ngShape.setDrawStroke((float)Utils.clampMin(this.getStrokeWidth(), 0.0), this.getStrokeType(), this.getStrokeLineCap(), this.convertLineJoin(this.getStrokeLineJoin()), (float)Utils.clampMin(this.getStrokeMiterLimit(), 1.0), this.hasStrokeDashArray() ? toPGDashArray(this.getStrokeDashArray()) : Shape.DEFAULT_PG_STROKE_DASH_ARRAY, (float)this.getStrokeDashOffset());
            this.strokeAttributesDirty = false;
        }
        if (NodeHelper.isDirty(this, DirtyBits.SHAPE_MODE)) {
            ngShape.setMode(this.mode);
        }
        if (NodeHelper.isDirty(this, DirtyBits.SHAPE_FILL)) {
            final Paint fill = this.getFill();
            ngShape.setFillPaint((fill == null) ? null : Toolkit.getPaintAccessor().getPlatformPaint(fill));
        }
        if (NodeHelper.isDirty(this, DirtyBits.SHAPE_STROKE)) {
            final Paint stroke = this.getStroke();
            ngShape.setDrawPaint((stroke == null) ? null : Toolkit.getPaintAccessor().getPlatformPaint(stroke));
        }
        if (NodeHelper.isDirty(this, DirtyBits.NODE_SMOOTH)) {
            ngShape.setSmooth(this.isSmooth());
        }
    }
    
    private void doMarkDirty(final DirtyBits dirtyBits) {
        final Runnable runnable = (this.shapeChangeListener != null) ? this.shapeChangeListener.get() : null;
        if (runnable != null && NodeHelper.isDirtyEmpty(this)) {
            runnable.run();
        }
    }
    
    void setShapeChangeListener(final Runnable referent) {
        if (this.shapeChangeListener != null) {
            this.shapeChangeListener.clear();
        }
        this.shapeChangeListener = ((referent != null) ? new WeakReference<Runnable>(referent) : null);
    }
    
    private void doUpdatePeer() {
        this.updatePGShape();
    }
    
    BaseBounds computeBounds(BaseBounds deriveWithNewBounds, final BaseTransform baseTransform, final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        if (n5 < 0.0 || n6 < 0.0) {
            return deriveWithNewBounds.makeEmpty();
        }
        double n7 = n3;
        double n8 = n4;
        double n9 = n2;
        double n10;
        double n11;
        if (baseTransform.isTranslateOrIdentity()) {
            n10 = n5 + n7;
            n11 = n6 + n8;
            if (baseTransform.getType() == 1) {
                final double mxt = baseTransform.getMxt();
                final double myt = baseTransform.getMyt();
                n7 += mxt;
                n8 += myt;
                n10 += mxt;
                n11 += myt;
            }
            n9 += n;
        }
        else {
            final double n12 = n7 - n;
            final double n13 = n8 - n;
            final double n14 = n5 + n * 2.0;
            final double n15 = n6 + n * 2.0;
            final double mxx = baseTransform.getMxx();
            final double mxy = baseTransform.getMxy();
            final double myx = baseTransform.getMyx();
            final double myy = baseTransform.getMyy();
            final double n16 = n12 * mxx + n13 * mxy + baseTransform.getMxt();
            final double n17 = n12 * myx + n13 * myy + baseTransform.getMyt();
            final double n18 = mxx * n14;
            final double n19 = mxy * n15;
            final double n20 = myx * n14;
            final double n21 = myy * n15;
            n7 = Math.min(Math.min(0.0, n18), Math.min(n19, n18 + n19)) + n16;
            n8 = Math.min(Math.min(0.0, n20), Math.min(n21, n20 + n21)) + n17;
            n10 = Math.max(Math.max(0.0, n18), Math.max(n19, n18 + n19)) + n16;
            n11 = Math.max(Math.max(0.0, n20), Math.max(n21, n20 + n21)) + n17;
        }
        deriveWithNewBounds = deriveWithNewBounds.deriveWithNewBounds((float)(n7 - n9), (float)(n8 - n9), 0.0f, (float)(n10 + n9), (float)(n11 + n9), 0.0f);
        return deriveWithNewBounds;
    }
    
    BaseBounds computeShapeBounds(BaseBounds deriveWithNewBounds, final BaseTransform baseTransform, final com.sun.javafx.geom.Shape shape) {
        if (this.mode == NGShape.Mode.EMPTY) {
            return deriveWithNewBounds.makeEmpty();
        }
        final float[] array = { Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY };
        boolean b = this.mode != NGShape.Mode.STROKE;
        int n = (this.mode != NGShape.Mode.FILL) ? 1 : 0;
        if (n != 0 && this.getStrokeType() == StrokeType.INSIDE) {
            b = true;
            n = 0;
        }
        if (n != 0) {
            Toolkit.getToolkit().accumulateStrokeBounds(shape, array, this.getStrokeType(), Utils.clampMin(this.getStrokeWidth(), 0.0), this.getStrokeLineCap(), this.convertLineJoin(this.getStrokeLineJoin()), (float)Utils.clampMin(this.getStrokeMiterLimit(), 1.0), baseTransform);
            final float[] array2 = array;
            final int n2 = 0;
            array2[n2] -= 0.5;
            final float[] array3 = array;
            final int n3 = 1;
            array3[n3] -= 0.5;
            final float[] array4 = array;
            final int n4 = 2;
            array4[n4] += 0.5;
            final float[] array5 = array;
            final int n5 = 3;
            array5[n5] += 0.5;
        }
        else if (b) {
            com.sun.javafx.geom.Shape.accumulate(array, shape, baseTransform);
        }
        if (array[2] < array[0] || array[3] < array[1]) {
            return deriveWithNewBounds.makeEmpty();
        }
        deriveWithNewBounds = deriveWithNewBounds.deriveWithNewBounds(array[0], array[1], 0.0f, array[2], array[3], 0.0f);
        return deriveWithNewBounds;
    }
    
    boolean computeShapeContains(final double n, final double n2, final com.sun.javafx.geom.Shape shape) {
        if (this.mode == NGShape.Mode.EMPTY) {
            return false;
        }
        final boolean b = this.mode != NGShape.Mode.STROKE;
        int n3 = (this.mode != NGShape.Mode.FILL) ? 1 : 0;
        if (n3 != 0 && b && this.getStrokeType() == StrokeType.INSIDE) {
            n3 = 0;
        }
        return (b && shape.contains((float)n, (float)n2)) || (n3 != 0 && Toolkit.getToolkit().strokeContains(shape, n, n2, this.getStrokeType(), Utils.clampMin(this.getStrokeWidth(), 0.0), this.getStrokeLineCap(), this.convertLineJoin(this.getStrokeLineJoin()), (float)Utils.clampMin(this.getStrokeMiterLimit(), 1.0)));
    }
    
    private StrokeAttributes getStrokeAttributes() {
        if (this.strokeAttributes == null) {
            this.strokeAttributes = new StrokeAttributes();
        }
        return this.strokeAttributes;
    }
    
    private boolean hasStrokeDashArray() {
        return this.strokeAttributes != null && this.strokeAttributes.hasDashArray();
    }
    
    private static float[] toPGDashArray(final List<Double> list) {
        final int size = list.size();
        final float[] array = new float[size];
        for (int i = 0; i < size; ++i) {
            array[i] = list.get(i).floatValue();
        }
        return array;
    }
    
    public static Shape union(final Shape shape, final Shape shape2) {
        final Area transformedArea = shape.getTransformedArea();
        transformedArea.add(shape2.getTransformedArea());
        return createFromGeomShape(transformedArea);
    }
    
    public static Shape subtract(final Shape shape, final Shape shape2) {
        final Area transformedArea = shape.getTransformedArea();
        transformedArea.subtract(shape2.getTransformedArea());
        return createFromGeomShape(transformedArea);
    }
    
    public static Shape intersect(final Shape shape, final Shape shape2) {
        final Area transformedArea = shape.getTransformedArea();
        transformedArea.intersect(shape2.getTransformedArea());
        return createFromGeomShape(transformedArea);
    }
    
    private Area getTransformedArea() {
        return this.getTransformedArea(calculateNodeToSceneTransform(this));
    }
    
    private Area getTransformedArea(final BaseTransform baseTransform) {
        if (this.mode == NGShape.Mode.EMPTY) {
            return new Area();
        }
        final com.sun.javafx.geom.Shape configShape = ShapeHelper.configShape(this);
        if (this.mode == NGShape.Mode.FILL || (this.mode == NGShape.Mode.STROKE_FILL && this.getStrokeType() == StrokeType.INSIDE)) {
            return createTransformedArea(configShape, baseTransform);
        }
        final com.sun.javafx.geom.Shape strokedShape = Toolkit.getToolkit().createStrokedShape(configShape, this.getStrokeType(), Utils.clampMin(this.getStrokeWidth(), 0.0), this.getStrokeLineCap(), this.convertLineJoin(this.getStrokeLineJoin()), (float)Utils.clampMin(this.getStrokeMiterLimit(), 1.0), this.hasStrokeDashArray() ? toPGDashArray(this.getStrokeDashArray()) : Shape.DEFAULT_PG_STROKE_DASH_ARRAY, (float)this.getStrokeDashOffset());
        if (this.mode == NGShape.Mode.STROKE) {
            return createTransformedArea(strokedShape, baseTransform);
        }
        final Area area = new Area(configShape);
        area.add(new Area(strokedShape));
        return createTransformedArea(area, baseTransform);
    }
    
    private static BaseTransform calculateNodeToSceneTransform(Node parent) {
        final Affine3D affine3D = new Affine3D();
        do {
            affine3D.preConcatenate(NodeHelper.getLeafTransform(parent));
            parent = parent.getParent();
        } while (parent != null);
        return affine3D;
    }
    
    private static Area createTransformedArea(final com.sun.javafx.geom.Shape shape, final BaseTransform baseTransform) {
        return baseTransform.isIdentity() ? new Area(shape) : new Area(shape.getPathIterator(baseTransform));
    }
    
    private static Path createFromGeomShape(final com.sun.javafx.geom.Shape shape) {
        final Path path = new Path();
        final ObservableList<PathElement> elements = path.getElements();
        final PathIterator pathIterator = shape.getPathIterator(null);
        final float[] array = new float[6];
        while (!pathIterator.isDone()) {
            switch (pathIterator.currentSegment(array)) {
                case 0: {
                    elements.add(new MoveTo(array[0], array[1]));
                    break;
                }
                case 1: {
                    elements.add(new LineTo(array[0], array[1]));
                    break;
                }
                case 2: {
                    elements.add(new QuadCurveTo(array[0], array[1], array[2], array[3]));
                    break;
                }
                case 3: {
                    elements.add(new CubicCurveTo(array[0], array[1], array[2], array[3], array[4], array[5]));
                    break;
                }
                case 4: {
                    elements.add(new ClosePath());
                    break;
                }
            }
            pathIterator.next();
        }
        path.setFillRule((pathIterator.getWindingRule() == 0) ? FillRule.EVEN_ODD : FillRule.NON_ZERO);
        path.setFill(Color.BLACK);
        path.setStroke(null);
        return path;
    }
    
    static {
        ShapeHelper.setShapeAccessor(new ShapeHelper.ShapeAccessor() {
            @Override
            public void doUpdatePeer(final Node node) {
                ((Shape)node).doUpdatePeer();
            }
            
            @Override
            public void doMarkDirty(final Node node, final DirtyBits dirtyBits) {
                ((Shape)node).doMarkDirty(dirtyBits);
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Shape)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public boolean doComputeContains(final Node node, final double n, final double n2) {
                return ((Shape)node).doComputeContains(n, n2);
            }
            
            @Override
            public Paint doCssGetFillInitialValue(final Shape shape) {
                return shape.doCssGetFillInitialValue();
            }
            
            @Override
            public Paint doCssGetStrokeInitialValue(final Shape shape) {
                return shape.doCssGetStrokeInitialValue();
            }
            
            @Override
            public NGShape.Mode getMode(final Shape shape) {
                return shape.getMode();
            }
            
            @Override
            public void setMode(final Shape shape, final NGShape.Mode mode) {
                shape.setMode(mode);
            }
            
            @Override
            public void setShapeChangeListener(final Shape shape, final Runnable shapeChangeListener) {
                shape.setShapeChangeListener(shapeChangeListener);
            }
        });
        DEFAULT_STROKE_TYPE = StrokeType.CENTERED;
        DEFAULT_STROKE_LINE_JOIN = StrokeLineJoin.MITER;
        DEFAULT_STROKE_LINE_CAP = StrokeLineCap.SQUARE;
        DEFAULT_PG_STROKE_DASH_ARRAY = new float[0];
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Shape, Paint> FILL;
        private static final CssMetaData<Shape, Boolean> SMOOTH;
        private static final CssMetaData<Shape, Paint> STROKE;
        private static final CssMetaData<Shape, Number[]> STROKE_DASH_ARRAY;
        private static final CssMetaData<Shape, Number> STROKE_DASH_OFFSET;
        private static final CssMetaData<Shape, StrokeLineCap> STROKE_LINE_CAP;
        private static final CssMetaData<Shape, StrokeLineJoin> STROKE_LINE_JOIN;
        private static final CssMetaData<Shape, StrokeType> STROKE_TYPE;
        private static final CssMetaData<Shape, Number> STROKE_MITER_LIMIT;
        private static final CssMetaData<Shape, Number> STROKE_WIDTH;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            FILL = new CssMetaData<Shape, Paint>((StyleConverter)PaintConverter.getInstance(), (Paint)Color.BLACK) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return shape.fill == null || !shape.fill.isBound();
                }
                
                @Override
                public StyleableProperty<Paint> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<Paint>)(StyleableProperty)shape.fillProperty();
                }
                
                @Override
                public Paint getInitialValue(final Shape shape) {
                    return ShapeHelper.cssGetFillInitialValue(shape);
                }
            };
            SMOOTH = new CssMetaData<Shape, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return shape.smooth == null || !shape.smooth.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<Boolean>)shape.smoothProperty();
                }
            };
            STROKE = new CssMetaData<Shape, Paint>((StyleConverter)PaintConverter.getInstance()) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return shape.stroke == null || !shape.stroke.isBound();
                }
                
                @Override
                public StyleableProperty<Paint> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<Paint>)(StyleableProperty)shape.strokeProperty();
                }
                
                @Override
                public Paint getInitialValue(final Shape shape) {
                    return ShapeHelper.cssGetStrokeInitialValue(shape);
                }
            };
            STROKE_DASH_ARRAY = new CssMetaData<Shape, Number[]>((StyleConverter)SizeConverter.SequenceConverter.getInstance(), (Number[])new Double[0]) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return true;
                }
                
                @Override
                public StyleableProperty<Number[]> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<Number[]>)(StyleableProperty)shape.getStrokeAttributes().cssDashArrayProperty();
                }
            };
            STROKE_DASH_OFFSET = new CssMetaData<Shape, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return shape.strokeAttributes == null || shape.strokeAttributes.canSetDashOffset();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<Number>)shape.strokeDashOffsetProperty();
                }
            };
            STROKE_LINE_CAP = new CssMetaData<Shape, StrokeLineCap>((StyleConverter)new EnumConverter(StrokeLineCap.class), StrokeLineCap.SQUARE) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return shape.strokeAttributes == null || shape.strokeAttributes.canSetLineCap();
                }
                
                @Override
                public StyleableProperty<StrokeLineCap> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<StrokeLineCap>)(StyleableProperty)shape.strokeLineCapProperty();
                }
            };
            STROKE_LINE_JOIN = new CssMetaData<Shape, StrokeLineJoin>((StyleConverter)new EnumConverter(StrokeLineJoin.class), StrokeLineJoin.MITER) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return shape.strokeAttributes == null || shape.strokeAttributes.canSetLineJoin();
                }
                
                @Override
                public StyleableProperty<StrokeLineJoin> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<StrokeLineJoin>)(StyleableProperty)shape.strokeLineJoinProperty();
                }
            };
            STROKE_TYPE = new CssMetaData<Shape, StrokeType>((StyleConverter)new EnumConverter(StrokeType.class), StrokeType.CENTERED) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return shape.strokeAttributes == null || shape.strokeAttributes.canSetType();
                }
                
                @Override
                public StyleableProperty<StrokeType> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<StrokeType>)(StyleableProperty)shape.strokeTypeProperty();
                }
            };
            STROKE_MITER_LIMIT = new CssMetaData<Shape, Number>((StyleConverter)SizeConverter.getInstance(), (Number)10.0) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return shape.strokeAttributes == null || shape.strokeAttributes.canSetMiterLimit();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<Number>)shape.strokeMiterLimitProperty();
                }
            };
            STROKE_WIDTH = new CssMetaData<Shape, Number>((StyleConverter)SizeConverter.getInstance(), (Number)1.0) {
                @Override
                public boolean isSettable(final Shape shape) {
                    return shape.strokeAttributes == null || shape.strokeAttributes.canSetWidth();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Shape shape) {
                    return (StyleableProperty<Number>)shape.strokeWidthProperty();
                }
            };
            final ArrayList<CssMetaData<Shape, Boolean>> list = new ArrayList<CssMetaData<Shape, Boolean>>((Collection<? extends CssMetaData<Shape, Boolean>>)Node.getClassCssMetaData());
            list.add(StyleableProperties.FILL);
            list.add(StyleableProperties.SMOOTH);
            list.add((CssMetaData<Shape, Boolean>)StyleableProperties.STROKE);
            list.add((CssMetaData<Shape, Boolean>)StyleableProperties.STROKE_DASH_ARRAY);
            list.add((CssMetaData<Shape, Boolean>)StyleableProperties.STROKE_DASH_OFFSET);
            list.add((CssMetaData<Shape, Boolean>)StyleableProperties.STROKE_LINE_CAP);
            list.add((CssMetaData<Shape, Boolean>)StyleableProperties.STROKE_LINE_JOIN);
            list.add((CssMetaData<Shape, Boolean>)StyleableProperties.STROKE_TYPE);
            list.add((CssMetaData<Shape, Boolean>)StyleableProperties.STROKE_MITER_LIMIT);
            list.add((CssMetaData<Shape, Boolean>)StyleableProperties.STROKE_WIDTH);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    private final class StrokeAttributes
    {
        private ObjectProperty<StrokeType> type;
        private DoubleProperty width;
        private ObjectProperty<StrokeLineJoin> lineJoin;
        private ObjectProperty<StrokeLineCap> lineCap;
        private DoubleProperty miterLimit;
        private DoubleProperty dashOffset;
        private ObservableList<Double> dashArray;
        private ObjectProperty<Number[]> cssDashArray;
        
        private StrokeAttributes() {
            this.cssDashArray = null;
        }
        
        public final StrokeType getType() {
            return (this.type == null) ? Shape.DEFAULT_STROKE_TYPE : this.type.get();
        }
        
        public final ObjectProperty<StrokeType> typeProperty() {
            if (this.type == null) {
                this.type = new StyleableObjectProperty<StrokeType>(Shape.DEFAULT_STROKE_TYPE) {
                    public void invalidated() {
                        StrokeAttributes.this.invalidated(StyleableProperties.STROKE_TYPE);
                    }
                    
                    @Override
                    public CssMetaData<Shape, StrokeType> getCssMetaData() {
                        return StyleableProperties.STROKE_TYPE;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Shape.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "strokeType";
                    }
                };
            }
            return this.type;
        }
        
        public double getWidth() {
            return (this.width == null) ? 1.0 : this.width.get();
        }
        
        public final DoubleProperty widthProperty() {
            if (this.width == null) {
                this.width = new StyleableDoubleProperty(1.0) {
                    public void invalidated() {
                        StrokeAttributes.this.invalidated(StyleableProperties.STROKE_WIDTH);
                    }
                    
                    @Override
                    public CssMetaData<Shape, Number> getCssMetaData() {
                        return StyleableProperties.STROKE_WIDTH;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Shape.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "strokeWidth";
                    }
                };
            }
            return this.width;
        }
        
        public StrokeLineJoin getLineJoin() {
            return (this.lineJoin == null) ? Shape.DEFAULT_STROKE_LINE_JOIN : this.lineJoin.get();
        }
        
        public final ObjectProperty<StrokeLineJoin> lineJoinProperty() {
            if (this.lineJoin == null) {
                this.lineJoin = new StyleableObjectProperty<StrokeLineJoin>(Shape.DEFAULT_STROKE_LINE_JOIN) {
                    public void invalidated() {
                        StrokeAttributes.this.invalidated(StyleableProperties.STROKE_LINE_JOIN);
                    }
                    
                    @Override
                    public CssMetaData<Shape, StrokeLineJoin> getCssMetaData() {
                        return StyleableProperties.STROKE_LINE_JOIN;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Shape.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "strokeLineJoin";
                    }
                };
            }
            return this.lineJoin;
        }
        
        public StrokeLineCap getLineCap() {
            return (this.lineCap == null) ? Shape.DEFAULT_STROKE_LINE_CAP : this.lineCap.get();
        }
        
        public final ObjectProperty<StrokeLineCap> lineCapProperty() {
            if (this.lineCap == null) {
                this.lineCap = new StyleableObjectProperty<StrokeLineCap>(Shape.DEFAULT_STROKE_LINE_CAP) {
                    public void invalidated() {
                        StrokeAttributes.this.invalidated(StyleableProperties.STROKE_LINE_CAP);
                    }
                    
                    @Override
                    public CssMetaData<Shape, StrokeLineCap> getCssMetaData() {
                        return StyleableProperties.STROKE_LINE_CAP;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Shape.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "strokeLineCap";
                    }
                };
            }
            return this.lineCap;
        }
        
        public double getMiterLimit() {
            return (this.miterLimit == null) ? 10.0 : this.miterLimit.get();
        }
        
        public final DoubleProperty miterLimitProperty() {
            if (this.miterLimit == null) {
                this.miterLimit = new StyleableDoubleProperty(10.0) {
                    public void invalidated() {
                        StrokeAttributes.this.invalidated(StyleableProperties.STROKE_MITER_LIMIT);
                    }
                    
                    @Override
                    public CssMetaData<Shape, Number> getCssMetaData() {
                        return StyleableProperties.STROKE_MITER_LIMIT;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Shape.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "strokeMiterLimit";
                    }
                };
            }
            return this.miterLimit;
        }
        
        public double getDashOffset() {
            return (this.dashOffset == null) ? 0.0 : this.dashOffset.get();
        }
        
        public final DoubleProperty dashOffsetProperty() {
            if (this.dashOffset == null) {
                this.dashOffset = new StyleableDoubleProperty(0.0) {
                    public void invalidated() {
                        StrokeAttributes.this.invalidated(StyleableProperties.STROKE_DASH_OFFSET);
                    }
                    
                    @Override
                    public CssMetaData<Shape, Number> getCssMetaData() {
                        return StyleableProperties.STROKE_DASH_OFFSET;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Shape.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "strokeDashOffset";
                    }
                };
            }
            return this.dashOffset;
        }
        
        public ObservableList<Double> dashArrayProperty() {
            if (this.dashArray == null) {
                this.dashArray = new TrackableObservableList<Double>() {
                    @Override
                    protected void onChanged(final ListChangeListener.Change<Double> change) {
                        StrokeAttributes.this.invalidated(StyleableProperties.STROKE_DASH_ARRAY);
                    }
                };
            }
            return this.dashArray;
        }
        
        private ObjectProperty<Number[]> cssDashArrayProperty() {
            if (this.cssDashArray == null) {
                this.cssDashArray = new StyleableObjectProperty<Number[]>() {
                    @Override
                    public void set(final Number[] array) {
                        final ObservableList<Double> dashArrayProperty = StrokeAttributes.this.dashArrayProperty();
                        dashArrayProperty.clear();
                        if (array != null && array.length > 0) {
                            for (int i = 0; i < array.length; ++i) {
                                dashArrayProperty.add(array[i].doubleValue());
                            }
                        }
                    }
                    
                    @Override
                    public Double[] get() {
                        final ObservableList<Double> dashArrayProperty = StrokeAttributes.this.dashArrayProperty();
                        return dashArrayProperty.toArray(new Double[dashArrayProperty.size()]);
                    }
                    
                    @Override
                    public Object getBean() {
                        return Shape.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "cssDashArray";
                    }
                    
                    @Override
                    public CssMetaData<Shape, Number[]> getCssMetaData() {
                        return StyleableProperties.STROKE_DASH_ARRAY;
                    }
                };
            }
            return this.cssDashArray;
        }
        
        public boolean canSetType() {
            return this.type == null || !this.type.isBound();
        }
        
        public boolean canSetWidth() {
            return this.width == null || !this.width.isBound();
        }
        
        public boolean canSetLineJoin() {
            return this.lineJoin == null || !this.lineJoin.isBound();
        }
        
        public boolean canSetLineCap() {
            return this.lineCap == null || !this.lineCap.isBound();
        }
        
        public boolean canSetMiterLimit() {
            return this.miterLimit == null || !this.miterLimit.isBound();
        }
        
        public boolean canSetDashOffset() {
            return this.dashOffset == null || !this.dashOffset.isBound();
        }
        
        public boolean hasDashArray() {
            return this.dashArray != null;
        }
        
        private void invalidated(final CssMetaData<Shape, ?> cssMetaData) {
            NodeHelper.markDirty(Shape.this, DirtyBits.SHAPE_STROKEATTRS);
            Shape.this.strokeAttributesDirty = true;
            if (cssMetaData != StyleableProperties.STROKE_DASH_OFFSET) {
                NodeHelper.geomChanged(Shape.this);
            }
        }
    }
}
