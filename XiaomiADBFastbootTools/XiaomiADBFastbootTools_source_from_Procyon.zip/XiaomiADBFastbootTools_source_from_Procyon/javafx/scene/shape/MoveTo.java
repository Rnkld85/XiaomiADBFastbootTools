// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.shape;

import com.sun.javafx.geom.Path2D;
import com.sun.javafx.sg.prism.NGPath;
import javafx.beans.property.DoublePropertyBase;
import com.sun.javafx.scene.shape.MoveToHelper;
import javafx.beans.property.DoubleProperty;

public class MoveTo extends PathElement
{
    private DoubleProperty x;
    private DoubleProperty y;
    
    public MoveTo() {
        MoveToHelper.initHelper(this);
    }
    
    public MoveTo(final double x, final double y) {
        this.setX(x);
        this.setY(y);
        MoveToHelper.initHelper(this);
    }
    
    public final void setX(final double n) {
        if (this.x != null || n != 0.0) {
            this.xProperty().set(n);
        }
    }
    
    public final double getX() {
        return (this.x == null) ? 0.0 : this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        if (this.x == null) {
            this.x = new DoublePropertyBase() {
                public void invalidated() {
                    MoveTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return MoveTo.this;
                }
                
                @Override
                public String getName() {
                    return "x";
                }
            };
        }
        return this.x;
    }
    
    public final void setY(final double n) {
        if (this.y != null || n != 0.0) {
            this.yProperty().set(n);
        }
    }
    
    public final double getY() {
        return (this.y == null) ? 0.0 : this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        if (this.y == null) {
            this.y = new DoublePropertyBase() {
                public void invalidated() {
                    MoveTo.this.u();
                }
                
                @Override
                public Object getBean() {
                    return MoveTo.this;
                }
                
                @Override
                public String getName() {
                    return "y";
                }
            };
        }
        return this.y;
    }
    
    @Override
    void addTo(final NGPath ngPath) {
        if (this.isAbsolute()) {
            ngPath.addMoveTo((float)this.getX(), (float)this.getY());
        }
        else {
            ngPath.addMoveTo((float)(ngPath.getCurrentX() + this.getX()), (float)(ngPath.getCurrentY() + this.getY()));
        }
    }
    
    private void doAddTo(final Path2D path2D) {
        if (this.isAbsolute()) {
            path2D.moveTo((float)this.getX(), (float)this.getY());
        }
        else {
            path2D.moveTo((float)(path2D.getCurrentX() + this.getX()), (float)(path2D.getCurrentY() + this.getY()));
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("MoveTo[");
        sb.append("x=").append(this.getX());
        sb.append(", y=").append(this.getY());
        return sb.append("]").toString();
    }
    
    static {
        MoveToHelper.setMoveToAccessor(new MoveToHelper.MoveToAccessor() {
            @Override
            public void doAddTo(final PathElement pathElement, final Path2D path2D) {
                ((MoveTo)pathElement).doAddTo(path2D);
            }
        });
    }
}
