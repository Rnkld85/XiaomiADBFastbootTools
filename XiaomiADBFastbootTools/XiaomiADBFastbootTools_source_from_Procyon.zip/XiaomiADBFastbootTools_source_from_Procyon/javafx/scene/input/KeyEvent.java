// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import com.sun.javafx.tk.Toolkit;
import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;

public final class KeyEvent extends InputEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<KeyEvent> ANY;
    public static final EventType<KeyEvent> KEY_PRESSED;
    public static final EventType<KeyEvent> KEY_RELEASED;
    public static final EventType<KeyEvent> KEY_TYPED;
    public static final String CHAR_UNDEFINED;
    private final String character;
    private final String text;
    private final KeyCode code;
    private final boolean shiftDown;
    private final boolean controlDown;
    private final boolean altDown;
    private final boolean metaDown;
    
    public KeyEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<KeyEvent> eventType, @NamedArg("character") final String s, @NamedArg("text") final String s2, @NamedArg("code") final KeyCode keyCode, @NamedArg("shiftDown") final boolean shiftDown, @NamedArg("controlDown") final boolean controlDown, @NamedArg("altDown") final boolean altDown, @NamedArg("metaDown") final boolean metaDown) {
        super(o, eventTarget, eventType);
        final boolean b = eventType == KeyEvent.KEY_TYPED;
        this.character = (b ? s : KeyEvent.CHAR_UNDEFINED);
        this.text = (b ? "" : s2);
        this.code = (b ? KeyCode.UNDEFINED : keyCode);
        this.shiftDown = shiftDown;
        this.controlDown = controlDown;
        this.altDown = altDown;
        this.metaDown = metaDown;
    }
    
    public KeyEvent(@NamedArg("eventType") final EventType<KeyEvent> eventType, @NamedArg("character") final String s, @NamedArg("text") final String s2, @NamedArg("code") final KeyCode keyCode, @NamedArg("shiftDown") final boolean shiftDown, @NamedArg("controlDown") final boolean controlDown, @NamedArg("altDown") final boolean altDown, @NamedArg("metaDown") final boolean metaDown) {
        super(eventType);
        final boolean b = eventType == KeyEvent.KEY_TYPED;
        this.character = (b ? s : KeyEvent.CHAR_UNDEFINED);
        this.text = (b ? "" : s2);
        this.code = (b ? KeyCode.UNDEFINED : keyCode);
        this.shiftDown = shiftDown;
        this.controlDown = controlDown;
        this.altDown = altDown;
        this.metaDown = metaDown;
    }
    
    public final String getCharacter() {
        return this.character;
    }
    
    public final String getText() {
        return this.text;
    }
    
    public final KeyCode getCode() {
        return this.code;
    }
    
    public final boolean isShiftDown() {
        return this.shiftDown;
    }
    
    public final boolean isControlDown() {
        return this.controlDown;
    }
    
    public final boolean isAltDown() {
        return this.altDown;
    }
    
    public final boolean isMetaDown() {
        return this.metaDown;
    }
    
    public final boolean isShortcutDown() {
        switch (Toolkit.getToolkit().getPlatformShortcutKey()) {
            case SHIFT: {
                return this.shiftDown;
            }
            case CONTROL: {
                return this.controlDown;
            }
            case ALT: {
                return this.altDown;
            }
            case META: {
                return this.metaDown;
            }
            default: {
                return false;
            }
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("KeyEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", character = ").append(this.getCharacter());
        sb.append(", text = ").append(this.getText());
        sb.append(", code = ").append(this.getCode());
        if (this.isShiftDown()) {
            sb.append(", shiftDown");
        }
        if (this.isControlDown()) {
            sb.append(", controlDown");
        }
        if (this.isAltDown()) {
            sb.append(", altDown");
        }
        if (this.isMetaDown()) {
            sb.append(", metaDown");
        }
        if (this.isShortcutDown()) {
            sb.append(", shortcutDown");
        }
        return sb.append("]").toString();
    }
    
    @Override
    public KeyEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (KeyEvent)super.copyFor(o, eventTarget);
    }
    
    public KeyEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<KeyEvent> eventType) {
        final KeyEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    @Override
    public EventType<KeyEvent> getEventType() {
        return (EventType<KeyEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<KeyEvent>(InputEvent.ANY, "KEY");
        KEY_PRESSED = new EventType<KeyEvent>(KeyEvent.ANY, "KEY_PRESSED");
        KEY_RELEASED = new EventType<KeyEvent>(KeyEvent.ANY, "KEY_RELEASED");
        KEY_TYPED = new EventType<KeyEvent>(KeyEvent.ANY, "KEY_TYPED");
        CHAR_UNDEFINED = KeyCode.UNDEFINED.ch;
    }
}
