// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.beans.NamedArg;
import java.io.Serializable;

public class InputMethodTextRun implements Serializable
{
    private final String text;
    private final InputMethodHighlight highlight;
    
    public InputMethodTextRun(@NamedArg("text") final String text, @NamedArg("highlight") final InputMethodHighlight highlight) {
        this.text = text;
        this.highlight = highlight;
    }
    
    public final String getText() {
        return this.text;
    }
    
    public final InputMethodHighlight getHighlight() {
        return this.highlight;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/input/InputMethodHighlight;)Ljava/lang/String;, this.getText(), this.getHighlight());
    }
}
