// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import com.sun.javafx.PlatformUtil;
import com.sun.javafx.util.Utils;
import javafx.beans.NamedArg;

public final class KeyCodeCombination extends KeyCombination
{
    private KeyCode code;
    
    public final KeyCode getCode() {
        return this.code;
    }
    
    public KeyCodeCombination(@NamedArg("code") final KeyCode code, @NamedArg("shift") final ModifierValue modifierValue, @NamedArg("control") final ModifierValue modifierValue2, @NamedArg("alt") final ModifierValue modifierValue3, @NamedArg("meta") final ModifierValue modifierValue4, @NamedArg("shortcut") final ModifierValue modifierValue5) {
        super(modifierValue, modifierValue2, modifierValue3, modifierValue4, modifierValue5);
        validateKeyCode(code);
        this.code = code;
    }
    
    public KeyCodeCombination(@NamedArg("code") final KeyCode code, @NamedArg("modifiers") final Modifier... array) {
        super(array);
        validateKeyCode(code);
        this.code = code;
    }
    
    @Override
    public boolean match(final KeyEvent keyEvent) {
        return keyEvent.getCode() == this.getCode() && super.match(keyEvent);
    }
    
    @Override
    public String getName() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.getName());
        if (sb.length() > 0) {
            sb.append("+");
        }
        return sb.append(this.code.getName()).toString();
    }
    
    @Override
    public String getDisplayText() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.getDisplayText());
        final int length = sb.length();
        final char singleChar = getSingleChar(this.code);
        if (singleChar != '\0') {
            sb.append(singleChar);
            return sb.toString();
        }
        for (final String s : Utils.split(this.code.toString(), "_")) {
            if (sb.length() > length) {
                sb.append(' ');
            }
            sb.append(s.charAt(0));
            sb.append(s.substring(1).toLowerCase());
        }
        return sb.toString();
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof KeyCodeCombination && this.getCode() == ((KeyCodeCombination)o).getCode() && super.equals(o));
    }
    
    @Override
    public int hashCode() {
        return 23 * super.hashCode() + this.code.hashCode();
    }
    
    private static void validateKeyCode(final KeyCode keyCode) {
        if (keyCode == null) {
            throw new NullPointerException("Key code must not be null!");
        }
        if (KeyCombination.getModifier(keyCode.getName()) != null) {
            throw new IllegalArgumentException("Key code must not match modifier key!");
        }
        if (keyCode == KeyCode.UNDEFINED) {
            throw new IllegalArgumentException("Key code must differ from undefined value!");
        }
    }
    
    private static char getSingleChar(final KeyCode keyCode) {
        switch (keyCode) {
            case ENTER: {
                return '\u21b5';
            }
            case LEFT: {
                return '\u2190';
            }
            case UP: {
                return '\u2191';
            }
            case RIGHT: {
                return '\u2192';
            }
            case DOWN: {
                return '\u2193';
            }
            case COMMA: {
                return ',';
            }
            case MINUS: {
                return '-';
            }
            case PERIOD: {
                return '.';
            }
            case SLASH: {
                return '/';
            }
            case SEMICOLON: {
                return ';';
            }
            case EQUALS: {
                return '=';
            }
            case OPEN_BRACKET: {
                return '[';
            }
            case BACK_SLASH: {
                return '\\';
            }
            case CLOSE_BRACKET: {
                return ']';
            }
            case MULTIPLY: {
                return '*';
            }
            case ADD: {
                return '+';
            }
            case SUBTRACT: {
                return '-';
            }
            case DECIMAL: {
                return '.';
            }
            case DIVIDE: {
                return '/';
            }
            case BACK_QUOTE: {
                return '`';
            }
            case QUOTE: {
                return '\"';
            }
            case AMPERSAND: {
                return '&';
            }
            case ASTERISK: {
                return '*';
            }
            case LESS: {
                return '<';
            }
            case GREATER: {
                return '>';
            }
            case BRACELEFT: {
                return '{';
            }
            case BRACERIGHT: {
                return '}';
            }
            case AT: {
                return '@';
            }
            case COLON: {
                return ':';
            }
            case CIRCUMFLEX: {
                return '^';
            }
            case DOLLAR: {
                return '$';
            }
            case EURO_SIGN: {
                return '\u20ac';
            }
            case EXCLAMATION_MARK: {
                return '!';
            }
            case LEFT_PARENTHESIS: {
                return '(';
            }
            case NUMBER_SIGN: {
                return '#';
            }
            case PLUS: {
                return '+';
            }
            case RIGHT_PARENTHESIS: {
                return ')';
            }
            case UNDERSCORE: {
                return '_';
            }
            case DIGIT0: {
                return '0';
            }
            case DIGIT1: {
                return '1';
            }
            case DIGIT2: {
                return '2';
            }
            case DIGIT3: {
                return '3';
            }
            case DIGIT4: {
                return '4';
            }
            case DIGIT5: {
                return '5';
            }
            case DIGIT6: {
                return '6';
            }
            case DIGIT7: {
                return '7';
            }
            case DIGIT8: {
                return '8';
            }
            case DIGIT9: {
                return '9';
            }
            default: {
                if (PlatformUtil.isMac()) {
                    switch (keyCode) {
                        case BACK_SPACE: {
                            return '\u232b';
                        }
                        case ESCAPE: {
                            return '\u238b';
                        }
                        case DELETE: {
                            return '\u2326';
                        }
                    }
                }
                return '\0';
            }
        }
    }
}
