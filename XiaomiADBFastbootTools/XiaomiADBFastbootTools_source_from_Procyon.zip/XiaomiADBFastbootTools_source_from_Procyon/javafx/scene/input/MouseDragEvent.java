// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;

public final class MouseDragEvent extends MouseEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<MouseDragEvent> ANY;
    public static final EventType<MouseDragEvent> MOUSE_DRAG_OVER;
    public static final EventType<MouseDragEvent> MOUSE_DRAG_RELEASED;
    public static final EventType<MouseDragEvent> MOUSE_DRAG_ENTERED_TARGET;
    public static final EventType<MouseDragEvent> MOUSE_DRAG_ENTERED;
    public static final EventType<MouseDragEvent> MOUSE_DRAG_EXITED_TARGET;
    public static final EventType<MouseDragEvent> MOUSE_DRAG_EXITED;
    private final transient Object gestureSource;
    
    public MouseDragEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<MouseDragEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("button") final MouseButton mouseButton, @NamedArg("clickCount") final int n5, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("primaryButtonDown") final boolean b5, @NamedArg("middleButtonDown") final boolean b6, @NamedArg("secondaryButtonDown") final boolean b7, @NamedArg("synthesized") final boolean b8, @NamedArg("popupTrigger") final boolean b9, @NamedArg("pickResult") final PickResult pickResult, @NamedArg("gestureSource") final Object gestureSource) {
        super(o, eventTarget, eventType, n, n2, n3, n4, mouseButton, n5, b, b2, b3, b4, b5, b6, b7, b8, b9, false, pickResult);
        this.gestureSource = gestureSource;
    }
    
    public MouseDragEvent(@NamedArg("eventType") final EventType<MouseDragEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("button") final MouseButton mouseButton, @NamedArg("clickCount") final int n5, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("primaryButtonDown") final boolean b5, @NamedArg("middleButtonDown") final boolean b6, @NamedArg("secondaryButtonDown") final boolean b7, @NamedArg("synthesized") final boolean b8, @NamedArg("popupTrigger") final boolean b9, @NamedArg("pickResult") final PickResult pickResult, @NamedArg("gestureSource") final Object o) {
        this(null, null, eventType, n, n2, n3, n4, mouseButton, n5, b, b2, b3, b4, b5, b6, b7, b8, b9, pickResult, o);
    }
    
    public Object getGestureSource() {
        return this.gestureSource;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("MouseDragEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", gestureSource = ").append(this.getGestureSource());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", x = ").append(this.getX()).append(", y = ").append(this.getY()).append(", z = ").append(this.getZ());
        if (this.getButton() != null) {
            sb.append(", button = ").append(this.getButton());
        }
        if (this.getClickCount() > 1) {
            sb.append(", clickCount = ").append(this.getClickCount());
        }
        if (this.isPrimaryButtonDown()) {
            sb.append(", primaryButtonDown");
        }
        if (this.isMiddleButtonDown()) {
            sb.append(", middleButtonDown");
        }
        if (this.isSecondaryButtonDown()) {
            sb.append(", secondaryButtonDown");
        }
        if (this.isShiftDown()) {
            sb.append(", shiftDown");
        }
        if (this.isControlDown()) {
            sb.append(", controlDown");
        }
        if (this.isAltDown()) {
            sb.append(", altDown");
        }
        if (this.isMetaDown()) {
            sb.append(", metaDown");
        }
        if (this.isShortcutDown()) {
            sb.append(", shortcutDown");
        }
        if (this.isSynthesized()) {
            sb.append(", synthesized");
        }
        sb.append(", pickResult = ").append(this.getPickResult());
        return sb.append("]").toString();
    }
    
    @Override
    public MouseDragEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (MouseDragEvent)super.copyFor(o, eventTarget);
    }
    
    @Override
    public MouseDragEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<? extends MouseEvent> eventType) {
        return (MouseDragEvent)super.copyFor(o, eventTarget, eventType);
    }
    
    @Override
    public EventType<MouseDragEvent> getEventType() {
        return (EventType<MouseDragEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<MouseDragEvent>(MouseEvent.ANY, "MOUSE-DRAG");
        MOUSE_DRAG_OVER = new EventType<MouseDragEvent>(MouseDragEvent.ANY, "MOUSE-DRAG_OVER");
        MOUSE_DRAG_RELEASED = new EventType<MouseDragEvent>(MouseDragEvent.ANY, "MOUSE-DRAG_RELEASED");
        MOUSE_DRAG_ENTERED_TARGET = new EventType<MouseDragEvent>(MouseDragEvent.ANY, "MOUSE-DRAG_ENTERED_TARGET");
        MOUSE_DRAG_ENTERED = new EventType<MouseDragEvent>(MouseDragEvent.MOUSE_DRAG_ENTERED_TARGET, "MOUSE-DRAG_ENTERED");
        MOUSE_DRAG_EXITED_TARGET = new EventType<MouseDragEvent>(MouseDragEvent.ANY, "MOUSE-DRAG_EXITED_TARGET");
        MOUSE_DRAG_EXITED = new EventType<MouseDragEvent>(MouseDragEvent.MOUSE_DRAG_EXITED_TARGET, "MOUSE-DRAG_EXITED");
    }
}
