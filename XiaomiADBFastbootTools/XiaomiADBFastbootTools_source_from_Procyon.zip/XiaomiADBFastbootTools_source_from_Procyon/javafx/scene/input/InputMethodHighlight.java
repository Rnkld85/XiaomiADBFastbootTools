// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

public enum InputMethodHighlight
{
    UNSELECTED_RAW, 
    SELECTED_RAW, 
    UNSELECTED_CONVERTED, 
    SELECTED_CONVERTED;
}
