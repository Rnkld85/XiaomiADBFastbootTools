// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import com.sun.javafx.tk.Toolkit;
import javafx.beans.NamedArg;

public final class KeyCharacterCombination extends KeyCombination
{
    private String character;
    
    public final String getCharacter() {
        return this.character;
    }
    
    public KeyCharacterCombination(@NamedArg("character") final String character, @NamedArg("shift") final ModifierValue modifierValue, @NamedArg("control") final ModifierValue modifierValue2, @NamedArg("alt") final ModifierValue modifierValue3, @NamedArg("meta") final ModifierValue modifierValue4, @NamedArg("shortcut") final ModifierValue modifierValue5) {
        super(modifierValue, modifierValue2, modifierValue3, modifierValue4, modifierValue5);
        this.character = "";
        validateKeyCharacter(character);
        this.character = character;
    }
    
    public KeyCharacterCombination(@NamedArg("character") final String character, @NamedArg("modifiers") final Modifier... array) {
        super(array);
        this.character = "";
        validateKeyCharacter(character);
        this.character = character;
    }
    
    @Override
    public boolean match(final KeyEvent keyEvent) {
        return keyEvent.getCode() != KeyCode.UNDEFINED && keyEvent.getCode().getCode() == Toolkit.getToolkit().getKeyCodeForChar(this.getCharacter()) && super.match(keyEvent);
    }
    
    @Override
    public String getName() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.getName());
        if (sb.length() > 0) {
            sb.append("+");
        }
        return sb.append('\'').append(this.character.replace("'", "\\'")).append('\'').toString();
    }
    
    @Override
    public String getDisplayText() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.getDisplayText());
        sb.append(this.getCharacter());
        return sb.toString();
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof KeyCharacterCombination && this.character.equals(((KeyCharacterCombination)o).getCharacter()) && super.equals(o));
    }
    
    @Override
    public int hashCode() {
        return 23 * super.hashCode() + this.character.hashCode();
    }
    
    private static void validateKeyCharacter(final String s) {
        if (s == null) {
            throw new NullPointerException("Key character must not be null!");
        }
    }
}
