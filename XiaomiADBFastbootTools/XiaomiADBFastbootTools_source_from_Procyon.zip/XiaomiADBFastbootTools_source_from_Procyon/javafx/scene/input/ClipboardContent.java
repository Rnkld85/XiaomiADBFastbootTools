// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import java.util.Iterator;
import java.util.ArrayList;
import java.io.File;
import java.util.List;
import javafx.scene.image.Image;
import java.util.HashMap;

public class ClipboardContent extends HashMap<DataFormat, Object>
{
    public final boolean hasString() {
        return this.containsKey(DataFormat.PLAIN_TEXT);
    }
    
    public final boolean putString(final String value) {
        if (value == null) {
            this.remove(DataFormat.PLAIN_TEXT);
        }
        else {
            ((HashMap<DataFormat, String>)this).put(DataFormat.PLAIN_TEXT, value);
        }
        return true;
    }
    
    public final String getString() {
        return ((HashMap<K, String>)this).get(DataFormat.PLAIN_TEXT);
    }
    
    public final boolean hasUrl() {
        return this.containsKey(DataFormat.URL);
    }
    
    public final boolean putUrl(final String value) {
        if (value == null) {
            this.remove(DataFormat.URL);
        }
        else {
            ((HashMap<DataFormat, String>)this).put(DataFormat.URL, value);
        }
        return true;
    }
    
    public final String getUrl() {
        return ((HashMap<K, String>)this).get(DataFormat.URL);
    }
    
    public final boolean hasHtml() {
        return this.containsKey(DataFormat.HTML);
    }
    
    public final boolean putHtml(final String value) {
        if (value == null) {
            this.remove(DataFormat.HTML);
        }
        else {
            ((HashMap<DataFormat, String>)this).put(DataFormat.HTML, value);
        }
        return true;
    }
    
    public final String getHtml() {
        return ((HashMap<K, String>)this).get(DataFormat.HTML);
    }
    
    public final boolean hasRtf() {
        return this.containsKey(DataFormat.RTF);
    }
    
    public final boolean putRtf(final String value) {
        if (value == null) {
            this.remove(DataFormat.RTF);
        }
        else {
            ((HashMap<DataFormat, String>)this).put(DataFormat.RTF, value);
        }
        return true;
    }
    
    public final String getRtf() {
        return ((HashMap<K, String>)this).get(DataFormat.RTF);
    }
    
    public final boolean hasImage() {
        return this.containsKey(DataFormat.IMAGE);
    }
    
    public final boolean putImage(final Image value) {
        if (value == null) {
            this.remove(DataFormat.IMAGE);
        }
        else {
            ((HashMap<DataFormat, Image>)this).put(DataFormat.IMAGE, value);
        }
        return true;
    }
    
    public final Image getImage() {
        return ((HashMap<K, Image>)this).get(DataFormat.IMAGE);
    }
    
    public final boolean hasFiles() {
        return this.containsKey(DataFormat.FILES);
    }
    
    public final boolean putFiles(final List<File> value) {
        if (value == null) {
            this.remove(DataFormat.FILES);
        }
        else {
            ((HashMap<DataFormat, List<File>>)this).put(DataFormat.FILES, value);
        }
        return true;
    }
    
    public final boolean putFilesByPath(final List<String> list) {
        final ArrayList<File> list2 = new ArrayList<File>(list.size());
        final Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            list2.add(new File(iterator.next()));
        }
        return this.putFiles(list2);
    }
    
    public final List<File> getFiles() {
        return ((HashMap<K, List<File>>)this).get(DataFormat.FILES);
    }
}
