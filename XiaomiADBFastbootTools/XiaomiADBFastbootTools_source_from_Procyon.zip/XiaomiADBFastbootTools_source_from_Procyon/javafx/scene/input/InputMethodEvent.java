// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.io.ObjectOutputStream;
import java.util.Collection;
import javafx.collections.FXCollections;
import java.util.List;
import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.collections.ObservableList;
import javafx.event.EventType;

public final class InputMethodEvent extends InputEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<InputMethodEvent> INPUT_METHOD_TEXT_CHANGED;
    public static final EventType<InputMethodEvent> ANY;
    private transient ObservableList<InputMethodTextRun> composed;
    private final String committed;
    private final int caretPosition;
    
    public InputMethodEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<InputMethodEvent> eventType, @NamedArg("composed") final List<InputMethodTextRun> list, @NamedArg("committed") final String committed, @NamedArg("caretPosition") final int caretPosition) {
        super(o, eventTarget, eventType);
        this.composed = FXCollections.unmodifiableObservableList(FXCollections.observableArrayList((Collection<? extends InputMethodTextRun>)list));
        this.committed = committed;
        this.caretPosition = caretPosition;
    }
    
    public InputMethodEvent(@NamedArg("eventType") final EventType<InputMethodEvent> eventType, @NamedArg("composed") final List<InputMethodTextRun> list, @NamedArg("committed") final String s, @NamedArg("caretPosition") final int n) {
        this(null, null, eventType, list, s, n);
    }
    
    public final ObservableList<InputMethodTextRun> getComposed() {
        return this.composed;
    }
    
    public final String getCommitted() {
        return this.committed;
    }
    
    public final int getCaretPosition() {
        return this.caretPosition;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("InputMethodEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", composed = ").append(this.getComposed());
        sb.append(", committed = ").append(this.getCommitted());
        sb.append(", caretPosition = ").append(this.getCaretPosition());
        return sb.append("]").toString();
    }
    
    @Override
    public InputMethodEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (InputMethodEvent)super.copyFor(o, eventTarget);
    }
    
    @Override
    public EventType<InputMethodEvent> getEventType() {
        return (EventType<InputMethodEvent>)super.getEventType();
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
        objectOutputStream.writeObject(new ArrayList(this.composed));
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.composed = FXCollections.unmodifiableObservableList(FXCollections.observableArrayList((Collection<? extends InputMethodTextRun>)objectInputStream.readObject()));
    }
    
    static {
        INPUT_METHOD_TEXT_CHANGED = new EventType<InputMethodEvent>(InputEvent.ANY, "INPUT_METHOD_TEXT_CHANGED");
        ANY = InputMethodEvent.INPUT_METHOD_TEXT_CHANGED;
    }
}
