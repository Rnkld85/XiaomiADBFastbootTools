// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import com.sun.javafx.scene.input.DragboardHelper;
import javafx.scene.image.Image;
import java.util.Set;
import com.sun.javafx.tk.PermissionHelper;
import com.sun.javafx.tk.TKClipboard;

public final class Dragboard extends Clipboard
{
    private boolean dataAccessRestricted;
    
    Dragboard(final TKClipboard tkClipboard) {
        super(tkClipboard);
        this.dataAccessRestricted = true;
    }
    
    @Override
    Object getContentImpl(final DataFormat dataFormat) {
        if (this.dataAccessRestricted) {
            PermissionHelper.checkClipboardPermission();
        }
        return super.getContentImpl(dataFormat);
    }
    
    public final Set<TransferMode> getTransferModes() {
        return this.peer.getTransferModes();
    }
    
    TKClipboard getPeer() {
        return this.peer;
    }
    
    static Dragboard createDragboard(final TKClipboard tkClipboard) {
        return new Dragboard(tkClipboard);
    }
    
    public void setDragView(final Image dragView, final double dragViewOffsetX, final double dragViewOffsetY) {
        this.peer.setDragView(dragView);
        this.peer.setDragViewOffsetX(dragViewOffsetX);
        this.peer.setDragViewOffsetY(dragViewOffsetY);
    }
    
    public void setDragView(final Image dragView) {
        this.peer.setDragView(dragView);
    }
    
    public void setDragViewOffsetX(final double dragViewOffsetX) {
        this.peer.setDragViewOffsetX(dragViewOffsetX);
    }
    
    public void setDragViewOffsetY(final double dragViewOffsetY) {
        this.peer.setDragViewOffsetY(dragViewOffsetY);
    }
    
    public Image getDragView() {
        return this.peer.getDragView();
    }
    
    public double getDragViewOffsetX() {
        return this.peer.getDragViewOffsetX();
    }
    
    public double getDragViewOffsetY() {
        return this.peer.getDragViewOffsetY();
    }
    
    static {
        DragboardHelper.setDragboardAccessor(new DragboardHelper.DragboardAccessor() {
            @Override
            public void setDataAccessRestriction(final Dragboard dragboard, final boolean b) {
                dragboard.dataAccessRestricted = b;
            }
            
            @Override
            public TKClipboard getPeer(final Dragboard dragboard) {
                return dragboard.getPeer();
            }
            
            @Override
            public Dragboard createDragboard(final TKClipboard tkClipboard) {
                return Dragboard.createDragboard(tkClipboard);
            }
        });
    }
}
