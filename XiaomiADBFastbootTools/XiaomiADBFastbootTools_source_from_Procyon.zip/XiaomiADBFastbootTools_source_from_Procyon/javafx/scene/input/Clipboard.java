// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import com.sun.javafx.scene.input.ClipboardHelper;
import java.io.File;
import java.util.List;
import javafx.scene.image.Image;
import java.util.Iterator;
import javafx.util.Pair;
import java.util.Set;
import java.util.Map;
import com.sun.javafx.tk.Toolkit;
import java.security.AccessController;
import com.sun.javafx.tk.PermissionHelper;
import com.sun.javafx.tk.TKClipboard;
import java.security.AccessControlContext;

public class Clipboard
{
    private boolean contentPut;
    private final AccessControlContext acc;
    TKClipboard peer;
    private static Clipboard systemClipboard;
    private static Clipboard localClipboard;
    
    public static Clipboard getSystemClipboard() {
        try {
            PermissionHelper.checkClipboardPermission();
            return getSystemClipboardImpl();
        }
        catch (SecurityException ex) {
            return getLocalClipboardImpl();
        }
    }
    
    Clipboard(final TKClipboard peer) {
        this.contentPut = false;
        this.acc = AccessController.getContext();
        Toolkit.getToolkit().checkFxUserThread();
        if (peer == null) {
            throw new NullPointerException();
        }
        peer.setSecurityContext(this.acc);
        this.peer = peer;
    }
    
    public final void clear() {
        this.setContent(null);
    }
    
    public final Set<DataFormat> getContentTypes() {
        return this.peer.getContentTypes();
    }
    
    public final boolean setContent(final Map<DataFormat, Object> map) {
        Toolkit.getToolkit().checkFxUserThread();
        if (map == null) {
            this.contentPut = false;
            this.peer.putContent((Pair<DataFormat, Object>[])new Pair[0]);
            return true;
        }
        final Pair[] array = new Pair[map.size()];
        int n = 0;
        for (final Map.Entry<DataFormat, Object> entry : map.entrySet()) {
            array[n++] = new Pair<DataFormat, Object>(entry.getKey(), entry.getValue());
        }
        return this.contentPut = this.peer.putContent((Pair<DataFormat, Object>[])array);
    }
    
    public final Object getContent(final DataFormat dataFormat) {
        Toolkit.getToolkit().checkFxUserThread();
        return this.getContentImpl(dataFormat);
    }
    
    Object getContentImpl(final DataFormat dataFormat) {
        return this.peer.getContent(dataFormat);
    }
    
    public final boolean hasContent(final DataFormat dataFormat) {
        Toolkit.getToolkit().checkFxUserThread();
        return this.peer.hasContent(dataFormat);
    }
    
    public final boolean hasString() {
        return this.hasContent(DataFormat.PLAIN_TEXT);
    }
    
    public final String getString() {
        return (String)this.getContent(DataFormat.PLAIN_TEXT);
    }
    
    public final boolean hasUrl() {
        return this.hasContent(DataFormat.URL);
    }
    
    public final String getUrl() {
        return (String)this.getContent(DataFormat.URL);
    }
    
    public final boolean hasHtml() {
        return this.hasContent(DataFormat.HTML);
    }
    
    public final String getHtml() {
        return (String)this.getContent(DataFormat.HTML);
    }
    
    public final boolean hasRtf() {
        return this.hasContent(DataFormat.RTF);
    }
    
    public final String getRtf() {
        return (String)this.getContent(DataFormat.RTF);
    }
    
    public final boolean hasImage() {
        return this.hasContent(DataFormat.IMAGE);
    }
    
    public final Image getImage() {
        return (Image)this.getContent(DataFormat.IMAGE);
    }
    
    public final boolean hasFiles() {
        return this.hasContent(DataFormat.FILES);
    }
    
    public final List<File> getFiles() {
        return (List<File>)this.getContent(DataFormat.FILES);
    }
    
    boolean contentPut() {
        return this.contentPut;
    }
    
    private static synchronized Clipboard getSystemClipboardImpl() {
        if (Clipboard.systemClipboard == null) {
            Clipboard.systemClipboard = new Clipboard(Toolkit.getToolkit().getSystemClipboard());
        }
        return Clipboard.systemClipboard;
    }
    
    private static synchronized Clipboard getLocalClipboardImpl() {
        if (Clipboard.localClipboard == null) {
            Clipboard.localClipboard = new Clipboard(Toolkit.getToolkit().createLocalClipboard());
        }
        return Clipboard.localClipboard;
    }
    
    static {
        ClipboardHelper.setClipboardAccessor(new ClipboardHelper.ClipboardAccessor() {
            @Override
            public boolean contentPut(final Clipboard clipboard) {
                return clipboard.contentPut();
            }
        });
    }
}
