// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.beans.NamedArg;
import javafx.scene.Node;

public class Mnemonic
{
    private KeyCombination keyCombination;
    private Node node;
    
    public Mnemonic(@NamedArg("node") final Node node, @NamedArg("keyCombination") final KeyCombination keyCombination) {
        this.node = node;
        this.keyCombination = keyCombination;
    }
    
    public KeyCombination getKeyCombination() {
        return this.keyCombination;
    }
    
    public void setKeyCombination(final KeyCombination keyCombination) {
        this.keyCombination = keyCombination;
    }
    
    public Node getNode() {
        return this.node;
    }
    
    public void setNode(final Node node) {
        this.node = node;
    }
    
    public void fire() {
        if (this.node != null) {
            this.node.fireEvent(new ActionEvent());
        }
    }
}
