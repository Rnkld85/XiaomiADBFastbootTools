// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import java.util.Iterator;
import java.util.Collections;
import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import java.util.List;
import javafx.event.EventType;

public final class TouchEvent extends InputEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<TouchEvent> ANY;
    public static final EventType<TouchEvent> TOUCH_PRESSED;
    public static final EventType<TouchEvent> TOUCH_MOVED;
    public static final EventType<TouchEvent> TOUCH_RELEASED;
    public static final EventType<TouchEvent> TOUCH_STATIONARY;
    private final int eventSetId;
    private final boolean shiftDown;
    private final boolean controlDown;
    private final boolean altDown;
    private final boolean metaDown;
    private final TouchPoint touchPoint;
    private final List<TouchPoint> touchPoints;
    
    public TouchEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<TouchEvent> eventType, @NamedArg("touchPoint") final TouchPoint touchPoint, @NamedArg("touchPoints") final List<TouchPoint> list, @NamedArg("eventSetId") final int eventSetId, @NamedArg("shiftDown") final boolean shiftDown, @NamedArg("controlDown") final boolean controlDown, @NamedArg("altDown") final boolean altDown, @NamedArg("metaDown") final boolean metaDown) {
        super(o, eventTarget, eventType);
        this.touchPoints = ((list != null) ? Collections.unmodifiableList((List<? extends TouchPoint>)list) : null);
        this.eventSetId = eventSetId;
        this.shiftDown = shiftDown;
        this.controlDown = controlDown;
        this.altDown = altDown;
        this.metaDown = metaDown;
        this.touchPoint = touchPoint;
    }
    
    public TouchEvent(@NamedArg("eventType") final EventType<TouchEvent> eventType, @NamedArg("touchPoint") final TouchPoint touchPoint, @NamedArg("touchPoints") final List<TouchPoint> list, @NamedArg("eventSetId") final int n, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4) {
        this(null, null, eventType, touchPoint, list, n, b, b2, b3, b4);
    }
    
    public int getTouchCount() {
        return this.touchPoints.size();
    }
    
    private static void recomputeToSource(final TouchEvent touchEvent, final Object o, final Object o2) {
        final Iterator<TouchPoint> iterator = touchEvent.touchPoints.iterator();
        while (iterator.hasNext()) {
            iterator.next().recomputeToSource(o, o2);
        }
    }
    
    @Override
    public TouchEvent copyFor(final Object o, final EventTarget eventTarget) {
        final TouchEvent touchEvent = (TouchEvent)super.copyFor(o, eventTarget);
        recomputeToSource(touchEvent, this.getSource(), o);
        return touchEvent;
    }
    
    public TouchEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<TouchEvent> eventType) {
        final TouchEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    @Override
    public EventType<TouchEvent> getEventType() {
        return (EventType<TouchEvent>)super.getEventType();
    }
    
    public final int getEventSetId() {
        return this.eventSetId;
    }
    
    public final boolean isShiftDown() {
        return this.shiftDown;
    }
    
    public final boolean isControlDown() {
        return this.controlDown;
    }
    
    public final boolean isAltDown() {
        return this.altDown;
    }
    
    public final boolean isMetaDown() {
        return this.metaDown;
    }
    
    public TouchPoint getTouchPoint() {
        return this.touchPoint;
    }
    
    public List<TouchPoint> getTouchPoints() {
        return this.touchPoints;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TouchEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", touchCount = ").append(this.getTouchCount());
        sb.append(", eventSetId = ").append(this.getEventSetId());
        sb.append(", touchPoint = ").append(this.getTouchPoint().toString());
        return sb.append("]").toString();
    }
    
    static {
        ANY = new EventType<TouchEvent>(InputEvent.ANY, "TOUCH");
        TOUCH_PRESSED = new EventType<TouchEvent>(TouchEvent.ANY, "TOUCH_PRESSED");
        TOUCH_MOVED = new EventType<TouchEvent>(TouchEvent.ANY, "TOUCH_MOVED");
        TOUCH_RELEASED = new EventType<TouchEvent>(TouchEvent.ANY, "TOUCH_RELEASED");
        TOUCH_STATIONARY = new EventType<TouchEvent>(TouchEvent.ANY, "TOUCH_STATIONARY");
    }
}
