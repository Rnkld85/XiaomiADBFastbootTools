// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;

public final class SwipeEvent extends GestureEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<SwipeEvent> ANY;
    public static final EventType<SwipeEvent> SWIPE_LEFT;
    public static final EventType<SwipeEvent> SWIPE_RIGHT;
    public static final EventType<SwipeEvent> SWIPE_UP;
    public static final EventType<SwipeEvent> SWIPE_DOWN;
    private final int touchCount;
    
    public SwipeEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<SwipeEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("direct") final boolean b5, @NamedArg("touchCount") final int touchCount, @NamedArg("pickResult") final PickResult pickResult) {
        super(o, eventTarget, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, false, pickResult);
        this.touchCount = touchCount;
    }
    
    public SwipeEvent(@NamedArg("eventType") final EventType<SwipeEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("direct") final boolean b5, @NamedArg("touchCount") final int n5, @NamedArg("pickResult") final PickResult pickResult) {
        this(null, null, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, n5, pickResult);
    }
    
    public int getTouchCount() {
        return this.touchCount;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SwipeEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", touchCount = ").append(this.getTouchCount());
        sb.append(", x = ").append(this.getX()).append(", y = ").append(this.getY()).append(", z = ").append(this.getZ());
        sb.append(this.isDirect() ? ", direct" : ", indirect");
        if (this.isShiftDown()) {
            sb.append(", shiftDown");
        }
        if (this.isControlDown()) {
            sb.append(", controlDown");
        }
        if (this.isAltDown()) {
            sb.append(", altDown");
        }
        if (this.isMetaDown()) {
            sb.append(", metaDown");
        }
        if (this.isShortcutDown()) {
            sb.append(", shortcutDown");
        }
        sb.append(", pickResult = ").append(this.getPickResult());
        return sb.append("]").toString();
    }
    
    @Override
    public SwipeEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (SwipeEvent)super.copyFor(o, eventTarget);
    }
    
    public SwipeEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<SwipeEvent> eventType) {
        final SwipeEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    @Override
    public EventType<SwipeEvent> getEventType() {
        return (EventType<SwipeEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<SwipeEvent>(GestureEvent.ANY, "ANY_SWIPE");
        SWIPE_LEFT = new EventType<SwipeEvent>(SwipeEvent.ANY, "SWIPE_LEFT");
        SWIPE_RIGHT = new EventType<SwipeEvent>(SwipeEvent.ANY, "SWIPE_RIGHT");
        SWIPE_UP = new EventType<SwipeEvent>(SwipeEvent.ANY, "SWIPE_UP");
        SWIPE_DOWN = new EventType<SwipeEvent>(SwipeEvent.ANY, "SWIPE_DOWN");
    }
}
