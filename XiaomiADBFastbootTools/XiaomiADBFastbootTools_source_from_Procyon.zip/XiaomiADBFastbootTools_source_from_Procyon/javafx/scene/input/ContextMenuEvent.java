// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import java.io.IOException;
import java.io.ObjectInputStream;
import javafx.geometry.Point3D;
import com.sun.javafx.scene.input.InputEventUtils;
import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;

public class ContextMenuEvent extends InputEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<ContextMenuEvent> CONTEXT_MENU_REQUESTED;
    public static final EventType<ContextMenuEvent> ANY;
    private final boolean keyboardTrigger;
    private transient double x;
    private transient double y;
    private transient double z;
    private final double screenX;
    private final double screenY;
    private final double sceneX;
    private final double sceneY;
    private PickResult pickResult;
    
    public ContextMenuEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<ContextMenuEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double screenX, @NamedArg("screenY") final double screenY, @NamedArg("keyboardTrigger") final boolean keyboardTrigger, @NamedArg("pickResult") final PickResult pickResult) {
        super(o, eventTarget, eventType);
        this.screenX = screenX;
        this.screenY = screenY;
        this.sceneX = n;
        this.sceneY = n2;
        this.x = n;
        this.y = n2;
        this.pickResult = ((pickResult != null) ? pickResult : new PickResult(eventTarget, n, n2));
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, null);
        this.x = recomputeCoordinates.getX();
        this.y = recomputeCoordinates.getY();
        this.z = recomputeCoordinates.getZ();
        this.keyboardTrigger = keyboardTrigger;
    }
    
    public ContextMenuEvent(@NamedArg("eventType") final EventType<ContextMenuEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("keyboardTrigger") final boolean b, @NamedArg("pickResult") final PickResult pickResult) {
        this(null, null, eventType, n, n2, n3, n4, b, pickResult);
    }
    
    private void recomputeCoordinatesToSource(final ContextMenuEvent contextMenuEvent, final Object o) {
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, o);
        contextMenuEvent.x = recomputeCoordinates.getX();
        contextMenuEvent.y = recomputeCoordinates.getY();
        contextMenuEvent.z = recomputeCoordinates.getZ();
    }
    
    @Override
    public ContextMenuEvent copyFor(final Object o, final EventTarget eventTarget) {
        final ContextMenuEvent contextMenuEvent = (ContextMenuEvent)super.copyFor(o, eventTarget);
        this.recomputeCoordinatesToSource(contextMenuEvent, o);
        return contextMenuEvent;
    }
    
    @Override
    public EventType<ContextMenuEvent> getEventType() {
        return (EventType<ContextMenuEvent>)super.getEventType();
    }
    
    public boolean isKeyboardTrigger() {
        return this.keyboardTrigger;
    }
    
    public final double getX() {
        return this.x;
    }
    
    public final double getY() {
        return this.y;
    }
    
    public final double getZ() {
        return this.z;
    }
    
    public final double getScreenX() {
        return this.screenX;
    }
    
    public final double getScreenY() {
        return this.screenY;
    }
    
    public final double getSceneX() {
        return this.sceneX;
    }
    
    public final double getSceneY() {
        return this.sceneY;
    }
    
    public final PickResult getPickResult() {
        return this.pickResult;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ContextMenuEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", x = ").append(this.getX()).append(", y = ").append(this.getY()).append(", z = ").append(this.getZ());
        sb.append(", pickResult = ").append(this.getPickResult());
        return sb.append("]").toString();
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.x = this.sceneX;
        this.y = this.sceneY;
    }
    
    static {
        CONTEXT_MENU_REQUESTED = new EventType<ContextMenuEvent>(InputEvent.ANY, "CONTEXTMENUREQUESTED");
        ANY = ContextMenuEvent.CONTEXT_MENU_REQUESTED;
    }
}
