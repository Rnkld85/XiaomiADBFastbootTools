// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

public enum TransferMode
{
    COPY, 
    MOVE, 
    LINK;
    
    public static final TransferMode[] ANY;
    public static final TransferMode[] COPY_OR_MOVE;
    public static final TransferMode[] NONE;
    
    static {
        ANY = new TransferMode[] { TransferMode.COPY, TransferMode.MOVE, TransferMode.LINK };
        COPY_OR_MOVE = new TransferMode[] { TransferMode.COPY, TransferMode.MOVE };
        NONE = new TransferMode[0];
    }
}
