// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;
import javafx.event.Event;

public class InputEvent extends Event
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<InputEvent> ANY;
    
    public InputEvent(@NamedArg("eventType") final EventType<? extends InputEvent> eventType) {
        super(eventType);
    }
    
    public InputEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<? extends InputEvent> eventType) {
        super(o, eventTarget, eventType);
    }
    
    @Override
    public EventType<? extends InputEvent> getEventType() {
        return (EventType<? extends InputEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<InputEvent>(Event.ANY, "INPUT");
    }
}
