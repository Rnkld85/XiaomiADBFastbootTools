// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.geometry.Point2D;
import javafx.geometry.Point3D;
import javafx.scene.Node;

public class PickResult
{
    public static final int FACE_UNDEFINED = -1;
    private Node node;
    private Point3D point;
    private double distance;
    private int face;
    private Point3D normal;
    private Point2D texCoord;
    
    public PickResult(@NamedArg("node") final Node node, @NamedArg("point") final Point3D point, @NamedArg("distance") final double distance, @NamedArg("face") final int face, @NamedArg("texCoord") final Point2D texCoord) {
        this.distance = Double.POSITIVE_INFINITY;
        this.face = -1;
        this.node = node;
        this.point = point;
        this.distance = distance;
        this.face = face;
        this.normal = null;
        this.texCoord = texCoord;
    }
    
    public PickResult(@NamedArg("node") final Node node, @NamedArg("point") final Point3D point, @NamedArg("distance") final double distance, @NamedArg("face") final int face, @NamedArg("normal") final Point3D normal, @NamedArg("texCoord") final Point2D texCoord) {
        this.distance = Double.POSITIVE_INFINITY;
        this.face = -1;
        this.node = node;
        this.point = point;
        this.distance = distance;
        this.face = face;
        this.normal = normal;
        this.texCoord = texCoord;
    }
    
    public PickResult(@NamedArg("node") final Node node, @NamedArg("point") final Point3D point, @NamedArg("distance") final double distance) {
        this.distance = Double.POSITIVE_INFINITY;
        this.face = -1;
        this.node = node;
        this.point = point;
        this.distance = distance;
        this.face = -1;
        this.normal = null;
        this.texCoord = null;
    }
    
    public PickResult(@NamedArg("target") final EventTarget eventTarget, @NamedArg("sceneX") final double n, @NamedArg("sceneY") final double n2) {
        this((eventTarget instanceof Node) ? ((Node)eventTarget) : null, (eventTarget instanceof Node) ? ((Node)eventTarget).sceneToLocal(n, n2, 0.0) : new Point3D(n, n2, 0.0), 1.0);
    }
    
    public final Node getIntersectedNode() {
        return this.node;
    }
    
    public final Point3D getIntersectedPoint() {
        return this.point;
    }
    
    public final double getIntersectedDistance() {
        return this.distance;
    }
    
    public final int getIntersectedFace() {
        return this.face;
    }
    
    public final Point3D getIntersectedNormal() {
        return this.normal;
    }
    
    public final Point2D getIntersectedTexCoord() {
        return this.texCoord;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PickResult [");
        sb.append("node = ").append(this.getIntersectedNode()).append(", point = ").append(this.getIntersectedPoint()).append(", distance = ").append(this.getIntersectedDistance());
        if (this.getIntersectedFace() != -1) {
            sb.append(", face = ").append(this.getIntersectedFace());
        }
        if (this.getIntersectedNormal() != null) {
            sb.append(", normal = ").append(this.getIntersectedNormal());
        }
        if (this.getIntersectedTexCoord() != null) {
            sb.append(", texCoord = ").append(this.getIntersectedTexCoord());
        }
        return sb.toString();
    }
}
