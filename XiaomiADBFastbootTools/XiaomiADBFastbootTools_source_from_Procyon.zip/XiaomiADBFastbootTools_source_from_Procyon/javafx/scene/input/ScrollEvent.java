// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import javafx.beans.NamedArg;
import javafx.event.EventTarget;
import javafx.event.EventType;

public final class ScrollEvent extends GestureEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<ScrollEvent> ANY;
    public static final EventType<ScrollEvent> SCROLL;
    public static final EventType<ScrollEvent> SCROLL_STARTED;
    public static final EventType<ScrollEvent> SCROLL_FINISHED;
    private final double deltaX;
    private final double deltaY;
    private double totalDeltaX;
    private final double totalDeltaY;
    private final HorizontalTextScrollUnits textDeltaXUnits;
    private final VerticalTextScrollUnits textDeltaYUnits;
    private final double textDeltaX;
    private final double textDeltaY;
    private final int touchCount;
    private final double multiplierX;
    private final double multiplierY;
    
    private ScrollEvent(final Object o, final EventTarget eventTarget, final EventType<ScrollEvent> eventType, final double n, final double n2, final double n3, final double n4, final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5, final boolean b6, final double deltaX, final double deltaY, final double totalDeltaX, final double totalDeltaY, final double multiplierX, final double multiplierY, final HorizontalTextScrollUnits textDeltaXUnits, final double textDeltaX, final VerticalTextScrollUnits textDeltaYUnits, final double textDeltaY, final int touchCount, final PickResult pickResult) {
        super(o, eventTarget, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, b6, pickResult);
        this.deltaX = deltaX;
        this.deltaY = deltaY;
        this.totalDeltaX = totalDeltaX;
        this.totalDeltaY = totalDeltaY;
        this.textDeltaXUnits = textDeltaXUnits;
        this.textDeltaX = textDeltaX;
        this.textDeltaYUnits = textDeltaYUnits;
        this.textDeltaY = textDeltaY;
        this.touchCount = touchCount;
        this.multiplierX = multiplierX;
        this.multiplierY = multiplierY;
    }
    
    public ScrollEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<ScrollEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("direct") final boolean b5, @NamedArg("inertia") final boolean b6, @NamedArg("deltaX") final double n5, @NamedArg("deltaY") final double n6, @NamedArg("totalDeltaX") final double n7, @NamedArg("totalDeltaY") final double n8, @NamedArg("textDeltaXUnits") final HorizontalTextScrollUnits horizontalTextScrollUnits, @NamedArg("textDeltaX") final double n9, @NamedArg("textDeltaYUnits") final VerticalTextScrollUnits verticalTextScrollUnits, @NamedArg("textDeltaY") final double n10, @NamedArg("touchCount") final int n11, @NamedArg("pickResult") final PickResult pickResult) {
        this(o, eventTarget, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, b6, n5, n6, n7, n8, 1.0, 1.0, horizontalTextScrollUnits, n9, verticalTextScrollUnits, n10, n11, pickResult);
    }
    
    public ScrollEvent(@NamedArg("eventType") final EventType<ScrollEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("direct") final boolean b5, @NamedArg("inertia") final boolean b6, @NamedArg("deltaX") final double n5, @NamedArg("deltaY") final double n6, @NamedArg("totalDeltaX") final double n7, @NamedArg("totalDeltaY") final double n8, @NamedArg("textDeltaXUnits") final HorizontalTextScrollUnits horizontalTextScrollUnits, @NamedArg("textDeltaX") final double n9, @NamedArg("textDeltaYUnits") final VerticalTextScrollUnits verticalTextScrollUnits, @NamedArg("textDeltaY") final double n10, @NamedArg("touchCount") final int n11, @NamedArg("pickResult") final PickResult pickResult) {
        this(null, null, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, b6, n5, n6, n7, n8, 1.0, 1.0, horizontalTextScrollUnits, n9, verticalTextScrollUnits, n10, n11, pickResult);
    }
    
    public ScrollEvent(@NamedArg("eventType") final EventType<ScrollEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("direct") final boolean b5, @NamedArg("inertia") final boolean b6, @NamedArg("deltaX") final double n5, @NamedArg("deltaY") final double n6, @NamedArg("totalDeltaX") final double n7, @NamedArg("totalDeltaY") final double n8, @NamedArg("multiplierX") final double n9, @NamedArg("multiplierY") final double n10, @NamedArg("textDeltaXUnits") final HorizontalTextScrollUnits horizontalTextScrollUnits, @NamedArg("textDeltaX") final double n11, @NamedArg("textDeltaYUnits") final VerticalTextScrollUnits verticalTextScrollUnits, @NamedArg("textDeltaY") final double n12, @NamedArg("touchCount") final int n13, @NamedArg("pickResult") final PickResult pickResult) {
        this(null, null, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, b6, n5, n6, n7, n8, n9, n10, horizontalTextScrollUnits, n11, verticalTextScrollUnits, n12, n13, pickResult);
    }
    
    public double getDeltaX() {
        return this.deltaX;
    }
    
    public double getDeltaY() {
        return this.deltaY;
    }
    
    public double getTotalDeltaX() {
        return this.totalDeltaX;
    }
    
    public double getTotalDeltaY() {
        return this.totalDeltaY;
    }
    
    public HorizontalTextScrollUnits getTextDeltaXUnits() {
        return this.textDeltaXUnits;
    }
    
    public VerticalTextScrollUnits getTextDeltaYUnits() {
        return this.textDeltaYUnits;
    }
    
    public double getTextDeltaX() {
        return this.textDeltaX;
    }
    
    public double getTextDeltaY() {
        return this.textDeltaY;
    }
    
    public int getTouchCount() {
        return this.touchCount;
    }
    
    public double getMultiplierX() {
        return this.multiplierX;
    }
    
    public double getMultiplierY() {
        return this.multiplierY;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ScrollEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", deltaX = ").append(this.getDeltaX()).append(", deltaY = ").append(this.getDeltaY());
        sb.append(", totalDeltaX = ").append(this.getTotalDeltaX()).append(", totalDeltaY = ").append(this.getTotalDeltaY());
        sb.append(", textDeltaXUnits = ").append(this.getTextDeltaXUnits()).append(", textDeltaX = ").append(this.getTextDeltaX());
        sb.append(", textDeltaYUnits = ").append(this.getTextDeltaYUnits()).append(", textDeltaY = ").append(this.getTextDeltaY());
        sb.append(", touchCount = ").append(this.getTouchCount());
        sb.append(", x = ").append(this.getX()).append(", y = ").append(this.getY()).append(", z = ").append(this.getZ());
        sb.append(this.isDirect() ? ", direct" : ", indirect");
        if (this.isInertia()) {
            sb.append(", inertia");
        }
        if (this.isShiftDown()) {
            sb.append(", shiftDown");
        }
        if (this.isControlDown()) {
            sb.append(", controlDown");
        }
        if (this.isAltDown()) {
            sb.append(", altDown");
        }
        if (this.isMetaDown()) {
            sb.append(", metaDown");
        }
        if (this.isShortcutDown()) {
            sb.append(", shortcutDown");
        }
        sb.append(", pickResult = ").append(this.getPickResult());
        return sb.append("]").toString();
    }
    
    @Override
    public ScrollEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (ScrollEvent)super.copyFor(o, eventTarget);
    }
    
    public ScrollEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<ScrollEvent> eventType) {
        final ScrollEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    @Override
    public EventType<ScrollEvent> getEventType() {
        return (EventType<ScrollEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<ScrollEvent>(GestureEvent.ANY, "ANY_SCROLL");
        SCROLL = new EventType<ScrollEvent>(ScrollEvent.ANY, "SCROLL");
        SCROLL_STARTED = new EventType<ScrollEvent>(ScrollEvent.ANY, "SCROLL_STARTED");
        SCROLL_FINISHED = new EventType<ScrollEvent>(ScrollEvent.ANY, "SCROLL_FINISHED");
    }
    
    public enum HorizontalTextScrollUnits
    {
        NONE, 
        CHARACTERS;
    }
    
    public enum VerticalTextScrollUnits
    {
        NONE, 
        LINES, 
        PAGES;
    }
}
