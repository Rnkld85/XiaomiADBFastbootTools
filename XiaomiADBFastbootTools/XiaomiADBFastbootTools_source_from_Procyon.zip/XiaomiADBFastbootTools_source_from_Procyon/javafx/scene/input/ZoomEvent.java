// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;

public final class ZoomEvent extends GestureEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<ZoomEvent> ANY;
    public static final EventType<ZoomEvent> ZOOM;
    public static final EventType<ZoomEvent> ZOOM_STARTED;
    public static final EventType<ZoomEvent> ZOOM_FINISHED;
    private final double zoomFactor;
    private final double totalZoomFactor;
    
    public ZoomEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<ZoomEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("direct") final boolean b5, @NamedArg("inertia") final boolean b6, @NamedArg("zoomFactor") final double zoomFactor, @NamedArg("totalZoomFactor") final double totalZoomFactor, @NamedArg("pickResult") final PickResult pickResult) {
        super(o, eventTarget, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, b6, pickResult);
        this.zoomFactor = zoomFactor;
        this.totalZoomFactor = totalZoomFactor;
    }
    
    public ZoomEvent(@NamedArg("eventType") final EventType<ZoomEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("direct") final boolean b5, @NamedArg("inertia") final boolean b6, @NamedArg("zoomFactor") final double n5, @NamedArg("totalZoomFactor") final double n6, @NamedArg("pickResult") final PickResult pickResult) {
        this(null, null, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, b6, n5, n6, pickResult);
    }
    
    public double getZoomFactor() {
        return this.zoomFactor;
    }
    
    public double getTotalZoomFactor() {
        return this.totalZoomFactor;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ZoomEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", zoomFactor = ").append(this.getZoomFactor());
        sb.append(", totalZoomFactor = ").append(this.getTotalZoomFactor());
        sb.append(", x = ").append(this.getX()).append(", y = ").append(this.getY()).append(", z = ").append(this.getZ());
        sb.append(this.isDirect() ? ", direct" : ", indirect");
        if (this.isInertia()) {
            sb.append(", inertia");
        }
        if (this.isShiftDown()) {
            sb.append(", shiftDown");
        }
        if (this.isControlDown()) {
            sb.append(", controlDown");
        }
        if (this.isAltDown()) {
            sb.append(", altDown");
        }
        if (this.isMetaDown()) {
            sb.append(", metaDown");
        }
        if (this.isShortcutDown()) {
            sb.append(", shortcutDown");
        }
        sb.append(", pickResult = ").append(this.getPickResult());
        return sb.append("]").toString();
    }
    
    @Override
    public ZoomEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (ZoomEvent)super.copyFor(o, eventTarget);
    }
    
    public ZoomEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<ZoomEvent> eventType) {
        final ZoomEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    @Override
    public EventType<ZoomEvent> getEventType() {
        return (EventType<ZoomEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<ZoomEvent>(GestureEvent.ANY, "ANY_ZOOM");
        ZOOM = new EventType<ZoomEvent>(ZoomEvent.ANY, "ZOOM");
        ZOOM_STARTED = new EventType<ZoomEvent>(ZoomEvent.ANY, "ZOOM_STARTED");
        ZOOM_FINISHED = new EventType<ZoomEvent>(ZoomEvent.ANY, "ZOOM_FINISHED");
    }
}
