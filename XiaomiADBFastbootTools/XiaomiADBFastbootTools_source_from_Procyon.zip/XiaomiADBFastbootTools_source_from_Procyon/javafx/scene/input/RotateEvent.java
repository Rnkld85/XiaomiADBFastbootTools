// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;

public final class RotateEvent extends GestureEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<RotateEvent> ANY;
    public static final EventType<RotateEvent> ROTATE;
    public static final EventType<RotateEvent> ROTATION_STARTED;
    public static final EventType<RotateEvent> ROTATION_FINISHED;
    private final double angle;
    private final double totalAngle;
    
    public RotateEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<RotateEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("direct") final boolean b5, @NamedArg("inertia") final boolean b6, @NamedArg("angle") final double angle, @NamedArg("totalAngle") final double totalAngle, @NamedArg("pickResult") final PickResult pickResult) {
        super(o, eventTarget, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, b6, pickResult);
        this.angle = angle;
        this.totalAngle = totalAngle;
    }
    
    public RotateEvent(@NamedArg("eventType") final EventType<RotateEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("direct") final boolean b5, @NamedArg("inertia") final boolean b6, @NamedArg("angle") final double n5, @NamedArg("totalAngle") final double n6, @NamedArg("pickResult") final PickResult pickResult) {
        this(null, null, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, b6, n5, n6, pickResult);
    }
    
    public double getAngle() {
        return this.angle;
    }
    
    public double getTotalAngle() {
        return this.totalAngle;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("RotateEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", angle = ").append(this.getAngle());
        sb.append(", totalAngle = ").append(this.getTotalAngle());
        sb.append(", x = ").append(this.getX()).append(", y = ").append(this.getY()).append(", z = ").append(this.getZ());
        sb.append(this.isDirect() ? ", direct" : ", indirect");
        if (this.isInertia()) {
            sb.append(", inertia");
        }
        if (this.isShiftDown()) {
            sb.append(", shiftDown");
        }
        if (this.isControlDown()) {
            sb.append(", controlDown");
        }
        if (this.isAltDown()) {
            sb.append(", altDown");
        }
        if (this.isMetaDown()) {
            sb.append(", metaDown");
        }
        if (this.isShortcutDown()) {
            sb.append(", shortcutDown");
        }
        sb.append(", pickResult = ").append(this.getPickResult());
        return sb.append("]").toString();
    }
    
    @Override
    public RotateEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (RotateEvent)super.copyFor(o, eventTarget);
    }
    
    public RotateEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<RotateEvent> eventType) {
        final RotateEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    @Override
    public EventType<RotateEvent> getEventType() {
        return (EventType<RotateEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<RotateEvent>(GestureEvent.ANY, "ANY_ROTATE");
        ROTATE = new EventType<RotateEvent>(RotateEvent.ANY, "ROTATE");
        ROTATION_STARTED = new EventType<RotateEvent>(RotateEvent.ANY, "ROTATION_STARTED");
        ROTATION_FINISHED = new EventType<RotateEvent>(RotateEvent.ANY, "ROTATION_FINISHED");
    }
}
