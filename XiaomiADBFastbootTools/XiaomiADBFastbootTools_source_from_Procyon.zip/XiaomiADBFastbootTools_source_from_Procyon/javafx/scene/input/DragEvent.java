// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Iterator;
import java.util.EnumSet;
import java.util.Set;
import javafx.geometry.Point3D;
import com.sun.javafx.scene.input.InputEventUtils;
import javafx.beans.NamedArg;
import javafx.event.EventTarget;
import javafx.event.EventType;

public final class DragEvent extends InputEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<DragEvent> ANY;
    public static final EventType<DragEvent> DRAG_ENTERED_TARGET;
    public static final EventType<DragEvent> DRAG_ENTERED;
    public static final EventType<DragEvent> DRAG_EXITED_TARGET;
    public static final EventType<DragEvent> DRAG_EXITED;
    public static final EventType<DragEvent> DRAG_OVER;
    public static final EventType<DragEvent> DRAG_DROPPED;
    public static final EventType<DragEvent> DRAG_DONE;
    private transient double x;
    private transient double y;
    private transient double z;
    private final double screenX;
    private final double screenY;
    private final double sceneX;
    private final double sceneY;
    private PickResult pickResult;
    private Object gestureSource;
    private Object gestureTarget;
    private TransferMode transferMode;
    private final State state;
    private transient Dragboard dragboard;
    
    public DragEvent copyFor(final Object o, final EventTarget eventTarget, final Object gestureSource, final Object gestureTarget, final EventType<DragEvent> eventType) {
        final DragEvent copy = this.copyFor(o, eventTarget, eventType);
        this.recomputeCoordinatesToSource(copy, o);
        copy.gestureSource = gestureSource;
        copy.gestureTarget = gestureTarget;
        return copy;
    }
    
    public DragEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<DragEvent> eventType, @NamedArg("dragboard") final Dragboard dragboard, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double screenX, @NamedArg("screenY") final double screenY, @NamedArg("transferMode") final TransferMode transferMode, @NamedArg("gestureSource") final Object gestureSource, @NamedArg("gestureTarget") final Object gestureTarget, @NamedArg("pickResult") final PickResult pickResult) {
        super(o, eventTarget, eventType);
        this.state = new State();
        this.gestureSource = gestureSource;
        this.gestureTarget = gestureTarget;
        this.x = n;
        this.y = n2;
        this.screenX = screenX;
        this.screenY = screenY;
        this.sceneX = n;
        this.sceneY = n2;
        this.transferMode = transferMode;
        this.dragboard = dragboard;
        if (eventType == DragEvent.DRAG_DROPPED || eventType == DragEvent.DRAG_DONE) {
            this.state.accepted = (transferMode != null);
            this.state.acceptedTransferMode = transferMode;
            this.state.acceptingObject = (this.state.accepted ? o : null);
        }
        this.pickResult = ((pickResult != null) ? pickResult : new PickResult((eventType == DragEvent.DRAG_DONE) ? null : eventTarget, n, n2));
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, null);
        this.x = recomputeCoordinates.getX();
        this.y = recomputeCoordinates.getY();
        this.z = recomputeCoordinates.getZ();
    }
    
    public DragEvent(@NamedArg("eventType") final EventType<DragEvent> eventType, @NamedArg("dragboard") final Dragboard dragboard, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("transferMode") final TransferMode transferMode, @NamedArg("gestureSource") final Object o, @NamedArg("gestureTarget") final Object o2, @NamedArg("pickResult") final PickResult pickResult) {
        this(null, null, eventType, dragboard, n, n2, n3, n4, transferMode, o, o2, pickResult);
    }
    
    private void recomputeCoordinatesToSource(final DragEvent dragEvent, final Object o) {
        if (dragEvent.getEventType() == DragEvent.DRAG_DONE) {
            return;
        }
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, o);
        dragEvent.x = recomputeCoordinates.getX();
        dragEvent.y = recomputeCoordinates.getY();
        dragEvent.z = recomputeCoordinates.getZ();
    }
    
    @Override
    public DragEvent copyFor(final Object o, final EventTarget eventTarget) {
        final DragEvent dragEvent = (DragEvent)super.copyFor(o, eventTarget);
        this.recomputeCoordinatesToSource(dragEvent, o);
        return dragEvent;
    }
    
    public DragEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<DragEvent> eventType) {
        final DragEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    @Override
    public EventType<DragEvent> getEventType() {
        return (EventType<DragEvent>)super.getEventType();
    }
    
    public final double getX() {
        return this.x;
    }
    
    public final double getY() {
        return this.y;
    }
    
    public final double getZ() {
        return this.z;
    }
    
    public final double getScreenX() {
        return this.screenX;
    }
    
    public final double getScreenY() {
        return this.screenY;
    }
    
    public final double getSceneX() {
        return this.sceneX;
    }
    
    public final double getSceneY() {
        return this.sceneY;
    }
    
    public final PickResult getPickResult() {
        return this.pickResult;
    }
    
    public final Object getGestureSource() {
        return this.gestureSource;
    }
    
    public final Object getGestureTarget() {
        return this.gestureTarget;
    }
    
    public final TransferMode getTransferMode() {
        return this.transferMode;
    }
    
    public final boolean isAccepted() {
        return this.state.accepted;
    }
    
    public final TransferMode getAcceptedTransferMode() {
        return this.state.acceptedTransferMode;
    }
    
    public final Object getAcceptingObject() {
        return this.state.acceptingObject;
    }
    
    public final Dragboard getDragboard() {
        return this.dragboard;
    }
    
    private static TransferMode chooseTransferMode(final Set<TransferMode> set, final TransferMode[] array, final TransferMode transferMode) {
        TransferMode transferMode2 = null;
        final EnumSet<TransferMode> none = EnumSet.noneOf(TransferMode.class);
        for (final TransferMode transferMode3 : InputEventUtils.safeTransferModes(array)) {
            if (set.contains(transferMode3)) {
                none.add(transferMode3);
            }
        }
        if (none.contains(transferMode)) {
            transferMode2 = transferMode;
        }
        else if (none.contains(TransferMode.MOVE)) {
            transferMode2 = TransferMode.MOVE;
        }
        else if (none.contains(TransferMode.COPY)) {
            transferMode2 = TransferMode.COPY;
        }
        else if (none.contains(TransferMode.LINK)) {
            transferMode2 = TransferMode.LINK;
        }
        return transferMode2;
    }
    
    public void acceptTransferModes(final TransferMode... array) {
        if (this.dragboard == null || this.dragboard.getTransferModes() == null || this.transferMode == null) {
            this.state.accepted = false;
            return;
        }
        final TransferMode chooseTransferMode = chooseTransferMode(this.dragboard.getTransferModes(), array, this.transferMode);
        if (chooseTransferMode == null && this.getEventType() == DragEvent.DRAG_DROPPED) {
            throw new IllegalStateException("Accepting unsupported transfer modes inside DRAG_DROPPED handler");
        }
        this.state.accepted = (chooseTransferMode != null);
        this.state.acceptedTransferMode = chooseTransferMode;
        this.state.acceptingObject = (this.state.accepted ? this.source : null);
    }
    
    public void setDropCompleted(final boolean dropCompleted) {
        if (this.getEventType() != DragEvent.DRAG_DROPPED) {
            throw new IllegalStateException("setDropCompleted can be called only from DRAG_DROPPED handler");
        }
        this.state.dropCompleted = dropCompleted;
    }
    
    public boolean isDropCompleted() {
        return this.state.dropCompleted;
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.x = this.sceneX;
        this.y = this.sceneY;
    }
    
    static {
        ANY = new EventType<DragEvent>(InputEvent.ANY, "DRAG");
        DRAG_ENTERED_TARGET = new EventType<DragEvent>(DragEvent.ANY, "DRAG_ENTERED_TARGET");
        DRAG_ENTERED = new EventType<DragEvent>(DragEvent.DRAG_ENTERED_TARGET, "DRAG_ENTERED");
        DRAG_EXITED_TARGET = new EventType<DragEvent>(DragEvent.ANY, "DRAG_EXITED_TARGET");
        DRAG_EXITED = new EventType<DragEvent>(DragEvent.DRAG_EXITED_TARGET, "DRAG_EXITED");
        DRAG_OVER = new EventType<DragEvent>(DragEvent.ANY, "DRAG_OVER");
        DRAG_DROPPED = new EventType<DragEvent>(DragEvent.ANY, "DRAG_DROPPED");
        DRAG_DONE = new EventType<DragEvent>(DragEvent.ANY, "DRAG_DONE");
    }
    
    private static class State
    {
        boolean accepted;
        boolean dropCompleted;
        TransferMode acceptedTransferMode;
        Object acceptingObject;
        
        private State() {
            this.accepted = false;
            this.dropCompleted = false;
            this.acceptedTransferMode = null;
            this.acceptingObject = null;
        }
    }
}
