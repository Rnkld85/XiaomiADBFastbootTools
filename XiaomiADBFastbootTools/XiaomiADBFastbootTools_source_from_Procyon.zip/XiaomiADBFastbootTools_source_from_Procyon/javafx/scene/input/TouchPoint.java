// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import com.sun.javafx.scene.input.TouchPointHelper;
import java.io.IOException;
import java.io.ObjectInputStream;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.geometry.Point3D;
import com.sun.javafx.scene.input.InputEventUtils;
import javafx.beans.NamedArg;
import javafx.event.EventTarget;
import java.io.Serializable;

public final class TouchPoint implements Serializable
{
    private transient EventTarget target;
    private transient Object source;
    private EventTarget grabbed;
    private int id;
    private State state;
    private transient double x;
    private transient double y;
    private transient double z;
    private double screenX;
    private double screenY;
    private double sceneX;
    private double sceneY;
    private PickResult pickResult;
    
    public TouchPoint(@NamedArg("id") final int id, @NamedArg("state") final State state, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double screenX, @NamedArg("screenY") final double screenY, @NamedArg("target") final EventTarget target, @NamedArg("pickResult") final PickResult pickResult) {
        this.grabbed = null;
        this.target = target;
        this.id = id;
        this.state = state;
        this.x = n;
        this.y = n2;
        this.sceneX = n;
        this.sceneY = n2;
        this.screenX = screenX;
        this.screenY = screenY;
        this.pickResult = ((pickResult != null) ? pickResult : new PickResult(target, n, n2));
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, null);
        this.x = recomputeCoordinates.getX();
        this.y = recomputeCoordinates.getY();
        this.z = recomputeCoordinates.getZ();
    }
    
    void recomputeToSource(final Object o, final Object source) {
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, source);
        this.x = recomputeCoordinates.getX();
        this.y = recomputeCoordinates.getY();
        this.z = recomputeCoordinates.getZ();
        this.source = source;
    }
    
    public boolean belongsTo(final EventTarget eventTarget) {
        if (this.target instanceof Node) {
            Node parent = (Node)this.target;
            if (eventTarget instanceof Scene) {
                return parent.getScene() == eventTarget;
            }
            while (parent != null) {
                if (parent == eventTarget) {
                    return true;
                }
                parent = parent.getParent();
            }
        }
        return eventTarget == this.target;
    }
    
    void reset() {
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, null);
        this.x = recomputeCoordinates.getX();
        this.y = recomputeCoordinates.getY();
        this.z = recomputeCoordinates.getZ();
    }
    
    public EventTarget getGrabbed() {
        return this.grabbed;
    }
    
    public void grab() {
        if (this.source instanceof EventTarget) {
            this.grabbed = (EventTarget)this.source;
            return;
        }
        throw new IllegalStateException(invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;)Ljava/lang/String;, this.source));
    }
    
    public void grab(final EventTarget grabbed) {
        this.grabbed = grabbed;
    }
    
    public void ungrab() {
        this.grabbed = null;
    }
    
    public final int getId() {
        return this.id;
    }
    
    public final State getState() {
        return this.state;
    }
    
    public final double getX() {
        return this.x;
    }
    
    public final double getY() {
        return this.y;
    }
    
    public final double getZ() {
        return this.z;
    }
    
    public final double getScreenX() {
        return this.screenX;
    }
    
    public final double getScreenY() {
        return this.screenY;
    }
    
    public final double getSceneX() {
        return this.sceneX;
    }
    
    public final double getSceneY() {
        return this.sceneY;
    }
    
    public final PickResult getPickResult() {
        return this.pickResult;
    }
    
    public EventTarget getTarget() {
        return this.target;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TouchPoint [");
        sb.append("state = ").append(this.getState());
        sb.append(", id = ").append(this.getId());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", x = ").append(this.getX()).append(", y = ").append(this.getY()).append(", z = ").append(this.getZ());
        sb.append(", pickResult = ").append(this.getPickResult());
        return sb.append("]").toString();
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.x = this.sceneX;
        this.y = this.sceneY;
    }
    
    static {
        TouchPointHelper.setTouchPointAccessor(new TouchPointHelper.TouchPointAccessor() {
            @Override
            public void reset(final TouchPoint touchPoint) {
                touchPoint.reset();
            }
        });
    }
    
    public enum State
    {
        PRESSED, 
        MOVED, 
        STATIONARY, 
        RELEASED;
    }
}
