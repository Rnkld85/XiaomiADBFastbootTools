// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import java.io.IOException;
import java.io.ObjectInputStream;
import com.sun.javafx.tk.Toolkit;
import javafx.geometry.Point3D;
import com.sun.javafx.scene.input.InputEventUtils;
import javafx.event.EventTarget;
import javafx.event.EventType;

public class GestureEvent extends InputEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<GestureEvent> ANY;
    private transient double x;
    private transient double y;
    private transient double z;
    private final double screenX;
    private final double screenY;
    private final double sceneX;
    private final double sceneY;
    private final boolean shiftDown;
    private final boolean controlDown;
    private final boolean altDown;
    private final boolean metaDown;
    private final boolean direct;
    private final boolean inertia;
    private PickResult pickResult;
    
    @Deprecated(since = "8")
    protected GestureEvent(final EventType<? extends GestureEvent> eventType) {
        this(eventType, 0.0, 0.0, 0.0, 0.0, false, false, false, false, false, false, null);
    }
    
    @Deprecated(since = "8")
    protected GestureEvent(final Object o, final EventTarget eventTarget, final EventType<? extends GestureEvent> eventType) {
        super(o, eventTarget, eventType);
        final double n = 0.0;
        this.sceneY = n;
        this.sceneX = n;
        this.screenY = n;
        this.screenX = n;
        this.y = n;
        this.x = n;
        final boolean b = false;
        this.inertia = b;
        this.direct = b;
        this.metaDown = b;
        this.altDown = b;
        this.controlDown = b;
        this.shiftDown = b;
    }
    
    protected GestureEvent(final Object o, final EventTarget eventTarget, final EventType<? extends GestureEvent> eventType, final double n, final double n2, final double screenX, final double screenY, final boolean shiftDown, final boolean controlDown, final boolean altDown, final boolean metaDown, final boolean direct, final boolean inertia, final PickResult pickResult) {
        super(o, eventTarget, eventType);
        this.x = n;
        this.y = n2;
        this.screenX = screenX;
        this.screenY = screenY;
        this.sceneX = n;
        this.sceneY = n2;
        this.shiftDown = shiftDown;
        this.controlDown = controlDown;
        this.altDown = altDown;
        this.metaDown = metaDown;
        this.direct = direct;
        this.inertia = inertia;
        this.pickResult = ((pickResult != null) ? pickResult : new PickResult(eventTarget, n, n2));
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, null);
        this.x = recomputeCoordinates.getX();
        this.y = recomputeCoordinates.getY();
        this.z = recomputeCoordinates.getZ();
    }
    
    protected GestureEvent(final EventType<? extends GestureEvent> eventType, final double n, final double n2, final double n3, final double n4, final boolean b, final boolean b2, final boolean b3, final boolean b4, final boolean b5, final boolean b6, final PickResult pickResult) {
        this(null, null, eventType, n, n2, n3, n4, b, b2, b3, b4, b5, b6, pickResult);
    }
    
    private void recomputeCoordinatesToSource(final GestureEvent gestureEvent, final Object o) {
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, o);
        gestureEvent.x = recomputeCoordinates.getX();
        gestureEvent.y = recomputeCoordinates.getY();
        gestureEvent.z = recomputeCoordinates.getZ();
    }
    
    @Override
    public GestureEvent copyFor(final Object o, final EventTarget eventTarget) {
        final GestureEvent gestureEvent = (GestureEvent)super.copyFor(o, eventTarget);
        this.recomputeCoordinatesToSource(gestureEvent, o);
        return gestureEvent;
    }
    
    public final double getX() {
        return this.x;
    }
    
    public final double getY() {
        return this.y;
    }
    
    public final double getZ() {
        return this.z;
    }
    
    public final double getScreenX() {
        return this.screenX;
    }
    
    public final double getScreenY() {
        return this.screenY;
    }
    
    public final double getSceneX() {
        return this.sceneX;
    }
    
    public final double getSceneY() {
        return this.sceneY;
    }
    
    public final boolean isShiftDown() {
        return this.shiftDown;
    }
    
    public final boolean isControlDown() {
        return this.controlDown;
    }
    
    public final boolean isAltDown() {
        return this.altDown;
    }
    
    public final boolean isMetaDown() {
        return this.metaDown;
    }
    
    public final boolean isDirect() {
        return this.direct;
    }
    
    public boolean isInertia() {
        return this.inertia;
    }
    
    public final PickResult getPickResult() {
        return this.pickResult;
    }
    
    public final boolean isShortcutDown() {
        switch (Toolkit.getToolkit().getPlatformShortcutKey()) {
            case SHIFT: {
                return this.shiftDown;
            }
            case CONTROL: {
                return this.controlDown;
            }
            case ALT: {
                return this.altDown;
            }
            case META: {
                return this.metaDown;
            }
            default: {
                return false;
            }
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("GestureEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", x = ").append(this.getX()).append(", y = ").append(this.getY()).append(", z = ").append(this.getZ());
        sb.append(this.isDirect() ? ", direct" : ", indirect");
        if (this.isInertia()) {
            sb.append(", inertia");
        }
        if (this.isShiftDown()) {
            sb.append(", shiftDown");
        }
        if (this.isControlDown()) {
            sb.append(", controlDown");
        }
        if (this.isAltDown()) {
            sb.append(", altDown");
        }
        if (this.isMetaDown()) {
            sb.append(", metaDown");
        }
        if (this.isShortcutDown()) {
            sb.append(", shortcutDown");
        }
        sb.append(", pickResult = ").append(this.getPickResult());
        return sb.append("]").toString();
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.x = this.sceneX;
        this.y = this.sceneY;
    }
    
    @Override
    public EventType<? extends GestureEvent> getEventType() {
        return (EventType<? extends GestureEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<GestureEvent>(InputEvent.ANY, "GESTURE");
    }
}
