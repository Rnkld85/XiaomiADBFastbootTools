// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.geometry.Point2D;

public interface InputMethodRequests
{
    Point2D getTextLocation(final int p0);
    
    int getLocationOffset(final int p0, final int p1);
    
    void cancelLatestCommittedText();
    
    String getSelectedText();
}
