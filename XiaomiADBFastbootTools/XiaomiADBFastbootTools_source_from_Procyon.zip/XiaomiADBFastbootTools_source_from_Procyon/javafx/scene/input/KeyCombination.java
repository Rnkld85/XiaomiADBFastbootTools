// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import java.util.Locale;
import java.util.ArrayList;
import com.sun.javafx.PlatformUtil;
import com.sun.javafx.tk.Toolkit;

public abstract class KeyCombination
{
    public static final Modifier SHIFT_DOWN;
    public static final Modifier SHIFT_ANY;
    public static final Modifier CONTROL_DOWN;
    public static final Modifier CONTROL_ANY;
    public static final Modifier ALT_DOWN;
    public static final Modifier ALT_ANY;
    public static final Modifier META_DOWN;
    public static final Modifier META_ANY;
    public static final Modifier SHORTCUT_DOWN;
    public static final Modifier SHORTCUT_ANY;
    private static final Modifier[] POSSIBLE_MODIFIERS;
    public static final KeyCombination NO_MATCH;
    private final ModifierValue shift;
    private final ModifierValue control;
    private final ModifierValue alt;
    private final ModifierValue meta;
    private final ModifierValue shortcut;
    
    public final ModifierValue getShift() {
        return this.shift;
    }
    
    public final ModifierValue getControl() {
        return this.control;
    }
    
    public final ModifierValue getAlt() {
        return this.alt;
    }
    
    public final ModifierValue getMeta() {
        return this.meta;
    }
    
    public final ModifierValue getShortcut() {
        return this.shortcut;
    }
    
    protected KeyCombination(final ModifierValue shift, final ModifierValue control, final ModifierValue alt, final ModifierValue meta, final ModifierValue shortcut) {
        if (shift == null || control == null || alt == null || meta == null || shortcut == null) {
            throw new NullPointerException("Modifier value must not be null!");
        }
        this.shift = shift;
        this.control = control;
        this.alt = alt;
        this.meta = meta;
        this.shortcut = shortcut;
    }
    
    protected KeyCombination(final Modifier... array) {
        this(getModifierValue(array, KeyCode.SHIFT), getModifierValue(array, KeyCode.CONTROL), getModifierValue(array, KeyCode.ALT), getModifierValue(array, KeyCode.META), getModifierValue(array, KeyCode.SHORTCUT));
    }
    
    public boolean match(final KeyEvent keyEvent) {
        final KeyCode platformShortcutKey = Toolkit.getToolkit().getPlatformShortcutKey();
        return test(KeyCode.SHIFT, this.shift, platformShortcutKey, this.shortcut, keyEvent.isShiftDown()) && test(KeyCode.CONTROL, this.control, platformShortcutKey, this.shortcut, keyEvent.isControlDown()) && test(KeyCode.ALT, this.alt, platformShortcutKey, this.shortcut, keyEvent.isAltDown()) && test(KeyCode.META, this.meta, platformShortcutKey, this.shortcut, keyEvent.isMetaDown());
    }
    
    public String getName() {
        final StringBuilder sb = new StringBuilder();
        this.addModifiersIntoString(sb);
        return sb.toString();
    }
    
    public String getDisplayText() {
        final StringBuilder sb = new StringBuilder();
        if (PlatformUtil.isMac()) {
            if (this.getControl() == ModifierValue.DOWN) {
                sb.append("\u2303");
            }
            if (this.getAlt() == ModifierValue.DOWN) {
                sb.append("\u2325");
            }
            if (this.getShift() == ModifierValue.DOWN) {
                sb.append("\u21e7");
            }
            if (this.getMeta() == ModifierValue.DOWN || this.getShortcut() == ModifierValue.DOWN) {
                sb.append("\u2318");
            }
        }
        else {
            if (this.getControl() == ModifierValue.DOWN || this.getShortcut() == ModifierValue.DOWN) {
                sb.append("Ctrl+");
            }
            if (this.getAlt() == ModifierValue.DOWN) {
                sb.append("Alt+");
            }
            if (this.getShift() == ModifierValue.DOWN) {
                sb.append("Shift+");
            }
            if (this.getMeta() == ModifierValue.DOWN) {
                sb.append("Meta+");
            }
        }
        return sb.toString();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof KeyCombination)) {
            return false;
        }
        final KeyCombination keyCombination = (KeyCombination)o;
        return this.shift == keyCombination.shift && this.control == keyCombination.control && this.alt == keyCombination.alt && this.meta == keyCombination.meta && this.shortcut == keyCombination.shortcut;
    }
    
    @Override
    public int hashCode() {
        return 23 * (23 * (23 * (23 * (23 * 7 + this.shift.hashCode()) + this.control.hashCode()) + this.alt.hashCode()) + this.meta.hashCode()) + this.shortcut.hashCode();
    }
    
    @Override
    public String toString() {
        return this.getName();
    }
    
    public static KeyCombination valueOf(final String s) {
        final ArrayList<Modifier> list = new ArrayList<Modifier>(4);
        final String[] splitName = splitName(s);
        KeyCode keyCode = null;
        String replace = null;
        for (final String s2 : splitName) {
            if (s2.length() > 2 && s2.charAt(0) == '\'' && s2.charAt(s2.length() - 1) == '\'') {
                if (keyCode != null || replace != null) {
                    throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                }
                replace = s2.substring(1, s2.length() - 1).replace("\\'", "'");
            }
            else {
                final String normalizeToken = normalizeToken(s2);
                final Modifier modifier = getModifier(normalizeToken);
                if (modifier != null) {
                    list.add(modifier);
                }
                else {
                    if (keyCode != null || replace != null) {
                        throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                    }
                    keyCode = KeyCode.getKeyCode(normalizeToken);
                    if (keyCode == null) {
                        replace = s2;
                    }
                }
            }
        }
        if (keyCode == null && replace == null) {
            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
        }
        final Modifier[] array2 = list.toArray(new Modifier[list.size()]);
        return (keyCode != null) ? new KeyCodeCombination(keyCode, array2) : new KeyCharacterCombination(replace, array2);
    }
    
    public static KeyCombination keyCombination(final String s) {
        return valueOf(s);
    }
    
    private void addModifiersIntoString(final StringBuilder sb) {
        addModifierIntoString(sb, KeyCode.SHIFT, this.shift);
        addModifierIntoString(sb, KeyCode.CONTROL, this.control);
        addModifierIntoString(sb, KeyCode.ALT, this.alt);
        addModifierIntoString(sb, KeyCode.META, this.meta);
        addModifierIntoString(sb, KeyCode.SHORTCUT, this.shortcut);
    }
    
    private static void addModifierIntoString(final StringBuilder sb, final KeyCode keyCode, final ModifierValue modifierValue) {
        if (modifierValue == ModifierValue.UP) {
            return;
        }
        if (sb.length() > 0) {
            sb.append("+");
        }
        if (modifierValue == ModifierValue.ANY) {
            sb.append("Ignore ");
        }
        sb.append(keyCode.getName());
    }
    
    private static boolean test(final KeyCode keyCode, final ModifierValue modifierValue, final KeyCode keyCode2, final ModifierValue modifierValue2, final boolean b) {
        return test((keyCode == keyCode2) ? resolveModifierValue(modifierValue, modifierValue2) : modifierValue, b);
    }
    
    private static boolean test(final ModifierValue modifierValue, final boolean b) {
        switch (modifierValue) {
            case DOWN: {
                return b;
            }
            case UP: {
                return !b;
            }
            default: {
                return true;
            }
        }
    }
    
    private static ModifierValue resolveModifierValue(final ModifierValue modifierValue, final ModifierValue modifierValue2) {
        if (modifierValue == ModifierValue.DOWN || modifierValue2 == ModifierValue.DOWN) {
            return ModifierValue.DOWN;
        }
        if (modifierValue == ModifierValue.ANY || modifierValue2 == ModifierValue.ANY) {
            return ModifierValue.ANY;
        }
        return ModifierValue.UP;
    }
    
    static Modifier getModifier(final String anObject) {
        for (final Modifier modifier : KeyCombination.POSSIBLE_MODIFIERS) {
            if (modifier.toString().equals(anObject)) {
                return modifier;
            }
        }
        return null;
    }
    
    private static ModifierValue getModifierValue(final Modifier[] array, final KeyCode keyCode) {
        ModifierValue modifierValue = ModifierValue.UP;
        for (final Modifier modifier : array) {
            if (modifier == null) {
                throw new NullPointerException("Modifier must not be null!");
            }
            if (modifier.getKey() == keyCode) {
                if (modifierValue != ModifierValue.UP) {
                    throw new IllegalArgumentException((modifier.getValue() != modifierValue) ? "Conflicting modifiers specified!" : "Duplicate modifiers specified!");
                }
                modifierValue = modifier.getValue();
            }
        }
        return modifierValue;
    }
    
    private static String normalizeToken(final String s) {
        final String[] split = s.split("\\s+");
        final StringBuilder sb = new StringBuilder();
        for (final String s2 : split) {
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(s2.substring(0, 1).toUpperCase(Locale.ROOT));
            sb.append(s2.substring(1).toLowerCase(Locale.ROOT));
        }
        return sb.toString();
    }
    
    private static String[] splitName(final String s) {
        final ArrayList<String> list = new ArrayList<String>();
        final char[] charArray = s.trim().toCharArray();
        int n = 0;
        int n2 = 0;
        int n3 = -1;
        for (int i = 0; i < charArray.length; ++i) {
            final char c = charArray[i];
            switch (n) {
                case 0: {
                    switch (c) {
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                        case 13:
                        case 32: {
                            n3 = i;
                            n = 1;
                            continue;
                        }
                        case 43: {
                            n3 = i;
                            n = 2;
                            continue;
                        }
                        case 39: {
                            if (i == 0 || charArray[i - 1] != '\\') {
                                n = 3;
                                continue;
                            }
                            continue;
                        }
                        default: {
                            continue;
                        }
                    }
                    break;
                }
                case 1: {
                    switch (c) {
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                        case 13:
                        case 32: {
                            continue;
                        }
                        case 43: {
                            n = 2;
                            continue;
                        }
                        case 39: {
                            n = 3;
                            n3 = -1;
                            continue;
                        }
                        default: {
                            n = 0;
                            n3 = -1;
                            continue;
                        }
                    }
                    break;
                }
                case 2: {
                    switch (c) {
                        case 9:
                        case 10:
                        case 11:
                        case 12:
                        case 13:
                        case 32: {
                            continue;
                        }
                        case 43: {
                            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                        }
                        default: {
                            if (n3 <= n2) {
                                throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                            }
                            list.add(new String(charArray, n2, n3 - n2));
                            n2 = i;
                            n3 = -1;
                            n = ((c == '\'') ? 3 : 0);
                            continue;
                        }
                    }
                    break;
                }
                case 3: {
                    if (c == '\'' && charArray[i - 1] != '\\') {
                        n = 0;
                        break;
                    }
                    break;
                }
            }
        }
        switch (n) {
            case 0:
            case 1: {
                list.add(new String(charArray, n2, charArray.length - n2));
                break;
            }
            case 2:
            case 3: {
                throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
            }
        }
        return list.toArray(new String[list.size()]);
    }
    
    static {
        SHIFT_DOWN = new Modifier(KeyCode.SHIFT, ModifierValue.DOWN);
        SHIFT_ANY = new Modifier(KeyCode.SHIFT, ModifierValue.ANY);
        CONTROL_DOWN = new Modifier(KeyCode.CONTROL, ModifierValue.DOWN);
        CONTROL_ANY = new Modifier(KeyCode.CONTROL, ModifierValue.ANY);
        ALT_DOWN = new Modifier(KeyCode.ALT, ModifierValue.DOWN);
        ALT_ANY = new Modifier(KeyCode.ALT, ModifierValue.ANY);
        META_DOWN = new Modifier(KeyCode.META, ModifierValue.DOWN);
        META_ANY = new Modifier(KeyCode.META, ModifierValue.ANY);
        SHORTCUT_DOWN = new Modifier(KeyCode.SHORTCUT, ModifierValue.DOWN);
        SHORTCUT_ANY = new Modifier(KeyCode.SHORTCUT, ModifierValue.ANY);
        POSSIBLE_MODIFIERS = new Modifier[] { KeyCombination.SHIFT_DOWN, KeyCombination.SHIFT_ANY, KeyCombination.CONTROL_DOWN, KeyCombination.CONTROL_ANY, KeyCombination.ALT_DOWN, KeyCombination.ALT_ANY, KeyCombination.META_DOWN, KeyCombination.META_ANY, KeyCombination.SHORTCUT_DOWN, KeyCombination.SHORTCUT_ANY };
        NO_MATCH = new KeyCombination() {
            @Override
            public boolean match(final KeyEvent keyEvent) {
                return false;
            }
        };
    }
    
    public static final class Modifier
    {
        private final KeyCode key;
        private final ModifierValue value;
        
        private Modifier(final KeyCode key, final ModifierValue value) {
            this.key = key;
            this.value = value;
        }
        
        public KeyCode getKey() {
            return this.key;
        }
        
        public ModifierValue getValue() {
            return this.value;
        }
        
        @Override
        public String toString() {
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, (this.value == ModifierValue.ANY) ? "Ignore " : "", this.key.getName());
        }
    }
    
    public enum ModifierValue
    {
        DOWN, 
        UP, 
        ANY;
    }
}
