// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import javafx.event.Event;
import java.io.IOException;
import java.io.ObjectInputStream;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.NamedArg;
import javafx.event.EventTarget;
import javafx.geometry.Point3D;
import com.sun.javafx.scene.input.InputEventUtils;
import javafx.event.EventType;

public class MouseEvent extends InputEvent
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<MouseEvent> ANY;
    public static final EventType<MouseEvent> MOUSE_PRESSED;
    public static final EventType<MouseEvent> MOUSE_RELEASED;
    public static final EventType<MouseEvent> MOUSE_CLICKED;
    public static final EventType<MouseEvent> MOUSE_ENTERED_TARGET;
    public static final EventType<MouseEvent> MOUSE_ENTERED;
    public static final EventType<MouseEvent> MOUSE_EXITED_TARGET;
    public static final EventType<MouseEvent> MOUSE_EXITED;
    public static final EventType<MouseEvent> MOUSE_MOVED;
    public static final EventType<MouseEvent> MOUSE_DRAGGED;
    public static final EventType<MouseEvent> DRAG_DETECTED;
    private final Flags flags;
    private transient double x;
    private transient double y;
    private transient double z;
    private final double screenX;
    private final double screenY;
    private final double sceneX;
    private final double sceneY;
    private final MouseButton button;
    private final int clickCount;
    private final boolean stillSincePress;
    private final boolean shiftDown;
    private final boolean controlDown;
    private final boolean altDown;
    private final boolean metaDown;
    private final boolean synthesized;
    private final boolean popupTrigger;
    private final boolean primaryButtonDown;
    private final boolean secondaryButtonDown;
    private final boolean middleButtonDown;
    private PickResult pickResult;
    
    void recomputeCoordinatesToSource(final MouseEvent mouseEvent, final Object o) {
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, o);
        this.x = recomputeCoordinates.getX();
        this.y = recomputeCoordinates.getY();
        this.z = recomputeCoordinates.getZ();
    }
    
    @Override
    public EventType<? extends MouseEvent> getEventType() {
        return (EventType<? extends MouseEvent>)super.getEventType();
    }
    
    @Override
    public MouseEvent copyFor(final Object o, final EventTarget eventTarget) {
        final MouseEvent mouseEvent = (MouseEvent)super.copyFor(o, eventTarget);
        mouseEvent.recomputeCoordinatesToSource(this, o);
        return mouseEvent;
    }
    
    public MouseEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<? extends MouseEvent> eventType) {
        final MouseEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    public MouseEvent(@NamedArg("eventType") final EventType<? extends MouseEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double n3, @NamedArg("screenY") final double n4, @NamedArg("button") final MouseButton mouseButton, @NamedArg("clickCount") final int n5, @NamedArg("shiftDown") final boolean b, @NamedArg("controlDown") final boolean b2, @NamedArg("altDown") final boolean b3, @NamedArg("metaDown") final boolean b4, @NamedArg("primaryButtonDown") final boolean b5, @NamedArg("middleButtonDown") final boolean b6, @NamedArg("secondaryButtonDown") final boolean b7, @NamedArg("synthesized") final boolean b8, @NamedArg("popupTrigger") final boolean b9, @NamedArg("stillSincePress") final boolean b10, @NamedArg("pickResult") final PickResult pickResult) {
        this(null, null, eventType, n, n2, n3, n4, mouseButton, n5, b, b2, b3, b4, b5, b6, b7, b8, b9, b10, pickResult);
    }
    
    public MouseEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("eventType") final EventType<? extends MouseEvent> eventType, @NamedArg("x") final double n, @NamedArg("y") final double n2, @NamedArg("screenX") final double screenX, @NamedArg("screenY") final double screenY, @NamedArg("button") final MouseButton button, @NamedArg("clickCount") final int clickCount, @NamedArg("shiftDown") final boolean shiftDown, @NamedArg("controlDown") final boolean controlDown, @NamedArg("altDown") final boolean altDown, @NamedArg("metaDown") final boolean metaDown, @NamedArg("primaryButtonDown") final boolean primaryButtonDown, @NamedArg("middleButtonDown") final boolean middleButtonDown, @NamedArg("secondaryButtonDown") final boolean secondaryButtonDown, @NamedArg("synthesized") final boolean synthesized, @NamedArg("popupTrigger") final boolean popupTrigger, @NamedArg("stillSincePress") final boolean stillSincePress, @NamedArg("pickResult") final PickResult pickResult) {
        super(o, eventTarget, eventType);
        this.flags = new Flags();
        this.x = n;
        this.y = n2;
        this.screenX = screenX;
        this.screenY = screenY;
        this.sceneX = n;
        this.sceneY = n2;
        this.button = button;
        this.clickCount = clickCount;
        this.shiftDown = shiftDown;
        this.controlDown = controlDown;
        this.altDown = altDown;
        this.metaDown = metaDown;
        this.primaryButtonDown = primaryButtonDown;
        this.middleButtonDown = middleButtonDown;
        this.secondaryButtonDown = secondaryButtonDown;
        this.synthesized = synthesized;
        this.stillSincePress = stillSincePress;
        this.popupTrigger = popupTrigger;
        this.pickResult = pickResult;
        this.pickResult = ((pickResult != null) ? pickResult : new PickResult(eventTarget, n, n2));
        final Point3D recomputeCoordinates = InputEventUtils.recomputeCoordinates(this.pickResult, null);
        this.x = recomputeCoordinates.getX();
        this.y = recomputeCoordinates.getY();
        this.z = recomputeCoordinates.getZ();
    }
    
    public static MouseDragEvent copyForMouseDragEvent(final MouseEvent mouseEvent, final Object o, final EventTarget eventTarget, final EventType<MouseDragEvent> eventType, final Object o2, final PickResult pickResult) {
        final MouseDragEvent mouseDragEvent = new MouseDragEvent(o, eventTarget, eventType, mouseEvent.sceneX, mouseEvent.sceneY, mouseEvent.screenX, mouseEvent.screenY, mouseEvent.button, mouseEvent.clickCount, mouseEvent.shiftDown, mouseEvent.controlDown, mouseEvent.altDown, mouseEvent.metaDown, mouseEvent.primaryButtonDown, mouseEvent.middleButtonDown, mouseEvent.secondaryButtonDown, mouseEvent.synthesized, mouseEvent.popupTrigger, pickResult, o2);
        mouseDragEvent.recomputeCoordinatesToSource(mouseEvent, o);
        return mouseDragEvent;
    }
    
    public boolean isDragDetect() {
        return this.flags.dragDetect;
    }
    
    public void setDragDetect(final boolean dragDetect) {
        this.flags.dragDetect = dragDetect;
    }
    
    public final double getX() {
        return this.x;
    }
    
    public final double getY() {
        return this.y;
    }
    
    public final double getZ() {
        return this.z;
    }
    
    public final double getScreenX() {
        return this.screenX;
    }
    
    public final double getScreenY() {
        return this.screenY;
    }
    
    public final double getSceneX() {
        return this.sceneX;
    }
    
    public final double getSceneY() {
        return this.sceneY;
    }
    
    public final MouseButton getButton() {
        return this.button;
    }
    
    public final int getClickCount() {
        return this.clickCount;
    }
    
    public final boolean isStillSincePress() {
        return this.stillSincePress;
    }
    
    public final boolean isShiftDown() {
        return this.shiftDown;
    }
    
    public final boolean isControlDown() {
        return this.controlDown;
    }
    
    public final boolean isAltDown() {
        return this.altDown;
    }
    
    public final boolean isMetaDown() {
        return this.metaDown;
    }
    
    public boolean isSynthesized() {
        return this.synthesized;
    }
    
    public final boolean isShortcutDown() {
        switch (Toolkit.getToolkit().getPlatformShortcutKey()) {
            case SHIFT: {
                return this.shiftDown;
            }
            case CONTROL: {
                return this.controlDown;
            }
            case ALT: {
                return this.altDown;
            }
            case META: {
                return this.metaDown;
            }
            default: {
                return false;
            }
        }
    }
    
    public final boolean isPopupTrigger() {
        return this.popupTrigger;
    }
    
    public final boolean isPrimaryButtonDown() {
        return this.primaryButtonDown;
    }
    
    public final boolean isSecondaryButtonDown() {
        return this.secondaryButtonDown;
    }
    
    public final boolean isMiddleButtonDown() {
        return this.middleButtonDown;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("MouseEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        sb.append(", x = ").append(this.getX()).append(", y = ").append(this.getY()).append(", z = ").append(this.getZ());
        if (this.getButton() != null) {
            sb.append(", button = ").append(this.getButton());
        }
        if (this.getClickCount() > 1) {
            sb.append(", clickCount = ").append(this.getClickCount());
        }
        if (this.isPrimaryButtonDown()) {
            sb.append(", primaryButtonDown");
        }
        if (this.isMiddleButtonDown()) {
            sb.append(", middleButtonDown");
        }
        if (this.isSecondaryButtonDown()) {
            sb.append(", secondaryButtonDown");
        }
        if (this.isShiftDown()) {
            sb.append(", shiftDown");
        }
        if (this.isControlDown()) {
            sb.append(", controlDown");
        }
        if (this.isAltDown()) {
            sb.append(", altDown");
        }
        if (this.isMetaDown()) {
            sb.append(", metaDown");
        }
        if (this.isShortcutDown()) {
            sb.append(", shortcutDown");
        }
        if (this.isSynthesized()) {
            sb.append(", synthesized");
        }
        sb.append(", pickResult = ").append(this.getPickResult());
        return sb.append("]").toString();
    }
    
    public final PickResult getPickResult() {
        return this.pickResult;
    }
    
    private void readObject(final ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        objectInputStream.defaultReadObject();
        this.x = this.sceneX;
        this.y = this.sceneY;
    }
    
    static {
        ANY = new EventType<MouseEvent>(InputEvent.ANY, "MOUSE");
        MOUSE_PRESSED = new EventType<MouseEvent>(MouseEvent.ANY, "MOUSE_PRESSED");
        MOUSE_RELEASED = new EventType<MouseEvent>(MouseEvent.ANY, "MOUSE_RELEASED");
        MOUSE_CLICKED = new EventType<MouseEvent>(MouseEvent.ANY, "MOUSE_CLICKED");
        MOUSE_ENTERED_TARGET = new EventType<MouseEvent>(MouseEvent.ANY, "MOUSE_ENTERED_TARGET");
        MOUSE_ENTERED = new EventType<MouseEvent>(MouseEvent.MOUSE_ENTERED_TARGET, "MOUSE_ENTERED");
        MOUSE_EXITED_TARGET = new EventType<MouseEvent>(MouseEvent.ANY, "MOUSE_EXITED_TARGET");
        MOUSE_EXITED = new EventType<MouseEvent>(MouseEvent.MOUSE_EXITED_TARGET, "MOUSE_EXITED");
        MOUSE_MOVED = new EventType<MouseEvent>(MouseEvent.ANY, "MOUSE_MOVED");
        MOUSE_DRAGGED = new EventType<MouseEvent>(MouseEvent.ANY, "MOUSE_DRAGGED");
        DRAG_DETECTED = new EventType<MouseEvent>(MouseEvent.ANY, "DRAG_DETECTED");
    }
    
    private static class Flags implements Cloneable
    {
        boolean dragDetect;
        
        private Flags() {
            this.dragDetect = true;
        }
        
        public Flags clone() {
            try {
                return (Flags)super.clone();
            }
            catch (CloneNotSupportedException ex) {
                return null;
            }
        }
    }
}
