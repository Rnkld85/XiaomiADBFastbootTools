// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.input;

import java.util.Iterator;
import java.util.Collections;
import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import javafx.beans.NamedArg;
import java.util.Set;
import com.sun.javafx.util.WeakReferenceQueue;

public class DataFormat
{
    private static final WeakReferenceQueue<DataFormat> DATA_FORMAT_LIST;
    public static final DataFormat PLAIN_TEXT;
    public static final DataFormat HTML;
    public static final DataFormat RTF;
    public static final DataFormat URL;
    public static final DataFormat IMAGE;
    public static final DataFormat FILES;
    private static final DataFormat DRAG_IMAGE;
    private static final DataFormat DRAG_IMAGE_OFFSET;
    private final Set<String> identifier;
    
    public DataFormat(@NamedArg("ids") final String... a) {
        DataFormat.DATA_FORMAT_LIST.cleanup();
        if (a != null) {
            for (final String s : a) {
                if (lookupMimeType(s) != null) {
                    throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                }
            }
            this.identifier = Collections.unmodifiableSet((Set<? extends String>)new HashSet<String>(Arrays.asList(a)));
        }
        else {
            this.identifier = Collections.emptySet();
        }
        DataFormat.DATA_FORMAT_LIST.add(this);
    }
    
    public final Set<String> getIdentifiers() {
        return this.identifier;
    }
    
    @Override
    public String toString() {
        if (this.identifier.isEmpty()) {
            return "[]";
        }
        if (this.identifier.size() == 1) {
            final StringBuilder sb = new StringBuilder("[");
            sb.append(this.identifier.iterator().next());
            return sb.append("]").toString();
        }
        StringBuilder sb2 = new StringBuilder("[");
        final Iterator<String> iterator = this.identifier.iterator();
        while (iterator.hasNext()) {
            sb2 = sb2.append(iterator.next());
            if (iterator.hasNext()) {
                sb2 = sb2.append(", ");
            }
        }
        return sb2.append("]").toString();
    }
    
    @Override
    public int hashCode() {
        int n = 7;
        final Iterator<String> iterator = this.identifier.iterator();
        while (iterator.hasNext()) {
            n = 31 * n + iterator.next().hashCode();
        }
        return n;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o != null && o instanceof DataFormat && this.identifier.equals(((DataFormat)o).identifier);
    }
    
    public static DataFormat lookupMimeType(final String s) {
        if (s == null || s.length() == 0) {
            return null;
        }
        for (final DataFormat dataFormat : DataFormat.DATA_FORMAT_LIST) {
            if (dataFormat.getIdentifiers().contains(s)) {
                return dataFormat;
            }
        }
        return null;
    }
    
    static {
        DATA_FORMAT_LIST = new WeakReferenceQueue<DataFormat>();
        PLAIN_TEXT = new DataFormat(new String[] { "text/plain" });
        HTML = new DataFormat(new String[] { "text/html" });
        RTF = new DataFormat(new String[] { "text/rtf" });
        URL = new DataFormat(new String[] { "text/uri-list" });
        IMAGE = new DataFormat(new String[] { "application/x-java-rawimage" });
        FILES = new DataFormat(new String[] { "application/x-java-file-list", "java.file-list" });
        DRAG_IMAGE = new DataFormat(new String[] { "application/x-java-drag-image" });
        DRAG_IMAGE_OFFSET = new DataFormat(new String[] { "application/x-java-drag-image-offset" });
    }
}
