// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.css.PseudoClass;
import javafx.beans.property.ReadOnlyIntegerWrapper;

public class IndexedCell<T> extends Cell<T>
{
    private ReadOnlyIntegerWrapper index;
    private static final String DEFAULT_STYLE_CLASS = "indexed-cell";
    private static final PseudoClass PSEUDO_CLASS_ODD;
    private static final PseudoClass PSEUDO_CLASS_EVEN;
    
    public IndexedCell() {
        this.index = new ReadOnlyIntegerWrapper((Object)this, "index", -1) {
            @Override
            protected void invalidated() {
                final boolean b = this.get() % 2 == 0;
                IndexedCell.this.pseudoClassStateChanged(IndexedCell.PSEUDO_CLASS_EVEN, b);
                IndexedCell.this.pseudoClassStateChanged(IndexedCell.PSEUDO_CLASS_ODD, !b);
            }
        };
        this.getStyleClass().addAll("indexed-cell");
    }
    
    public final int getIndex() {
        return this.index.get();
    }
    
    public final ReadOnlyIntegerProperty indexProperty() {
        return this.index.getReadOnlyProperty();
    }
    
    public void updateIndex(final int n) {
        final int value = this.index.get();
        this.index.set(n);
        this.indexChanged(value, n);
    }
    
    void indexChanged(final int n, final int n2) {
    }
    
    static {
        PSEUDO_CLASS_ODD = PseudoClass.getPseudoClass("odd");
        PSEUDO_CLASS_EVEN = PseudoClass.getPseudoClass("even");
    }
}
