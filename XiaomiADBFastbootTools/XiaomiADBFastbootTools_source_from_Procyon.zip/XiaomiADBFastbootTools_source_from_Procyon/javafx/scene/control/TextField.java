// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.SizeConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;
import com.sun.javafx.binding.ExpressionHelper;
import javafx.event.Event;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.TextFieldSkin;
import javafx.css.StyleableObjectProperty;
import javafx.scene.AccessibleRole;
import javafx.event.EventType;
import javafx.beans.property.ObjectPropertyBase;
import javafx.css.CssMetaData;
import javafx.css.StyleableIntegerProperty;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.IntegerProperty;

public class TextField extends TextInputControl
{
    public static final int DEFAULT_PREF_COLUMN_COUNT = 12;
    private IntegerProperty prefColumnCount;
    private ObjectProperty<EventHandler<ActionEvent>> onAction;
    private ObjectProperty<Pos> alignment;
    
    public TextField() {
        this("");
    }
    
    public TextField(final String text) {
        super(new TextFieldContent());
        this.prefColumnCount = new StyleableIntegerProperty(12) {
            private int oldValue = this.get();
            
            @Override
            protected void invalidated() {
                final int value = this.get();
                if (value < 0) {
                    if (this.isBound()) {
                        this.unbind();
                    }
                    this.set(this.oldValue);
                    throw new IllegalArgumentException("value cannot be negative.");
                }
                this.oldValue = value;
            }
            
            @Override
            public CssMetaData<TextField, Number> getCssMetaData() {
                return StyleableProperties.PREF_COLUMN_COUNT;
            }
            
            @Override
            public Object getBean() {
                return TextField.this;
            }
            
            @Override
            public String getName() {
                return "prefColumnCount";
            }
        };
        this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler((EventType<Event>)ActionEvent.ACTION, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return TextField.this;
            }
            
            @Override
            public String getName() {
                return "onAction";
            }
        };
        this.getStyleClass().add("text-field");
        this.setAccessibleRole(AccessibleRole.TEXT_FIELD);
        this.setText(text);
    }
    
    public CharSequence getCharacters() {
        return ((TextFieldContent)this.getContent()).characters;
    }
    
    public final IntegerProperty prefColumnCountProperty() {
        return this.prefColumnCount;
    }
    
    public final int getPrefColumnCount() {
        return this.prefColumnCount.getValue();
    }
    
    public final void setPrefColumnCount(final int i) {
        this.prefColumnCount.setValue(i);
    }
    
    public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() {
        return this.onAction;
    }
    
    public final EventHandler<ActionEvent> getOnAction() {
        return this.onActionProperty().get();
    }
    
    public final void setOnAction(final EventHandler<ActionEvent> eventHandler) {
        this.onActionProperty().set(eventHandler);
    }
    
    public final ObjectProperty<Pos> alignmentProperty() {
        if (this.alignment == null) {
            this.alignment = new StyleableObjectProperty<Pos>(Pos.CENTER_LEFT) {
                @Override
                public CssMetaData<TextField, Pos> getCssMetaData() {
                    return StyleableProperties.ALIGNMENT;
                }
                
                @Override
                public Object getBean() {
                    return TextField.this;
                }
                
                @Override
                public String getName() {
                    return "alignment";
                }
            };
        }
        return this.alignment;
    }
    
    public final void setAlignment(final Pos pos) {
        this.alignmentProperty().set(pos);
    }
    
    public final Pos getAlignment() {
        return (this.alignment == null) ? Pos.CENTER_LEFT : this.alignment.get();
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TextFieldSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static final class TextFieldContent implements Content
    {
        private ExpressionHelper<String> helper;
        private StringBuilder characters;
        
        private TextFieldContent() {
            this.helper = null;
            this.characters = new StringBuilder();
        }
        
        @Override
        public String get(final int n, final int n2) {
            return this.characters.substring(n, n2);
        }
        
        @Override
        public void insert(final int offset, String filterInput, final boolean b) {
            filterInput = TextInputControl.filterInput(filterInput, true, true);
            if (!filterInput.isEmpty()) {
                this.characters.insert(offset, filterInput);
                if (b) {
                    ExpressionHelper.fireValueChangedEvent(this.helper);
                }
            }
        }
        
        @Override
        public void delete(final int start, final int end, final boolean b) {
            if (end > start) {
                this.characters.delete(start, end);
                if (b) {
                    ExpressionHelper.fireValueChangedEvent(this.helper);
                }
            }
        }
        
        @Override
        public int length() {
            return this.characters.length();
        }
        
        @Override
        public String get() {
            return this.characters.toString();
        }
        
        @Override
        public void addListener(final ChangeListener<? super String> changeListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, changeListener);
        }
        
        @Override
        public void removeListener(final ChangeListener<? super String> changeListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, changeListener);
        }
        
        @Override
        public String getValue() {
            return this.get();
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, invalidationListener);
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TextField, Pos> ALIGNMENT;
        private static final CssMetaData<TextField, Number> PREF_COLUMN_COUNT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            ALIGNMENT = new CssMetaData<TextField, Pos>((StyleConverter)new EnumConverter(Pos.class), Pos.CENTER_LEFT) {
                @Override
                public boolean isSettable(final TextField textField) {
                    return textField.alignment == null || !textField.alignment.isBound();
                }
                
                @Override
                public StyleableProperty<Pos> getStyleableProperty(final TextField textField) {
                    return (StyleableProperty<Pos>)(StyleableProperty)textField.alignmentProperty();
                }
            };
            PREF_COLUMN_COUNT = new CssMetaData<TextField, Number>((StyleConverter)SizeConverter.getInstance(), (Number)12) {
                @Override
                public boolean isSettable(final TextField textField) {
                    return textField.prefColumnCount == null || !textField.prefColumnCount.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TextField textField) {
                    return (StyleableProperty<Number>)textField.prefColumnCountProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(TextInputControl.getClassCssMetaData());
            list.add(StyleableProperties.ALIGNMENT);
            list.add(StyleableProperties.PREF_COLUMN_COUNT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
