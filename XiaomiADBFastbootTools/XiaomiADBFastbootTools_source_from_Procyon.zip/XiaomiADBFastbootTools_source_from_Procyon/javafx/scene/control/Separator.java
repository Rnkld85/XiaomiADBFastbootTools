// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.SeparatorSkin;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.css.PseudoClass;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.geometry.Orientation;
import javafx.beans.property.ObjectProperty;

public class Separator extends Control
{
    private ObjectProperty<Orientation> orientation;
    private ObjectProperty<HPos> halignment;
    private ObjectProperty<VPos> valignment;
    private static final String DEFAULT_STYLE_CLASS = "separator";
    private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE;
    private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE;
    
    public Separator() {
        this(Orientation.HORIZONTAL);
    }
    
    public Separator(final Orientation orientation) {
        this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL) {
            @Override
            protected void invalidated() {
                final boolean b = this.get() == Orientation.VERTICAL;
                Separator.this.pseudoClassStateChanged(Separator.VERTICAL_PSEUDOCLASS_STATE, b);
                Separator.this.pseudoClassStateChanged(Separator.HORIZONTAL_PSEUDOCLASS_STATE, !b);
            }
            
            @Override
            public CssMetaData<Separator, Orientation> getCssMetaData() {
                return StyleableProperties.ORIENTATION;
            }
            
            @Override
            public Object getBean() {
                return Separator.this;
            }
            
            @Override
            public String getName() {
                return "orientation";
            }
        };
        this.getStyleClass().setAll("separator");
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
        this.pseudoClassStateChanged(Separator.HORIZONTAL_PSEUDOCLASS_STATE, orientation != Orientation.VERTICAL);
        this.pseudoClassStateChanged(Separator.VERTICAL_PSEUDOCLASS_STATE, orientation == Orientation.VERTICAL);
        ((StyleableProperty)this.orientationProperty()).applyStyle(null, (orientation != null) ? orientation : Orientation.HORIZONTAL);
    }
    
    public final void setOrientation(final Orientation orientation) {
        this.orientation.set(orientation);
    }
    
    public final Orientation getOrientation() {
        return this.orientation.get();
    }
    
    public final ObjectProperty<Orientation> orientationProperty() {
        return this.orientation;
    }
    
    public final void setHalignment(final HPos hPos) {
        this.halignmentProperty().set(hPos);
    }
    
    public final HPos getHalignment() {
        return (this.halignment == null) ? HPos.CENTER : this.halignment.get();
    }
    
    public final ObjectProperty<HPos> halignmentProperty() {
        if (this.halignment == null) {
            this.halignment = new StyleableObjectProperty<HPos>(HPos.CENTER) {
                @Override
                public Object getBean() {
                    return Separator.this;
                }
                
                @Override
                public String getName() {
                    return "halignment";
                }
                
                @Override
                public CssMetaData<Separator, HPos> getCssMetaData() {
                    return StyleableProperties.HALIGNMENT;
                }
            };
        }
        return this.halignment;
    }
    
    public final void setValignment(final VPos vPos) {
        this.valignmentProperty().set(vPos);
    }
    
    public final VPos getValignment() {
        return (this.valignment == null) ? VPos.CENTER : this.valignment.get();
    }
    
    public final ObjectProperty<VPos> valignmentProperty() {
        if (this.valignment == null) {
            this.valignment = new StyleableObjectProperty<VPos>(VPos.CENTER) {
                @Override
                public Object getBean() {
                    return Separator.this;
                }
                
                @Override
                public String getName() {
                    return "valignment";
                }
                
                @Override
                public CssMetaData<Separator, VPos> getCssMetaData() {
                    return StyleableProperties.VALIGNMENT;
                }
            };
        }
        return this.valignment;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new SeparatorSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    protected List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    static {
        VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
        HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Separator, Orientation> ORIENTATION;
        private static final CssMetaData<Separator, HPos> HALIGNMENT;
        private static final CssMetaData<Separator, VPos> VALIGNMENT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            ORIENTATION = new CssMetaData<Separator, Orientation>((StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL) {
                @Override
                public Orientation getInitialValue(final Separator separator) {
                    return separator.getOrientation();
                }
                
                @Override
                public boolean isSettable(final Separator separator) {
                    return separator.orientation == null || !separator.orientation.isBound();
                }
                
                @Override
                public StyleableProperty<Orientation> getStyleableProperty(final Separator separator) {
                    return (StyleableProperty<Orientation>)(StyleableProperty)separator.orientationProperty();
                }
            };
            HALIGNMENT = new CssMetaData<Separator, HPos>((StyleConverter)new EnumConverter(HPos.class), HPos.CENTER) {
                @Override
                public boolean isSettable(final Separator separator) {
                    return separator.halignment == null || !separator.halignment.isBound();
                }
                
                @Override
                public StyleableProperty<HPos> getStyleableProperty(final Separator separator) {
                    return (StyleableProperty<HPos>)(StyleableProperty)separator.halignmentProperty();
                }
            };
            VALIGNMENT = new CssMetaData<Separator, VPos>((StyleConverter)new EnumConverter(VPos.class), VPos.CENTER) {
                @Override
                public boolean isSettable(final Separator separator) {
                    return separator.valignment == null || !separator.valignment.isBound();
                }
                
                @Override
                public StyleableProperty<VPos> getStyleableProperty(final Separator separator) {
                    return (StyleableProperty<VPos>)(StyleableProperty)separator.valignmentProperty();
                }
            };
            final ArrayList<CssMetaData<Separator, HPos>> list = new ArrayList<CssMetaData<Separator, HPos>>((Collection<? extends CssMetaData<Separator, HPos>>)Control.getClassCssMetaData());
            list.add(StyleableProperties.ORIENTATION);
            list.add((CssMetaData<Separator, Orientation>)StyleableProperties.HALIGNMENT);
            list.add((CssMetaData<Separator, Orientation>)StyleableProperties.VALIGNMENT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
