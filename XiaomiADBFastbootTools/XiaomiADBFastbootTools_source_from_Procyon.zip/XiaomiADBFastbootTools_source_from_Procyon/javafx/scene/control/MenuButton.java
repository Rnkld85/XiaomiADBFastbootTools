// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.AccessibleAction;
import javafx.scene.control.skin.MenuButtonSkin;
import javafx.event.ActionEvent;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.event.EventTarget;
import javafx.scene.AccessibleRole;
import javafx.beans.property.ObjectPropertyBase;
import javafx.collections.FXCollections;
import javafx.scene.Node;
import javafx.css.PseudoClass;
import javafx.event.EventHandler;
import javafx.geometry.Side;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventType;

public class MenuButton extends ButtonBase
{
    public static final EventType<Event> ON_SHOWING;
    public static final EventType<Event> ON_SHOWN;
    public static final EventType<Event> ON_HIDING;
    public static final EventType<Event> ON_HIDDEN;
    private final ObservableList<MenuItem> items;
    private ReadOnlyBooleanWrapper showing;
    private ObjectProperty<Side> popupSide;
    private ObjectProperty<EventHandler<Event>> onShowing;
    private ObjectProperty<EventHandler<Event>> onShown;
    private ObjectProperty<EventHandler<Event>> onHiding;
    private ObjectProperty<EventHandler<Event>> onHidden;
    private static final String DEFAULT_STYLE_CLASS = "menu-button";
    private static final PseudoClass PSEUDO_CLASS_OPENVERTICALLY;
    private static final PseudoClass PSEUDO_CLASS_SHOWING;
    
    public MenuButton() {
        this(null, null);
    }
    
    public MenuButton(final String s) {
        this(s, null);
    }
    
    public MenuButton(final String s, final Node node) {
        this(s, node, (MenuItem[])null);
    }
    
    public MenuButton(final String text, final Node graphic, final MenuItem... array) {
        this.items = FXCollections.observableArrayList();
        this.showing = new ReadOnlyBooleanWrapper((Object)this, "showing", false) {
            @Override
            protected void invalidated() {
                MenuButton.this.pseudoClassStateChanged(MenuButton.PSEUDO_CLASS_SHOWING, this.get());
                super.invalidated();
            }
        };
        this.onShowing = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(MenuButton.ON_SHOWING, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return MenuButton.this;
            }
            
            @Override
            public String getName() {
                return "onShowing";
            }
        };
        this.onShown = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(MenuButton.ON_SHOWN, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return MenuButton.this;
            }
            
            @Override
            public String getName() {
                return "onShown";
            }
        };
        this.onHiding = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(MenuButton.ON_HIDING, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return MenuButton.this;
            }
            
            @Override
            public String getName() {
                return "onHiding";
            }
        };
        this.onHidden = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(MenuButton.ON_HIDDEN, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return MenuButton.this;
            }
            
            @Override
            public String getName() {
                return "onHidden";
            }
        };
        if (text != null) {
            this.setText(text);
        }
        if (graphic != null) {
            this.setGraphic(graphic);
        }
        if (array != null) {
            this.getItems().addAll(array);
        }
        this.getStyleClass().setAll("menu-button");
        this.setAccessibleRole(AccessibleRole.MENU_BUTTON);
        this.setMnemonicParsing(true);
        this.pseudoClassStateChanged(MenuButton.PSEUDO_CLASS_OPENVERTICALLY, true);
    }
    
    public final ObservableList<MenuItem> getItems() {
        return this.items;
    }
    
    private void setShowing(final boolean b) {
        Event.fireEvent(this, b ? new Event(MenuButton.ON_SHOWING) : new Event(MenuButton.ON_HIDING));
        this.showing.set(b);
        Event.fireEvent(this, b ? new Event(MenuButton.ON_SHOWN) : new Event(MenuButton.ON_HIDDEN));
    }
    
    public final boolean isShowing() {
        return this.showing.get();
    }
    
    public final ReadOnlyBooleanProperty showingProperty() {
        return this.showing.getReadOnlyProperty();
    }
    
    public final void setPopupSide(final Side side) {
        this.popupSideProperty().set(side);
    }
    
    public final Side getPopupSide() {
        return (this.popupSide == null) ? Side.BOTTOM : this.popupSide.get();
    }
    
    public final ObjectProperty<Side> popupSideProperty() {
        if (this.popupSide == null) {
            this.popupSide = new ObjectPropertyBase<Side>(Side.BOTTOM) {
                @Override
                protected void invalidated() {
                    final Side side = this.get();
                    MenuButton.this.pseudoClassStateChanged(MenuButton.PSEUDO_CLASS_OPENVERTICALLY, side == Side.TOP || side == Side.BOTTOM);
                }
                
                @Override
                public Object getBean() {
                    return MenuButton.this;
                }
                
                @Override
                public String getName() {
                    return "popupSide";
                }
            };
        }
        return this.popupSide;
    }
    
    public final ObjectProperty<EventHandler<Event>> onShowingProperty() {
        return this.onShowing;
    }
    
    public final void setOnShowing(final EventHandler<Event> eventHandler) {
        this.onShowingProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnShowing() {
        return this.onShowingProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onShownProperty() {
        return this.onShown;
    }
    
    public final void setOnShown(final EventHandler<Event> eventHandler) {
        this.onShownProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnShown() {
        return this.onShownProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onHidingProperty() {
        return this.onHiding;
    }
    
    public final void setOnHiding(final EventHandler<Event> eventHandler) {
        this.onHidingProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnHiding() {
        return this.onHidingProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onHiddenProperty() {
        return this.onHidden;
    }
    
    public final void setOnHidden(final EventHandler<Event> eventHandler) {
        this.onHiddenProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnHidden() {
        return this.onHiddenProperty().get();
    }
    
    public void show() {
        if (!this.isDisabled() && !this.showing.isBound()) {
            this.setShowing(true);
        }
    }
    
    public void hide() {
        if (!this.showing.isBound()) {
            this.setShowing(false);
        }
    }
    
    @Override
    public void fire() {
        if (!this.isDisabled()) {
            this.fireEvent(new ActionEvent());
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new MenuButtonSkin(this);
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case FIRE: {
                if (this.isShowing()) {
                    this.hide();
                    break;
                }
                this.show();
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, new Object[0]);
                break;
            }
        }
    }
    
    static {
        ON_SHOWING = new EventType<Event>(Event.ANY, "MENU_BUTTON_ON_SHOWING");
        ON_SHOWN = new EventType<Event>(Event.ANY, "MENU_BUTTON_ON_SHOWN");
        ON_HIDING = new EventType<Event>(Event.ANY, "MENU_BUTTON_ON_HIDING");
        ON_HIDDEN = new EventType<Event>(Event.ANY, "MENU_BUTTON_ON_HIDDEN");
        PSEUDO_CLASS_OPENVERTICALLY = PseudoClass.getPseudoClass("openvertically");
        PSEUDO_CLASS_SHOWING = PseudoClass.getPseudoClass("showing");
    }
}
