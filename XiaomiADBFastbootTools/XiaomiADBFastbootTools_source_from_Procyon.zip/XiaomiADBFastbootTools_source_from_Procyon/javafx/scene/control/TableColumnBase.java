// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import com.sun.javafx.scene.control.TableColumnBaseHelper;
import java.text.Collator;
import javafx.css.PseudoClass;
import javafx.collections.ObservableSet;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.event.EventDispatcher;
import javafx.event.EventDispatchChain;
import javafx.beans.value.ObservableValue;
import java.util.Map;
import java.util.HashMap;
import javafx.beans.property.ReadOnlyDoubleProperty;
import java.util.List;
import com.sun.javafx.scene.control.ControlAcceleratorSupport;
import java.lang.ref.WeakReference;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import java.util.Iterator;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableMap;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyDoubleWrapper;
import javafx.scene.Node;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.StringProperty;
import com.sun.javafx.event.EventHandlerManager;
import java.util.Comparator;
import com.sun.javafx.beans.IDProperty;
import javafx.css.Styleable;
import javafx.event.EventTarget;

@IDProperty("id")
public abstract class TableColumnBase<S, T> implements EventTarget, Styleable
{
    static final double DEFAULT_WIDTH = 80.0;
    static final double DEFAULT_MIN_WIDTH = 10.0;
    static final double DEFAULT_MAX_WIDTH = 5000.0;
    public static final Comparator DEFAULT_COMPARATOR;
    final EventHandlerManager eventHandlerManager;
    private StringProperty text;
    private BooleanProperty visible;
    private ReadOnlyObjectWrapper<TableColumnBase<S, ?>> parentColumn;
    private ObjectProperty<ContextMenu> contextMenu;
    private StringProperty id;
    private StringProperty style;
    private final ObservableList<String> styleClass;
    private ObjectProperty<Node> graphic;
    private ObjectProperty<Node> sortNode;
    private ReadOnlyDoubleWrapper width;
    private DoubleProperty minWidth;
    private final DoubleProperty prefWidth;
    private DoubleProperty maxWidth;
    private BooleanProperty resizable;
    private BooleanProperty sortable;
    private BooleanProperty reorderable;
    private ObjectProperty<Comparator<T>> comparator;
    private BooleanProperty editable;
    private static final Object USER_DATA_KEY;
    private ObservableMap<Object, Object> properties;
    
    protected TableColumnBase() {
        this("");
    }
    
    protected TableColumnBase(final String text) {
        this.eventHandlerManager = new EventHandlerManager(this);
        this.text = new SimpleStringProperty(this, "text", "");
        this.visible = new SimpleBooleanProperty((Object)this, "visible", true) {
            @Override
            protected void invalidated() {
                final Iterator<TableColumnBase> iterator = TableColumnBase.this.getColumns().iterator();
                while (iterator.hasNext()) {
                    iterator.next().setVisible(TableColumnBase.this.isVisible());
                }
            }
        };
        this.styleClass = FXCollections.observableArrayList();
        this.sortNode = new SimpleObjectProperty<Node>(this, "sortNode");
        this.width = new ReadOnlyDoubleWrapper(this, "width", 80.0);
        this.prefWidth = new SimpleDoubleProperty((Object)this, "prefWidth", 80.0) {
            @Override
            protected void invalidated() {
                TableColumnBase.this.doSetWidth(TableColumnBase.this.getPrefWidth());
            }
        };
        this.maxWidth = new SimpleDoubleProperty((Object)this, "maxWidth", 5000.0) {
            @Override
            protected void invalidated() {
                TableColumnBase.this.doSetWidth(TableColumnBase.this.getWidth());
            }
        };
        this.setText(text);
    }
    
    public final StringProperty textProperty() {
        return this.text;
    }
    
    public final void setText(final String s) {
        this.text.set(s);
    }
    
    public final String getText() {
        return this.text.get();
    }
    
    public final void setVisible(final boolean b) {
        this.visibleProperty().set(b);
    }
    
    public final boolean isVisible() {
        return this.visible.get();
    }
    
    public final BooleanProperty visibleProperty() {
        return this.visible;
    }
    
    void setParentColumn(final TableColumnBase<S, ?> tableColumnBase) {
        this.parentColumnPropertyImpl().set(tableColumnBase);
    }
    
    public final TableColumnBase<S, ?> getParentColumn() {
        return (this.parentColumn == null) ? null : this.parentColumn.get();
    }
    
    public final ReadOnlyObjectProperty<TableColumnBase<S, ?>> parentColumnProperty() {
        return this.parentColumnPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<TableColumnBase<S, ?>> parentColumnPropertyImpl() {
        if (this.parentColumn == null) {
            this.parentColumn = new ReadOnlyObjectWrapper<TableColumnBase<S, ?>>(this, "parentColumn");
        }
        return this.parentColumn;
    }
    
    public final void setContextMenu(final ContextMenu contextMenu) {
        this.contextMenuProperty().set(contextMenu);
    }
    
    public final ContextMenu getContextMenu() {
        return (this.contextMenu == null) ? null : this.contextMenu.get();
    }
    
    public final ObjectProperty<ContextMenu> contextMenuProperty() {
        if (this.contextMenu == null) {
            this.contextMenu = new SimpleObjectProperty<ContextMenu>(this, "contextMenu") {
                private WeakReference<ContextMenu> contextMenuRef;
                
                @Override
                protected void invalidated() {
                    final ContextMenu contextMenu = (this.contextMenuRef == null) ? null : this.contextMenuRef.get();
                    if (contextMenu != null) {
                        ControlAcceleratorSupport.removeAcceleratorsFromScene(contextMenu.getItems(), TableColumnBase.this);
                    }
                    final ContextMenu referent = this.get();
                    this.contextMenuRef = new WeakReference<ContextMenu>(referent);
                    if (referent != null) {
                        ControlAcceleratorSupport.addAcceleratorsIntoScene(referent.getItems(), TableColumnBase.this);
                    }
                }
            };
        }
        return this.contextMenu;
    }
    
    public final void setId(final String s) {
        this.idProperty().set(s);
    }
    
    @Override
    public final String getId() {
        return (this.id == null) ? null : this.id.get();
    }
    
    public final StringProperty idProperty() {
        if (this.id == null) {
            this.id = new SimpleStringProperty(this, "id");
        }
        return this.id;
    }
    
    public final void setStyle(final String s) {
        this.styleProperty().set(s);
    }
    
    @Override
    public final String getStyle() {
        return (this.style == null) ? "" : this.style.get();
    }
    
    public final StringProperty styleProperty() {
        if (this.style == null) {
            this.style = new SimpleStringProperty(this, "style");
        }
        return this.style;
    }
    
    @Override
    public ObservableList<String> getStyleClass() {
        return this.styleClass;
    }
    
    public final void setGraphic(final Node node) {
        this.graphicProperty().set(node);
    }
    
    public final Node getGraphic() {
        return (this.graphic == null) ? null : this.graphic.get();
    }
    
    public final ObjectProperty<Node> graphicProperty() {
        if (this.graphic == null) {
            this.graphic = new SimpleObjectProperty<Node>(this, "graphic");
        }
        return this.graphic;
    }
    
    public final void setSortNode(final Node node) {
        this.sortNodeProperty().set(node);
    }
    
    public final Node getSortNode() {
        return this.sortNode.get();
    }
    
    public final ObjectProperty<Node> sortNodeProperty() {
        return this.sortNode;
    }
    
    public final ReadOnlyDoubleProperty widthProperty() {
        return this.width.getReadOnlyProperty();
    }
    
    public final double getWidth() {
        return this.width.get();
    }
    
    void setWidth(final double n) {
        this.width.set(n);
    }
    
    public final void setMinWidth(final double n) {
        this.minWidthProperty().set(n);
    }
    
    public final double getMinWidth() {
        return (this.minWidth == null) ? 10.0 : this.minWidth.get();
    }
    
    public final DoubleProperty minWidthProperty() {
        if (this.minWidth == null) {
            this.minWidth = new SimpleDoubleProperty(this, "minWidth", 10.0) {
                @Override
                protected void invalidated() {
                    if (TableColumnBase.this.getMinWidth() < 0.0) {
                        TableColumnBase.this.setMinWidth(0.0);
                    }
                    TableColumnBase.this.doSetWidth(TableColumnBase.this.getWidth());
                }
            };
        }
        return this.minWidth;
    }
    
    public final DoubleProperty prefWidthProperty() {
        return this.prefWidth;
    }
    
    public final void setPrefWidth(final double n) {
        this.prefWidthProperty().set(n);
    }
    
    public final double getPrefWidth() {
        return this.prefWidth.get();
    }
    
    public final DoubleProperty maxWidthProperty() {
        return this.maxWidth;
    }
    
    public final void setMaxWidth(final double n) {
        this.maxWidthProperty().set(n);
    }
    
    public final double getMaxWidth() {
        return this.maxWidth.get();
    }
    
    public final BooleanProperty resizableProperty() {
        if (this.resizable == null) {
            this.resizable = new SimpleBooleanProperty(this, "resizable", true);
        }
        return this.resizable;
    }
    
    public final void setResizable(final boolean b) {
        this.resizableProperty().set(b);
    }
    
    public final boolean isResizable() {
        return this.resizable == null || this.resizable.get();
    }
    
    public final BooleanProperty sortableProperty() {
        if (this.sortable == null) {
            this.sortable = new SimpleBooleanProperty(this, "sortable", true);
        }
        return this.sortable;
    }
    
    public final void setSortable(final boolean b) {
        this.sortableProperty().set(b);
    }
    
    public final boolean isSortable() {
        return this.sortable == null || this.sortable.get();
    }
    
    public final BooleanProperty reorderableProperty() {
        if (this.reorderable == null) {
            this.reorderable = new SimpleBooleanProperty(this, "reorderable", true);
        }
        return this.reorderable;
    }
    
    public final void setReorderable(final boolean b) {
        this.reorderableProperty().set(b);
    }
    
    public final boolean isReorderable() {
        return this.reorderable == null || this.reorderable.get();
    }
    
    public final ObjectProperty<Comparator<T>> comparatorProperty() {
        if (this.comparator == null) {
            this.comparator = new SimpleObjectProperty<Comparator<T>>(this, "comparator", TableColumnBase.DEFAULT_COMPARATOR);
        }
        return this.comparator;
    }
    
    public final void setComparator(final Comparator<T> comparator) {
        this.comparatorProperty().set(comparator);
    }
    
    public final Comparator<T> getComparator() {
        return (this.comparator == null) ? TableColumnBase.DEFAULT_COMPARATOR : ((Comparator<T>)this.comparator.get());
    }
    
    public final void setEditable(final boolean b) {
        this.editableProperty().set(b);
    }
    
    public final boolean isEditable() {
        return this.editable == null || this.editable.get();
    }
    
    public final BooleanProperty editableProperty() {
        if (this.editable == null) {
            this.editable = new SimpleBooleanProperty(this, "editable", true);
        }
        return this.editable;
    }
    
    public final ObservableMap<Object, Object> getProperties() {
        if (this.properties == null) {
            this.properties = FXCollections.observableMap(new HashMap<Object, Object>());
        }
        return this.properties;
    }
    
    public boolean hasProperties() {
        return this.properties != null && !this.properties.isEmpty();
    }
    
    public void setUserData(final Object o) {
        this.getProperties().put(TableColumnBase.USER_DATA_KEY, o);
    }
    
    public Object getUserData() {
        return this.getProperties().get(TableColumnBase.USER_DATA_KEY);
    }
    
    public abstract ObservableList<? extends TableColumnBase<S, ?>> getColumns();
    
    public final T getCellData(final int n) {
        final ObservableValue<T> cellObservableValue = this.getCellObservableValue(n);
        return (cellObservableValue == null) ? null : cellObservableValue.getValue();
    }
    
    public final T getCellData(final S n) {
        final ObservableValue<T> cellObservableValue = this.getCellObservableValue(n);
        return (cellObservableValue == null) ? null : cellObservableValue.getValue();
    }
    
    public abstract ObservableValue<T> getCellObservableValue(final int p0);
    
    public abstract ObservableValue<T> getCellObservableValue(final S p0);
    
    @Override
    public EventDispatchChain buildEventDispatchChain(final EventDispatchChain eventDispatchChain) {
        return eventDispatchChain.prepend(this.eventHandlerManager);
    }
    
    public <E extends Event> void addEventHandler(final EventType<E> eventType, final EventHandler<E> eventHandler) {
        this.eventHandlerManager.addEventHandler(eventType, eventHandler);
    }
    
    public <E extends Event> void removeEventHandler(final EventType<E> eventType, final EventHandler<E> eventHandler) {
        this.eventHandlerManager.removeEventHandler(eventType, eventHandler);
    }
    
    void doSetWidth(final double n) {
        this.setWidth(Utils.boundedSize(n, this.getMinWidth(), this.getMaxWidth()));
    }
    
    void updateColumnWidths() {
        if (!this.getColumns().isEmpty()) {
            double minWidth = 0.0;
            double prefWidth = 0.0;
            double maxWidth = 0.0;
            for (final TableColumnBase tableColumnBase : this.getColumns()) {
                tableColumnBase.setParentColumn(this);
                minWidth += tableColumnBase.getMinWidth();
                prefWidth += tableColumnBase.getPrefWidth();
                maxWidth += tableColumnBase.getMaxWidth();
            }
            this.setMinWidth(minWidth);
            this.setPrefWidth(prefWidth);
            this.setMaxWidth(maxWidth);
        }
    }
    
    @Override
    public final ObservableSet<PseudoClass> getPseudoClassStates() {
        return FXCollections.emptyObservableSet();
    }
    
    static {
        TableColumnBaseHelper.setTableColumnBaseAccessor(new TableColumnBaseHelper.TableColumnBaseAccessor() {
            @Override
            public void setWidth(final TableColumnBase tableColumnBase, final double n) {
                tableColumnBase.doSetWidth(n);
            }
        });
        DEFAULT_COMPARATOR = ((o1, o2) -> {
            if (o1 == null && o2 == null) {
                return 0;
            }
            else if (o1 == null) {
                return -1;
            }
            else if (o2 == null) {
                return 1;
            }
            else if (o1 instanceof Comparable && (o1.getClass() == o2.getClass() || o1.getClass().isAssignableFrom(o2.getClass()))) {
                return (o1 instanceof String) ? Collator.getInstance().compare(o1, o2) : o1.compareTo(o2);
            }
            else {
                return Collator.getInstance().compare(o1.toString(), o2.toString());
            }
        });
        USER_DATA_KEY = new Object();
    }
}
