// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.Observable;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.Node;
import javafx.scene.layout.Priority;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import java.util.Collection;
import java.util.Arrays;
import java.util.Collections;
import javafx.scene.layout.GridPane;

public class ChoiceDialog<T> extends Dialog<T>
{
    private final GridPane grid;
    private final Label label;
    private final ComboBox<T> comboBox;
    private final T defaultChoice;
    
    public ChoiceDialog() {
        this(null, (Object[])null);
    }
    
    public ChoiceDialog(final T t, final T... a) {
        this(t, (Collection<Object>)((a == null) ? Collections.emptyList() : Arrays.asList(a)));
    }
    
    public ChoiceDialog(final T t, final Collection<T> collection) {
        final DialogPane dialogPane = this.getDialogPane();
        (this.grid = new GridPane()).setHgap(10.0);
        this.grid.setMaxWidth(Double.MAX_VALUE);
        this.grid.setAlignment(Pos.CENTER_LEFT);
        (this.label = DialogPane.createContentLabel(dialogPane.getContentText())).setPrefWidth(-1.0);
        this.label.textProperty().bind(dialogPane.contentTextProperty());
        dialogPane.contentTextProperty().addListener(p0 -> this.updateGrid());
        this.setTitle(ControlResources.getString("Dialog.confirm.title"));
        dialogPane.setHeaderText(ControlResources.getString("Dialog.confirm.header"));
        dialogPane.getStyleClass().add("choice-dialog");
        dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        (this.comboBox = new ComboBox<T>()).setMinWidth(150.0);
        if (collection != null) {
            this.comboBox.getItems().addAll((Collection<?>)collection);
        }
        this.comboBox.setMaxWidth(Double.MAX_VALUE);
        GridPane.setHgrow(this.comboBox, Priority.ALWAYS);
        GridPane.setFillWidth(this.comboBox, true);
        this.defaultChoice = (this.comboBox.getItems().contains(t) ? t : null);
        if (t == null) {
            this.comboBox.getSelectionModel().selectFirst();
        }
        else {
            this.comboBox.getSelectionModel().select(t);
        }
        this.updateGrid();
        this.setResultConverter(buttonType -> (((buttonType == null) ? null : buttonType.getButtonData()) == ButtonBar.ButtonData.OK_DONE) ? this.getSelectedItem() : null);
    }
    
    public final T getSelectedItem() {
        return this.comboBox.getSelectionModel().getSelectedItem();
    }
    
    public final ReadOnlyObjectProperty<T> selectedItemProperty() {
        return this.comboBox.getSelectionModel().selectedItemProperty();
    }
    
    public final void setSelectedItem(final T t) {
        this.comboBox.getSelectionModel().select(t);
    }
    
    public final ObservableList<T> getItems() {
        return this.comboBox.getItems();
    }
    
    public final T getDefaultChoice() {
        return this.defaultChoice;
    }
    
    private void updateGrid() {
        this.grid.getChildren().clear();
        this.grid.add(this.label, 0, 0);
        this.grid.add(this.comboBox, 1, 0);
        this.getDialogPane().setContent(this.grid);
        Platform.runLater(() -> this.comboBox.requestFocus());
    }
}
