// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.MenuBarSkin;
import javafx.beans.value.ObservableValue;
import javafx.css.CssMetaData;
import javafx.css.StyleableBooleanProperty;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.scene.AccessibleRole;
import javafx.collections.FXCollections;
import javafx.beans.property.BooleanProperty;
import javafx.collections.ObservableList;
import javafx.beans.DefaultProperty;

@DefaultProperty("menus")
public class MenuBar extends Control
{
    private ObservableList<Menu> menus;
    private String BIND_MSG;
    private BooleanProperty useSystemMenuBar;
    private static final String DEFAULT_STYLE_CLASS = "menu-bar";
    
    public MenuBar() {
        this((Menu[])null);
    }
    
    public MenuBar(final Menu... array) {
        this.menus = FXCollections.observableArrayList();
        this.BIND_MSG = "cannot uni-directionally bind to the system menu bar - use bindBidrectional instead";
        this.getStyleClass().setAll("menu-bar");
        this.setAccessibleRole(AccessibleRole.MENU_BAR);
        if (array != null) {
            this.getMenus().addAll(array);
        }
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
    }
    
    public final BooleanProperty useSystemMenuBarProperty() {
        if (this.useSystemMenuBar == null) {
            this.useSystemMenuBar = new StyleableBooleanProperty() {
                @Override
                public CssMetaData<MenuBar, Boolean> getCssMetaData() {
                    return StyleableProperties.USE_SYSTEM_MENU_BAR;
                }
                
                @Override
                public Object getBean() {
                    return MenuBar.this;
                }
                
                @Override
                public String getName() {
                    return "useSystemMenuBar";
                }
                
                @Override
                public void bind(final ObservableValue<? extends Boolean> observableValue) {
                    throw new RuntimeException(MenuBar.this.BIND_MSG);
                }
            };
        }
        return this.useSystemMenuBar;
    }
    
    public final void setUseSystemMenuBar(final boolean b) {
        this.useSystemMenuBarProperty().setValue(b);
    }
    
    public final boolean isUseSystemMenuBar() {
        return this.useSystemMenuBar != null && this.useSystemMenuBar.getValue();
    }
    
    public final ObservableList<Menu> getMenus() {
        return this.menus;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new MenuBarSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<MenuBar, Boolean> USE_SYSTEM_MENU_BAR;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            USE_SYSTEM_MENU_BAR = new CssMetaData<MenuBar, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.valueOf(false)) {
                @Override
                public boolean isSettable(final MenuBar menuBar) {
                    return menuBar.useSystemMenuBar == null || !menuBar.useSystemMenuBar.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final MenuBar menuBar) {
                    return (StyleableProperty<Boolean>)menuBar.useSystemMenuBarProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.USE_SYSTEM_MENU_BAR);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
