// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.InsetsConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.converter.BooleanConverter;
import javafx.css.converter.StringConverter;
import javafx.css.converter.PaintConverter;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.css.FontCssMetaData;
import javafx.css.Styleable;
import java.util.List;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.paint.Color;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.css.StyleableDoubleProperty;
import javafx.scene.image.Image;
import com.sun.javafx.css.StyleManager;
import javafx.scene.image.ImageView;
import com.sun.javafx.scene.NodeHelper;
import javafx.geometry.Orientation;
import javafx.css.StyleableBooleanProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.scene.paint.Paint;
import javafx.geometry.Insets;
import javafx.beans.property.DoubleProperty;
import javafx.css.StyleableStringProperty;
import javafx.scene.Node;
import javafx.scene.text.Font;
import javafx.beans.property.BooleanProperty;
import javafx.scene.text.TextAlignment;
import javafx.geometry.Pos;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.DefaultProperty;

@DefaultProperty("text")
public abstract class Labeled extends Control
{
    private static final String DEFAULT_ELLIPSIS_STRING = "...";
    private StringProperty text;
    private ObjectProperty<Pos> alignment;
    private ObjectProperty<TextAlignment> textAlignment;
    private ObjectProperty<OverrunStyle> textOverrun;
    private StringProperty ellipsisString;
    private BooleanProperty wrapText;
    private ObjectProperty<Font> font;
    private ObjectProperty<Node> graphic;
    private StyleableStringProperty imageUrl;
    private BooleanProperty underline;
    private DoubleProperty lineSpacing;
    private ObjectProperty<ContentDisplay> contentDisplay;
    private ObjectProperty<Insets> labelPadding;
    private DoubleProperty graphicTextGap;
    private ObjectProperty<Paint> textFill;
    private BooleanProperty mnemonicParsing;
    
    public Labeled() {
        this.imageUrl = null;
    }
    
    public Labeled(final String text) {
        this.imageUrl = null;
        this.setText(text);
    }
    
    public Labeled(final String text, final Node node) {
        this.imageUrl = null;
        this.setText(text);
        ((StyleableProperty)this.graphicProperty()).applyStyle(null, node);
    }
    
    public final StringProperty textProperty() {
        if (this.text == null) {
            this.text = new SimpleStringProperty(this, "text", "");
        }
        return this.text;
    }
    
    public final void setText(final String value) {
        this.textProperty().setValue(value);
    }
    
    public final String getText() {
        return (this.text == null) ? "" : this.text.getValue();
    }
    
    public final ObjectProperty<Pos> alignmentProperty() {
        if (this.alignment == null) {
            this.alignment = new StyleableObjectProperty<Pos>(Pos.CENTER_LEFT) {
                @Override
                public CssMetaData<Labeled, Pos> getCssMetaData() {
                    return StyleableProperties.ALIGNMENT;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "alignment";
                }
            };
        }
        return this.alignment;
    }
    
    public final void setAlignment(final Pos pos) {
        this.alignmentProperty().set(pos);
    }
    
    public final Pos getAlignment() {
        return (this.alignment == null) ? Pos.CENTER_LEFT : this.alignment.get();
    }
    
    public final ObjectProperty<TextAlignment> textAlignmentProperty() {
        if (this.textAlignment == null) {
            this.textAlignment = new StyleableObjectProperty<TextAlignment>(TextAlignment.LEFT) {
                @Override
                public CssMetaData<Labeled, TextAlignment> getCssMetaData() {
                    return StyleableProperties.TEXT_ALIGNMENT;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "textAlignment";
                }
            };
        }
        return this.textAlignment;
    }
    
    public final void setTextAlignment(final TextAlignment value) {
        this.textAlignmentProperty().setValue(value);
    }
    
    public final TextAlignment getTextAlignment() {
        return (this.textAlignment == null) ? TextAlignment.LEFT : this.textAlignment.getValue();
    }
    
    public final ObjectProperty<OverrunStyle> textOverrunProperty() {
        if (this.textOverrun == null) {
            this.textOverrun = new StyleableObjectProperty<OverrunStyle>(OverrunStyle.ELLIPSIS) {
                @Override
                public CssMetaData<Labeled, OverrunStyle> getCssMetaData() {
                    return StyleableProperties.TEXT_OVERRUN;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "textOverrun";
                }
            };
        }
        return this.textOverrun;
    }
    
    public final void setTextOverrun(final OverrunStyle value) {
        this.textOverrunProperty().setValue(value);
    }
    
    public final OverrunStyle getTextOverrun() {
        return (this.textOverrun == null) ? OverrunStyle.ELLIPSIS : this.textOverrun.getValue();
    }
    
    public final StringProperty ellipsisStringProperty() {
        if (this.ellipsisString == null) {
            this.ellipsisString = new StyleableStringProperty("...") {
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "ellipsisString";
                }
                
                @Override
                public CssMetaData<Labeled, String> getCssMetaData() {
                    return StyleableProperties.ELLIPSIS_STRING;
                }
            };
        }
        return this.ellipsisString;
    }
    
    public final void setEllipsisString(final String s) {
        this.ellipsisStringProperty().set((s == null) ? "" : s);
    }
    
    public final String getEllipsisString() {
        return (this.ellipsisString == null) ? "..." : this.ellipsisString.get();
    }
    
    public final BooleanProperty wrapTextProperty() {
        if (this.wrapText == null) {
            this.wrapText = new StyleableBooleanProperty() {
                @Override
                public CssMetaData<Labeled, Boolean> getCssMetaData() {
                    return StyleableProperties.WRAP_TEXT;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "wrapText";
                }
            };
        }
        return this.wrapText;
    }
    
    public final void setWrapText(final boolean b) {
        this.wrapTextProperty().setValue(b);
    }
    
    public final boolean isWrapText() {
        return this.wrapText != null && this.wrapText.getValue();
    }
    
    @Override
    public Orientation getContentBias() {
        return this.isWrapText() ? Orientation.HORIZONTAL : null;
    }
    
    public final ObjectProperty<Font> fontProperty() {
        if (this.font == null) {
            this.font = new StyleableObjectProperty<Font>(Font.getDefault()) {
                private boolean fontSetByCss = false;
                
                @Override
                public void applyStyle(final StyleOrigin styleOrigin, final Font font) {
                    try {
                        this.fontSetByCss = true;
                        super.applyStyle(styleOrigin, font);
                    }
                    catch (Exception ex) {
                        throw ex;
                    }
                    finally {
                        this.fontSetByCss = false;
                    }
                }
                
                @Override
                public void set(final Font font) {
                    final Font font2 = this.get();
                    if (font != null) {
                        if (font.equals(font2)) {
                            return;
                        }
                    }
                    else if (font2 == null) {
                        return;
                    }
                    super.set(font);
                }
                
                @Override
                protected void invalidated() {
                    if (!this.fontSetByCss) {
                        NodeHelper.reapplyCSS(Labeled.this);
                    }
                }
                
                @Override
                public CssMetaData<Labeled, Font> getCssMetaData() {
                    return (CssMetaData<Labeled, Font>)StyleableProperties.FONT;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "font";
                }
            };
        }
        return this.font;
    }
    
    public final void setFont(final Font value) {
        this.fontProperty().setValue(value);
    }
    
    public final Font getFont() {
        return (this.font == null) ? Font.getDefault() : this.font.getValue();
    }
    
    public final ObjectProperty<Node> graphicProperty() {
        if (this.graphic == null) {
            this.graphic = new StyleableObjectProperty<Node>() {
                @Override
                public CssMetaData getCssMetaData() {
                    return StyleableProperties.GRAPHIC;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "graphic";
                }
            };
        }
        return this.graphic;
    }
    
    public final void setGraphic(final Node value) {
        this.graphicProperty().setValue(value);
    }
    
    public final Node getGraphic() {
        return (this.graphic == null) ? null : this.graphic.getValue();
    }
    
    private StyleableStringProperty imageUrlProperty() {
        if (this.imageUrl == null) {
            this.imageUrl = new StyleableStringProperty() {
                StyleOrigin origin = StyleOrigin.USER;
                
                @Override
                public void applyStyle(final StyleOrigin origin, final String s) {
                    this.origin = origin;
                    if (Labeled.this.graphic == null || !Labeled.this.graphic.isBound()) {
                        super.applyStyle(origin, s);
                    }
                    this.origin = StyleOrigin.USER;
                }
                
                @Override
                protected void invalidated() {
                    final String value = super.get();
                    if (value == null) {
                        ((StyleableProperty)Labeled.this.graphicProperty()).applyStyle(this.origin, null);
                    }
                    else {
                        final Node graphic = Labeled.this.getGraphic();
                        if (graphic instanceof ImageView) {
                            final Image image = ((ImageView)graphic).getImage();
                            if (image != null && value.equals(image.getUrl())) {
                                return;
                            }
                        }
                        final Image cachedImage = StyleManager.getInstance().getCachedImage(value);
                        if (cachedImage != null) {
                            ((StyleableProperty)Labeled.this.graphicProperty()).applyStyle(this.origin, new ImageView(cachedImage));
                        }
                    }
                }
                
                @Override
                public String get() {
                    final Node graphic = Labeled.this.getGraphic();
                    if (graphic instanceof ImageView) {
                        final Image image = ((ImageView)graphic).getImage();
                        if (image != null) {
                            return image.getUrl();
                        }
                    }
                    return null;
                }
                
                @Override
                public StyleOrigin getStyleOrigin() {
                    return (Labeled.this.graphic != null) ? ((StyleableProperty)Labeled.this.graphic).getStyleOrigin() : null;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "imageUrl";
                }
                
                @Override
                public CssMetaData<Labeled, String> getCssMetaData() {
                    return StyleableProperties.GRAPHIC;
                }
            };
        }
        return this.imageUrl;
    }
    
    public final BooleanProperty underlineProperty() {
        if (this.underline == null) {
            this.underline = new StyleableBooleanProperty(false) {
                @Override
                public CssMetaData<Labeled, Boolean> getCssMetaData() {
                    return StyleableProperties.UNDERLINE;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "underline";
                }
            };
        }
        return this.underline;
    }
    
    public final void setUnderline(final boolean b) {
        this.underlineProperty().setValue(b);
    }
    
    public final boolean isUnderline() {
        return this.underline != null && this.underline.getValue();
    }
    
    public final DoubleProperty lineSpacingProperty() {
        if (this.lineSpacing == null) {
            this.lineSpacing = new StyleableDoubleProperty(0.0) {
                @Override
                public CssMetaData<Labeled, Number> getCssMetaData() {
                    return StyleableProperties.LINE_SPACING;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "lineSpacing";
                }
            };
        }
        return this.lineSpacing;
    }
    
    public final void setLineSpacing(final double d) {
        this.lineSpacingProperty().setValue(d);
    }
    
    public final double getLineSpacing() {
        return (this.lineSpacing == null) ? 0.0 : this.lineSpacing.getValue();
    }
    
    public final ObjectProperty<ContentDisplay> contentDisplayProperty() {
        if (this.contentDisplay == null) {
            this.contentDisplay = new StyleableObjectProperty<ContentDisplay>(ContentDisplay.LEFT) {
                @Override
                public CssMetaData<Labeled, ContentDisplay> getCssMetaData() {
                    return StyleableProperties.CONTENT_DISPLAY;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "contentDisplay";
                }
            };
        }
        return this.contentDisplay;
    }
    
    public final void setContentDisplay(final ContentDisplay value) {
        this.contentDisplayProperty().setValue(value);
    }
    
    public final ContentDisplay getContentDisplay() {
        return (this.contentDisplay == null) ? ContentDisplay.LEFT : this.contentDisplay.getValue();
    }
    
    public final ReadOnlyObjectProperty<Insets> labelPaddingProperty() {
        return this.labelPaddingPropertyImpl();
    }
    
    private ObjectProperty<Insets> labelPaddingPropertyImpl() {
        if (this.labelPadding == null) {
            this.labelPadding = new StyleableObjectProperty<Insets>(Insets.EMPTY) {
                private Insets lastValidValue = Insets.EMPTY;
                
                public void invalidated() {
                    final Insets lastValidValue = this.get();
                    if (lastValidValue == null) {
                        this.set(this.lastValidValue);
                        throw new NullPointerException("cannot set labelPadding to null");
                    }
                    this.lastValidValue = lastValidValue;
                    Labeled.this.requestLayout();
                }
                
                @Override
                public CssMetaData<Labeled, Insets> getCssMetaData() {
                    return StyleableProperties.LABEL_PADDING;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "labelPadding";
                }
            };
        }
        return this.labelPadding;
    }
    
    private void setLabelPadding(final Insets insets) {
        this.labelPaddingPropertyImpl().set(insets);
    }
    
    public final Insets getLabelPadding() {
        return (this.labelPadding == null) ? Insets.EMPTY : this.labelPadding.get();
    }
    
    public final DoubleProperty graphicTextGapProperty() {
        if (this.graphicTextGap == null) {
            this.graphicTextGap = new StyleableDoubleProperty(4.0) {
                @Override
                public CssMetaData<Labeled, Number> getCssMetaData() {
                    return StyleableProperties.GRAPHIC_TEXT_GAP;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "graphicTextGap";
                }
            };
        }
        return this.graphicTextGap;
    }
    
    public final void setGraphicTextGap(final double d) {
        this.graphicTextGapProperty().setValue(d);
    }
    
    public final double getGraphicTextGap() {
        return (this.graphicTextGap == null) ? 4.0 : this.graphicTextGap.getValue();
    }
    
    public final void setTextFill(final Paint paint) {
        this.textFillProperty().set(paint);
    }
    
    public final Paint getTextFill() {
        return (this.textFill == null) ? Color.BLACK : this.textFill.get();
    }
    
    public final ObjectProperty<Paint> textFillProperty() {
        if (this.textFill == null) {
            this.textFill = new StyleableObjectProperty<Paint>(Color.BLACK) {
                @Override
                public CssMetaData<Labeled, Paint> getCssMetaData() {
                    return StyleableProperties.TEXT_FILL;
                }
                
                @Override
                public Object getBean() {
                    return Labeled.this;
                }
                
                @Override
                public String getName() {
                    return "textFill";
                }
            };
        }
        return this.textFill;
    }
    
    public final void setMnemonicParsing(final boolean b) {
        this.mnemonicParsingProperty().set(b);
    }
    
    public final boolean isMnemonicParsing() {
        return this.mnemonicParsing != null && this.mnemonicParsing.get();
    }
    
    public final BooleanProperty mnemonicParsingProperty() {
        if (this.mnemonicParsing == null) {
            this.mnemonicParsing = new SimpleBooleanProperty(this, "mnemonicParsing");
        }
        return this.mnemonicParsing;
    }
    
    @Override
    public String toString() {
        return super.toString() + "'" + this.getText() + "'";
    }
    
    protected Pos getInitialAlignment() {
        return Pos.CENTER_LEFT;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final FontCssMetaData<Labeled> FONT;
        private static final CssMetaData<Labeled, Pos> ALIGNMENT;
        private static final CssMetaData<Labeled, TextAlignment> TEXT_ALIGNMENT;
        private static final CssMetaData<Labeled, Paint> TEXT_FILL;
        private static final CssMetaData<Labeled, OverrunStyle> TEXT_OVERRUN;
        private static final CssMetaData<Labeled, String> ELLIPSIS_STRING;
        private static final CssMetaData<Labeled, Boolean> WRAP_TEXT;
        private static final CssMetaData<Labeled, String> GRAPHIC;
        private static final CssMetaData<Labeled, Boolean> UNDERLINE;
        private static final CssMetaData<Labeled, Number> LINE_SPACING;
        private static final CssMetaData<Labeled, ContentDisplay> CONTENT_DISPLAY;
        private static final CssMetaData<Labeled, Insets> LABEL_PADDING;
        private static final CssMetaData<Labeled, Number> GRAPHIC_TEXT_GAP;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            FONT = new FontCssMetaData<Labeled>(Font.getDefault()) {
                public boolean isSettable(final Labeled labeled) {
                    return labeled.font == null || !labeled.font.isBound();
                }
                
                public StyleableProperty<Font> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<Font>)(StyleableProperty)labeled.fontProperty();
                }
            };
            ALIGNMENT = new CssMetaData<Labeled, Pos>((StyleConverter)new EnumConverter(Pos.class), Pos.CENTER_LEFT) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.alignment == null || !labeled.alignment.isBound();
                }
                
                @Override
                public StyleableProperty<Pos> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<Pos>)(StyleableProperty)labeled.alignmentProperty();
                }
                
                @Override
                public Pos getInitialValue(final Labeled labeled) {
                    return labeled.getInitialAlignment();
                }
            };
            TEXT_ALIGNMENT = new CssMetaData<Labeled, TextAlignment>((StyleConverter)new EnumConverter(TextAlignment.class), TextAlignment.LEFT) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.textAlignment == null || !labeled.textAlignment.isBound();
                }
                
                @Override
                public StyleableProperty<TextAlignment> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<TextAlignment>)(StyleableProperty)labeled.textAlignmentProperty();
                }
            };
            TEXT_FILL = new CssMetaData<Labeled, Paint>((StyleConverter)PaintConverter.getInstance(), (Paint)Color.BLACK) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.textFill == null || !labeled.textFill.isBound();
                }
                
                @Override
                public StyleableProperty<Paint> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<Paint>)(StyleableProperty)labeled.textFillProperty();
                }
            };
            TEXT_OVERRUN = new CssMetaData<Labeled, OverrunStyle>((StyleConverter)new EnumConverter(OverrunStyle.class), OverrunStyle.ELLIPSIS) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.textOverrun == null || !labeled.textOverrun.isBound();
                }
                
                @Override
                public StyleableProperty<OverrunStyle> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<OverrunStyle>)(StyleableProperty)labeled.textOverrunProperty();
                }
            };
            ELLIPSIS_STRING = new CssMetaData<Labeled, String>((StyleConverter)StringConverter.getInstance(), "...") {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.ellipsisString == null || !labeled.ellipsisString.isBound();
                }
                
                @Override
                public StyleableProperty<String> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<String>)labeled.ellipsisStringProperty();
                }
            };
            WRAP_TEXT = new CssMetaData<Labeled, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.valueOf(false)) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.wrapText == null || !labeled.wrapText.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<Boolean>)labeled.wrapTextProperty();
                }
            };
            GRAPHIC = new CssMetaData<Labeled, String>((StyleConverter)StringConverter.getInstance()) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.graphic == null || !labeled.graphic.isBound();
                }
                
                @Override
                public StyleableProperty<String> getStyleableProperty(final Labeled labeled) {
                    return labeled.imageUrlProperty();
                }
            };
            UNDERLINE = new CssMetaData<Labeled, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.underline == null || !labeled.underline.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<Boolean>)labeled.underlineProperty();
                }
            };
            LINE_SPACING = new CssMetaData<Labeled, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.lineSpacing == null || !labeled.lineSpacing.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<Number>)labeled.lineSpacingProperty();
                }
            };
            CONTENT_DISPLAY = new CssMetaData<Labeled, ContentDisplay>((StyleConverter)new EnumConverter(ContentDisplay.class), ContentDisplay.LEFT) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.contentDisplay == null || !labeled.contentDisplay.isBound();
                }
                
                @Override
                public StyleableProperty<ContentDisplay> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<ContentDisplay>)(StyleableProperty)labeled.contentDisplayProperty();
                }
            };
            LABEL_PADDING = new CssMetaData<Labeled, Insets>((StyleConverter)InsetsConverter.getInstance(), Insets.EMPTY) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.labelPadding == null || !labeled.labelPadding.isBound();
                }
                
                @Override
                public StyleableProperty<Insets> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<Insets>)(StyleableProperty)labeled.labelPaddingPropertyImpl();
                }
            };
            GRAPHIC_TEXT_GAP = new CssMetaData<Labeled, Number>((StyleConverter)SizeConverter.getInstance(), (Number)4.0) {
                @Override
                public boolean isSettable(final Labeled labeled) {
                    return labeled.graphicTextGap == null || !labeled.graphicTextGap.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Labeled labeled) {
                    return (StyleableProperty<Number>)labeled.graphicTextGapProperty();
                }
            };
            final ArrayList<Object> list = new ArrayList<Object>(Control.getClassCssMetaData());
            Collections.addAll(list, StyleableProperties.FONT, StyleableProperties.ALIGNMENT, StyleableProperties.TEXT_ALIGNMENT, StyleableProperties.TEXT_FILL, StyleableProperties.TEXT_OVERRUN, StyleableProperties.ELLIPSIS_STRING, StyleableProperties.WRAP_TEXT, StyleableProperties.GRAPHIC, StyleableProperties.UNDERLINE, StyleableProperties.LINE_SPACING, StyleableProperties.CONTENT_DISPLAY, StyleableProperties.LABEL_PADDING, StyleableProperties.GRAPHIC_TEXT_GAP);
            STYLEABLES = Collections.unmodifiableList((List<? extends CssMetaData<? extends Styleable, ?>>)list);
        }
    }
}
