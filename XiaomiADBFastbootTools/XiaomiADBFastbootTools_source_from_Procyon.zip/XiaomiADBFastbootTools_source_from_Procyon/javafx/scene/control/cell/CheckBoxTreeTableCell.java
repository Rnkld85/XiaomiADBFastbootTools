// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.geometry.Pos;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.property.Property;
import javafx.beans.property.BooleanProperty;
import javafx.scene.Node;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.TreeTableColumn;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TreeTableCell;

public class CheckBoxTreeTableCell<S, T> extends TreeTableCell<S, T>
{
    private final CheckBox checkBox;
    private boolean showLabel;
    private ObservableValue<Boolean> booleanProperty;
    private ObjectProperty<StringConverter<T>> converter;
    private ObjectProperty<Callback<Integer, ObservableValue<Boolean>>> selectedStateCallback;
    
    public static <S> Callback<TreeTableColumn<S, Boolean>, TreeTableCell<S, Boolean>> forTreeTableColumn(final TreeTableColumn<S, Boolean> treeTableColumn) {
        return forTreeTableColumn(null, (StringConverter<Boolean>)null);
    }
    
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final Callback<Integer, ObservableValue<Boolean>> callback) {
        return forTreeTableColumn(callback, (StringConverter<T>)null);
    }
    
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final Callback<Integer, ObservableValue<Boolean>> callback, final boolean b) {
        return forTreeTableColumn(callback, b ? CellUtils.defaultStringConverter() : null);
    }
    
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final Callback<Integer, ObservableValue<Boolean>> callback, final StringConverter<T> stringConverter) {
        return (Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>)(p2 -> new CheckBoxTreeTableCell(callback, (StringConverter<Object>)stringConverter));
    }
    
    public CheckBoxTreeTableCell() {
        this(null, (StringConverter)null);
    }
    
    public CheckBoxTreeTableCell(final Callback<Integer, ObservableValue<Boolean>> callback) {
        this(callback, null);
    }
    
    public CheckBoxTreeTableCell(final Callback<Integer, ObservableValue<Boolean>> selectedStateCallback, final StringConverter<T> converter) {
        this.converter = new SimpleObjectProperty<StringConverter<T>>((Object)this, "converter") {
            @Override
            protected void invalidated() {
                CheckBoxTreeTableCell.this.updateShowLabel();
            }
        };
        this.selectedStateCallback = new SimpleObjectProperty<Callback<Integer, ObservableValue<Boolean>>>(this, "selectedStateCallback");
        this.getStyleClass().add("check-box-tree-table-cell");
        this.checkBox = new CheckBox();
        this.setGraphic(null);
        this.setSelectedStateCallback(selectedStateCallback);
        this.setConverter(converter);
    }
    
    public final ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    public final ObjectProperty<Callback<Integer, ObservableValue<Boolean>>> selectedStateCallbackProperty() {
        return this.selectedStateCallback;
    }
    
    public final void setSelectedStateCallback(final Callback<Integer, ObservableValue<Boolean>> callback) {
        this.selectedStateCallbackProperty().set(callback);
    }
    
    public final Callback<Integer, ObservableValue<Boolean>> getSelectedStateCallback() {
        return this.selectedStateCallbackProperty().get();
    }
    
    public void updateItem(final T t, final boolean b) {
        super.updateItem((T)t, b);
        if (b) {
            this.setText(null);
            this.setGraphic(null);
        }
        else {
            final StringConverter<T> converter = this.getConverter();
            if (this.showLabel) {
                this.setText(converter.toString(t));
            }
            this.setGraphic(this.checkBox);
            if (this.booleanProperty instanceof BooleanProperty) {
                this.checkBox.selectedProperty().unbindBidirectional((Property<Boolean>)this.booleanProperty);
            }
            final ObservableValue<?> selectedProperty = this.getSelectedProperty();
            if (selectedProperty instanceof BooleanProperty) {
                this.booleanProperty = (ObservableValue<Boolean>)selectedProperty;
                this.checkBox.selectedProperty().bindBidirectional((Property<Boolean>)this.booleanProperty);
            }
            this.checkBox.disableProperty().bind(Bindings.not(this.getTreeTableView().editableProperty().and(this.getTableColumn().editableProperty()).and(this.editableProperty())));
        }
    }
    
    private void updateShowLabel() {
        this.showLabel = (this.converter != null);
        this.checkBox.setAlignment(this.showLabel ? Pos.CENTER_LEFT : Pos.CENTER);
    }
    
    private ObservableValue<?> getSelectedProperty() {
        return (ObservableValue<?>)((this.getSelectedStateCallback() != null) ? ((ObservableValue<Boolean>)this.getSelectedStateCallback().call(this.getIndex())) : this.getTableColumn().getCellObservableValue(this.getIndex()));
    }
}
