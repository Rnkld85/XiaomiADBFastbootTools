// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.beans.property.Property;
import javafx.beans.property.BooleanProperty;
import javafx.scene.Node;
import javafx.scene.control.ContentDisplay;
import javafx.geometry.Pos;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListCell;

public class CheckBoxListCell<T> extends ListCell<T>
{
    private final CheckBox checkBox;
    private ObservableValue<Boolean> booleanProperty;
    private ObjectProperty<StringConverter<T>> converter;
    private ObjectProperty<Callback<T, ObservableValue<Boolean>>> selectedStateCallback;
    
    public static <T> Callback<ListView<T>, ListCell<T>> forListView(final Callback<T, ObservableValue<Boolean>> callback) {
        return forListView(callback, CellUtils.defaultStringConverter());
    }
    
    public static <T> Callback<ListView<T>, ListCell<T>> forListView(final Callback<T, ObservableValue<Boolean>> callback, final StringConverter<T> stringConverter) {
        return (Callback<ListView<T>, ListCell<T>>)(p2 -> new CheckBoxListCell((Callback<Object, ObservableValue<Boolean>>)callback, (StringConverter<Object>)stringConverter));
    }
    
    public CheckBoxListCell() {
        this((Callback)null);
    }
    
    public CheckBoxListCell(final Callback<T, ObservableValue<Boolean>> callback) {
        this((Callback<Object, ObservableValue<Boolean>>)callback, CellUtils.defaultStringConverter());
    }
    
    public CheckBoxListCell(final Callback<T, ObservableValue<Boolean>> selectedStateCallback, final StringConverter<T> converter) {
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter");
        this.selectedStateCallback = new SimpleObjectProperty<Callback<T, ObservableValue<Boolean>>>(this, "selectedStateCallback");
        this.getStyleClass().add("check-box-list-cell");
        this.setSelectedStateCallback(selectedStateCallback);
        this.setConverter(converter);
        this.checkBox = new CheckBox();
        this.setAlignment(Pos.CENTER_LEFT);
        this.setContentDisplay(ContentDisplay.LEFT);
        this.setGraphic(null);
    }
    
    public final ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    public final ObjectProperty<Callback<T, ObservableValue<Boolean>>> selectedStateCallbackProperty() {
        return this.selectedStateCallback;
    }
    
    public final void setSelectedStateCallback(final Callback<T, ObservableValue<Boolean>> callback) {
        this.selectedStateCallbackProperty().set(callback);
    }
    
    public final Callback<T, ObservableValue<Boolean>> getSelectedStateCallback() {
        return this.selectedStateCallbackProperty().get();
    }
    
    public void updateItem(final T t, final boolean b) {
        super.updateItem(t, b);
        if (!b) {
            final StringConverter<T> converter = this.getConverter();
            final Callback<T, ObservableValue<Boolean>> selectedStateCallback = this.getSelectedStateCallback();
            if (selectedStateCallback == null) {
                throw new NullPointerException("The CheckBoxListCell selectedStateCallbackProperty can not be null");
            }
            this.setGraphic(this.checkBox);
            this.setText((converter != null) ? converter.toString(t) : ((t == null) ? "" : t.toString()));
            if (this.booleanProperty != null) {
                this.checkBox.selectedProperty().unbindBidirectional((Property<Boolean>)this.booleanProperty);
            }
            this.booleanProperty = selectedStateCallback.call(t);
            if (this.booleanProperty != null) {
                this.checkBox.selectedProperty().bindBidirectional((Property<Boolean>)this.booleanProperty);
            }
        }
        else {
            this.setGraphic(null);
            this.setText(null);
        }
    }
}
