// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.event.ActionEvent;
import javafx.scene.control.Skin;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.ListView;
import javafx.scene.control.skin.ComboBoxListViewSkin;
import javafx.beans.Observable;
import javafx.beans.InvalidationListener;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextInputControl;
import javafx.scene.input.KeyCode;
import javafx.scene.control.TextField;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableList;
import javafx.scene.layout.HBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.Node;
import javafx.scene.control.Cell;
import javafx.scene.control.TreeItem;
import javafx.util.StringConverter;

class CellUtils
{
    static int TREE_VIEW_HBOX_GRAPHIC_PADDING;
    private static final StringConverter<?> defaultStringConverter;
    private static final StringConverter<?> defaultTreeItemStringConverter;
    
    static <T> StringConverter<T> defaultStringConverter() {
        return (StringConverter<T>)CellUtils.defaultStringConverter;
    }
    
    static <T> StringConverter<TreeItem<T>> defaultTreeItemStringConverter() {
        return (StringConverter<TreeItem<T>>)CellUtils.defaultTreeItemStringConverter;
    }
    
    private static <T> String getItemText(final Cell<T> cell, final StringConverter<T> stringConverter) {
        return (stringConverter == null) ? ((cell.getItem() == null) ? "" : cell.getItem().toString()) : stringConverter.toString(cell.getItem());
    }
    
    static Node getGraphic(final TreeItem<?> treeItem) {
        return (treeItem == null) ? null : treeItem.getGraphic();
    }
    
    static <T> void updateItem(final Cell<T> cell, final StringConverter<T> stringConverter, final ChoiceBox<T> choiceBox) {
        updateItem(cell, stringConverter, null, null, choiceBox);
    }
    
    static <T> void updateItem(final Cell<T> cell, final StringConverter<T> stringConverter, final HBox graphic, final Node graphic2, final ChoiceBox<T> graphic3) {
        if (cell.isEmpty()) {
            cell.setText(null);
            cell.setGraphic(null);
        }
        else if (cell.isEditing()) {
            if (graphic3 != null) {
                graphic3.getSelectionModel().select(cell.getItem());
            }
            cell.setText(null);
            if (graphic2 != null) {
                graphic.getChildren().setAll(graphic2, graphic3);
                cell.setGraphic(graphic);
            }
            else {
                cell.setGraphic(graphic3);
            }
        }
        else {
            cell.setText(getItemText(cell, stringConverter));
            cell.setGraphic(graphic2);
        }
    }
    
    static <T> ChoiceBox<T> createChoiceBox(final Cell<T> cell, final ObservableList<T> list, final ObjectProperty<StringConverter<T>> objectProperty) {
        final ChoiceBox<T> choiceBox = new ChoiceBox<T>(list);
        choiceBox.setMaxWidth(Double.MAX_VALUE);
        choiceBox.converterProperty().bind((ObservableValue<?>)objectProperty);
        final ChoiceBox choiceBox2;
        choiceBox.showingProperty().addListener(p2 -> {
            if (!choiceBox2.isShowing()) {
                cell.commitEdit((T)choiceBox2.getSelectionModel().getSelectedItem());
            }
            return;
        });
        return choiceBox;
    }
    
    static <T> void updateItem(final Cell<T> cell, final StringConverter<T> stringConverter, final TextField textField) {
        updateItem(cell, stringConverter, null, null, textField);
    }
    
    static <T> void updateItem(final Cell<T> cell, final StringConverter<T> stringConverter, final HBox graphic, final Node graphic2, final TextField graphic3) {
        if (cell.isEmpty()) {
            cell.setText(null);
            cell.setGraphic(null);
        }
        else if (cell.isEditing()) {
            if (graphic3 != null) {
                graphic3.setText(getItemText(cell, stringConverter));
            }
            cell.setText(null);
            if (graphic2 != null) {
                graphic.getChildren().setAll(graphic2, graphic3);
                cell.setGraphic(graphic);
            }
            else {
                cell.setGraphic(graphic3);
            }
        }
        else {
            cell.setText(getItemText(cell, stringConverter));
            cell.setGraphic(graphic2);
        }
    }
    
    static <T> void startEdit(final Cell<T> cell, final StringConverter<T> stringConverter, final HBox graphic, final Node node, final TextField graphic2) {
        if (graphic2 != null) {
            graphic2.setText(getItemText(cell, stringConverter));
        }
        cell.setText(null);
        if (node != null) {
            graphic.getChildren().setAll(node, graphic2);
            cell.setGraphic(graphic);
        }
        else {
            cell.setGraphic(graphic2);
        }
        graphic2.selectAll();
        graphic2.requestFocus();
    }
    
    static <T> void cancelEdit(final Cell<T> cell, final StringConverter<T> stringConverter, final Node graphic) {
        cell.setText(getItemText(cell, stringConverter));
        cell.setGraphic(graphic);
    }
    
    static <T> TextField createTextField(final Cell<T> cell, final StringConverter<T> stringConverter) {
        final TextField textField = new TextField(getItemText(cell, stringConverter));
        final TextInputControl textInputControl;
        textField.setOnAction(actionEvent -> {
            if (stringConverter == null) {
                throw new IllegalStateException("Attempting to convert text input into Object, but provided StringConverter is null. Be sure to set a StringConverter in your cell factory.");
            }
            else {
                cell.commitEdit(stringConverter.fromString(textInputControl.getText()));
                actionEvent.consume();
                return;
            }
        });
        textField.setOnKeyReleased(keyEvent -> {
            if (keyEvent.getCode() == KeyCode.ESCAPE) {
                cell.cancelEdit();
                keyEvent.consume();
            }
            return;
        });
        return textField;
    }
    
    static <T> void updateItem(final Cell<T> cell, final StringConverter<T> stringConverter, final ComboBox<T> comboBox) {
        updateItem(cell, stringConverter, null, null, comboBox);
    }
    
    static <T> void updateItem(final Cell<T> cell, final StringConverter<T> stringConverter, final HBox graphic, final Node graphic2, final ComboBox<T> graphic3) {
        if (cell.isEmpty()) {
            cell.setText(null);
            cell.setGraphic(null);
        }
        else if (cell.isEditing()) {
            if (graphic3 != null) {
                graphic3.getSelectionModel().select(cell.getItem());
            }
            cell.setText(null);
            if (graphic2 != null) {
                graphic.getChildren().setAll(graphic2, graphic3);
                cell.setGraphic(graphic);
            }
            else {
                cell.setGraphic(graphic3);
            }
        }
        else {
            cell.setText(getItemText(cell, stringConverter));
            cell.setGraphic(graphic2);
        }
    }
    
    static <T> ComboBox<T> createComboBox(final Cell<T> cell, final ObservableList<T> list, final ObjectProperty<StringConverter<T>> objectProperty) {
        final ComboBox<T> comboBox = new ComboBox<T>(list);
        comboBox.converterProperty().bind((ObservableValue<?>)objectProperty);
        comboBox.setMaxWidth(Double.MAX_VALUE);
        final ComboBox<T> comboBox2;
        comboBox.addEventFilter(KeyEvent.KEY_RELEASED, keyEvent -> {
            if (keyEvent.getCode() == KeyCode.ENTER) {
                tryComboBoxCommit(comboBox2, cell);
            }
            else if (keyEvent.getCode() == KeyCode.ESCAPE) {
                cell.cancelEdit();
            }
            return;
        });
        final ComboBox<T> comboBox3;
        comboBox.getEditor().focusedProperty().addListener(p2 -> {
            if (!comboBox3.isFocused()) {
                tryComboBoxCommit(comboBox3, cell);
            }
            return;
        });
        if (!listenToComboBoxSkin(comboBox, cell)) {
            comboBox.skinProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(final Observable observable) {
                    if (listenToComboBoxSkin(comboBox, (Cell<Object>)cell)) {
                        comboBox.skinProperty().removeListener(this);
                    }
                }
            });
        }
        return comboBox;
    }
    
    private static <T> void tryComboBoxCommit(final ComboBox<T> comboBox, final Cell<T> cell) {
        final StringConverter<T> converter = comboBox.getConverter();
        if (comboBox.isEditable() && converter != null) {
            cell.commitEdit(converter.fromString(comboBox.getEditor().getText()));
        }
        else {
            cell.commitEdit(comboBox.getValue());
        }
    }
    
    private static <T> boolean listenToComboBoxSkin(final ComboBox<T> comboBox, final Cell<T> cell) {
        final Skin<?> skin = comboBox.getSkin();
        if (skin != null && skin instanceof ComboBoxListViewSkin) {
            final Node popupContent = ((ComboBoxListViewSkin<?>)skin).getPopupContent();
            if (popupContent != null && popupContent instanceof ListView) {
                popupContent.addEventHandler(MouseEvent.MOUSE_RELEASED, p2 -> cell.commitEdit(comboBox.getValue()));
                return true;
            }
        }
        return false;
    }
    
    static {
        CellUtils.TREE_VIEW_HBOX_GRAPHIC_PADDING = 3;
        defaultStringConverter = new StringConverter<Object>() {
            @Override
            public String toString(final Object o) {
                return (o == null) ? null : o.toString();
            }
            
            @Override
            public Object fromString(final String s) {
                return s;
            }
        };
        defaultTreeItemStringConverter = new StringConverter<TreeItem<?>>() {
            @Override
            public String toString(final TreeItem<?> treeItem) {
                return (treeItem == null || treeItem.getValue() == null) ? "" : treeItem.getValue().toString();
            }
            
            @Override
            public TreeItem<?> fromString(final String s) {
                return new TreeItem<Object>(s);
            }
        };
    }
}
