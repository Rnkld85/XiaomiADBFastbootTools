// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.scene.control.TreeItem;
import javafx.scene.Node;
import javafx.scene.control.Cell;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeView;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.scene.layout.HBox;
import javafx.scene.control.ChoiceBox;
import javafx.collections.ObservableList;

public class ChoiceBoxTreeCell<T> extends DefaultTreeCell<T>
{
    private final ObservableList<T> items;
    private ChoiceBox<T> choiceBox;
    private HBox hbox;
    private ObjectProperty<StringConverter<T>> converter;
    
    @SafeVarargs
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final T... array) {
        return forTreeView((ObservableList<T>)FXCollections.observableArrayList((T[])array));
    }
    
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final ObservableList<T> list) {
        return forTreeView(null, list);
    }
    
    @SafeVarargs
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final StringConverter<T> stringConverter, final T... array) {
        return forTreeView(stringConverter, (ObservableList<T>)FXCollections.observableArrayList((T[])array));
    }
    
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final StringConverter<T> stringConverter, final ObservableList<T> list) {
        return (Callback<TreeView<T>, TreeCell<T>>)(p2 -> new ChoiceBoxTreeCell((StringConverter<Object>)stringConverter, (ObservableList<Object>)list));
    }
    
    public ChoiceBoxTreeCell() {
        this(FXCollections.observableArrayList());
    }
    
    @SafeVarargs
    public ChoiceBoxTreeCell(final T... array) {
        this(FXCollections.observableArrayList(array));
    }
    
    @SafeVarargs
    public ChoiceBoxTreeCell(final StringConverter<T> stringConverter, final T... array) {
        this(stringConverter, FXCollections.observableArrayList(array));
    }
    
    public ChoiceBoxTreeCell(final ObservableList<T> list) {
        this(null, list);
    }
    
    public ChoiceBoxTreeCell(final StringConverter<T> stringConverter, final ObservableList<T> items) {
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter");
        this.getStyleClass().add("choice-box-tree-cell");
        this.items = items;
        this.setConverter((stringConverter != null) ? stringConverter : CellUtils.defaultStringConverter());
    }
    
    public final ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    public ObservableList<T> getItems() {
        return this.items;
    }
    
    @Override
    public void startEdit() {
        if (!this.isEditable() || !this.getTreeView().isEditable()) {
            return;
        }
        final TreeItem<T> treeItem = this.getTreeItem();
        if (treeItem == null) {
            return;
        }
        if (this.choiceBox == null) {
            this.choiceBox = CellUtils.createChoiceBox(this, this.items, this.converterProperty());
        }
        if (this.hbox == null) {
            this.hbox = new HBox(CellUtils.TREE_VIEW_HBOX_GRAPHIC_PADDING);
        }
        this.choiceBox.getSelectionModel().select(treeItem.getValue());
        super.startEdit();
        if (this.isEditing()) {
            this.setText(null);
            final Node treeItemGraphic = this.getTreeItemGraphic();
            if (treeItemGraphic != null) {
                this.hbox.getChildren().setAll(treeItemGraphic, this.choiceBox);
                this.setGraphic(this.hbox);
            }
            else {
                this.setGraphic(this.choiceBox);
            }
        }
    }
    
    @Override
    public void cancelEdit() {
        super.cancelEdit();
        this.setText(this.getConverter().toString(this.getItem()));
        this.setGraphic(null);
    }
    
    @Override
    public void updateItem(final T t, final boolean b) {
        super.updateItem(t, b);
        CellUtils.updateItem(this, this.getConverter(), this.hbox, this.getTreeItemGraphic(), this.choiceBox);
    }
    
    private Node getTreeItemGraphic() {
        final TreeItem<T> treeItem = this.getTreeItem();
        return (treeItem == null) ? null : treeItem.getGraphic();
    }
}
