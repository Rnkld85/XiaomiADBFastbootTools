// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.ReadOnlyDoubleWrapper;
import javafx.beans.property.ReadOnlyLongWrapper;
import javafx.beans.property.ReadOnlyFloatWrapper;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.NamedArg;
import javafx.beans.value.ObservableValue;
import java.util.Map;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;

public class MapValueFactory<T> implements Callback<TableColumn.CellDataFeatures<Map, T>, ObservableValue<T>>
{
    private final Object key;
    
    public MapValueFactory(@NamedArg("key") final Object key) {
        this.key = key;
    }
    
    @Override
    public ObservableValue<T> call(final TableColumn.CellDataFeatures<Map, T> cellDataFeatures) {
        final Object value = cellDataFeatures.getValue().get(this.key);
        if (value instanceof ObservableValue) {
            return (ObservableValue<T>)value;
        }
        if (value instanceof Boolean) {
            return (ObservableValue<T>)new ReadOnlyBooleanWrapper((boolean)value);
        }
        if (value instanceof Integer) {
            return (ObservableValue<T>)new ReadOnlyIntegerWrapper((int)value);
        }
        if (value instanceof Float) {
            return (ObservableValue<T>)new ReadOnlyFloatWrapper((float)value);
        }
        if (value instanceof Long) {
            return (ObservableValue<T>)new ReadOnlyLongWrapper((long)value);
        }
        if (value instanceof Double) {
            return (ObservableValue<T>)new ReadOnlyDoubleWrapper((double)value);
        }
        if (value instanceof String) {
            return (ObservableValue<T>)new ReadOnlyStringWrapper((String)value);
        }
        return new ReadOnlyObjectWrapper<T>((T)value);
    }
}
