// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TableCell;

public class ProgressBarTableCell<S> extends TableCell<S, Double>
{
    private final ProgressBar progressBar;
    private ObservableValue<Double> observable;
    
    public static <S> Callback<TableColumn<S, Double>, TableCell<S, Double>> forTableColumn() {
        return (Callback<TableColumn<S, Double>, TableCell<S, Double>>)(p0 -> new ProgressBarTableCell());
    }
    
    public ProgressBarTableCell() {
        this.getStyleClass().add("progress-bar-table-cell");
        (this.progressBar = new ProgressBar()).setMaxWidth(Double.MAX_VALUE);
    }
    
    public void updateItem(final Double n, final boolean b) {
        super.updateItem((T)n, b);
        if (b) {
            this.setGraphic(null);
        }
        else {
            this.progressBar.progressProperty().unbind();
            final TableColumn<S, Double> tableColumn = this.getTableColumn();
            this.observable = ((tableColumn == null) ? null : tableColumn.getCellObservableValue(this.getIndex()));
            if (this.observable != null) {
                this.progressBar.progressProperty().bind(this.observable);
            }
            else if (n != null) {
                this.progressBar.setProgress(n);
            }
            this.setGraphic(this.progressBar);
        }
    }
}
