// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.scene.control.Logging;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.NamedArg;
import com.sun.javafx.property.PropertyReference;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TreeTableColumn;
import javafx.util.Callback;

public class TreeItemPropertyValueFactory<S, T> implements Callback<TreeTableColumn.CellDataFeatures<S, T>, ObservableValue<T>>
{
    private final String property;
    private Class<?> columnClass;
    private String previousProperty;
    private PropertyReference<T> propertyRef;
    
    public TreeItemPropertyValueFactory(@NamedArg("property") final String property) {
        this.property = property;
    }
    
    @Override
    public ObservableValue<T> call(final TreeTableColumn.CellDataFeatures<S, T> cellDataFeatures) {
        return this.getCellDataReflectively(cellDataFeatures.getValue().getValue());
    }
    
    public final String getProperty() {
        return this.property;
    }
    
    private ObservableValue<T> getCellDataReflectively(final S n) {
        if (this.getProperty() == null || this.getProperty().isEmpty() || n == null) {
            return null;
        }
        try {
            if (this.columnClass == null || this.previousProperty == null || !this.columnClass.equals(n.getClass()) || !this.previousProperty.equals(this.getProperty())) {
                this.columnClass = n.getClass();
                this.previousProperty = this.getProperty();
                this.propertyRef = new PropertyReference<T>(n.getClass(), this.getProperty());
            }
            if (this.propertyRef != null) {
                return this.propertyRef.getProperty(n);
            }
        }
        catch (RuntimeException ex) {
            try {
                return new ReadOnlyObjectWrapper<T>(this.propertyRef.get(n));
            }
            catch (RuntimeException ex2) {
                final PlatformLogger controlsLogger = Logging.getControlsLogger();
                if (controlsLogger.isLoggable(PlatformLogger.Level.WARNING)) {
                    controlsLogger.warning(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/control/cell/TreeItemPropertyValueFactory;Ljava/lang/Class;)Ljava/lang/String;, this.getProperty(), this, n.getClass()), (Throwable)ex);
                }
                this.propertyRef = null;
            }
        }
        return null;
    }
}
