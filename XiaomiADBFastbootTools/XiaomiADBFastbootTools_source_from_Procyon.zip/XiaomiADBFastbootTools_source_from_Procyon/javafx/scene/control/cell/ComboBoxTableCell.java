// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.scene.layout.HBox;
import javafx.scene.Node;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Cell;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;
import javafx.beans.property.BooleanProperty;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.scene.control.ComboBox;
import javafx.collections.ObservableList;
import javafx.scene.control.TableCell;

public class ComboBoxTableCell<S, T> extends TableCell<S, T>
{
    private final ObservableList<T> items;
    private ComboBox<T> comboBox;
    private ObjectProperty<StringConverter<T>> converter;
    private BooleanProperty comboBoxEditable;
    
    @SafeVarargs
    public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(final T... array) {
        return forTableColumn((StringConverter<T>)null, array);
    }
    
    @SafeVarargs
    public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(final StringConverter<T> stringConverter, final T... array) {
        return forTableColumn(stringConverter, (ObservableList<T>)FXCollections.observableArrayList((T[])array));
    }
    
    public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(final ObservableList<T> list) {
        return forTableColumn(null, list);
    }
    
    public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(final StringConverter<T> stringConverter, final ObservableList<T> list) {
        return (Callback<TableColumn<S, T>, TableCell<S, T>>)(p2 -> new ComboBoxTableCell((StringConverter<Object>)stringConverter, (ObservableList<Object>)list));
    }
    
    public ComboBoxTableCell() {
        this(FXCollections.observableArrayList());
    }
    
    @SafeVarargs
    public ComboBoxTableCell(final T... array) {
        this(FXCollections.observableArrayList(array));
    }
    
    @SafeVarargs
    public ComboBoxTableCell(final StringConverter<T> stringConverter, final T... array) {
        this(stringConverter, FXCollections.observableArrayList(array));
    }
    
    public ComboBoxTableCell(final ObservableList<T> list) {
        this(null, list);
    }
    
    public ComboBoxTableCell(final StringConverter<T> stringConverter, final ObservableList<T> items) {
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter");
        this.comboBoxEditable = new SimpleBooleanProperty(this, "comboBoxEditable");
        this.getStyleClass().add("combo-box-table-cell");
        this.items = items;
        this.setConverter((stringConverter != null) ? stringConverter : CellUtils.defaultStringConverter());
    }
    
    public final ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    public final BooleanProperty comboBoxEditableProperty() {
        return this.comboBoxEditable;
    }
    
    public final void setComboBoxEditable(final boolean b) {
        this.comboBoxEditableProperty().set(b);
    }
    
    public final boolean isComboBoxEditable() {
        return this.comboBoxEditableProperty().get();
    }
    
    public ObservableList<T> getItems() {
        return this.items;
    }
    
    @Override
    public void startEdit() {
        if (!this.isEditable() || !this.getTableView().isEditable() || !this.getTableColumn().isEditable()) {
            return;
        }
        if (this.comboBox == null) {
            this.comboBox = CellUtils.createComboBox((Cell<T>)this, this.items, this.converterProperty());
            this.comboBox.editableProperty().bind(this.comboBoxEditableProperty());
        }
        this.comboBox.getSelectionModel().select((T)this.getItem());
        super.startEdit();
        this.setText(null);
        this.setGraphic(this.comboBox);
    }
    
    @Override
    public void cancelEdit() {
        super.cancelEdit();
        this.setText(this.getConverter().toString((T)this.getItem()));
        this.setGraphic(null);
    }
    
    public void updateItem(final T t, final boolean b) {
        super.updateItem((T)t, b);
        CellUtils.updateItem((Cell<T>)this, this.getConverter(), null, null, this.comboBox);
    }
}
