// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.scene.Node;
import javafx.scene.control.TreeItem;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Cell;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeView;
import javafx.util.Callback;
import javafx.beans.property.BooleanProperty;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.scene.layout.HBox;
import javafx.scene.control.ComboBox;
import javafx.collections.ObservableList;

public class ComboBoxTreeCell<T> extends DefaultTreeCell<T>
{
    private final ObservableList<T> items;
    private ComboBox<T> comboBox;
    private HBox hbox;
    private ObjectProperty<StringConverter<T>> converter;
    private BooleanProperty comboBoxEditable;
    
    @SafeVarargs
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final T... array) {
        return forTreeView((ObservableList<T>)FXCollections.observableArrayList((T[])array));
    }
    
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final ObservableList<T> list) {
        return forTreeView(null, list);
    }
    
    @SafeVarargs
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final StringConverter<T> stringConverter, final T... array) {
        return forTreeView(stringConverter, (ObservableList<T>)FXCollections.observableArrayList((T[])array));
    }
    
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final StringConverter<T> stringConverter, final ObservableList<T> list) {
        return (Callback<TreeView<T>, TreeCell<T>>)(p2 -> new ComboBoxTreeCell((StringConverter<Object>)stringConverter, (ObservableList<Object>)list));
    }
    
    public ComboBoxTreeCell() {
        this(FXCollections.observableArrayList());
    }
    
    @SafeVarargs
    public ComboBoxTreeCell(final T... array) {
        this(FXCollections.observableArrayList(array));
    }
    
    @SafeVarargs
    public ComboBoxTreeCell(final StringConverter<T> stringConverter, final T... array) {
        this(stringConverter, FXCollections.observableArrayList(array));
    }
    
    public ComboBoxTreeCell(final ObservableList<T> list) {
        this(null, list);
    }
    
    public ComboBoxTreeCell(final StringConverter<T> stringConverter, final ObservableList<T> items) {
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter");
        this.comboBoxEditable = new SimpleBooleanProperty(this, "comboBoxEditable");
        this.getStyleClass().add("combo-box-tree-cell");
        this.items = items;
        this.setConverter((stringConverter != null) ? stringConverter : CellUtils.defaultStringConverter());
    }
    
    public final ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    public final BooleanProperty comboBoxEditableProperty() {
        return this.comboBoxEditable;
    }
    
    public final void setComboBoxEditable(final boolean b) {
        this.comboBoxEditableProperty().set(b);
    }
    
    public final boolean isComboBoxEditable() {
        return this.comboBoxEditableProperty().get();
    }
    
    public ObservableList<T> getItems() {
        return this.items;
    }
    
    @Override
    public void startEdit() {
        if (!this.isEditable() || !this.getTreeView().isEditable()) {
            return;
        }
        final TreeItem<T> treeItem = this.getTreeItem();
        if (treeItem == null) {
            return;
        }
        if (this.comboBox == null) {
            this.comboBox = CellUtils.createComboBox(this, this.items, this.converterProperty());
            this.comboBox.editableProperty().bind(this.comboBoxEditableProperty());
        }
        if (this.hbox == null) {
            this.hbox = new HBox(CellUtils.TREE_VIEW_HBOX_GRAPHIC_PADDING);
        }
        this.comboBox.getSelectionModel().select(treeItem.getValue());
        super.startEdit();
        if (this.isEditing()) {
            this.setText(null);
            final Node graphic = CellUtils.getGraphic(treeItem);
            if (graphic != null) {
                this.hbox.getChildren().setAll(graphic, this.comboBox);
                this.setGraphic(this.hbox);
            }
            else {
                this.setGraphic(this.comboBox);
            }
        }
    }
    
    @Override
    public void cancelEdit() {
        super.cancelEdit();
        this.setText(this.getConverter().toString(this.getItem()));
        this.setGraphic(null);
    }
    
    @Override
    public void updateItem(final T t, final boolean b) {
        super.updateItem(t, b);
        CellUtils.updateItem(this, this.getConverter(), this.hbox, CellUtils.getGraphic(this.getTreeItem()), this.comboBox);
    }
}
