// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.scene.Node;
import javafx.scene.control.TreeTableColumn;
import javafx.util.Callback;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TreeTableCell;

public class ProgressBarTreeTableCell<S> extends TreeTableCell<S, Double>
{
    private final ProgressBar progressBar;
    private ObservableValue<Double> observable;
    
    public static <S> Callback<TreeTableColumn<S, Double>, TreeTableCell<S, Double>> forTreeTableColumn() {
        return (Callback<TreeTableColumn<S, Double>, TreeTableCell<S, Double>>)(p0 -> new ProgressBarTreeTableCell());
    }
    
    public ProgressBarTreeTableCell() {
        this.getStyleClass().add("progress-bar-tree-table-cell");
        (this.progressBar = new ProgressBar()).setMaxWidth(Double.MAX_VALUE);
    }
    
    public void updateItem(final Double n, final boolean b) {
        super.updateItem((T)n, b);
        if (b) {
            this.setGraphic(null);
        }
        else {
            this.progressBar.progressProperty().unbind();
            final TreeTableColumn<S, Double> tableColumn = this.getTableColumn();
            this.observable = ((tableColumn == null) ? null : tableColumn.getCellObservableValue(this.getIndex()));
            if (this.observable != null) {
                this.progressBar.progressProperty().bind(this.observable);
            }
            else if (n != null) {
                this.progressBar.setProgress(n);
            }
            this.setGraphic(this.progressBar);
        }
    }
}
