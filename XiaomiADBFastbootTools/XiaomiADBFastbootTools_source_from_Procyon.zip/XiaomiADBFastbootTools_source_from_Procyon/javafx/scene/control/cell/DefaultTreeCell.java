// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.scene.Node;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.InvalidationListener;
import javafx.scene.control.TreeItem;
import java.lang.ref.WeakReference;
import javafx.scene.layout.HBox;
import javafx.scene.control.TreeCell;

class DefaultTreeCell<T> extends TreeCell<T>
{
    private HBox hbox;
    private WeakReference<TreeItem<T>> treeItemRef;
    private InvalidationListener treeItemGraphicListener;
    private InvalidationListener treeItemListener;
    private WeakInvalidationListener weakTreeItemGraphicListener;
    private WeakInvalidationListener weakTreeItemListener;
    
    public DefaultTreeCell() {
        this.treeItemGraphicListener = (p0 -> this.updateDisplay(this.getItem(), this.isEmpty()));
        this.treeItemListener = new InvalidationListener() {
            @Override
            public void invalidated(final Observable observable) {
                final TreeItem treeItem = (DefaultTreeCell.this.treeItemRef == null) ? null : ((TreeItem)DefaultTreeCell.this.treeItemRef.get());
                if (treeItem != null) {
                    treeItem.graphicProperty().removeListener(DefaultTreeCell.this.weakTreeItemGraphicListener);
                }
                final TreeItem<Object> treeItem2 = DefaultTreeCell.this.getTreeItem();
                if (treeItem2 != null) {
                    treeItem2.graphicProperty().addListener(DefaultTreeCell.this.weakTreeItemGraphicListener);
                    DefaultTreeCell.this.treeItemRef = (WeakReference<TreeItem<T>>)new WeakReference((T)treeItem2);
                }
            }
        };
        this.weakTreeItemGraphicListener = new WeakInvalidationListener(this.treeItemGraphicListener);
        this.weakTreeItemListener = new WeakInvalidationListener(this.treeItemListener);
        this.treeItemProperty().addListener(this.weakTreeItemListener);
        if (this.getTreeItem() != null) {
            this.getTreeItem().graphicProperty().addListener(this.weakTreeItemGraphicListener);
        }
    }
    
    void updateDisplay(final T t, final boolean b) {
        if (t == null || b) {
            this.hbox = null;
            this.setText(null);
            this.setGraphic(null);
        }
        else {
            final TreeItem<T> treeItem = this.getTreeItem();
            if (treeItem != null && treeItem.getGraphic() != null) {
                if (t instanceof Node) {
                    this.setText(null);
                    if (this.hbox == null) {
                        this.hbox = new HBox(3.0);
                    }
                    this.hbox.getChildren().setAll(treeItem.getGraphic(), (Node)t);
                    this.setGraphic(this.hbox);
                }
                else {
                    this.hbox = null;
                    this.setText(t.toString());
                    this.setGraphic(treeItem.getGraphic());
                }
            }
            else {
                this.hbox = null;
                if (t instanceof Node) {
                    this.setText(null);
                    this.setGraphic((Node)t);
                }
                else {
                    this.setText(t.toString());
                    this.setGraphic(null);
                }
            }
        }
    }
    
    public void updateItem(final T t, final boolean b) {
        super.updateItem(t, b);
        this.updateDisplay(t, b);
    }
}
