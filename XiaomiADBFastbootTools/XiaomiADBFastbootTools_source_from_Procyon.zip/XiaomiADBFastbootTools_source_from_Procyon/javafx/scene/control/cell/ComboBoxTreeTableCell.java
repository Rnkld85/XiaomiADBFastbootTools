// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.scene.layout.HBox;
import javafx.scene.Node;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Cell;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.scene.control.TreeTableColumn;
import javafx.util.Callback;
import javafx.beans.property.BooleanProperty;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.scene.control.ComboBox;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeTableCell;

public class ComboBoxTreeTableCell<S, T> extends TreeTableCell<S, T>
{
    private final ObservableList<T> items;
    private ComboBox<T> comboBox;
    private ObjectProperty<StringConverter<T>> converter;
    private BooleanProperty comboBoxEditable;
    
    @SafeVarargs
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final T... array) {
        return forTreeTableColumn((StringConverter<T>)null, array);
    }
    
    @SafeVarargs
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final StringConverter<T> stringConverter, final T... array) {
        return forTreeTableColumn(stringConverter, (ObservableList<T>)FXCollections.observableArrayList((T[])array));
    }
    
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final ObservableList<T> list) {
        return forTreeTableColumn(null, list);
    }
    
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final StringConverter<T> stringConverter, final ObservableList<T> list) {
        return (Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>)(p2 -> new ComboBoxTreeTableCell((StringConverter<Object>)stringConverter, (ObservableList<Object>)list));
    }
    
    public ComboBoxTreeTableCell() {
        this(FXCollections.observableArrayList());
    }
    
    @SafeVarargs
    public ComboBoxTreeTableCell(final T... array) {
        this(FXCollections.observableArrayList(array));
    }
    
    @SafeVarargs
    public ComboBoxTreeTableCell(final StringConverter<T> stringConverter, final T... array) {
        this(stringConverter, FXCollections.observableArrayList(array));
    }
    
    public ComboBoxTreeTableCell(final ObservableList<T> list) {
        this(null, list);
    }
    
    public ComboBoxTreeTableCell(final StringConverter<T> stringConverter, final ObservableList<T> items) {
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter");
        this.comboBoxEditable = new SimpleBooleanProperty(this, "comboBoxEditable");
        this.getStyleClass().add("combo-box-tree-table-cell");
        this.items = items;
        this.setConverter((stringConverter != null) ? stringConverter : CellUtils.defaultStringConverter());
    }
    
    public final ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    public final BooleanProperty comboBoxEditableProperty() {
        return this.comboBoxEditable;
    }
    
    public final void setComboBoxEditable(final boolean b) {
        this.comboBoxEditableProperty().set(b);
    }
    
    public final boolean isComboBoxEditable() {
        return this.comboBoxEditableProperty().get();
    }
    
    public ObservableList<T> getItems() {
        return this.items;
    }
    
    @Override
    public void startEdit() {
        if (!this.isEditable() || !this.getTreeTableView().isEditable() || !this.getTableColumn().isEditable()) {
            return;
        }
        if (this.comboBox == null) {
            this.comboBox = CellUtils.createComboBox((Cell<T>)this, this.items, this.converterProperty());
            this.comboBox.editableProperty().bind(this.comboBoxEditableProperty());
        }
        this.comboBox.getSelectionModel().select((T)this.getItem());
        super.startEdit();
        this.setText(null);
        this.setGraphic(this.comboBox);
    }
    
    @Override
    public void cancelEdit() {
        super.cancelEdit();
        this.setText(this.getConverter().toString((T)this.getItem()));
        this.setGraphic(null);
    }
    
    public void updateItem(final T t, final boolean b) {
        super.updateItem((T)t, b);
        CellUtils.updateItem((Cell<T>)this, this.getConverter(), null, null, this.comboBox);
    }
}
