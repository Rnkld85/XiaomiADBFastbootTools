// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.scene.layout.HBox;
import javafx.scene.Node;
import javafx.scene.control.Cell;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.scene.control.TreeTableColumn;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.scene.control.ChoiceBox;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeTableCell;

public class ChoiceBoxTreeTableCell<S, T> extends TreeTableCell<S, T>
{
    private final ObservableList<T> items;
    private ChoiceBox<T> choiceBox;
    private ObjectProperty<StringConverter<T>> converter;
    
    @SafeVarargs
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final T... array) {
        return forTreeTableColumn((StringConverter<T>)null, array);
    }
    
    @SafeVarargs
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final StringConverter<T> stringConverter, final T... array) {
        return forTreeTableColumn(stringConverter, (ObservableList<T>)FXCollections.observableArrayList((T[])array));
    }
    
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final ObservableList<T> list) {
        return forTreeTableColumn(null, list);
    }
    
    public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(final StringConverter<T> stringConverter, final ObservableList<T> list) {
        return (Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>)(p2 -> new ChoiceBoxTreeTableCell((StringConverter<Object>)stringConverter, (ObservableList<Object>)list));
    }
    
    public ChoiceBoxTreeTableCell() {
        this(FXCollections.observableArrayList());
    }
    
    @SafeVarargs
    public ChoiceBoxTreeTableCell(final T... array) {
        this(FXCollections.observableArrayList(array));
    }
    
    @SafeVarargs
    public ChoiceBoxTreeTableCell(final StringConverter<T> stringConverter, final T... array) {
        this(stringConverter, FXCollections.observableArrayList(array));
    }
    
    public ChoiceBoxTreeTableCell(final ObservableList<T> list) {
        this(null, list);
    }
    
    public ChoiceBoxTreeTableCell(final StringConverter<T> stringConverter, final ObservableList<T> items) {
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter");
        this.getStyleClass().add("choice-box-tree-table-cell");
        this.items = items;
        this.setConverter((stringConverter != null) ? stringConverter : CellUtils.defaultStringConverter());
    }
    
    public final ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    public ObservableList<T> getItems() {
        return this.items;
    }
    
    @Override
    public void startEdit() {
        if (!this.isEditable() || !this.getTreeTableView().isEditable() || !this.getTableColumn().isEditable()) {
            return;
        }
        if (this.choiceBox == null) {
            this.choiceBox = CellUtils.createChoiceBox((Cell<T>)this, this.items, this.converterProperty());
        }
        this.choiceBox.getSelectionModel().select((T)this.getItem());
        super.startEdit();
        this.setText(null);
        this.setGraphic(this.choiceBox);
    }
    
    @Override
    public void cancelEdit() {
        super.cancelEdit();
        this.setText(this.getConverter().toString((T)this.getItem()));
        this.setGraphic(null);
    }
    
    public void updateItem(final T t, final boolean b) {
        super.updateItem((T)t, b);
        CellUtils.updateItem((Cell<T>)this, this.getConverter(), null, null, this.choiceBox);
    }
}
