// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.beans.property.Property;
import javafx.scene.Node;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.CheckBoxTreeItem;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeView;
import javafx.util.Callback;
import javafx.scene.control.TreeItem;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.CheckBox;

public class CheckBoxTreeCell<T> extends DefaultTreeCell<T>
{
    private final CheckBox checkBox;
    private ObservableValue<Boolean> booleanProperty;
    private BooleanProperty indeterminateProperty;
    private ObjectProperty<StringConverter<TreeItem<T>>> converter;
    private ObjectProperty<Callback<TreeItem<T>, ObservableValue<Boolean>>> selectedStateCallback;
    
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView() {
        return forTreeView(checkBoxTreeItem -> {
            if (checkBoxTreeItem instanceof CheckBoxTreeItem) {
                return checkBoxTreeItem.selectedProperty();
            }
            else {
                return null;
            }
        }, CellUtils.defaultTreeItemStringConverter());
    }
    
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final Callback<TreeItem<T>, ObservableValue<Boolean>> callback) {
        return forTreeView(callback, CellUtils.defaultTreeItemStringConverter());
    }
    
    public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(final Callback<TreeItem<T>, ObservableValue<Boolean>> callback, final StringConverter<TreeItem<T>> stringConverter) {
        return (Callback<TreeView<T>, TreeCell<T>>)(p2 -> new CheckBoxTreeCell((Callback<TreeItem<Object>, ObservableValue<Boolean>>)callback, (StringConverter<TreeItem<Object>>)stringConverter));
    }
    
    public CheckBoxTreeCell() {
        this(checkBoxTreeItem -> {
            if (checkBoxTreeItem instanceof CheckBoxTreeItem) {
                return checkBoxTreeItem.selectedProperty();
            }
            else {
                return null;
            }
        });
    }
    
    public CheckBoxTreeCell(final Callback<TreeItem<T>, ObservableValue<Boolean>> callback) {
        this(callback, CellUtils.defaultTreeItemStringConverter(), null);
    }
    
    public CheckBoxTreeCell(final Callback<TreeItem<T>, ObservableValue<Boolean>> callback, final StringConverter<TreeItem<T>> stringConverter) {
        this(callback, stringConverter, null);
    }
    
    private CheckBoxTreeCell(final Callback<TreeItem<T>, ObservableValue<Boolean>> selectedStateCallback, final StringConverter<TreeItem<T>> converter, final Callback<TreeItem<T>, ObservableValue<Boolean>> callback) {
        this.converter = new SimpleObjectProperty<StringConverter<TreeItem<T>>>(this, "converter");
        this.selectedStateCallback = new SimpleObjectProperty<Callback<TreeItem<T>, ObservableValue<Boolean>>>(this, "selectedStateCallback");
        this.getStyleClass().add("check-box-tree-cell");
        this.setSelectedStateCallback(selectedStateCallback);
        this.setConverter(converter);
        (this.checkBox = new CheckBox()).setAllowIndeterminate(false);
        this.setGraphic(null);
    }
    
    public final ObjectProperty<StringConverter<TreeItem<T>>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<TreeItem<T>> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<TreeItem<T>> getConverter() {
        return this.converterProperty().get();
    }
    
    public final ObjectProperty<Callback<TreeItem<T>, ObservableValue<Boolean>>> selectedStateCallbackProperty() {
        return this.selectedStateCallback;
    }
    
    public final void setSelectedStateCallback(final Callback<TreeItem<T>, ObservableValue<Boolean>> callback) {
        this.selectedStateCallbackProperty().set(callback);
    }
    
    public final Callback<TreeItem<T>, ObservableValue<Boolean>> getSelectedStateCallback() {
        return this.selectedStateCallbackProperty().get();
    }
    
    @Override
    public void updateItem(final T t, final boolean b) {
        super.updateItem(t, b);
        if (b) {
            this.setText(null);
            this.setGraphic(null);
        }
        else {
            final StringConverter<TreeItem<T>> converter = this.getConverter();
            final TreeItem<T> treeItem = this.getTreeItem();
            this.setText((converter != null) ? converter.toString(treeItem) : ((treeItem == null) ? "" : treeItem.toString()));
            this.checkBox.setGraphic((treeItem == null) ? null : treeItem.getGraphic());
            this.setGraphic(this.checkBox);
            if (this.booleanProperty != null) {
                this.checkBox.selectedProperty().unbindBidirectional((Property<Boolean>)this.booleanProperty);
            }
            if (this.indeterminateProperty != null) {
                this.checkBox.indeterminateProperty().unbindBidirectional(this.indeterminateProperty);
            }
            if (treeItem instanceof CheckBoxTreeItem) {
                final CheckBoxTreeItem<T> checkBoxTreeItem = (CheckBoxTreeItem<T>)treeItem;
                this.booleanProperty = checkBoxTreeItem.selectedProperty();
                this.checkBox.selectedProperty().bindBidirectional((Property<Boolean>)this.booleanProperty);
                this.indeterminateProperty = checkBoxTreeItem.indeterminateProperty();
                this.checkBox.indeterminateProperty().bindBidirectional(this.indeterminateProperty);
            }
            else {
                final Callback<TreeItem<T>, ObservableValue<Boolean>> selectedStateCallback = this.getSelectedStateCallback();
                if (selectedStateCallback == null) {
                    throw new NullPointerException("The CheckBoxTreeCell selectedStateCallbackProperty can not be null");
                }
                this.booleanProperty = selectedStateCallback.call(treeItem);
                if (this.booleanProperty != null) {
                    this.checkBox.selectedProperty().bindBidirectional((Property<Boolean>)this.booleanProperty);
                }
            }
        }
    }
    
    @Override
    void updateDisplay(final T t, final boolean b) {
    }
}
