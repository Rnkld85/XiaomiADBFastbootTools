// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.cell;

import javafx.scene.Node;
import javafx.scene.layout.HBox;
import javafx.scene.control.Cell;
import javafx.beans.property.SimpleObjectProperty;
import javafx.util.converter.DefaultStringConverter;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;
import javafx.scene.control.TextField;
import javafx.scene.control.ListCell;

public class TextFieldListCell<T> extends ListCell<T>
{
    private TextField textField;
    private ObjectProperty<StringConverter<T>> converter;
    
    public static Callback<ListView<String>, ListCell<String>> forListView() {
        return forListView((StringConverter<String>)new DefaultStringConverter());
    }
    
    public static <T> Callback<ListView<T>, ListCell<T>> forListView(final StringConverter<T> stringConverter) {
        return (Callback<ListView<T>, ListCell<T>>)(p1 -> new TextFieldListCell((StringConverter<Object>)stringConverter));
    }
    
    public TextFieldListCell() {
        this((StringConverter)null);
    }
    
    public TextFieldListCell(final StringConverter<T> converter) {
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter");
        this.getStyleClass().add("text-field-list-cell");
        this.setConverter(converter);
    }
    
    public final ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    @Override
    public void startEdit() {
        if (!this.isEditable() || !this.getListView().isEditable()) {
            return;
        }
        super.startEdit();
        if (this.isEditing()) {
            if (this.textField == null) {
                this.textField = CellUtils.createTextField((Cell<Object>)this, this.getConverter());
            }
            CellUtils.startEdit((Cell<Object>)this, this.getConverter(), null, null, this.textField);
        }
    }
    
    @Override
    public void cancelEdit() {
        super.cancelEdit();
        CellUtils.cancelEdit((Cell<Object>)this, this.getConverter(), null);
    }
    
    public void updateItem(final T t, final boolean b) {
        super.updateItem(t, b);
        CellUtils.updateItem((Cell<Object>)this, this.getConverter(), null, null, this.textField);
    }
}
