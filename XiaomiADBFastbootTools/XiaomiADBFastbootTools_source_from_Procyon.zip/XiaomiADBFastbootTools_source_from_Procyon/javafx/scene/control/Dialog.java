// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ObjectPropertyBase;
import javafx.event.EventDispatcher;
import javafx.event.EventDispatchChain;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.stage.Window;
import javafx.stage.StageStyle;
import java.util.Iterator;
import java.util.Optional;
import javafx.event.Event;
import javafx.event.EventType;
import com.sun.javafx.tk.Toolkit;
import javafx.stage.Modality;
import javafx.beans.Observable;
import javafx.collections.ListChangeListener;
import javafx.scene.Node;
import java.lang.ref.WeakReference;
import javafx.beans.InvalidationListener;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.PseudoClass;
import javafx.event.EventHandler;
import com.sun.javafx.event.EventHandlerManager;
import javafx.util.Callback;
import javafx.beans.property.ObjectProperty;
import javafx.event.EventTarget;

public class Dialog<R> implements EventTarget
{
    final FXDialog dialog;
    private boolean isClosing;
    private ObjectProperty<DialogPane> dialogPane;
    private final ObjectProperty<R> resultProperty;
    private final ObjectProperty<Callback<ButtonType, R>> resultConverterProperty;
    private final EventHandlerManager eventHandlerManager;
    private ObjectProperty<EventHandler<DialogEvent>> onShowing;
    private ObjectProperty<EventHandler<DialogEvent>> onShown;
    private ObjectProperty<EventHandler<DialogEvent>> onHiding;
    private ObjectProperty<EventHandler<DialogEvent>> onHidden;
    private ObjectProperty<EventHandler<DialogEvent>> onCloseRequest;
    private static final PseudoClass HEADER_PSEUDO_CLASS;
    private static final PseudoClass NO_HEADER_PSEUDO_CLASS;
    
    public Dialog() {
        this.dialogPane = new SimpleObjectProperty<DialogPane>((Object)this, "dialogPane", new DialogPane()) {
            final InvalidationListener expandedListener;
            final InvalidationListener headerListener;
            WeakReference<DialogPane> dialogPaneRef;
            
            {
                final DialogPane dialogPane2;
                final Node node;
                this.expandedListener = (p0 -> {
                    Dialog.this.getDialogPane();
                    if (dialogPane2 == null) {
                        return;
                    }
                    else {
                        dialogPane2.getExpandableContent();
                        Dialog.this.setResizable(node != null && node.isVisible());
                        Dialog.this.dialog.sizeToScene();
                        return;
                    }
                });
                this.headerListener = (p0 -> Dialog.this.updatePseudoClassState());
                this.dialogPaneRef = new WeakReference<DialogPane>(null);
            }
            
            @Override
            protected void invalidated() {
                final DialogPane dialogPane = this.dialogPaneRef.get();
                if (dialogPane != null) {
                    dialogPane.expandedProperty().removeListener(this.expandedListener);
                    dialogPane.headerProperty().removeListener(this.headerListener);
                    dialogPane.headerTextProperty().removeListener(this.headerListener);
                    dialogPane.setDialog(null);
                }
                final DialogPane dialogPane2 = Dialog.this.getDialogPane();
                if (dialogPane2 != null) {
                    dialogPane2.setDialog(Dialog.this);
                    dialogPane2.getButtonTypes().addListener(p1 -> dialogPane2.requestLayout());
                    dialogPane2.expandedProperty().addListener(this.expandedListener);
                    dialogPane2.headerProperty().addListener(this.headerListener);
                    dialogPane2.headerTextProperty().addListener(this.headerListener);
                    Dialog.this.updatePseudoClassState();
                    dialogPane2.requestLayout();
                }
                Dialog.this.dialog.setDialogPane(dialogPane2);
                this.dialogPaneRef = new WeakReference<DialogPane>(dialogPane2);
            }
        };
        this.resultProperty = new SimpleObjectProperty<R>() {
            @Override
            protected void invalidated() {
                Dialog.this.close();
            }
        };
        this.resultConverterProperty = new SimpleObjectProperty<Callback<ButtonType, R>>(this, "resultConverter");
        this.eventHandlerManager = new EventHandlerManager(this);
        this.dialog = new HeavyweightDialog(this);
        this.setDialogPane(new DialogPane());
        this.initModality(Modality.APPLICATION_MODAL);
    }
    
    public final void show() {
        Toolkit.getToolkit().checkFxUserThread();
        Event.fireEvent(this, new DialogEvent(this, DialogEvent.DIALOG_SHOWING));
        if (Double.isNaN(this.getWidth()) && Double.isNaN(this.getHeight())) {
            this.dialog.sizeToScene();
        }
        this.dialog.show();
        Event.fireEvent(this, new DialogEvent(this, DialogEvent.DIALOG_SHOWN));
    }
    
    public final Optional<R> showAndWait() {
        Toolkit.getToolkit().checkFxUserThread();
        if (!Toolkit.getToolkit().canStartNestedEventLoop()) {
            throw new IllegalStateException("showAndWait is not allowed during animation or layout processing");
        }
        Event.fireEvent(this, new DialogEvent(this, DialogEvent.DIALOG_SHOWING));
        if (Double.isNaN(this.getWidth()) && Double.isNaN(this.getHeight())) {
            this.dialog.sizeToScene();
        }
        Event.fireEvent(this, new DialogEvent(this, DialogEvent.DIALOG_SHOWN));
        this.dialog.showAndWait();
        return Optional.ofNullable(this.getResult());
    }
    
    public final void close() {
        if (this.isClosing) {
            return;
        }
        this.isClosing = true;
        final Object result = this.getResult();
        if (result == null && !this.dialog.requestPermissionToClose(this)) {
            this.isClosing = false;
            return;
        }
        if (result == null) {
            ButtonType buttonType = null;
            for (final ButtonType buttonType2 : this.getDialogPane().getButtonTypes()) {
                final ButtonBar.ButtonData buttonData = buttonType2.getButtonData();
                if (buttonData == null) {
                    continue;
                }
                if (buttonData == ButtonBar.ButtonData.CANCEL_CLOSE) {
                    buttonType = buttonType2;
                    break;
                }
                if (!buttonData.isCancelButton()) {
                    continue;
                }
                buttonType = buttonType2;
            }
            this.setResultAndClose(buttonType, false);
        }
        Event.fireEvent(this, new DialogEvent(this, DialogEvent.DIALOG_HIDING));
        final DialogEvent dialogEvent = new DialogEvent(this, DialogEvent.DIALOG_CLOSE_REQUEST);
        Event.fireEvent(this, dialogEvent);
        if (dialogEvent.isConsumed()) {
            this.isClosing = false;
            return;
        }
        this.dialog.close();
        Event.fireEvent(this, new DialogEvent(this, DialogEvent.DIALOG_HIDDEN));
        this.isClosing = false;
    }
    
    public final void hide() {
        this.close();
    }
    
    public final void initModality(final Modality modality) {
        this.dialog.initModality(modality);
    }
    
    public final Modality getModality() {
        return this.dialog.getModality();
    }
    
    public final void initStyle(final StageStyle stageStyle) {
        this.dialog.initStyle(stageStyle);
    }
    
    public final void initOwner(final Window window) {
        this.dialog.initOwner(window);
    }
    
    public final Window getOwner() {
        return this.dialog.getOwner();
    }
    
    public final ObjectProperty<DialogPane> dialogPaneProperty() {
        return this.dialogPane;
    }
    
    public final DialogPane getDialogPane() {
        return this.dialogPane.get();
    }
    
    public final void setDialogPane(final DialogPane dialogPane) {
        this.dialogPane.set(dialogPane);
    }
    
    public final StringProperty contentTextProperty() {
        return this.getDialogPane().contentTextProperty();
    }
    
    public final String getContentText() {
        return this.getDialogPane().getContentText();
    }
    
    public final void setContentText(final String contentText) {
        this.getDialogPane().setContentText(contentText);
    }
    
    public final StringProperty headerTextProperty() {
        return this.getDialogPane().headerTextProperty();
    }
    
    public final String getHeaderText() {
        return this.getDialogPane().getHeaderText();
    }
    
    public final void setHeaderText(final String headerText) {
        this.getDialogPane().setHeaderText(headerText);
    }
    
    public final ObjectProperty<Node> graphicProperty() {
        return this.getDialogPane().graphicProperty();
    }
    
    public final Node getGraphic() {
        return this.getDialogPane().getGraphic();
    }
    
    public final void setGraphic(final Node graphic) {
        this.getDialogPane().setGraphic(graphic);
    }
    
    public final ObjectProperty<R> resultProperty() {
        return this.resultProperty;
    }
    
    public final R getResult() {
        return this.resultProperty().get();
    }
    
    public final void setResult(final R r) {
        this.resultProperty().set(r);
    }
    
    public final ObjectProperty<Callback<ButtonType, R>> resultConverterProperty() {
        return this.resultConverterProperty;
    }
    
    public final Callback<ButtonType, R> getResultConverter() {
        return this.resultConverterProperty().get();
    }
    
    public final void setResultConverter(final Callback<ButtonType, R> callback) {
        this.resultConverterProperty().set(callback);
    }
    
    public final ReadOnlyBooleanProperty showingProperty() {
        return this.dialog.showingProperty();
    }
    
    public final boolean isShowing() {
        return this.showingProperty().get();
    }
    
    public final BooleanProperty resizableProperty() {
        return this.dialog.resizableProperty();
    }
    
    public final boolean isResizable() {
        return this.resizableProperty().get();
    }
    
    public final void setResizable(final boolean b) {
        this.resizableProperty().set(b);
    }
    
    public final ReadOnlyDoubleProperty widthProperty() {
        return this.dialog.widthProperty();
    }
    
    public final double getWidth() {
        return this.widthProperty().get();
    }
    
    public final void setWidth(final double width) {
        this.dialog.setWidth(width);
    }
    
    public final ReadOnlyDoubleProperty heightProperty() {
        return this.dialog.heightProperty();
    }
    
    public final double getHeight() {
        return this.heightProperty().get();
    }
    
    public final void setHeight(final double height) {
        this.dialog.setHeight(height);
    }
    
    public final StringProperty titleProperty() {
        return this.dialog.titleProperty();
    }
    
    public final String getTitle() {
        return this.dialog.titleProperty().get();
    }
    
    public final void setTitle(final String s) {
        this.dialog.titleProperty().set(s);
    }
    
    public final double getX() {
        return this.dialog.getX();
    }
    
    public final void setX(final double x) {
        this.dialog.setX(x);
    }
    
    public final ReadOnlyDoubleProperty xProperty() {
        return this.dialog.xProperty();
    }
    
    public final double getY() {
        return this.dialog.getY();
    }
    
    public final void setY(final double y) {
        this.dialog.setY(y);
    }
    
    public final ReadOnlyDoubleProperty yProperty() {
        return this.dialog.yProperty();
    }
    
    @Override
    public EventDispatchChain buildEventDispatchChain(final EventDispatchChain eventDispatchChain) {
        return eventDispatchChain.prepend(this.eventHandlerManager);
    }
    
    public final void setOnShowing(final EventHandler<DialogEvent> eventHandler) {
        this.onShowingProperty().set(eventHandler);
    }
    
    public final EventHandler<DialogEvent> getOnShowing() {
        return (this.onShowing == null) ? null : this.onShowing.get();
    }
    
    public final ObjectProperty<EventHandler<DialogEvent>> onShowingProperty() {
        if (this.onShowing == null) {
            this.onShowing = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onShowing") {
                @Override
                protected void invalidated() {
                    Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_SHOWING, ((ObjectPropertyBase<EventHandler<? super DialogEvent>>)this).get());
                }
            };
        }
        return this.onShowing;
    }
    
    public final void setOnShown(final EventHandler<DialogEvent> eventHandler) {
        this.onShownProperty().set(eventHandler);
    }
    
    public final EventHandler<DialogEvent> getOnShown() {
        return (this.onShown == null) ? null : this.onShown.get();
    }
    
    public final ObjectProperty<EventHandler<DialogEvent>> onShownProperty() {
        if (this.onShown == null) {
            this.onShown = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onShown") {
                @Override
                protected void invalidated() {
                    Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_SHOWN, ((ObjectPropertyBase<EventHandler<? super DialogEvent>>)this).get());
                }
            };
        }
        return this.onShown;
    }
    
    public final void setOnHiding(final EventHandler<DialogEvent> eventHandler) {
        this.onHidingProperty().set(eventHandler);
    }
    
    public final EventHandler<DialogEvent> getOnHiding() {
        return (this.onHiding == null) ? null : this.onHiding.get();
    }
    
    public final ObjectProperty<EventHandler<DialogEvent>> onHidingProperty() {
        if (this.onHiding == null) {
            this.onHiding = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onHiding") {
                @Override
                protected void invalidated() {
                    Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_HIDING, ((ObjectPropertyBase<EventHandler<? super DialogEvent>>)this).get());
                }
            };
        }
        return this.onHiding;
    }
    
    public final void setOnHidden(final EventHandler<DialogEvent> eventHandler) {
        this.onHiddenProperty().set(eventHandler);
    }
    
    public final EventHandler<DialogEvent> getOnHidden() {
        return (this.onHidden == null) ? null : this.onHidden.get();
    }
    
    public final ObjectProperty<EventHandler<DialogEvent>> onHiddenProperty() {
        if (this.onHidden == null) {
            this.onHidden = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onHidden") {
                @Override
                protected void invalidated() {
                    Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_HIDDEN, ((ObjectPropertyBase<EventHandler<? super DialogEvent>>)this).get());
                }
            };
        }
        return this.onHidden;
    }
    
    public final void setOnCloseRequest(final EventHandler<DialogEvent> eventHandler) {
        this.onCloseRequestProperty().set(eventHandler);
    }
    
    public final EventHandler<DialogEvent> getOnCloseRequest() {
        return (this.onCloseRequest != null) ? this.onCloseRequest.get() : null;
    }
    
    public final ObjectProperty<EventHandler<DialogEvent>> onCloseRequestProperty() {
        if (this.onCloseRequest == null) {
            this.onCloseRequest = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onCloseRequest") {
                @Override
                protected void invalidated() {
                    Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_CLOSE_REQUEST, ((ObjectPropertyBase<EventHandler<? super DialogEvent>>)this).get());
                }
            };
        }
        return this.onCloseRequest;
    }
    
    void setResultAndClose(final ButtonType buttonType, final boolean b) {
        final Callback<ButtonType, R> resultConverter = this.getResultConverter();
        final R result = this.getResult();
        Object call;
        if (resultConverter == null) {
            call = buttonType;
        }
        else {
            call = resultConverter.call(buttonType);
        }
        this.setResult((R)call);
        if (b && result == call) {
            this.close();
        }
    }
    
    private void updatePseudoClassState() {
        final DialogPane dialogPane = this.getDialogPane();
        if (dialogPane != null) {
            final boolean hasHeader = this.getDialogPane().hasHeader();
            dialogPane.pseudoClassStateChanged(Dialog.HEADER_PSEUDO_CLASS, hasHeader);
            dialogPane.pseudoClassStateChanged(Dialog.NO_HEADER_PSEUDO_CLASS, !hasHeader);
        }
    }
    
    static {
        HEADER_PSEUDO_CLASS = PseudoClass.getPseudoClass("header");
        NO_HEADER_PSEUDO_CLASS = PseudoClass.getPseudoClass("no-header");
    }
}
