// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;
import javafx.event.Event;

public class DialogEvent extends Event
{
    private static final long serialVersionUID = 20140716L;
    public static final EventType<DialogEvent> ANY;
    public static final EventType<DialogEvent> DIALOG_SHOWING;
    public static final EventType<DialogEvent> DIALOG_SHOWN;
    public static final EventType<DialogEvent> DIALOG_HIDING;
    public static final EventType<DialogEvent> DIALOG_HIDDEN;
    public static final EventType<DialogEvent> DIALOG_CLOSE_REQUEST;
    
    public DialogEvent(@NamedArg("source") final Dialog<?> dialog, @NamedArg("eventType") final EventType<? extends Event> eventType) {
        super(dialog, dialog, eventType);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("DialogEvent [");
        sb.append("source = ").append(this.getSource());
        sb.append(", target = ").append(this.getTarget());
        sb.append(", eventType = ").append(this.getEventType());
        sb.append(", consumed = ").append(this.isConsumed());
        return sb.append("]").toString();
    }
    
    @Override
    public DialogEvent copyFor(final Object o, final EventTarget eventTarget) {
        return (DialogEvent)super.copyFor(o, eventTarget);
    }
    
    public DialogEvent copyFor(final Object o, final EventTarget eventTarget, final EventType<DialogEvent> eventType) {
        final DialogEvent copy = this.copyFor(o, eventTarget);
        copy.eventType = eventType;
        return copy;
    }
    
    @Override
    public EventType<DialogEvent> getEventType() {
        return (EventType<DialogEvent>)super.getEventType();
    }
    
    static {
        ANY = new EventType<DialogEvent>(Event.ANY, "DIALOG");
        DIALOG_SHOWING = new EventType<DialogEvent>(DialogEvent.ANY, "DIALOG_SHOWING");
        DIALOG_SHOWN = new EventType<DialogEvent>(DialogEvent.ANY, "DIALOG_SHOWN");
        DIALOG_HIDING = new EventType<DialogEvent>(DialogEvent.ANY, "DIALOG_HIDING");
        DIALOG_HIDDEN = new EventType<DialogEvent>(DialogEvent.ANY, "DIALOG_HIDDEN");
        DIALOG_CLOSE_REQUEST = new EventType<DialogEvent>(DialogEvent.ANY, "DIALOG_CLOSE_REQUEST");
    }
}
