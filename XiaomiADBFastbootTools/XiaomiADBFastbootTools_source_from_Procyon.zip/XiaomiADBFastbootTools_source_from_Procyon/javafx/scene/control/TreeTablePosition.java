// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.NamedArg;
import java.lang.ref.WeakReference;

public class TreeTablePosition<S, T> extends TablePositionBase<TreeTableColumn<S, T>>
{
    private final WeakReference<TreeTableView<S>> controlRef;
    private final WeakReference<TreeItem<S>> treeItemRef;
    int fixedColumnIndex;
    private final int nonFixedColumnIndex;
    
    public TreeTablePosition(@NamedArg("treeTableView") final TreeTableView<S> treeTableView, @NamedArg("row") final int n, @NamedArg("tableColumn") final TreeTableColumn<S, T> treeTableColumn) {
        this(treeTableView, n, treeTableColumn, true);
    }
    
    TreeTablePosition(@NamedArg("treeTableView") final TreeTableView<S> referent, @NamedArg("row") final int n, @NamedArg("tableColumn") final TreeTableColumn<S, T> treeTableColumn, final boolean b) {
        super(n, treeTableColumn);
        this.fixedColumnIndex = -1;
        this.controlRef = new WeakReference<TreeTableView<S>>(referent);
        this.treeItemRef = new WeakReference<TreeItem<S>>(b ? referent.getTreeItem(n) : null);
        this.nonFixedColumnIndex = ((referent == null || treeTableColumn == null) ? -1 : referent.getVisibleLeafIndex(treeTableColumn));
    }
    
    @Override
    public int getColumn() {
        if (this.fixedColumnIndex > -1) {
            return this.fixedColumnIndex;
        }
        return this.nonFixedColumnIndex;
    }
    
    public final TreeTableView<S> getTreeTableView() {
        return this.controlRef.get();
    }
    
    @Override
    public final TreeTableColumn<S, T> getTableColumn() {
        return super.getTableColumn();
    }
    
    public final TreeItem<S> getTreeItem() {
        return this.treeItemRef.get();
    }
}
