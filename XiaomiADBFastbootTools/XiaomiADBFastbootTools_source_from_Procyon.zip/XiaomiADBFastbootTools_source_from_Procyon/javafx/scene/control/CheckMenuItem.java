// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.BooleanPropertyBase;
import javafx.scene.Node;
import javafx.beans.property.BooleanProperty;

public class CheckMenuItem extends MenuItem
{
    private BooleanProperty selected;
    private static final String DEFAULT_STYLE_CLASS = "check-menu-item";
    private static final String STYLE_CLASS_SELECTED = "selected";
    
    public CheckMenuItem() {
        this(null, null);
    }
    
    public CheckMenuItem(final String s) {
        this(s, null);
    }
    
    public CheckMenuItem(final String s, final Node node) {
        super(s, node);
        this.getStyleClass().add("check-menu-item");
    }
    
    public final void setSelected(final boolean b) {
        this.selectedProperty().set(b);
    }
    
    public final boolean isSelected() {
        return this.selected != null && this.selected.get();
    }
    
    public final BooleanProperty selectedProperty() {
        if (this.selected == null) {
            this.selected = new BooleanPropertyBase() {
                @Override
                protected void invalidated() {
                    this.get();
                    if (CheckMenuItem.this.isSelected()) {
                        CheckMenuItem.this.getStyleClass().add("selected");
                    }
                    else {
                        CheckMenuItem.this.getStyleClass().remove("selected");
                    }
                }
                
                @Override
                public Object getBean() {
                    return CheckMenuItem.this;
                }
                
                @Override
                public String getName() {
                    return "selected";
                }
            };
        }
        return this.selected;
    }
}
