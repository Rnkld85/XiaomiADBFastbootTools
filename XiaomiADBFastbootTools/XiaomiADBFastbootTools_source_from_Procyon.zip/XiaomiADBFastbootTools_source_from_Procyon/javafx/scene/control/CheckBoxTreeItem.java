// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.value.ObservableValue;
import javafx.event.EventTarget;
import java.util.Iterator;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.Node;
import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.event.Event;
import javafx.event.EventType;

public class CheckBoxTreeItem<T> extends TreeItem<T>
{
    private static final EventType<? extends Event> CHECK_BOX_SELECTION_CHANGED_EVENT;
    private final ChangeListener<Boolean> stateChangeListener;
    private final BooleanProperty selected;
    private final BooleanProperty indeterminate;
    private final BooleanProperty independent;
    private static boolean updateLock;
    
    public static <T> EventType<TreeModificationEvent<T>> checkBoxSelectionChangedEvent() {
        return (EventType<TreeModificationEvent<T>>)CheckBoxTreeItem.CHECK_BOX_SELECTION_CHANGED_EVENT;
    }
    
    public CheckBoxTreeItem() {
        this(null);
    }
    
    public CheckBoxTreeItem(final T t) {
        this(t, null, false);
    }
    
    public CheckBoxTreeItem(final T t, final Node node) {
        this(t, node, false);
    }
    
    public CheckBoxTreeItem(final T t, final Node node, final boolean b) {
        this(t, node, b, false);
    }
    
    public CheckBoxTreeItem(final T t, final Node node, final boolean selected, final boolean independent) {
        super(t, node);
        this.stateChangeListener = ((p0, p1, p2) -> this.updateState());
        this.selected = new SimpleBooleanProperty((Object)this, "selected", false) {
            @Override
            protected void invalidated() {
                super.invalidated();
                CheckBoxTreeItem.this.fireEvent(CheckBoxTreeItem.this, true);
            }
        };
        this.indeterminate = new SimpleBooleanProperty((Object)this, "indeterminate", false) {
            @Override
            protected void invalidated() {
                super.invalidated();
                CheckBoxTreeItem.this.fireEvent(CheckBoxTreeItem.this, false);
            }
        };
        this.independent = new SimpleBooleanProperty(this, "independent", false);
        this.setSelected(selected);
        this.setIndependent(independent);
        this.selectedProperty().addListener(this.stateChangeListener);
        this.indeterminateProperty().addListener(this.stateChangeListener);
    }
    
    public final void setSelected(final boolean b) {
        this.selectedProperty().setValue(b);
    }
    
    public final boolean isSelected() {
        return this.selected.getValue();
    }
    
    public final BooleanProperty selectedProperty() {
        return this.selected;
    }
    
    public final void setIndeterminate(final boolean b) {
        this.indeterminateProperty().setValue(b);
    }
    
    public final boolean isIndeterminate() {
        return this.indeterminate.getValue();
    }
    
    public final BooleanProperty indeterminateProperty() {
        return this.indeterminate;
    }
    
    public final BooleanProperty independentProperty() {
        return this.independent;
    }
    
    public final void setIndependent(final boolean b) {
        this.independentProperty().setValue(b);
    }
    
    public final boolean isIndependent() {
        return this.independent.getValue();
    }
    
    private void updateState() {
        if (this.isIndependent()) {
            return;
        }
        final boolean b = !CheckBoxTreeItem.updateLock;
        CheckBoxTreeItem.updateLock = true;
        this.updateUpwards();
        if (b) {
            CheckBoxTreeItem.updateLock = false;
        }
        if (CheckBoxTreeItem.updateLock) {
            return;
        }
        this.updateDownwards();
    }
    
    private void updateUpwards() {
        if (!(this.getParent() instanceof CheckBoxTreeItem)) {
            return;
        }
        final CheckBoxTreeItem checkBoxTreeItem = (CheckBoxTreeItem)this.getParent();
        int n = 0;
        int n2 = 0;
        for (final TreeItem treeItem : checkBoxTreeItem.getChildren()) {
            if (!(treeItem instanceof CheckBoxTreeItem)) {
                continue;
            }
            final CheckBoxTreeItem checkBoxTreeItem2 = (CheckBoxTreeItem)treeItem;
            n += ((checkBoxTreeItem2.isSelected() && !checkBoxTreeItem2.isIndeterminate()) ? 1 : 0);
            n2 += (checkBoxTreeItem2.isIndeterminate() ? 1 : 0);
        }
        if (n == checkBoxTreeItem.getChildren().size()) {
            checkBoxTreeItem.setSelected(true);
            checkBoxTreeItem.setIndeterminate(false);
        }
        else if (n == 0 && n2 == 0) {
            checkBoxTreeItem.setSelected(false);
            checkBoxTreeItem.setIndeterminate(false);
        }
        else {
            checkBoxTreeItem.setIndeterminate(true);
        }
    }
    
    private void updateDownwards() {
        if (!this.isLeaf()) {
            for (final TreeItem treeItem : this.getChildren()) {
                if (treeItem instanceof CheckBoxTreeItem) {
                    ((CheckBoxTreeItem)treeItem).setSelected(this.isSelected());
                }
            }
        }
    }
    
    private void fireEvent(final CheckBoxTreeItem<T> checkBoxTreeItem, final boolean b) {
        Event.fireEvent(this, new TreeModificationEvent<Object>(CheckBoxTreeItem.CHECK_BOX_SELECTION_CHANGED_EVENT, checkBoxTreeItem, b));
    }
    
    static {
        CHECK_BOX_SELECTION_CHANGED_EVENT = new EventType<Event>(TreeModificationEvent.ANY, "checkBoxSelectionChangedEvent");
        CheckBoxTreeItem.updateLock = false;
    }
    
    public static class TreeModificationEvent<T> extends Event
    {
        private static final long serialVersionUID = -8445355590698862999L;
        private final transient CheckBoxTreeItem<T> treeItem;
        private final boolean selectionChanged;
        public static final EventType<Event> ANY;
        
        public TreeModificationEvent(final EventType<? extends Event> eventType, final CheckBoxTreeItem<T> treeItem, final boolean selectionChanged) {
            super(eventType);
            this.treeItem = treeItem;
            this.selectionChanged = selectionChanged;
        }
        
        public CheckBoxTreeItem<T> getTreeItem() {
            return this.treeItem;
        }
        
        public boolean wasSelectionChanged() {
            return this.selectionChanged;
        }
        
        public boolean wasIndeterminateChanged() {
            return !this.selectionChanged;
        }
        
        static {
            ANY = new EventType<Event>(Event.ANY, "TREE_MODIFICATION");
        }
    }
}
