// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import com.sun.javafx.scene.control.ContextMenuContent;
import javafx.scene.control.skin.ContextMenuSkin;
import java.util.Collections;
import javafx.css.CssMetaData;
import java.util.List;
import javafx.css.PseudoClass;
import javafx.collections.ObservableSet;
import java.util.Map;
import java.util.HashMap;
import javafx.event.EventDispatcher;
import javafx.event.EventDispatchChain;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.scene.input.KeyCombination;
import javafx.beans.property.BooleanProperty;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableMap;
import com.sun.javafx.event.EventHandlerManager;
import javafx.collections.ObservableList;
import com.sun.javafx.beans.IDProperty;
import javafx.css.Styleable;
import javafx.event.EventTarget;

@IDProperty("id")
public class MenuItem implements EventTarget, Styleable
{
    private final ObservableList<String> styleClass;
    final EventHandlerManager eventHandlerManager;
    private Object userData;
    private ObservableMap<Object, Object> properties;
    private StringProperty id;
    private StringProperty style;
    private ReadOnlyObjectWrapper<Menu> parentMenu;
    private ReadOnlyObjectWrapper<ContextMenu> parentPopup;
    private StringProperty text;
    private ObjectProperty<Node> graphic;
    private ObjectProperty<EventHandler<ActionEvent>> onAction;
    public static final EventType<Event> MENU_VALIDATION_EVENT;
    private ObjectProperty<EventHandler<Event>> onMenuValidation;
    private BooleanProperty disable;
    private BooleanProperty visible;
    private ObjectProperty<KeyCombination> accelerator;
    private BooleanProperty mnemonicParsing;
    private static final String DEFAULT_STYLE_CLASS = "menu-item";
    
    public MenuItem() {
        this(null, null);
    }
    
    public MenuItem(final String s) {
        this(s, null);
    }
    
    public MenuItem(final String text, final Node graphic) {
        this.styleClass = FXCollections.observableArrayList();
        this.eventHandlerManager = new EventHandlerManager(this);
        this.setText(text);
        this.setGraphic(graphic);
        this.styleClass.add("menu-item");
    }
    
    public final void setId(final String s) {
        this.idProperty().set(s);
    }
    
    @Override
    public final String getId() {
        return (this.id == null) ? null : this.id.get();
    }
    
    public final StringProperty idProperty() {
        if (this.id == null) {
            this.id = new SimpleStringProperty(this, "id");
        }
        return this.id;
    }
    
    public final void setStyle(final String s) {
        this.styleProperty().set(s);
    }
    
    @Override
    public final String getStyle() {
        return (this.style == null) ? null : this.style.get();
    }
    
    public final StringProperty styleProperty() {
        if (this.style == null) {
            this.style = new SimpleStringProperty(this, "style");
        }
        return this.style;
    }
    
    protected final void setParentMenu(final Menu menu) {
        this.parentMenuPropertyImpl().set(menu);
    }
    
    public final Menu getParentMenu() {
        return (this.parentMenu == null) ? null : this.parentMenu.get();
    }
    
    public final ReadOnlyObjectProperty<Menu> parentMenuProperty() {
        return this.parentMenuPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<Menu> parentMenuPropertyImpl() {
        if (this.parentMenu == null) {
            this.parentMenu = new ReadOnlyObjectWrapper<Menu>(this, "parentMenu");
        }
        return this.parentMenu;
    }
    
    protected final void setParentPopup(final ContextMenu contextMenu) {
        this.parentPopupPropertyImpl().set(contextMenu);
    }
    
    public final ContextMenu getParentPopup() {
        return (this.parentPopup == null) ? null : this.parentPopup.get();
    }
    
    public final ReadOnlyObjectProperty<ContextMenu> parentPopupProperty() {
        return this.parentPopupPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<ContextMenu> parentPopupPropertyImpl() {
        if (this.parentPopup == null) {
            this.parentPopup = new ReadOnlyObjectWrapper<ContextMenu>(this, "parentPopup");
        }
        return this.parentPopup;
    }
    
    public final void setText(final String s) {
        this.textProperty().set(s);
    }
    
    public final String getText() {
        return (this.text == null) ? null : this.text.get();
    }
    
    public final StringProperty textProperty() {
        if (this.text == null) {
            this.text = new SimpleStringProperty(this, "text");
        }
        return this.text;
    }
    
    public final void setGraphic(final Node node) {
        this.graphicProperty().set(node);
    }
    
    public final Node getGraphic() {
        return (this.graphic == null) ? null : this.graphic.get();
    }
    
    public final ObjectProperty<Node> graphicProperty() {
        if (this.graphic == null) {
            this.graphic = new SimpleObjectProperty<Node>(this, "graphic");
        }
        return this.graphic;
    }
    
    public final void setOnAction(final EventHandler<ActionEvent> eventHandler) {
        this.onActionProperty().set(eventHandler);
    }
    
    public final EventHandler<ActionEvent> getOnAction() {
        return (this.onAction == null) ? null : this.onAction.get();
    }
    
    public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() {
        if (this.onAction == null) {
            this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
                @Override
                protected void invalidated() {
                    MenuItem.this.eventHandlerManager.setEventHandler(ActionEvent.ACTION, ((ObjectPropertyBase<EventHandler<? super ActionEvent>>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return MenuItem.this;
                }
                
                @Override
                public String getName() {
                    return "onAction";
                }
            };
        }
        return this.onAction;
    }
    
    public final void setOnMenuValidation(final EventHandler<Event> eventHandler) {
        this.onMenuValidationProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnMenuValidation() {
        return (this.onMenuValidation == null) ? null : this.onMenuValidation.get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onMenuValidationProperty() {
        if (this.onMenuValidation == null) {
            this.onMenuValidation = new ObjectPropertyBase<EventHandler<Event>>() {
                @Override
                protected void invalidated() {
                    MenuItem.this.eventHandlerManager.setEventHandler(MenuItem.MENU_VALIDATION_EVENT, ((ObjectPropertyBase<EventHandler<? super Event>>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return MenuItem.this;
                }
                
                @Override
                public String getName() {
                    return "onMenuValidation";
                }
            };
        }
        return this.onMenuValidation;
    }
    
    public final void setDisable(final boolean b) {
        this.disableProperty().set(b);
    }
    
    public final boolean isDisable() {
        return this.disable != null && this.disable.get();
    }
    
    public final BooleanProperty disableProperty() {
        if (this.disable == null) {
            this.disable = new SimpleBooleanProperty(this, "disable");
        }
        return this.disable;
    }
    
    public final void setVisible(final boolean b) {
        this.visibleProperty().set(b);
    }
    
    public final boolean isVisible() {
        return this.visible == null || this.visible.get();
    }
    
    public final BooleanProperty visibleProperty() {
        if (this.visible == null) {
            this.visible = new SimpleBooleanProperty(this, "visible", true);
        }
        return this.visible;
    }
    
    public final void setAccelerator(final KeyCombination keyCombination) {
        this.acceleratorProperty().set(keyCombination);
    }
    
    public final KeyCombination getAccelerator() {
        return (this.accelerator == null) ? null : this.accelerator.get();
    }
    
    public final ObjectProperty<KeyCombination> acceleratorProperty() {
        if (this.accelerator == null) {
            this.accelerator = new SimpleObjectProperty<KeyCombination>(this, "accelerator");
        }
        return this.accelerator;
    }
    
    public final void setMnemonicParsing(final boolean b) {
        this.mnemonicParsingProperty().set(b);
    }
    
    public final boolean isMnemonicParsing() {
        return this.mnemonicParsing == null || this.mnemonicParsing.get();
    }
    
    public final BooleanProperty mnemonicParsingProperty() {
        if (this.mnemonicParsing == null) {
            this.mnemonicParsing = new SimpleBooleanProperty(this, "mnemonicParsing", true);
        }
        return this.mnemonicParsing;
    }
    
    @Override
    public ObservableList<String> getStyleClass() {
        return this.styleClass;
    }
    
    public void fire() {
        Event.fireEvent(this, new ActionEvent(this, this));
    }
    
    public <E extends Event> void addEventHandler(final EventType<E> eventType, final EventHandler<E> eventHandler) {
        this.eventHandlerManager.addEventHandler(eventType, eventHandler);
    }
    
    public <E extends Event> void removeEventHandler(final EventType<E> eventType, final EventHandler<E> eventHandler) {
        this.eventHandlerManager.removeEventHandler(eventType, eventHandler);
    }
    
    @Override
    public EventDispatchChain buildEventDispatchChain(final EventDispatchChain eventDispatchChain) {
        if (this.getParentPopup() != null) {
            this.getParentPopup().buildEventDispatchChain(eventDispatchChain);
        }
        if (this.getParentMenu() != null) {
            this.getParentMenu().buildEventDispatchChain(eventDispatchChain);
        }
        return eventDispatchChain.prepend(this.eventHandlerManager);
    }
    
    public Object getUserData() {
        return this.userData;
    }
    
    public void setUserData(final Object userData) {
        this.userData = userData;
    }
    
    public ObservableMap<Object, Object> getProperties() {
        if (this.properties == null) {
            this.properties = FXCollections.observableMap(new HashMap<Object, Object>());
        }
        return this.properties;
    }
    
    @Override
    public String getTypeSelector() {
        return "MenuItem";
    }
    
    @Override
    public Styleable getStyleableParent() {
        if (this.getParentMenu() == null) {
            return this.getParentPopup();
        }
        return this.getParentMenu();
    }
    
    @Override
    public final ObservableSet<PseudoClass> getPseudoClassStates() {
        return FXCollections.emptyObservableSet();
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return Collections.emptyList();
    }
    
    @Override
    public Node getStyleableNode() {
        final ContextMenu parentPopup = this.getParentPopup();
        if (parentPopup == null || !(parentPopup.getSkin() instanceof ContextMenuSkin)) {
            return null;
        }
        final ContextMenuSkin contextMenuSkin = (ContextMenuSkin)parentPopup.getSkin();
        if (!(contextMenuSkin.getNode() instanceof ContextMenuContent)) {
            return null;
        }
        final ObservableList<Node> childrenUnmodifiable = ((ContextMenuContent)contextMenuSkin.getNode()).getItemsContainer().getChildrenUnmodifiable();
        for (int i = 0; i < childrenUnmodifiable.size(); ++i) {
            if (childrenUnmodifiable.get(i) instanceof ContextMenuContent.MenuItemContainer) {
                final ContextMenuContent.MenuItemContainer menuItemContainer = childrenUnmodifiable.get(i);
                if (this.equals(menuItemContainer.getItem())) {
                    return menuItemContainer;
                }
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder(this.getClass().getSimpleName());
        final boolean b = this.id != null && !"".equals(this.getId());
        final boolean b2 = !this.getStyleClass().isEmpty();
        if (!b) {
            sb.append('@');
            sb.append(Integer.toHexString(this.hashCode()));
        }
        else {
            sb.append("[id=");
            sb.append(this.getId());
            if (!b2) {
                sb.append("]");
            }
        }
        if (b2) {
            if (!b) {
                sb.append('[');
            }
            else {
                sb.append(", ");
            }
            sb.append("styleClass=");
            sb.append(this.getStyleClass());
            sb.append("]");
        }
        return sb.toString();
    }
    
    static {
        MENU_VALIDATION_EVENT = new EventType<Event>(Event.ANY, "MENU_VALIDATION_EVENT");
    }
}
