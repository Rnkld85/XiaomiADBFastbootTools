// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.collections.ObservableList;
import javafx.beans.NamedArg;
import java.lang.ref.WeakReference;

public class TablePosition<S, T> extends TablePositionBase<TableColumn<S, T>>
{
    private final WeakReference<TableView<S>> controlRef;
    private final WeakReference<S> itemRef;
    int fixedColumnIndex;
    private final int nonFixedColumnIndex;
    
    public TablePosition(@NamedArg("tableView") final TableView<S> referent, @NamedArg("row") final int n, @NamedArg("tableColumn") final TableColumn<S, T> tableColumn) {
        super(n, tableColumn);
        this.fixedColumnIndex = -1;
        this.controlRef = new WeakReference<TableView<S>>(referent);
        final ObservableList<S> items = referent.getItems();
        this.itemRef = new WeakReference<S>((items != null && n >= 0 && n < items.size()) ? items.get(n) : null);
        this.nonFixedColumnIndex = ((referent == null || tableColumn == null) ? -1 : referent.getVisibleLeafIndex(tableColumn));
    }
    
    @Override
    public int getColumn() {
        if (this.fixedColumnIndex > -1) {
            return this.fixedColumnIndex;
        }
        return this.nonFixedColumnIndex;
    }
    
    public final TableView<S> getTableView() {
        return this.controlRef.get();
    }
    
    @Override
    public final TableColumn<S, T> getTableColumn() {
        return super.getTableColumn();
    }
    
    final S getItem() {
        return (this.itemRef == null) ? null : this.itemRef.get();
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(ILjavafx/scene/control/TableColumn;Ljavafx/scene/control/TableView;)Ljava/lang/String;, this.getRow(), this.getTableColumn(), this.getTableView());
    }
}
