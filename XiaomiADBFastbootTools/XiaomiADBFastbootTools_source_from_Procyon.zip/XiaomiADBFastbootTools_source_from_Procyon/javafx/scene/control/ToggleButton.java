// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.control.skin.ToggleButtonSkin;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.traversal.ParentTraversalEngine;
import javafx.scene.Parent;
import com.sun.javafx.scene.ParentHelper;
import javafx.beans.value.ChangeListener;
import javafx.beans.property.ObjectPropertyBase;
import javafx.scene.AccessibleAttribute;
import javafx.beans.property.BooleanPropertyBase;
import javafx.css.StyleOrigin;
import javafx.geometry.Pos;
import javafx.css.StyleableProperty;
import javafx.scene.AccessibleRole;
import javafx.scene.Node;
import javafx.css.PseudoClass;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.BooleanProperty;

public class ToggleButton extends ButtonBase implements Toggle
{
    private BooleanProperty selected;
    private ObjectProperty<ToggleGroup> toggleGroup;
    private static final String DEFAULT_STYLE_CLASS = "toggle-button";
    private static final PseudoClass PSEUDO_CLASS_SELECTED;
    
    public ToggleButton() {
        this.initialize();
    }
    
    public ToggleButton(final String text) {
        this.setText(text);
        this.initialize();
    }
    
    public ToggleButton(final String text, final Node graphic) {
        this.setText(text);
        this.setGraphic(graphic);
        this.initialize();
    }
    
    private void initialize() {
        this.getStyleClass().setAll("toggle-button");
        this.setAccessibleRole(AccessibleRole.TOGGLE_BUTTON);
        ((StyleableProperty)this.alignmentProperty()).applyStyle(null, Pos.CENTER);
        this.setMnemonicParsing(true);
    }
    
    @Override
    public final void setSelected(final boolean b) {
        this.selectedProperty().set(b);
    }
    
    @Override
    public final boolean isSelected() {
        return this.selected != null && this.selected.get();
    }
    
    @Override
    public final BooleanProperty selectedProperty() {
        if (this.selected == null) {
            this.selected = new BooleanPropertyBase() {
                @Override
                protected void invalidated() {
                    final boolean value = this.get();
                    final ToggleGroup toggleGroup = ToggleButton.this.getToggleGroup();
                    ToggleButton.this.pseudoClassStateChanged(ToggleButton.PSEUDO_CLASS_SELECTED, value);
                    ToggleButton.this.notifyAccessibleAttributeChanged(AccessibleAttribute.SELECTED);
                    if (toggleGroup != null) {
                        if (value) {
                            toggleGroup.selectToggle(ToggleButton.this);
                        }
                        else if (toggleGroup.getSelectedToggle() == ToggleButton.this) {
                            toggleGroup.clearSelectedToggle();
                        }
                    }
                }
                
                @Override
                public Object getBean() {
                    return ToggleButton.this;
                }
                
                @Override
                public String getName() {
                    return "selected";
                }
            };
        }
        return this.selected;
    }
    
    @Override
    public final void setToggleGroup(final ToggleGroup toggleGroup) {
        this.toggleGroupProperty().set(toggleGroup);
    }
    
    @Override
    public final ToggleGroup getToggleGroup() {
        return (this.toggleGroup == null) ? null : this.toggleGroup.get();
    }
    
    @Override
    public final ObjectProperty<ToggleGroup> toggleGroupProperty() {
        if (this.toggleGroup == null) {
            this.toggleGroup = new ObjectPropertyBase<ToggleGroup>() {
                private ToggleGroup old;
                private ChangeListener<Toggle> listener = (p0, p1, toggle) -> ParentHelper.getTraversalEngine(ToggleButton.this).setOverriddenFocusTraversability((toggle != null) ? Boolean.valueOf(ToggleButton.this.isSelected()) : null);
                
                @Override
                protected void invalidated() {
                    final ToggleGroup old = this.get();
                    if (old != null && !old.getToggles().contains(ToggleButton.this)) {
                        if (this.old != null) {
                            this.old.getToggles().remove(ToggleButton.this);
                        }
                        old.getToggles().add(ToggleButton.this);
                        final ParentTraversalEngine parentTraversalEngine = new ParentTraversalEngine(ToggleButton.this);
                        ParentHelper.setTraversalEngine(ToggleButton.this, parentTraversalEngine);
                        parentTraversalEngine.setOverriddenFocusTraversability((old.getSelectedToggle() != null) ? Boolean.valueOf(ToggleButton.this.isSelected()) : null);
                        old.selectedToggleProperty().addListener(this.listener);
                    }
                    else if (old == null) {
                        this.old.selectedToggleProperty().removeListener(this.listener);
                        this.old.getToggles().remove(ToggleButton.this);
                        ParentHelper.setTraversalEngine(ToggleButton.this, null);
                    }
                    this.old = old;
                }
                
                @Override
                public Object getBean() {
                    return ToggleButton.this;
                }
                
                @Override
                public String getName() {
                    return "toggleGroup";
                }
            };
        }
        return this.toggleGroup;
    }
    
    @Override
    public void fire() {
        if (!this.isDisabled()) {
            this.setSelected(!this.isSelected());
            this.fireEvent(new ActionEvent());
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ToggleButtonSkin(this);
    }
    
    @Override
    protected Pos getInitialAlignment() {
        return Pos.CENTER;
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case SELECTED: {
                return this.isSelected();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        PSEUDO_CLASS_SELECTED = PseudoClass.getPseudoClass("selected");
    }
}
