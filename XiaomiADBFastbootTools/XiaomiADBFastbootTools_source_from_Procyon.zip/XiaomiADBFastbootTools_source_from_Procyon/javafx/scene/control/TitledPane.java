// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.scene.AccessibleAction;
import javafx.geometry.Orientation;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.TitledPaneSkin;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.AccessibleRole;
import javafx.css.CssMetaData;
import javafx.css.StyleableBooleanProperty;
import javafx.scene.AccessibleAttribute;
import javafx.beans.property.BooleanPropertyBase;
import javafx.css.PseudoClass;
import javafx.beans.property.BooleanProperty;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.DefaultProperty;

@DefaultProperty("content")
public class TitledPane extends Labeled
{
    private ObjectProperty<Node> content;
    private BooleanProperty expanded;
    private BooleanProperty animated;
    private BooleanProperty collapsible;
    private static final String DEFAULT_STYLE_CLASS = "titled-pane";
    private static final PseudoClass PSEUDO_CLASS_EXPANDED;
    private static final PseudoClass PSEUDO_CLASS_COLLAPSED;
    
    public TitledPane() {
        this.expanded = new BooleanPropertyBase(true) {
            @Override
            protected void invalidated() {
                final boolean value = this.get();
                TitledPane.this.pseudoClassStateChanged(TitledPane.PSEUDO_CLASS_EXPANDED, value);
                TitledPane.this.pseudoClassStateChanged(TitledPane.PSEUDO_CLASS_COLLAPSED, !value);
                TitledPane.this.notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED);
            }
            
            @Override
            public Object getBean() {
                return TitledPane.this;
            }
            
            @Override
            public String getName() {
                return "expanded";
            }
        };
        this.animated = new StyleableBooleanProperty(true) {
            @Override
            public Object getBean() {
                return TitledPane.this;
            }
            
            @Override
            public String getName() {
                return "animated";
            }
            
            @Override
            public CssMetaData<TitledPane, Boolean> getCssMetaData() {
                return StyleableProperties.ANIMATED;
            }
        };
        this.collapsible = new StyleableBooleanProperty(true) {
            @Override
            public Object getBean() {
                return TitledPane.this;
            }
            
            @Override
            public String getName() {
                return "collapsible";
            }
            
            @Override
            public CssMetaData<TitledPane, Boolean> getCssMetaData() {
                return StyleableProperties.COLLAPSIBLE;
            }
        };
        this.getStyleClass().setAll("titled-pane");
        this.setAccessibleRole(AccessibleRole.TITLED_PANE);
        this.pseudoClassStateChanged(TitledPane.PSEUDO_CLASS_EXPANDED, true);
    }
    
    public TitledPane(final String text, final Node content) {
        this();
        this.setText(text);
        this.setContent(content);
    }
    
    public final void setContent(final Node node) {
        this.contentProperty().set(node);
    }
    
    public final Node getContent() {
        return (this.content == null) ? null : this.content.get();
    }
    
    public final ObjectProperty<Node> contentProperty() {
        if (this.content == null) {
            this.content = new SimpleObjectProperty<Node>(this, "content");
        }
        return this.content;
    }
    
    public final void setExpanded(final boolean b) {
        this.expandedProperty().set(b);
    }
    
    public final boolean isExpanded() {
        return this.expanded.get();
    }
    
    public final BooleanProperty expandedProperty() {
        return this.expanded;
    }
    
    public final void setAnimated(final boolean b) {
        this.animatedProperty().set(b);
    }
    
    public final boolean isAnimated() {
        return this.animated.get();
    }
    
    public final BooleanProperty animatedProperty() {
        return this.animated;
    }
    
    public final void setCollapsible(final boolean b) {
        this.collapsibleProperty().set(b);
    }
    
    public final boolean isCollapsible() {
        return this.collapsible.get();
    }
    
    public final BooleanProperty collapsibleProperty() {
        return this.collapsible;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TitledPaneSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    public Orientation getContentBias() {
        final Node content = this.getContent();
        return (content == null) ? super.getContentBias() : content.getContentBias();
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case TEXT: {
                final String accessibleText = this.getAccessibleText();
                if (accessibleText != null && !accessibleText.isEmpty()) {
                    return accessibleText;
                }
                return this.getText();
            }
            case EXPANDED: {
                return this.isExpanded();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case EXPAND: {
                this.setExpanded(true);
                break;
            }
            case COLLAPSE: {
                this.setExpanded(false);
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, new Object[0]);
                break;
            }
        }
    }
    
    static {
        PSEUDO_CLASS_EXPANDED = PseudoClass.getPseudoClass("expanded");
        PSEUDO_CLASS_COLLAPSED = PseudoClass.getPseudoClass("collapsed");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TitledPane, Boolean> COLLAPSIBLE;
        private static final CssMetaData<TitledPane, Boolean> ANIMATED;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            COLLAPSIBLE = new CssMetaData<TitledPane, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final TitledPane titledPane) {
                    return titledPane.collapsible == null || !titledPane.collapsible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final TitledPane titledPane) {
                    return (StyleableProperty<Boolean>)titledPane.collapsibleProperty();
                }
            };
            ANIMATED = new CssMetaData<TitledPane, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final TitledPane titledPane) {
                    return titledPane.animated == null || !titledPane.animated.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final TitledPane titledPane) {
                    return (StyleableProperty<Boolean>)titledPane.animatedProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Labeled.getClassCssMetaData());
            list.add(StyleableProperties.COLLAPSIBLE);
            list.add(StyleableProperties.ANIMATED);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
