// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.Observable;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.skin.TreeTableCellSkin;
import javafx.event.EventTarget;
import javafx.event.Event;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.AccessibleRole;
import java.util.Collection;
import javafx.css.PseudoClass;
import java.lang.ref.WeakReference;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.WeakInvalidationListener;
import javafx.collections.WeakListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;

public class TreeTableCell<S, T> extends IndexedCell<T>
{
    boolean lockItemOnEdit;
    private boolean itemDirty;
    private ListChangeListener<TreeTablePosition<S, ?>> selectedListener;
    private final InvalidationListener focusedListener;
    private final InvalidationListener tableRowUpdateObserver;
    private final InvalidationListener editingListener;
    private ListChangeListener<TreeTableColumn<S, ?>> visibleLeafColumnsListener;
    private ListChangeListener<String> columnStyleClassListener;
    private final InvalidationListener rootPropertyListener;
    private final InvalidationListener columnStyleListener;
    private final InvalidationListener columnIdListener;
    private final WeakListChangeListener<TreeTablePosition<S, ?>> weakSelectedListener;
    private final WeakInvalidationListener weakFocusedListener;
    private final WeakInvalidationListener weaktableRowUpdateObserver;
    private final WeakInvalidationListener weakEditingListener;
    private final WeakListChangeListener<TreeTableColumn<S, ?>> weakVisibleLeafColumnsListener;
    private final WeakListChangeListener<String> weakColumnStyleClassListener;
    private final WeakInvalidationListener weakColumnStyleListener;
    private final WeakInvalidationListener weakColumnIdListener;
    private final WeakInvalidationListener weakRootPropertyListener;
    private ReadOnlyObjectWrapper<TreeTableColumn<S, T>> treeTableColumn;
    private ReadOnlyObjectWrapper<TreeTableView<S>> treeTableView;
    private ReadOnlyObjectWrapper<TreeTableRow<S>> treeTableRow;
    private boolean isLastVisibleColumn;
    private int columnIndex;
    private boolean updateEditingIndex;
    private ObservableValue<T> currentObservableValue;
    private boolean isFirstRun;
    private WeakReference<S> oldRowItemRef;
    private static final String DEFAULT_STYLE_CLASS = "tree-table-cell";
    private static final PseudoClass PSEUDO_CLASS_LAST_VISIBLE;
    
    public TreeTableCell() {
        this.lockItemOnEdit = false;
        this.itemDirty = false;
        this.selectedListener = (change -> {
            while (change.next()) {
                if (change.wasAdded() || change.wasRemoved()) {
                    this.updateSelection();
                }
            }
            return;
        });
        this.focusedListener = (p0 -> this.updateFocus());
        this.tableRowUpdateObserver = (p0 -> {
            this.itemDirty = true;
            this.requestLayout();
            return;
        });
        this.editingListener = (p0 -> this.updateEditing());
        this.visibleLeafColumnsListener = (p0 -> this.updateColumnIndex());
        this.columnStyleClassListener = (change2 -> {
            while (change2.next()) {
                if (change2.wasRemoved()) {
                    this.getStyleClass().removeAll(change2.getRemoved());
                }
                if (change2.wasAdded()) {
                    this.getStyleClass().addAll((Collection<?>)change2.getAddedSubList());
                }
            }
            return;
        });
        this.rootPropertyListener = (p0 -> this.updateItem(-1));
        this.columnStyleListener = (p0 -> {
            if (this.getTableColumn() != null) {
                this.possiblySetStyle(this.getTableColumn().getStyle());
            }
            return;
        });
        this.columnIdListener = (p0 -> {
            if (this.getTableColumn() != null) {
                this.possiblySetId(this.getTableColumn().getId());
            }
            return;
        });
        this.weakSelectedListener = new WeakListChangeListener<TreeTablePosition<S, ?>>(this.selectedListener);
        this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
        this.weaktableRowUpdateObserver = new WeakInvalidationListener(this.tableRowUpdateObserver);
        this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
        this.weakVisibleLeafColumnsListener = new WeakListChangeListener<TreeTableColumn<S, ?>>(this.visibleLeafColumnsListener);
        this.weakColumnStyleClassListener = new WeakListChangeListener<String>(this.columnStyleClassListener);
        this.weakColumnStyleListener = new WeakInvalidationListener(this.columnStyleListener);
        this.weakColumnIdListener = new WeakInvalidationListener(this.columnIdListener);
        this.weakRootPropertyListener = new WeakInvalidationListener(this.rootPropertyListener);
        this.treeTableColumn = new ReadOnlyObjectWrapper<TreeTableColumn<S, T>>((Object)this, "treeTableColumn") {
            @Override
            protected void invalidated() {
                TreeTableCell.this.updateColumnIndex();
            }
        };
        this.treeTableRow = new ReadOnlyObjectWrapper<TreeTableRow<S>>(this, "treeTableRow");
        this.isLastVisibleColumn = false;
        this.columnIndex = -1;
        this.updateEditingIndex = true;
        this.currentObservableValue = null;
        this.isFirstRun = true;
        this.getStyleClass().addAll("tree-table-cell");
        this.setAccessibleRole(AccessibleRole.TREE_TABLE_CELL);
        this.updateColumnIndex();
    }
    
    public final ReadOnlyObjectProperty<TreeTableColumn<S, T>> tableColumnProperty() {
        return this.treeTableColumn.getReadOnlyProperty();
    }
    
    private void setTableColumn(final TreeTableColumn<S, T> treeTableColumn) {
        this.treeTableColumn.set(treeTableColumn);
    }
    
    public final TreeTableColumn<S, T> getTableColumn() {
        return this.treeTableColumn.get();
    }
    
    private void setTreeTableView(final TreeTableView<S> treeTableView) {
        this.treeTableViewPropertyImpl().set(treeTableView);
    }
    
    public final TreeTableView<S> getTreeTableView() {
        return (this.treeTableView == null) ? null : this.treeTableView.get();
    }
    
    public final ReadOnlyObjectProperty<TreeTableView<S>> treeTableViewProperty() {
        return this.treeTableViewPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<TreeTableView<S>> treeTableViewPropertyImpl() {
        if (this.treeTableView == null) {
            this.treeTableView = new ReadOnlyObjectWrapper<TreeTableView<S>>(this, "treeTableView") {
                private WeakReference<TreeTableView<S>> weakTableViewRef;
                
                @Override
                protected void invalidated() {
                    if (this.weakTableViewRef != null) {
                        final TreeTableView treeTableView = this.weakTableViewRef.get();
                        if (treeTableView != null) {
                            final TreeTableView.TreeTableViewSelectionModel selectionModel = treeTableView.getSelectionModel();
                            if (selectionModel != null) {
                                selectionModel.getSelectedCells().removeListener(TreeTableCell.this.weakSelectedListener);
                            }
                            final TreeTableView.TreeTableViewFocusModel focusModel = treeTableView.getFocusModel();
                            if (focusModel != null) {
                                focusModel.focusedCellProperty().removeListener(TreeTableCell.this.weakFocusedListener);
                            }
                            treeTableView.editingCellProperty().removeListener(TreeTableCell.this.weakEditingListener);
                            treeTableView.getVisibleLeafColumns().removeListener(TreeTableCell.this.weakVisibleLeafColumnsListener);
                            treeTableView.rootProperty().removeListener(TreeTableCell.this.weakRootPropertyListener);
                        }
                    }
                    final TreeTableView<S> referent = this.get();
                    if (referent != null) {
                        final TreeTableView.TreeTableViewSelectionModel<S> selectionModel2 = referent.getSelectionModel();
                        if (selectionModel2 != null) {
                            selectionModel2.getSelectedCells().addListener(TreeTableCell.this.weakSelectedListener);
                        }
                        final TreeTableView.TreeTableViewFocusModel<S> focusModel2 = referent.getFocusModel();
                        if (focusModel2 != null) {
                            focusModel2.focusedCellProperty().addListener(TreeTableCell.this.weakFocusedListener);
                        }
                        referent.editingCellProperty().addListener(TreeTableCell.this.weakEditingListener);
                        referent.getVisibleLeafColumns().addListener(TreeTableCell.this.weakVisibleLeafColumnsListener);
                        referent.rootProperty().addListener(TreeTableCell.this.weakRootPropertyListener);
                        this.weakTableViewRef = new WeakReference<TreeTableView<S>>(referent);
                    }
                    TreeTableCell.this.updateColumnIndex();
                }
            };
        }
        return this.treeTableView;
    }
    
    private void setTreeTableRow(final TreeTableRow<S> treeTableRow) {
        this.treeTableRow.set(treeTableRow);
    }
    
    public final TreeTableRow<S> getTreeTableRow() {
        return this.treeTableRow.get();
    }
    
    public final ReadOnlyObjectProperty<TreeTableRow<S>> tableRowProperty() {
        return this.treeTableRow;
    }
    
    @Override
    public void startEdit() {
        if (this.isEditing()) {
            return;
        }
        final TreeTableView<?> treeTableView = this.getTreeTableView();
        final TreeTableColumn<S, T> tableColumn = this.getTableColumn();
        if (!this.isEditable() || (treeTableView != null && !treeTableView.isEditable()) || (tableColumn != null && !this.getTableColumn().isEditable())) {
            return;
        }
        if (!this.lockItemOnEdit) {
            this.updateItem(-1);
        }
        super.startEdit();
        if (tableColumn != null) {
            Event.fireEvent(tableColumn, new TreeTableColumn.CellEditEvent<Object, Object>(treeTableView, treeTableView.getEditingCell(), TreeTableColumn.editStartEvent(), null));
        }
    }
    
    @Override
    public void commitEdit(final T t) {
        if (!this.isEditing()) {
            return;
        }
        final TreeTableView<?> treeTableView = this.getTreeTableView();
        if (treeTableView != null) {
            Event.fireEvent(this.getTableColumn(), new TreeTableColumn.CellEditEvent<Object, Object>((TreeTableView<Object>)treeTableView, (TreeTablePosition<Object, Object>)treeTableView.getEditingCell(), TreeTableColumn.editCommitEvent(), t));
        }
        super.commitEdit(t);
        this.updateItem(t, false);
        if (treeTableView != null) {
            treeTableView.edit(-1, null);
            ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(treeTableView);
        }
    }
    
    @Override
    public void cancelEdit() {
        if (!this.isEditing()) {
            return;
        }
        final TreeTableView<Object> treeTableView = this.getTreeTableView();
        super.cancelEdit();
        if (treeTableView != null) {
            final TreeTablePosition<Object, ?> editingCell = treeTableView.getEditingCell();
            if (this.updateEditingIndex) {
                treeTableView.edit(-1, null);
            }
            ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(treeTableView);
            Event.fireEvent(this.getTableColumn(), new TreeTableColumn.CellEditEvent<Object, Object>(treeTableView, (TreeTablePosition<Object, Object>)editingCell, TreeTableColumn.editCancelEvent(), null));
        }
    }
    
    @Override
    public void updateSelected(final boolean selected) {
        if (this.getTreeTableRow() == null || this.getTreeTableRow().isEmpty()) {
            return;
        }
        this.setSelected(selected);
    }
    
    @Override
    void indexChanged(final int n, final int n2) {
        super.indexChanged(n, n2);
        if (!this.isEditing() || n2 != n) {
            this.updateItem(n);
            this.updateSelection();
            this.updateFocus();
            this.updateEditing();
        }
    }
    
    private void updateColumnIndex() {
        final TreeTableView<S> treeTableView = this.getTreeTableView();
        final TreeTableColumn<S, ?> tableColumn = this.getTableColumn();
        this.columnIndex = ((treeTableView == null || tableColumn == null) ? -1 : treeTableView.getVisibleLeafIndex(tableColumn));
        this.isLastVisibleColumn = (this.getTableColumn() != null && this.columnIndex != -1 && this.columnIndex == treeTableView.getVisibleLeafColumns().size() - 1);
        this.pseudoClassStateChanged(TreeTableCell.PSEUDO_CLASS_LAST_VISIBLE, this.isLastVisibleColumn);
    }
    
    private void updateSelection() {
        if (this.isEmpty()) {
            return;
        }
        final boolean selected = this.isSelected();
        if (!this.isInCellSelectionMode()) {
            if (selected) {
                this.updateSelected(false);
            }
            return;
        }
        final TreeTableView<?> treeTableView = this.getTreeTableView();
        if (this.getIndex() == -1 || treeTableView == null) {
            return;
        }
        final TreeTableView.TreeTableViewSelectionModel<?> selectionModel = treeTableView.getSelectionModel();
        if (selectionModel == null) {
            this.updateSelected(false);
            return;
        }
        final boolean selected2 = selectionModel.isSelected(this.getIndex(), (TableColumnBase<?, ?>)this.getTableColumn());
        if (selected == selected2) {
            return;
        }
        this.updateSelected(selected2);
    }
    
    private void updateFocus() {
        final boolean focused = this.isFocused();
        if (!this.isInCellSelectionMode()) {
            if (focused) {
                this.setFocused(false);
            }
            return;
        }
        final TreeTableView<S> treeTableView = this.getTreeTableView();
        if (this.getIndex() == -1 || treeTableView == null) {
            return;
        }
        final TreeTableView.TreeTableViewFocusModel<S> focusModel = treeTableView.getFocusModel();
        if (focusModel == null) {
            this.setFocused(false);
            return;
        }
        this.setFocused(focusModel.isFocused(this.getIndex(), this.getTableColumn()));
    }
    
    private void updateEditing() {
        final TreeTableView<S> treeTableView = this.getTreeTableView();
        if (this.getIndex() == -1 || treeTableView == null) {
            return;
        }
        final boolean match = this.match(treeTableView.getEditingCell());
        if (match && !this.isEditing()) {
            this.startEdit();
        }
        else if (!match && this.isEditing()) {
            this.updateEditingIndex = false;
            this.cancelEdit();
            this.updateEditingIndex = true;
        }
    }
    
    private boolean match(final TreeTablePosition treeTablePosition) {
        return treeTablePosition != null && treeTablePosition.getRow() == this.getIndex() && treeTablePosition.getTableColumn() == this.getTableColumn();
    }
    
    private boolean isInCellSelectionMode() {
        final TreeTableView<S> treeTableView = this.getTreeTableView();
        if (treeTableView == null) {
            return false;
        }
        final TreeTableView.TreeTableViewSelectionModel<S> selectionModel = treeTableView.getSelectionModel();
        return selectionModel != null && selectionModel.isCellSelectionEnabled();
    }
    
    private void updateItem(final int n) {
        if (this.currentObservableValue != null) {
            this.currentObservableValue.removeListener(this.weaktableRowUpdateObserver);
        }
        final TreeTableView<S> treeTableView = this.getTreeTableView();
        final TreeTableColumn<S, T> tableColumn = this.getTableColumn();
        final int n2 = (treeTableView == null) ? -1 : this.getTreeTableView().getExpandedItemCount();
        final int index = this.getIndex();
        final boolean empty = this.isEmpty();
        final T item = this.getItem();
        final TreeTableRow<S> treeTableRow = this.getTreeTableRow();
        final S n3 = (treeTableRow == null) ? null : treeTableRow.getItem();
        final boolean b = index >= n2;
        if (b || index < 0 || this.columnIndex < 0 || !this.isVisible() || tableColumn == null || !tableColumn.isVisible() || treeTableView.getRoot() == null) {
            if ((!empty && item != null) || this.isFirstRun || b) {
                this.updateItem(null, true);
                this.isFirstRun = false;
            }
            return;
        }
        this.currentObservableValue = tableColumn.getCellObservableValue(index);
        final T t = (this.currentObservableValue == null) ? null : this.currentObservableValue.getValue();
        Label_0271: {
            if (n == index && !this.isItemChanged(item, t)) {
                final Object o = (this.oldRowItemRef != null) ? this.oldRowItemRef.get() : null;
                if (o != null && o.equals(n3)) {
                    break Label_0271;
                }
            }
            this.updateItem(t, false);
        }
        this.oldRowItemRef = new WeakReference<S>(n3);
        if (this.currentObservableValue == null) {
            return;
        }
        this.currentObservableValue.addListener(this.weaktableRowUpdateObserver);
    }
    
    @Override
    protected void layoutChildren() {
        if (this.itemDirty) {
            this.updateItem(-1);
            this.itemDirty = false;
        }
        super.layoutChildren();
    }
    
    public final void updateTreeTableView(final TreeTableView<S> treeTableView) {
        this.setTreeTableView(treeTableView);
    }
    
    public final void updateTreeTableRow(final TreeTableRow<S> treeTableRow) {
        this.setTreeTableRow(treeTableRow);
    }
    
    public final void updateTreeTableColumn(final TreeTableColumn<S, T> tableColumn) {
        final TreeTableColumn<S, T> tableColumn2 = this.getTableColumn();
        if (tableColumn2 != null) {
            tableColumn2.getStyleClass().removeListener(this.weakColumnStyleClassListener);
            this.getStyleClass().removeAll(tableColumn2.getStyleClass());
            tableColumn2.idProperty().removeListener(this.weakColumnIdListener);
            tableColumn2.styleProperty().removeListener(this.weakColumnStyleListener);
            final String id = this.getId();
            final String style = this.getStyle();
            if (id != null && id.equals(tableColumn2.getId())) {
                this.setId(null);
            }
            if (style != null && style.equals(tableColumn2.getStyle())) {
                this.setStyle("");
            }
        }
        this.setTableColumn(tableColumn);
        if (tableColumn != null) {
            this.getStyleClass().addAll((Collection<?>)tableColumn.getStyleClass());
            tableColumn.getStyleClass().addListener(this.weakColumnStyleClassListener);
            tableColumn.idProperty().addListener(this.weakColumnIdListener);
            tableColumn.styleProperty().addListener(this.weakColumnStyleListener);
            this.possiblySetId(tableColumn.getId());
            this.possiblySetStyle(tableColumn.getStyle());
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TreeTableCellSkin<Object, Object>(this);
    }
    
    private void possiblySetId(final String id) {
        if (this.getId() == null || this.getId().isEmpty()) {
            this.setId(id);
        }
    }
    
    private void possiblySetStyle(final String style) {
        if (this.getStyle() == null || this.getStyle().isEmpty()) {
            this.setStyle(style);
        }
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case ROW_INDEX: {
                return this.getIndex();
            }
            case COLUMN_INDEX: {
                return this.columnIndex;
            }
            case SELECTED: {
                return this.isInCellSelectionMode() ? this.isSelected() : this.getTreeTableRow().isSelected();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case REQUEST_FOCUS: {
                final TreeTableView<S> treeTableView = this.getTreeTableView();
                if (treeTableView != null) {
                    final TreeTableView.TreeTableViewFocusModel<S> focusModel = treeTableView.getFocusModel();
                    if (focusModel != null) {
                        focusModel.focus(this.getIndex(), this.getTableColumn());
                    }
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    static {
        PSEUDO_CLASS_LAST_VISIBLE = PseudoClass.getPseudoClass("last-visible");
    }
}
