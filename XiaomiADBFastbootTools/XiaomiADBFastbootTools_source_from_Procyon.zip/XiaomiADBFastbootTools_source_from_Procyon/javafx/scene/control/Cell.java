// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.Observable;
import javafx.beans.InvalidationListener;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.PseudoClass;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.ObjectProperty;

public class Cell<T> extends Labeled
{
    private ObjectProperty<T> item;
    private ReadOnlyBooleanWrapper empty;
    private ReadOnlyBooleanWrapper selected;
    private ReadOnlyBooleanWrapper editing;
    private BooleanProperty editable;
    private boolean itemDirty;
    private static final String DEFAULT_STYLE_CLASS = "cell";
    private static final PseudoClass PSEUDO_CLASS_SELECTED;
    private static final PseudoClass PSEUDO_CLASS_FOCUSED;
    private static final PseudoClass PSEUDO_CLASS_EMPTY;
    private static final PseudoClass PSEUDO_CLASS_FILLED;
    
    public Cell() {
        this.item = new SimpleObjectProperty<T>(this, "item");
        this.empty = new ReadOnlyBooleanWrapper(true) {
            @Override
            protected void invalidated() {
                final boolean value = this.get();
                Cell.this.pseudoClassStateChanged(Cell.PSEUDO_CLASS_EMPTY, value);
                Cell.this.pseudoClassStateChanged(Cell.PSEUDO_CLASS_FILLED, !value);
            }
            
            @Override
            public Object getBean() {
                return Cell.this;
            }
            
            @Override
            public String getName() {
                return "empty";
            }
        };
        this.selected = new ReadOnlyBooleanWrapper() {
            @Override
            protected void invalidated() {
                Cell.this.pseudoClassStateChanged(Cell.PSEUDO_CLASS_SELECTED, this.get());
            }
            
            @Override
            public Object getBean() {
                return Cell.this;
            }
            
            @Override
            public String getName() {
                return "selected";
            }
        };
        this.itemDirty = false;
        this.setText(null);
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
        this.getStyleClass().addAll("cell");
        super.focusedProperty().addListener(new InvalidationListener() {
            @Override
            public void invalidated(final Observable observable) {
                Cell.this.pseudoClassStateChanged(Cell.PSEUDO_CLASS_FOCUSED, Cell.this.isFocused());
                if (!Cell.this.isFocused() && Cell.this.isEditing()) {
                    Cell.this.cancelEdit();
                }
            }
        });
        this.pseudoClassStateChanged(Cell.PSEUDO_CLASS_EMPTY, true);
    }
    
    public final ObjectProperty<T> itemProperty() {
        return this.item;
    }
    
    public final void setItem(final T t) {
        this.item.set(t);
    }
    
    public final T getItem() {
        return this.item.get();
    }
    
    public final ReadOnlyBooleanProperty emptyProperty() {
        return this.empty.getReadOnlyProperty();
    }
    
    private void setEmpty(final boolean b) {
        this.empty.set(b);
    }
    
    public final boolean isEmpty() {
        return this.empty.get();
    }
    
    public final ReadOnlyBooleanProperty selectedProperty() {
        return this.selected.getReadOnlyProperty();
    }
    
    void setSelected(final boolean b) {
        this.selected.set(b);
    }
    
    public final boolean isSelected() {
        return this.selected.get();
    }
    
    private void setEditing(final boolean b) {
        this.editingPropertyImpl().set(b);
    }
    
    public final boolean isEditing() {
        return this.editing != null && this.editing.get();
    }
    
    public final ReadOnlyBooleanProperty editingProperty() {
        return this.editingPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper editingPropertyImpl() {
        if (this.editing == null) {
            this.editing = new ReadOnlyBooleanWrapper(this, "editing");
        }
        return this.editing;
    }
    
    public final void setEditable(final boolean b) {
        this.editableProperty().set(b);
    }
    
    public final boolean isEditable() {
        return this.editable == null || this.editable.get();
    }
    
    public final BooleanProperty editableProperty() {
        if (this.editable == null) {
            this.editable = new SimpleBooleanProperty(this, "editable", true);
        }
        return this.editable;
    }
    
    public void startEdit() {
        if (this.isEditable() && !this.isEditing() && !this.isEmpty()) {
            this.setEditing(true);
        }
    }
    
    public void cancelEdit() {
        if (this.isEditing()) {
            this.setEditing(false);
        }
    }
    
    public void commitEdit(final T t) {
        if (this.isEditing()) {
            this.setEditing(false);
        }
    }
    
    @Override
    protected void layoutChildren() {
        if (this.itemDirty) {
            this.updateItem(this.getItem(), this.isEmpty());
            this.itemDirty = false;
        }
        super.layoutChildren();
    }
    
    protected void updateItem(final T item, final boolean empty) {
        this.setItem(item);
        this.setEmpty(empty);
        if (empty && this.isSelected()) {
            this.updateSelected(false);
        }
    }
    
    public void updateSelected(final boolean selected) {
        if (selected && this.isEmpty()) {
            return;
        }
        final boolean selected2 = this.isSelected();
        this.setSelected(selected);
        if (selected2 != selected) {
            this.markCellDirty();
        }
    }
    
    protected boolean isItemChanged(final T t, final T obj) {
        return (t != null) ? (!t.equals(obj)) : (obj != null);
    }
    
    private final void markCellDirty() {
        this.itemDirty = true;
        this.requestLayout();
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    static {
        PSEUDO_CLASS_SELECTED = PseudoClass.getPseudoClass("selected");
        PSEUDO_CLASS_FOCUSED = PseudoClass.getPseudoClass("focused");
        PSEUDO_CLASS_EMPTY = PseudoClass.getPseudoClass("empty");
        PSEUDO_CLASS_FILLED = PseudoClass.getPseudoClass("filled");
    }
}
