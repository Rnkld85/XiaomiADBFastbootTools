// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.control.skin.ButtonSkin;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.beans.property.BooleanPropertyBase;
import javafx.scene.AccessibleRole;
import javafx.scene.Node;
import javafx.css.PseudoClass;
import javafx.beans.property.BooleanProperty;

public class Button extends ButtonBase
{
    private BooleanProperty defaultButton;
    private BooleanProperty cancelButton;
    private static final String DEFAULT_STYLE_CLASS = "button";
    private static final PseudoClass PSEUDO_CLASS_DEFAULT;
    private static final PseudoClass PSEUDO_CLASS_CANCEL;
    
    public Button() {
        this.initialize();
    }
    
    public Button(final String s) {
        super(s);
        this.initialize();
    }
    
    public Button(final String s, final Node node) {
        super(s, node);
        this.initialize();
    }
    
    private void initialize() {
        this.getStyleClass().setAll("button");
        this.setAccessibleRole(AccessibleRole.BUTTON);
        this.setMnemonicParsing(true);
    }
    
    public final void setDefaultButton(final boolean b) {
        this.defaultButtonProperty().set(b);
    }
    
    public final boolean isDefaultButton() {
        return this.defaultButton != null && this.defaultButton.get();
    }
    
    public final BooleanProperty defaultButtonProperty() {
        if (this.defaultButton == null) {
            this.defaultButton = new BooleanPropertyBase(false) {
                @Override
                protected void invalidated() {
                    Button.this.pseudoClassStateChanged(Button.PSEUDO_CLASS_DEFAULT, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Button.this;
                }
                
                @Override
                public String getName() {
                    return "defaultButton";
                }
            };
        }
        return this.defaultButton;
    }
    
    public final void setCancelButton(final boolean b) {
        this.cancelButtonProperty().set(b);
    }
    
    public final boolean isCancelButton() {
        return this.cancelButton != null && this.cancelButton.get();
    }
    
    public final BooleanProperty cancelButtonProperty() {
        if (this.cancelButton == null) {
            this.cancelButton = new BooleanPropertyBase(false) {
                @Override
                protected void invalidated() {
                    Button.this.pseudoClassStateChanged(Button.PSEUDO_CLASS_CANCEL, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Button.this;
                }
                
                @Override
                public String getName() {
                    return "cancelButton";
                }
            };
        }
        return this.cancelButton;
    }
    
    @Override
    public void fire() {
        if (!this.isDisabled()) {
            this.fireEvent(new ActionEvent());
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ButtonSkin(this);
    }
    
    static {
        PSEUDO_CLASS_DEFAULT = PseudoClass.getPseudoClass("default");
        PSEUDO_CLASS_CANCEL = PseudoClass.getPseudoClass("cancel");
    }
}
