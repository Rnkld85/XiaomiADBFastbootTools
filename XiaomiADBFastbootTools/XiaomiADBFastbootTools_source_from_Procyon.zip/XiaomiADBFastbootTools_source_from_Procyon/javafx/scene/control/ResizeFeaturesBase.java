// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.NamedArg;

public class ResizeFeaturesBase<S>
{
    private final TableColumnBase<S, ?> column;
    private final Double delta;
    
    public ResizeFeaturesBase(@NamedArg("column") final TableColumnBase<S, ?> column, @NamedArg("delta") final Double delta) {
        this.column = column;
        this.delta = delta;
    }
    
    public TableColumnBase<S, ?> getColumn() {
        return this.column;
    }
    
    public Double getDelta() {
        return this.delta;
    }
}
