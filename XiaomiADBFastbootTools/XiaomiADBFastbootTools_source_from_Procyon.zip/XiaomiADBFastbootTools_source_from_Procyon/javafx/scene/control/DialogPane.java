// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.scene.layout.Region;
import javafx.css.StyleConverter;
import javafx.css.converter.StringConverter;
import javafx.collections.ListChangeListener;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.layout.Priority;
import javafx.scene.layout.ColumnConstraints;
import javafx.geometry.Pos;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import com.sun.javafx.css.StyleManager;
import javafx.scene.image.ImageView;
import javafx.css.StyleableProperty;
import javafx.css.StyleOrigin;
import java.util.Iterator;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.CssMetaData;
import java.lang.ref.WeakReference;
import javafx.css.StyleableObjectProperty;
import java.util.WeakHashMap;
import javafx.collections.FXCollections;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.css.StyleableStringProperty;
import javafx.beans.property.ObjectProperty;
import java.util.Map;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.GridPane;
import javafx.beans.DefaultProperty;
import javafx.scene.layout.Pane;

@DefaultProperty("buttonTypes")
public class DialogPane extends Pane
{
    private final GridPane headerTextPanel;
    private final Label contentLabel;
    private final StackPane graphicContainer;
    private final Node buttonBar;
    private final ObservableList<ButtonType> buttons;
    private final Map<ButtonType, Node> buttonNodes;
    private Node detailsButton;
    private Dialog<?> dialog;
    private final ObjectProperty<Node> graphicProperty;
    private StyleableStringProperty imageUrl;
    private final ObjectProperty<Node> header;
    private final StringProperty headerText;
    private final ObjectProperty<Node> content;
    private final StringProperty contentText;
    private final ObjectProperty<Node> expandableContentProperty;
    private final BooleanProperty expandedProperty;
    private double oldHeight;
    
    static Label createContentLabel(final String s) {
        final Label label = new Label(s);
        label.setMaxWidth(Double.MAX_VALUE);
        label.setMaxHeight(Double.MAX_VALUE);
        label.getStyleClass().add("content");
        label.setWrapText(true);
        label.setPrefWidth(360.0);
        return label;
    }
    
    public DialogPane() {
        this.buttons = FXCollections.observableArrayList();
        this.buttonNodes = new WeakHashMap<ButtonType, Node>();
        this.graphicProperty = new StyleableObjectProperty<Node>() {
            WeakReference<Node> graphicRef = new WeakReference<Node>(null);
            
            @Override
            public CssMetaData getCssMetaData() {
                return StyleableProperties.GRAPHIC;
            }
            
            @Override
            public Object getBean() {
                return DialogPane.this;
            }
            
            @Override
            public String getName() {
                return "graphic";
            }
            
            @Override
            protected void invalidated() {
                final Node node = this.graphicRef.get();
                if (node != null) {
                    DialogPane.this.getChildren().remove(node);
                }
                this.graphicRef = new WeakReference<Node>(DialogPane.this.getGraphic());
                DialogPane.this.updateHeaderArea();
            }
        };
        this.imageUrl = null;
        this.header = new SimpleObjectProperty<Node>((Node)null) {
            WeakReference<Node> headerRef = new WeakReference<Node>(null);
            
            @Override
            protected void invalidated() {
                final Node node = this.headerRef.get();
                if (node != null) {
                    DialogPane.this.getChildren().remove(node);
                }
                this.headerRef = new WeakReference<Node>(DialogPane.this.getHeader());
                DialogPane.this.updateHeaderArea();
            }
        };
        this.headerText = new SimpleStringProperty((Object)this, "headerText") {
            @Override
            protected void invalidated() {
                DialogPane.this.updateHeaderArea();
                DialogPane.this.requestLayout();
            }
        };
        this.content = new SimpleObjectProperty<Node>((Node)null) {
            WeakReference<Node> contentRef = new WeakReference<Node>(null);
            
            @Override
            protected void invalidated() {
                final Node node = this.contentRef.get();
                if (node != null) {
                    DialogPane.this.getChildren().remove(node);
                }
                this.contentRef = new WeakReference<Node>(DialogPane.this.getContent());
                DialogPane.this.updateContentArea();
            }
        };
        this.contentText = new SimpleStringProperty((Object)this, "contentText") {
            @Override
            protected void invalidated() {
                DialogPane.this.updateContentArea();
                DialogPane.this.requestLayout();
            }
        };
        this.expandableContentProperty = new SimpleObjectProperty<Node>((Node)null) {
            WeakReference<Node> expandableContentRef = new WeakReference<Node>(null);
            
            @Override
            protected void invalidated() {
                final Node node = this.expandableContentRef.get();
                if (node != null) {
                    DialogPane.this.getChildren().remove(node);
                }
                final Node expandableContent = DialogPane.this.getExpandableContent();
                this.expandableContentRef = new WeakReference<Node>(expandableContent);
                if (expandableContent != null) {
                    expandableContent.setVisible(DialogPane.this.isExpanded());
                    expandableContent.setManaged(DialogPane.this.isExpanded());
                    if (!expandableContent.getStyleClass().contains("expandable-content")) {
                        expandableContent.getStyleClass().add("expandable-content");
                    }
                    DialogPane.this.getChildren().add(expandableContent);
                }
            }
        };
        this.expandedProperty = new SimpleBooleanProperty((Object)this, "expanded", false) {
            @Override
            protected void invalidated() {
                final Node expandableContent = DialogPane.this.getExpandableContent();
                if (expandableContent != null) {
                    expandableContent.setVisible(DialogPane.this.isExpanded());
                }
                DialogPane.this.requestLayout();
            }
        };
        this.oldHeight = -1.0;
        this.getStyleClass().add("dialog-pane");
        this.headerTextPanel = new GridPane();
        this.getChildren().add(this.headerTextPanel);
        this.graphicContainer = new StackPane();
        this.contentLabel = createContentLabel("");
        this.getChildren().add(this.contentLabel);
        this.buttonBar = this.createButtonBar();
        if (this.buttonBar != null) {
            this.getChildren().add(this.buttonBar);
        }
        final Iterator<ButtonType> iterator;
        final Iterator<ButtonType> iterator2;
        ButtonType buttonType;
        this.buttons.addListener(change -> {
            while (change.next()) {
                if (change.wasRemoved()) {
                    change.getRemoved().iterator();
                    while (iterator.hasNext()) {
                        this.buttonNodes.remove(iterator.next());
                    }
                }
                if (change.wasAdded()) {
                    change.getAddedSubList().iterator();
                    while (iterator2.hasNext()) {
                        buttonType = iterator2.next();
                        if (!this.buttonNodes.containsKey(buttonType)) {
                            this.buttonNodes.put(buttonType, this.createButton(buttonType));
                        }
                    }
                }
            }
        });
    }
    
    public final ObjectProperty<Node> graphicProperty() {
        return this.graphicProperty;
    }
    
    public final Node getGraphic() {
        return this.graphicProperty.get();
    }
    
    public final void setGraphic(final Node node) {
        this.graphicProperty.set(node);
    }
    
    private StyleableStringProperty imageUrlProperty() {
        if (this.imageUrl == null) {
            this.imageUrl = new StyleableStringProperty() {
                StyleOrigin origin = StyleOrigin.USER;
                
                @Override
                public void applyStyle(final StyleOrigin origin, final String s) {
                    this.origin = origin;
                    if (DialogPane.this.graphicProperty == null || !DialogPane.this.graphicProperty.isBound()) {
                        super.applyStyle(origin, s);
                    }
                    this.origin = StyleOrigin.USER;
                }
                
                @Override
                protected void invalidated() {
                    final String value = super.get();
                    if (value == null) {
                        ((StyleableProperty)DialogPane.this.graphicProperty()).applyStyle(this.origin, null);
                    }
                    else {
                        final Node graphic = DialogPane.this.getGraphic();
                        if (graphic instanceof ImageView) {
                            final Image image = ((ImageView)graphic).getImage();
                            if (image != null && value.equals(image.getUrl())) {
                                return;
                            }
                        }
                        final Image cachedImage = StyleManager.getInstance().getCachedImage(value);
                        if (cachedImage != null) {
                            ((StyleableProperty)DialogPane.this.graphicProperty()).applyStyle(this.origin, new ImageView(cachedImage));
                        }
                    }
                }
                
                @Override
                public String get() {
                    final Node graphic = DialogPane.this.getGraphic();
                    if (graphic instanceof ImageView) {
                        final Image image = ((ImageView)graphic).getImage();
                        if (image != null) {
                            return image.getUrl();
                        }
                    }
                    return null;
                }
                
                @Override
                public StyleOrigin getStyleOrigin() {
                    return (DialogPane.this.graphicProperty != null) ? ((StyleableProperty)DialogPane.this.graphicProperty).getStyleOrigin() : null;
                }
                
                @Override
                public Object getBean() {
                    return DialogPane.this;
                }
                
                @Override
                public String getName() {
                    return "imageUrl";
                }
                
                @Override
                public CssMetaData<DialogPane, String> getCssMetaData() {
                    return StyleableProperties.GRAPHIC;
                }
            };
        }
        return this.imageUrl;
    }
    
    public final Node getHeader() {
        return this.header.get();
    }
    
    public final void setHeader(final Node value) {
        this.header.setValue(value);
    }
    
    public final ObjectProperty<Node> headerProperty() {
        return this.header;
    }
    
    public final void setHeaderText(final String s) {
        this.headerText.set(s);
    }
    
    public final String getHeaderText() {
        return this.headerText.get();
    }
    
    public final StringProperty headerTextProperty() {
        return this.headerText;
    }
    
    public final Node getContent() {
        return this.content.get();
    }
    
    public final void setContent(final Node value) {
        this.content.setValue(value);
    }
    
    public final ObjectProperty<Node> contentProperty() {
        return this.content;
    }
    
    public final void setContentText(final String s) {
        this.contentText.set(s);
    }
    
    public final String getContentText() {
        return this.contentText.get();
    }
    
    public final StringProperty contentTextProperty() {
        return this.contentText;
    }
    
    public final ObjectProperty<Node> expandableContentProperty() {
        return this.expandableContentProperty;
    }
    
    public final Node getExpandableContent() {
        return this.expandableContentProperty.get();
    }
    
    public final void setExpandableContent(final Node node) {
        this.expandableContentProperty.set(node);
    }
    
    public final BooleanProperty expandedProperty() {
        return this.expandedProperty;
    }
    
    public final boolean isExpanded() {
        return this.expandedProperty().get();
    }
    
    public final void setExpanded(final boolean b) {
        this.expandedProperty().set(b);
    }
    
    public final ObservableList<ButtonType> getButtonTypes() {
        return this.buttons;
    }
    
    public final Node lookupButton(final ButtonType buttonType) {
        return this.buttonNodes.get(buttonType);
    }
    
    protected Node createButtonBar() {
        final ButtonBar buttonBar = new ButtonBar();
        buttonBar.setMaxWidth(Double.MAX_VALUE);
        this.updateButtons(buttonBar);
        this.getButtonTypes().addListener(p1 -> this.updateButtons(buttonBar));
        this.expandableContentProperty().addListener(p1 -> this.updateButtons(buttonBar));
        return buttonBar;
    }
    
    protected Node createButton(final ButtonType buttonType) {
        final Button button = new Button(buttonType.getText());
        final ButtonBar.ButtonData buttonData = buttonType.getButtonData();
        ButtonBar.setButtonData(button, buttonData);
        button.setDefaultButton(buttonData.isDefaultButton());
        button.setCancelButton(buttonData.isCancelButton());
        button.addEventHandler(ActionEvent.ACTION, actionEvent -> {
            if (actionEvent.isConsumed()) {
                return;
            }
            else {
                if (this.dialog != null) {
                    this.dialog.setResultAndClose(buttonType, (boolean)(1 != 0));
                }
                return;
            }
        });
        return button;
    }
    
    protected Node createDetailsButton() {
        final Hyperlink hyperlink = new Hyperlink();
        final Labeled labeled;
        final boolean b;
        final String s;
        final String s2;
        final InvalidationListener invalidationListener = p3 -> {
            ControlResources.getString("Dialog.detail.button.less");
            ControlResources.getString("Dialog.detail.button.more");
            this.isExpanded();
            labeled.setText(b ? s : s2);
            labeled.getStyleClass().setAll("details-button", b ? "less" : "more");
            return;
        };
        invalidationListener.invalidated(null);
        this.expandedProperty().addListener(invalidationListener);
        hyperlink.setOnAction(p0 -> this.setExpanded(!this.isExpanded()));
        return hyperlink;
    }
    
    @Override
    protected void layoutChildren() {
        final boolean hasHeader = this.hasHeader();
        final double max = Math.max(this.minWidth(-1.0), this.getWidth());
        final double minHeight = this.minHeight(max);
        final double prefHeight = this.prefHeight(max);
        final double maxHeight = this.maxHeight(max);
        final double height = this.getHeight();
        final double n = (this.dialog == null) ? 0.0 : this.dialog.dialog.getSceneHeight();
        double n2;
        if (prefHeight > height && prefHeight > minHeight && (prefHeight <= n || n == 0.0)) {
            n2 = prefHeight;
            this.resize(max, n2);
        }
        else {
            if (height > this.oldHeight) {
                n2 = Utils.boundedSize((height < prefHeight) ? Math.min(prefHeight, height) : Math.max(prefHeight, n), minHeight, maxHeight);
            }
            else {
                n2 = Utils.boundedSize(Math.min(height, n), minHeight, maxHeight);
            }
            this.resize(max, n2);
        }
        final double oldHeight = n2 - (this.snappedTopInset() + this.snappedBottomInset());
        this.oldHeight = oldHeight;
        final double snappedLeftInset = this.snappedLeftInset();
        final double snappedTopInset = this.snappedTopInset();
        final double snappedRightInset = this.snappedRightInset();
        final Node actualHeader = this.getActualHeader();
        final Node actualContent = this.getActualContent();
        final Node actualGraphic = this.getActualGraphic();
        final Node expandableContent = this.getExpandableContent();
        final double n3 = (hasHeader || actualGraphic == null) ? 0.0 : actualGraphic.prefWidth(-1.0);
        final double n4 = hasHeader ? actualHeader.prefHeight(max) : 0.0;
        final double n5 = (this.buttonBar == null) ? 0.0 : this.buttonBar.prefHeight(max);
        final double n6 = (hasHeader || actualGraphic == null) ? 0.0 : actualGraphic.prefHeight(-1.0);
        final double n7 = max - n3 - snappedLeftInset - snappedRightInset;
        double n8;
        double n10;
        if (this.isExpanded()) {
            n8 = (this.isExpanded() ? actualContent.prefHeight(n7) : 0.0);
            final double n9 = hasHeader ? n8 : Math.max(n6, n8);
            n10 = oldHeight - (n4 + n9 + n5);
        }
        else {
            n10 = (this.isExpanded() ? expandableContent.prefHeight(max) : 0.0);
            n8 = oldHeight - (n4 + n10 + n5);
            final double n9 = hasHeader ? n8 : Math.max(n6, n8);
        }
        double n11 = snappedLeftInset;
        double n12 = snappedTopInset;
        if (!hasHeader) {
            if (actualGraphic != null) {
                actualGraphic.resizeRelocate(n11, n12, n3, n6);
                n11 += n3;
            }
        }
        else {
            actualHeader.resizeRelocate(n11, n12, max - (snappedLeftInset + snappedRightInset), n4);
            n12 += n4;
        }
        actualContent.resizeRelocate(n11, n12, n7, n8);
        double n9;
        double n13 = n12 + (hasHeader ? n8 : n9);
        if (expandableContent != null) {
            expandableContent.resizeRelocate(snappedLeftInset, n13, max - snappedRightInset, n10);
            n13 += n10;
        }
        if (this.buttonBar != null) {
            this.buttonBar.resizeRelocate(snappedLeftInset, n13, max - (snappedLeftInset + snappedRightInset), n5);
        }
    }
    
    @Override
    protected double computeMinWidth(final double n) {
        final double a = this.hasHeader() ? (this.getActualHeader().minWidth(n) + 10.0) : 0.0;
        final double minWidth = this.getActualContent().minWidth(n);
        final double b = (this.buttonBar == null) ? 0.0 : this.buttonBar.minWidth(n);
        final double minWidth2 = this.getActualGraphic().minWidth(n);
        double minWidth3 = 0.0;
        final Node expandableContent = this.getExpandableContent();
        if (this.isExpanded() && expandableContent != null) {
            minWidth3 = expandableContent.minWidth(n);
        }
        return this.snapSizeX(this.snappedLeftInset() + (this.hasHeader() ? 0.0 : minWidth2) + Math.max(Math.max(a, minWidth3), Math.max(minWidth, b)) + this.snappedRightInset());
    }
    
    @Override
    protected double computeMinHeight(final double n) {
        final boolean hasHeader = this.hasHeader();
        final double n2 = hasHeader ? this.getActualHeader().minHeight(n) : 0.0;
        final double n3 = (this.buttonBar == null) ? 0.0 : this.buttonBar.minHeight(n);
        final Node actualGraphic = this.getActualGraphic();
        final double n4 = hasHeader ? 0.0 : actualGraphic.minWidth(-1.0);
        final double a = hasHeader ? 0.0 : actualGraphic.minHeight(n);
        final double minHeight = this.getActualContent().minHeight((n == -1.0) ? -1.0 : (hasHeader ? n : (n - n4)));
        double minHeight2 = 0.0;
        final Node expandableContent = this.getExpandableContent();
        if (this.isExpanded() && expandableContent != null) {
            minHeight2 = expandableContent.minHeight(n);
        }
        return this.snapSizeY(this.snappedTopInset() + n2 + Math.max(a, minHeight) + minHeight2 + n3 + this.snappedBottomInset());
    }
    
    @Override
    protected double computePrefWidth(final double n) {
        final double a = this.hasHeader() ? (this.getActualHeader().prefWidth(n) + 10.0) : 0.0;
        final double prefWidth = this.getActualContent().prefWidth(n);
        final double b = (this.buttonBar == null) ? 0.0 : this.buttonBar.prefWidth(n);
        final double prefWidth2 = this.getActualGraphic().prefWidth(n);
        double prefWidth3 = 0.0;
        final Node expandableContent = this.getExpandableContent();
        if (this.isExpanded() && expandableContent != null) {
            prefWidth3 = expandableContent.prefWidth(n);
        }
        return this.snapSizeX(this.snappedLeftInset() + (this.hasHeader() ? 0.0 : prefWidth2) + Math.max(Math.max(a, prefWidth3), Math.max(prefWidth, b)) + this.snappedRightInset());
    }
    
    @Override
    protected double computePrefHeight(final double n) {
        final boolean hasHeader = this.hasHeader();
        final double n2 = hasHeader ? this.getActualHeader().prefHeight(n) : 0.0;
        final double n3 = (this.buttonBar == null) ? 0.0 : this.buttonBar.prefHeight(n);
        final Node actualGraphic = this.getActualGraphic();
        final double n4 = hasHeader ? 0.0 : actualGraphic.prefWidth(-1.0);
        final double a = hasHeader ? 0.0 : actualGraphic.prefHeight(n);
        final double prefHeight = this.getActualContent().prefHeight((n == -1.0) ? -1.0 : (hasHeader ? n : (n - n4)));
        double prefHeight2 = 0.0;
        final Node expandableContent = this.getExpandableContent();
        if (this.isExpanded() && expandableContent != null) {
            prefHeight2 = expandableContent.prefHeight(n);
        }
        return this.snapSizeY(this.snappedTopInset() + n2 + Math.max(a, prefHeight) + prefHeight2 + n3 + this.snappedBottomInset());
    }
    
    private void updateButtons(final ButtonBar buttonBar) {
        buttonBar.getButtons().clear();
        if (this.hasExpandableContent()) {
            if (this.detailsButton == null) {
                this.detailsButton = this.createDetailsButton();
            }
            ButtonBar.setButtonData(this.detailsButton, ButtonBar.ButtonData.HELP_2);
            buttonBar.getButtons().add(this.detailsButton);
            ButtonBar.setButtonUniformSize(this.detailsButton, false);
        }
        boolean b = false;
        for (final ButtonType key : this.getButtonTypes()) {
            final Node node = this.buttonNodes.computeIfAbsent(key, p1 -> this.createButton(key));
            if (node instanceof Button) {
                final ButtonBar.ButtonData buttonData = key.getButtonData();
                ((Button)node).setDefaultButton(!b && buttonData != null && buttonData.isDefaultButton());
                ((Button)node).setCancelButton(buttonData != null && buttonData.isCancelButton());
                b |= (buttonData != null && buttonData.isDefaultButton());
            }
            buttonBar.getButtons().add(node);
        }
    }
    
    private Node getActualContent() {
        final Node content = this.getContent();
        return (content == null) ? this.contentLabel : content;
    }
    
    private Node getActualHeader() {
        final Node header = this.getHeader();
        return (header == null) ? this.headerTextPanel : header;
    }
    
    private Node getActualGraphic() {
        return this.headerTextPanel;
    }
    
    private void updateHeaderArea() {
        final Node header = this.getHeader();
        if (header != null) {
            if (!this.getChildren().contains(header)) {
                this.getChildren().add(header);
            }
            this.headerTextPanel.setVisible(false);
            this.headerTextPanel.setManaged(false);
        }
        else {
            final String headerText = this.getHeaderText();
            this.headerTextPanel.getChildren().clear();
            this.headerTextPanel.getStyleClass().clear();
            this.headerTextPanel.setMaxWidth(Double.MAX_VALUE);
            if (headerText != null && !headerText.isEmpty()) {
                this.headerTextPanel.getStyleClass().add("header-panel");
            }
            final Label label = new Label(headerText);
            label.setWrapText(true);
            label.setAlignment(Pos.CENTER_LEFT);
            label.setMaxWidth(Double.MAX_VALUE);
            label.setMaxHeight(Double.MAX_VALUE);
            this.headerTextPanel.add(label, 0, 0);
            this.graphicContainer.getChildren().clear();
            if (!this.graphicContainer.getStyleClass().contains("graphic-container")) {
                this.graphicContainer.getStyleClass().add("graphic-container");
            }
            final Node graphic = this.getGraphic();
            if (graphic != null) {
                this.graphicContainer.getChildren().add(graphic);
            }
            this.headerTextPanel.add(this.graphicContainer, 1, 0);
            final ColumnConstraints columnConstraints = new ColumnConstraints();
            columnConstraints.setFillWidth(true);
            columnConstraints.setHgrow(Priority.ALWAYS);
            final ColumnConstraints columnConstraints2 = new ColumnConstraints();
            columnConstraints2.setFillWidth(false);
            columnConstraints2.setHgrow(Priority.NEVER);
            this.headerTextPanel.getColumnConstraints().setAll(columnConstraints, columnConstraints2);
            this.headerTextPanel.setVisible(true);
            this.headerTextPanel.setManaged(true);
        }
    }
    
    private void updateContentArea() {
        final Node content = this.getContent();
        if (content != null) {
            if (!this.getChildren().contains(content)) {
                this.getChildren().add(content);
            }
            if (!content.getStyleClass().contains("content")) {
                content.getStyleClass().add("content");
            }
            this.contentLabel.setVisible(false);
            this.contentLabel.setManaged(false);
        }
        else {
            final String contentText = this.getContentText();
            final boolean b = contentText != null && !contentText.isEmpty();
            this.contentLabel.setText(b ? contentText : "");
            this.contentLabel.setVisible(b);
            this.contentLabel.setManaged(b);
        }
    }
    
    boolean hasHeader() {
        return this.getHeader() != null || this.isTextHeader();
    }
    
    private boolean isTextHeader() {
        final String headerText = this.getHeaderText();
        return headerText != null && !headerText.isEmpty();
    }
    
    boolean hasExpandableContent() {
        return this.getExpandableContent() != null;
    }
    
    void setDialog(final Dialog<?> dialog) {
        this.dialog = dialog;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<DialogPane, String> GRAPHIC;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            GRAPHIC = new CssMetaData<DialogPane, String>((StyleConverter)StringConverter.getInstance()) {
                @Override
                public boolean isSettable(final DialogPane dialogPane) {
                    return dialogPane.graphicProperty == null || !dialogPane.graphicProperty.isBound();
                }
                
                @Override
                public StyleableProperty<String> getStyleableProperty(final DialogPane dialogPane) {
                    return dialogPane.imageUrlProperty();
                }
            };
            final ArrayList<Object> list = new ArrayList<Object>(Region.getClassCssMetaData());
            Collections.addAll(list, StyleableProperties.GRAPHIC);
            STYLEABLES = Collections.unmodifiableList((List<? extends CssMetaData<? extends Styleable, ?>>)list);
        }
    }
}
