// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.scene.control.skin.ListCellSkin;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.AccessibleRole;
import javafx.beans.Observable;
import javafx.collections.ObservableList;
import java.lang.ref.WeakReference;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.WeakChangeListener;
import javafx.collections.WeakListChangeListener;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;
import javafx.beans.InvalidationListener;

public class ListCell<T> extends IndexedCell<T>
{
    private final InvalidationListener editingListener;
    private boolean updateEditingIndex;
    private final ListChangeListener<Integer> selectedListener;
    private final ChangeListener<MultipleSelectionModel<T>> selectionModelPropertyListener;
    private final ListChangeListener<T> itemsListener;
    private final InvalidationListener itemsPropertyListener;
    private final InvalidationListener focusedListener;
    private final ChangeListener<FocusModel<T>> focusModelPropertyListener;
    private final WeakInvalidationListener weakEditingListener;
    private final WeakListChangeListener<Integer> weakSelectedListener;
    private final WeakChangeListener<MultipleSelectionModel<T>> weakSelectionModelPropertyListener;
    private final WeakListChangeListener<T> weakItemsListener;
    private final WeakInvalidationListener weakItemsPropertyListener;
    private final WeakInvalidationListener weakFocusedListener;
    private final WeakChangeListener<FocusModel<T>> weakFocusModelPropertyListener;
    private ReadOnlyObjectWrapper<ListView<T>> listView;
    private boolean firstRun;
    private static final String DEFAULT_STYLE_CLASS = "list-cell";
    
    public ListCell() {
        this.editingListener = (p0 -> this.updateEditing());
        this.updateEditingIndex = true;
        this.selectedListener = (p0 -> this.updateSelection());
        this.selectionModelPropertyListener = new ChangeListener<MultipleSelectionModel<T>>() {
            @Override
            public void changed(final ObservableValue<? extends MultipleSelectionModel<T>> observableValue, final MultipleSelectionModel<T> multipleSelectionModel, final MultipleSelectionModel<T> multipleSelectionModel2) {
                if (multipleSelectionModel != null) {
                    multipleSelectionModel.getSelectedIndices().removeListener(ListCell.this.weakSelectedListener);
                }
                if (multipleSelectionModel2 != null) {
                    multipleSelectionModel2.getSelectedIndices().addListener(ListCell.this.weakSelectedListener);
                }
                ListCell.this.updateSelection();
            }
        };
        final ListView<T> listView;
        ObservableList<T> list;
        int n;
        final int n2;
        boolean b;
        boolean b2;
        boolean b3 = false;
        this.itemsListener = (change -> {
            while (change.next()) {
                this.getIndex();
                this.getListView();
                list = ((listView == null) ? null : listView.getItems());
                n = ((list == null) ? 0 : list.size());
                b = (n2 >= change.getFrom());
                b2 = (n2 < change.getTo() || n2 == n);
                b3 = ((b && b2) || (b && !change.wasReplaced() && (change.wasRemoved() || change.wasAdded())));
            }
            if (b3) {
                this.updateItem(-1);
            }
            return;
        });
        this.itemsPropertyListener = new InvalidationListener() {
            private WeakReference<ObservableList<T>> weakItemsRef = new WeakReference<ObservableList<T>>(null);
            
            @Override
            public void invalidated(final Observable observable) {
                final ObservableList list = this.weakItemsRef.get();
                if (list != null) {
                    list.removeListener(ListCell.this.weakItemsListener);
                }
                final ListView<T> listView = ListCell.this.getListView();
                final ObservableList<T> referent = (listView == null) ? null : listView.getItems();
                this.weakItemsRef = new WeakReference<ObservableList<T>>(referent);
                if (referent != null) {
                    referent.addListener(ListCell.this.weakItemsListener);
                }
                ListCell.this.updateItem(-1);
            }
        };
        this.focusedListener = (p0 -> this.updateFocus());
        this.focusModelPropertyListener = new ChangeListener<FocusModel<T>>() {
            @Override
            public void changed(final ObservableValue<? extends FocusModel<T>> observableValue, final FocusModel<T> focusModel, final FocusModel<T> focusModel2) {
                if (focusModel != null) {
                    focusModel.focusedIndexProperty().removeListener(ListCell.this.weakFocusedListener);
                }
                if (focusModel2 != null) {
                    focusModel2.focusedIndexProperty().addListener(ListCell.this.weakFocusedListener);
                }
                ListCell.this.updateFocus();
            }
        };
        this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
        this.weakSelectedListener = new WeakListChangeListener<Integer>(this.selectedListener);
        this.weakSelectionModelPropertyListener = new WeakChangeListener<MultipleSelectionModel<T>>(this.selectionModelPropertyListener);
        this.weakItemsListener = new WeakListChangeListener<T>(this.itemsListener);
        this.weakItemsPropertyListener = new WeakInvalidationListener(this.itemsPropertyListener);
        this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
        this.weakFocusModelPropertyListener = new WeakChangeListener<FocusModel<T>>(this.focusModelPropertyListener);
        this.listView = new ReadOnlyObjectWrapper<ListView<T>>((Object)this, "listView") {
            private WeakReference<ListView<T>> weakListViewRef = new WeakReference<ListView<T>>(null);
            
            @Override
            protected void invalidated() {
                final ListView<T> referent = this.get();
                final ListView<T> listView = this.weakListViewRef.get();
                if (referent == listView) {
                    return;
                }
                if (listView != null) {
                    final MultipleSelectionModel<T> selectionModel = listView.getSelectionModel();
                    if (selectionModel != null) {
                        selectionModel.getSelectedIndices().removeListener(ListCell.this.weakSelectedListener);
                    }
                    final FocusModel<T> focusModel = listView.getFocusModel();
                    if (focusModel != null) {
                        focusModel.focusedIndexProperty().removeListener(ListCell.this.weakFocusedListener);
                    }
                    final ObservableList<T> items = listView.getItems();
                    if (items != null) {
                        items.removeListener(ListCell.this.weakItemsListener);
                    }
                    listView.editingIndexProperty().removeListener(ListCell.this.weakEditingListener);
                    listView.itemsProperty().removeListener(ListCell.this.weakItemsPropertyListener);
                    listView.focusModelProperty().removeListener(ListCell.this.weakFocusModelPropertyListener);
                    listView.selectionModelProperty().removeListener(ListCell.this.weakSelectionModelPropertyListener);
                }
                if (referent != null) {
                    final MultipleSelectionModel<T> selectionModel2 = referent.getSelectionModel();
                    if (selectionModel2 != null) {
                        selectionModel2.getSelectedIndices().addListener(ListCell.this.weakSelectedListener);
                    }
                    final FocusModel<T> focusModel2 = referent.getFocusModel();
                    if (focusModel2 != null) {
                        focusModel2.focusedIndexProperty().addListener(ListCell.this.weakFocusedListener);
                    }
                    final ObservableList<T> items2 = referent.getItems();
                    if (items2 != null) {
                        items2.addListener(ListCell.this.weakItemsListener);
                    }
                    referent.editingIndexProperty().addListener(ListCell.this.weakEditingListener);
                    referent.itemsProperty().addListener(ListCell.this.weakItemsPropertyListener);
                    referent.focusModelProperty().addListener(ListCell.this.weakFocusModelPropertyListener);
                    referent.selectionModelProperty().addListener(ListCell.this.weakSelectionModelPropertyListener);
                    this.weakListViewRef = new WeakReference<ListView<T>>(referent);
                }
                ListCell.this.updateItem(-1);
                ListCell.this.updateSelection();
                ListCell.this.updateFocus();
                ListCell.this.requestLayout();
            }
        };
        this.firstRun = true;
        this.getStyleClass().addAll("list-cell");
        this.setAccessibleRole(AccessibleRole.LIST_ITEM);
    }
    
    private void setListView(final ListView<T> listView) {
        this.listView.set(listView);
    }
    
    public final ListView<T> getListView() {
        return this.listView.get();
    }
    
    public final ReadOnlyObjectProperty<ListView<T>> listViewProperty() {
        return this.listView.getReadOnlyProperty();
    }
    
    @Override
    void indexChanged(final int n, final int n2) {
        super.indexChanged(n, n2);
        if (!this.isEditing() || n2 != n) {
            this.updateItem(n);
            this.updateSelection();
            this.updateFocus();
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ListCellSkin<Object>(this);
    }
    
    @Override
    public void startEdit() {
        final ListView<?> listView = this.getListView();
        if (!this.isEditable() || (listView != null && !listView.isEditable())) {
            return;
        }
        super.startEdit();
        if (listView != null) {
            listView.fireEvent(new ListView.EditEvent<Object>((ListView<Object>)listView, ListView.editStartEvent(), null, this.getIndex()));
            listView.edit(this.getIndex());
            listView.requestFocus();
        }
    }
    
    @Override
    public void commitEdit(final T t) {
        if (!this.isEditing()) {
            return;
        }
        final ListView<?> listView = this.getListView();
        if (listView != null) {
            listView.fireEvent(new ListView.EditEvent<Object>((ListView<Object>)listView, ListView.editCommitEvent(), t, listView.getEditingIndex()));
        }
        super.commitEdit(t);
        this.updateItem(t, false);
        if (listView != null) {
            listView.edit(-1);
            ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(listView);
        }
    }
    
    @Override
    public void cancelEdit() {
        if (!this.isEditing()) {
            return;
        }
        final ListView<?> listView = this.getListView();
        super.cancelEdit();
        if (listView != null) {
            final int editingIndex = listView.getEditingIndex();
            if (this.updateEditingIndex) {
                listView.edit(-1);
            }
            ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(listView);
            listView.fireEvent(new ListView.EditEvent<Object>((ListView<Object>)listView, ListView.editCancelEvent(), null, editingIndex));
        }
    }
    
    private void updateItem(final int n) {
        final ListView<T> listView = this.getListView();
        final ObservableList<T> list = (listView == null) ? null : listView.getItems();
        final int index = this.getIndex();
        final int n2 = (list == null) ? -1 : list.size();
        final boolean b = list != null && index >= 0 && index < n2;
        final T item = this.getItem();
        final boolean empty = this.isEmpty();
        if (b) {
            final Object value = list.get(index);
            if (n != index || this.isItemChanged(item, (T)value)) {
                this.updateItem((T)value, false);
            }
        }
        else if ((!empty && item != null) || this.firstRun) {
            this.updateItem(null, true);
            this.firstRun = false;
        }
    }
    
    public final void updateListView(final ListView<T> listView) {
        this.setListView(listView);
    }
    
    private void updateSelection() {
        if (this.isEmpty()) {
            return;
        }
        final int index = this.getIndex();
        final ListView<T> listView = this.getListView();
        if (index == -1 || listView == null) {
            return;
        }
        final MultipleSelectionModel<T> selectionModel = listView.getSelectionModel();
        if (selectionModel == null) {
            this.updateSelected(false);
            return;
        }
        final boolean selected = selectionModel.isSelected(index);
        if (this.isSelected() == selected) {
            return;
        }
        this.updateSelected(selected);
    }
    
    private void updateFocus() {
        final int index = this.getIndex();
        final ListView<T> listView = this.getListView();
        if (index == -1 || listView == null) {
            return;
        }
        final FocusModel<T> focusModel = listView.getFocusModel();
        if (focusModel == null) {
            this.setFocused(false);
            return;
        }
        this.setFocused(focusModel.isFocused(index));
    }
    
    private void updateEditing() {
        final int index = this.getIndex();
        final ListView<T> listView = this.getListView();
        final int n = (listView == null) ? -1 : listView.getEditingIndex();
        final boolean editing = this.isEditing();
        if (index != -1 && listView != null) {
            if (index == n && !editing) {
                this.startEdit();
            }
            else if (index != n && editing) {
                this.updateEditingIndex = false;
                this.cancelEdit();
                this.updateEditingIndex = true;
            }
        }
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case INDEX: {
                return this.getIndex();
            }
            case SELECTED: {
                return this.isSelected();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case REQUEST_FOCUS: {
                final ListView<T> listView = this.getListView();
                if (listView != null) {
                    final FocusModel<T> focusModel = listView.getFocusModel();
                    if (focusModel != null) {
                        focusModel.focus(this.getIndex());
                    }
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
}
