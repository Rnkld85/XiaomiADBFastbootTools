// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import java.util.Iterator;
import javafx.collections.ListChangeListener;
import com.sun.javafx.scene.control.behavior.CellBehaviorBase;
import javafx.beans.value.WeakChangeListener;
import javafx.beans.value.ChangeListener;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.event.Event;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.TreeViewSkin;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.BooleanProperty;
import javafx.util.Callback;
import javafx.beans.property.ObjectProperty;
import javafx.event.WeakEventHandler;
import javafx.event.EventHandler;
import java.lang.ref.SoftReference;
import java.util.Map;
import javafx.event.EventType;
import javafx.beans.DefaultProperty;

@DefaultProperty("root")
public class TreeView<T> extends Control
{
    private static final EventType<?> EDIT_ANY_EVENT;
    private static final EventType<?> EDIT_START_EVENT;
    private static final EventType<?> EDIT_CANCEL_EVENT;
    private static final EventType<?> EDIT_COMMIT_EVENT;
    private boolean expandedItemCountDirty;
    private Map<Integer, SoftReference<TreeItem<T>>> treeItemCacheMap;
    private final EventHandler<TreeItem.TreeModificationEvent<T>> rootEvent;
    private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakRootEventListener;
    private ObjectProperty<Callback<TreeView<T>, TreeCell<T>>> cellFactory;
    private ObjectProperty<TreeItem<T>> root;
    private BooleanProperty showRoot;
    private ObjectProperty<MultipleSelectionModel<TreeItem<T>>> selectionModel;
    private ObjectProperty<FocusModel<TreeItem<T>>> focusModel;
    private ReadOnlyIntegerWrapper expandedItemCount;
    private DoubleProperty fixedCellSize;
    private BooleanProperty editable;
    private ReadOnlyObjectWrapper<TreeItem<T>> editingItem;
    private ObjectProperty<EventHandler<EditEvent<T>>> onEditStart;
    private ObjectProperty<EventHandler<EditEvent<T>>> onEditCommit;
    private ObjectProperty<EventHandler<EditEvent<T>>> onEditCancel;
    private ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollTo;
    private static final String DEFAULT_STYLE_CLASS = "tree-view";
    
    public static <T> EventType<EditEvent<T>> editAnyEvent() {
        return (EventType<EditEvent<T>>)TreeView.EDIT_ANY_EVENT;
    }
    
    public static <T> EventType<EditEvent<T>> editStartEvent() {
        return (EventType<EditEvent<T>>)TreeView.EDIT_START_EVENT;
    }
    
    public static <T> EventType<EditEvent<T>> editCancelEvent() {
        return (EventType<EditEvent<T>>)TreeView.EDIT_CANCEL_EVENT;
    }
    
    public static <T> EventType<EditEvent<T>> editCommitEvent() {
        return (EventType<EditEvent<T>>)TreeView.EDIT_COMMIT_EVENT;
    }
    
    @Deprecated(since = "8u20")
    public static int getNodeLevel(final TreeItem<?> treeItem) {
        if (treeItem == null) {
            return -1;
        }
        int n = 0;
        for (TreeItem<?> treeItem2 = treeItem.getParent(); treeItem2 != null; treeItem2 = treeItem2.getParent()) {
            ++n;
        }
        return n;
    }
    
    public TreeView() {
        this(null);
    }
    
    public TreeView(final TreeItem<T> p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokespecial   javafx/scene/control/Control.<init>:()V
        //     4: aload_0        
        //     5: iconst_1       
        //     6: putfield        javafx/scene/control/TreeView.expandedItemCountDirty:Z
        //     9: aload_0        
        //    10: new             Ljava/util/HashMap;
        //    13: dup            
        //    14: invokespecial   java/util/HashMap.<init>:()V
        //    17: putfield        javafx/scene/control/TreeView.treeItemCacheMap:Ljava/util/Map;
        //    20: aload_0        
        //    21: aload_0        
        //    22: invokedynamic   BootstrapMethod #0, handle:(Ljavafx/scene/control/TreeView;)Ljavafx/event/EventHandler;
        //    27: putfield        javafx/scene/control/TreeView.rootEvent:Ljavafx/event/EventHandler;
        //    30: aload_0        
        //    31: new             Ljavafx/scene/control/TreeView$1;
        //    34: dup            
        //    35: aload_0        
        //    36: aload_0        
        //    37: ldc             "root"
        //    39: invokespecial   javafx/scene/control/TreeView$1.<init>:(Ljavafx/scene/control/TreeView;Ljava/lang/Object;Ljava/lang/String;)V
        //    42: putfield        javafx/scene/control/TreeView.root:Ljavafx/beans/property/ObjectProperty;
        //    45: aload_0        
        //    46: new             Ljavafx/beans/property/ReadOnlyIntegerWrapper;
        //    49: dup            
        //    50: aload_0        
        //    51: ldc             "expandedItemCount"
        //    53: iconst_0       
        //    54: invokespecial   javafx/beans/property/ReadOnlyIntegerWrapper.<init>:(Ljava/lang/Object;Ljava/lang/String;I)V
        //    57: putfield        javafx/scene/control/TreeView.expandedItemCount:Ljavafx/beans/property/ReadOnlyIntegerWrapper;
        //    60: aload_0        
        //    61: invokevirtual   javafx/scene/control/TreeView.getStyleClass:()Ljavafx/collections/ObservableList;
        //    64: iconst_1       
        //    65: anewarray       Ljava/lang/String;
        //    68: dup            
        //    69: iconst_0       
        //    70: ldc             "tree-view"
        //    72: aastore        
        //    73: invokeinterface javafx/collections/ObservableList.setAll:([Ljava/lang/Object;)Z
        //    78: pop            
        //    79: aload_0        
        //    80: getstatic       javafx/scene/AccessibleRole.TREE_VIEW:Ljavafx/scene/AccessibleRole;
        //    83: invokevirtual   javafx/scene/control/TreeView.setAccessibleRole:(Ljavafx/scene/AccessibleRole;)V
        //    86: aload_0        
        //    87: aload_1        
        //    88: invokevirtual   javafx/scene/control/TreeView.setRoot:(Ljavafx/scene/control/TreeItem;)V
        //    91: aload_0        
        //    92: aload_1        
        //    93: invokespecial   javafx/scene/control/TreeView.updateExpandedItemCount:(Ljavafx/scene/control/TreeItem;)V
        //    96: new             Ljavafx/scene/control/TreeView$TreeViewBitSetSelectionModel;
        //    99: dup            
        //   100: aload_0        
        //   101: invokespecial   javafx/scene/control/TreeView$TreeViewBitSetSelectionModel.<init>:(Ljavafx/scene/control/TreeView;)V
        //   104: astore_2       
        //   105: aload_0        
        //   106: aload_2        
        //   107: invokevirtual   javafx/scene/control/TreeView.setSelectionModel:(Ljavafx/scene/control/MultipleSelectionModel;)V
        //   110: aload_0        
        //   111: new             Ljavafx/scene/control/TreeView$TreeViewFocusModel;
        //   114: dup            
        //   115: aload_0        
        //   116: invokespecial   javafx/scene/control/TreeView$TreeViewFocusModel.<init>:(Ljavafx/scene/control/TreeView;)V
        //   119: invokevirtual   javafx/scene/control/TreeView.setFocusModel:(Ljavafx/scene/control/FocusModel;)V
        //   122: return         
        //    Signature:
        //  (Ljavafx/scene/control/TreeItem<TT;>;)V
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.generateNameForVariable(NameVariables.java:264)
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.assignNamesToVariables(NameVariables.java:198)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:276)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public final void setCellFactory(final Callback<TreeView<T>, TreeCell<T>> callback) {
        this.cellFactoryProperty().set(callback);
    }
    
    public final Callback<TreeView<T>, TreeCell<T>> getCellFactory() {
        return (this.cellFactory == null) ? null : this.cellFactory.get();
    }
    
    public final ObjectProperty<Callback<TreeView<T>, TreeCell<T>>> cellFactoryProperty() {
        if (this.cellFactory == null) {
            this.cellFactory = new SimpleObjectProperty<Callback<TreeView<T>, TreeCell<T>>>(this, "cellFactory");
        }
        return this.cellFactory;
    }
    
    public final void setRoot(final TreeItem<T> treeItem) {
        this.rootProperty().set(treeItem);
    }
    
    public final TreeItem<T> getRoot() {
        return (this.root == null) ? null : this.root.get();
    }
    
    public final ObjectProperty<TreeItem<T>> rootProperty() {
        return this.root;
    }
    
    public final void setShowRoot(final boolean b) {
        this.showRootProperty().set(b);
    }
    
    public final boolean isShowRoot() {
        return this.showRoot == null || this.showRoot.get();
    }
    
    public final BooleanProperty showRootProperty() {
        if (this.showRoot == null) {
            this.showRoot = new SimpleBooleanProperty(this, "showRoot", true) {
                @Override
                protected void invalidated() {
                    TreeView.this.updateRootExpanded();
                    TreeView.this.updateExpandedItemCount(TreeView.this.getRoot());
                }
            };
        }
        return this.showRoot;
    }
    
    public final void setSelectionModel(final MultipleSelectionModel<TreeItem<T>> multipleSelectionModel) {
        this.selectionModelProperty().set(multipleSelectionModel);
    }
    
    public final MultipleSelectionModel<TreeItem<T>> getSelectionModel() {
        return (this.selectionModel == null) ? null : this.selectionModel.get();
    }
    
    public final ObjectProperty<MultipleSelectionModel<TreeItem<T>>> selectionModelProperty() {
        if (this.selectionModel == null) {
            this.selectionModel = new SimpleObjectProperty<MultipleSelectionModel<TreeItem<T>>>(this, "selectionModel");
        }
        return this.selectionModel;
    }
    
    public final void setFocusModel(final FocusModel<TreeItem<T>> focusModel) {
        this.focusModelProperty().set(focusModel);
    }
    
    public final FocusModel<TreeItem<T>> getFocusModel() {
        return (this.focusModel == null) ? null : this.focusModel.get();
    }
    
    public final ObjectProperty<FocusModel<TreeItem<T>>> focusModelProperty() {
        if (this.focusModel == null) {
            this.focusModel = new SimpleObjectProperty<FocusModel<TreeItem<T>>>(this, "focusModel");
        }
        return this.focusModel;
    }
    
    public final ReadOnlyIntegerProperty expandedItemCountProperty() {
        return this.expandedItemCount.getReadOnlyProperty();
    }
    
    private void setExpandedItemCount(final int n) {
        this.expandedItemCount.set(n);
    }
    
    public final int getExpandedItemCount() {
        if (this.expandedItemCountDirty) {
            this.updateExpandedItemCount(this.getRoot());
        }
        return this.expandedItemCount.get();
    }
    
    public final void setFixedCellSize(final double n) {
        this.fixedCellSizeProperty().set(n);
    }
    
    public final double getFixedCellSize() {
        return (this.fixedCellSize == null) ? -1.0 : this.fixedCellSize.get();
    }
    
    public final DoubleProperty fixedCellSizeProperty() {
        if (this.fixedCellSize == null) {
            this.fixedCellSize = new StyleableDoubleProperty(-1.0) {
                @Override
                public CssMetaData<TreeView<?>, Number> getCssMetaData() {
                    return StyleableProperties.FIXED_CELL_SIZE;
                }
                
                @Override
                public Object getBean() {
                    return TreeView.this;
                }
                
                @Override
                public String getName() {
                    return "fixedCellSize";
                }
            };
        }
        return this.fixedCellSize;
    }
    
    public final void setEditable(final boolean b) {
        this.editableProperty().set(b);
    }
    
    public final boolean isEditable() {
        return this.editable != null && this.editable.get();
    }
    
    public final BooleanProperty editableProperty() {
        if (this.editable == null) {
            this.editable = new SimpleBooleanProperty(this, "editable", false);
        }
        return this.editable;
    }
    
    private void setEditingItem(final TreeItem<T> treeItem) {
        this.editingItemPropertyImpl().set(treeItem);
    }
    
    public final TreeItem<T> getEditingItem() {
        return (this.editingItem == null) ? null : this.editingItem.get();
    }
    
    public final ReadOnlyObjectProperty<TreeItem<T>> editingItemProperty() {
        return this.editingItemPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<TreeItem<T>> editingItemPropertyImpl() {
        if (this.editingItem == null) {
            this.editingItem = new ReadOnlyObjectWrapper<TreeItem<T>>(this, "editingItem");
        }
        return this.editingItem;
    }
    
    public final void setOnEditStart(final EventHandler<EditEvent<T>> eventHandler) {
        this.onEditStartProperty().set(eventHandler);
    }
    
    public final EventHandler<EditEvent<T>> getOnEditStart() {
        return (this.onEditStart == null) ? null : this.onEditStart.get();
    }
    
    public final ObjectProperty<EventHandler<EditEvent<T>>> onEditStartProperty() {
        if (this.onEditStart == null) {
            this.onEditStart = new SimpleObjectProperty<EventHandler<EditEvent<T>>>(this, "onEditStart") {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(TreeView.editStartEvent(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
            };
        }
        return this.onEditStart;
    }
    
    public final void setOnEditCommit(final EventHandler<EditEvent<T>> eventHandler) {
        this.onEditCommitProperty().set(eventHandler);
    }
    
    public final EventHandler<EditEvent<T>> getOnEditCommit() {
        return (this.onEditCommit == null) ? null : this.onEditCommit.get();
    }
    
    public final ObjectProperty<EventHandler<EditEvent<T>>> onEditCommitProperty() {
        if (this.onEditCommit == null) {
            this.onEditCommit = new SimpleObjectProperty<EventHandler<EditEvent<T>>>(this, "onEditCommit") {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(TreeView.editCommitEvent(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
            };
        }
        return this.onEditCommit;
    }
    
    public final void setOnEditCancel(final EventHandler<EditEvent<T>> eventHandler) {
        this.onEditCancelProperty().set(eventHandler);
    }
    
    public final EventHandler<EditEvent<T>> getOnEditCancel() {
        return (this.onEditCancel == null) ? null : this.onEditCancel.get();
    }
    
    public final ObjectProperty<EventHandler<EditEvent<T>>> onEditCancelProperty() {
        if (this.onEditCancel == null) {
            this.onEditCancel = new SimpleObjectProperty<EventHandler<EditEvent<T>>>(this, "onEditCancel") {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(TreeView.editCancelEvent(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
            };
        }
        return this.onEditCancel;
    }
    
    @Override
    protected void layoutChildren() {
        if (this.expandedItemCountDirty) {
            this.updateExpandedItemCount(this.getRoot());
        }
        super.layoutChildren();
    }
    
    public void edit(final TreeItem<T> editingItem) {
        if (!this.isEditable()) {
            return;
        }
        this.setEditingItem(editingItem);
    }
    
    public void scrollTo(final int n) {
        ControlUtils.scrollToIndex(this, n);
    }
    
    public void setOnScrollTo(final EventHandler<ScrollToEvent<Integer>> eventHandler) {
        this.onScrollToProperty().set(eventHandler);
    }
    
    public EventHandler<ScrollToEvent<Integer>> getOnScrollTo() {
        if (this.onScrollTo != null) {
            return this.onScrollTo.get();
        }
        return null;
    }
    
    public ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollToProperty() {
        if (this.onScrollTo == null) {
            this.onScrollTo = new ObjectPropertyBase<EventHandler<ScrollToEvent<Integer>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(ScrollToEvent.scrollToTopIndex(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return TreeView.this;
                }
                
                @Override
                public String getName() {
                    return "onScrollTo";
                }
            };
        }
        return this.onScrollTo;
    }
    
    public int getRow(final TreeItem<T> treeItem) {
        return TreeUtil.getRow(treeItem, this.getRoot(), this.expandedItemCountDirty, this.isShowRoot());
    }
    
    public TreeItem<T> getTreeItem(final int n) {
        if (n < 0) {
            return null;
        }
        final int i = this.isShowRoot() ? n : (n + 1);
        if (this.expandedItemCountDirty) {
            this.updateExpandedItemCount(this.getRoot());
        }
        else if (this.treeItemCacheMap.containsKey(i)) {
            final TreeItem<T> treeItem = this.treeItemCacheMap.get(i).get();
            if (treeItem != null) {
                return treeItem;
            }
        }
        final TreeItem<T> item = TreeUtil.getItem(this.getRoot(), i, this.expandedItemCountDirty);
        this.treeItemCacheMap.put(i, new SoftReference<TreeItem<T>>(item));
        return item;
    }
    
    public int getTreeItemLevel(final TreeItem<?> treeItem) {
        final TreeItem<?> root = this.getRoot();
        if (treeItem == null) {
            return -1;
        }
        if (treeItem == root) {
            return 0;
        }
        int n = 0;
        for (TreeItem<?> treeItem2 = treeItem.getParent(); treeItem2 != null; treeItem2 = treeItem2.getParent()) {
            ++n;
            if (treeItem2 == root) {
                break;
            }
        }
        return n;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TreeViewSkin<Object>(this);
    }
    
    public void refresh() {
        this.getProperties().put("recreateKey", Boolean.TRUE);
    }
    
    private void updateExpandedItemCount(final TreeItem<T> treeItem) {
        this.setExpandedItemCount(TreeUtil.updateExpandedItemCount(treeItem, this.expandedItemCountDirty, this.isShowRoot()));
        if (this.expandedItemCountDirty) {
            this.treeItemCacheMap.clear();
        }
        this.expandedItemCountDirty = false;
    }
    
    private void updateRootExpanded() {
        if (!this.isShowRoot() && this.getRoot() != null && !this.getRoot().isExpanded()) {
            this.getRoot().setExpanded(true);
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case MULTIPLE_SELECTION: {
                final MultipleSelectionModel<TreeItem<T>> selectionModel = this.getSelectionModel();
                return selectionModel != null && selectionModel.getSelectionMode() == SelectionMode.MULTIPLE;
            }
            case ROW_COUNT: {
                return this.getExpandedItemCount();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        EDIT_ANY_EVENT = new EventType<Object>(Event.ANY, "TREE_VIEW_EDIT");
        EDIT_START_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_START");
        EDIT_CANCEL_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_CANCEL");
        EDIT_COMMIT_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_COMMIT");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TreeView<?>, Number> FIXED_CELL_SIZE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            FIXED_CELL_SIZE = new CssMetaData<TreeView<?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)(-1.0)) {
                @Override
                public Double getInitialValue(final TreeView<?> treeView) {
                    return treeView.getFixedCellSize();
                }
                
                @Override
                public boolean isSettable(final TreeView<?> treeView) {
                    return ((TreeView<Object>)treeView).fixedCellSize == null || !((TreeView<Object>)treeView).fixedCellSize.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TreeView<?> treeView) {
                    return (StyleableProperty<Number>)treeView.fixedCellSizeProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.FIXED_CELL_SIZE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    public static class EditEvent<T> extends Event
    {
        private static final long serialVersionUID = -4437033058917528976L;
        public static final EventType<?> ANY;
        private final TreeView<T> source;
        private final T oldValue;
        private final T newValue;
        private final transient TreeItem<T> treeItem;
        
        public EditEvent(final TreeView<T> source, final EventType<? extends EditEvent> eventType, final TreeItem<T> treeItem, final T oldValue, final T newValue) {
            super(source, Event.NULL_SOURCE_TARGET, eventType);
            this.source = source;
            this.oldValue = oldValue;
            this.newValue = newValue;
            this.treeItem = treeItem;
        }
        
        @Override
        public TreeView<T> getSource() {
            return this.source;
        }
        
        public TreeItem<T> getTreeItem() {
            return this.treeItem;
        }
        
        public T getNewValue() {
            return this.newValue;
        }
        
        public T getOldValue() {
            return this.oldValue;
        }
        
        static {
            ANY = TreeView.EDIT_ANY_EVENT;
        }
    }
    
    static class TreeViewBitSetSelectionModel<T> extends MultipleSelectionModelBase<TreeItem<T>>
    {
        private TreeView<T> treeView;
        private ChangeListener<TreeItem<T>> rootPropertyListener;
        private EventHandler<TreeItem.TreeModificationEvent<T>> treeItemListener;
        private WeakChangeListener<TreeItem<T>> weakRootPropertyListener;
        private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakTreeItemListener;
        
        public TreeViewBitSetSelectionModel(final TreeView<T> treeView) {
            this.treeView = null;
            this.rootPropertyListener = ((p0, treeItem, treeItem2) -> {
                this.updateDefaultSelection();
                this.updateTreeEventListener(treeItem, treeItem2);
                return;
            });
            final TreeItem<TreeItem> treeItem3;
            final ListChangeListener.Change change;
            int n;
            int n2;
            int n3 = 0;
            int row = 0;
            int previousExpandedDescendentCount;
            final int n4;
            boolean b;
            ArrayList<Integer> list;
            int i = 0;
            final int n5;
            final Iterator<Integer> iterator;
            final int n6;
            final boolean b2;
            TreeItem treeItem4;
            int n7 = 0;
            final List<Integer> list2;
            final ObservableList list3;
            final List<? extends TreeItem<T>> list4;
            final int n8;
            final TreeItem<TreeItem> obj;
            Integer n9;
            this.treeItemListener = (treeModificationEvent -> {
                if (this.getSelectedIndex() == -1 && this.getSelectedItem() == null) {
                    return;
                }
                else {
                    treeModificationEvent.getTreeItem();
                    if (treeItem3 == null) {
                        return;
                    }
                    else {
                        ((TreeView<Object>)this.treeView).expandedItemCountDirty = true;
                        this.treeView.getRow((TreeItem<?>)treeItem3);
                        treeModificationEvent.getChange();
                        if (change != null) {
                            change.next();
                        }
                        do {
                            n = ((change == null) ? 0 : change.getAddedSize());
                            n2 = ((change == null) ? 0 : change.getRemovedSize());
                            if (treeModificationEvent.wasExpanded()) {
                                n3 += treeItem3.getExpandedDescendentCount(false) - 1;
                                ++row;
                            }
                            else if (treeModificationEvent.wasCollapsed()) {
                                treeItem3.getExpandedDescendentCount(false);
                                previousExpandedDescendentCount = treeItem3.previousExpandedDescendentCount;
                                this.getSelectedIndex();
                                b = (n4 >= row + 1 && n4 < row + previousExpandedDescendentCount);
                                this.selectedIndices._beginChange();
                                list = new ArrayList<Integer>();
                                while (i < n5) {
                                    if (this.isSelected(i)) {
                                        list.add(i);
                                    }
                                    ++i;
                                }
                                ControlUtils.reducingChange(this.selectedIndices, list);
                                list.iterator();
                                while (iterator.hasNext()) {
                                    iterator.next();
                                    this.startAtomic();
                                    this.clearSelection(n6);
                                    this.stopAtomic();
                                }
                                this.selectedIndices._endChange();
                                if (b && b2) {
                                    this.select(row);
                                }
                                ++row;
                            }
                            else if (treeModificationEvent.wasPermutated()) {
                                continue;
                            }
                            else if (treeModificationEvent.wasAdded()) {
                                n3 += (treeItem3.isExpanded() ? n : 0);
                                row = this.treeView.getRow((TreeItem<?>)treeModificationEvent.getChange().getAddedSubList().get(0));
                            }
                            else if (treeModificationEvent.wasRemoved()) {
                                n3 += (treeItem3.isExpanded() ? (-n2) : 0);
                                row += treeModificationEvent.getFrom() + 1;
                                this.getSelectedIndices();
                                this.getSelectedIndex();
                                this.getSelectedItems();
                                treeItem4 = this.getSelectedItem();
                                treeModificationEvent.getChange().getRemoved();
                                while (n7 < list2.size() && !list3.isEmpty()) {
                                    if (list2.get(n7) > list3.size()) {
                                        break;
                                    }
                                    else {
                                        if (list4.size() == 1 && list3.size() == 1 && treeItem4 != null && treeItem4.equals(list4.get(0)) && n8 < this.getItemCount()) {
                                            this.getModelItem((n8 == 0) ? 0 : (n8 - 1));
                                            if (!treeItem4.equals(obj)) {
                                                this.select(obj);
                                            }
                                        }
                                        ++n7;
                                    }
                                }
                            }
                            else {
                                continue;
                            }
                        } while (treeModificationEvent.getChange() != null && treeModificationEvent.getChange().next());
                        this.shiftSelection(row, n3, null);
                        if (treeModificationEvent.wasAdded() || treeModificationEvent.wasRemoved()) {
                            n9 = CellBehaviorBase.getAnchor(this.treeView, (Integer)null);
                            if (n9 != null && this.isSelected(n9 + n3)) {
                                CellBehaviorBase.setAnchor(this.treeView, n9 + n3, false);
                            }
                        }
                        return;
                    }
                }
            });
            this.weakRootPropertyListener = new WeakChangeListener<TreeItem<T>>(this.rootPropertyListener);
            if (treeView == null) {
                throw new IllegalArgumentException("TreeView can not be null");
            }
            this.treeView = treeView;
            this.treeView.rootProperty().addListener(this.weakRootPropertyListener);
            this.treeView.showRootProperty().addListener(p1 -> this.shiftSelection(0, treeView.isShowRoot() ? 1 : -1, null));
            this.updateTreeEventListener(null, treeView.getRoot());
            this.updateDefaultSelection();
        }
        
        private void updateTreeEventListener(final TreeItem<T> treeItem, final TreeItem<T> treeItem2) {
            if (treeItem != null && this.weakTreeItemListener != null) {
                treeItem.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakTreeItemListener);
            }
            if (treeItem2 != null) {
                this.weakTreeItemListener = new WeakEventHandler<TreeItem.TreeModificationEvent<T>>(this.treeItemListener);
                treeItem2.addEventHandler(TreeItem.expandedItemCountChangeEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakTreeItemListener);
            }
        }
        
        @Override
        public void selectAll() {
            final int intValue = CellBehaviorBase.getAnchor(this.treeView, -1);
            super.selectAll();
            CellBehaviorBase.setAnchor(this.treeView, intValue, false);
        }
        
        @Override
        public void select(final TreeItem<T> selectedItem) {
            if (selectedItem == null && this.getSelectionMode() == SelectionMode.SINGLE) {
                this.clearSelection();
                return;
            }
            if (selectedItem != null) {
                for (TreeItem<T> treeItem = selectedItem.getParent(); treeItem != null; treeItem = treeItem.getParent()) {
                    treeItem.setExpanded(true);
                }
            }
            ((TreeView<Object>)this.treeView).updateExpandedItemCount(this.treeView.getRoot());
            final int row = this.treeView.getRow(selectedItem);
            if (row == -1) {
                this.setSelectedIndex(-1);
                this.setSelectedItem(selectedItem);
            }
            else {
                this.select(row);
            }
        }
        
        @Override
        public void clearAndSelect(final int i) {
            CellBehaviorBase.setAnchor(this.treeView, i, false);
            super.clearAndSelect(i);
        }
        
        @Override
        protected void focus(final int n) {
            if (this.treeView.getFocusModel() != null) {
                this.treeView.getFocusModel().focus(n);
            }
            this.treeView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
        }
        
        @Override
        protected int getFocusedIndex() {
            if (this.treeView.getFocusModel() == null) {
                return -1;
            }
            return this.treeView.getFocusModel().getFocusedIndex();
        }
        
        @Override
        protected int getItemCount() {
            return (this.treeView == null) ? 0 : this.treeView.getExpandedItemCount();
        }
        
        public TreeItem<T> getModelItem(final int n) {
            if (this.treeView == null) {
                return null;
            }
            if (n < 0 || n >= this.treeView.getExpandedItemCount()) {
                return null;
            }
            return this.treeView.getTreeItem(n);
        }
        
        private void updateDefaultSelection() {
            this.clearSelection();
            this.focus((this.getItemCount() > 0) ? 0 : -1);
        }
    }
    
    static class TreeViewFocusModel<T> extends FocusModel<TreeItem<T>>
    {
        private final TreeView<T> treeView;
        private final ChangeListener<TreeItem<T>> rootPropertyListener;
        private final WeakChangeListener<TreeItem<T>> weakRootPropertyListener;
        private EventHandler<TreeItem.TreeModificationEvent<T>> treeItemListener;
        private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakTreeItemListener;
        
        public TreeViewFocusModel(final TreeView<T> treeView) {
            this.rootPropertyListener = ((p0, treeItem, treeItem2) -> this.updateTreeEventListener(treeItem, treeItem2));
            this.weakRootPropertyListener = new WeakChangeListener<TreeItem<T>>(this.rootPropertyListener);
            this.treeItemListener = new EventHandler<TreeItem.TreeModificationEvent<T>>() {
                @Override
                public void handle(final TreeItem.TreeModificationEvent<T> treeModificationEvent) {
                    if (TreeViewFocusModel.this.getFocusedIndex() == -1) {
                        return;
                    }
                    int n = TreeViewFocusModel.this.treeView.getRow(treeModificationEvent.getTreeItem());
                    int n2 = 0;
                    if (treeModificationEvent.getChange() != null) {
                        treeModificationEvent.getChange().next();
                    }
                    do {
                        if (treeModificationEvent.wasExpanded()) {
                            if (n >= TreeViewFocusModel.this.getFocusedIndex()) {
                                continue;
                            }
                            n2 += treeModificationEvent.getTreeItem().getExpandedDescendentCount(false) - 1;
                        }
                        else if (treeModificationEvent.wasCollapsed()) {
                            if (n >= TreeViewFocusModel.this.getFocusedIndex()) {
                                continue;
                            }
                            n2 += -treeModificationEvent.getTreeItem().previousExpandedDescendentCount + 1;
                        }
                        else if (treeModificationEvent.wasAdded()) {
                            if (!treeModificationEvent.getTreeItem().isExpanded()) {
                                continue;
                            }
                            for (int i = 0; i < treeModificationEvent.getAddedChildren().size(); ++i) {
                                final TreeItem treeItem = (TreeItem)treeModificationEvent.getAddedChildren().get(i);
                                n = TreeViewFocusModel.this.treeView.getRow(treeItem);
                                if (treeItem != null && n <= n2 + TreeViewFocusModel.this.getFocusedIndex()) {
                                    n2 += treeItem.getExpandedDescendentCount(false);
                                }
                            }
                        }
                        else {
                            if (!treeModificationEvent.wasRemoved()) {
                                continue;
                            }
                            n += treeModificationEvent.getFrom() + 1;
                            for (int j = 0; j < treeModificationEvent.getRemovedChildren().size(); ++j) {
                                final TreeItem treeItem2 = (TreeItem)treeModificationEvent.getRemovedChildren().get(j);
                                if (treeItem2 != null && treeItem2.equals(TreeViewFocusModel.this.getFocusedItem())) {
                                    TreeViewFocusModel.this.focus(Math.max(0, TreeViewFocusModel.this.getFocusedIndex() - 1));
                                    return;
                                }
                            }
                            if (n > TreeViewFocusModel.this.getFocusedIndex()) {
                                continue;
                            }
                            n2 += (treeModificationEvent.getTreeItem().isExpanded() ? (-treeModificationEvent.getRemovedSize()) : 0);
                        }
                    } while (treeModificationEvent.getChange() != null && treeModificationEvent.getChange().next());
                    if (n2 != 0 && TreeViewFocusModel.this.getFocusedIndex() + n2 >= 0) {
                        final int n3;
                        Platform.runLater(() -> TreeViewFocusModel.this.focus(n3));
                    }
                }
            };
            this.treeView = treeView;
            this.treeView.rootProperty().addListener(this.weakRootPropertyListener);
            this.updateTreeEventListener(null, treeView.getRoot());
            if (treeView.getExpandedItemCount() > 0) {
                this.focus(0);
            }
            treeView.showRootProperty().addListener(p0 -> {
                if (this.isFocused(0)) {
                    this.focus(-1);
                    this.focus(0);
                }
                return;
            });
            this.focusedIndexProperty().addListener(p1 -> treeView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM));
        }
        
        private void updateTreeEventListener(final TreeItem<T> treeItem, final TreeItem<T> treeItem2) {
            if (treeItem != null && this.weakTreeItemListener != null) {
                treeItem.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakTreeItemListener);
            }
            if (treeItem2 != null) {
                this.weakTreeItemListener = new WeakEventHandler<TreeItem.TreeModificationEvent<T>>(this.treeItemListener);
                treeItem2.addEventHandler(TreeItem.expandedItemCountChangeEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakTreeItemListener);
            }
        }
        
        @Override
        protected int getItemCount() {
            return (this.treeView == null) ? -1 : this.treeView.getExpandedItemCount();
        }
        
        @Override
        protected TreeItem<T> getModelItem(final int n) {
            if (this.treeView == null) {
                return null;
            }
            if (n < 0 || n >= this.treeView.getExpandedItemCount()) {
                return null;
            }
            return this.treeView.getTreeItem(n);
        }
        
        @Override
        public void focus(final int n) {
            if (((TreeView<Object>)this.treeView).expandedItemCountDirty) {
                ((TreeView<Object>)this.treeView).updateExpandedItemCount(this.treeView.getRoot());
            }
            super.focus(n);
        }
    }
}
