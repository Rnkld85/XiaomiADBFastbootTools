// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.control.skin.ButtonBarSkin;
import com.sun.javafx.util.Utils;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableMap;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.Node;
import javafx.collections.ObservableList;

public class ButtonBar extends Control
{
    public static final String BUTTON_ORDER_WINDOWS = "L_E+U+FBXI_YNOCAH_R";
    public static final String BUTTON_ORDER_MAC_OS = "L_HE+U+FBIX_NCYOA_R";
    public static final String BUTTON_ORDER_LINUX = "L_HE+UNYACBXIO_R";
    public static final String BUTTON_ORDER_NONE = "";
    private ObservableList<Node> buttons;
    private final StringProperty buttonOrderProperty;
    private final DoubleProperty buttonMinWidthProperty;
    
    public static void setButtonData(final Node node, final ButtonData buttonData) {
        final ObservableMap<Object, Object> properties = node.getProperties();
        final SimpleObjectProperty<ButtonData> value = properties.getOrDefault("javafx.scene.control.ButtonBar.ButtonData", new SimpleObjectProperty<ButtonData>(node, "buttonData", buttonData));
        value.set(buttonData);
        properties.putIfAbsent("javafx.scene.control.ButtonBar.ButtonData", value);
    }
    
    public static ButtonData getButtonData(final Node node) {
        final ObservableMap<Object, Object> properties = node.getProperties();
        if (properties.containsKey("javafx.scene.control.ButtonBar.ButtonData")) {
            final ObjectProperty<ButtonData> objectProperty = properties.get("javafx.scene.control.ButtonBar.ButtonData");
            return (objectProperty == null) ? null : ((ButtonData)objectProperty.get());
        }
        return null;
    }
    
    public static void setButtonUniformSize(final Node node, final boolean b) {
        if (b) {
            node.getProperties().remove("javafx.scene.control.ButtonBar.independentSize");
        }
        else {
            node.getProperties().put("javafx.scene.control.ButtonBar.independentSize", b);
        }
    }
    
    public static boolean isButtonUniformSize(final Node node) {
        return node.getProperties().getOrDefault("javafx.scene.control.ButtonBar.independentSize", true);
    }
    
    public ButtonBar() {
        this(null);
    }
    
    public ButtonBar(final String s) {
        this.buttons = FXCollections.observableArrayList();
        this.buttonOrderProperty = new SimpleStringProperty(this, "buttonOrder");
        this.buttonMinWidthProperty = new SimpleDoubleProperty(this, "buttonMinWidthProperty");
        this.getStyleClass().add("button-bar");
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
        final boolean b = s == null || s.isEmpty();
        if (Utils.isMac()) {
            this.setButtonOrder(b ? "L_HE+U+FBIX_NCYOA_R" : s);
            this.setButtonMinWidth(70.0);
        }
        else if (Utils.isUnix()) {
            this.setButtonOrder(b ? "L_HE+UNYACBXIO_R" : s);
            this.setButtonMinWidth(85.0);
        }
        else {
            this.setButtonOrder(b ? "L_E+U+FBXI_YNOCAH_R" : s);
            this.setButtonMinWidth(75.0);
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ButtonBarSkin(this);
    }
    
    public final ObservableList<Node> getButtons() {
        return this.buttons;
    }
    
    public final StringProperty buttonOrderProperty() {
        return this.buttonOrderProperty;
    }
    
    public final void setButtonOrder(final String s) {
        this.buttonOrderProperty.set(s);
    }
    
    public final String getButtonOrder() {
        return this.buttonOrderProperty.get();
    }
    
    public final DoubleProperty buttonMinWidthProperty() {
        return this.buttonMinWidthProperty;
    }
    
    public final void setButtonMinWidth(final double n) {
        this.buttonMinWidthProperty.set(n);
    }
    
    public final double getButtonMinWidth() {
        return this.buttonMinWidthProperty.get();
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    public enum ButtonData
    {
        LEFT("L", false, false), 
        RIGHT("R", false, false), 
        HELP("H", false, false), 
        HELP_2("E", false, false), 
        YES("Y", false, true), 
        NO("N", true, false), 
        NEXT_FORWARD("X", false, true), 
        BACK_PREVIOUS("B", false, false), 
        FINISH("I", false, true), 
        APPLY("A", false, false), 
        CANCEL_CLOSE("C", true, false), 
        OK_DONE("O", false, true), 
        OTHER("U", false, false), 
        BIG_GAP("+", false, false), 
        SMALL_GAP("_", false, false);
        
        private final String typeCode;
        private final boolean cancelButton;
        private final boolean defaultButton;
        
        private ButtonData(final String typeCode, final boolean cancelButton, final boolean defaultButton) {
            this.typeCode = typeCode;
            this.cancelButton = cancelButton;
            this.defaultButton = defaultButton;
        }
        
        public String getTypeCode() {
            return this.typeCode;
        }
        
        public final boolean isCancelButton() {
            return this.cancelButton;
        }
        
        public final boolean isDefaultButton() {
            return this.defaultButton;
        }
    }
}
