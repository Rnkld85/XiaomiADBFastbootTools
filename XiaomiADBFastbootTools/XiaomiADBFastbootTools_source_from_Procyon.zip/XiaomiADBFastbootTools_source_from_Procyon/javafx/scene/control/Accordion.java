// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.Node;
import javafx.scene.control.skin.AccordionSkin;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.beans.property.ObjectPropertyBase;
import java.util.Iterator;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableList;
import javafx.geometry.Orientation;

public class Accordion extends Control
{
    private boolean biasDirty;
    private Orientation bias;
    private final ObservableList<TitledPane> panes;
    private ObjectProperty<TitledPane> expandedPane;
    private static final String DEFAULT_STYLE_CLASS = "accordion";
    
    public Accordion() {
        this((TitledPane[])null);
    }
    
    public Accordion(final TitledPane... array) {
        this.biasDirty = true;
        this.panes = new TrackableObservableList<TitledPane>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<TitledPane> change) {
                while (change.next()) {
                    if (change.wasRemoved() && !Accordion.this.expandedPane.isBound()) {
                        for (final TitledPane titledPane : change.getRemoved()) {
                            if (!change.getAddedSubList().contains(titledPane) && Accordion.this.getExpandedPane() == titledPane) {
                                Accordion.this.setExpandedPane(null);
                                break;
                            }
                        }
                    }
                }
            }
        };
        this.expandedPane = new ObjectPropertyBase<TitledPane>() {
            private TitledPane oldValue;
            
            @Override
            protected void invalidated() {
                final TitledPane oldValue = this.get();
                if (oldValue != null) {
                    oldValue.setExpanded(true);
                }
                else if (this.oldValue != null) {
                    this.oldValue.setExpanded(false);
                }
                this.oldValue = oldValue;
            }
            
            @Override
            public String getName() {
                return "expandedPane";
            }
            
            @Override
            public Object getBean() {
                return Accordion.this;
            }
        };
        this.getStyleClass().setAll("accordion");
        if (array != null) {
            this.getPanes().addAll(array);
        }
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
    }
    
    public final void setExpandedPane(final TitledPane titledPane) {
        this.expandedPaneProperty().set(titledPane);
    }
    
    public final TitledPane getExpandedPane() {
        return this.expandedPane.get();
    }
    
    public final ObjectProperty<TitledPane> expandedPaneProperty() {
        return this.expandedPane;
    }
    
    public final ObservableList<TitledPane> getPanes() {
        return this.panes;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new AccordionSkin(this);
    }
    
    @Override
    public void requestLayout() {
        this.biasDirty = true;
        this.bias = null;
        super.requestLayout();
    }
    
    @Override
    public Orientation getContentBias() {
        if (this.biasDirty) {
            this.bias = null;
            final Iterator<Node> iterator = this.getManagedChildren().iterator();
            while (iterator.hasNext()) {
                final Orientation contentBias = iterator.next().getContentBias();
                if (contentBias != null && (this.bias = contentBias) == Orientation.HORIZONTAL) {
                    break;
                }
            }
            this.biasDirty = false;
        }
        return this.bias;
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
}
