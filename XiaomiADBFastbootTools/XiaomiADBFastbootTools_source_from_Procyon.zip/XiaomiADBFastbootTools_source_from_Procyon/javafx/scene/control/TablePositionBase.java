// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.lang.ref.WeakReference;

public abstract class TablePositionBase<TC extends TableColumnBase>
{
    private final int row;
    private final WeakReference<TC> tableColumnRef;
    
    protected TablePositionBase(final int row, final TC referent) {
        this.row = row;
        this.tableColumnRef = new WeakReference<TC>(referent);
    }
    
    public int getRow() {
        return this.row;
    }
    
    public abstract int getColumn();
    
    public TC getTableColumn() {
        return this.tableColumnRef.get();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        final TablePositionBase tablePositionBase = (TablePositionBase)o;
        if (this.row != tablePositionBase.row) {
            return false;
        }
        final TableColumnBase tableColumn = this.getTableColumn();
        final TableColumnBase tableColumn2 = tablePositionBase.getTableColumn();
        return tableColumn == tableColumn2 || (tableColumn != null && tableColumn.equals(tableColumn2));
    }
    
    @Override
    public int hashCode() {
        final int n = 79 * 5 + this.row;
        final TableColumnBase tableColumn = this.getTableColumn();
        return 79 * n + ((tableColumn != null) ? tableColumn.hashCode() : 0);
    }
}
