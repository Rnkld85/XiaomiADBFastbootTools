// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.AccessibleAttribute;
import java.util.Collections;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.collections.ListChangeListener;
import javafx.css.Styleable;
import com.sun.javafx.collections.UnmodifiableListSet;
import java.util.Collection;
import java.util.Set;
import javafx.scene.Node;
import javafx.scene.control.skin.TabPaneSkin;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.ObjectPropertyBase;
import java.util.Iterator;
import javafx.scene.AccessibleRole;
import javafx.beans.property.SimpleObjectProperty;
import java.util.List;
import com.sun.javafx.scene.control.TabObservableList;
import java.util.ArrayList;
import javafx.css.PseudoClass;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.BooleanProperty;
import javafx.geometry.Side;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableList;
import javafx.beans.DefaultProperty;

@DefaultProperty("tabs")
public class TabPane extends Control
{
    private static final double DEFAULT_TAB_MIN_WIDTH = 0.0;
    private static final double DEFAULT_TAB_MAX_WIDTH = Double.MAX_VALUE;
    private static final double DEFAULT_TAB_MIN_HEIGHT = 0.0;
    private static final double DEFAULT_TAB_MAX_HEIGHT = Double.MAX_VALUE;
    public static final String STYLE_CLASS_FLOATING = "floating";
    private ObservableList<Tab> tabs;
    private ObjectProperty<SingleSelectionModel<Tab>> selectionModel;
    private ObjectProperty<Side> side;
    private ObjectProperty<TabClosingPolicy> tabClosingPolicy;
    private BooleanProperty rotateGraphic;
    private DoubleProperty tabMinWidth;
    private DoubleProperty tabMaxWidth;
    private DoubleProperty tabMinHeight;
    private DoubleProperty tabMaxHeight;
    private static final PseudoClass TOP_PSEUDOCLASS_STATE;
    private static final PseudoClass BOTTOM_PSEUDOCLASS_STATE;
    private static final PseudoClass LEFT_PSEUDOCLASS_STATE;
    private static final PseudoClass RIGHT_PSEUDOCLASS_STATE;
    private ObjectProperty<TabDragPolicy> tabDragPolicy;
    
    public TabPane() {
        this((Tab[])null);
    }
    
    public TabPane(final Tab... array) {
        this.tabs = new TabObservableList<Tab>(new ArrayList<Tab>());
        this.selectionModel = new SimpleObjectProperty<SingleSelectionModel<Tab>>(this, "selectionModel");
        this.getStyleClass().setAll("tab-pane");
        this.setAccessibleRole(AccessibleRole.TAB_PANE);
        this.setSelectionModel(new TabPaneSelectionModel(this));
        final Iterator<Tab> iterator;
        Tab tab;
        final Iterator<Tab> iterator2;
        Tab tab2;
        this.tabs.addListener(change -> {
            while (change.next()) {
                change.getRemoved().iterator();
                while (iterator.hasNext()) {
                    tab = iterator.next();
                    if (tab != null && !this.getTabs().contains(tab)) {
                        tab.setTabPane(null);
                    }
                }
                change.getAddedSubList().iterator();
                while (iterator2.hasNext()) {
                    tab2 = iterator2.next();
                    if (tab2 != null) {
                        tab2.setTabPane(this);
                    }
                }
            }
            return;
        });
        if (array != null) {
            this.getTabs().addAll(array);
        }
        final Side side = this.getSide();
        this.pseudoClassStateChanged(TabPane.TOP_PSEUDOCLASS_STATE, side == Side.TOP);
        this.pseudoClassStateChanged(TabPane.RIGHT_PSEUDOCLASS_STATE, side == Side.RIGHT);
        this.pseudoClassStateChanged(TabPane.BOTTOM_PSEUDOCLASS_STATE, side == Side.BOTTOM);
        this.pseudoClassStateChanged(TabPane.LEFT_PSEUDOCLASS_STATE, side == Side.LEFT);
    }
    
    public final ObservableList<Tab> getTabs() {
        return this.tabs;
    }
    
    public final void setSelectionModel(final SingleSelectionModel<Tab> singleSelectionModel) {
        this.selectionModel.set(singleSelectionModel);
    }
    
    public final SingleSelectionModel<Tab> getSelectionModel() {
        return this.selectionModel.get();
    }
    
    public final ObjectProperty<SingleSelectionModel<Tab>> selectionModelProperty() {
        return this.selectionModel;
    }
    
    public final void setSide(final Side side) {
        this.sideProperty().set(side);
    }
    
    public final Side getSide() {
        return (this.side == null) ? Side.TOP : this.side.get();
    }
    
    public final ObjectProperty<Side> sideProperty() {
        if (this.side == null) {
            this.side = new ObjectPropertyBase<Side>(Side.TOP) {
                private Side oldSide;
                
                @Override
                protected void invalidated() {
                    this.oldSide = this.get();
                    TabPane.this.pseudoClassStateChanged(TabPane.TOP_PSEUDOCLASS_STATE, this.oldSide == Side.TOP || this.oldSide == null);
                    TabPane.this.pseudoClassStateChanged(TabPane.RIGHT_PSEUDOCLASS_STATE, this.oldSide == Side.RIGHT);
                    TabPane.this.pseudoClassStateChanged(TabPane.BOTTOM_PSEUDOCLASS_STATE, this.oldSide == Side.BOTTOM);
                    TabPane.this.pseudoClassStateChanged(TabPane.LEFT_PSEUDOCLASS_STATE, this.oldSide == Side.LEFT);
                }
                
                @Override
                public Object getBean() {
                    return TabPane.this;
                }
                
                @Override
                public String getName() {
                    return "side";
                }
            };
        }
        return this.side;
    }
    
    public final void setTabClosingPolicy(final TabClosingPolicy tabClosingPolicy) {
        this.tabClosingPolicyProperty().set(tabClosingPolicy);
    }
    
    public final TabClosingPolicy getTabClosingPolicy() {
        return (this.tabClosingPolicy == null) ? TabClosingPolicy.SELECTED_TAB : this.tabClosingPolicy.get();
    }
    
    public final ObjectProperty<TabClosingPolicy> tabClosingPolicyProperty() {
        if (this.tabClosingPolicy == null) {
            this.tabClosingPolicy = new SimpleObjectProperty<TabClosingPolicy>(this, "tabClosingPolicy", TabClosingPolicy.SELECTED_TAB);
        }
        return this.tabClosingPolicy;
    }
    
    public final void setRotateGraphic(final boolean b) {
        this.rotateGraphicProperty().set(b);
    }
    
    public final boolean isRotateGraphic() {
        return this.rotateGraphic != null && this.rotateGraphic.get();
    }
    
    public final BooleanProperty rotateGraphicProperty() {
        if (this.rotateGraphic == null) {
            this.rotateGraphic = new SimpleBooleanProperty(this, "rotateGraphic", false);
        }
        return this.rotateGraphic;
    }
    
    public final void setTabMinWidth(final double d) {
        this.tabMinWidthProperty().setValue(d);
    }
    
    public final double getTabMinWidth() {
        return (this.tabMinWidth == null) ? 0.0 : this.tabMinWidth.getValue();
    }
    
    public final DoubleProperty tabMinWidthProperty() {
        if (this.tabMinWidth == null) {
            this.tabMinWidth = new StyleableDoubleProperty(0.0) {
                @Override
                public CssMetaData<TabPane, Number> getCssMetaData() {
                    return StyleableProperties.TAB_MIN_WIDTH;
                }
                
                @Override
                public Object getBean() {
                    return TabPane.this;
                }
                
                @Override
                public String getName() {
                    return "tabMinWidth";
                }
            };
        }
        return this.tabMinWidth;
    }
    
    public final void setTabMaxWidth(final double d) {
        this.tabMaxWidthProperty().setValue(d);
    }
    
    public final double getTabMaxWidth() {
        return (this.tabMaxWidth == null) ? Double.MAX_VALUE : this.tabMaxWidth.getValue();
    }
    
    public final DoubleProperty tabMaxWidthProperty() {
        if (this.tabMaxWidth == null) {
            this.tabMaxWidth = new StyleableDoubleProperty(Double.MAX_VALUE) {
                @Override
                public CssMetaData<TabPane, Number> getCssMetaData() {
                    return StyleableProperties.TAB_MAX_WIDTH;
                }
                
                @Override
                public Object getBean() {
                    return TabPane.this;
                }
                
                @Override
                public String getName() {
                    return "tabMaxWidth";
                }
            };
        }
        return this.tabMaxWidth;
    }
    
    public final void setTabMinHeight(final double d) {
        this.tabMinHeightProperty().setValue(d);
    }
    
    public final double getTabMinHeight() {
        return (this.tabMinHeight == null) ? 0.0 : this.tabMinHeight.getValue();
    }
    
    public final DoubleProperty tabMinHeightProperty() {
        if (this.tabMinHeight == null) {
            this.tabMinHeight = new StyleableDoubleProperty(0.0) {
                @Override
                public CssMetaData<TabPane, Number> getCssMetaData() {
                    return StyleableProperties.TAB_MIN_HEIGHT;
                }
                
                @Override
                public Object getBean() {
                    return TabPane.this;
                }
                
                @Override
                public String getName() {
                    return "tabMinHeight";
                }
            };
        }
        return this.tabMinHeight;
    }
    
    public final void setTabMaxHeight(final double d) {
        this.tabMaxHeightProperty().setValue(d);
    }
    
    public final double getTabMaxHeight() {
        return (this.tabMaxHeight == null) ? Double.MAX_VALUE : this.tabMaxHeight.getValue();
    }
    
    public final DoubleProperty tabMaxHeightProperty() {
        if (this.tabMaxHeight == null) {
            this.tabMaxHeight = new StyleableDoubleProperty(Double.MAX_VALUE) {
                @Override
                public CssMetaData<TabPane, Number> getCssMetaData() {
                    return StyleableProperties.TAB_MAX_HEIGHT;
                }
                
                @Override
                public Object getBean() {
                    return TabPane.this;
                }
                
                @Override
                public String getName() {
                    return "tabMaxHeight";
                }
            };
        }
        return this.tabMaxHeight;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TabPaneSkin(this);
    }
    
    @Override
    public Node lookup(final String s) {
        Node node = super.lookup(s);
        if (node == null) {
            final Iterator<Tab> iterator = this.tabs.iterator();
            while (iterator.hasNext()) {
                node = iterator.next().lookup(s);
                if (node != null) {
                    break;
                }
            }
        }
        return node;
    }
    
    @Override
    public Set<Node> lookupAll(final String s) {
        if (s == null) {
            return null;
        }
        final ArrayList<Node> list = new ArrayList<Node>();
        list.addAll((Collection<?>)super.lookupAll(s));
        final Iterator<Tab> iterator = this.tabs.iterator();
        while (iterator.hasNext()) {
            list.addAll((Collection<?>)iterator.next().lookupAll(s));
        }
        return new UnmodifiableListSet<Node>((List<Object>)list);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    public final ObjectProperty<TabDragPolicy> tabDragPolicyProperty() {
        if (this.tabDragPolicy == null) {
            this.tabDragPolicy = new SimpleObjectProperty<TabDragPolicy>(this, "tabDragPolicy", TabDragPolicy.FIXED);
        }
        return this.tabDragPolicy;
    }
    
    public final void setTabDragPolicy(final TabDragPolicy tabDragPolicy) {
        this.tabDragPolicyProperty().set(tabDragPolicy);
    }
    
    public final TabDragPolicy getTabDragPolicy() {
        return this.tabDragPolicyProperty().get();
    }
    
    static {
        TOP_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("top");
        BOTTOM_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("bottom");
        LEFT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("left");
        RIGHT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("right");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TabPane, Number> TAB_MIN_WIDTH;
        private static final CssMetaData<TabPane, Number> TAB_MAX_WIDTH;
        private static final CssMetaData<TabPane, Number> TAB_MIN_HEIGHT;
        private static final CssMetaData<TabPane, Number> TAB_MAX_HEIGHT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            TAB_MIN_WIDTH = new CssMetaData<TabPane, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final TabPane tabPane) {
                    return tabPane.tabMinWidth == null || !tabPane.tabMinWidth.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TabPane tabPane) {
                    return (StyleableProperty<Number>)tabPane.tabMinWidthProperty();
                }
            };
            TAB_MAX_WIDTH = new CssMetaData<TabPane, Number>((StyleConverter)SizeConverter.getInstance(), (Number)Double.MAX_VALUE) {
                @Override
                public boolean isSettable(final TabPane tabPane) {
                    return tabPane.tabMaxWidth == null || !tabPane.tabMaxWidth.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TabPane tabPane) {
                    return (StyleableProperty<Number>)tabPane.tabMaxWidthProperty();
                }
            };
            TAB_MIN_HEIGHT = new CssMetaData<TabPane, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final TabPane tabPane) {
                    return tabPane.tabMinHeight == null || !tabPane.tabMinHeight.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TabPane tabPane) {
                    return (StyleableProperty<Number>)tabPane.tabMinHeightProperty();
                }
            };
            TAB_MAX_HEIGHT = new CssMetaData<TabPane, Number>((StyleConverter)SizeConverter.getInstance(), (Number)Double.MAX_VALUE) {
                @Override
                public boolean isSettable(final TabPane tabPane) {
                    return tabPane.tabMaxHeight == null || !tabPane.tabMaxHeight.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TabPane tabPane) {
                    return (StyleableProperty<Number>)tabPane.tabMaxHeightProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.TAB_MIN_WIDTH);
            list.add(StyleableProperties.TAB_MAX_WIDTH);
            list.add(StyleableProperties.TAB_MIN_HEIGHT);
            list.add(StyleableProperties.TAB_MAX_HEIGHT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    static class TabPaneSelectionModel extends SingleSelectionModel<Tab>
    {
        private final TabPane tabPane;
        
        public TabPaneSelectionModel(final TabPane tabPane) {
            if (tabPane == null) {
                throw new NullPointerException("TabPane can not be null");
            }
            this.tabPane = tabPane;
            final Iterator<Tab> iterator;
            Tab tab;
            final ListChangeListener<? super Tab> listChangeListener = change -> {
                while (change.next()) {
                    change.getRemoved().iterator();
                    while (iterator.hasNext()) {
                        tab = iterator.next();
                        if (tab != null && !this.tabPane.getTabs().contains(tab) && tab.isSelected()) {
                            tab.setSelected((boolean)(0 != 0));
                            this.findNearestAvailableTab(change.getFrom(), true);
                        }
                    }
                    if ((change.wasAdded() || change.wasRemoved()) && this.getSelectedIndex() != this.tabPane.getTabs().indexOf(((SelectionModel<Object>)this).getSelectedItem())) {
                        this.clearAndSelect(this.tabPane.getTabs().indexOf(((SelectionModel<Object>)this).getSelectedItem()));
                    }
                }
                if (this.getSelectedIndex() == -1 && this.getSelectedItem() == null && this.tabPane.getTabs().size() > 0) {
                    this.findNearestAvailableTab(0, (boolean)(1 != 0));
                }
                else if (this.tabPane.getTabs().isEmpty()) {
                    this.clearSelection();
                }
                return;
            };
            if (this.tabPane.getTabs() != null) {
                this.tabPane.getTabs().addListener(listChangeListener);
            }
        }
        
        @Override
        public void select(final int selectedIndex) {
            if (selectedIndex < 0 || (this.getItemCount() > 0 && selectedIndex >= this.getItemCount()) || (selectedIndex == this.getSelectedIndex() && this.getModelItem(selectedIndex).isSelected())) {
                return;
            }
            if (this.getSelectedIndex() >= 0 && this.getSelectedIndex() < this.tabPane.getTabs().size()) {
                this.tabPane.getTabs().get(this.getSelectedIndex()).setSelected(false);
            }
            this.setSelectedIndex(selectedIndex);
            final Tab modelItem = this.getModelItem(selectedIndex);
            if (modelItem != null) {
                this.setSelectedItem(modelItem);
            }
            if (this.getSelectedIndex() >= 0 && this.getSelectedIndex() < this.tabPane.getTabs().size()) {
                this.tabPane.getTabs().get(this.getSelectedIndex()).setSelected(true);
            }
            this.tabPane.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
        }
        
        @Override
        public void select(final Tab obj) {
            for (int itemCount = this.getItemCount(), i = 0; i < itemCount; ++i) {
                final Tab modelItem = this.getModelItem(i);
                if (modelItem != null && modelItem.equals(obj)) {
                    this.select(i);
                    return;
                }
            }
        }
        
        @Override
        protected Tab getModelItem(final int n) {
            final ObservableList<Tab> tabs = this.tabPane.getTabs();
            if (tabs == null) {
                return null;
            }
            if (n < 0 || n >= tabs.size()) {
                return null;
            }
            return (Tab)tabs.get(n);
        }
        
        @Override
        protected int getItemCount() {
            final ObservableList<Tab> tabs = this.tabPane.getTabs();
            return (tabs == null) ? 0 : tabs.size();
        }
        
        private Tab findNearestAvailableTab(final int n, final boolean b) {
            final int itemCount = this.getItemCount();
            int n2 = 1;
            Tab tab = null;
            while (true) {
                final int n3 = n - n2;
                if (n3 >= 0) {
                    final Tab modelItem = this.getModelItem(n3);
                    if (modelItem != null && !modelItem.isDisable()) {
                        tab = modelItem;
                        break;
                    }
                }
                final int n4 = n + n2 - 1;
                if (n4 < itemCount) {
                    final Tab modelItem2 = this.getModelItem(n4);
                    if (modelItem2 != null && !modelItem2.isDisable()) {
                        tab = modelItem2;
                        break;
                    }
                }
                if (n3 < 0 && n4 >= itemCount) {
                    break;
                }
                ++n2;
            }
            if (b && tab != null) {
                this.select(tab);
            }
            return tab;
        }
    }
    
    public enum TabClosingPolicy
    {
        SELECTED_TAB, 
        ALL_TABS, 
        UNAVAILABLE;
    }
    
    public enum TabDragPolicy
    {
        FIXED, 
        REORDER;
    }
}
