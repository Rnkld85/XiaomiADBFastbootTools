// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.Observable;
import javafx.scene.AccessibleAttribute;
import javafx.collections.ObservableList;
import javafx.scene.control.skin.TableRowSkin;
import java.lang.ref.WeakReference;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.AccessibleRole;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.WeakInvalidationListener;
import javafx.collections.WeakListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;

public class TableRow<T> extends IndexedCell<T>
{
    private ListChangeListener<Integer> selectedListener;
    private final InvalidationListener focusedListener;
    private final InvalidationListener editingListener;
    private final WeakListChangeListener<Integer> weakSelectedListener;
    private final WeakInvalidationListener weakFocusedListener;
    private final WeakInvalidationListener weakEditingListener;
    private ReadOnlyObjectWrapper<TableView<T>> tableView;
    private boolean isFirstRun;
    private static final String DEFAULT_STYLE_CLASS = "table-row-cell";
    
    public TableRow() {
        this.selectedListener = (p0 -> this.updateSelection());
        this.focusedListener = (p0 -> this.updateFocus());
        this.editingListener = (p0 -> this.updateEditing());
        this.weakSelectedListener = new WeakListChangeListener<Integer>(this.selectedListener);
        this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
        this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
        this.isFirstRun = true;
        this.getStyleClass().addAll("table-row-cell");
        this.setAccessibleRole(AccessibleRole.TABLE_ROW);
    }
    
    private void setTableView(final TableView<T> tableView) {
        this.tableViewPropertyImpl().set(tableView);
    }
    
    public final TableView<T> getTableView() {
        return (this.tableView == null) ? null : this.tableView.get();
    }
    
    public final ReadOnlyObjectProperty<TableView<T>> tableViewProperty() {
        return this.tableViewPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<TableView<T>> tableViewPropertyImpl() {
        if (this.tableView == null) {
            this.tableView = new ReadOnlyObjectWrapper<TableView<T>>() {
                private WeakReference<TableView<T>> weakTableViewRef;
                
                @Override
                protected void invalidated() {
                    if (this.weakTableViewRef != null) {
                        final TableView tableView = this.weakTableViewRef.get();
                        if (tableView != null) {
                            final TableView.TableViewSelectionModel selectionModel = tableView.getSelectionModel();
                            if (selectionModel != null) {
                                selectionModel.getSelectedIndices().removeListener(TableRow.this.weakSelectedListener);
                            }
                            final TableView.TableViewFocusModel focusModel = tableView.getFocusModel();
                            if (focusModel != null) {
                                focusModel.focusedCellProperty().removeListener(TableRow.this.weakFocusedListener);
                            }
                            tableView.editingCellProperty().removeListener(TableRow.this.weakEditingListener);
                        }
                        this.weakTableViewRef = null;
                    }
                    final TableView<T> tableView2 = TableRow.this.getTableView();
                    if (tableView2 != null) {
                        final TableView.TableViewSelectionModel<T> selectionModel2 = tableView2.getSelectionModel();
                        if (selectionModel2 != null) {
                            selectionModel2.getSelectedIndices().addListener(TableRow.this.weakSelectedListener);
                        }
                        final TableView.TableViewFocusModel<T> focusModel2 = tableView2.getFocusModel();
                        if (focusModel2 != null) {
                            focusModel2.focusedCellProperty().addListener(TableRow.this.weakFocusedListener);
                        }
                        tableView2.editingCellProperty().addListener(TableRow.this.weakEditingListener);
                        this.weakTableViewRef = new WeakReference<TableView<T>>((TableView<T>)((ObjectPropertyBase<TableView<?>>)this).get());
                    }
                }
                
                @Override
                public Object getBean() {
                    return TableRow.this;
                }
                
                @Override
                public String getName() {
                    return "tableView";
                }
            };
        }
        return this.tableView;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TableRowSkin<Object>(this);
    }
    
    @Override
    void indexChanged(final int n, final int n2) {
        super.indexChanged(n, n2);
        this.updateItem(n);
        this.updateSelection();
        this.updateFocus();
    }
    
    private void updateItem(final int n) {
        final TableView<Object> tableView = (TableView<Object>)this.getTableView();
        if (tableView == null || tableView.getItems() == null) {
            return;
        }
        final ObservableList<Object> items = (ObservableList<Object>)tableView.getItems();
        final int n2 = (items == null) ? -1 : items.size();
        final int index = this.getIndex();
        final boolean b = index >= 0 && index < n2;
        final T item = this.getItem();
        final boolean empty = this.isEmpty();
        if (b) {
            final T value = items.get(index);
            if (n != index || this.isItemChanged(item, value)) {
                this.updateItem(value, false);
            }
        }
        else if ((!empty && item != null) || this.isFirstRun) {
            this.updateItem(null, true);
            this.isFirstRun = false;
        }
    }
    
    private void updateSelection() {
        if (this.getIndex() == -1) {
            return;
        }
        final TableView<T> tableView = this.getTableView();
        this.updateSelected(tableView != null && tableView.getSelectionModel() != null && !tableView.getSelectionModel().isCellSelectionEnabled() && tableView.getSelectionModel().isSelected(this.getIndex()));
    }
    
    private void updateFocus() {
        if (this.getIndex() == -1) {
            return;
        }
        final TableView<T> tableView = this.getTableView();
        if (tableView == null) {
            return;
        }
        final TableView.TableViewSelectionModel<T> selectionModel = tableView.getSelectionModel();
        final TableView.TableViewFocusModel<T> focusModel = tableView.getFocusModel();
        if (selectionModel == null || focusModel == null) {
            return;
        }
        this.setFocused(!selectionModel.isCellSelectionEnabled() && focusModel.isFocused(this.getIndex()));
    }
    
    private void updateEditing() {
        if (this.getIndex() == -1) {
            return;
        }
        final TableView<T> tableView = this.getTableView();
        if (tableView == null) {
            return;
        }
        final TableView.TableViewSelectionModel<T> selectionModel = tableView.getSelectionModel();
        if (selectionModel == null || selectionModel.isCellSelectionEnabled()) {
            return;
        }
        final TablePosition<T, ?> editingCell = tableView.getEditingCell();
        if (editingCell != null && editingCell.getTableColumn() != null) {
            return;
        }
        final boolean b = editingCell != null && editingCell.getRow() == this.getIndex();
        if (!this.isEditing() && b) {
            this.startEdit();
        }
        else if (this.isEditing() && !b) {
            this.cancelEdit();
        }
    }
    
    public final void updateTableView(final TableView<T> tableView) {
        this.setTableView(tableView);
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case INDEX: {
                return this.getIndex();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
}
