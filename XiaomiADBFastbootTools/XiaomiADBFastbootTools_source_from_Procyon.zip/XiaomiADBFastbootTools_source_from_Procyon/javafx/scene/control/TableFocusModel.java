// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

public abstract class TableFocusModel<T, TC extends TableColumnBase<T, ?>> extends FocusModel<T>
{
    public abstract void focus(final int p0, final TC p1);
    
    public abstract boolean isFocused(final int p0, final TC p1);
    
    public abstract void focusAboveCell();
    
    public abstract void focusBelowCell();
    
    public abstract void focusLeftCell();
    
    public abstract void focusRightCell();
}
