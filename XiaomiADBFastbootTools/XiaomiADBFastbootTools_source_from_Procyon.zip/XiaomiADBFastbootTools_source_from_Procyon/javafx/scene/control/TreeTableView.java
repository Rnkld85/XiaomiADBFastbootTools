// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.binding.ObjectExpression;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import java.util.stream.Stream;
import java.util.function.Consumer;
import java.util.Objects;
import java.util.LinkedHashSet;
import com.sun.javafx.scene.control.behavior.CellBehaviorBase;
import java.util.HashMap;
import com.sun.javafx.scene.control.ReadOnlyUnbackedObservableList;
import com.sun.javafx.scene.control.SelectedCellsMap;
import javafx.beans.value.WeakChangeListener;
import javafx.beans.value.ChangeListener;
import com.sun.javafx.collections.MappingChange;
import java.util.Collections;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.collections.MapChangeListener;
import javafx.collections.FXCollections;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.skin.TreeTableViewSkin;
import javafx.css.Styleable;
import java.util.Iterator;
import com.sun.javafx.collections.NonIterableChange;
import java.util.Collection;
import java.util.ArrayList;
import javafx.event.Event;
import javafx.event.EventTarget;
import java.util.List;
import com.sun.javafx.scene.control.TableColumnComparatorBase;
import javafx.beans.property.ObjectPropertyBase;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.beans.Observable;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.css.PseudoClass;
import java.util.Comparator;
import javafx.beans.property.DoubleProperty;
import javafx.scene.Node;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.collections.WeakListChangeListener;
import javafx.beans.WeakInvalidationListener;
import javafx.event.WeakEventHandler;
import javafx.beans.InvalidationListener;
import java.util.WeakHashMap;
import javafx.collections.ListChangeListener;
import javafx.event.EventHandler;
import javafx.collections.ObservableList;
import java.lang.ref.SoftReference;
import java.util.Map;
import javafx.util.Callback;
import javafx.event.EventType;
import javafx.beans.DefaultProperty;

@DefaultProperty("root")
public class TreeTableView<S> extends Control
{
    private static final EventType<?> EDIT_ANY_EVENT;
    private static final EventType<?> EDIT_START_EVENT;
    private static final EventType<?> EDIT_CANCEL_EVENT;
    private static final EventType<?> EDIT_COMMIT_EVENT;
    public static final Callback<ResizeFeatures, Boolean> UNCONSTRAINED_RESIZE_POLICY;
    public static final Callback<ResizeFeatures, Boolean> CONSTRAINED_RESIZE_POLICY;
    public static final Callback<TreeTableView, Boolean> DEFAULT_SORT_POLICY;
    private boolean expandedItemCountDirty;
    private Map<Integer, SoftReference<TreeItem<S>>> treeItemCacheMap;
    private final ObservableList<TreeTableColumn<S, ?>> columns;
    private final ObservableList<TreeTableColumn<S, ?>> visibleLeafColumns;
    private final ObservableList<TreeTableColumn<S, ?>> unmodifiableVisibleLeafColumns;
    private ObservableList<TreeTableColumn<S, ?>> sortOrder;
    double contentWidth;
    private boolean isInited;
    private final EventHandler<TreeItem.TreeModificationEvent<S>> rootEvent;
    private final ListChangeListener<TreeTableColumn<S, ?>> columnsObserver;
    private final WeakHashMap<TreeTableColumn<S, ?>, Integer> lastKnownColumnIndex;
    private final InvalidationListener columnVisibleObserver;
    private final InvalidationListener columnSortableObserver;
    private final InvalidationListener columnSortTypeObserver;
    private final InvalidationListener columnComparatorObserver;
    private final InvalidationListener cellSelectionModelInvalidationListener;
    private WeakEventHandler<TreeItem.TreeModificationEvent<S>> weakRootEventListener;
    private final WeakInvalidationListener weakColumnVisibleObserver;
    private final WeakInvalidationListener weakColumnSortableObserver;
    private final WeakInvalidationListener weakColumnSortTypeObserver;
    private final WeakInvalidationListener weakColumnComparatorObserver;
    private final WeakListChangeListener<TreeTableColumn<S, ?>> weakColumnsObserver;
    private final WeakInvalidationListener weakCellSelectionModelInvalidationListener;
    private ObjectProperty<TreeItem<S>> root;
    private BooleanProperty showRoot;
    private ObjectProperty<TreeTableColumn<S, ?>> treeColumn;
    private ObjectProperty<TreeTableViewSelectionModel<S>> selectionModel;
    private ObjectProperty<TreeTableViewFocusModel<S>> focusModel;
    private ReadOnlyIntegerWrapper expandedItemCount;
    private BooleanProperty editable;
    private ReadOnlyObjectWrapper<TreeTablePosition<S, ?>> editingCell;
    private BooleanProperty tableMenuButtonVisible;
    private ObjectProperty<Callback<ResizeFeatures, Boolean>> columnResizePolicy;
    private ObjectProperty<Callback<TreeTableView<S>, TreeTableRow<S>>> rowFactory;
    private ObjectProperty<Node> placeholder;
    private DoubleProperty fixedCellSize;
    private ObjectProperty<TreeSortMode> sortMode;
    private ReadOnlyObjectWrapper<Comparator<TreeItem<S>>> comparator;
    private ObjectProperty<Callback<TreeTableView<S>, Boolean>> sortPolicy;
    private ObjectProperty<EventHandler<SortEvent<TreeTableView<S>>>> onSort;
    private ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollTo;
    private ObjectProperty<EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>>> onScrollToColumn;
    private boolean sortLock;
    private TableUtil.SortEventType lastSortEventType;
    private Object[] lastSortEventSupportInfo;
    private static final String DEFAULT_STYLE_CLASS = "tree-table-view";
    private static final PseudoClass PSEUDO_CLASS_CELL_SELECTION;
    private static final PseudoClass PSEUDO_CLASS_ROW_SELECTION;
    
    public TreeTableView() {
        this(null);
    }
    
    public TreeTableView(final TreeItem<S> p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokespecial   javafx/scene/control/Control.<init>:()V
        //     4: aload_0        
        //     5: iconst_1       
        //     6: putfield        javafx/scene/control/TreeTableView.expandedItemCountDirty:Z
        //     9: aload_0        
        //    10: new             Ljava/util/HashMap;
        //    13: dup            
        //    14: invokespecial   java/util/HashMap.<init>:()V
        //    17: putfield        javafx/scene/control/TreeTableView.treeItemCacheMap:Ljava/util/Map;
        //    20: aload_0        
        //    21: invokestatic    javafx/collections/FXCollections.observableArrayList:()Ljavafx/collections/ObservableList;
        //    24: putfield        javafx/scene/control/TreeTableView.columns:Ljavafx/collections/ObservableList;
        //    27: aload_0        
        //    28: invokestatic    javafx/collections/FXCollections.observableArrayList:()Ljavafx/collections/ObservableList;
        //    31: putfield        javafx/scene/control/TreeTableView.visibleLeafColumns:Ljavafx/collections/ObservableList;
        //    34: aload_0        
        //    35: aload_0        
        //    36: getfield        javafx/scene/control/TreeTableView.visibleLeafColumns:Ljavafx/collections/ObservableList;
        //    39: invokestatic    javafx/collections/FXCollections.unmodifiableObservableList:(Ljavafx/collections/ObservableList;)Ljavafx/collections/ObservableList;
        //    42: putfield        javafx/scene/control/TreeTableView.unmodifiableVisibleLeafColumns:Ljavafx/collections/ObservableList;
        //    45: aload_0        
        //    46: invokestatic    javafx/collections/FXCollections.observableArrayList:()Ljavafx/collections/ObservableList;
        //    49: putfield        javafx/scene/control/TreeTableView.sortOrder:Ljavafx/collections/ObservableList;
        //    52: aload_0        
        //    53: iconst_0       
        //    54: putfield        javafx/scene/control/TreeTableView.isInited:Z
        //    57: aload_0        
        //    58: aload_0        
        //    59: invokedynamic   BootstrapMethod #0, handle:(Ljavafx/scene/control/TreeTableView;)Ljavafx/event/EventHandler;
        //    64: putfield        javafx/scene/control/TreeTableView.rootEvent:Ljavafx/event/EventHandler;
        //    67: aload_0        
        //    68: new             Ljavafx/scene/control/TreeTableView$4;
        //    71: dup            
        //    72: aload_0        
        //    73: invokespecial   javafx/scene/control/TreeTableView$4.<init>:(Ljavafx/scene/control/TreeTableView;)V
        //    76: putfield        javafx/scene/control/TreeTableView.columnsObserver:Ljavafx/collections/ListChangeListener;
        //    79: aload_0        
        //    80: new             Ljava/util/WeakHashMap;
        //    83: dup            
        //    84: invokespecial   java/util/WeakHashMap.<init>:()V
        //    87: putfield        javafx/scene/control/TreeTableView.lastKnownColumnIndex:Ljava/util/WeakHashMap;
        //    90: aload_0        
        //    91: aload_0        
        //    92: invokedynamic   BootstrapMethod #1, invalidated:(Ljavafx/scene/control/TreeTableView;)Ljavafx/beans/InvalidationListener;
        //    97: putfield        javafx/scene/control/TreeTableView.columnVisibleObserver:Ljavafx/beans/InvalidationListener;
        //   100: aload_0        
        //   101: aload_0        
        //   102: invokedynamic   BootstrapMethod #2, invalidated:(Ljavafx/scene/control/TreeTableView;)Ljavafx/beans/InvalidationListener;
        //   107: putfield        javafx/scene/control/TreeTableView.columnSortableObserver:Ljavafx/beans/InvalidationListener;
        //   110: aload_0        
        //   111: aload_0        
        //   112: invokedynamic   BootstrapMethod #3, invalidated:(Ljavafx/scene/control/TreeTableView;)Ljavafx/beans/InvalidationListener;
        //   117: putfield        javafx/scene/control/TreeTableView.columnSortTypeObserver:Ljavafx/beans/InvalidationListener;
        //   120: aload_0        
        //   121: aload_0        
        //   122: invokedynamic   BootstrapMethod #4, invalidated:(Ljavafx/scene/control/TreeTableView;)Ljavafx/beans/InvalidationListener;
        //   127: putfield        javafx/scene/control/TreeTableView.columnComparatorObserver:Ljavafx/beans/InvalidationListener;
        //   130: aload_0        
        //   131: aload_0        
        //   132: invokedynamic   BootstrapMethod #5, invalidated:(Ljavafx/scene/control/TreeTableView;)Ljavafx/beans/InvalidationListener;
        //   137: putfield        javafx/scene/control/TreeTableView.cellSelectionModelInvalidationListener:Ljavafx/beans/InvalidationListener;
        //   140: aload_0        
        //   141: new             Ljavafx/beans/WeakInvalidationListener;
        //   144: dup            
        //   145: aload_0        
        //   146: getfield        javafx/scene/control/TreeTableView.columnVisibleObserver:Ljavafx/beans/InvalidationListener;
        //   149: invokespecial   javafx/beans/WeakInvalidationListener.<init>:(Ljavafx/beans/InvalidationListener;)V
        //   152: putfield        javafx/scene/control/TreeTableView.weakColumnVisibleObserver:Ljavafx/beans/WeakInvalidationListener;
        //   155: aload_0        
        //   156: new             Ljavafx/beans/WeakInvalidationListener;
        //   159: dup            
        //   160: aload_0        
        //   161: getfield        javafx/scene/control/TreeTableView.columnSortableObserver:Ljavafx/beans/InvalidationListener;
        //   164: invokespecial   javafx/beans/WeakInvalidationListener.<init>:(Ljavafx/beans/InvalidationListener;)V
        //   167: putfield        javafx/scene/control/TreeTableView.weakColumnSortableObserver:Ljavafx/beans/WeakInvalidationListener;
        //   170: aload_0        
        //   171: new             Ljavafx/beans/WeakInvalidationListener;
        //   174: dup            
        //   175: aload_0        
        //   176: getfield        javafx/scene/control/TreeTableView.columnSortTypeObserver:Ljavafx/beans/InvalidationListener;
        //   179: invokespecial   javafx/beans/WeakInvalidationListener.<init>:(Ljavafx/beans/InvalidationListener;)V
        //   182: putfield        javafx/scene/control/TreeTableView.weakColumnSortTypeObserver:Ljavafx/beans/WeakInvalidationListener;
        //   185: aload_0        
        //   186: new             Ljavafx/beans/WeakInvalidationListener;
        //   189: dup            
        //   190: aload_0        
        //   191: getfield        javafx/scene/control/TreeTableView.columnComparatorObserver:Ljavafx/beans/InvalidationListener;
        //   194: invokespecial   javafx/beans/WeakInvalidationListener.<init>:(Ljavafx/beans/InvalidationListener;)V
        //   197: putfield        javafx/scene/control/TreeTableView.weakColumnComparatorObserver:Ljavafx/beans/WeakInvalidationListener;
        //   200: aload_0        
        //   201: new             Ljavafx/collections/WeakListChangeListener;
        //   204: dup            
        //   205: aload_0        
        //   206: getfield        javafx/scene/control/TreeTableView.columnsObserver:Ljavafx/collections/ListChangeListener;
        //   209: invokespecial   javafx/collections/WeakListChangeListener.<init>:(Ljavafx/collections/ListChangeListener;)V
        //   212: putfield        javafx/scene/control/TreeTableView.weakColumnsObserver:Ljavafx/collections/WeakListChangeListener;
        //   215: aload_0        
        //   216: new             Ljavafx/beans/WeakInvalidationListener;
        //   219: dup            
        //   220: aload_0        
        //   221: getfield        javafx/scene/control/TreeTableView.cellSelectionModelInvalidationListener:Ljavafx/beans/InvalidationListener;
        //   224: invokespecial   javafx/beans/WeakInvalidationListener.<init>:(Ljavafx/beans/InvalidationListener;)V
        //   227: putfield        javafx/scene/control/TreeTableView.weakCellSelectionModelInvalidationListener:Ljavafx/beans/WeakInvalidationListener;
        //   230: aload_0        
        //   231: new             Ljavafx/scene/control/TreeTableView$5;
        //   234: dup            
        //   235: aload_0        
        //   236: aload_0        
        //   237: ldc             "root"
        //   239: invokespecial   javafx/scene/control/TreeTableView$5.<init>:(Ljavafx/scene/control/TreeTableView;Ljava/lang/Object;Ljava/lang/String;)V
        //   242: putfield        javafx/scene/control/TreeTableView.root:Ljavafx/beans/property/ObjectProperty;
        //   245: aload_0        
        //   246: new             Ljavafx/beans/property/ReadOnlyIntegerWrapper;
        //   249: dup            
        //   250: aload_0        
        //   251: ldc             "expandedItemCount"
        //   253: iconst_0       
        //   254: invokespecial   javafx/beans/property/ReadOnlyIntegerWrapper.<init>:(Ljava/lang/Object;Ljava/lang/String;I)V
        //   257: putfield        javafx/scene/control/TreeTableView.expandedItemCount:Ljavafx/beans/property/ReadOnlyIntegerWrapper;
        //   260: aload_0        
        //   261: iconst_0       
        //   262: putfield        javafx/scene/control/TreeTableView.sortLock:Z
        //   265: aload_0        
        //   266: aconst_null    
        //   267: putfield        javafx/scene/control/TreeTableView.lastSortEventType:Ljavafx/scene/control/TableUtil$SortEventType;
        //   270: aload_0        
        //   271: aconst_null    
        //   272: putfield        javafx/scene/control/TreeTableView.lastSortEventSupportInfo:[Ljava/lang/Object;
        //   275: aload_0        
        //   276: invokevirtual   javafx/scene/control/TreeTableView.getStyleClass:()Ljavafx/collections/ObservableList;
        //   279: iconst_1       
        //   280: anewarray       Ljava/lang/String;
        //   283: dup            
        //   284: iconst_0       
        //   285: ldc             "tree-table-view"
        //   287: aastore        
        //   288: invokeinterface javafx/collections/ObservableList.setAll:([Ljava/lang/Object;)Z
        //   293: pop            
        //   294: aload_0        
        //   295: getstatic       javafx/scene/AccessibleRole.TREE_TABLE_VIEW:Ljavafx/scene/AccessibleRole;
        //   298: invokevirtual   javafx/scene/control/TreeTableView.setAccessibleRole:(Ljavafx/scene/AccessibleRole;)V
        //   301: aload_0        
        //   302: aload_1        
        //   303: invokevirtual   javafx/scene/control/TreeTableView.setRoot:(Ljavafx/scene/control/TreeItem;)V
        //   306: aload_0        
        //   307: aload_1        
        //   308: invokespecial   javafx/scene/control/TreeTableView.updateExpandedItemCount:(Ljavafx/scene/control/TreeItem;)V
        //   311: aload_0        
        //   312: new             Ljavafx/scene/control/TreeTableView$TreeTableViewArrayListSelectionModel;
        //   315: dup            
        //   316: aload_0        
        //   317: invokespecial   javafx/scene/control/TreeTableView$TreeTableViewArrayListSelectionModel.<init>:(Ljavafx/scene/control/TreeTableView;)V
        //   320: invokevirtual   javafx/scene/control/TreeTableView.setSelectionModel:(Ljavafx/scene/control/TreeTableView$TreeTableViewSelectionModel;)V
        //   323: aload_0        
        //   324: new             Ljavafx/scene/control/TreeTableView$TreeTableViewFocusModel;
        //   327: dup            
        //   328: aload_0        
        //   329: invokespecial   javafx/scene/control/TreeTableView$TreeTableViewFocusModel.<init>:(Ljavafx/scene/control/TreeTableView;)V
        //   332: invokevirtual   javafx/scene/control/TreeTableView.setFocusModel:(Ljavafx/scene/control/TreeTableView$TreeTableViewFocusModel;)V
        //   335: aload_0        
        //   336: invokevirtual   javafx/scene/control/TreeTableView.getColumns:()Ljavafx/collections/ObservableList;
        //   339: aload_0        
        //   340: getfield        javafx/scene/control/TreeTableView.weakColumnsObserver:Ljavafx/collections/WeakListChangeListener;
        //   343: invokeinterface javafx/collections/ObservableList.addListener:(Ljavafx/collections/ListChangeListener;)V
        //   348: aload_0        
        //   349: invokevirtual   javafx/scene/control/TreeTableView.getSortOrder:()Ljavafx/collections/ObservableList;
        //   352: aload_0        
        //   353: invokedynamic   BootstrapMethod #6, onChanged:(Ljavafx/scene/control/TreeTableView;)Ljavafx/collections/ListChangeListener;
        //   358: invokeinterface javafx/collections/ObservableList.addListener:(Ljavafx/collections/ListChangeListener;)V
        //   363: aload_0        
        //   364: invokevirtual   javafx/scene/control/TreeTableView.getProperties:()Ljavafx/collections/ObservableMap;
        //   367: aload_0        
        //   368: invokedynamic   BootstrapMethod #7, onChanged:(Ljavafx/scene/control/TreeTableView;)Ljavafx/collections/MapChangeListener;
        //   373: invokeinterface javafx/collections/ObservableMap.addListener:(Ljavafx/collections/MapChangeListener;)V
        //   378: aload_0        
        //   379: iconst_1       
        //   380: putfield        javafx/scene/control/TreeTableView.isInited:Z
        //   383: return         
        //    Signature:
        //  (Ljavafx/scene/control/TreeItem<TS;>;)V
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.generateNameForVariable(NameVariables.java:264)
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.assignNamesToVariables(NameVariables.java:198)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:276)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static <S> EventType<EditEvent<S>> editAnyEvent() {
        return (EventType<EditEvent<S>>)TreeTableView.EDIT_ANY_EVENT;
    }
    
    public static <S> EventType<EditEvent<S>> editStartEvent() {
        return (EventType<EditEvent<S>>)TreeTableView.EDIT_START_EVENT;
    }
    
    public static <S> EventType<EditEvent<S>> editCancelEvent() {
        return (EventType<EditEvent<S>>)TreeTableView.EDIT_CANCEL_EVENT;
    }
    
    public static <S> EventType<EditEvent<S>> editCommitEvent() {
        return (EventType<EditEvent<S>>)TreeTableView.EDIT_COMMIT_EVENT;
    }
    
    @Deprecated(since = "8u20")
    public static int getNodeLevel(final TreeItem<?> treeItem) {
        return TreeView.getNodeLevel(treeItem);
    }
    
    public final void setRoot(final TreeItem<S> treeItem) {
        this.rootProperty().set(treeItem);
    }
    
    public final TreeItem<S> getRoot() {
        return (this.root == null) ? null : this.root.get();
    }
    
    public final ObjectProperty<TreeItem<S>> rootProperty() {
        return this.root;
    }
    
    public final void setShowRoot(final boolean b) {
        this.showRootProperty().set(b);
    }
    
    public final boolean isShowRoot() {
        return this.showRoot == null || this.showRoot.get();
    }
    
    public final BooleanProperty showRootProperty() {
        if (this.showRoot == null) {
            this.showRoot = new SimpleBooleanProperty(this, "showRoot", true) {
                @Override
                protected void invalidated() {
                    TreeTableView.this.updateRootExpanded();
                    TreeTableView.this.updateExpandedItemCount(TreeTableView.this.getRoot());
                }
            };
        }
        return this.showRoot;
    }
    
    public final ObjectProperty<TreeTableColumn<S, ?>> treeColumnProperty() {
        if (this.treeColumn == null) {
            this.treeColumn = new SimpleObjectProperty<TreeTableColumn<S, ?>>(this, "treeColumn", null);
        }
        return this.treeColumn;
    }
    
    public final void setTreeColumn(final TreeTableColumn<S, ?> treeTableColumn) {
        this.treeColumnProperty().set(treeTableColumn);
    }
    
    public final TreeTableColumn<S, ?> getTreeColumn() {
        return (this.treeColumn == null) ? null : this.treeColumn.get();
    }
    
    public final void setSelectionModel(final TreeTableViewSelectionModel<S> treeTableViewSelectionModel) {
        this.selectionModelProperty().set(treeTableViewSelectionModel);
    }
    
    public final TreeTableViewSelectionModel<S> getSelectionModel() {
        return (this.selectionModel == null) ? null : this.selectionModel.get();
    }
    
    public final ObjectProperty<TreeTableViewSelectionModel<S>> selectionModelProperty() {
        if (this.selectionModel == null) {
            this.selectionModel = new SimpleObjectProperty<TreeTableViewSelectionModel<S>>(this, "selectionModel") {
                TreeTableViewSelectionModel<S> oldValue = null;
                
                @Override
                protected void invalidated() {
                    if (this.oldValue != null) {
                        this.oldValue.cellSelectionEnabledProperty().removeListener(TreeTableView.this.weakCellSelectionModelInvalidationListener);
                        if (this.oldValue instanceof TreeTableViewArrayListSelectionModel) {
                            ((TreeTableViewArrayListSelectionModel)this.oldValue).dispose();
                        }
                    }
                    this.oldValue = this.get();
                    if (this.oldValue != null) {
                        this.oldValue.cellSelectionEnabledProperty().addListener(TreeTableView.this.weakCellSelectionModelInvalidationListener);
                        TreeTableView.this.weakCellSelectionModelInvalidationListener.invalidated(this.oldValue.cellSelectionEnabledProperty());
                    }
                }
            };
        }
        return this.selectionModel;
    }
    
    public final void setFocusModel(final TreeTableViewFocusModel<S> treeTableViewFocusModel) {
        this.focusModelProperty().set(treeTableViewFocusModel);
    }
    
    public final TreeTableViewFocusModel<S> getFocusModel() {
        return (this.focusModel == null) ? null : this.focusModel.get();
    }
    
    public final ObjectProperty<TreeTableViewFocusModel<S>> focusModelProperty() {
        if (this.focusModel == null) {
            this.focusModel = new SimpleObjectProperty<TreeTableViewFocusModel<S>>(this, "focusModel");
        }
        return this.focusModel;
    }
    
    public final ReadOnlyIntegerProperty expandedItemCountProperty() {
        return this.expandedItemCount.getReadOnlyProperty();
    }
    
    private void setExpandedItemCount(final int n) {
        this.expandedItemCount.set(n);
    }
    
    public final int getExpandedItemCount() {
        if (this.expandedItemCountDirty) {
            this.updateExpandedItemCount(this.getRoot());
        }
        return this.expandedItemCount.get();
    }
    
    public final void setEditable(final boolean b) {
        this.editableProperty().set(b);
    }
    
    public final boolean isEditable() {
        return this.editable != null && this.editable.get();
    }
    
    public final BooleanProperty editableProperty() {
        if (this.editable == null) {
            this.editable = new SimpleBooleanProperty(this, "editable", false);
        }
        return this.editable;
    }
    
    private void setEditingCell(final TreeTablePosition<S, ?> treeTablePosition) {
        this.editingCellPropertyImpl().set(treeTablePosition);
    }
    
    public final TreeTablePosition<S, ?> getEditingCell() {
        return (this.editingCell == null) ? null : this.editingCell.get();
    }
    
    public final ReadOnlyObjectProperty<TreeTablePosition<S, ?>> editingCellProperty() {
        return this.editingCellPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<TreeTablePosition<S, ?>> editingCellPropertyImpl() {
        if (this.editingCell == null) {
            this.editingCell = new ReadOnlyObjectWrapper<TreeTablePosition<S, ?>>(this, "editingCell");
        }
        return this.editingCell;
    }
    
    public final BooleanProperty tableMenuButtonVisibleProperty() {
        if (this.tableMenuButtonVisible == null) {
            this.tableMenuButtonVisible = new SimpleBooleanProperty(this, "tableMenuButtonVisible");
        }
        return this.tableMenuButtonVisible;
    }
    
    public final void setTableMenuButtonVisible(final boolean b) {
        this.tableMenuButtonVisibleProperty().set(b);
    }
    
    public final boolean isTableMenuButtonVisible() {
        return this.tableMenuButtonVisible != null && this.tableMenuButtonVisible.get();
    }
    
    public final void setColumnResizePolicy(final Callback<ResizeFeatures, Boolean> callback) {
        this.columnResizePolicyProperty().set(callback);
    }
    
    public final Callback<ResizeFeatures, Boolean> getColumnResizePolicy() {
        return (this.columnResizePolicy == null) ? TreeTableView.UNCONSTRAINED_RESIZE_POLICY : this.columnResizePolicy.get();
    }
    
    public final ObjectProperty<Callback<ResizeFeatures, Boolean>> columnResizePolicyProperty() {
        if (this.columnResizePolicy == null) {
            this.columnResizePolicy = new SimpleObjectProperty<Callback<ResizeFeatures, Boolean>>(this, "columnResizePolicy", TreeTableView.UNCONSTRAINED_RESIZE_POLICY) {
                private Callback<ResizeFeatures, Boolean> oldPolicy;
                
                @Override
                protected void invalidated() {
                    if (TreeTableView.this.isInited) {
                        ((ObjectPropertyBase<Callback<ResizeFeatures, Object>>)this).get().call(new ResizeFeatures(TreeTableView.this, null, 0.0));
                        if (this.oldPolicy != null) {
                            TreeTableView.this.pseudoClassStateChanged(PseudoClass.getPseudoClass(this.oldPolicy.toString()), false);
                        }
                        if (this.get() != null) {
                            TreeTableView.this.pseudoClassStateChanged(PseudoClass.getPseudoClass(((ObjectPropertyBase<Callback<?, ?>>)this).get().toString()), true);
                        }
                        this.oldPolicy = this.get();
                    }
                }
            };
        }
        return this.columnResizePolicy;
    }
    
    public final ObjectProperty<Callback<TreeTableView<S>, TreeTableRow<S>>> rowFactoryProperty() {
        if (this.rowFactory == null) {
            this.rowFactory = new SimpleObjectProperty<Callback<TreeTableView<S>, TreeTableRow<S>>>(this, "rowFactory");
        }
        return this.rowFactory;
    }
    
    public final void setRowFactory(final Callback<TreeTableView<S>, TreeTableRow<S>> callback) {
        this.rowFactoryProperty().set(callback);
    }
    
    public final Callback<TreeTableView<S>, TreeTableRow<S>> getRowFactory() {
        return (this.rowFactory == null) ? null : this.rowFactory.get();
    }
    
    public final ObjectProperty<Node> placeholderProperty() {
        if (this.placeholder == null) {
            this.placeholder = new SimpleObjectProperty<Node>(this, "placeholder");
        }
        return this.placeholder;
    }
    
    public final void setPlaceholder(final Node node) {
        this.placeholderProperty().set(node);
    }
    
    public final Node getPlaceholder() {
        return (this.placeholder == null) ? null : this.placeholder.get();
    }
    
    public final void setFixedCellSize(final double n) {
        this.fixedCellSizeProperty().set(n);
    }
    
    public final double getFixedCellSize() {
        return (this.fixedCellSize == null) ? -1.0 : this.fixedCellSize.get();
    }
    
    public final DoubleProperty fixedCellSizeProperty() {
        if (this.fixedCellSize == null) {
            this.fixedCellSize = new StyleableDoubleProperty(-1.0) {
                @Override
                public CssMetaData<TreeTableView<?>, Number> getCssMetaData() {
                    return StyleableProperties.FIXED_CELL_SIZE;
                }
                
                @Override
                public Object getBean() {
                    return TreeTableView.this;
                }
                
                @Override
                public String getName() {
                    return "fixedCellSize";
                }
            };
        }
        return this.fixedCellSize;
    }
    
    public final ObjectProperty<TreeSortMode> sortModeProperty() {
        if (this.sortMode == null) {
            this.sortMode = new SimpleObjectProperty<TreeSortMode>(this, "sortMode", TreeSortMode.ALL_DESCENDANTS);
        }
        return this.sortMode;
    }
    
    public final void setSortMode(final TreeSortMode treeSortMode) {
        this.sortModeProperty().set(treeSortMode);
    }
    
    public final TreeSortMode getSortMode() {
        return (this.sortMode == null) ? TreeSortMode.ALL_DESCENDANTS : this.sortMode.get();
    }
    
    private void setComparator(final Comparator<TreeItem<S>> comparator) {
        this.comparatorPropertyImpl().set(comparator);
    }
    
    public final Comparator<TreeItem<S>> getComparator() {
        return (this.comparator == null) ? null : this.comparator.get();
    }
    
    public final ReadOnlyObjectProperty<Comparator<TreeItem<S>>> comparatorProperty() {
        return this.comparatorPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<Comparator<TreeItem<S>>> comparatorPropertyImpl() {
        if (this.comparator == null) {
            this.comparator = new ReadOnlyObjectWrapper<Comparator<TreeItem<S>>>(this, "comparator");
        }
        return this.comparator;
    }
    
    public final void setSortPolicy(final Callback<TreeTableView<S>, Boolean> callback) {
        this.sortPolicyProperty().set(callback);
    }
    
    public final Callback<TreeTableView<S>, Boolean> getSortPolicy() {
        return (this.sortPolicy == null) ? ((Callback<TreeTableView, Boolean>)TreeTableView.DEFAULT_SORT_POLICY) : this.sortPolicy.get();
    }
    
    public final ObjectProperty<Callback<TreeTableView<S>, Boolean>> sortPolicyProperty() {
        if (this.sortPolicy == null) {
            this.sortPolicy = new SimpleObjectProperty<Callback<TreeTableView<S>, Boolean>>(this, "sortPolicy", (Callback<TreeTableView, Boolean>)TreeTableView.DEFAULT_SORT_POLICY) {
                @Override
                protected void invalidated() {
                    TreeTableView.this.sort();
                }
            };
        }
        return this.sortPolicy;
    }
    
    public void setOnSort(final EventHandler<SortEvent<TreeTableView<S>>> eventHandler) {
        this.onSortProperty().set(eventHandler);
    }
    
    public EventHandler<SortEvent<TreeTableView<S>>> getOnSort() {
        if (this.onSort != null) {
            return this.onSort.get();
        }
        return null;
    }
    
    public ObjectProperty<EventHandler<SortEvent<TreeTableView<S>>>> onSortProperty() {
        if (this.onSort == null) {
            this.onSort = new ObjectPropertyBase<EventHandler<SortEvent<TreeTableView<S>>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(SortEvent.sortEvent(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return TreeTableView.this;
                }
                
                @Override
                public String getName() {
                    return "onSort";
                }
            };
        }
        return this.onSort;
    }
    
    @Override
    protected void layoutChildren() {
        if (this.expandedItemCountDirty) {
            this.updateExpandedItemCount(this.getRoot());
        }
        super.layoutChildren();
    }
    
    public void scrollTo(final int n) {
        ControlUtils.scrollToIndex(this, n);
    }
    
    public void setOnScrollTo(final EventHandler<ScrollToEvent<Integer>> eventHandler) {
        this.onScrollToProperty().set(eventHandler);
    }
    
    public EventHandler<ScrollToEvent<Integer>> getOnScrollTo() {
        if (this.onScrollTo != null) {
            return this.onScrollTo.get();
        }
        return null;
    }
    
    public ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollToProperty() {
        if (this.onScrollTo == null) {
            this.onScrollTo = new ObjectPropertyBase<EventHandler<ScrollToEvent<Integer>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(ScrollToEvent.scrollToTopIndex(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return TreeTableView.this;
                }
                
                @Override
                public String getName() {
                    return "onScrollTo";
                }
            };
        }
        return this.onScrollTo;
    }
    
    public void scrollToColumn(final TreeTableColumn<S, ?> treeTableColumn) {
        ControlUtils.scrollToColumn(this, treeTableColumn);
    }
    
    public void scrollToColumnIndex(final int n) {
        if (this.getColumns() != null) {
            ControlUtils.scrollToColumn(this, this.getColumns().get(n));
        }
    }
    
    public void setOnScrollToColumn(final EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>> eventHandler) {
        this.onScrollToColumnProperty().set(eventHandler);
    }
    
    public EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>> getOnScrollToColumn() {
        if (this.onScrollToColumn != null) {
            return this.onScrollToColumn.get();
        }
        return null;
    }
    
    public ObjectProperty<EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>>> onScrollToColumnProperty() {
        if (this.onScrollToColumn == null) {
            this.onScrollToColumn = new ObjectPropertyBase<EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(ScrollToEvent.scrollToColumn(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return TreeTableView.this;
                }
                
                @Override
                public String getName() {
                    return "onScrollToColumn";
                }
            };
        }
        return this.onScrollToColumn;
    }
    
    public int getRow(final TreeItem<S> treeItem) {
        return TreeUtil.getRow(treeItem, this.getRoot(), this.expandedItemCountDirty, this.isShowRoot());
    }
    
    public TreeItem<S> getTreeItem(final int n) {
        if (n < 0) {
            return null;
        }
        final int i = this.isShowRoot() ? n : (n + 1);
        if (this.expandedItemCountDirty) {
            this.updateExpandedItemCount(this.getRoot());
        }
        else if (this.treeItemCacheMap.containsKey(i)) {
            final TreeItem<S> treeItem = this.treeItemCacheMap.get(i).get();
            if (treeItem != null) {
                return treeItem;
            }
        }
        final TreeItem<S> item = TreeUtil.getItem(this.getRoot(), i, this.expandedItemCountDirty);
        this.treeItemCacheMap.put(i, new SoftReference<TreeItem<S>>(item));
        return item;
    }
    
    public int getTreeItemLevel(final TreeItem<?> treeItem) {
        final TreeItem<?> root = this.getRoot();
        if (treeItem == null) {
            return -1;
        }
        if (treeItem == root) {
            return 0;
        }
        int n = 0;
        for (TreeItem<?> treeItem2 = treeItem.getParent(); treeItem2 != null; treeItem2 = treeItem2.getParent()) {
            ++n;
            if (treeItem2 == root) {
                break;
            }
        }
        return n;
    }
    
    public final ObservableList<TreeTableColumn<S, ?>> getColumns() {
        return this.columns;
    }
    
    public final ObservableList<TreeTableColumn<S, ?>> getSortOrder() {
        return this.sortOrder;
    }
    
    public boolean resizeColumn(final TreeTableColumn<S, ?> treeTableColumn, final double n) {
        return treeTableColumn != null && Double.compare(n, 0.0) != 0 && this.getColumnResizePolicy().call(new ResizeFeatures(this, treeTableColumn, n));
    }
    
    public void edit(final int n, final TreeTableColumn<S, ?> treeTableColumn) {
        if (!this.isEditable() || (treeTableColumn != null && !treeTableColumn.isEditable())) {
            return;
        }
        if (n < 0 && treeTableColumn == null) {
            this.setEditingCell(null);
        }
        else {
            this.setEditingCell(new TreeTablePosition<S, Object>(this, n, treeTableColumn));
        }
    }
    
    public ObservableList<TreeTableColumn<S, ?>> getVisibleLeafColumns() {
        return this.unmodifiableVisibleLeafColumns;
    }
    
    public int getVisibleLeafIndex(final TreeTableColumn<S, ?> treeTableColumn) {
        return this.getVisibleLeafColumns().indexOf(treeTableColumn);
    }
    
    public TreeTableColumn<S, ?> getVisibleLeafColumn(final int n) {
        if (n < 0 || n >= this.visibleLeafColumns.size()) {
            return null;
        }
        return this.visibleLeafColumns.get(n);
    }
    
    public void sort() {
        final ObservableList<TreeTableColumn<Object, ?>> sortOrder = this.getSortOrder();
        final Comparator<TreeItem<S>> comparator = this.getComparator();
        this.setComparator(sortOrder.isEmpty() ? null : new TableColumnComparatorBase.TreeTableColumnComparator<TreeItem<S>, Object>((List<TreeTableColumn<Object, Object>>)sortOrder));
        final SortEvent sortEvent = new SortEvent((C)this, this);
        this.fireEvent(sortEvent);
        if (sortEvent.isConsumed()) {
            return;
        }
        final ArrayList<Object> list = new ArrayList<Object>(this.getSelectionModel().getSelectedCells());
        final int size = list.size();
        this.getSelectionModel().startAtomic();
        final Callback<TreeTableView<S>, Boolean> sortPolicy = this.getSortPolicy();
        if (sortPolicy == null) {
            return;
        }
        final Boolean b = sortPolicy.call(this);
        this.getSelectionModel().stopAtomic();
        if (b == null || !b) {
            this.sortLock = true;
            TableUtil.handleSortFailure(sortOrder, this.lastSortEventType, this.lastSortEventSupportInfo);
            this.setComparator(comparator);
            this.sortLock = false;
        }
        else if (this.getSelectionModel() instanceof TreeTableViewArrayListSelectionModel) {
            final TreeTableViewArrayListSelectionModel treeTableViewArrayListSelectionModel = (TreeTableViewArrayListSelectionModel)this.getSelectionModel();
            final ObservableList<TreeTablePosition<Object, ?>> selectedCells = treeTableViewArrayListSelectionModel.getSelectedCells();
            final ArrayList<TreeTablePosition> list2 = new ArrayList<TreeTablePosition>();
            for (int i = 0; i < size; ++i) {
                final TreeTablePosition treeTablePosition = list.get(i);
                if (!selectedCells.contains(treeTablePosition)) {
                    list2.add(treeTablePosition);
                }
            }
            if (!list2.isEmpty()) {
                treeTableViewArrayListSelectionModel.fireCustomSelectedCellsListChangeEvent(new NonIterableChange.GenericAddRemoveChange(0, size, (List<Object>)list2, (ObservableList<Object>)selectedCells));
            }
        }
    }
    
    public void refresh() {
        this.getProperties().put("recreateKey", Boolean.TRUE);
    }
    
    private void doSort(final TableUtil.SortEventType lastSortEventType, final Object... lastSortEventSupportInfo) {
        if (this.sortLock) {
            return;
        }
        this.lastSortEventType = lastSortEventType;
        this.lastSortEventSupportInfo = lastSortEventSupportInfo;
        this.sort();
        this.lastSortEventType = null;
        this.lastSortEventSupportInfo = null;
    }
    
    private void updateExpandedItemCount(final TreeItem<S> treeItem) {
        this.setExpandedItemCount(TreeUtil.updateExpandedItemCount(treeItem, this.expandedItemCountDirty, this.isShowRoot()));
        if (this.expandedItemCountDirty) {
            this.treeItemCacheMap.clear();
        }
        this.expandedItemCountDirty = false;
    }
    
    private void updateRootExpanded() {
        if (!this.isShowRoot() && this.getRoot() != null && !this.getRoot().isExpanded()) {
            this.getRoot().setExpanded(true);
        }
    }
    
    private void setContentWidth(final double contentWidth) {
        this.contentWidth = contentWidth;
        if (this.isInited) {
            this.getColumnResizePolicy().call(new ResizeFeatures(this, null, 0.0));
        }
    }
    
    private void updateVisibleLeafColumns() {
        final ArrayList<TreeTableColumn<S, ?>> all = new ArrayList<TreeTableColumn<S, ?>>();
        this.buildVisibleLeafColumns(this.getColumns(), all);
        this.visibleLeafColumns.setAll(all);
        this.getColumnResizePolicy().call(new ResizeFeatures(this, null, 0.0));
    }
    
    private void buildVisibleLeafColumns(final List<TreeTableColumn<S, ?>> list, final List<TreeTableColumn<S, ?>> list2) {
        for (final TreeTableColumn<S, ?> treeTableColumn : list) {
            if (treeTableColumn == null) {
                continue;
            }
            if (!treeTableColumn.getColumns().isEmpty()) {
                this.buildVisibleLeafColumns((List<TreeTableColumn<S, ?>>)treeTableColumn.getColumns(), (List<TreeTableColumn<S, ?>>)list2);
            }
            else {
                if (!treeTableColumn.isVisible()) {
                    continue;
                }
                list2.add(treeTableColumn);
            }
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TreeTableViewSkin<Object>(this);
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case ROW_COUNT: {
                return this.getExpandedItemCount();
            }
            case COLUMN_COUNT: {
                return this.getVisibleLeafColumns().size();
            }
            case SELECTED_ITEMS: {
                final ObservableList list = (ObservableList)super.queryAccessibleAttribute(accessibleAttribute, array);
                final ArrayList<Object> list2 = new ArrayList<Object>();
                final Iterator<TreeTableRow> iterator = list.iterator();
                while (iterator.hasNext()) {
                    final ObservableList list3 = (ObservableList)iterator.next().queryAccessibleAttribute(accessibleAttribute, array);
                    if (list3 != null) {
                        list2.addAll(list3);
                    }
                }
                return FXCollections.observableArrayList((Collection<?>)list2);
            }
            case FOCUS_ITEM: {
                final Node node = (Node)super.queryAccessibleAttribute(accessibleAttribute, array);
                if (node == null) {
                    return null;
                }
                final Node node2 = (Node)node.queryAccessibleAttribute(accessibleAttribute, array);
                return (node2 != null) ? node2 : node;
            }
            case CELL_AT_ROW_COLUMN: {
                final TreeTableRow treeTableRow = (TreeTableRow)super.queryAccessibleAttribute(accessibleAttribute, array);
                return (treeTableRow != null) ? treeTableRow.queryAccessibleAttribute(accessibleAttribute, array) : null;
            }
            case MULTIPLE_SELECTION: {
                final TreeTableViewSelectionModel<S> selectionModel = this.getSelectionModel();
                return selectionModel != null && selectionModel.getSelectionMode() == SelectionMode.MULTIPLE;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        EDIT_ANY_EVENT = new EventType<Object>(Event.ANY, "TREE_TABLE_VIEW_EDIT");
        EDIT_START_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_START");
        EDIT_CANCEL_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_CANCEL");
        EDIT_COMMIT_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_COMMIT");
        UNCONSTRAINED_RESIZE_POLICY = new Callback<ResizeFeatures, Boolean>() {
            @Override
            public String toString() {
                return "unconstrained-resize";
            }
            
            @Override
            public Boolean call(final ResizeFeatures resizeFeatures) {
                return Double.compare(TableUtil.resize(resizeFeatures.getColumn(), resizeFeatures.getDelta()), 0.0) == 0;
            }
        };
        CONSTRAINED_RESIZE_POLICY = new Callback<ResizeFeatures, Boolean>() {
            private boolean isFirstRun = true;
            
            @Override
            public String toString() {
                return "constrained-resize";
            }
            
            @Override
            public Boolean call(final ResizeFeatures resizeFeatures) {
                final TreeTableView table = resizeFeatures.getTable();
                final Boolean value = TableUtil.constrainedResize(resizeFeatures, this.isFirstRun, table.contentWidth, table.getVisibleLeafColumns());
                this.isFirstRun = (this.isFirstRun && !value);
                return value;
            }
        };
        DEFAULT_SORT_POLICY = new Callback<TreeTableView, Boolean>() {
            @Override
            public Boolean call(final TreeTableView treeTableView) {
                try {
                    final TreeItem<T> root = treeTableView.getRoot();
                    if (root == null) {
                        return false;
                    }
                    final TreeSortMode sortMode = treeTableView.getSortMode();
                    if (sortMode == null) {
                        return false;
                    }
                    root.lastSortMode = sortMode;
                    root.lastComparator = treeTableView.getComparator();
                    root.sort();
                    return true;
                }
                catch (UnsupportedOperationException ex) {
                    return false;
                }
            }
        };
        PSEUDO_CLASS_CELL_SELECTION = PseudoClass.getPseudoClass("cell-selection");
        PSEUDO_CLASS_ROW_SELECTION = PseudoClass.getPseudoClass("row-selection");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TreeTableView<?>, Number> FIXED_CELL_SIZE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            FIXED_CELL_SIZE = new CssMetaData<TreeTableView<?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)(-1.0)) {
                @Override
                public Double getInitialValue(final TreeTableView<?> treeTableView) {
                    return treeTableView.getFixedCellSize();
                }
                
                @Override
                public boolean isSettable(final TreeTableView<?> treeTableView) {
                    return ((TreeTableView<Object>)treeTableView).fixedCellSize == null || !((TreeTableView<Object>)treeTableView).fixedCellSize.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TreeTableView<?> treeTableView) {
                    return (StyleableProperty<Number>)treeTableView.fixedCellSizeProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.FIXED_CELL_SIZE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    public static class ResizeFeatures<S> extends ResizeFeaturesBase<TreeItem<S>>
    {
        private TreeTableView<S> treeTable;
        
        public ResizeFeatures(final TreeTableView<S> treeTable, final TreeTableColumn<S, ?> treeTableColumn, final Double n) {
            super(treeTableColumn, n);
            this.treeTable = treeTable;
        }
        
        @Override
        public TreeTableColumn<S, ?> getColumn() {
            return (TreeTableColumn<S, ?>)(TreeTableColumn)super.getColumn();
        }
        
        public TreeTableView<S> getTable() {
            return this.treeTable;
        }
    }
    
    public static class EditEvent<S> extends Event
    {
        private static final long serialVersionUID = -4437033058917528976L;
        public static final EventType<?> ANY;
        private final TreeTableView<S> source;
        private final S oldValue;
        private final S newValue;
        private final transient TreeItem<S> treeItem;
        
        public EditEvent(final TreeTableView<S> source, final EventType<? extends EditEvent> eventType, final TreeItem<S> treeItem, final S oldValue, final S newValue) {
            super(source, Event.NULL_SOURCE_TARGET, eventType);
            this.source = source;
            this.oldValue = oldValue;
            this.newValue = newValue;
            this.treeItem = treeItem;
        }
        
        @Override
        public TreeTableView<S> getSource() {
            return this.source;
        }
        
        public TreeItem<S> getTreeItem() {
            return this.treeItem;
        }
        
        public S getNewValue() {
            return this.newValue;
        }
        
        public S getOldValue() {
            return this.oldValue;
        }
        
        static {
            ANY = TreeTableView.EDIT_ANY_EVENT;
        }
    }
    
    public abstract static class TreeTableViewSelectionModel<S> extends TableSelectionModel<TreeItem<S>>
    {
        private final TreeTableView<S> treeTableView;
        
        public TreeTableViewSelectionModel(final TreeTableView<S> treeTableView) {
            if (treeTableView == null) {
                throw new NullPointerException("TreeTableView can not be null");
            }
            this.treeTableView = treeTableView;
        }
        
        public abstract ObservableList<TreeTablePosition<S, ?>> getSelectedCells();
        
        public TreeTableView<S> getTreeTableView() {
            return this.treeTableView;
        }
        
        public TreeItem<S> getModelItem(final int n) {
            return this.treeTableView.getTreeItem(n);
        }
        
        @Override
        protected int getItemCount() {
            return this.treeTableView.getExpandedItemCount();
        }
        
        public void focus(final int n) {
            this.focus(n, null);
        }
        
        public int getFocusedIndex() {
            return this.getFocusedCell().getRow();
        }
        
        @Override
        public void selectRange(final int n, final TableColumnBase<TreeItem<S>, ?> tableColumnBase, final int n2, final TableColumnBase<TreeItem<S>, ?> tableColumnBase2) {
            final int visibleLeafIndex = this.treeTableView.getVisibleLeafIndex((TreeTableColumn<S, ?>)tableColumnBase);
            final int visibleLeafIndex2 = this.treeTableView.getVisibleLeafIndex((TreeTableColumn<S, ?>)tableColumnBase2);
            for (int i = n; i <= n2; ++i) {
                for (int j = visibleLeafIndex; j <= visibleLeafIndex2; ++j) {
                    this.select(i, (TableColumnBase<TreeItem<S>, ?>)this.treeTableView.getVisibleLeafColumn(j));
                }
            }
        }
        
        private void focus(final int n, final TreeTableColumn<S, ?> treeTableColumn) {
            this.focus(new TreeTablePosition<S, Object>(this.getTreeTableView(), n, treeTableColumn));
        }
        
        private void focus(final TreeTablePosition<S, ?> treeTablePosition) {
            if (this.getTreeTableView().getFocusModel() == null) {
                return;
            }
            this.getTreeTableView().getFocusModel().focus(treeTablePosition.getRow(), treeTablePosition.getTableColumn());
        }
        
        private TreeTablePosition<S, ?> getFocusedCell() {
            if (this.treeTableView.getFocusModel() == null) {
                return new TreeTablePosition<S, Object>(this.treeTableView, -1, null);
            }
            return this.treeTableView.getFocusModel().getFocusedCell();
        }
    }
    
    static class TreeTableViewArrayListSelectionModel<S> extends TreeTableViewSelectionModel<S>
    {
        private final MappingChange.Map<TreeTablePosition<S, ?>, Integer> cellToIndicesMap;
        private TreeTableView<S> treeTableView;
        private ChangeListener<TreeItem<S>> rootPropertyListener;
        private InvalidationListener showRootPropertyListener;
        private EventHandler<TreeItem.TreeModificationEvent<S>> treeItemListener;
        private WeakChangeListener<TreeItem<S>> weakRootPropertyListener;
        private WeakEventHandler<TreeItem.TreeModificationEvent<S>> weakTreeItemListener;
        private final SelectedCellsMap<TreeTablePosition<S, ?>> selectedCellsMap;
        private final ReadOnlyUnbackedObservableList<TreeTablePosition<S, ?>> selectedCellsSeq;
        
        public TreeTableViewArrayListSelectionModel(final TreeTableView<S> treeTableView) {
            super(treeTableView);
            this.cellToIndicesMap = (MappingChange.Map<TreeTablePosition<S, ?>, Integer>)(treeTablePosition -> treeTablePosition.getRow());
            this.treeTableView = null;
            this.rootPropertyListener = ((p0, treeItem, treeItem2) -> {
                this.updateDefaultSelection();
                this.updateTreeEventListener(treeItem, treeItem2);
                return;
            });
            this.showRootPropertyListener = (p0 -> this.shiftSelection(0, this.treeTableView.isShowRoot() ? 1 : -1, null));
            this.treeItemListener = new EventHandler<TreeItem.TreeModificationEvent<S>>() {
                @Override
                public void handle(final TreeItem.TreeModificationEvent<S> treeModificationEvent) {
                    if (TreeTableViewArrayListSelectionModel.this.getSelectedIndex() == -1 && TreeTableViewArrayListSelectionModel.this.getSelectedItem() == null) {
                        return;
                    }
                    final TreeItem<S> treeItem = treeModificationEvent.getTreeItem();
                    if (treeItem == null) {
                        return;
                    }
                    final int selectedIndex = TreeTableViewArrayListSelectionModel.this.getSelectedIndex();
                    TreeTableViewArrayListSelectionModel.this.treeTableView.expandedItemCountDirty = true;
                    int n = TreeTableViewArrayListSelectionModel.this.treeTableView.getRow(treeItem);
                    int n2 = 0;
                    final ListChangeListener.Change<? extends TreeItem<S>> change = treeModificationEvent.getChange();
                    if (change != null) {
                        change.next();
                    }
                    do {
                        final int n3 = (change == null) ? 0 : change.getAddedSize();
                        final int n4 = (change == null) ? 0 : change.getRemovedSize();
                        if (treeModificationEvent.wasExpanded()) {
                            n2 += treeItem.getExpandedDescendentCount(false) - 1;
                            ++n;
                        }
                        else if (treeModificationEvent.wasCollapsed()) {
                            treeItem.getExpandedDescendentCount(false);
                            final int previousExpandedDescendentCount = treeItem.previousExpandedDescendentCount;
                            final int selectedIndex2 = TreeTableViewArrayListSelectionModel.this.getSelectedIndex();
                            final boolean b = selectedIndex2 >= n + 1 && selectedIndex2 < n + previousExpandedDescendentCount;
                            boolean b2 = false;
                            final boolean cellSelectionEnabled = TreeTableViewArrayListSelectionModel.this.isCellSelectionEnabled();
                            final ObservableList<TreeTableColumn<Object, ?>> visibleLeafColumns = TreeTableViewArrayListSelectionModel.this.getTreeTableView().getVisibleLeafColumns();
                            TreeTableViewArrayListSelectionModel.this.selectedIndices._beginChange();
                            final int n5 = n + 1;
                            final int n6 = n + previousExpandedDescendentCount;
                            final ArrayList<Integer> list = new ArrayList<Integer>();
                            TableColumnBase<TreeItem<S>, ?> tableColumnBase = null;
                            for (int i = n5; i < n6; ++i) {
                                if (cellSelectionEnabled) {
                                    for (int j = 0; j < visibleLeafColumns.size(); ++j) {
                                        final TreeTableColumn treeTableColumn = visibleLeafColumns.get(j);
                                        if (TreeTableViewArrayListSelectionModel.this.isSelected(i, treeTableColumn)) {
                                            b2 = true;
                                            TreeTableViewArrayListSelectionModel.this.clearSelection(i, treeTableColumn);
                                            tableColumnBase = (TableColumnBase<TreeItem<S>, ?>)treeTableColumn;
                                        }
                                    }
                                }
                                else if (TreeTableViewArrayListSelectionModel.this.isSelected(i)) {
                                    b2 = true;
                                    list.add(i);
                                }
                            }
                            ControlUtils.reducingChange(TreeTableViewArrayListSelectionModel.this.selectedIndices, list);
                            for (final int intValue : list) {
                                TreeTableViewArrayListSelectionModel.this.startAtomic();
                                TreeTableViewArrayListSelectionModel.this.clearSelection(new TreeTablePosition(TreeTableViewArrayListSelectionModel.this.treeTableView, intValue, null, false));
                                TreeTableViewArrayListSelectionModel.this.stopAtomic();
                            }
                            TreeTableViewArrayListSelectionModel.this.selectedIndices._endChange();
                            if (b && b2) {
                                TreeTableViewArrayListSelectionModel.this.select(n, tableColumnBase);
                            }
                            n2 += -previousExpandedDescendentCount + 1;
                            ++n;
                        }
                        else if (treeModificationEvent.wasPermutated()) {
                            TreeTableViewArrayListSelectionModel.this.startAtomic();
                            final int n7 = n + 1;
                            final HashMap<Integer, Integer> hashMap = new HashMap<Integer, Integer>(treeModificationEvent.getTo() - treeModificationEvent.getFrom());
                            for (int k = treeModificationEvent.getFrom(); k < treeModificationEvent.getTo(); ++k) {
                                hashMap.put(k, treeModificationEvent.getChange().getPermutation(k));
                            }
                            final ArrayList<TreeTablePosition<Object, T>> list2 = new ArrayList<TreeTablePosition<Object, T>>((Collection<? extends TreeTablePosition<Object, T>>)TreeTableViewArrayListSelectionModel.this.getSelectedCells());
                            final ArrayList all = new ArrayList<TreeTablePosition>(list2.size());
                            boolean b3 = false;
                            for (int l = 0; l < list2.size(); ++l) {
                                final TreeTablePosition<Object, T> treeTablePosition = list2.get(l);
                                final int n8 = treeTablePosition.getRow() - n7;
                                if (hashMap.containsKey(n8)) {
                                    final int n9 = hashMap.get(n8) + n7;
                                    b3 = (b3 || n9 != n8);
                                    all.add((TreeTablePosition)new TreeTablePosition(treeTablePosition.getTreeTableView(), n9, (TreeTableColumn<Object, Object>)treeTablePosition.getTableColumn()));
                                }
                                if (treeTablePosition.getRow() == n) {
                                    all.add((TreeTablePosition)new TreeTablePosition(treeTablePosition.getTreeTableView(), treeTablePosition.getRow(), (TreeTableColumn<Object, Object>)treeTablePosition.getTableColumn()));
                                }
                            }
                            if (b3) {
                                TreeTableViewArrayListSelectionModel.this.quietClearSelection();
                                TreeTableViewArrayListSelectionModel.this.stopAtomic();
                                TreeTableViewArrayListSelectionModel.this.selectedCellsMap.setAll(all);
                                final int n10 = selectedIndex - n7;
                                if (n10 < 0 || n10 >= TreeTableViewArrayListSelectionModel.this.getItemCount()) {
                                    continue;
                                }
                                final int permutation = treeModificationEvent.getChange().getPermutation(n10);
                                TreeTableViewArrayListSelectionModel.this.setSelectedIndex(permutation + n7);
                                TreeTableViewArrayListSelectionModel.this.focus(permutation + n7);
                            }
                            else {
                                TreeTableViewArrayListSelectionModel.this.stopAtomic();
                            }
                        }
                        else if (treeModificationEvent.wasAdded()) {
                            n2 += (treeItem.isExpanded() ? n3 : false);
                            n = TreeTableViewArrayListSelectionModel.this.treeTableView.getRow((TreeItem<Object>)treeModificationEvent.getChange().getAddedSubList().get(0));
                            final TreeTablePosition<Object, Object> treeTablePosition2 = CellBehaviorBase.getAnchor(TreeTableViewArrayListSelectionModel.this.treeTableView, (TreeTablePosition<Object, Object>)null);
                            if (treeTablePosition2 == null || !TreeTableViewArrayListSelectionModel.this.isSelected(treeTablePosition2.getRow(), treeTablePosition2.getTableColumn())) {
                                continue;
                            }
                            CellBehaviorBase.setAnchor(TreeTableViewArrayListSelectionModel.this.treeTableView, new TreeTablePosition(TreeTableViewArrayListSelectionModel.this.treeTableView, treeTablePosition2.getRow() + n2, treeTablePosition2.getTableColumn()), false);
                        }
                        else {
                            if (!treeModificationEvent.wasRemoved()) {
                                continue;
                            }
                            n2 += (treeItem.isExpanded() ? (-n4) : false);
                            n += treeModificationEvent.getFrom() + 1;
                            final ObservableList selectedIndices = TreeTableViewArrayListSelectionModel.this.getSelectedIndices();
                            final ObservableList selectedItems = TreeTableViewArrayListSelectionModel.this.getSelectedItems();
                            final TreeItem treeItem2 = TreeTableViewArrayListSelectionModel.this.getSelectedItem();
                            final List<? extends TreeItem<S>> removed = treeModificationEvent.getChange().getRemoved();
                            for (int n11 = 0; n11 < selectedIndices.size() && !selectedItems.isEmpty(); ++n11) {
                                if ((int)selectedIndices.get(n11) > selectedItems.size()) {
                                    break;
                                }
                                if (removed.size() == 1 && selectedItems.size() == 1 && treeItem2 != null && treeItem2.equals(removed.get(0)) && selectedIndex < TreeTableViewArrayListSelectionModel.this.getItemCount()) {
                                    final int n12 = (selectedIndex == 0) ? 0 : (selectedIndex - 1);
                                    if (!treeItem2.equals(TreeTableViewArrayListSelectionModel.this.getModelItem(n12))) {
                                        TreeTableViewArrayListSelectionModel.this.clearAndSelect(n12);
                                    }
                                }
                            }
                        }
                    } while (treeModificationEvent.getChange() != null && treeModificationEvent.getChange().next());
                    TreeTableViewArrayListSelectionModel.this.shiftSelection(n, n2, new Callback<ShiftParams, Void>() {
                        @Override
                        public Void call(final ShiftParams shiftParams) {
                            TreeTableViewArrayListSelectionModel.this.startAtomic();
                            final int clearIndex = shiftParams.getClearIndex();
                            final int setIndex = shiftParams.getSetIndex();
                            TreeTablePosition treeTablePosition = null;
                            if (clearIndex > -1) {
                                for (int i = 0; i < TreeTableViewArrayListSelectionModel.this.selectedCellsMap.size(); ++i) {
                                    final TreeTablePosition<Object, Object> treeTablePosition2 = TreeTableViewArrayListSelectionModel.this.selectedCellsMap.get(i);
                                    if (treeTablePosition2.getRow() == clearIndex) {
                                        treeTablePosition = treeTablePosition2;
                                        TreeTableViewArrayListSelectionModel.this.selectedCellsMap.remove(treeTablePosition2);
                                    }
                                    else if (treeTablePosition2.getRow() == setIndex && !shiftParams.isSelected()) {
                                        TreeTableViewArrayListSelectionModel.this.selectedCellsMap.remove(treeTablePosition2);
                                    }
                                }
                            }
                            if (treeTablePosition != null && shiftParams.isSelected()) {
                                TreeTableViewArrayListSelectionModel.this.selectedCellsMap.add(new TreeTablePosition(TreeTableViewArrayListSelectionModel.this.treeTableView, shiftParams.getSetIndex(), treeTablePosition.getTableColumn()));
                            }
                            TreeTableViewArrayListSelectionModel.this.stopAtomic();
                            return null;
                        }
                    });
                }
            };
            this.weakRootPropertyListener = new WeakChangeListener<TreeItem<S>>(this.rootPropertyListener);
            this.treeTableView = treeTableView;
            this.treeTableView.rootProperty().addListener(this.weakRootPropertyListener);
            this.treeTableView.showRootProperty().addListener(this.showRootPropertyListener);
            this.updateTreeEventListener(null, treeTableView.getRoot());
            this.selectedCellsMap = new SelectedCellsMap<TreeTablePosition<S, ?>>(this::fireCustomSelectedCellsListChangeEvent) {
                @Override
                public boolean isCellSelectionEnabled() {
                    return TreeTableViewArrayListSelectionModel.this.isCellSelectionEnabled();
                }
            };
            this.selectedCellsSeq = new ReadOnlyUnbackedObservableList<TreeTablePosition<S, ?>>() {
                @Override
                public TreeTablePosition<S, ?> get(final int n) {
                    return TreeTableViewArrayListSelectionModel.this.selectedCellsMap.get(n);
                }
                
                @Override
                public int size() {
                    return TreeTableViewArrayListSelectionModel.this.selectedCellsMap.size();
                }
            };
            this.updateDefaultSelection();
            this.cellSelectionEnabledProperty().addListener(p1 -> {
                this.updateDefaultSelection();
                CellBehaviorBase.setAnchor(treeTableView, this.getFocusedCell(), true);
            });
        }
        
        private void dispose() {
            this.treeTableView.rootProperty().removeListener(this.weakRootPropertyListener);
            this.treeTableView.showRootProperty().removeListener(this.showRootPropertyListener);
            final TreeItem<S> root = this.treeTableView.getRoot();
            if (root != null) {
                root.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakTreeItemListener);
            }
        }
        
        private void updateTreeEventListener(final TreeItem<S> treeItem, final TreeItem<S> treeItem2) {
            if (treeItem != null && this.weakTreeItemListener != null) {
                treeItem.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakTreeItemListener);
            }
            if (treeItem2 != null) {
                this.weakTreeItemListener = new WeakEventHandler<TreeItem.TreeModificationEvent<S>>(this.treeItemListener);
                treeItem2.addEventHandler(TreeItem.expandedItemCountChangeEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakTreeItemListener);
            }
        }
        
        @Override
        public ObservableList<TreeTablePosition<S, ?>> getSelectedCells() {
            return this.selectedCellsSeq;
        }
        
        @Override
        public void clearAndSelect(final int n) {
            this.clearAndSelect(n, null);
        }
        
        @Override
        public void clearAndSelect(final int n, final TableColumnBase<TreeItem<S>, ?> tableColumnBase) {
            if (n < 0 || n >= this.getItemCount()) {
                return;
            }
            final TreeTablePosition<S, Object> treeTablePosition = new TreeTablePosition<S, Object>(this.getTreeTableView(), n, (TreeTableColumn<S, Object>)tableColumnBase);
            final boolean cellSelectionEnabled = this.isCellSelectionEnabled();
            CellBehaviorBase.setAnchor(this.treeTableView, treeTablePosition, false);
            final ArrayList<TreeTablePosition<S, ?>> list = new ArrayList<TreeTablePosition<S, ?>>(this.selectedCellsMap.getSelectedCells());
            final boolean selected = this.isSelected(n, tableColumnBase);
            if (selected && list.size() == 1) {
                final TreeTablePosition treeTablePosition2 = this.getSelectedCells().get(0);
                if (this.getSelectedItem() == this.getModelItem(n) && treeTablePosition2.getRow() == n && treeTablePosition2.getTableColumn() == tableColumnBase) {
                    return;
                }
            }
            this.startAtomic();
            this.clearSelection();
            this.select(n, tableColumnBase);
            this.stopAtomic();
            if (cellSelectionEnabled) {
                list.remove(treeTablePosition);
            }
            else {
                for (final TreeTablePosition treeTablePosition3 : list) {
                    if (treeTablePosition3.getRow() == n) {
                        list.remove(treeTablePosition3);
                        break;
                    }
                }
            }
            ListChangeListener.Change<TreeTablePosition<S, ?>> buildClearAndSelectChange;
            if (selected) {
                buildClearAndSelectChange = ControlUtils.buildClearAndSelectChange(this.selectedCellsSeq, list, n);
            }
            else {
                final int n2 = cellSelectionEnabled ? 0 : Math.max(0, this.selectedCellsSeq.indexOf(treeTablePosition));
                buildClearAndSelectChange = new NonIterableChange.GenericAddRemoveChange<TreeTablePosition<S, ?>>(n2, n2 + (cellSelectionEnabled ? this.getSelectedCells().size() : 1), (List<Object>)list, (ObservableList<Object>)this.selectedCellsSeq);
            }
            this.fireCustomSelectedCellsListChangeEvent(buildClearAndSelectChange);
        }
        
        @Override
        public void select(final int n) {
            this.select(n, null);
        }
        
        @Override
        public void select(final int n, final TableColumnBase<TreeItem<S>, ?> tableColumnBase) {
            if (n < 0 || n >= this.getRowCount()) {
                return;
            }
            if (this.isCellSelectionEnabled() && tableColumnBase == null) {
                final ObservableList<TreeTableColumn<S, ?>> visibleLeafColumns = this.getTreeTableView().getVisibleLeafColumns();
                for (int i = 0; i < visibleLeafColumns.size(); ++i) {
                    this.select(n, visibleLeafColumns.get(i));
                }
                return;
            }
            if (CellBehaviorBase.hasDefaultAnchor(this.treeTableView)) {
                CellBehaviorBase.removeAnchor(this.treeTableView);
            }
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
            }
            this.selectedCellsMap.add(new TreeTablePosition<S, Object>(this.getTreeTableView(), n, (TreeTableColumn<S, Object>)tableColumnBase));
            this.updateSelectedIndex(n);
            this.focus(n, (TreeTableColumn<S, ?>)tableColumnBase);
        }
        
        @Override
        public void select(final TreeItem<S> selectedItem) {
            if (selectedItem == null && this.getSelectionMode() == SelectionMode.SINGLE) {
                this.clearSelection();
                return;
            }
            final int row = this.treeTableView.getRow(selectedItem);
            if (row > -1) {
                if (this.isSelected(row)) {
                    return;
                }
                if (this.getSelectionMode() == SelectionMode.SINGLE) {
                    this.quietClearSelection();
                }
                this.select(row);
            }
            else {
                this.setSelectedIndex(-1);
                this.setSelectedItem((TreeItem<S>)selectedItem);
            }
        }
        
        @Override
        public void selectIndices(final int n, final int... array) {
            if (array == null) {
                this.select(n);
                return;
            }
            final int rowCount = this.getRowCount();
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
                for (int i = array.length - 1; i >= 0; --i) {
                    final int n2 = array[i];
                    if (n2 >= 0 && n2 < rowCount) {
                        this.select(n2);
                        break;
                    }
                }
                if (this.selectedCellsMap.isEmpty() && n > 0 && n < rowCount) {
                    this.select(n);
                }
            }
            else {
                int n3 = -1;
                final LinkedHashSet<TreeTablePosition<S, Object>> set = new LinkedHashSet<TreeTablePosition<S, Object>>();
                if (n >= 0 && n < rowCount) {
                    if (this.isCellSelectionEnabled()) {
                        final ObservableList<TreeTableColumn<S, ?>> visibleLeafColumns = this.getTreeTableView().getVisibleLeafColumns();
                        for (int j = 0; j < visibleLeafColumns.size(); ++j) {
                            if (!this.selectedCellsMap.isSelected(n, j)) {
                                set.add(new TreeTablePosition<S, Object>(this.getTreeTableView(), n, visibleLeafColumns.get(j)));
                            }
                        }
                    }
                    else if (!this.selectedCellsMap.isSelected(n, -1)) {
                        set.add(new TreeTablePosition<S, Object>(this.getTreeTableView(), n, null));
                    }
                    n3 = n;
                }
                for (int k = 0; k < array.length; ++k) {
                    final int n4 = array[k];
                    if (n4 >= 0) {
                        if (n4 < rowCount) {
                            n3 = n4;
                            if (this.isCellSelectionEnabled()) {
                                final ObservableList<TreeTableColumn<S, ?>> visibleLeafColumns2 = this.getTreeTableView().getVisibleLeafColumns();
                                for (int l = 0; l < visibleLeafColumns2.size(); ++l) {
                                    if (!this.selectedCellsMap.isSelected(n4, l)) {
                                        set.add(new TreeTablePosition<S, Object>(this.getTreeTableView(), n4, visibleLeafColumns2.get(l)));
                                        n3 = n4;
                                    }
                                }
                            }
                            else if (!this.selectedCellsMap.isSelected(n4, -1)) {
                                set.add(new TreeTablePosition<S, Object>(this.getTreeTableView(), n4, null));
                            }
                        }
                    }
                }
                this.selectedCellsMap.addAll((Collection<TreeTablePosition<S, ?>>)set);
                if (n3 != -1) {
                    this.select(n3);
                }
            }
        }
        
        @Override
        public void selectAll() {
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                return;
            }
            if (this.isCellSelectionEnabled()) {
                final ArrayList<TreeTablePosition<S, ?>> all = new ArrayList<TreeTablePosition<S, ?>>();
                TreeTablePosition<S, ?> treeTablePosition = null;
                for (int i = 0; i < this.getTreeTableView().getVisibleLeafColumns().size(); ++i) {
                    final TreeTableColumn<S, ?> treeTableColumn = this.getTreeTableView().getVisibleLeafColumns().get(i);
                    for (int j = 0; j < this.getRowCount(); ++j) {
                        treeTablePosition = new TreeTablePosition<S, Object>(this.getTreeTableView(), j, (TreeTableColumn<Object, Object>)treeTableColumn);
                        all.add(treeTablePosition);
                    }
                }
                this.selectedCellsMap.setAll(all);
                if (treeTablePosition != null) {
                    this.select(treeTablePosition.getRow(), (TableColumnBase<TreeItem<S>, ?>)treeTablePosition.getTableColumn());
                    this.focus(treeTablePosition.getRow(), treeTablePosition.getTableColumn());
                }
            }
            else {
                final ArrayList<Object> all2 = new ArrayList<Object>();
                for (int k = 0; k < this.getRowCount(); ++k) {
                    all2.add(new TreeTablePosition<S, Object>(this.getTreeTableView(), k, null));
                }
                this.selectedCellsMap.setAll((Collection<TreeTablePosition<S, ?>>)all2);
                final int focusedIndex = this.getFocusedIndex();
                if (focusedIndex == -1) {
                    final int itemCount = this.getItemCount();
                    if (itemCount > 0) {
                        this.select(itemCount - 1);
                        this.focus((TreeTablePosition<S, ?>)all2.get(all2.size() - 1));
                    }
                }
                else {
                    this.select(focusedIndex);
                    this.focus(focusedIndex);
                }
            }
        }
        
        @Override
        public void selectRange(final int n, final TableColumnBase<TreeItem<S>, ?> tableColumnBase, final int n2, final TableColumnBase<TreeItem<S>, ?> tableColumnBase2) {
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
                this.select(n2, tableColumnBase2);
                return;
            }
            this.startAtomic();
            final int itemCount = this.getItemCount();
            final boolean cellSelectionEnabled = this.isCellSelectionEnabled();
            final int visibleLeafIndex = this.treeTableView.getVisibleLeafIndex((TreeTableColumn<S, ?>)tableColumnBase);
            final int visibleLeafIndex2 = this.treeTableView.getVisibleLeafIndex((TreeTableColumn<S, ?>)tableColumnBase2);
            final int min = Math.min(visibleLeafIndex, visibleLeafIndex2);
            final int max = Math.max(visibleLeafIndex, visibleLeafIndex2);
            final int min2 = Math.min(n, n2);
            final int max2 = Math.max(n, n2);
            final ArrayList<TreeTablePosition<S, ?>> list = new ArrayList<TreeTablePosition<S, ?>>();
            for (int i = min2; i <= max2; ++i) {
                if (i >= 0) {
                    if (i < itemCount) {
                        if (!cellSelectionEnabled) {
                            list.add(new TreeTablePosition<S, Object>((TreeTableView<Object>)this.treeTableView, i, (TreeTableColumn<Object, Object>)tableColumnBase));
                        }
                        else {
                            for (int j = min; j <= max; ++j) {
                                final TreeTableColumn<S, ?> visibleLeafColumn = this.treeTableView.getVisibleLeafColumn(j);
                                if (visibleLeafColumn != null || !cellSelectionEnabled) {
                                    list.add(new TreeTablePosition<S, Object>((TreeTableView<Object>)this.treeTableView, i, (TreeTableColumn<Object, Object>)visibleLeafColumn));
                                }
                            }
                        }
                    }
                }
            }
            list.removeAll(this.getSelectedCells());
            this.selectedCellsMap.addAll(list);
            this.stopAtomic();
            this.updateSelectedIndex(n2);
            this.focus(n2, (TreeTableColumn<S, ?>)tableColumnBase2);
            final TreeTableColumn<S, ?> treeTableColumn = (TreeTableColumn<S, ?>)tableColumnBase;
            final TreeTableColumn<S, ?> treeTableColumn2 = (TreeTableColumn<S, ?>)(cellSelectionEnabled ? tableColumnBase2 : treeTableColumn);
            final int index = this.selectedCellsMap.indexOf(new TreeTablePosition<S, Object>(this.treeTableView, n, (TreeTableColumn<S, Object>)treeTableColumn));
            final int index2 = this.selectedCellsMap.indexOf(new TreeTablePosition<S, Object>(this.treeTableView, n2, (TreeTableColumn<S, Object>)treeTableColumn2));
            if (index > -1 && index2 > -1) {
                this.fireCustomSelectedCellsListChangeEvent(new NonIterableChange.SimpleAddChange<TreeTablePosition<S, ?>>(Math.min(index, index2), Math.max(index, index2) + 1, (ObservableList<Object>)this.selectedCellsSeq));
            }
        }
        
        @Override
        public void clearSelection(final int n) {
            this.clearSelection(n, null);
        }
        
        @Override
        public void clearSelection(final int n, final TableColumnBase<TreeItem<S>, ?> tableColumnBase) {
            this.clearSelection(new TreeTablePosition<S, Object>(this.getTreeTableView(), n, (TreeTableColumn<S, ?>)tableColumnBase));
        }
        
        private void clearSelection(final TreeTablePosition<S, ?> treeTablePosition) {
            final boolean cellSelectionEnabled = this.isCellSelectionEnabled();
            final int row = treeTablePosition.getRow();
            final boolean b = treeTablePosition.getTableColumn() == null;
            final ArrayList<TreeTablePosition<S, ?>> list = new ArrayList<TreeTablePosition<S, ?>>();
            for (final TreeTablePosition<S, ?> treeTablePosition2 : this.getSelectedCells()) {
                if (!cellSelectionEnabled) {
                    if (treeTablePosition2.getRow() == row) {
                        list.add(treeTablePosition2);
                        break;
                    }
                    continue;
                }
                else if (b && treeTablePosition2.getRow() == row) {
                    list.add(treeTablePosition2);
                }
                else {
                    if (treeTablePosition2.equals(treeTablePosition)) {
                        list.add(treeTablePosition);
                        break;
                    }
                    continue;
                }
            }
            final Stream<Object> stream = list.stream();
            final SelectedCellsMap<TreeTablePosition<S, ?>> selectedCellsMap = this.selectedCellsMap;
            Objects.requireNonNull(selectedCellsMap);
            stream.forEach((Consumer<? super Object>)selectedCellsMap::remove);
            if (this.isEmpty() && !this.isAtomic()) {
                this.updateSelectedIndex(-1);
                this.selectedCellsMap.clear();
            }
        }
        
        @Override
        public void clearSelection() {
            final ArrayList list = new ArrayList((Collection<? extends E>)this.getSelectedCells());
            this.quietClearSelection();
            if (!this.isAtomic()) {
                this.updateSelectedIndex(-1);
                this.focus(-1);
                if (!list.isEmpty()) {
                    this.fireCustomSelectedCellsListChangeEvent(new NonIterableChange<TreeTablePosition<S, ?>>(0, 0, this.selectedCellsSeq) {
                        @Override
                        public List<TreeTablePosition<S, ?>> getRemoved() {
                            return (List<TreeTablePosition<S, ?>>)list;
                        }
                    });
                }
            }
        }
        
        private void quietClearSelection() {
            this.startAtomic();
            this.selectedCellsMap.clear();
            this.stopAtomic();
        }
        
        @Override
        public boolean isSelected(final int n) {
            return this.isSelected(n, null);
        }
        
        @Override
        public boolean isSelected(final int n, final TableColumnBase<TreeItem<S>, ?> tableColumnBase) {
            final boolean cellSelectionEnabled = this.isCellSelectionEnabled();
            if (cellSelectionEnabled && tableColumnBase == null) {
                for (int size = this.treeTableView.getVisibleLeafColumns().size(), i = 0; i < size; ++i) {
                    if (!this.selectedCellsMap.isSelected(n, i)) {
                        return false;
                    }
                }
                return true;
            }
            return this.selectedCellsMap.isSelected(n, (!cellSelectionEnabled || tableColumnBase == null) ? -1 : this.treeTableView.getVisibleLeafIndex((TreeTableColumn<S, ?>)tableColumnBase));
        }
        
        @Override
        public boolean isEmpty() {
            return this.selectedCellsMap.isEmpty();
        }
        
        @Override
        public void selectPrevious() {
            if (this.isCellSelectionEnabled()) {
                final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
                if (focusedCell.getColumn() - 1 >= 0) {
                    this.select(focusedCell.getRow(), (TableColumnBase<TreeItem<S>, ?>)this.getTableColumn(focusedCell.getTableColumn(), -1));
                }
                else if (focusedCell.getRow() < this.getRowCount() - 1) {
                    this.select(focusedCell.getRow() - 1, (TableColumnBase<TreeItem<S>, ?>)this.getTableColumn(this.getTreeTableView().getVisibleLeafColumns().size() - 1));
                }
            }
            else {
                final int focusedIndex = this.getFocusedIndex();
                if (focusedIndex == -1) {
                    this.select(this.getRowCount() - 1);
                }
                else if (focusedIndex > 0) {
                    this.select(focusedIndex - 1);
                }
            }
        }
        
        @Override
        public void selectNext() {
            if (this.isCellSelectionEnabled()) {
                final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
                if (focusedCell.getColumn() + 1 < this.getTreeTableView().getVisibleLeafColumns().size()) {
                    this.select(focusedCell.getRow(), (TableColumnBase<TreeItem<S>, ?>)this.getTableColumn(focusedCell.getTableColumn(), 1));
                }
                else if (focusedCell.getRow() < this.getRowCount() - 1) {
                    this.select(focusedCell.getRow() + 1, (TableColumnBase<TreeItem<S>, ?>)this.getTableColumn(0));
                }
            }
            else {
                final int focusedIndex = this.getFocusedIndex();
                if (focusedIndex == -1) {
                    this.select(0);
                }
                else if (focusedIndex < this.getRowCount() - 1) {
                    this.select(focusedIndex + 1);
                }
            }
        }
        
        @Override
        public void selectAboveCell() {
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getRow() == -1) {
                this.select(this.getRowCount() - 1);
            }
            else if (focusedCell.getRow() > 0) {
                this.select(focusedCell.getRow() - 1, (TableColumnBase<TreeItem<S>, ?>)focusedCell.getTableColumn());
            }
        }
        
        @Override
        public void selectBelowCell() {
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getRow() == -1) {
                this.select(0);
            }
            else if (focusedCell.getRow() < this.getRowCount() - 1) {
                this.select(focusedCell.getRow() + 1, (TableColumnBase<TreeItem<S>, ?>)focusedCell.getTableColumn());
            }
        }
        
        @Override
        public void selectFirst() {
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
            }
            if (this.getRowCount() > 0) {
                if (this.isCellSelectionEnabled()) {
                    this.select(0, (TableColumnBase<TreeItem<S>, ?>)focusedCell.getTableColumn());
                }
                else {
                    this.select(0);
                }
            }
        }
        
        @Override
        public void selectLast() {
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
            }
            final int rowCount = this.getRowCount();
            if (rowCount > 0 && this.getSelectedIndex() < rowCount - 1) {
                if (this.isCellSelectionEnabled()) {
                    this.select(rowCount - 1, (TableColumnBase<TreeItem<S>, ?>)focusedCell.getTableColumn());
                }
                else {
                    this.select(rowCount - 1);
                }
            }
        }
        
        @Override
        public void selectLeftCell() {
            if (!this.isCellSelectionEnabled()) {
                return;
            }
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getColumn() - 1 >= 0) {
                this.select(focusedCell.getRow(), (TableColumnBase<TreeItem<S>, ?>)this.getTableColumn(focusedCell.getTableColumn(), -1));
            }
        }
        
        @Override
        public void selectRightCell() {
            if (!this.isCellSelectionEnabled()) {
                return;
            }
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getColumn() + 1 < this.getTreeTableView().getVisibleLeafColumns().size()) {
                this.select(focusedCell.getRow(), (TableColumnBase<TreeItem<S>, ?>)this.getTableColumn(focusedCell.getTableColumn(), 1));
            }
        }
        
        private void updateDefaultSelection() {
            int row = -1;
            final TreeItem<S> treeItem = this.getSelectedItem();
            if (treeItem != null) {
                row = this.treeTableView.getRow((TreeItem<S>)treeItem);
            }
            final int n = (row != -1) ? row : ((this.treeTableView.getExpandedItemCount() > 0) ? 0 : -1);
            this.clearSelection();
            this.select(row, (TableColumnBase<TreeItem<S>, ?>)(this.isCellSelectionEnabled() ? this.getTableColumn(0) : null));
            this.focus(n, this.isCellSelectionEnabled() ? this.getTableColumn(0) : null);
        }
        
        private TreeTableColumn<S, ?> getTableColumn(final int n) {
            return this.getTreeTableView().getVisibleLeafColumn(n);
        }
        
        private TreeTableColumn<S, ?> getTableColumn(final TreeTableColumn<S, ?> treeTableColumn, final int n) {
            return this.getTreeTableView().getVisibleLeafColumn(this.getTreeTableView().getVisibleLeafIndex(treeTableColumn) + n);
        }
        
        private void updateSelectedIndex(final int selectedIndex) {
            this.setSelectedIndex(selectedIndex);
            this.setSelectedItem((TreeItem<S>)this.getModelItem(selectedIndex));
        }
        
        @Override
        public void focus(final int n) {
            this.focus(n, null);
        }
        
        private void focus(final int n, final TreeTableColumn<S, ?> treeTableColumn) {
            this.focus(new TreeTablePosition<S, Object>(this.getTreeTableView(), n, treeTableColumn));
        }
        
        private void focus(final TreeTablePosition<S, ?> treeTablePosition) {
            if (this.getTreeTableView().getFocusModel() == null) {
                return;
            }
            this.getTreeTableView().getFocusModel().focus(treeTablePosition.getRow(), treeTablePosition.getTableColumn());
            this.getTreeTableView().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
        }
        
        @Override
        public int getFocusedIndex() {
            return this.getFocusedCell().getRow();
        }
        
        private TreeTablePosition<S, ?> getFocusedCell() {
            if (this.treeTableView.getFocusModel() == null) {
                return new TreeTablePosition<S, Object>(this.treeTableView, -1, null);
            }
            return this.treeTableView.getFocusModel().getFocusedCell();
        }
        
        private int getRowCount() {
            return this.treeTableView.getExpandedItemCount();
        }
        
        private void fireCustomSelectedCellsListChangeEvent(final ListChangeListener.Change<? extends TreeTablePosition<S, ?>> change) {
            ControlUtils.updateSelectedIndices(this, change);
            if (this.isAtomic()) {
                return;
            }
            this.selectedCellsSeq.callObservers((ListChangeListener.Change<TreeTablePosition<S, ?>>)new MappingChange(change, MappingChange.NOOP_MAP, (ObservableList<Object>)this.selectedCellsSeq));
        }
    }
    
    public static class TreeTableViewFocusModel<S> extends TableFocusModel<TreeItem<S>, TreeTableColumn<S, ?>>
    {
        private final TreeTableView<S> treeTableView;
        private final TreeTablePosition EMPTY_CELL;
        private final ChangeListener<TreeItem<S>> rootPropertyListener;
        private final WeakChangeListener<TreeItem<S>> weakRootPropertyListener;
        private EventHandler<TreeItem.TreeModificationEvent<S>> treeItemListener;
        private WeakEventHandler<TreeItem.TreeModificationEvent<S>> weakTreeItemListener;
        private ReadOnlyObjectWrapper<TreeTablePosition<S, ?>> focusedCell;
        
        public TreeTableViewFocusModel(final TreeTableView<S> treeTableView) {
            this.rootPropertyListener = ((p0, treeItem, treeItem2) -> this.updateTreeEventListener(treeItem, treeItem2));
            this.weakRootPropertyListener = new WeakChangeListener<TreeItem<S>>(this.rootPropertyListener);
            this.treeItemListener = new EventHandler<TreeItem.TreeModificationEvent<S>>() {
                @Override
                public void handle(final TreeItem.TreeModificationEvent<S> treeModificationEvent) {
                    if (TreeTableViewFocusModel.this.getFocusedIndex() == -1) {
                        return;
                    }
                    int n = 0;
                    if (treeModificationEvent.getChange() != null) {
                        treeModificationEvent.getChange().next();
                    }
                    do {
                        final int row = TreeTableViewFocusModel.this.treeTableView.getRow(treeModificationEvent.getTreeItem());
                        if (treeModificationEvent.wasExpanded()) {
                            if (row >= TreeTableViewFocusModel.this.getFocusedIndex()) {
                                continue;
                            }
                            n += treeModificationEvent.getTreeItem().getExpandedDescendentCount(false) - 1;
                        }
                        else if (treeModificationEvent.wasCollapsed()) {
                            if (row >= TreeTableViewFocusModel.this.getFocusedIndex()) {
                                continue;
                            }
                            n += -treeModificationEvent.getTreeItem().previousExpandedDescendentCount + 1;
                        }
                        else if (treeModificationEvent.wasAdded()) {
                            if (!treeModificationEvent.getTreeItem().isExpanded()) {
                                continue;
                            }
                            for (int i = 0; i < treeModificationEvent.getAddedChildren().size(); ++i) {
                                final TreeItem treeItem = (TreeItem)treeModificationEvent.getAddedChildren().get(i);
                                final int row2 = TreeTableViewFocusModel.this.treeTableView.getRow(treeItem);
                                if (treeItem != null && row2 <= n + TreeTableViewFocusModel.this.getFocusedIndex()) {
                                    n += treeItem.getExpandedDescendentCount(false);
                                }
                            }
                        }
                        else {
                            if (!treeModificationEvent.wasRemoved()) {
                                continue;
                            }
                            final int n2 = row + (treeModificationEvent.getFrom() + 1);
                            for (int j = 0; j < treeModificationEvent.getRemovedChildren().size(); ++j) {
                                final TreeItem treeItem2 = (TreeItem)treeModificationEvent.getRemovedChildren().get(j);
                                if (treeItem2 != null && treeItem2.equals(TreeTableViewFocusModel.this.getFocusedItem())) {
                                    TreeTableViewFocusModel.this.focus(Math.max(0, TreeTableViewFocusModel.this.getFocusedIndex() - 1));
                                    return;
                                }
                            }
                            if (n2 > TreeTableViewFocusModel.this.getFocusedIndex()) {
                                continue;
                            }
                            n += (treeModificationEvent.getTreeItem().isExpanded() ? (-treeModificationEvent.getRemovedSize()) : 0);
                        }
                    } while (treeModificationEvent.getChange() != null && treeModificationEvent.getChange().next());
                    if (n != 0 && TreeTableViewFocusModel.this.getFocusedCell().getRow() + n >= 0) {
                        final int n3;
                        final TreeTablePosition<S, ?> treeTablePosition;
                        Platform.runLater(() -> TreeTableViewFocusModel.this.focus(n3, treeTablePosition.getTableColumn()));
                    }
                }
            };
            if (treeTableView == null) {
                throw new NullPointerException("TableView can not be null");
            }
            this.treeTableView = treeTableView;
            this.EMPTY_CELL = new TreeTablePosition((TreeTableView<Object>)treeTableView, -1, null);
            this.treeTableView.rootProperty().addListener(this.weakRootPropertyListener);
            this.updateTreeEventListener(null, treeTableView.getRoot());
            this.setFocusedCell(new TreeTablePosition<S, Object>((TreeTableView<Object>)treeTableView, (this.getItemCount() > 0) ? 0 : -1, null));
            treeTableView.showRootProperty().addListener(p0 -> {
                if (this.isFocused(0)) {
                    this.focus(-1);
                    this.focus(0);
                }
                return;
            });
            this.focusedCellProperty().addListener(p1 -> treeTableView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM));
        }
        
        private void updateTreeEventListener(final TreeItem<S> treeItem, final TreeItem<S> treeItem2) {
            if (treeItem != null && this.weakTreeItemListener != null) {
                treeItem.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakTreeItemListener);
            }
            if (treeItem2 != null) {
                this.weakTreeItemListener = new WeakEventHandler<TreeItem.TreeModificationEvent<S>>(this.treeItemListener);
                treeItem2.addEventHandler(TreeItem.expandedItemCountChangeEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakTreeItemListener);
            }
        }
        
        @Override
        protected int getItemCount() {
            return this.treeTableView.getExpandedItemCount();
        }
        
        @Override
        protected TreeItem<S> getModelItem(final int n) {
            if (n < 0 || n >= this.getItemCount()) {
                return null;
            }
            return this.treeTableView.getTreeItem(n);
        }
        
        public final ReadOnlyObjectProperty<TreeTablePosition<S, ?>> focusedCellProperty() {
            return this.focusedCellPropertyImpl().getReadOnlyProperty();
        }
        
        private void setFocusedCell(final TreeTablePosition<S, ?> treeTablePosition) {
            this.focusedCellPropertyImpl().set(treeTablePosition);
        }
        
        public final TreeTablePosition<S, ?> getFocusedCell() {
            return (this.focusedCell == null) ? this.EMPTY_CELL : ((TreeTablePosition<S, ?>)this.focusedCell.get());
        }
        
        private ReadOnlyObjectWrapper<TreeTablePosition<S, ?>> focusedCellPropertyImpl() {
            if (this.focusedCell == null) {
                this.focusedCell = new ReadOnlyObjectWrapper<TreeTablePosition<S, ?>>(this.EMPTY_CELL) {
                    private TreeTablePosition<S, ?> old;
                    
                    @Override
                    protected void invalidated() {
                        if (this.get() == null) {
                            return;
                        }
                        if (this.old == null || !this.old.equals(((ObjectPropertyBase<Object>)this).get())) {
                            TreeTableViewFocusModel.this.setFocusedIndex(((ObjectPropertyBase<TreeTablePosition>)this).get().getRow());
                            TreeTableViewFocusModel.this.setFocusedItem(TreeTableViewFocusModel.this.getModelItem(((ObjectExpression<TreeTablePosition>)this).getValue().getRow()));
                            this.old = this.get();
                        }
                    }
                    
                    @Override
                    public Object getBean() {
                        return TreeTableViewFocusModel.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "focusedCell";
                    }
                };
            }
            return this.focusedCell;
        }
        
        @Override
        public void focus(final int focusedIndex, final TreeTableColumn<S, ?> treeTableColumn) {
            if (focusedIndex < 0 || focusedIndex >= this.getItemCount()) {
                this.setFocusedCell(this.EMPTY_CELL);
            }
            else {
                final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
                final TreeTablePosition<S, Object> focusedCell2 = new TreeTablePosition<S, Object>(this.treeTableView, focusedIndex, (TreeTableColumn<S, Object>)treeTableColumn);
                this.setFocusedCell(focusedCell2);
                if (focusedCell2.equals(focusedCell)) {
                    this.setFocusedIndex(focusedIndex);
                    this.setFocusedItem((T)this.getModelItem(focusedIndex));
                }
            }
        }
        
        public void focus(final TreeTablePosition<S, ?> treeTablePosition) {
            if (treeTablePosition == null) {
                return;
            }
            this.focus(treeTablePosition.getRow(), treeTablePosition.getTableColumn());
        }
        
        @Override
        public boolean isFocused(final int n, final TreeTableColumn<S, ?> treeTableColumn) {
            if (n < 0 || n >= this.getItemCount()) {
                return false;
            }
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            final boolean b = treeTableColumn == null || treeTableColumn.equals(focusedCell.getTableColumn());
            return focusedCell.getRow() == n && b;
        }
        
        @Override
        public void focus(final int n) {
            if (((TreeTableView<Object>)this.treeTableView).expandedItemCountDirty) {
                ((TreeTableView<Object>)this.treeTableView).updateExpandedItemCount(this.treeTableView.getRoot());
            }
            if (n < 0 || n >= this.getItemCount()) {
                this.setFocusedCell(this.EMPTY_CELL);
            }
            else {
                this.setFocusedCell(new TreeTablePosition<S, Object>(this.treeTableView, n, null));
            }
        }
        
        @Override
        public void focusAboveCell() {
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (this.getFocusedIndex() == -1) {
                this.focus(this.getItemCount() - 1, focusedCell.getTableColumn());
            }
            else if (this.getFocusedIndex() > 0) {
                this.focus(this.getFocusedIndex() - 1, focusedCell.getTableColumn());
            }
        }
        
        @Override
        public void focusBelowCell() {
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (this.getFocusedIndex() == -1) {
                this.focus(0, focusedCell.getTableColumn());
            }
            else if (this.getFocusedIndex() != this.getItemCount() - 1) {
                this.focus(this.getFocusedIndex() + 1, focusedCell.getTableColumn());
            }
        }
        
        @Override
        public void focusLeftCell() {
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getColumn() <= 0) {
                return;
            }
            this.focus(focusedCell.getRow(), this.getTableColumn(focusedCell.getTableColumn(), -1));
        }
        
        @Override
        public void focusRightCell() {
            final TreeTablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getColumn() == this.getColumnCount() - 1) {
                return;
            }
            this.focus(focusedCell.getRow(), this.getTableColumn(focusedCell.getTableColumn(), 1));
        }
        
        @Override
        public void focusPrevious() {
            if (this.getFocusedIndex() == -1) {
                this.focus(0);
            }
            else if (this.getFocusedIndex() > 0) {
                this.focusAboveCell();
            }
        }
        
        @Override
        public void focusNext() {
            if (this.getFocusedIndex() == -1) {
                this.focus(0);
            }
            else if (this.getFocusedIndex() != this.getItemCount() - 1) {
                this.focusBelowCell();
            }
        }
        
        private int getColumnCount() {
            return this.treeTableView.getVisibleLeafColumns().size();
        }
        
        private TreeTableColumn<S, ?> getTableColumn(final TreeTableColumn<S, ?> treeTableColumn, final int n) {
            return this.treeTableView.getVisibleLeafColumn(this.treeTableView.getVisibleLeafIndex(treeTableColumn) + n);
        }
    }
}
