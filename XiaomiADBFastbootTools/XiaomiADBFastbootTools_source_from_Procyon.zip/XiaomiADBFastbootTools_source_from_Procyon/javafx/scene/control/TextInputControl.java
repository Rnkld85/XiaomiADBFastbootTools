// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.value.ObservableStringValue;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.FontCssMetaData;
import javafx.beans.value.ChangeListener;
import com.sun.javafx.binding.ExpressionHelper;
import javafx.beans.InvalidationListener;
import javafx.scene.AccessibleAction;
import javafx.css.Styleable;
import java.util.List;
import javafx.util.StringConverter;
import javafx.scene.AccessibleAttribute;
import com.sun.javafx.util.Utils;
import javafx.scene.input.DataFormat;
import java.util.Map;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyStringProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.css.CssMetaData;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import javafx.css.StyleOrigin;
import javafx.css.StyleableObjectProperty;
import javafx.beans.binding.StringBinding;
import javafx.beans.value.ObservableValue;
import javafx.beans.Observable;
import javafx.beans.binding.IntegerBinding;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleStringProperty;
import javafx.css.PseudoClass;
import com.sun.javafx.scene.control.FormatterAccessor;
import java.text.BreakIterator;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.StringProperty;
import javafx.scene.text.Font;
import javafx.beans.property.ObjectProperty;
import javafx.beans.DefaultProperty;

@DefaultProperty("text")
public abstract class TextInputControl extends Control
{
    private ObjectProperty<Font> font;
    private StringProperty promptText;
    private final ObjectProperty<TextFormatter<?>> textFormatter;
    private final Content content;
    private TextProperty text;
    private ReadOnlyIntegerWrapper length;
    private BooleanProperty editable;
    private ReadOnlyObjectWrapper<IndexRange> selection;
    private ReadOnlyStringWrapper selectedText;
    private ReadOnlyIntegerWrapper anchor;
    private ReadOnlyIntegerWrapper caretPosition;
    private UndoRedoChange undoChangeHead;
    private UndoRedoChange undoChange;
    private boolean createNewUndoRecord;
    private final ReadOnlyBooleanWrapper undoable;
    private final ReadOnlyBooleanWrapper redoable;
    private BreakIterator charIterator;
    private BreakIterator wordIterator;
    private FormatterAccessor accessor;
    private static final PseudoClass PSEUDO_CLASS_READONLY;
    
    protected TextInputControl(final Content content) {
        this.promptText = new SimpleStringProperty((Object)this, "promptText", "") {
            @Override
            protected void invalidated() {
                final String value = this.get();
                if (value != null && value.contains("\n")) {
                    this.set(value.replace("\n", ""));
                }
            }
        };
        this.textFormatter = new ObjectPropertyBase<TextFormatter<?>>() {
            private TextFormatter<?> oldFormatter = null;
            
            @Override
            public Object getBean() {
                return TextInputControl.this;
            }
            
            @Override
            public String getName() {
                return "textFormatter";
            }
            
            @Override
            protected void invalidated() {
                final TextFormatter<?> oldFormatter = this.get();
                try {
                    if (oldFormatter != null) {
                        try {
                            oldFormatter.bindToControl(textFormatter -> TextInputControl.this.updateText((TextFormatter<Object>)textFormatter));
                        }
                        catch (IllegalStateException ex) {
                            if (this.isBound()) {
                                this.unbind();
                            }
                            this.set(null);
                            throw ex;
                        }
                        if (!TextInputControl.this.isFocused()) {
                            TextInputControl.this.updateText((TextFormatter<Object>)((ObjectPropertyBase<TextFormatter>)this).get());
                        }
                    }
                    if (this.oldFormatter != null) {
                        this.oldFormatter.unbindFromControl();
                    }
                }
                finally {
                    this.oldFormatter = oldFormatter;
                }
            }
        };
        this.text = new TextProperty();
        this.length = new ReadOnlyIntegerWrapper(this, "length");
        this.editable = new SimpleBooleanProperty((Object)this, "editable", true) {
            @Override
            protected void invalidated() {
                TextInputControl.this.pseudoClassStateChanged(TextInputControl.PSEUDO_CLASS_READONLY, !this.get());
            }
        };
        this.selection = new ReadOnlyObjectWrapper<IndexRange>(this, "selection", new IndexRange(0, 0));
        this.selectedText = new ReadOnlyStringWrapper(this, "selectedText");
        this.anchor = new ReadOnlyIntegerWrapper(this, "anchor", 0);
        this.caretPosition = new ReadOnlyIntegerWrapper(this, "caretPosition", 0);
        this.undoChangeHead = new UndoRedoChange();
        this.undoChange = this.undoChangeHead;
        this.createNewUndoRecord = false;
        this.undoable = new ReadOnlyBooleanWrapper(this, "undoable", false);
        this.redoable = new ReadOnlyBooleanWrapper(this, "redoable", false);
        (this.content = content).addListener(p1 -> {
            if (content.length() > 0) {
                this.text.textIsNull = false;
            }
            this.text.controlContentHasChanged();
            return;
        });
        this.length.bind(new IntegerBinding() {
            {
                this.bind(TextInputControl.this.text);
            }
            
            @Override
            protected int computeValue() {
                final String value = TextInputControl.this.text.get();
                return (value == null) ? 0 : value.length();
            }
        });
        this.selectedText.bind(new StringBinding() {
            {
                this.bind(TextInputControl.this.selection, TextInputControl.this.text);
            }
            
            @Override
            protected String computeValue() {
                final String value = TextInputControl.this.text.get();
                final IndexRange indexRange = (IndexRange)TextInputControl.this.selection.get();
                if (value == null || indexRange == null) {
                    return "";
                }
                int start = indexRange.getStart();
                int end = indexRange.getEnd();
                final int length = value.length();
                if (end > start + length) {
                    end = length;
                }
                if (start > length - 1) {
                    end = (start = 0);
                }
                return value.substring(start, end);
            }
        });
        this.focusedProperty().addListener((p0, p1, b) -> {
            if (b) {
                if (this.getTextFormatter() != null) {
                    this.updateText(this.getTextFormatter());
                }
            }
            else {
                this.commitValue();
            }
            return;
        });
        this.getStyleClass().add("text-input");
    }
    
    public final ObjectProperty<Font> fontProperty() {
        if (this.font == null) {
            this.font = new StyleableObjectProperty<Font>(Font.getDefault()) {
                private boolean fontSetByCss = false;
                
                @Override
                public void applyStyle(final StyleOrigin styleOrigin, final Font font) {
                    try {
                        this.fontSetByCss = true;
                        super.applyStyle(styleOrigin, font);
                    }
                    catch (Exception ex) {
                        throw ex;
                    }
                    finally {
                        this.fontSetByCss = false;
                    }
                }
                
                @Override
                public void set(final Font font) {
                    final Font font2 = this.get();
                    Label_0028: {
                        if (font == null) {
                            if (font2 != null) {
                                break Label_0028;
                            }
                        }
                        else if (!font.equals(font2)) {
                            break Label_0028;
                        }
                        return;
                    }
                    super.set(font);
                }
                
                @Override
                protected void invalidated() {
                    if (!this.fontSetByCss) {
                        NodeHelper.reapplyCSS(TextInputControl.this);
                    }
                }
                
                @Override
                public CssMetaData<TextInputControl, Font> getCssMetaData() {
                    return (CssMetaData<TextInputControl, Font>)StyleableProperties.FONT;
                }
                
                @Override
                public Object getBean() {
                    return TextInputControl.this;
                }
                
                @Override
                public String getName() {
                    return "font";
                }
            };
        }
        return this.font;
    }
    
    public final void setFont(final Font value) {
        this.fontProperty().setValue(value);
    }
    
    public final Font getFont() {
        return (this.font == null) ? Font.getDefault() : this.font.getValue();
    }
    
    public final StringProperty promptTextProperty() {
        return this.promptText;
    }
    
    public final String getPromptText() {
        return this.promptText.get();
    }
    
    public final void setPromptText(final String s) {
        this.promptText.set(s);
    }
    
    public final ObjectProperty<TextFormatter<?>> textFormatterProperty() {
        return this.textFormatter;
    }
    
    public final TextFormatter<?> getTextFormatter() {
        return this.textFormatter.get();
    }
    
    public final void setTextFormatter(final TextFormatter<?> textFormatter) {
        this.textFormatter.set(textFormatter);
    }
    
    protected final Content getContent() {
        return this.content;
    }
    
    public final String getText() {
        return this.text.get();
    }
    
    public final void setText(final String s) {
        this.text.set(s);
    }
    
    public final StringProperty textProperty() {
        return this.text;
    }
    
    public final int getLength() {
        return this.length.get();
    }
    
    public final ReadOnlyIntegerProperty lengthProperty() {
        return this.length.getReadOnlyProperty();
    }
    
    public final boolean isEditable() {
        return this.editable.getValue();
    }
    
    public final void setEditable(final boolean b) {
        this.editable.setValue(b);
    }
    
    public final BooleanProperty editableProperty() {
        return this.editable;
    }
    
    public final IndexRange getSelection() {
        return this.selection.getValue();
    }
    
    public final ReadOnlyObjectProperty<IndexRange> selectionProperty() {
        return this.selection.getReadOnlyProperty();
    }
    
    public final String getSelectedText() {
        return this.selectedText.get();
    }
    
    public final ReadOnlyStringProperty selectedTextProperty() {
        return this.selectedText.getReadOnlyProperty();
    }
    
    public final int getAnchor() {
        return this.anchor.get();
    }
    
    public final ReadOnlyIntegerProperty anchorProperty() {
        return this.anchor.getReadOnlyProperty();
    }
    
    public final int getCaretPosition() {
        return this.caretPosition.get();
    }
    
    public final ReadOnlyIntegerProperty caretPositionProperty() {
        return this.caretPosition.getReadOnlyProperty();
    }
    
    public final boolean isUndoable() {
        return this.undoable.get();
    }
    
    public final ReadOnlyBooleanProperty undoableProperty() {
        return this.undoable.getReadOnlyProperty();
    }
    
    public final boolean isRedoable() {
        return this.redoable.get();
    }
    
    public final ReadOnlyBooleanProperty redoableProperty() {
        return this.redoable.getReadOnlyProperty();
    }
    
    public String getText(final int n, final int n2) {
        if (n > n2) {
            throw new IllegalArgumentException("The start must be <= the end");
        }
        if (n < 0 || n2 > this.getLength()) {
            throw new IndexOutOfBoundsException();
        }
        return this.getContent().get(n, n2);
    }
    
    public void appendText(final String s) {
        this.insertText(this.getLength(), s);
    }
    
    public void insertText(final int n, final String s) {
        this.replaceText(n, n, s);
    }
    
    public void deleteText(final IndexRange indexRange) {
        this.replaceText(indexRange, "");
    }
    
    public void deleteText(final int n, final int n2) {
        this.replaceText(n, n2, "");
    }
    
    public void replaceText(final IndexRange indexRange, final String s) {
        final int start = indexRange.getStart();
        this.replaceText(start, start + indexRange.getLength(), s);
    }
    
    public void replaceText(final int n, final int n2, final String s) {
        if (n > n2) {
            throw new IllegalArgumentException();
        }
        if (s == null) {
            throw new NullPointerException();
        }
        if (n < 0 || n2 > this.getLength()) {
            throw new IndexOutOfBoundsException();
        }
        if (!this.text.isBound()) {
            final int length = this.getLength();
            final TextFormatter<?> textFormatter = this.getTextFormatter();
            TextFormatter.Change change = new TextFormatter.Change(this, this.getFormatterAccessor(), n, n2, s);
            if (textFormatter != null && textFormatter.getFilter() != null) {
                change = (TextFormatter.Change)textFormatter.getFilter().apply(change);
                if (change == null) {
                    return;
                }
            }
            this.updateContent(change, length == 0);
        }
    }
    
    private void updateContent(final TextFormatter.Change change, final boolean b) {
        final boolean b2 = this.getSelection().getLength() > 0;
        final String text = this.getText(change.start, change.end);
        final String text2 = this.getText(change.start, change.start + change.text.length() - this.replaceText(change.start, change.end, change.text, change.getAnchor(), change.getCaretPosition()));
        if (text2.equals(text)) {
            return;
        }
        final int n = (this.undoChange == this.undoChangeHead) ? -1 : (this.undoChange.start + this.undoChange.newText.length());
        boolean b3 = false;
        if (text2.equals(" ")) {
            if (!UndoRedoChange.isSpaceCharSequence()) {
                b3 = true;
                UndoRedoChange.setSpaceCharSequence(true);
            }
        }
        else {
            UndoRedoChange.setSpaceCharSequence(false);
        }
        if (this.createNewUndoRecord || b2 || n == -1 || b || b3 || UndoRedoChange.hasChangeDurationElapsed() || (n != change.start && n != change.end) || change.end - change.start > 0) {
            this.undoChange = this.undoChange.add(change.start, text, text2);
        }
        else if (change.start != change.end && change.text.isEmpty()) {
            if (this.undoChange.newText.length() > 0) {
                this.undoChange.newText = this.undoChange.newText.substring(0, change.start - this.undoChange.start);
                if (this.undoChange.newText.isEmpty()) {
                    this.undoChange = this.undoChange.discard();
                }
            }
            else if (change.start == n) {
                final UndoRedoChange undoChange = this.undoChange;
                undoChange.oldText = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, undoChange.oldText, text);
            }
            else {
                this.undoChange.oldText = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, text, this.undoChange.oldText);
                final UndoRedoChange undoChange2 = this.undoChange;
                --undoChange2.start;
            }
        }
        else {
            final UndoRedoChange undoChange3 = this.undoChange;
            undoChange3.newText = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, undoChange3.newText, text2);
        }
        this.updateUndoRedoState();
    }
    
    public void cut() {
        this.copy();
        final IndexRange selection = this.getSelection();
        this.deleteText(selection.getStart(), selection.getEnd());
    }
    
    public void copy() {
        final String selectedText = this.getSelectedText();
        if (selectedText.length() > 0) {
            final ClipboardContent content = new ClipboardContent();
            content.putString(selectedText);
            Clipboard.getSystemClipboard().setContent(content);
        }
    }
    
    public void paste() {
        final Clipboard systemClipboard = Clipboard.getSystemClipboard();
        if (systemClipboard.hasString()) {
            final String string = systemClipboard.getString();
            if (string != null) {
                this.createNewUndoRecord = true;
                try {
                    this.replaceSelection(string);
                }
                finally {
                    this.createNewUndoRecord = false;
                }
            }
        }
    }
    
    public void selectBackward() {
        if (this.getCaretPosition() > 0 && this.getLength() > 0) {
            if (this.charIterator == null) {
                this.charIterator = BreakIterator.getCharacterInstance();
            }
            this.charIterator.setText(this.getText());
            this.selectRange(this.getAnchor(), this.charIterator.preceding(this.getCaretPosition()));
        }
    }
    
    public void selectForward() {
        final int length = this.getLength();
        if (length > 0 && this.getCaretPosition() < length) {
            if (this.charIterator == null) {
                this.charIterator = BreakIterator.getCharacterInstance();
            }
            this.charIterator.setText(this.getText());
            this.selectRange(this.getAnchor(), this.charIterator.following(this.getCaretPosition()));
        }
    }
    
    public void previousWord() {
        this.previousWord(false);
    }
    
    public void nextWord() {
        this.nextWord(false);
    }
    
    public void endOfNextWord() {
        this.endOfNextWord(false);
    }
    
    public void selectPreviousWord() {
        this.previousWord(true);
    }
    
    public void selectNextWord() {
        this.nextWord(true);
    }
    
    public void selectEndOfNextWord() {
        this.endOfNextWord(true);
    }
    
    private void previousWord(final boolean b) {
        final int length = this.getLength();
        final String text = this.getText();
        if (length <= 0) {
            return;
        }
        if (this.wordIterator == null) {
            this.wordIterator = BreakIterator.getWordInstance();
        }
        this.wordIterator.setText(text);
        int n;
        for (n = this.wordIterator.preceding(Utils.clamp(0, this.getCaretPosition(), length)); n != -1 && !Character.isLetterOrDigit(text.charAt(Utils.clamp(0, n, length - 1))); n = this.wordIterator.preceding(Utils.clamp(0, n, length))) {}
        this.selectRange(b ? this.getAnchor() : n, n);
    }
    
    private void nextWord(final boolean b) {
        final int length = this.getLength();
        final String text = this.getText();
        if (length <= 0) {
            return;
        }
        if (this.wordIterator == null) {
            this.wordIterator = BreakIterator.getWordInstance();
        }
        this.wordIterator.setText(text);
        int following = this.wordIterator.following(Utils.clamp(0, this.getCaretPosition(), length - 1));
        for (int i = this.wordIterator.next(); i != -1; i = this.wordIterator.next()) {
            for (int j = following; j <= i; ++j) {
                final char char1 = text.charAt(Utils.clamp(0, j, length - 1));
                if (char1 != ' ' && char1 != '\t') {
                    if (b) {
                        this.selectRange(this.getAnchor(), j);
                    }
                    else {
                        this.selectRange(j, j);
                    }
                    return;
                }
            }
            following = i;
        }
        if (b) {
            this.selectRange(this.getAnchor(), length);
        }
        else {
            this.end();
        }
    }
    
    private void endOfNextWord(final boolean b) {
        final int length = this.getLength();
        final String text = this.getText();
        if (length <= 0) {
            return;
        }
        if (this.wordIterator == null) {
            this.wordIterator = BreakIterator.getWordInstance();
        }
        this.wordIterator.setText(text);
        int following = this.wordIterator.following(Utils.clamp(0, this.getCaretPosition(), length));
        for (int i = this.wordIterator.next(); i != -1; i = this.wordIterator.next()) {
            for (int j = following; j <= i; ++j) {
                if (!Character.isLetterOrDigit(text.charAt(Utils.clamp(0, j, length - 1)))) {
                    if (b) {
                        this.selectRange(this.getAnchor(), j);
                    }
                    else {
                        this.selectRange(j, j);
                    }
                    return;
                }
            }
            following = i;
        }
        if (b) {
            this.selectRange(this.getAnchor(), length);
        }
        else {
            this.end();
        }
    }
    
    public void selectAll() {
        this.selectRange(0, this.getLength());
    }
    
    public void home() {
        this.selectRange(0, 0);
    }
    
    public void end() {
        final int length = this.getLength();
        if (length > 0) {
            this.selectRange(length, length);
        }
    }
    
    public void selectHome() {
        this.selectRange(this.getAnchor(), 0);
    }
    
    public void selectEnd() {
        final int length = this.getLength();
        if (length > 0) {
            this.selectRange(this.getAnchor(), length);
        }
    }
    
    public boolean deletePreviousChar() {
        boolean b = true;
        if (this.isEditable() && !this.isDisabled()) {
            final String text = this.getText();
            final int caretPosition = this.getCaretPosition();
            if (caretPosition != this.getAnchor()) {
                this.replaceSelection("");
                b = false;
            }
            else if (caretPosition > 0) {
                this.deleteText(Character.offsetByCodePoints(text, caretPosition, -1), caretPosition);
                b = false;
            }
        }
        return !b;
    }
    
    public boolean deleteNextChar() {
        boolean b = true;
        if (this.isEditable() && !this.isDisabled()) {
            final int length = this.getLength();
            final String text = this.getText();
            final int caretPosition = this.getCaretPosition();
            if (caretPosition != this.getAnchor()) {
                this.replaceSelection("");
                b = false;
            }
            else if (length > 0 && caretPosition < length) {
                if (this.charIterator == null) {
                    this.charIterator = BreakIterator.getCharacterInstance();
                }
                this.charIterator.setText(text);
                this.deleteText(caretPosition, this.charIterator.following(caretPosition));
                b = false;
            }
        }
        return !b;
    }
    
    public void forward() {
        final int length = this.getLength();
        final int caretPosition = this.getCaretPosition();
        final int anchor = this.getAnchor();
        if (caretPosition != anchor) {
            final int max = Math.max(caretPosition, anchor);
            this.selectRange(max, max);
        }
        else if (caretPosition < length && length > 0) {
            if (this.charIterator == null) {
                this.charIterator = BreakIterator.getCharacterInstance();
            }
            this.charIterator.setText(this.getText());
            final int following = this.charIterator.following(caretPosition);
            this.selectRange(following, following);
        }
        this.deselect();
    }
    
    public void backward() {
        final int length = this.getLength();
        final int caretPosition = this.getCaretPosition();
        final int anchor = this.getAnchor();
        if (caretPosition != anchor) {
            final int min = Math.min(caretPosition, anchor);
            this.selectRange(min, min);
        }
        else if (caretPosition > 0 && length > 0) {
            if (this.charIterator == null) {
                this.charIterator = BreakIterator.getCharacterInstance();
            }
            this.charIterator.setText(this.getText());
            final int preceding = this.charIterator.preceding(caretPosition);
            this.selectRange(preceding, preceding);
        }
        this.deselect();
    }
    
    public void positionCaret(final int n) {
        final int clamp = Utils.clamp(0, n, this.getLength());
        this.selectRange(clamp, clamp);
    }
    
    public void selectPositionCaret(final int n) {
        this.selectRange(this.getAnchor(), Utils.clamp(0, n, this.getLength()));
    }
    
    public void selectRange(int clamp, int clamp2) {
        clamp2 = Utils.clamp(0, clamp2, this.getLength());
        clamp = Utils.clamp(0, clamp, this.getLength());
        TextFormatter.Change change = new TextFormatter.Change(this, this.getFormatterAccessor(), clamp, clamp2);
        final TextFormatter<?> textFormatter = this.getTextFormatter();
        if (textFormatter != null && textFormatter.getFilter() != null) {
            change = (TextFormatter.Change)textFormatter.getFilter().apply(change);
            if (change == null) {
                return;
            }
        }
        this.updateContent(change, false);
    }
    
    private void doSelectRange(final int n, final int n2) {
        this.caretPosition.set(Utils.clamp(0, n2, this.getLength()));
        this.anchor.set(Utils.clamp(0, n, this.getLength()));
        this.selection.set(IndexRange.normalize(this.getAnchor(), this.getCaretPosition()));
        this.notifyAccessibleAttributeChanged(AccessibleAttribute.SELECTION_START);
    }
    
    public void extendSelection(final int n) {
        final int clamp = Utils.clamp(0, n, this.getLength());
        final int caretPosition = this.getCaretPosition();
        final int anchor = this.getAnchor();
        final int min = Math.min(caretPosition, anchor);
        final int max = Math.max(caretPosition, anchor);
        if (clamp < min) {
            this.selectRange(max, clamp);
        }
        else {
            this.selectRange(min, clamp);
        }
    }
    
    public void clear() {
        this.deselect();
        if (!this.text.isBound()) {
            this.setText("");
        }
    }
    
    public void deselect() {
        this.selectRange(this.getCaretPosition(), this.getCaretPosition());
    }
    
    public void replaceSelection(final String s) {
        this.replaceText(this.getSelection(), s);
    }
    
    public final void undo() {
        if (this.isUndoable()) {
            final int start = this.undoChange.start;
            final String newText = this.undoChange.newText;
            final String oldText = this.undoChange.oldText;
            if (newText != null) {
                this.getContent().delete(start, start + newText.length(), oldText.isEmpty());
            }
            if (oldText != null) {
                this.getContent().insert(start, oldText, true);
                this.doSelectRange(start, start + oldText.length());
            }
            else {
                this.doSelectRange(start, start + newText.length());
            }
            this.undoChange = this.undoChange.prev;
        }
        this.updateUndoRedoState();
    }
    
    public final void redo() {
        if (this.isRedoable()) {
            this.undoChange = this.undoChange.next;
            final int start = this.undoChange.start;
            final String newText = this.undoChange.newText;
            final String oldText = this.undoChange.oldText;
            if (oldText != null) {
                this.getContent().delete(start, start + oldText.length(), newText.isEmpty());
            }
            if (newText != null) {
                this.getContent().insert(start, newText, true);
                this.doSelectRange(start + newText.length(), start + newText.length());
            }
            else {
                this.doSelectRange(start, start);
            }
        }
        this.updateUndoRedoState();
    }
    
    void textUpdated() {
    }
    
    private void resetUndoRedoState() {
        this.undoChange = this.undoChangeHead;
        this.undoChange.next = null;
        this.updateUndoRedoState();
    }
    
    private void updateUndoRedoState() {
        this.undoable.set(this.undoChange != this.undoChangeHead);
        this.redoable.set(this.undoChange.next != null);
    }
    
    private boolean filterAndSet(final String s) {
        final TextFormatter<?> textFormatter = this.getTextFormatter();
        final int length = this.content.length();
        if (textFormatter != null && textFormatter.getFilter() != null && !this.text.isBound()) {
            final TextFormatter.Change change = textFormatter.getFilter().apply(new TextFormatter.Change(this, this.getFormatterAccessor(), 0, length, s, 0, 0));
            if (change == null) {
                return false;
            }
            this.replaceText(change.start, change.end, change.text, change.getAnchor(), change.getCaretPosition());
        }
        else {
            this.replaceText(0, length, s, 0, 0);
        }
        return true;
    }
    
    private int replaceText(final int n, final int n2, final String s, int n3, int n4) {
        int length = this.getLength();
        int n5 = 0;
        if (n2 != n) {
            this.getContent().delete(n, n2, s.isEmpty());
            length -= n2 - n;
        }
        if (s != null) {
            this.getContent().insert(n, s, true);
            n5 = s.length() - (this.getLength() - length);
            n3 -= n5;
            n4 -= n5;
        }
        this.doSelectRange(n3, n4);
        return n5;
    }
    
    private <T> void updateText(final TextFormatter<T> textFormatter) {
        final T value = textFormatter.getValue();
        final StringConverter<T> valueConverter = textFormatter.getValueConverter();
        if (valueConverter != null) {
            String string = valueConverter.toString(value);
            if (string == null) {
                string = "";
            }
            this.replaceText(0, this.getLength(), string, string.length(), string.length());
        }
    }
    
    public final void commitValue() {
        if (this.getTextFormatter() != null) {
            this.getTextFormatter().updateValue(this.getText());
        }
    }
    
    public final void cancelEdit() {
        if (this.getTextFormatter() != null) {
            this.updateText(this.getTextFormatter());
        }
    }
    
    private FormatterAccessor getFormatterAccessor() {
        if (this.accessor == null) {
            this.accessor = new TextInputControlFromatterAccessor();
        }
        return this.accessor;
    }
    
    static String filterInput(String string, final boolean b, final boolean b2) {
        if (containsInvalidCharacters(string, b, b2)) {
            final StringBuilder sb = new StringBuilder(string.length());
            for (int i = 0; i < string.length(); ++i) {
                final char char1 = string.charAt(i);
                if (!isInvalidCharacter(char1, b, b2)) {
                    sb.append(char1);
                }
            }
            string = sb.toString();
        }
        return string;
    }
    
    static boolean containsInvalidCharacters(final String s, final boolean b, final boolean b2) {
        for (int i = 0; i < s.length(); ++i) {
            if (isInvalidCharacter(s.charAt(i), b, b2)) {
                return true;
            }
        }
        return false;
    }
    
    private static boolean isInvalidCharacter(final char c, final boolean b, final boolean b2) {
        if (c == '\u007f') {
            return true;
        }
        if (c == '\n') {
            return b;
        }
        if (c == '\t') {
            return b2;
        }
        return c < ' ';
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case TEXT: {
                final String accessibleText = this.getAccessibleText();
                if (accessibleText != null && !accessibleText.isEmpty()) {
                    return accessibleText;
                }
                String s = this.getText();
                if (s == null || s.isEmpty()) {
                    s = this.getPromptText();
                }
                return s;
            }
            case EDITABLE: {
                return this.isEditable();
            }
            case SELECTION_START: {
                return this.getSelection().getStart();
            }
            case SELECTION_END: {
                return this.getSelection().getEnd();
            }
            case CARET_OFFSET: {
                return this.getCaretPosition();
            }
            case FONT: {
                return this.getFont();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case SET_TEXT: {
                final String text = (String)array[0];
                if (text != null) {
                    this.setText(text);
                    break;
                }
                break;
            }
            case SET_TEXT_SELECTION: {
                final Integer n = (Integer)array[0];
                final Integer n2 = (Integer)array[1];
                if (n != null && n2 != null) {
                    this.selectRange(n, n2);
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    static {
        PSEUDO_CLASS_READONLY = PseudoClass.getPseudoClass("readonly");
    }
    
    private class TextProperty extends StringProperty
    {
        private ObservableValue<? extends String> observable;
        private InvalidationListener listener;
        private ExpressionHelper<String> helper;
        private boolean textIsNull;
        
        private TextProperty() {
            this.observable = null;
            this.listener = null;
            this.helper = null;
            this.textIsNull = false;
        }
        
        @Override
        public String get() {
            return this.textIsNull ? null : TextInputControl.this.content.get();
        }
        
        @Override
        public void set(final String s) {
            if (this.isBound()) {
                throw new RuntimeException("A bound value cannot be set.");
            }
            this.doSet(s);
            this.markInvalid();
        }
        
        private void controlContentHasChanged() {
            this.markInvalid();
            TextInputControl.this.notifyAccessibleAttributeChanged(AccessibleAttribute.TEXT);
        }
        
        @Override
        public void bind(final ObservableValue<? extends String> observable) {
            if (observable == null) {
                throw new NullPointerException("Cannot bind to null");
            }
            if (!observable.equals(this.observable)) {
                this.unbind();
                this.observable = observable;
                if (this.listener == null) {
                    this.listener = new Listener();
                }
                this.observable.addListener(this.listener);
                this.markInvalid();
                this.doSet((String)observable.getValue());
            }
        }
        
        @Override
        public void unbind() {
            if (this.observable != null) {
                this.doSet((String)this.observable.getValue());
                this.observable.removeListener(this.listener);
                this.observable = null;
            }
        }
        
        @Override
        public boolean isBound() {
            return this.observable != null;
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, invalidationListener);
        }
        
        @Override
        public void addListener(final ChangeListener<? super String> changeListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, changeListener);
        }
        
        @Override
        public void removeListener(final ChangeListener<? super String> changeListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, changeListener);
        }
        
        @Override
        public Object getBean() {
            return TextInputControl.this;
        }
        
        @Override
        public String getName() {
            return "text";
        }
        
        private void fireValueChangedEvent() {
            ExpressionHelper.fireValueChangedEvent(this.helper);
        }
        
        private void markInvalid() {
            this.fireValueChangedEvent();
        }
        
        private void doSet(String s) {
            this.textIsNull = (s == null);
            if (s == null) {
                s = "";
            }
            if (!TextInputControl.this.filterAndSet(s)) {
                return;
            }
            if (TextInputControl.this.getTextFormatter() != null) {
                TextInputControl.this.getTextFormatter().updateValue(TextInputControl.this.getText());
            }
            TextInputControl.this.textUpdated();
            TextInputControl.this.resetUndoRedoState();
        }
        
        private class Listener implements InvalidationListener
        {
            @Override
            public void invalidated(final Observable observable) {
                TextProperty.this.doSet(TextProperty.this.observable.getValue());
            }
        }
    }
    
    static class UndoRedoChange
    {
        static long prevRecordTime;
        static final long CHANGE_DURATION = 2500L;
        static boolean spaceCharSequence;
        int start;
        String oldText;
        String newText;
        UndoRedoChange prev;
        UndoRedoChange next;
        
        public UndoRedoChange add(final int start, final String oldText, final String newText) {
            final UndoRedoChange next = new UndoRedoChange();
            next.start = start;
            next.oldText = oldText;
            next.newText = newText;
            next.prev = this;
            this.next = next;
            UndoRedoChange.prevRecordTime = System.currentTimeMillis();
            return next;
        }
        
        static boolean hasChangeDurationElapsed() {
            return System.currentTimeMillis() - UndoRedoChange.prevRecordTime > 2500L;
        }
        
        static void setSpaceCharSequence(final boolean spaceCharSequence) {
            UndoRedoChange.spaceCharSequence = spaceCharSequence;
        }
        
        static boolean isSpaceCharSequence() {
            return UndoRedoChange.spaceCharSequence;
        }
        
        public UndoRedoChange discard() {
            this.prev.next = this.next;
            return this.prev;
        }
        
        void debugPrint() {
            UndoRedoChange next = this;
            System.out.print("[");
            while (next != null) {
                System.out.print(next.toString());
                if (next.next != null) {
                    System.out.print(", ");
                }
                next = next.next;
            }
            System.out.println("]");
        }
        
        @Override
        public String toString() {
            if (this.oldText == null && this.newText == null) {
                return "head";
            }
            if (this.oldText.isEmpty() && !this.newText.isEmpty()) {
                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;I)Ljava/lang/String;, this.newText, this.start);
            }
            if (!this.oldText.isEmpty() && !this.newText.isEmpty()) {
                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;, this.oldText, this.newText, this.start);
            }
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;I)Ljava/lang/String;, this.oldText, this.start);
        }
        
        static {
            UndoRedoChange.spaceCharSequence = false;
        }
    }
    
    private static class StyleableProperties
    {
        private static final FontCssMetaData<TextInputControl> FONT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            FONT = new FontCssMetaData<TextInputControl>(Font.getDefault()) {
                public boolean isSettable(final TextInputControl textInputControl) {
                    return textInputControl.font == null || !textInputControl.font.isBound();
                }
                
                public StyleableProperty<Font> getStyleableProperty(final TextInputControl textInputControl) {
                    return (StyleableProperty<Font>)(StyleableProperty)textInputControl.fontProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.FONT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    private class TextInputControlFromatterAccessor implements FormatterAccessor
    {
        @Override
        public int getTextLength() {
            return TextInputControl.this.getLength();
        }
        
        @Override
        public String getText(final int n, final int n2) {
            return TextInputControl.this.getText(n, n2);
        }
        
        @Override
        public int getCaret() {
            return TextInputControl.this.getCaretPosition();
        }
        
        @Override
        public int getAnchor() {
            return TextInputControl.this.getAnchor();
        }
    }
    
    protected interface Content extends ObservableStringValue
    {
        String get(final int p0, final int p1);
        
        void insert(final int p0, final String p1, final boolean p2);
        
        void delete(final int p0, final int p1, final boolean p2);
        
        int length();
    }
}
