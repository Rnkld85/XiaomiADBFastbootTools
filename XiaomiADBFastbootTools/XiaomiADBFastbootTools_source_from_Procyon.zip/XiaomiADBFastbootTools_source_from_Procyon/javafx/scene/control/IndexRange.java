// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.NamedArg;

public final class IndexRange
{
    private int start;
    private int end;
    public static final String VALUE_DELIMITER = ",";
    
    public IndexRange(@NamedArg("start") final int start, @NamedArg("end") final int end) {
        if (end < start) {
            throw new IllegalArgumentException();
        }
        this.start = start;
        this.end = end;
    }
    
    public IndexRange(@NamedArg("range") final IndexRange indexRange) {
        this.start = indexRange.start;
        this.end = indexRange.end;
    }
    
    public int getStart() {
        return this.start;
    }
    
    public int getEnd() {
        return this.end;
    }
    
    public int getLength() {
        return this.end - this.start;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof IndexRange) {
            final IndexRange indexRange = (IndexRange)o;
            return this.start == indexRange.start && this.end == indexRange.end;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return 31 * this.start + this.end;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, this.start, this.end);
    }
    
    public static IndexRange normalize(final int n, final int n2) {
        return new IndexRange(Math.min(n, n2), Math.max(n, n2));
    }
    
    public static IndexRange valueOf(final String s) {
        if (s == null) {
            throw new IllegalArgumentException();
        }
        final String[] split = s.split(",");
        if (split.length != 2) {
            throw new IllegalArgumentException();
        }
        return normalize(Integer.parseInt(split[0].trim()), Integer.parseInt(split[1].trim()));
    }
}
