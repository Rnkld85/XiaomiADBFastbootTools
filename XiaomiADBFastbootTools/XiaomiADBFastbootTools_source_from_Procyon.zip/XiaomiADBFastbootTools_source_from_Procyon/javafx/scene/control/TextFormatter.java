// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import com.sun.javafx.scene.control.FormatterAccessor;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.NamedArg;
import javafx.beans.property.ObjectProperty;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import javafx.util.StringConverter;

public class TextFormatter<V>
{
    private final StringConverter<V> valueConverter;
    private final UnaryOperator<Change> filter;
    private Consumer<TextFormatter<?>> textUpdater;
    public static final StringConverter<String> IDENTITY_STRING_CONVERTER;
    private final ObjectProperty<V> value;
    
    public TextFormatter(@NamedArg("filter") final UnaryOperator<Change> unaryOperator) {
        this(null, null, unaryOperator);
    }
    
    public TextFormatter(@NamedArg("valueConverter") final StringConverter<V> valueConverter, @NamedArg("defaultValue") final V value, @NamedArg("filter") final UnaryOperator<Change> filter) {
        this.value = new ObjectPropertyBase<V>() {
            @Override
            public Object getBean() {
                return TextFormatter.this;
            }
            
            @Override
            public String getName() {
                return "value";
            }
            
            @Override
            protected void invalidated() {
                if (TextFormatter.this.valueConverter == null && this.get() != null) {
                    if (this.isBound()) {
                        this.unbind();
                    }
                    throw new IllegalStateException("Value changes are not supported when valueConverter is not set");
                }
                TextFormatter.this.updateText();
            }
        };
        this.filter = filter;
        this.valueConverter = valueConverter;
        this.setValue(value);
    }
    
    public TextFormatter(@NamedArg("valueConverter") final StringConverter<V> stringConverter, @NamedArg("defaultValue") final V v) {
        this((StringConverter<Object>)stringConverter, v, null);
    }
    
    public TextFormatter(@NamedArg("valueConverter") final StringConverter<V> stringConverter) {
        this((StringConverter<Object>)stringConverter, null, null);
    }
    
    public final StringConverter<V> getValueConverter() {
        return this.valueConverter;
    }
    
    public final UnaryOperator<Change> getFilter() {
        return this.filter;
    }
    
    public final ObjectProperty<V> valueProperty() {
        return this.value;
    }
    
    public final void setValue(final V v) {
        if (this.valueConverter == null && v != null) {
            throw new IllegalStateException("Value changes are not supported when valueConverter is not set");
        }
        this.value.set(v);
    }
    
    public final V getValue() {
        return this.value.get();
    }
    
    private void updateText() {
        if (this.textUpdater != null) {
            this.textUpdater.accept(this);
        }
    }
    
    void bindToControl(final Consumer<TextFormatter<?>> textUpdater) {
        if (this.textUpdater != null) {
            throw new IllegalStateException("Formatter is already used in other control");
        }
        this.textUpdater = textUpdater;
    }
    
    void unbindFromControl() {
        this.textUpdater = null;
    }
    
    void updateValue(final String s) {
        if (!this.value.isBound()) {
            try {
                this.setValue(this.valueConverter.fromString(s));
            }
            catch (Exception ex) {
                this.updateText();
            }
        }
    }
    
    static {
        IDENTITY_STRING_CONVERTER = new StringConverter<String>() {
            @Override
            public String toString(final String s) {
                return (s == null) ? "" : s;
            }
            
            @Override
            public String fromString(final String s) {
                return s;
            }
        };
    }
    
    public static final class Change implements Cloneable
    {
        private final FormatterAccessor accessor;
        private Control control;
        int start;
        int end;
        String text;
        int anchor;
        int caret;
        
        Change(final Control control, final FormatterAccessor formatterAccessor, final int n, final int n2) {
            this(control, formatterAccessor, n2, n2, "", n, n2);
        }
        
        Change(final Control control, final FormatterAccessor formatterAccessor, final int n, final int n2, final String s) {
            this(control, formatterAccessor, n, n2, s, n + s.length(), n + s.length());
        }
        
        Change(final Control control, final FormatterAccessor accessor, final int start, final int end, final String text, final int anchor, final int caret) {
            this.control = control;
            this.accessor = accessor;
            this.start = start;
            this.end = end;
            this.text = text;
            this.anchor = anchor;
            this.caret = caret;
        }
        
        public final Control getControl() {
            return this.control;
        }
        
        public final int getRangeStart() {
            return this.start;
        }
        
        public final int getRangeEnd() {
            return this.end;
        }
        
        public final void setRange(final int start, final int end) {
            final int textLength = this.accessor.getTextLength();
            if (start < 0 || start > textLength || end < 0 || end > textLength) {
                throw new IndexOutOfBoundsException();
            }
            this.start = start;
            this.end = end;
        }
        
        public final int getCaretPosition() {
            return this.caret;
        }
        
        public final int getAnchor() {
            return this.anchor;
        }
        
        public final int getControlCaretPosition() {
            return this.accessor.getCaret();
        }
        
        public final int getControlAnchor() {
            return this.accessor.getAnchor();
        }
        
        public final void selectRange(final int anchor, final int caret) {
            if (anchor < 0 || anchor > this.accessor.getTextLength() - (this.end - this.start) + this.text.length() || caret < 0 || caret > this.accessor.getTextLength() - (this.end - this.start) + this.text.length()) {
                throw new IndexOutOfBoundsException();
            }
            this.anchor = anchor;
            this.caret = caret;
        }
        
        public final IndexRange getSelection() {
            return IndexRange.normalize(this.anchor, this.caret);
        }
        
        public final void setAnchor(final int anchor) {
            if (anchor < 0 || anchor > this.accessor.getTextLength() - (this.end - this.start) + this.text.length()) {
                throw new IndexOutOfBoundsException();
            }
            this.anchor = anchor;
        }
        
        public final void setCaretPosition(final int caret) {
            if (caret < 0 || caret > this.accessor.getTextLength() - (this.end - this.start) + this.text.length()) {
                throw new IndexOutOfBoundsException();
            }
            this.caret = caret;
        }
        
        public final String getText() {
            return this.text;
        }
        
        public final void setText(final String text) {
            if (text == null) {
                throw new NullPointerException();
            }
            this.text = text;
        }
        
        public final String getControlText() {
            return this.accessor.getText(0, this.accessor.getTextLength());
        }
        
        public final String getControlNewText() {
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, this.accessor.getText(0, this.start), this.text, this.accessor.getText(this.end, this.accessor.getTextLength()));
        }
        
        public final boolean isAdded() {
            return !this.text.isEmpty();
        }
        
        public final boolean isDeleted() {
            return this.start != this.end;
        }
        
        public final boolean isReplaced() {
            return this.isAdded() && this.isDeleted();
        }
        
        public final boolean isContentChange() {
            return this.isAdded() || this.isDeleted();
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("TextInputControl.Change [");
            if (this.isReplaced()) {
                sb.append(" replaced \"").append(this.accessor.getText(this.start, this.end)).append("\" with \"").append(this.text).append("\" at (").append(this.start).append(", ").append(this.end).append(")");
            }
            else if (this.isDeleted()) {
                sb.append(" deleted \"").append(this.accessor.getText(this.start, this.end)).append("\" at (").append(this.start).append(", ").append(this.end).append(")");
            }
            else if (this.isAdded()) {
                sb.append(" added \"").append(this.text).append("\" at ").append(this.start);
            }
            if (this.isAdded() || this.isDeleted()) {
                sb.append("; ");
            }
            else {
                sb.append(" ");
            }
            sb.append("new selection (anchor, caret): [").append(this.anchor).append(", ").append(this.caret).append("]");
            sb.append(" ]");
            return sb.toString();
        }
        
        public Change clone() {
            try {
                return (Change)super.clone();
            }
            catch (CloneNotSupportedException cause) {
                throw new RuntimeException(cause);
            }
        }
    }
}
