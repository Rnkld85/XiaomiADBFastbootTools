// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.control.skin.CheckBoxSkin;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.AccessibleAttribute;
import javafx.beans.property.BooleanPropertyBase;
import javafx.geometry.Pos;
import javafx.scene.AccessibleRole;
import javafx.css.PseudoClass;
import javafx.beans.property.BooleanProperty;

public class CheckBox extends ButtonBase
{
    private BooleanProperty indeterminate;
    private BooleanProperty selected;
    private BooleanProperty allowIndeterminate;
    private static final String DEFAULT_STYLE_CLASS = "check-box";
    private static final PseudoClass PSEUDO_CLASS_DETERMINATE;
    private static final PseudoClass PSEUDO_CLASS_INDETERMINATE;
    private static final PseudoClass PSEUDO_CLASS_SELECTED;
    
    public CheckBox() {
        this.initialize();
    }
    
    public CheckBox(final String text) {
        this.setText(text);
        this.initialize();
    }
    
    private void initialize() {
        this.getStyleClass().setAll("check-box");
        this.setAccessibleRole(AccessibleRole.CHECK_BOX);
        this.setAlignment(Pos.CENTER_LEFT);
        this.setMnemonicParsing(true);
        this.pseudoClassStateChanged(CheckBox.PSEUDO_CLASS_DETERMINATE, true);
    }
    
    public final void setIndeterminate(final boolean b) {
        this.indeterminateProperty().set(b);
    }
    
    public final boolean isIndeterminate() {
        return this.indeterminate != null && this.indeterminate.get();
    }
    
    public final BooleanProperty indeterminateProperty() {
        if (this.indeterminate == null) {
            this.indeterminate = new BooleanPropertyBase(false) {
                @Override
                protected void invalidated() {
                    final boolean value = this.get();
                    CheckBox.this.pseudoClassStateChanged(CheckBox.PSEUDO_CLASS_DETERMINATE, !value);
                    CheckBox.this.pseudoClassStateChanged(CheckBox.PSEUDO_CLASS_INDETERMINATE, value);
                    CheckBox.this.notifyAccessibleAttributeChanged(AccessibleAttribute.INDETERMINATE);
                }
                
                @Override
                public Object getBean() {
                    return CheckBox.this;
                }
                
                @Override
                public String getName() {
                    return "indeterminate";
                }
            };
        }
        return this.indeterminate;
    }
    
    public final void setSelected(final boolean b) {
        this.selectedProperty().set(b);
    }
    
    public final boolean isSelected() {
        return this.selected != null && this.selected.get();
    }
    
    public final BooleanProperty selectedProperty() {
        if (this.selected == null) {
            this.selected = new BooleanPropertyBase() {
                @Override
                protected void invalidated() {
                    CheckBox.this.pseudoClassStateChanged(CheckBox.PSEUDO_CLASS_SELECTED, (boolean)this.get());
                    CheckBox.this.notifyAccessibleAttributeChanged(AccessibleAttribute.SELECTED);
                }
                
                @Override
                public Object getBean() {
                    return CheckBox.this;
                }
                
                @Override
                public String getName() {
                    return "selected";
                }
            };
        }
        return this.selected;
    }
    
    public final void setAllowIndeterminate(final boolean b) {
        this.allowIndeterminateProperty().set(b);
    }
    
    public final boolean isAllowIndeterminate() {
        return this.allowIndeterminate != null && this.allowIndeterminate.get();
    }
    
    public final BooleanProperty allowIndeterminateProperty() {
        if (this.allowIndeterminate == null) {
            this.allowIndeterminate = new SimpleBooleanProperty(this, "allowIndeterminate");
        }
        return this.allowIndeterminate;
    }
    
    @Override
    public void fire() {
        if (!this.isDisabled()) {
            if (this.isAllowIndeterminate()) {
                if (!this.isSelected() && !this.isIndeterminate()) {
                    this.setIndeterminate(true);
                }
                else if (this.isSelected() && !this.isIndeterminate()) {
                    this.setSelected(false);
                }
                else if (this.isIndeterminate()) {
                    this.setSelected(true);
                    this.setIndeterminate(false);
                }
            }
            else {
                this.setSelected(!this.isSelected());
                this.setIndeterminate(false);
            }
            this.fireEvent(new ActionEvent());
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new CheckBoxSkin(this);
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case SELECTED: {
                return this.isSelected();
            }
            case INDETERMINATE: {
                return this.isIndeterminate();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        PSEUDO_CLASS_DETERMINATE = PseudoClass.getPseudoClass("determinate");
        PSEUDO_CLASS_INDETERMINATE = PseudoClass.getPseudoClass("indeterminate");
        PSEUDO_CLASS_SELECTED = PseudoClass.getPseudoClass("selected");
    }
}
