// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.BooleanProperty;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;

public class CustomMenuItem extends MenuItem
{
    private ObjectProperty<Node> content;
    private BooleanProperty hideOnClick;
    private static final String DEFAULT_STYLE_CLASS = "custom-menu-item";
    
    public CustomMenuItem() {
        this(null, true);
    }
    
    public CustomMenuItem(final Node node) {
        this(node, true);
    }
    
    public CustomMenuItem(final Node content, final boolean hideOnClick) {
        this.getStyleClass().add("custom-menu-item");
        this.setContent(content);
        this.setHideOnClick(hideOnClick);
    }
    
    public final void setContent(final Node node) {
        this.contentProperty().set(node);
    }
    
    public final Node getContent() {
        return (this.content == null) ? null : this.content.get();
    }
    
    public final ObjectProperty<Node> contentProperty() {
        if (this.content == null) {
            this.content = new SimpleObjectProperty<Node>(this, "content");
        }
        return this.content;
    }
    
    public final void setHideOnClick(final boolean b) {
        this.hideOnClickProperty().set(b);
    }
    
    public final boolean isHideOnClick() {
        return this.hideOnClick == null || this.hideOnClick.get();
    }
    
    public final BooleanProperty hideOnClickProperty() {
        if (this.hideOnClick == null) {
            this.hideOnClick = new SimpleBooleanProperty(this, "hideOnClick", true);
        }
        return this.hideOnClick;
    }
}
