// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.WeakInvalidationListener;
import java.lang.ref.WeakReference;
import javafx.collections.WeakListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;
import javafx.beans.Observable;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.skin.ComboBoxListViewSkin;
import com.sun.javafx.scene.control.FakeFocusTextField;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.AccessibleRole;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.beans.value.ChangeListener;
import javafx.scene.Node;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.IntegerProperty;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;

public class ComboBox<T> extends ComboBoxBase<T>
{
    private ObjectProperty<ObservableList<T>> items;
    private ObjectProperty<StringConverter<T>> converter;
    private ObjectProperty<Callback<ListView<T>, ListCell<T>>> cellFactory;
    private ObjectProperty<ListCell<T>> buttonCell;
    private ObjectProperty<SingleSelectionModel<T>> selectionModel;
    private IntegerProperty visibleRowCount;
    private TextField textField;
    private ReadOnlyObjectWrapper<TextField> editor;
    private ObjectProperty<Node> placeholder;
    private ChangeListener<T> selectedItemListener;
    private static final String DEFAULT_STYLE_CLASS = "combo-box";
    private boolean wasSetAllCalled;
    private int previousItemCount;
    
    private static <T> StringConverter<T> defaultStringConverter() {
        return new StringConverter<T>() {
            @Override
            public String toString(final T t) {
                return (t == null) ? null : t.toString();
            }
            
            @Override
            public T fromString(final String s) {
                return (T)s;
            }
        };
    }
    
    public ComboBox() {
        this(FXCollections.observableArrayList());
    }
    
    public ComboBox(final ObservableList<T> items) {
        this.items = new SimpleObjectProperty<ObservableList<T>>(this, "items");
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter", defaultStringConverter());
        this.cellFactory = new SimpleObjectProperty<Callback<ListView<T>, ListCell<T>>>(this, "cellFactory");
        this.buttonCell = new SimpleObjectProperty<ListCell<T>>(this, "buttonCell");
        this.selectionModel = new SimpleObjectProperty<SingleSelectionModel<T>>((Object)this, "selectionModel") {
            private SingleSelectionModel<T> oldSM = null;
            
            @Override
            protected void invalidated() {
                if (this.oldSM != null) {
                    this.oldSM.selectedItemProperty().removeListener(ComboBox.this.selectedItemListener);
                }
                final SingleSelectionModel<Object> oldSM = ((ObjectPropertyBase<SingleSelectionModel<Object>>)this).get();
                if ((this.oldSM = (SingleSelectionModel<T>)oldSM) != null) {
                    oldSM.selectedItemProperty().addListener(ComboBox.this.selectedItemListener);
                }
            }
        };
        this.visibleRowCount = new SimpleIntegerProperty(this, "visibleRowCount", 10);
        this.selectedItemListener = new ChangeListener<T>() {
            @Override
            public void changed(final ObservableValue<? extends T> observableValue, final T t, final T t2) {
                if (!ComboBox.this.wasSetAllCalled || t2 != null) {
                    ComboBox.this.updateValue(t2);
                }
                ComboBox.this.wasSetAllCalled = false;
            }
        };
        this.wasSetAllCalled = false;
        this.previousItemCount = -1;
        this.getStyleClass().add("combo-box");
        this.setAccessibleRole(AccessibleRole.COMBO_BOX);
        this.setItems(items);
        this.setSelectionModel(new ComboBoxSelectionModel<T>(this));
        final int n;
        final SelectionModel<Object> selectionModel;
        Runnable runnable;
        final ComboBoxSelectionModel<Object> comboBoxSelectionModel;
        final Object o;
        this.valueProperty().addListener((p0, p1, selectedItem) -> {
            if (this.getItems() == null) {
                return;
            }
            else {
                this.getSelectionModel();
                this.getItems().indexOf(selectedItem);
                if (n == -1) {
                    runnable = (() -> {
                        selectionModel.setSelectedIndex(-1);
                        selectionModel.setSelectedItem(selectedItem);
                        return;
                    });
                    if (comboBoxSelectionModel instanceof ComboBoxSelectionModel) {
                        comboBoxSelectionModel.doAtomic(runnable);
                    }
                    else {
                        runnable.run();
                    }
                }
                else {
                    comboBoxSelectionModel.getSelectedItem();
                    if (o == null || !o.equals(this.getValue())) {
                        comboBoxSelectionModel.clearAndSelect(n);
                    }
                }
                return;
            }
        });
        this.editableProperty().addListener(p0 -> {
            if (!this.isEditable() && this.getItems() != null && !this.getItems().contains(this.getValue())) {
                this.getSelectionModel().clearSelection();
            }
            return;
        });
        this.focusedProperty().addListener(p0 -> {
            if (!this.isFocused()) {
                this.commitValue();
            }
        });
    }
    
    public final void setItems(final ObservableList<T> list) {
        this.itemsProperty().set(list);
    }
    
    public final ObservableList<T> getItems() {
        return this.items.get();
    }
    
    public ObjectProperty<ObservableList<T>> itemsProperty() {
        return this.items;
    }
    
    public ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    public final void setCellFactory(final Callback<ListView<T>, ListCell<T>> callback) {
        this.cellFactoryProperty().set(callback);
    }
    
    public final Callback<ListView<T>, ListCell<T>> getCellFactory() {
        return this.cellFactoryProperty().get();
    }
    
    public ObjectProperty<Callback<ListView<T>, ListCell<T>>> cellFactoryProperty() {
        return this.cellFactory;
    }
    
    public ObjectProperty<ListCell<T>> buttonCellProperty() {
        return this.buttonCell;
    }
    
    public final void setButtonCell(final ListCell<T> listCell) {
        this.buttonCellProperty().set(listCell);
    }
    
    public final ListCell<T> getButtonCell() {
        return this.buttonCellProperty().get();
    }
    
    public final void setSelectionModel(final SingleSelectionModel<T> singleSelectionModel) {
        this.selectionModel.set(singleSelectionModel);
    }
    
    public final SingleSelectionModel<T> getSelectionModel() {
        return this.selectionModel.get();
    }
    
    public final ObjectProperty<SingleSelectionModel<T>> selectionModelProperty() {
        return this.selectionModel;
    }
    
    public final void setVisibleRowCount(final int n) {
        this.visibleRowCount.set(n);
    }
    
    public final int getVisibleRowCount() {
        return this.visibleRowCount.get();
    }
    
    public final IntegerProperty visibleRowCountProperty() {
        return this.visibleRowCount;
    }
    
    public final TextField getEditor() {
        return this.editorProperty().get();
    }
    
    public final ReadOnlyObjectProperty<TextField> editorProperty() {
        if (this.editor == null) {
            this.editor = new ReadOnlyObjectWrapper<TextField>(this, "editor");
            this.textField = new FakeFocusTextField();
            this.editor.set(this.textField);
        }
        return this.editor.getReadOnlyProperty();
    }
    
    public final ObjectProperty<Node> placeholderProperty() {
        if (this.placeholder == null) {
            this.placeholder = new SimpleObjectProperty<Node>(this, "placeholder");
        }
        return this.placeholder;
    }
    
    public final void setPlaceholder(final Node node) {
        this.placeholderProperty().set(node);
    }
    
    public final Node getPlaceholder() {
        return (this.placeholder == null) ? null : this.placeholder.get();
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ComboBoxListViewSkin<Object>(this);
    }
    
    public final void commitValue() {
        if (!this.isEditable()) {
            return;
        }
        final String text = this.getEditor().getText();
        final StringConverter<T> converter = this.getConverter();
        if (converter != null) {
            this.setValue(converter.fromString(text));
        }
    }
    
    public final void cancelEdit() {
        if (!this.isEditable()) {
            return;
        }
        final Object value = this.getValue();
        final StringConverter<Object> converter = this.getConverter();
        if (converter != null) {
            this.getEditor().setText(converter.toString(value));
        }
    }
    
    private void updateValue(final T value) {
        if (!this.valueProperty().isBound()) {
            this.setValue(value);
        }
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case TEXT: {
                final String accessibleText = this.getAccessibleText();
                if (accessibleText != null && !accessibleText.isEmpty()) {
                    return accessibleText;
                }
                final Object queryAccessibleAttribute = super.queryAccessibleAttribute(accessibleAttribute, array);
                if (queryAccessibleAttribute != null) {
                    return queryAccessibleAttribute;
                }
                final StringConverter<Object> converter = this.getConverter();
                if (converter == null) {
                    return (this.getValue() != null) ? this.getValue().toString() : "";
                }
                return converter.toString(this.getValue());
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static class ComboBoxSelectionModel<T> extends SingleSelectionModel<T>
    {
        private final ComboBox<T> comboBox;
        private boolean atomic;
        private final ListChangeListener<T> itemsContentObserver;
        private final InvalidationListener itemsObserver;
        private WeakListChangeListener<T> weakItemsContentObserver;
        
        private void doAtomic(final Runnable runnable) {
            this.atomic = true;
            runnable.run();
            this.atomic = false;
        }
        
        public ComboBoxSelectionModel(final ComboBox<T> comboBox) {
            this.atomic = false;
            this.itemsContentObserver = new ListChangeListener<T>() {
                @Override
                public void onChanged(final Change<? extends T> change) {
                    if (ComboBoxSelectionModel.this.comboBox.getItems() == null || ComboBoxSelectionModel.this.comboBox.getItems().isEmpty()) {
                        ComboBoxSelectionModel.this.setSelectedIndex(-1);
                    }
                    else if (ComboBoxSelectionModel.this.getSelectedIndex() == -1 && ComboBoxSelectionModel.this.getSelectedItem() != null) {
                        final int index = ComboBoxSelectionModel.this.comboBox.getItems().indexOf(ComboBoxSelectionModel.this.getSelectedItem());
                        if (index != -1) {
                            ComboBoxSelectionModel.this.setSelectedIndex(index);
                        }
                    }
                    int n = 0;
                    while (change.next()) {
                        ComboBoxSelectionModel.this.comboBox.wasSetAllCalled = (ComboBoxSelectionModel.this.comboBox.previousItemCount == change.getRemovedSize());
                        if (change.wasReplaced()) {
                            continue;
                        }
                        if ((!change.wasAdded() && !change.wasRemoved()) || change.getFrom() > ComboBoxSelectionModel.this.getSelectedIndex() || ComboBoxSelectionModel.this.getSelectedIndex() == -1) {
                            continue;
                        }
                        n += (change.wasAdded() ? change.getAddedSize() : (-change.getRemovedSize()));
                    }
                    if (n != 0) {
                        ComboBoxSelectionModel.this.clearAndSelect(ComboBoxSelectionModel.this.getSelectedIndex() + n);
                    }
                    else if (ComboBoxSelectionModel.this.comboBox.wasSetAllCalled && ComboBoxSelectionModel.this.getSelectedIndex() >= 0 && ComboBoxSelectionModel.this.getSelectedItem() != null) {
                        final Object selectedItem = ComboBoxSelectionModel.this.getSelectedItem();
                        for (int i = 0; i < ComboBoxSelectionModel.this.comboBox.getItems().size(); ++i) {
                            if (selectedItem.equals(ComboBoxSelectionModel.this.comboBox.getItems().get(i))) {
                                ComboBoxSelectionModel.this.comboBox.setValue(null);
                                ComboBoxSelectionModel.this.setSelectedItem(null);
                                ComboBoxSelectionModel.this.setSelectedIndex(i);
                                break;
                            }
                        }
                    }
                    ComboBoxSelectionModel.this.comboBox.previousItemCount = ComboBoxSelectionModel.this.getItemCount();
                }
            };
            this.weakItemsContentObserver = new WeakListChangeListener<T>(this.itemsContentObserver);
            if (comboBox == null) {
                throw new NullPointerException("ComboBox can not be null");
            }
            ((ComboBox<Object>)(this.comboBox = comboBox)).previousItemCount = this.getItemCount();
            this.selectedIndexProperty().addListener(p0 -> {
                if (this.atomic) {
                    return;
                }
                else {
                    this.setSelectedItem(this.getModelItem(this.getSelectedIndex()));
                    return;
                }
            });
            this.itemsObserver = new InvalidationListener() {
                private WeakReference<ObservableList<T>> weakItemsRef = new WeakReference<ObservableList<T>>(ComboBoxSelectionModel.this.comboBox.getItems());
                
                @Override
                public void invalidated(final Observable observable) {
                    final ObservableList list = this.weakItemsRef.get();
                    this.weakItemsRef = new WeakReference<ObservableList<T>>(ComboBoxSelectionModel.this.comboBox.getItems());
                    ComboBoxSelectionModel.this.updateItemsObserver(list, ComboBoxSelectionModel.this.comboBox.getItems());
                    ComboBoxSelectionModel.this.comboBox.previousItemCount = ComboBoxSelectionModel.this.getItemCount();
                }
            };
            this.comboBox.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver));
            if (this.comboBox.getItems() != null) {
                this.comboBox.getItems().addListener(this.weakItemsContentObserver);
            }
        }
        
        private void updateItemsObserver(final ObservableList<T> list, final ObservableList<T> list2) {
            if (list != null) {
                list.removeListener(this.weakItemsContentObserver);
            }
            if (list2 != null) {
                list2.addListener(this.weakItemsContentObserver);
            }
            int index = -1;
            if (list2 != null) {
                final Object value = this.comboBox.getValue();
                if (value != null) {
                    index = list2.indexOf(value);
                }
            }
            this.setSelectedIndex(index);
        }
        
        @Override
        protected T getModelItem(final int n) {
            final ObservableList<T> items = this.comboBox.getItems();
            if (items == null) {
                return null;
            }
            if (n < 0 || n >= items.size()) {
                return null;
            }
            return (T)items.get(n);
        }
        
        @Override
        protected int getItemCount() {
            final ObservableList<T> items = this.comboBox.getItems();
            return (items == null) ? 0 : items.size();
        }
    }
}
