// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.collections.ObservableMap;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;

public interface Toggle
{
    ToggleGroup getToggleGroup();
    
    void setToggleGroup(final ToggleGroup p0);
    
    ObjectProperty<ToggleGroup> toggleGroupProperty();
    
    boolean isSelected();
    
    void setSelected(final boolean p0);
    
    BooleanProperty selectedProperty();
    
    Object getUserData();
    
    void setUserData(final Object p0);
    
    ObservableMap<Object, Object> getProperties();
}
