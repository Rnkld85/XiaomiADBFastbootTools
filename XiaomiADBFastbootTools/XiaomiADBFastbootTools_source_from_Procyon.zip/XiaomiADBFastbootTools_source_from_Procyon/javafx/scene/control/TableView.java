// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.stream.Stream;
import java.util.function.Consumer;
import java.util.Objects;
import java.util.LinkedHashSet;
import java.util.HashMap;
import com.sun.javafx.scene.control.behavior.CellBehaviorBase;
import com.sun.javafx.scene.control.SelectedItemsReadOnlyObservableList;
import com.sun.javafx.scene.control.ReadOnlyUnbackedObservableList;
import com.sun.javafx.scene.control.SelectedCellsMap;
import com.sun.javafx.collections.MappingChange;
import java.util.Collections;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.scene.control.Logging;
import javafx.beans.value.ObservableObjectValue;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import com.sun.javafx.collections.NonIterableChange;
import javafx.event.Event;
import javafx.event.EventTarget;
import com.sun.javafx.scene.control.TableColumnComparatorBase;
import javafx.scene.control.skin.TableViewSkin;
import javafx.event.EventType;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.MapChangeListener;
import javafx.scene.AccessibleRole;
import javafx.beans.Observable;
import javafx.collections.transformation.SortedList;
import java.lang.ref.WeakReference;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.Property;
import java.util.Iterator;
import java.util.List;
import java.util.Collection;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.css.PseudoClass;
import javafx.event.EventHandler;
import java.util.Comparator;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.DoubleProperty;
import javafx.scene.Node;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.collections.WeakListChangeListener;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.InvalidationListener;
import java.util.WeakHashMap;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.util.Callback;
import javafx.beans.DefaultProperty;

@DefaultProperty("items")
public class TableView<S> extends Control
{
    static final String SET_CONTENT_WIDTH = "TableView.contentWidth";
    public static final Callback<ResizeFeatures, Boolean> UNCONSTRAINED_RESIZE_POLICY;
    public static final Callback<ResizeFeatures, Boolean> CONSTRAINED_RESIZE_POLICY;
    public static final Callback<TableView, Boolean> DEFAULT_SORT_POLICY;
    private final ObservableList<TableColumn<S, ?>> columns;
    private final ObservableList<TableColumn<S, ?>> visibleLeafColumns;
    private final ObservableList<TableColumn<S, ?>> unmodifiableVisibleLeafColumns;
    private ObservableList<TableColumn<S, ?>> sortOrder;
    private double contentWidth;
    private boolean isInited;
    private final ListChangeListener<TableColumn<S, ?>> columnsObserver;
    private final WeakHashMap<TableColumn<S, ?>, Integer> lastKnownColumnIndex;
    private final InvalidationListener columnVisibleObserver;
    private final InvalidationListener columnSortableObserver;
    private final InvalidationListener columnSortTypeObserver;
    private final InvalidationListener columnComparatorObserver;
    private final InvalidationListener cellSelectionModelInvalidationListener;
    private final WeakInvalidationListener weakColumnVisibleObserver;
    private final WeakInvalidationListener weakColumnSortableObserver;
    private final WeakInvalidationListener weakColumnSortTypeObserver;
    private final WeakInvalidationListener weakColumnComparatorObserver;
    private final WeakListChangeListener<TableColumn<S, ?>> weakColumnsObserver;
    private final WeakInvalidationListener weakCellSelectionModelInvalidationListener;
    private ObjectProperty<ObservableList<S>> items;
    private BooleanProperty tableMenuButtonVisible;
    private ObjectProperty<Callback<ResizeFeatures, Boolean>> columnResizePolicy;
    private ObjectProperty<Callback<TableView<S>, TableRow<S>>> rowFactory;
    private ObjectProperty<Node> placeholder;
    private ObjectProperty<TableViewSelectionModel<S>> selectionModel;
    private ObjectProperty<TableViewFocusModel<S>> focusModel;
    private BooleanProperty editable;
    private DoubleProperty fixedCellSize;
    private ReadOnlyObjectWrapper<TablePosition<S, ?>> editingCell;
    private ReadOnlyObjectWrapper<Comparator<S>> comparator;
    private ObjectProperty<Callback<TableView<S>, Boolean>> sortPolicy;
    private ObjectProperty<EventHandler<SortEvent<TableView<S>>>> onSort;
    private ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollTo;
    private ObjectProperty<EventHandler<ScrollToEvent<TableColumn<S, ?>>>> onScrollToColumn;
    private boolean sortLock;
    private TableUtil.SortEventType lastSortEventType;
    private Object[] lastSortEventSupportInfo;
    private static final String DEFAULT_STYLE_CLASS = "table-view";
    private static final PseudoClass PSEUDO_CLASS_CELL_SELECTION;
    private static final PseudoClass PSEUDO_CLASS_ROW_SELECTION;
    
    public TableView() {
        this(FXCollections.observableArrayList());
    }
    
    public TableView(final ObservableList<S> items) {
        this.columns = FXCollections.observableArrayList();
        this.visibleLeafColumns = FXCollections.observableArrayList();
        this.unmodifiableVisibleLeafColumns = FXCollections.unmodifiableObservableList(this.visibleLeafColumns);
        this.sortOrder = FXCollections.observableArrayList();
        this.isInited = false;
        this.columnsObserver = new ListChangeListener<TableColumn<S, ?>>() {
            @Override
            public void onChanged(final Change<? extends TableColumn<S, ?>> change) {
                final ObservableList<TableColumn<S, ?>> columns = TableView.this.getColumns();
                while (change.next()) {
                    if (change.wasAdded()) {
                        final ArrayList<TableColumn> list = new ArrayList<TableColumn>();
                        for (final TableColumn tableColumn : change.getAddedSubList()) {
                            if (tableColumn == null) {
                                continue;
                            }
                            int n = 0;
                            final Iterator<TableColumn> iterator2 = columns.iterator();
                            while (iterator2.hasNext()) {
                                if (tableColumn == iterator2.next()) {
                                    ++n;
                                }
                            }
                            if (n <= 1) {
                                continue;
                            }
                            list.add(tableColumn);
                        }
                        if (!list.isEmpty()) {
                            String s = "";
                            final Iterator<Object> iterator3 = list.iterator();
                            while (iterator3.hasNext()) {
                                s = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, iterator3.next().getText());
                            }
                            throw new IllegalStateException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                        }
                        continue;
                    }
                }
                change.reset();
                final ArrayList list2 = new ArrayList();
                while (change.next()) {
                    final List<? extends TableColumn<S, ?>> removed = change.getRemoved();
                    final List<? extends TableColumn<S, ?>> addedSubList = change.getAddedSubList();
                    if (change.wasRemoved()) {
                        list2.addAll(removed);
                        final Iterator<? extends TableColumn<S, ?>> iterator4 = removed.iterator();
                        while (iterator4.hasNext()) {
                            ((TableColumn)iterator4.next()).setTableView(null);
                        }
                    }
                    if (change.wasAdded()) {
                        list2.removeAll(addedSubList);
                        final Iterator<? extends TableColumn<S, ?>> iterator5 = addedSubList.iterator();
                        while (iterator5.hasNext()) {
                            ((TableColumn)iterator5.next()).setTableView(TableView.this);
                        }
                    }
                    TableUtil.removeColumnsListener(removed, TableView.this.weakColumnsObserver);
                    TableUtil.addColumnsListener(addedSubList, TableView.this.weakColumnsObserver);
                    TableUtil.removeTableColumnListener(change.getRemoved(), TableView.this.weakColumnVisibleObserver, TableView.this.weakColumnSortableObserver, TableView.this.weakColumnSortTypeObserver, TableView.this.weakColumnComparatorObserver);
                    TableUtil.addTableColumnListener(change.getAddedSubList(), TableView.this.weakColumnVisibleObserver, TableView.this.weakColumnSortableObserver, TableView.this.weakColumnSortTypeObserver, TableView.this.weakColumnComparatorObserver);
                }
                TableView.this.updateVisibleLeafColumns();
                TableView.this.sortOrder.removeAll(list2);
                final TableViewFocusModel<S> focusModel = TableView.this.getFocusModel();
                final TableViewSelectionModel<Object> selectionModel = TableView.this.getSelectionModel();
                change.reset();
                final ArrayList<TableColumn<Object, ?>> list3 = new ArrayList<TableColumn<Object, ?>>();
                final ArrayList<Object> list4 = new ArrayList<Object>();
                while (change.next()) {
                    if (change.wasRemoved()) {
                        list3.addAll((Collection<?>)change.getRemoved());
                    }
                    if (change.wasAdded()) {
                        list4.addAll(change.getAddedSubList());
                    }
                }
                list3.removeAll(list4);
                if (focusModel != null) {
                    final TablePosition focusedCell = focusModel.getFocusedCell();
                    boolean b = false;
                    for (final TableColumn<Object, ?> tableColumn2 : list3) {
                        b = (focusedCell != null && focusedCell.getTableColumn() == tableColumn2);
                        if (b) {
                            break;
                        }
                    }
                    if (b) {
                        final int intValue = (int)TableView.this.lastKnownColumnIndex.getOrDefault(focusedCell.getTableColumn(), 0);
                        focusModel.focus(focusedCell.getRow(), TableView.this.getVisibleLeafColumn((intValue == 0) ? 0 : Math.min(TableView.this.getVisibleLeafColumns().size() - 1, intValue - 1)));
                    }
                }
                if (selectionModel != null) {
                    for (final TablePosition<Object, ?> tablePosition : new ArrayList<Object>(selectionModel.getSelectedCells())) {
                        boolean b2 = false;
                        for (final TableColumn<Object, ?> tableColumn3 : list3) {
                            b2 = (tablePosition != null && tablePosition.getTableColumn() == tableColumn3);
                            if (b2) {
                                break;
                            }
                        }
                        if (b2) {
                            final int intValue2 = (int)TableView.this.lastKnownColumnIndex.getOrDefault(tablePosition.getTableColumn(), -1);
                            if (intValue2 == -1) {
                                continue;
                            }
                            if (selectionModel instanceof TableViewArrayListSelectionModel) {
                                final TablePosition tablePosition2 = new TablePosition(TableView.this, tablePosition.getRow(), (TableColumn<Object, Object>)tablePosition.getTableColumn());
                                tablePosition2.fixedColumnIndex = intValue2;
                                ((TableViewArrayListSelectionModel<Object>)selectionModel).clearSelection(tablePosition2);
                            }
                            else {
                                selectionModel.clearSelection(tablePosition.getRow(), tablePosition.getTableColumn());
                            }
                        }
                    }
                }
                TableView.this.lastKnownColumnIndex.clear();
                for (final TableColumn<S, ?> key : TableView.this.getColumns()) {
                    final int visibleLeafIndex = TableView.this.getVisibleLeafIndex(key);
                    if (visibleLeafIndex > -1) {
                        TableView.this.lastKnownColumnIndex.put(key, visibleLeafIndex);
                    }
                }
            }
        };
        this.lastKnownColumnIndex = new WeakHashMap<TableColumn<S, ?>, Integer>();
        this.columnVisibleObserver = (p0 -> this.updateVisibleLeafColumns());
        final Object o;
        this.columnSortableObserver = (property -> {
            property.getBean();
            if (!this.getSortOrder().contains(o)) {
                return;
            }
            else {
                this.doSort(TableUtil.SortEventType.COLUMN_SORTABLE_CHANGE, o);
                return;
            }
        });
        final Object o2;
        this.columnSortTypeObserver = (property2 -> {
            property2.getBean();
            if (!this.getSortOrder().contains(o2)) {
                return;
            }
            else {
                this.doSort(TableUtil.SortEventType.COLUMN_SORT_TYPE_CHANGE, o2);
                return;
            }
        });
        final Object o3;
        this.columnComparatorObserver = (property3 -> {
            property3.getBean();
            if (!this.getSortOrder().contains(o3)) {
                return;
            }
            else {
                this.doSort(TableUtil.SortEventType.COLUMN_COMPARATOR_CHANGE, o3);
                return;
            }
        });
        final boolean b;
        this.cellSelectionModelInvalidationListener = (booleanProperty -> {
            booleanProperty.get();
            this.pseudoClassStateChanged(TableView.PSEUDO_CLASS_CELL_SELECTION, b);
            this.pseudoClassStateChanged(TableView.PSEUDO_CLASS_ROW_SELECTION, !b);
            return;
        });
        this.weakColumnVisibleObserver = new WeakInvalidationListener(this.columnVisibleObserver);
        this.weakColumnSortableObserver = new WeakInvalidationListener(this.columnSortableObserver);
        this.weakColumnSortTypeObserver = new WeakInvalidationListener(this.columnSortTypeObserver);
        this.weakColumnComparatorObserver = new WeakInvalidationListener(this.columnComparatorObserver);
        this.weakColumnsObserver = new WeakListChangeListener<TableColumn<S, ?>>(this.columnsObserver);
        this.weakCellSelectionModelInvalidationListener = new WeakInvalidationListener(this.cellSelectionModelInvalidationListener);
        this.items = new SimpleObjectProperty<ObservableList<S>>((Object)this, "items") {
            WeakReference<ObservableList<S>> oldItemsRef;
            
            @Override
            protected void invalidated() {
                final ObservableList<S> list = (this.oldItemsRef == null) ? null : this.oldItemsRef.get();
                final ObservableList<S> items = TableView.this.getItems();
                if (items != null && items == list) {
                    return;
                }
                if (!(items instanceof SortedList)) {
                    TableView.this.getSortOrder().clear();
                }
                this.oldItemsRef = new WeakReference<ObservableList<S>>(items);
            }
        };
        this.selectionModel = new SimpleObjectProperty<TableViewSelectionModel<S>>((Object)this, "selectionModel") {
            TableViewSelectionModel<S> oldValue = null;
            
            @Override
            protected void invalidated() {
                if (this.oldValue != null) {
                    this.oldValue.cellSelectionEnabledProperty().removeListener(TableView.this.weakCellSelectionModelInvalidationListener);
                    if (this.oldValue instanceof TableViewArrayListSelectionModel) {
                        ((TableViewArrayListSelectionModel)this.oldValue).dispose();
                    }
                }
                this.oldValue = this.get();
                if (this.oldValue != null) {
                    this.oldValue.cellSelectionEnabledProperty().addListener(TableView.this.weakCellSelectionModelInvalidationListener);
                    TableView.this.weakCellSelectionModelInvalidationListener.invalidated(this.oldValue.cellSelectionEnabledProperty());
                }
            }
        };
        this.sortLock = false;
        this.lastSortEventType = null;
        this.lastSortEventSupportInfo = null;
        this.getStyleClass().setAll("table-view");
        this.setAccessibleRole(AccessibleRole.TABLE_VIEW);
        this.setItems(items);
        this.setSelectionModel(new TableViewArrayListSelectionModel<S>(this));
        this.setFocusModel(new TableViewFocusModel<S>(this));
        this.getColumns().addListener(this.weakColumnsObserver);
        this.getSortOrder().addListener(change -> this.doSort(TableUtil.SortEventType.SORT_ORDER_CHANGE, change));
        this.getProperties().addListener(new MapChangeListener<Object, Object>() {
            @Override
            public void onChanged(final Change<?, ?> change) {
                if (change.wasAdded() && "TableView.contentWidth".equals(change.getKey())) {
                    if (change.getValueAdded() instanceof Number) {
                        TableView.this.setContentWidth((double)change.getValueAdded());
                    }
                    TableView.this.getProperties().remove("TableView.contentWidth");
                }
            }
        });
        this.isInited = true;
    }
    
    public final ObjectProperty<ObservableList<S>> itemsProperty() {
        return this.items;
    }
    
    public final void setItems(final ObservableList<S> list) {
        this.itemsProperty().set(list);
    }
    
    public final ObservableList<S> getItems() {
        return this.items.get();
    }
    
    public final BooleanProperty tableMenuButtonVisibleProperty() {
        if (this.tableMenuButtonVisible == null) {
            this.tableMenuButtonVisible = new SimpleBooleanProperty(this, "tableMenuButtonVisible");
        }
        return this.tableMenuButtonVisible;
    }
    
    public final void setTableMenuButtonVisible(final boolean b) {
        this.tableMenuButtonVisibleProperty().set(b);
    }
    
    public final boolean isTableMenuButtonVisible() {
        return this.tableMenuButtonVisible != null && this.tableMenuButtonVisible.get();
    }
    
    public final void setColumnResizePolicy(final Callback<ResizeFeatures, Boolean> callback) {
        this.columnResizePolicyProperty().set(callback);
    }
    
    public final Callback<ResizeFeatures, Boolean> getColumnResizePolicy() {
        return (this.columnResizePolicy == null) ? TableView.UNCONSTRAINED_RESIZE_POLICY : this.columnResizePolicy.get();
    }
    
    public final ObjectProperty<Callback<ResizeFeatures, Boolean>> columnResizePolicyProperty() {
        if (this.columnResizePolicy == null) {
            this.columnResizePolicy = new SimpleObjectProperty<Callback<ResizeFeatures, Boolean>>(this, "columnResizePolicy", TableView.UNCONSTRAINED_RESIZE_POLICY) {
                private Callback<ResizeFeatures, Boolean> oldPolicy;
                
                @Override
                protected void invalidated() {
                    if (TableView.this.isInited) {
                        ((ObjectPropertyBase<Callback<ResizeFeatures, Object>>)this).get().call(new ResizeFeatures(TableView.this, null, 0.0));
                        if (this.oldPolicy != null) {
                            TableView.this.pseudoClassStateChanged(PseudoClass.getPseudoClass(this.oldPolicy.toString()), false);
                        }
                        if (this.get() != null) {
                            TableView.this.pseudoClassStateChanged(PseudoClass.getPseudoClass(((ObjectPropertyBase<Callback<?, ?>>)this).get().toString()), true);
                        }
                        this.oldPolicy = this.get();
                    }
                }
            };
        }
        return this.columnResizePolicy;
    }
    
    public final ObjectProperty<Callback<TableView<S>, TableRow<S>>> rowFactoryProperty() {
        if (this.rowFactory == null) {
            this.rowFactory = new SimpleObjectProperty<Callback<TableView<S>, TableRow<S>>>(this, "rowFactory");
        }
        return this.rowFactory;
    }
    
    public final void setRowFactory(final Callback<TableView<S>, TableRow<S>> callback) {
        this.rowFactoryProperty().set(callback);
    }
    
    public final Callback<TableView<S>, TableRow<S>> getRowFactory() {
        return (this.rowFactory == null) ? null : this.rowFactory.get();
    }
    
    public final ObjectProperty<Node> placeholderProperty() {
        if (this.placeholder == null) {
            this.placeholder = new SimpleObjectProperty<Node>(this, "placeholder");
        }
        return this.placeholder;
    }
    
    public final void setPlaceholder(final Node node) {
        this.placeholderProperty().set(node);
    }
    
    public final Node getPlaceholder() {
        return (this.placeholder == null) ? null : this.placeholder.get();
    }
    
    public final ObjectProperty<TableViewSelectionModel<S>> selectionModelProperty() {
        return this.selectionModel;
    }
    
    public final void setSelectionModel(final TableViewSelectionModel<S> tableViewSelectionModel) {
        this.selectionModelProperty().set(tableViewSelectionModel);
    }
    
    public final TableViewSelectionModel<S> getSelectionModel() {
        return this.selectionModel.get();
    }
    
    public final void setFocusModel(final TableViewFocusModel<S> tableViewFocusModel) {
        this.focusModelProperty().set(tableViewFocusModel);
    }
    
    public final TableViewFocusModel<S> getFocusModel() {
        return (this.focusModel == null) ? null : this.focusModel.get();
    }
    
    public final ObjectProperty<TableViewFocusModel<S>> focusModelProperty() {
        if (this.focusModel == null) {
            this.focusModel = new SimpleObjectProperty<TableViewFocusModel<S>>(this, "focusModel");
        }
        return this.focusModel;
    }
    
    public final void setEditable(final boolean b) {
        this.editableProperty().set(b);
    }
    
    public final boolean isEditable() {
        return this.editable != null && this.editable.get();
    }
    
    public final BooleanProperty editableProperty() {
        if (this.editable == null) {
            this.editable = new SimpleBooleanProperty(this, "editable", false);
        }
        return this.editable;
    }
    
    public final void setFixedCellSize(final double n) {
        this.fixedCellSizeProperty().set(n);
    }
    
    public final double getFixedCellSize() {
        return (this.fixedCellSize == null) ? -1.0 : this.fixedCellSize.get();
    }
    
    public final DoubleProperty fixedCellSizeProperty() {
        if (this.fixedCellSize == null) {
            this.fixedCellSize = new StyleableDoubleProperty(-1.0) {
                @Override
                public CssMetaData<TableView<?>, Number> getCssMetaData() {
                    return StyleableProperties.FIXED_CELL_SIZE;
                }
                
                @Override
                public Object getBean() {
                    return TableView.this;
                }
                
                @Override
                public String getName() {
                    return "fixedCellSize";
                }
            };
        }
        return this.fixedCellSize;
    }
    
    private void setEditingCell(final TablePosition<S, ?> tablePosition) {
        this.editingCellPropertyImpl().set(tablePosition);
    }
    
    public final TablePosition<S, ?> getEditingCell() {
        return (this.editingCell == null) ? null : this.editingCell.get();
    }
    
    public final ReadOnlyObjectProperty<TablePosition<S, ?>> editingCellProperty() {
        return this.editingCellPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<TablePosition<S, ?>> editingCellPropertyImpl() {
        if (this.editingCell == null) {
            this.editingCell = new ReadOnlyObjectWrapper<TablePosition<S, ?>>(this, "editingCell");
        }
        return this.editingCell;
    }
    
    private void setComparator(final Comparator<S> comparator) {
        this.comparatorPropertyImpl().set(comparator);
    }
    
    public final Comparator<S> getComparator() {
        return (this.comparator == null) ? null : this.comparator.get();
    }
    
    public final ReadOnlyObjectProperty<Comparator<S>> comparatorProperty() {
        return this.comparatorPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<Comparator<S>> comparatorPropertyImpl() {
        if (this.comparator == null) {
            this.comparator = new ReadOnlyObjectWrapper<Comparator<S>>(this, "comparator");
        }
        return this.comparator;
    }
    
    public final void setSortPolicy(final Callback<TableView<S>, Boolean> callback) {
        this.sortPolicyProperty().set(callback);
    }
    
    public final Callback<TableView<S>, Boolean> getSortPolicy() {
        return (this.sortPolicy == null) ? ((Callback<TableView, Boolean>)TableView.DEFAULT_SORT_POLICY) : this.sortPolicy.get();
    }
    
    public final ObjectProperty<Callback<TableView<S>, Boolean>> sortPolicyProperty() {
        if (this.sortPolicy == null) {
            this.sortPolicy = new SimpleObjectProperty<Callback<TableView<S>, Boolean>>(this, "sortPolicy", (Callback<TableView, Boolean>)TableView.DEFAULT_SORT_POLICY) {
                @Override
                protected void invalidated() {
                    TableView.this.sort();
                }
            };
        }
        return this.sortPolicy;
    }
    
    public void setOnSort(final EventHandler<SortEvent<TableView<S>>> eventHandler) {
        this.onSortProperty().set(eventHandler);
    }
    
    public EventHandler<SortEvent<TableView<S>>> getOnSort() {
        if (this.onSort != null) {
            return this.onSort.get();
        }
        return null;
    }
    
    public ObjectProperty<EventHandler<SortEvent<TableView<S>>>> onSortProperty() {
        if (this.onSort == null) {
            this.onSort = new ObjectPropertyBase<EventHandler<SortEvent<TableView<S>>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(SortEvent.sortEvent(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return TableView.this;
                }
                
                @Override
                public String getName() {
                    return "onSort";
                }
            };
        }
        return this.onSort;
    }
    
    public final ObservableList<TableColumn<S, ?>> getColumns() {
        return this.columns;
    }
    
    public final ObservableList<TableColumn<S, ?>> getSortOrder() {
        return this.sortOrder;
    }
    
    public void scrollTo(final int n) {
        ControlUtils.scrollToIndex(this, n);
    }
    
    public void scrollTo(final S n) {
        if (this.getItems() != null) {
            final int index = this.getItems().indexOf(n);
            if (index >= 0) {
                ControlUtils.scrollToIndex(this, index);
            }
        }
    }
    
    public void setOnScrollTo(final EventHandler<ScrollToEvent<Integer>> eventHandler) {
        this.onScrollToProperty().set(eventHandler);
    }
    
    public EventHandler<ScrollToEvent<Integer>> getOnScrollTo() {
        if (this.onScrollTo != null) {
            return this.onScrollTo.get();
        }
        return null;
    }
    
    public ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollToProperty() {
        if (this.onScrollTo == null) {
            this.onScrollTo = new ObjectPropertyBase<EventHandler<ScrollToEvent<Integer>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(ScrollToEvent.scrollToTopIndex(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return TableView.this;
                }
                
                @Override
                public String getName() {
                    return "onScrollTo";
                }
            };
        }
        return this.onScrollTo;
    }
    
    public void scrollToColumn(final TableColumn<S, ?> tableColumn) {
        ControlUtils.scrollToColumn(this, tableColumn);
    }
    
    public void scrollToColumnIndex(final int n) {
        if (this.getColumns() != null) {
            ControlUtils.scrollToColumn(this, this.getColumns().get(n));
        }
    }
    
    public void setOnScrollToColumn(final EventHandler<ScrollToEvent<TableColumn<S, ?>>> eventHandler) {
        this.onScrollToColumnProperty().set(eventHandler);
    }
    
    public EventHandler<ScrollToEvent<TableColumn<S, ?>>> getOnScrollToColumn() {
        if (this.onScrollToColumn != null) {
            return this.onScrollToColumn.get();
        }
        return null;
    }
    
    public ObjectProperty<EventHandler<ScrollToEvent<TableColumn<S, ?>>>> onScrollToColumnProperty() {
        if (this.onScrollToColumn == null) {
            this.onScrollToColumn = new ObjectPropertyBase<EventHandler<ScrollToEvent<TableColumn<S, ?>>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(ScrollToEvent.scrollToColumn(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return TableView.this;
                }
                
                @Override
                public String getName() {
                    return "onScrollToColumn";
                }
            };
        }
        return this.onScrollToColumn;
    }
    
    public boolean resizeColumn(final TableColumn<S, ?> tableColumn, final double n) {
        return tableColumn != null && Double.compare(n, 0.0) != 0 && this.getColumnResizePolicy().call(new ResizeFeatures(this, tableColumn, n));
    }
    
    public void edit(final int n, final TableColumn<S, ?> tableColumn) {
        if (!this.isEditable() || (tableColumn != null && !tableColumn.isEditable())) {
            return;
        }
        if (n < 0 && tableColumn == null) {
            this.setEditingCell(null);
        }
        else {
            this.setEditingCell(new TablePosition<S, Object>(this, n, tableColumn));
        }
    }
    
    public ObservableList<TableColumn<S, ?>> getVisibleLeafColumns() {
        return this.unmodifiableVisibleLeafColumns;
    }
    
    public int getVisibleLeafIndex(final TableColumn<S, ?> tableColumn) {
        return this.visibleLeafColumns.indexOf(tableColumn);
    }
    
    public TableColumn<S, ?> getVisibleLeafColumn(final int n) {
        if (n < 0 || n >= this.visibleLeafColumns.size()) {
            return null;
        }
        return this.visibleLeafColumns.get(n);
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TableViewSkin<Object>(this);
    }
    
    public void sort() {
        final ObservableList<TableColumn<S, ?>> sortOrder = (ObservableList<TableColumn<S, ?>>)this.getSortOrder();
        final Comparator<S> comparator = this.getComparator();
        this.setComparator(sortOrder.isEmpty() ? null : new TableColumnComparatorBase.TableColumnComparator<S, Object>((List<TableColumn<Object, Object>>)sortOrder));
        final SortEvent sortEvent = new SortEvent((C)this, this);
        this.fireEvent(sortEvent);
        if (sortEvent.isConsumed()) {
            return;
        }
        final ArrayList<Object> list = new ArrayList<Object>(this.getSelectionModel().getSelectedCells());
        final int size = list.size();
        this.getSelectionModel().startAtomic();
        final Callback<TableView<S>, Boolean> sortPolicy = this.getSortPolicy();
        if (sortPolicy == null) {
            return;
        }
        final Boolean b = sortPolicy.call(this);
        this.getSelectionModel().stopAtomic();
        if (b == null || !b) {
            this.sortLock = true;
            TableUtil.handleSortFailure(sortOrder, this.lastSortEventType, this.lastSortEventSupportInfo);
            this.setComparator(comparator);
            this.sortLock = false;
        }
        else if (this.getSelectionModel() instanceof TableViewArrayListSelectionModel) {
            final TableViewArrayListSelectionModel tableViewArrayListSelectionModel = (TableViewArrayListSelectionModel)this.getSelectionModel();
            final ObservableList list2 = tableViewArrayListSelectionModel.getSelectedCells();
            final ArrayList<TablePosition> list3 = new ArrayList<TablePosition>();
            for (int i = 0; i < size; ++i) {
                final TablePosition tablePosition = list.get(i);
                if (!list2.contains(tablePosition)) {
                    list3.add(tablePosition);
                }
            }
            if (!list3.isEmpty()) {
                tableViewArrayListSelectionModel.fireCustomSelectedCellsListChangeEvent(new NonIterableChange.GenericAddRemoveChange(0, size, (List<Object>)list3, list2));
            }
        }
    }
    
    public void refresh() {
        this.getProperties().put("recreateKey", Boolean.TRUE);
    }
    
    private void doSort(final TableUtil.SortEventType lastSortEventType, final Object... lastSortEventSupportInfo) {
        if (this.sortLock) {
            return;
        }
        this.lastSortEventType = lastSortEventType;
        this.lastSortEventSupportInfo = lastSortEventSupportInfo;
        this.sort();
        this.lastSortEventType = null;
        this.lastSortEventSupportInfo = null;
    }
    
    private void setContentWidth(final double contentWidth) {
        this.contentWidth = contentWidth;
        if (this.isInited) {
            this.getColumnResizePolicy().call(new ResizeFeatures(this, null, 0.0));
        }
    }
    
    private void updateVisibleLeafColumns() {
        final ArrayList<TableColumn<S, ?>> all = new ArrayList<TableColumn<S, ?>>();
        this.buildVisibleLeafColumns(this.getColumns(), all);
        this.visibleLeafColumns.setAll(all);
        this.getColumnResizePolicy().call(new ResizeFeatures(this, null, 0.0));
    }
    
    private void buildVisibleLeafColumns(final List<TableColumn<S, ?>> list, final List<TableColumn<S, ?>> list2) {
        for (final TableColumn<S, ?> tableColumn : list) {
            if (tableColumn == null) {
                continue;
            }
            if (!tableColumn.getColumns().isEmpty()) {
                this.buildVisibleLeafColumns((List<TableColumn<S, ?>>)tableColumn.getColumns(), (List<TableColumn<S, ?>>)list2);
            }
            else {
                if (!tableColumn.isVisible()) {
                    continue;
                }
                list2.add(tableColumn);
            }
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case COLUMN_COUNT: {
                return this.getVisibleLeafColumns().size();
            }
            case ROW_COUNT: {
                return this.getItems().size();
            }
            case SELECTED_ITEMS: {
                final ObservableList list = (ObservableList)super.queryAccessibleAttribute(accessibleAttribute, array);
                final ArrayList<Object> list2 = new ArrayList<Object>();
                final Iterator<TableRow> iterator = list.iterator();
                while (iterator.hasNext()) {
                    final ObservableList list3 = (ObservableList)iterator.next().queryAccessibleAttribute(accessibleAttribute, array);
                    if (list3 != null) {
                        list2.addAll(list3);
                    }
                }
                return FXCollections.observableArrayList((Collection<?>)list2);
            }
            case FOCUS_ITEM: {
                final Node node = (Node)super.queryAccessibleAttribute(accessibleAttribute, array);
                if (node == null) {
                    return null;
                }
                final Node node2 = (Node)node.queryAccessibleAttribute(accessibleAttribute, array);
                return (node2 != null) ? node2 : node;
            }
            case CELL_AT_ROW_COLUMN: {
                final TableRow tableRow = (TableRow)super.queryAccessibleAttribute(accessibleAttribute, array);
                return (tableRow != null) ? tableRow.queryAccessibleAttribute(accessibleAttribute, array) : null;
            }
            case MULTIPLE_SELECTION: {
                final TableViewSelectionModel<S> selectionModel = this.getSelectionModel();
                return selectionModel != null && selectionModel.getSelectionMode() == SelectionMode.MULTIPLE;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        UNCONSTRAINED_RESIZE_POLICY = new Callback<ResizeFeatures, Boolean>() {
            @Override
            public String toString() {
                return "unconstrained-resize";
            }
            
            @Override
            public Boolean call(final ResizeFeatures resizeFeatures) {
                return Double.compare(TableUtil.resize(resizeFeatures.getColumn(), resizeFeatures.getDelta()), 0.0) == 0;
            }
        };
        CONSTRAINED_RESIZE_POLICY = new Callback<ResizeFeatures, Boolean>() {
            private boolean isFirstRun = true;
            
            @Override
            public String toString() {
                return "constrained-resize";
            }
            
            @Override
            public Boolean call(final ResizeFeatures resizeFeatures) {
                final TableView table = resizeFeatures.getTable();
                final Boolean value = TableUtil.constrainedResize(resizeFeatures, this.isFirstRun, table.contentWidth, table.getVisibleLeafColumns());
                this.isFirstRun = (this.isFirstRun && !value);
                return value;
            }
        };
        DEFAULT_SORT_POLICY = new Callback<TableView, Boolean>() {
            @Override
            public Boolean call(final TableView tableView) {
                try {
                    final ObservableList<T> items = tableView.getItems();
                    if (items instanceof SortedList) {
                        final boolean value = ((SortedList)items).comparatorProperty().isEqualTo(tableView.comparatorProperty()).get();
                        if (!value && Logging.getControlsLogger().isLoggable(PlatformLogger.Level.INFO)) {
                            Logging.getControlsLogger().info("TableView items list is a SortedList, but the SortedList comparator should be bound to the TableView comparator for sorting to be enabled (e.g. sortedList.comparatorProperty().bind(tableView.comparatorProperty());).");
                        }
                        return value;
                    }
                    if (items == null || items.isEmpty()) {
                        return true;
                    }
                    final Comparator<T> comparator = tableView.getComparator();
                    if (comparator == null) {
                        return true;
                    }
                    FXCollections.sort((ObservableList<Object>)items, (Comparator<? super Object>)comparator);
                    return true;
                }
                catch (UnsupportedOperationException ex) {
                    return false;
                }
            }
        };
        PSEUDO_CLASS_CELL_SELECTION = PseudoClass.getPseudoClass("cell-selection");
        PSEUDO_CLASS_ROW_SELECTION = PseudoClass.getPseudoClass("row-selection");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TableView<?>, Number> FIXED_CELL_SIZE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            FIXED_CELL_SIZE = new CssMetaData<TableView<?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)(-1.0)) {
                @Override
                public Double getInitialValue(final TableView<?> tableView) {
                    return tableView.getFixedCellSize();
                }
                
                @Override
                public boolean isSettable(final TableView<?> tableView) {
                    return ((TableView<Object>)tableView).fixedCellSize == null || !((TableView<Object>)tableView).fixedCellSize.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TableView<?> tableView) {
                    return (StyleableProperty<Number>)tableView.fixedCellSizeProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.FIXED_CELL_SIZE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    public static class ResizeFeatures<S> extends ResizeFeaturesBase<S>
    {
        private TableView<S> table;
        
        public ResizeFeatures(final TableView<S> table, final TableColumn<S, ?> tableColumn, final Double n) {
            super(tableColumn, n);
            this.table = table;
        }
        
        @Override
        public TableColumn<S, ?> getColumn() {
            return (TableColumn<S, ?>)(TableColumn)super.getColumn();
        }
        
        public TableView<S> getTable() {
            return this.table;
        }
    }
    
    public abstract static class TableViewSelectionModel<S> extends TableSelectionModel<S>
    {
        private final TableView<S> tableView;
        boolean blockFocusCall;
        
        public TableViewSelectionModel(final TableView<S> tableView) {
            this.blockFocusCall = false;
            if (tableView == null) {
                throw new NullPointerException("TableView can not be null");
            }
            this.tableView = tableView;
        }
        
        public abstract ObservableList<TablePosition> getSelectedCells();
        
        @Override
        public boolean isSelected(final int n, final TableColumnBase<S, ?> tableColumnBase) {
            return this.isSelected(n, (TableColumn<S, ?>)tableColumnBase);
        }
        
        public abstract boolean isSelected(final int p0, final TableColumn<S, ?> p1);
        
        @Override
        public void select(final int n, final TableColumnBase<S, ?> tableColumnBase) {
            this.select(n, (TableColumn<S, ?>)tableColumnBase);
        }
        
        public abstract void select(final int p0, final TableColumn<S, ?> p1);
        
        @Override
        public void clearAndSelect(final int n, final TableColumnBase<S, ?> tableColumnBase) {
            this.clearAndSelect(n, (TableColumn<S, ?>)tableColumnBase);
        }
        
        public abstract void clearAndSelect(final int p0, final TableColumn<S, ?> p1);
        
        @Override
        public void clearSelection(final int n, final TableColumnBase<S, ?> tableColumnBase) {
            this.clearSelection(n, (TableColumn<S, ?>)tableColumnBase);
        }
        
        public abstract void clearSelection(final int p0, final TableColumn<S, ?> p1);
        
        @Override
        public void selectRange(final int n, final TableColumnBase<S, ?> tableColumnBase, final int n2, final TableColumnBase<S, ?> tableColumnBase2) {
            final int visibleLeafIndex = this.tableView.getVisibleLeafIndex((TableColumn<S, ?>)tableColumnBase);
            final int visibleLeafIndex2 = this.tableView.getVisibleLeafIndex((TableColumn<S, ?>)tableColumnBase2);
            for (int i = n; i <= n2; ++i) {
                for (int j = visibleLeafIndex; j <= visibleLeafIndex2; ++j) {
                    this.select(i, this.tableView.getVisibleLeafColumn(j));
                }
            }
        }
        
        public TableView<S> getTableView() {
            return this.tableView;
        }
        
        protected List<S> getTableModel() {
            return this.tableView.getItems();
        }
        
        @Override
        protected S getModelItem(final int n) {
            if (n < 0 || n >= this.getItemCount()) {
                return null;
            }
            return this.tableView.getItems().get(n);
        }
        
        @Override
        protected int getItemCount() {
            return this.getTableModel().size();
        }
        
        public void focus(final int n) {
            this.focus(n, null);
        }
        
        public int getFocusedIndex() {
            return this.getFocusedCell().getRow();
        }
        
        void focus(final int n, final TableColumn<S, ?> tableColumn) {
            this.focus(new TablePosition<S, Object>(this.getTableView(), n, tableColumn));
            this.getTableView().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
        }
        
        void focus(final TablePosition<S, ?> tablePosition) {
            if (this.blockFocusCall) {
                return;
            }
            if (this.getTableView().getFocusModel() == null) {
                return;
            }
            this.getTableView().getFocusModel().focus(tablePosition.getRow(), tablePosition.getTableColumn());
        }
        
        TablePosition<S, ?> getFocusedCell() {
            if (this.getTableView().getFocusModel() == null) {
                return new TablePosition<S, Object>(this.getTableView(), -1, null);
            }
            return (TablePosition<S, ?>)this.getTableView().getFocusModel().getFocusedCell();
        }
    }
    
    static class TableViewArrayListSelectionModel<S> extends TableViewSelectionModel<S>
    {
        private int itemCount;
        private final MappingChange.Map<TablePosition<S, ?>, Integer> cellToIndicesMap;
        private final TableView<S> tableView;
        final InvalidationListener itemsPropertyListener;
        final ListChangeListener<S> itemsContentListener;
        final WeakListChangeListener<S> weakItemsContentListener;
        private final SelectedCellsMap<TablePosition<S, ?>> selectedCellsMap;
        private final ReadOnlyUnbackedObservableList<TablePosition<S, ?>> selectedCellsSeq;
        private int previousModelSize;
        
        public TableViewArrayListSelectionModel(final TableView<S> tableView) {
            super(tableView);
            this.itemCount = 0;
            this.cellToIndicesMap = (MappingChange.Map<TablePosition<S, ?>, Integer>)(tablePosition -> tablePosition.getRow());
            final List list;
            final int selectedIndex;
            boolean b = false;
            final Object o;
            final int n2;
            int n;
            this.itemsContentListener = (selectedItemChange -> {
                this.updateItemCount();
                this.getTableModel();
                while (selectedItemChange.next()) {
                    if (selectedItemChange.wasReplaced() || selectedItemChange.getAddedSize() == this.getItemCount()) {
                        this.selectedItemChange = selectedItemChange;
                        this.updateDefaultSelection();
                        this.selectedItemChange = null;
                        return;
                    }
                    else {
                        this.getSelectedItem();
                        this.getSelectedIndex();
                        if (list == null || list.isEmpty()) {
                            this.clearSelection();
                        }
                        else if (this.getSelectedIndex() == -1 && this.getSelectedItem() != null) {
                            list.indexOf(this.getSelectedItem());
                            if (selectedIndex != -1) {
                                this.setSelectedIndex(selectedIndex);
                                b = false;
                            }
                            else {
                                continue;
                            }
                        }
                        else if (selectedItemChange.wasRemoved() && selectedItemChange.getRemovedSize() == 1 && !selectedItemChange.wasAdded() && o != null && o.equals(selectedItemChange.getRemoved().get(0)) && this.getSelectedIndex() < this.getItemCount()) {
                            n = ((n2 == 0) ? 0 : (n2 - 1));
                            if (!o.equals(this.getModelItem(n))) {
                                this.clearAndSelect(n);
                            }
                            else {
                                continue;
                            }
                        }
                        else {
                            continue;
                        }
                    }
                }
                if (b) {
                    this.updateSelection(selectedItemChange);
                }
                return;
            });
            this.weakItemsContentListener = new WeakListChangeListener<S>(this.itemsContentListener);
            this.previousModelSize = 0;
            this.tableView = tableView;
            this.itemsPropertyListener = new InvalidationListener() {
                private WeakReference<ObservableList<S>> weakItemsRef = new WeakReference<ObservableList<S>>(tableView.getItems());
                
                @Override
                public void invalidated(final Observable observable) {
                    final ObservableList list = this.weakItemsRef.get();
                    this.weakItemsRef = new WeakReference<ObservableList<S>>(tableView.getItems());
                    TableViewArrayListSelectionModel.this.updateItemsObserver(list, tableView.getItems());
                    ((SelectedItemsReadOnlyObservableList)TableViewArrayListSelectionModel.this.getSelectedItems()).setItemsList(tableView.getItems());
                }
            };
            this.tableView.itemsProperty().addListener(this.itemsPropertyListener);
            this.selectedCellsMap = new SelectedCellsMap<TablePosition<S, ?>>(this::fireCustomSelectedCellsListChangeEvent) {
                @Override
                public boolean isCellSelectionEnabled() {
                    return TableViewArrayListSelectionModel.this.isCellSelectionEnabled();
                }
            };
            this.selectedCellsSeq = new ReadOnlyUnbackedObservableList<TablePosition<S, ?>>() {
                @Override
                public TablePosition<S, ?> get(final int n) {
                    return TableViewArrayListSelectionModel.this.selectedCellsMap.get(n);
                }
                
                @Override
                public int size() {
                    return TableViewArrayListSelectionModel.this.selectedCellsMap.size();
                }
            };
            final ObservableList<S> items = this.getTableView().getItems();
            if (items != null) {
                ((SelectedItemsReadOnlyObservableList)this.getSelectedItems()).setItemsList(items);
                items.addListener(this.weakItemsContentListener);
            }
            this.updateItemCount();
            this.updateDefaultSelection();
            this.cellSelectionEnabledProperty().addListener(p1 -> {
                this.updateDefaultSelection();
                CellBehaviorBase.setAnchor(tableView, this.getFocusedCell(), true);
            });
        }
        
        private void dispose() {
            this.tableView.itemsProperty().removeListener(this.itemsPropertyListener);
            final ObservableList<S> items = this.getTableView().getItems();
            if (items != null) {
                items.removeListener(this.weakItemsContentListener);
            }
        }
        
        @Override
        public ObservableList<TablePosition> getSelectedCells() {
            return (ObservableList<TablePosition>)this.selectedCellsSeq;
        }
        
        private void updateSelection(final ListChangeListener.Change<? extends S> change) {
            change.reset();
            int n = 0;
            int from = -1;
            while (change.next()) {
                if (change.wasReplaced()) {
                    if (change.getList().isEmpty()) {
                        this.clearSelection();
                    }
                    else {
                        final int selectedIndex = this.getSelectedIndex();
                        if (this.previousModelSize == change.getRemovedSize()) {
                            this.clearSelection();
                        }
                        else if (selectedIndex < this.getItemCount() && selectedIndex >= 0) {
                            this.startAtomic();
                            this.clearSelection(selectedIndex);
                            this.stopAtomic();
                            this.select(selectedIndex);
                        }
                        else {
                            this.clearSelection();
                        }
                    }
                }
                else if (change.wasAdded() || change.wasRemoved()) {
                    from = change.getFrom();
                    n += (change.wasAdded() ? change.getAddedSize() : (-change.getRemovedSize()));
                }
                else {
                    if (!change.wasPermutated()) {
                        continue;
                    }
                    this.startAtomic();
                    final int selectedIndex2 = this.getSelectedIndex();
                    final HashMap<Integer, Integer> hashMap = new HashMap<Integer, Integer>(change.getTo() - change.getFrom());
                    for (int i = change.getFrom(); i < change.getTo(); ++i) {
                        hashMap.put(i, change.getPermutation(i));
                    }
                    final ArrayList<TablePosition> list = (ArrayList<TablePosition>)new ArrayList<TablePosition<Object, T>>((Collection<? extends TablePosition<Object, T>>)this.getSelectedCells());
                    final ArrayList all = new ArrayList<TablePosition>(list.size());
                    boolean b = false;
                    for (int j = 0; j < list.size(); ++j) {
                        final TablePosition tablePosition = list.get(j);
                        final int row = tablePosition.getRow();
                        if (hashMap.containsKey(row)) {
                            final int intValue = hashMap.get(row);
                            b = (b || intValue != row);
                            all.add((TablePosition)new TablePosition(tablePosition.getTableView(), intValue, (TableColumn<Object, Object>)tablePosition.getTableColumn()));
                        }
                    }
                    if (b) {
                        this.quietClearSelection();
                        this.stopAtomic();
                        this.selectedCellsMap.setAll((Collection<TablePosition<S, ?>>)all);
                        if (selectedIndex2 < 0 || selectedIndex2 >= this.itemCount) {
                            continue;
                        }
                        final int permutation = change.getPermutation(selectedIndex2);
                        this.setSelectedIndex(permutation);
                        this.focus(permutation);
                    }
                    else {
                        this.stopAtomic();
                    }
                }
            }
            final TablePosition<S, ?> tablePosition2 = CellBehaviorBase.getAnchor(this.tableView, (TablePosition<S, ?>)null);
            if (n != 0 && from >= 0 && tablePosition2 != null && (change.wasRemoved() || change.wasAdded()) && this.isSelected(tablePosition2.getRow(), tablePosition2.getTableColumn())) {
                CellBehaviorBase.setAnchor(this.tableView, (TablePosition<S, ?>)new TablePosition<S, Object>((TableView<Object>)this.tableView, tablePosition2.getRow() + n, (TableColumn<Object, Object>)tablePosition2.getTableColumn()), false);
            }
            this.shiftSelection(from, n, new Callback<ShiftParams, Void>() {
                @Override
                public Void call(final ShiftParams shiftParams) {
                    TableViewArrayListSelectionModel.this.startAtomic();
                    final int clearIndex = shiftParams.getClearIndex();
                    final int setIndex = shiftParams.getSetIndex();
                    TablePosition tablePosition = null;
                    if (clearIndex > -1) {
                        for (int i = 0; i < TableViewArrayListSelectionModel.this.selectedCellsMap.size(); ++i) {
                            final TablePosition<Object, Object> tablePosition2 = TableViewArrayListSelectionModel.this.selectedCellsMap.get(i);
                            if (tablePosition2.getRow() == clearIndex) {
                                tablePosition = tablePosition2;
                                TableViewArrayListSelectionModel.this.selectedCellsMap.remove(tablePosition2);
                            }
                            else if (tablePosition2.getRow() == setIndex && !shiftParams.isSelected()) {
                                TableViewArrayListSelectionModel.this.selectedCellsMap.remove(tablePosition2);
                            }
                        }
                    }
                    if (tablePosition != null && shiftParams.isSelected()) {
                        TableViewArrayListSelectionModel.this.selectedCellsMap.add(new TablePosition(TableViewArrayListSelectionModel.this.tableView, shiftParams.getSetIndex(), tablePosition.getTableColumn()));
                    }
                    TableViewArrayListSelectionModel.this.stopAtomic();
                    return null;
                }
            });
            this.previousModelSize = this.getItemCount();
        }
        
        @Override
        public void clearAndSelect(final int n) {
            this.clearAndSelect(n, null);
        }
        
        @Override
        public void clearAndSelect(final int n, final TableColumn<S, ?> tableColumn) {
            if (n < 0 || n >= this.getItemCount()) {
                return;
            }
            final TablePosition<S, Object> tablePosition = new TablePosition<S, Object>(this.getTableView(), n, (TableColumn<S, Object>)tableColumn);
            final boolean cellSelectionEnabled = this.isCellSelectionEnabled();
            CellBehaviorBase.setAnchor(this.tableView, tablePosition, false);
            final ArrayList<TablePosition<S, ?>> list = new ArrayList<TablePosition<S, ?>>(this.selectedCellsMap.getSelectedCells());
            final boolean selected = this.isSelected(n, tableColumn);
            if (selected && list.size() == 1) {
                final TablePosition tablePosition2 = this.getSelectedCells().get(0);
                if (this.getSelectedItem() == this.getModelItem(n) && tablePosition2.getRow() == n && tablePosition2.getTableColumn() == tableColumn) {
                    return;
                }
            }
            this.startAtomic();
            this.clearSelection();
            this.select(n, tableColumn);
            this.stopAtomic();
            if (cellSelectionEnabled) {
                list.remove(tablePosition);
            }
            else {
                for (final TablePosition tablePosition3 : list) {
                    if (tablePosition3.getRow() == n) {
                        list.remove(tablePosition3);
                        break;
                    }
                }
            }
            ListChangeListener.Change<TablePosition<S, ?>> buildClearAndSelectChange;
            if (selected) {
                buildClearAndSelectChange = ControlUtils.buildClearAndSelectChange(this.selectedCellsSeq, list, n);
            }
            else {
                final int n2 = cellSelectionEnabled ? 0 : Math.max(0, this.selectedCellsSeq.indexOf(tablePosition));
                buildClearAndSelectChange = new NonIterableChange.GenericAddRemoveChange<TablePosition<S, ?>>(n2, n2 + (cellSelectionEnabled ? this.getSelectedCells().size() : 1), (List<Object>)list, (ObservableList<Object>)this.selectedCellsSeq);
            }
            this.fireCustomSelectedCellsListChangeEvent(buildClearAndSelectChange);
        }
        
        @Override
        public void select(final int n) {
            this.select(n, null);
        }
        
        @Override
        public void select(final int n, final TableColumn<S, ?> tableColumn) {
            if (n < 0 || n >= this.getItemCount()) {
                return;
            }
            if (this.isCellSelectionEnabled() && tableColumn == null) {
                final ObservableList<TableColumn<S, ?>> visibleLeafColumns = this.getTableView().getVisibleLeafColumns();
                for (int i = 0; i < visibleLeafColumns.size(); ++i) {
                    this.select(n, (TableColumn<S, ?>)visibleLeafColumns.get(i));
                }
                return;
            }
            if (CellBehaviorBase.hasDefaultAnchor(this.tableView)) {
                CellBehaviorBase.removeAnchor(this.tableView);
            }
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
            }
            this.selectedCellsMap.add(new TablePosition<S, Object>(this.getTableView(), n, (TableColumn<S, Object>)tableColumn));
            this.updateSelectedIndex(n);
            this.focus(n, tableColumn);
        }
        
        @Override
        public void select(final S n) {
            if (n == null && this.getSelectionMode() == SelectionMode.SINGLE) {
                this.clearSelection();
                return;
            }
            for (int i = 0; i < this.getItemCount(); ++i) {
                final S modelItem = this.getModelItem(i);
                if (modelItem != null) {
                    if (modelItem.equals(n)) {
                        if (this.isSelected(i)) {
                            return;
                        }
                        if (this.getSelectionMode() == SelectionMode.SINGLE) {
                            this.quietClearSelection();
                        }
                        this.select(i);
                        return;
                    }
                }
            }
            this.setSelectedIndex(-1);
            this.setSelectedItem(n);
        }
        
        @Override
        public void selectIndices(final int n, final int... array) {
            if (array == null) {
                this.select(n);
                return;
            }
            final int itemCount = this.getItemCount();
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
                for (int i = array.length - 1; i >= 0; --i) {
                    final int n2 = array[i];
                    if (n2 >= 0 && n2 < itemCount) {
                        this.select(n2);
                        break;
                    }
                }
                if (this.selectedCellsMap.isEmpty() && n > 0 && n < itemCount) {
                    this.select(n);
                }
            }
            else {
                int n3 = -1;
                final LinkedHashSet<TablePosition<S, Object>> set = new LinkedHashSet<TablePosition<S, Object>>();
                if (n >= 0 && n < itemCount) {
                    if (this.isCellSelectionEnabled()) {
                        final ObservableList<TableColumn<S, ?>> visibleLeafColumns = this.getTableView().getVisibleLeafColumns();
                        for (int j = 0; j < visibleLeafColumns.size(); ++j) {
                            if (!this.selectedCellsMap.isSelected(n, j)) {
                                set.add(new TablePosition<S, Object>(this.getTableView(), n, visibleLeafColumns.get(j)));
                            }
                        }
                    }
                    else if (!this.selectedCellsMap.isSelected(n, -1)) {
                        set.add(new TablePosition<S, Object>(this.getTableView(), n, null));
                    }
                    n3 = n;
                }
                for (int k = 0; k < array.length; ++k) {
                    final int n4 = array[k];
                    if (n4 >= 0) {
                        if (n4 < itemCount) {
                            n3 = n4;
                            if (this.isCellSelectionEnabled()) {
                                final ObservableList<TableColumn<S, ?>> visibleLeafColumns2 = this.getTableView().getVisibleLeafColumns();
                                for (int l = 0; l < visibleLeafColumns2.size(); ++l) {
                                    if (!this.selectedCellsMap.isSelected(n4, l)) {
                                        set.add(new TablePosition<S, Object>(this.getTableView(), n4, visibleLeafColumns2.get(l)));
                                        n3 = n4;
                                    }
                                }
                            }
                            else if (!this.selectedCellsMap.isSelected(n4, -1)) {
                                set.add(new TablePosition<S, Object>(this.getTableView(), n4, null));
                            }
                        }
                    }
                }
                this.selectedCellsMap.addAll((Collection<TablePosition<S, ?>>)set);
                if (n3 != -1) {
                    this.select(n3);
                }
            }
        }
        
        @Override
        public void selectAll() {
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                return;
            }
            if (this.isCellSelectionEnabled()) {
                final ArrayList<TablePosition<S, ?>> all = new ArrayList<TablePosition<S, ?>>();
                TablePosition<S, ?> tablePosition = null;
                for (int i = 0; i < this.getTableView().getVisibleLeafColumns().size(); ++i) {
                    final TableColumn<S, ?> tableColumn = this.getTableView().getVisibleLeafColumns().get(i);
                    for (int j = 0; j < this.getItemCount(); ++j) {
                        tablePosition = new TablePosition<S, Object>(this.getTableView(), j, (TableColumn<Object, Object>)tableColumn);
                        all.add(tablePosition);
                    }
                }
                this.selectedCellsMap.setAll(all);
                if (tablePosition != null) {
                    this.select(tablePosition.getRow(), tablePosition.getTableColumn());
                    this.focus(tablePosition.getRow(), tablePosition.getTableColumn());
                }
            }
            else {
                final ArrayList<Object> all2 = new ArrayList<Object>();
                for (int k = 0; k < this.getItemCount(); ++k) {
                    all2.add(new TablePosition<S, Object>(this.getTableView(), k, null));
                }
                this.selectedCellsMap.setAll((Collection<TablePosition<S, ?>>)all2);
                final int focusedIndex = this.getFocusedIndex();
                if (focusedIndex == -1) {
                    final int itemCount = this.getItemCount();
                    if (itemCount > 0) {
                        this.select(itemCount - 1);
                        this.focus((TablePosition<S, ?>)all2.get(all2.size() - 1));
                    }
                }
                else {
                    this.select(focusedIndex);
                    this.focus(focusedIndex);
                }
            }
        }
        
        @Override
        public void selectRange(final int n, final TableColumnBase<S, ?> tableColumnBase, final int n2, final TableColumnBase<S, ?> tableColumnBase2) {
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
                this.select(n2, tableColumnBase2);
                return;
            }
            this.startAtomic();
            final int itemCount = this.getItemCount();
            final boolean cellSelectionEnabled = this.isCellSelectionEnabled();
            final int visibleLeafIndex = this.tableView.getVisibleLeafIndex((TableColumn<S, ?>)tableColumnBase);
            final int visibleLeafIndex2 = this.tableView.getVisibleLeafIndex((TableColumn<S, ?>)tableColumnBase2);
            final int min = Math.min(visibleLeafIndex, visibleLeafIndex2);
            final int max = Math.max(visibleLeafIndex, visibleLeafIndex2);
            final int min2 = Math.min(n, n2);
            final int max2 = Math.max(n, n2);
            final ArrayList<TablePosition<S, ?>> list = new ArrayList<TablePosition<S, ?>>();
            for (int i = min2; i <= max2; ++i) {
                if (i >= 0) {
                    if (i < itemCount) {
                        if (!cellSelectionEnabled) {
                            list.add(new TablePosition<S, Object>((TableView<Object>)this.tableView, i, (TableColumn<Object, Object>)tableColumnBase));
                        }
                        else {
                            for (int j = min; j <= max; ++j) {
                                final TableColumn<S, ?> visibleLeafColumn = this.tableView.getVisibleLeafColumn(j);
                                if (visibleLeafColumn != null || !cellSelectionEnabled) {
                                    list.add(new TablePosition<S, Object>((TableView<Object>)this.tableView, i, (TableColumn<Object, Object>)visibleLeafColumn));
                                }
                            }
                        }
                    }
                }
            }
            list.removeAll(this.getSelectedCells());
            this.selectedCellsMap.addAll(list);
            this.stopAtomic();
            this.updateSelectedIndex(n2);
            this.focus(n2, (TableColumn<S, ?>)tableColumnBase2);
            final TableColumn<S, ?> tableColumn = (TableColumn<S, ?>)tableColumnBase;
            final TableColumn<S, ?> tableColumn2 = (TableColumn<S, ?>)(cellSelectionEnabled ? tableColumnBase2 : tableColumn);
            final int index = this.selectedCellsMap.indexOf(new TablePosition<S, Object>(this.tableView, n, (TableColumn<S, Object>)tableColumn));
            final int index2 = this.selectedCellsMap.indexOf(new TablePosition<S, Object>(this.tableView, n2, (TableColumn<S, Object>)tableColumn2));
            if (index > -1 && index2 > -1) {
                this.fireCustomSelectedCellsListChangeEvent(new NonIterableChange.SimpleAddChange<TablePosition<S, ?>>(Math.min(index, index2), Math.max(index, index2) + 1, (ObservableList<Object>)this.selectedCellsSeq));
            }
        }
        
        @Override
        public void clearSelection(final int n) {
            this.clearSelection(n, null);
        }
        
        @Override
        public void clearSelection(final int n, final TableColumn<S, ?> tableColumn) {
            this.clearSelection(new TablePosition<S, Object>(this.getTableView(), n, tableColumn));
        }
        
        private void clearSelection(final TablePosition<S, ?> tablePosition) {
            final boolean cellSelectionEnabled = this.isCellSelectionEnabled();
            final int row = tablePosition.getRow();
            final boolean b = tablePosition.getTableColumn() == null;
            final ArrayList<TablePosition<S, ?>> list = new ArrayList<TablePosition<S, ?>>();
            for (final TablePosition<S, ?> tablePosition2 : this.getSelectedCells()) {
                if (!cellSelectionEnabled) {
                    if (tablePosition2.getRow() == row) {
                        list.add(tablePosition2);
                        break;
                    }
                    continue;
                }
                else if (b && tablePosition2.getRow() == row) {
                    list.add(tablePosition2);
                }
                else {
                    if (tablePosition2.equals(tablePosition)) {
                        list.add(tablePosition);
                        break;
                    }
                    continue;
                }
            }
            final Stream<Object> stream = list.stream();
            final SelectedCellsMap<TablePosition<S, ?>> selectedCellsMap = this.selectedCellsMap;
            Objects.requireNonNull(selectedCellsMap);
            stream.forEach((Consumer<? super Object>)selectedCellsMap::remove);
            if (this.isEmpty() && !this.isAtomic()) {
                this.updateSelectedIndex(-1);
                this.selectedCellsMap.clear();
            }
        }
        
        @Override
        public void clearSelection() {
            final ArrayList list = new ArrayList((Collection<? extends E>)this.getSelectedCells());
            this.quietClearSelection();
            if (!this.isAtomic()) {
                this.updateSelectedIndex(-1);
                this.focus(-1);
                if (!list.isEmpty()) {
                    this.fireCustomSelectedCellsListChangeEvent(new NonIterableChange<TablePosition<S, ?>>(0, 0, this.selectedCellsSeq) {
                        @Override
                        public List<TablePosition<S, ?>> getRemoved() {
                            return (List<TablePosition<S, ?>>)list;
                        }
                    });
                }
            }
        }
        
        private void quietClearSelection() {
            this.startAtomic();
            this.selectedCellsMap.clear();
            this.stopAtomic();
        }
        
        @Override
        public boolean isSelected(final int n) {
            return this.isSelected(n, null);
        }
        
        @Override
        public boolean isSelected(final int n, final TableColumn<S, ?> tableColumn) {
            final boolean cellSelectionEnabled = this.isCellSelectionEnabled();
            if (cellSelectionEnabled && tableColumn == null) {
                for (int size = this.tableView.getVisibleLeafColumns().size(), i = 0; i < size; ++i) {
                    if (!this.selectedCellsMap.isSelected(n, i)) {
                        return false;
                    }
                }
                return true;
            }
            return this.selectedCellsMap.isSelected(n, (!cellSelectionEnabled || tableColumn == null) ? -1 : this.tableView.getVisibleLeafIndex(tableColumn));
        }
        
        @Override
        public boolean isEmpty() {
            return this.selectedCellsMap.isEmpty();
        }
        
        @Override
        public void selectPrevious() {
            if (this.isCellSelectionEnabled()) {
                final TablePosition<S, ?> focusedCell = this.getFocusedCell();
                if (focusedCell.getColumn() - 1 >= 0) {
                    this.select(focusedCell.getRow(), this.getTableColumn(focusedCell.getTableColumn(), -1));
                }
                else if (focusedCell.getRow() < this.getItemCount() - 1) {
                    this.select(focusedCell.getRow() - 1, this.getTableColumn(this.getTableView().getVisibleLeafColumns().size() - 1));
                }
            }
            else {
                final int focusedIndex = this.getFocusedIndex();
                if (focusedIndex == -1) {
                    this.select(this.getItemCount() - 1);
                }
                else if (focusedIndex > 0) {
                    this.select(focusedIndex - 1);
                }
            }
        }
        
        @Override
        public void selectNext() {
            if (this.isCellSelectionEnabled()) {
                final TablePosition<S, ?> focusedCell = this.getFocusedCell();
                if (focusedCell.getColumn() + 1 < this.getTableView().getVisibleLeafColumns().size()) {
                    this.select(focusedCell.getRow(), this.getTableColumn(focusedCell.getTableColumn(), 1));
                }
                else if (focusedCell.getRow() < this.getItemCount() - 1) {
                    this.select(focusedCell.getRow() + 1, this.getTableColumn(0));
                }
            }
            else {
                final int focusedIndex = this.getFocusedIndex();
                if (focusedIndex == -1) {
                    this.select(0);
                }
                else if (focusedIndex < this.getItemCount() - 1) {
                    this.select(focusedIndex + 1);
                }
            }
        }
        
        @Override
        public void selectAboveCell() {
            final TablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getRow() == -1) {
                this.select(this.getItemCount() - 1);
            }
            else if (focusedCell.getRow() > 0) {
                this.select(focusedCell.getRow() - 1, focusedCell.getTableColumn());
            }
        }
        
        @Override
        public void selectBelowCell() {
            final TablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getRow() == -1) {
                this.select(0);
            }
            else if (focusedCell.getRow() < this.getItemCount() - 1) {
                this.select(focusedCell.getRow() + 1, focusedCell.getTableColumn());
            }
        }
        
        @Override
        public void selectFirst() {
            final TablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
            }
            if (this.getItemCount() > 0) {
                if (this.isCellSelectionEnabled()) {
                    this.select(0, focusedCell.getTableColumn());
                }
                else {
                    this.select(0);
                }
            }
        }
        
        @Override
        public void selectLast() {
            final TablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.quietClearSelection();
            }
            final int itemCount = this.getItemCount();
            if (itemCount > 0 && this.getSelectedIndex() < itemCount - 1) {
                if (this.isCellSelectionEnabled()) {
                    this.select(itemCount - 1, focusedCell.getTableColumn());
                }
                else {
                    this.select(itemCount - 1);
                }
            }
        }
        
        @Override
        public void selectLeftCell() {
            if (!this.isCellSelectionEnabled()) {
                return;
            }
            final TablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getColumn() - 1 >= 0) {
                this.select(focusedCell.getRow(), this.getTableColumn(focusedCell.getTableColumn(), -1));
            }
        }
        
        @Override
        public void selectRightCell() {
            if (!this.isCellSelectionEnabled()) {
                return;
            }
            final TablePosition<S, ?> focusedCell = this.getFocusedCell();
            if (focusedCell.getColumn() + 1 < this.getTableView().getVisibleLeafColumns().size()) {
                this.select(focusedCell.getRow(), this.getTableColumn(focusedCell.getTableColumn(), 1));
            }
        }
        
        private void updateItemsObserver(final ObservableList<S> list, final ObservableList<S> list2) {
            if (list != null) {
                list.removeListener(this.weakItemsContentListener);
            }
            if (list2 != null) {
                list2.addListener(this.weakItemsContentListener);
            }
            this.updateItemCount();
            this.updateDefaultSelection();
        }
        
        private void updateDefaultSelection() {
            int index = -1;
            if (this.tableView.getItems() != null) {
                final Object selectedItem = this.getSelectedItem();
                if (selectedItem != null) {
                    index = this.tableView.getItems().indexOf(selectedItem);
                }
            }
            this.clearSelection();
            this.select(index, this.isCellSelectionEnabled() ? this.getTableColumn(0) : null);
        }
        
        private TableColumn<S, ?> getTableColumn(final int n) {
            return this.getTableView().getVisibleLeafColumn(n);
        }
        
        private TableColumn<S, ?> getTableColumn(final TableColumn<S, ?> tableColumn, final int n) {
            return this.getTableView().getVisibleLeafColumn(this.getTableView().getVisibleLeafIndex(tableColumn) + n);
        }
        
        private void updateSelectedIndex(final int selectedIndex) {
            this.setSelectedIndex(selectedIndex);
            this.setSelectedItem(this.getModelItem(selectedIndex));
        }
        
        @Override
        protected int getItemCount() {
            return this.itemCount;
        }
        
        private void updateItemCount() {
            if (this.tableView == null) {
                this.itemCount = -1;
            }
            else {
                final List<S> tableModel = this.getTableModel();
                this.itemCount = ((tableModel == null) ? -1 : tableModel.size());
            }
        }
        
        private void fireCustomSelectedCellsListChangeEvent(final ListChangeListener.Change<? extends TablePosition<S, ?>> change) {
            ControlUtils.updateSelectedIndices((MultipleSelectionModelBase<Object>)this, change);
            if (this.isAtomic()) {
                return;
            }
            this.selectedCellsSeq.callObservers((ListChangeListener.Change<TablePosition<S, ?>>)new MappingChange(change, MappingChange.NOOP_MAP, (ObservableList<Object>)this.selectedCellsSeq));
        }
    }
    
    public static class TableViewFocusModel<S> extends TableFocusModel<S, TableColumn<S, ?>>
    {
        private final TableView<S> tableView;
        private final TablePosition<S, ?> EMPTY_CELL;
        private final InvalidationListener itemsObserver;
        private final ListChangeListener<S> itemsContentListener;
        private WeakListChangeListener<S> weakItemsContentListener;
        private ReadOnlyObjectWrapper<TablePosition> focusedCell;
        
        public TableViewFocusModel(final TableView<S> tableView) {
            final TablePosition<S, ?> tablePosition;
            final int n;
            boolean b = false;
            boolean b2 = false;
            int n2 = 0;
            int n3 = 0;
            final int n4;
            this.itemsContentListener = (change -> {
                change.next();
                if (change.wasReplaced() || change.getAddedSize() == this.getItemCount()) {
                    this.updateDefaultFocus();
                    return;
                }
                else {
                    this.getFocusedCell();
                    tablePosition.getRow();
                    if (n == -1 || change.getFrom() > n) {
                        return;
                    }
                    else {
                        change.reset();
                        while (change.next()) {
                            b |= change.wasAdded();
                            b2 |= change.wasRemoved();
                            n2 += change.getAddedSize();
                            n3 += change.getRemovedSize();
                        }
                        if (b && !b2) {
                            if (n2 < change.getList().size()) {
                                this.focus(Math.min(this.getItemCount() - 1, this.getFocusedIndex() + n2), tablePosition.getTableColumn());
                            }
                        }
                        else if (!b && b2) {
                            Math.max(0, this.getFocusedIndex() - n3);
                            if (n4 < 0) {
                                this.focus(0, tablePosition.getTableColumn());
                            }
                            else {
                                this.focus(n4, tablePosition.getTableColumn());
                            }
                        }
                        return;
                    }
                }
            });
            this.weakItemsContentListener = new WeakListChangeListener<S>(this.itemsContentListener);
            if (tableView == null) {
                throw new NullPointerException("TableView can not be null");
            }
            this.tableView = tableView;
            this.EMPTY_CELL = new TablePosition<S, Object>(tableView, -1, null);
            this.itemsObserver = new InvalidationListener() {
                private WeakReference<ObservableList<S>> weakItemsRef = new WeakReference<ObservableList<S>>(tableView.getItems());
                
                @Override
                public void invalidated(final Observable observable) {
                    final ObservableList list = this.weakItemsRef.get();
                    this.weakItemsRef = new WeakReference<ObservableList<S>>(tableView.getItems());
                    TableViewFocusModel.this.updateItemsObserver(list, tableView.getItems());
                }
            };
            this.tableView.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver));
            if (tableView.getItems() != null) {
                this.tableView.getItems().addListener(this.weakItemsContentListener);
            }
            this.updateDefaultFocus();
            this.focusedCellProperty().addListener(p1 -> tableView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM));
        }
        
        private void updateItemsObserver(final ObservableList<S> list, final ObservableList<S> list2) {
            if (list != null) {
                list.removeListener(this.weakItemsContentListener);
            }
            if (list2 != null) {
                list2.addListener(this.weakItemsContentListener);
            }
            this.updateDefaultFocus();
        }
        
        @Override
        protected int getItemCount() {
            if (this.tableView.getItems() == null) {
                return -1;
            }
            return this.tableView.getItems().size();
        }
        
        @Override
        protected S getModelItem(final int n) {
            if (this.tableView.getItems() == null) {
                return null;
            }
            if (n < 0 || n >= this.getItemCount()) {
                return null;
            }
            return this.tableView.getItems().get(n);
        }
        
        public final ReadOnlyObjectProperty<TablePosition> focusedCellProperty() {
            return (ReadOnlyObjectProperty<TablePosition>)this.focusedCellPropertyImpl().getReadOnlyProperty();
        }
        
        private void setFocusedCell(final TablePosition tablePosition) {
            this.focusedCellPropertyImpl().set(tablePosition);
        }
        
        public final TablePosition getFocusedCell() {
            return (this.focusedCell == null) ? this.EMPTY_CELL : this.focusedCell.get();
        }
        
        private ReadOnlyObjectWrapper<TablePosition> focusedCellPropertyImpl() {
            if (this.focusedCell == null) {
                this.focusedCell = new ReadOnlyObjectWrapper<TablePosition>(this.EMPTY_CELL) {
                    private TablePosition old;
                    
                    @Override
                    protected void invalidated() {
                        if (this.get() == null) {
                            return;
                        }
                        if (this.old == null || !this.old.equals(((ObjectPropertyBase<Object>)this).get())) {
                            TableViewFocusModel.this.setFocusedIndex(this.get().getRow());
                            TableViewFocusModel.this.setFocusedItem(TableViewFocusModel.this.getModelItem(this.getValue().getRow()));
                            this.old = this.get();
                        }
                    }
                    
                    @Override
                    public Object getBean() {
                        return TableViewFocusModel.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "focusedCell";
                    }
                };
            }
            return this.focusedCell;
        }
        
        @Override
        public void focus(final int focusedIndex, final TableColumn<S, ?> tableColumn) {
            if (focusedIndex < 0 || focusedIndex >= this.getItemCount()) {
                this.setFocusedCell(this.EMPTY_CELL);
            }
            else {
                final TablePosition focusedCell = this.getFocusedCell();
                final TablePosition focusedCell2 = new TablePosition((TableView<S>)this.tableView, focusedIndex, (TableColumn<S, T>)tableColumn);
                this.setFocusedCell(focusedCell2);
                if (focusedCell2.equals(focusedCell)) {
                    this.setFocusedIndex(focusedIndex);
                    this.setFocusedItem(this.getModelItem(focusedIndex));
                }
            }
        }
        
        public void focus(final TablePosition tablePosition) {
            if (tablePosition == null) {
                return;
            }
            this.focus(tablePosition.getRow(), tablePosition.getTableColumn());
        }
        
        @Override
        public boolean isFocused(final int n, final TableColumn<S, ?> tableColumn) {
            if (n < 0 || n >= this.getItemCount()) {
                return false;
            }
            final TablePosition focusedCell = this.getFocusedCell();
            final boolean b = tableColumn == null || tableColumn.equals(focusedCell.getTableColumn());
            return focusedCell.getRow() == n && b;
        }
        
        @Override
        public void focus(final int n) {
            if (n < 0 || n >= this.getItemCount()) {
                this.setFocusedCell(this.EMPTY_CELL);
            }
            else {
                this.setFocusedCell(new TablePosition((TableView<S>)this.tableView, n, null));
            }
        }
        
        @Override
        public void focusAboveCell() {
            final TablePosition focusedCell = this.getFocusedCell();
            if (this.getFocusedIndex() == -1) {
                this.focus(this.getItemCount() - 1, focusedCell.getTableColumn());
            }
            else if (this.getFocusedIndex() > 0) {
                this.focus(this.getFocusedIndex() - 1, focusedCell.getTableColumn());
            }
        }
        
        @Override
        public void focusBelowCell() {
            final TablePosition focusedCell = this.getFocusedCell();
            if (this.getFocusedIndex() == -1) {
                this.focus(0, focusedCell.getTableColumn());
            }
            else if (this.getFocusedIndex() != this.getItemCount() - 1) {
                this.focus(this.getFocusedIndex() + 1, focusedCell.getTableColumn());
            }
        }
        
        @Override
        public void focusLeftCell() {
            final TablePosition focusedCell = this.getFocusedCell();
            if (focusedCell.getColumn() <= 0) {
                return;
            }
            this.focus(focusedCell.getRow(), this.getTableColumn(focusedCell.getTableColumn(), -1));
        }
        
        @Override
        public void focusRightCell() {
            final TablePosition focusedCell = this.getFocusedCell();
            if (focusedCell.getColumn() == this.getColumnCount() - 1) {
                return;
            }
            this.focus(focusedCell.getRow(), this.getTableColumn(focusedCell.getTableColumn(), 1));
        }
        
        @Override
        public void focusPrevious() {
            if (this.getFocusedIndex() == -1) {
                this.focus(0);
            }
            else if (this.getFocusedIndex() > 0) {
                this.focusAboveCell();
            }
        }
        
        @Override
        public void focusNext() {
            if (this.getFocusedIndex() == -1) {
                this.focus(0);
            }
            else if (this.getFocusedIndex() != this.getItemCount() - 1) {
                this.focusBelowCell();
            }
        }
        
        private void updateDefaultFocus() {
            int index = -1;
            if (this.tableView.getItems() != null) {
                final Object focusedItem = this.getFocusedItem();
                if (focusedItem != null) {
                    index = this.tableView.getItems().indexOf(focusedItem);
                }
                if (index == -1) {
                    index = ((this.tableView.getItems().size() > 0) ? 0 : -1);
                }
            }
            final TablePosition focusedCell = this.getFocusedCell();
            this.focus(index, (focusedCell != null && !this.EMPTY_CELL.equals(focusedCell)) ? focusedCell.getTableColumn() : this.tableView.getVisibleLeafColumn(0));
        }
        
        private int getColumnCount() {
            return this.tableView.getVisibleLeafColumns().size();
        }
        
        private TableColumn<S, ?> getTableColumn(final TableColumn<S, ?> tableColumn, final int n) {
            return this.tableView.getVisibleLeafColumn(this.tableView.getVisibleLeafIndex(tableColumn) + n);
        }
    }
}
