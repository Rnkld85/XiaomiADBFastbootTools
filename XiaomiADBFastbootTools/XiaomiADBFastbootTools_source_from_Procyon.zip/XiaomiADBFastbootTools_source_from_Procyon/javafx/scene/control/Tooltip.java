// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Window;
import javafx.geometry.NodeOrientation;
import javafx.animation.KeyValue;
import javafx.animation.KeyFrame;
import javafx.animation.Animation;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.animation.Timeline;
import javafx.scene.AccessibleRole;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.DurationConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.converter.StringConverter;
import javafx.css.converter.BooleanConverter;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.css.FontCssMetaData;
import javafx.scene.control.skin.TooltipSkin;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.scene.image.Image;
import com.sun.javafx.css.StyleManager;
import javafx.scene.image.ImageView;
import javafx.css.StyleableProperty;
import javafx.stage.PopupWindow;
import com.sun.javafx.stage.PopupWindowHelper;
import javafx.css.SimpleStyleableDoubleProperty;
import com.sun.javafx.scene.NodeHelper;
import javafx.css.StyleOrigin;
import javafx.css.StyleableObjectProperty;
import javafx.css.SimpleStyleableBooleanProperty;
import javafx.css.SimpleStyleableObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.css.Styleable;
import java.util.List;
import javafx.css.CssMetaData;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.DoubleProperty;
import javafx.css.StyleableStringProperty;
import javafx.scene.Node;
import javafx.util.Duration;
import javafx.scene.text.Font;
import javafx.beans.property.BooleanProperty;
import javafx.scene.text.TextAlignment;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import com.sun.javafx.beans.IDProperty;

@IDProperty("id")
public class Tooltip extends PopupControl
{
    private static String TOOLTIP_PROP_KEY;
    private static int TOOLTIP_XOFFSET;
    private static int TOOLTIP_YOFFSET;
    private static TooltipBehavior BEHAVIOR;
    private final StringProperty text;
    private final ObjectProperty<TextAlignment> textAlignment;
    private final ObjectProperty<OverrunStyle> textOverrun;
    private final BooleanProperty wrapText;
    private final ObjectProperty<Font> font;
    private final ObjectProperty<Duration> showDelayProperty;
    private final ObjectProperty<Duration> showDurationProperty;
    private final ObjectProperty<Duration> hideDelayProperty;
    private final ObjectProperty<Node> graphic;
    private StyleableStringProperty imageUrl;
    private final ObjectProperty<ContentDisplay> contentDisplay;
    private final DoubleProperty graphicTextGap;
    private final ReadOnlyBooleanWrapper activated;
    private static final CssMetaData<CSSBridge, Font> FONT;
    private static final CssMetaData<CSSBridge, TextAlignment> TEXT_ALIGNMENT;
    private static final CssMetaData<CSSBridge, OverrunStyle> TEXT_OVERRUN;
    private static final CssMetaData<CSSBridge, Boolean> WRAP_TEXT;
    private static final CssMetaData<CSSBridge, String> GRAPHIC;
    private static final CssMetaData<CSSBridge, ContentDisplay> CONTENT_DISPLAY;
    private static final CssMetaData<CSSBridge, Number> GRAPHIC_TEXT_GAP;
    private static final CssMetaData<CSSBridge, Duration> SHOW_DELAY;
    private static final CssMetaData<CSSBridge, Duration> SHOW_DURATION;
    private static final CssMetaData<CSSBridge, Duration> HIDE_DELAY;
    private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
    
    public static void install(final Node node, final Tooltip tooltip) {
        Tooltip.BEHAVIOR.install(node, tooltip);
    }
    
    public static void uninstall(final Node node, final Tooltip tooltip) {
        Tooltip.BEHAVIOR.uninstall(node);
    }
    
    public Tooltip() {
        this(null);
    }
    
    public Tooltip(final String text) {
        this.text = new SimpleStringProperty((Object)this, "text", "") {
            @Override
            protected void invalidated() {
                super.invalidated();
                final String value = this.get();
                if (Tooltip.this.isShowing() && value != null && !value.equals(Tooltip.this.getText())) {
                    Tooltip.this.setAnchorX(Tooltip.BEHAVIOR.lastMouseX);
                    Tooltip.this.setAnchorY(Tooltip.BEHAVIOR.lastMouseY);
                }
            }
        };
        this.textAlignment = new SimpleStyleableObjectProperty<TextAlignment>(Tooltip.TEXT_ALIGNMENT, this, "textAlignment", TextAlignment.LEFT);
        this.textOverrun = new SimpleStyleableObjectProperty<OverrunStyle>(Tooltip.TEXT_OVERRUN, this, "textOverrun", OverrunStyle.ELLIPSIS);
        this.wrapText = new SimpleStyleableBooleanProperty(Tooltip.WRAP_TEXT, this, "wrapText", false);
        this.font = new StyleableObjectProperty<Font>(Font.getDefault()) {
            private boolean fontSetByCss = false;
            
            @Override
            public void applyStyle(final StyleOrigin styleOrigin, final Font font) {
                try {
                    this.fontSetByCss = true;
                    super.applyStyle(styleOrigin, font);
                }
                catch (Exception ex) {
                    throw ex;
                }
                finally {
                    this.fontSetByCss = false;
                }
            }
            
            @Override
            public void set(final Font font) {
                final Font font2 = this.get();
                if (((StyleableObjectProperty)Tooltip.this.font).getStyleOrigin() != null) {
                    if (font != null) {
                        if (font.equals(font2)) {
                            return;
                        }
                    }
                    else if (font2 == null) {
                        return;
                    }
                }
                super.set(font);
            }
            
            @Override
            protected void invalidated() {
                if (!this.fontSetByCss) {
                    NodeHelper.reapplyCSS(Tooltip.this.bridge);
                }
            }
            
            @Override
            public CssMetaData<CSSBridge, Font> getCssMetaData() {
                return Tooltip.FONT;
            }
            
            @Override
            public Object getBean() {
                return Tooltip.this;
            }
            
            @Override
            public String getName() {
                return "font";
            }
        };
        this.showDelayProperty = new SimpleStyleableObjectProperty<Duration>(Tooltip.SHOW_DELAY, this, "showDelay", new Duration(1000.0));
        this.showDurationProperty = new SimpleStyleableObjectProperty<Duration>(Tooltip.SHOW_DURATION, this, "showDuration", new Duration(5000.0));
        this.hideDelayProperty = new SimpleStyleableObjectProperty<Duration>(Tooltip.HIDE_DELAY, this, "hideDelay", new Duration(200.0));
        this.graphic = new StyleableObjectProperty<Node>() {
            @Override
            public CssMetaData getCssMetaData() {
                return Tooltip.GRAPHIC;
            }
            
            @Override
            public Object getBean() {
                return Tooltip.this;
            }
            
            @Override
            public String getName() {
                return "graphic";
            }
        };
        this.imageUrl = null;
        this.contentDisplay = new SimpleStyleableObjectProperty<ContentDisplay>(Tooltip.CONTENT_DISPLAY, this, "contentDisplay", ContentDisplay.LEFT);
        this.graphicTextGap = new SimpleStyleableDoubleProperty(Tooltip.GRAPHIC_TEXT_GAP, this, "graphicTextGap", 4.0);
        this.activated = new ReadOnlyBooleanWrapper(this, "activated");
        if (text != null) {
            this.setText(text);
        }
        this.bridge = new CSSBridge();
        PopupWindowHelper.getContent(this).setAll(this.bridge);
        this.getStyleClass().setAll("tooltip");
    }
    
    public final StringProperty textProperty() {
        return this.text;
    }
    
    public final void setText(final String value) {
        this.textProperty().setValue(value);
    }
    
    public final String getText() {
        return (this.text.getValue() == null) ? "" : this.text.getValue();
    }
    
    public final ObjectProperty<TextAlignment> textAlignmentProperty() {
        return this.textAlignment;
    }
    
    public final void setTextAlignment(final TextAlignment value) {
        this.textAlignmentProperty().setValue(value);
    }
    
    public final TextAlignment getTextAlignment() {
        return this.textAlignmentProperty().getValue();
    }
    
    public final ObjectProperty<OverrunStyle> textOverrunProperty() {
        return this.textOverrun;
    }
    
    public final void setTextOverrun(final OverrunStyle value) {
        this.textOverrunProperty().setValue(value);
    }
    
    public final OverrunStyle getTextOverrun() {
        return this.textOverrunProperty().getValue();
    }
    
    public final BooleanProperty wrapTextProperty() {
        return this.wrapText;
    }
    
    public final void setWrapText(final boolean b) {
        this.wrapTextProperty().setValue(b);
    }
    
    public final boolean isWrapText() {
        return this.wrapTextProperty().getValue();
    }
    
    public final ObjectProperty<Font> fontProperty() {
        return this.font;
    }
    
    public final void setFont(final Font value) {
        this.fontProperty().setValue(value);
    }
    
    public final Font getFont() {
        return this.fontProperty().getValue();
    }
    
    public final ObjectProperty<Duration> showDelayProperty() {
        return this.showDelayProperty;
    }
    
    public final void setShowDelay(final Duration duration) {
        this.showDelayProperty.set(duration);
    }
    
    public final Duration getShowDelay() {
        return this.showDelayProperty.get();
    }
    
    public final ObjectProperty<Duration> showDurationProperty() {
        return this.showDurationProperty;
    }
    
    public final void setShowDuration(final Duration duration) {
        this.showDurationProperty.set(duration);
    }
    
    public final Duration getShowDuration() {
        return this.showDurationProperty.get();
    }
    
    public final ObjectProperty<Duration> hideDelayProperty() {
        return this.hideDelayProperty;
    }
    
    public final void setHideDelay(final Duration duration) {
        this.hideDelayProperty.set(duration);
    }
    
    public final Duration getHideDelay() {
        return this.hideDelayProperty.get();
    }
    
    public final ObjectProperty<Node> graphicProperty() {
        return this.graphic;
    }
    
    public final void setGraphic(final Node value) {
        this.graphicProperty().setValue(value);
    }
    
    public final Node getGraphic() {
        return this.graphicProperty().getValue();
    }
    
    private StyleableStringProperty imageUrlProperty() {
        if (this.imageUrl == null) {
            this.imageUrl = new StyleableStringProperty() {
                StyleOrigin origin = StyleOrigin.USER;
                
                @Override
                public void applyStyle(final StyleOrigin origin, final String s) {
                    this.origin = origin;
                    if (Tooltip.this.graphic == null || !Tooltip.this.graphic.isBound()) {
                        super.applyStyle(origin, s);
                    }
                    this.origin = StyleOrigin.USER;
                }
                
                @Override
                protected void invalidated() {
                    final String value = super.get();
                    if (value == null) {
                        ((StyleableProperty)Tooltip.this.graphicProperty()).applyStyle(this.origin, null);
                    }
                    else {
                        final Node graphic = Tooltip.this.getGraphic();
                        if (graphic instanceof ImageView) {
                            final Image image = ((ImageView)graphic).getImage();
                            if (image != null && value.equals(image.getUrl())) {
                                return;
                            }
                        }
                        final Image cachedImage = StyleManager.getInstance().getCachedImage(value);
                        if (cachedImage != null) {
                            ((StyleableProperty)Tooltip.this.graphicProperty()).applyStyle(this.origin, new ImageView(cachedImage));
                        }
                    }
                }
                
                @Override
                public String get() {
                    final Node graphic = Tooltip.this.getGraphic();
                    if (graphic instanceof ImageView) {
                        final Image image = ((ImageView)graphic).getImage();
                        if (image != null) {
                            return image.getUrl();
                        }
                    }
                    return null;
                }
                
                @Override
                public StyleOrigin getStyleOrigin() {
                    return (Tooltip.this.graphic != null) ? ((StyleableProperty)Tooltip.this.graphic).getStyleOrigin() : null;
                }
                
                @Override
                public Object getBean() {
                    return Tooltip.this;
                }
                
                @Override
                public String getName() {
                    return "imageUrl";
                }
                
                @Override
                public CssMetaData<CSSBridge, String> getCssMetaData() {
                    return Tooltip.GRAPHIC;
                }
            };
        }
        return this.imageUrl;
    }
    
    public final ObjectProperty<ContentDisplay> contentDisplayProperty() {
        return this.contentDisplay;
    }
    
    public final void setContentDisplay(final ContentDisplay value) {
        this.contentDisplayProperty().setValue(value);
    }
    
    public final ContentDisplay getContentDisplay() {
        return this.contentDisplayProperty().getValue();
    }
    
    public final DoubleProperty graphicTextGapProperty() {
        return this.graphicTextGap;
    }
    
    public final void setGraphicTextGap(final double d) {
        this.graphicTextGapProperty().setValue(d);
    }
    
    public final double getGraphicTextGap() {
        return this.graphicTextGapProperty().getValue();
    }
    
    final void setActivated(final boolean b) {
        this.activated.set(b);
    }
    
    public final boolean isActivated() {
        return this.activated.get();
    }
    
    public final ReadOnlyBooleanProperty activatedProperty() {
        return this.activated.getReadOnlyProperty();
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TooltipSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return Tooltip.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    public Styleable getStyleableParent() {
        if (Tooltip.BEHAVIOR.hoveredNode == null) {
            return super.getStyleableParent();
        }
        return Tooltip.BEHAVIOR.hoveredNode;
    }
    
    static {
        Tooltip.TOOLTIP_PROP_KEY = "javafx.scene.control.Tooltip";
        Tooltip.TOOLTIP_XOFFSET = 10;
        Tooltip.TOOLTIP_YOFFSET = 7;
        Tooltip.BEHAVIOR = new TooltipBehavior(false);
        FONT = new FontCssMetaData<CSSBridge>(Font.getDefault()) {
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.fontProperty().isBound();
            }
            
            public StyleableProperty<Font> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<Font>)(StyleableProperty)cssBridge.tooltip.fontProperty();
            }
        };
        TEXT_ALIGNMENT = new CssMetaData<CSSBridge, TextAlignment>((StyleConverter)new EnumConverter(TextAlignment.class), TextAlignment.LEFT) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.textAlignmentProperty().isBound();
            }
            
            @Override
            public StyleableProperty<TextAlignment> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<TextAlignment>)(StyleableProperty)cssBridge.tooltip.textAlignmentProperty();
            }
        };
        TEXT_OVERRUN = new CssMetaData<CSSBridge, OverrunStyle>((StyleConverter)new EnumConverter(OverrunStyle.class), OverrunStyle.ELLIPSIS) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.textOverrunProperty().isBound();
            }
            
            @Override
            public StyleableProperty<OverrunStyle> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<OverrunStyle>)(StyleableProperty)cssBridge.tooltip.textOverrunProperty();
            }
        };
        WRAP_TEXT = new CssMetaData<CSSBridge, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.wrapTextProperty().isBound();
            }
            
            @Override
            public StyleableProperty<Boolean> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<Boolean>)cssBridge.tooltip.wrapTextProperty();
            }
        };
        GRAPHIC = new CssMetaData<CSSBridge, String>((StyleConverter)StringConverter.getInstance()) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.graphicProperty().isBound();
            }
            
            @Override
            public StyleableProperty<String> getStyleableProperty(final CSSBridge cssBridge) {
                return cssBridge.tooltip.imageUrlProperty();
            }
        };
        CONTENT_DISPLAY = new CssMetaData<CSSBridge, ContentDisplay>((StyleConverter)new EnumConverter(ContentDisplay.class), ContentDisplay.LEFT) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.contentDisplayProperty().isBound();
            }
            
            @Override
            public StyleableProperty<ContentDisplay> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<ContentDisplay>)(StyleableProperty)cssBridge.tooltip.contentDisplayProperty();
            }
        };
        GRAPHIC_TEXT_GAP = new CssMetaData<CSSBridge, Number>((StyleConverter)SizeConverter.getInstance(), (Number)4.0) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.graphicTextGapProperty().isBound();
            }
            
            @Override
            public StyleableProperty<Number> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<Number>)cssBridge.tooltip.graphicTextGapProperty();
            }
        };
        SHOW_DELAY = new CssMetaData<CSSBridge, Duration>((StyleConverter)DurationConverter.getInstance(), new Duration(1000.0)) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.showDelayProperty().isBound();
            }
            
            @Override
            public StyleableProperty<Duration> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<Duration>)(StyleableProperty)cssBridge.tooltip.showDelayProperty();
            }
        };
        SHOW_DURATION = new CssMetaData<CSSBridge, Duration>((StyleConverter)DurationConverter.getInstance(), new Duration(5000.0)) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.showDurationProperty().isBound();
            }
            
            @Override
            public StyleableProperty<Duration> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<Duration>)(StyleableProperty)cssBridge.tooltip.showDurationProperty();
            }
        };
        HIDE_DELAY = new CssMetaData<CSSBridge, Duration>((StyleConverter)DurationConverter.getInstance(), new Duration(200.0)) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.tooltip.hideDelayProperty().isBound();
            }
            
            @Override
            public StyleableProperty<Duration> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<Duration>)(StyleableProperty)cssBridge.tooltip.hideDelayProperty();
            }
        };
        final ArrayList<CssMetaData<CSSBridge, TextAlignment>> list = new ArrayList<CssMetaData<CSSBridge, TextAlignment>>((Collection<? extends CssMetaData<CSSBridge, TextAlignment>>)PopupControl.getClassCssMetaData());
        list.add(Tooltip.FONT);
        list.add((CssMetaData<CSSBridge, Font>)Tooltip.TEXT_ALIGNMENT);
        list.add((CssMetaData<CSSBridge, Font>)Tooltip.TEXT_OVERRUN);
        list.add((CssMetaData<CSSBridge, Font>)Tooltip.WRAP_TEXT);
        list.add((CssMetaData<CSSBridge, Font>)Tooltip.GRAPHIC);
        list.add((CssMetaData<CSSBridge, Font>)Tooltip.CONTENT_DISPLAY);
        list.add((CssMetaData<CSSBridge, Font>)Tooltip.GRAPHIC_TEXT_GAP);
        list.add((CssMetaData<CSSBridge, Font>)Tooltip.SHOW_DELAY);
        list.add((CssMetaData<CSSBridge, Font>)Tooltip.SHOW_DURATION);
        list.add((CssMetaData<CSSBridge, Font>)Tooltip.HIDE_DELAY);
        STYLEABLES = Collections.unmodifiableList((List<?>)list);
    }
    
    private final class CSSBridge extends PopupControl.CSSBridge
    {
        private Tooltip tooltip;
        
        CSSBridge() {
            this.tooltip = Tooltip.this;
            this.setAccessibleRole(AccessibleRole.TOOLTIP);
        }
    }
    
    private static class TooltipBehavior
    {
        private Timeline activationTimer;
        private Timeline hideTimer;
        private Timeline leftTimer;
        private Node hoveredNode;
        private Tooltip activatedTooltip;
        private Tooltip visibleTooltip;
        private double lastMouseX;
        private double lastMouseY;
        private boolean hideOnExit;
        private boolean cssForced;
        private EventHandler<MouseEvent> MOVE_HANDLER;
        private EventHandler<MouseEvent> LEAVING_HANDLER;
        private EventHandler<MouseEvent> KILL_HANDLER;
        static final /* synthetic */ boolean $assertionsDisabled;
        
        TooltipBehavior(final boolean hideOnExit) {
            this.activationTimer = new Timeline();
            this.hideTimer = new Timeline();
            this.leftTimer = new Timeline();
            this.cssForced = false;
            Tooltip tooltip;
            final Window window;
            final boolean b;
            final double opacity;
            this.MOVE_HANDLER = (mouseEvent -> {
                this.lastMouseX = mouseEvent.getScreenX();
                this.lastMouseY = mouseEvent.getScreenY();
                if (this.hideTimer.getStatus() == Animation.Status.RUNNING) {
                    return;
                }
                else {
                    this.hoveredNode = (Node)mouseEvent.getSource();
                    tooltip = this.hoveredNode.getProperties().get(Tooltip.TOOLTIP_PROP_KEY);
                    if (tooltip != null) {
                        this.getWindow(this.hoveredNode);
                        this.isWindowHierarchyVisible(this.hoveredNode);
                        if (window != null && b) {
                            if (this.leftTimer.getStatus() == Animation.Status.RUNNING) {
                                if (this.visibleTooltip != null) {
                                    this.visibleTooltip.hide();
                                }
                                (this.visibleTooltip = tooltip).show(window, mouseEvent.getScreenX() + Tooltip.TOOLTIP_XOFFSET, mouseEvent.getScreenY() + Tooltip.TOOLTIP_YOFFSET);
                                this.leftTimer.stop();
                                if (tooltip.getShowDuration() != null) {
                                    this.hideTimer.getKeyFrames().setAll(new KeyFrame(tooltip.getShowDuration(), new KeyValue[0]));
                                }
                                this.hideTimer.playFromStart();
                            }
                            else {
                                if (!this.cssForced) {
                                    tooltip.getOpacity();
                                    tooltip.setOpacity(0.0);
                                    tooltip.show(window);
                                    tooltip.hide();
                                    tooltip.setOpacity(opacity);
                                    this.cssForced = true;
                                }
                                tooltip.setActivated(true);
                                this.activatedTooltip = tooltip;
                                this.activationTimer.stop();
                                if (tooltip.getShowDelay() != null) {
                                    this.activationTimer.getKeyFrames().setAll(new KeyFrame(tooltip.getShowDelay(), new KeyValue[0]));
                                }
                                this.activationTimer.playFromStart();
                            }
                        }
                    }
                    return;
                }
            });
            Tooltip tooltip2;
            this.LEAVING_HANDLER = (mouseEvent2 -> {
                if (this.activationTimer.getStatus() == Animation.Status.RUNNING) {
                    this.activationTimer.stop();
                }
                else if (this.hideTimer.getStatus() == Animation.Status.RUNNING) {
                    if (!TooltipBehavior.$assertionsDisabled && this.visibleTooltip == null) {
                        throw new AssertionError();
                    }
                    else {
                        this.hideTimer.stop();
                        if (this.hideOnExit) {
                            this.visibleTooltip.hide();
                        }
                        tooltip2 = ((Node)mouseEvent2.getSource()).getProperties().get(Tooltip.TOOLTIP_PROP_KEY);
                        if (tooltip2 != null) {
                            if (tooltip2.getHideDelay() != null) {
                                this.leftTimer.getKeyFrames().setAll(new KeyFrame(tooltip2.getHideDelay(), new KeyValue[0]));
                            }
                            this.leftTimer.playFromStart();
                        }
                    }
                }
                this.hoveredNode = null;
                this.activatedTooltip = null;
                if (this.hideOnExit) {
                    this.visibleTooltip = null;
                }
                return;
            });
            this.KILL_HANDLER = (p0 -> {
                this.activationTimer.stop();
                this.hideTimer.stop();
                this.leftTimer.stop();
                if (this.visibleTooltip != null) {
                    this.visibleTooltip.hide();
                }
                this.hoveredNode = null;
                this.activatedTooltip = null;
                this.visibleTooltip = null;
                return;
            });
            this.hideOnExit = hideOnExit;
            final Window window2;
            final boolean b2;
            double lastMouseX;
            double lastMouseY;
            final NodeOrientation nodeOrientation;
            this.activationTimer.setOnFinished(p0 -> {
                if (!TooltipBehavior.$assertionsDisabled && this.activatedTooltip == null) {
                    throw new AssertionError();
                }
                else {
                    this.getWindow(this.hoveredNode);
                    this.isWindowHierarchyVisible(this.hoveredNode);
                    if (window2 != null && window2.isShowing() && b2) {
                        lastMouseX = this.lastMouseX;
                        lastMouseY = this.lastMouseY;
                        this.hoveredNode.getEffectiveNodeOrientation();
                        this.activatedTooltip.getScene().setNodeOrientation(nodeOrientation);
                        if (nodeOrientation == NodeOrientation.RIGHT_TO_LEFT) {
                            lastMouseX -= this.activatedTooltip.getWidth();
                        }
                        this.activatedTooltip.show(window2, lastMouseX + Tooltip.TOOLTIP_XOFFSET, lastMouseY + Tooltip.TOOLTIP_YOFFSET);
                        if (lastMouseY + Tooltip.TOOLTIP_YOFFSET > this.activatedTooltip.getAnchorY()) {
                            this.activatedTooltip.hide();
                            this.activatedTooltip.show(window2, lastMouseX + Tooltip.TOOLTIP_XOFFSET, lastMouseY - this.activatedTooltip.getHeight());
                        }
                        this.visibleTooltip = this.activatedTooltip;
                        this.hoveredNode = null;
                        if (this.activatedTooltip.getShowDuration() != null) {
                            this.hideTimer.getKeyFrames().setAll(new KeyFrame(this.activatedTooltip.getShowDuration(), new KeyValue[0]));
                        }
                        this.hideTimer.playFromStart();
                    }
                    this.activatedTooltip.setActivated(false);
                    this.activatedTooltip = null;
                    return;
                }
            });
            this.hideTimer.setOnFinished(p0 -> {
                if (!TooltipBehavior.$assertionsDisabled && this.visibleTooltip == null) {
                    throw new AssertionError();
                }
                else {
                    this.visibleTooltip.hide();
                    this.visibleTooltip = null;
                    this.hoveredNode = null;
                    return;
                }
            });
            this.leftTimer.setOnFinished(p1 -> {
                if (!hideOnExit) {
                    if (!TooltipBehavior.$assertionsDisabled && this.visibleTooltip == null) {
                        throw new AssertionError();
                    }
                    else {
                        this.visibleTooltip.hide();
                        this.visibleTooltip = null;
                        this.hoveredNode = null;
                    }
                }
            });
        }
        
        private void install(final Node node, final Tooltip tooltip) {
            if (node == null) {
                return;
            }
            node.addEventHandler(MouseEvent.MOUSE_MOVED, this.MOVE_HANDLER);
            node.addEventHandler(MouseEvent.MOUSE_EXITED, this.LEAVING_HANDLER);
            node.addEventHandler(MouseEvent.MOUSE_PRESSED, this.KILL_HANDLER);
            node.getProperties().put(Tooltip.TOOLTIP_PROP_KEY, tooltip);
        }
        
        private void uninstall(final Node node) {
            if (node == null) {
                return;
            }
            node.removeEventHandler(MouseEvent.MOUSE_MOVED, this.MOVE_HANDLER);
            node.removeEventHandler(MouseEvent.MOUSE_EXITED, this.LEAVING_HANDLER);
            node.removeEventHandler(MouseEvent.MOUSE_PRESSED, this.KILL_HANDLER);
            final Tooltip tooltip = node.getProperties().get(Tooltip.TOOLTIP_PROP_KEY);
            if (tooltip != null) {
                node.getProperties().remove(Tooltip.TOOLTIP_PROP_KEY);
                if (tooltip.equals(this.visibleTooltip) || tooltip.equals(this.activatedTooltip)) {
                    this.KILL_HANDLER.handle(null);
                }
            }
        }
        
        private Window getWindow(final Node node) {
            final Scene scene = (node == null) ? null : node.getScene();
            return (scene == null) ? null : scene.getWindow();
        }
        
        private boolean isWindowHierarchyVisible(final Node node) {
            boolean visible = node != null;
            for (Parent parent = (node == null) ? null : node.getParent(); parent != null && visible; visible = parent.isVisible(), parent = parent.getParent()) {}
            return visible;
        }
    }
}
