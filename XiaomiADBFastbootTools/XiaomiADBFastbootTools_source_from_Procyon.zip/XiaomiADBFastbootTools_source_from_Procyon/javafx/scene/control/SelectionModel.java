// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyIntegerWrapper;

public abstract class SelectionModel<T>
{
    private ReadOnlyIntegerWrapper selectedIndex;
    private ReadOnlyObjectWrapper<T> selectedItem;
    
    public final ReadOnlyIntegerProperty selectedIndexProperty() {
        return this.selectedIndex.getReadOnlyProperty();
    }
    
    protected final void setSelectedIndex(final int n) {
        this.selectedIndex.set(n);
    }
    
    public final int getSelectedIndex() {
        return this.selectedIndexProperty().get();
    }
    
    public final ReadOnlyObjectProperty<T> selectedItemProperty() {
        return this.selectedItem.getReadOnlyProperty();
    }
    
    protected final void setSelectedItem(final T t) {
        this.selectedItem.set(t);
    }
    
    public final T getSelectedItem() {
        return this.selectedItemProperty().get();
    }
    
    public SelectionModel() {
        this.selectedIndex = new ReadOnlyIntegerWrapper(this, "selectedIndex", -1);
        this.selectedItem = new ReadOnlyObjectWrapper<T>(this, "selectedItem");
    }
    
    public abstract void clearAndSelect(final int p0);
    
    public abstract void select(final int p0);
    
    public abstract void select(final T p0);
    
    public abstract void clearSelection(final int p0);
    
    public abstract void clearSelection();
    
    public abstract boolean isSelected(final int p0);
    
    public abstract boolean isEmpty();
    
    public abstract void selectPrevious();
    
    public abstract void selectNext();
    
    public abstract void selectFirst();
    
    public abstract void selectLast();
}
