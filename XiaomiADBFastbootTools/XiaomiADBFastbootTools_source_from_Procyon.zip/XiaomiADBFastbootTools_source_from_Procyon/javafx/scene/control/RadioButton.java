// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.AccessibleAttribute;
import javafx.scene.control.skin.RadioButtonSkin;
import javafx.css.StyleOrigin;
import javafx.geometry.Pos;
import javafx.css.StyleableProperty;
import javafx.scene.AccessibleRole;

public class RadioButton extends ToggleButton
{
    private static final String DEFAULT_STYLE_CLASS = "radio-button";
    
    public RadioButton() {
        this.initialize();
    }
    
    public RadioButton(final String text) {
        this.setText(text);
        this.initialize();
    }
    
    private void initialize() {
        this.getStyleClass().setAll("radio-button");
        this.setAccessibleRole(AccessibleRole.RADIO_BUTTON);
        ((StyleableProperty)this.alignmentProperty()).applyStyle(null, Pos.CENTER_LEFT);
    }
    
    @Override
    public void fire() {
        if (this.getToggleGroup() == null || !this.isSelected()) {
            super.fire();
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new RadioButtonSkin(this);
    }
    
    @Override
    protected Pos getInitialAlignment() {
        return Pos.CENTER_LEFT;
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case SELECTED: {
                return this.isSelected();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
}
