// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Map;
import javafx.collections.FXCollections;
import java.util.HashMap;
import javafx.beans.property.ReadOnlyObjectProperty;
import java.util.List;
import com.sun.javafx.collections.VetoableListDecorator;
import java.util.Iterator;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import javafx.collections.ObservableMap;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.ObservableList;

public class ToggleGroup
{
    private final ObservableList<Toggle> toggles;
    private final ReadOnlyObjectWrapper<Toggle> selectedToggle;
    private static final Object USER_DATA_KEY;
    private ObservableMap<Object, Object> properties;
    
    public ToggleGroup() {
        this.toggles = new VetoableListDecorator<Toggle>((ObservableList)new TrackableObservableList<Toggle>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<Toggle> change) {
                while (change.next()) {
                    final Iterator<Toggle> iterator = change.getRemoved().iterator();
                    while (iterator.hasNext()) {
                        if (iterator.next().isSelected()) {
                            ToggleGroup.this.selectToggle(null);
                        }
                    }
                    for (final Toggle toggle : change.getAddedSubList()) {
                        if (!ToggleGroup.this.equals(toggle.getToggleGroup())) {
                            if (toggle.getToggleGroup() != null) {
                                toggle.getToggleGroup().getToggles().remove(toggle);
                            }
                            toggle.setToggleGroup(ToggleGroup.this);
                        }
                    }
                    for (final Toggle toggle2 : change.getAddedSubList()) {
                        if (toggle2.isSelected()) {
                            ToggleGroup.this.selectToggle(toggle2);
                            break;
                        }
                    }
                }
            }
        }) {
            @Override
            protected void onProposedChange(final List<Toggle> list, final int... array) {
                for (final Toggle toggle : list) {
                    if (array[0] == 0 && array[1] == this.size()) {
                        break;
                    }
                    if (ToggleGroup.this.toggles.contains(toggle)) {
                        throw new IllegalArgumentException("Duplicate toggles are not allow in a ToggleGroup.");
                    }
                }
            }
        };
        this.selectedToggle = new ReadOnlyObjectWrapper<Toggle>() {
            @Override
            public void set(final Toggle toggle) {
                if (this.isBound()) {
                    throw new RuntimeException("A bound value cannot be set.");
                }
                final Toggle toggle2 = this.get();
                if (toggle2 == toggle) {
                    return;
                }
                if (ToggleGroup.this.setSelected(toggle, true) || (toggle != null && toggle.getToggleGroup() == ToggleGroup.this) || toggle == null) {
                    if (toggle2 == null || toggle2.getToggleGroup() == ToggleGroup.this || !toggle2.isSelected()) {
                        ToggleGroup.this.setSelected(toggle2, false);
                    }
                    super.set(toggle);
                }
            }
        };
    }
    
    public final ObservableList<Toggle> getToggles() {
        return this.toggles;
    }
    
    public final void selectToggle(final Toggle toggle) {
        this.selectedToggle.set(toggle);
    }
    
    public final Toggle getSelectedToggle() {
        return this.selectedToggle.get();
    }
    
    public final ReadOnlyObjectProperty<Toggle> selectedToggleProperty() {
        return this.selectedToggle.getReadOnlyProperty();
    }
    
    private boolean setSelected(final Toggle toggle, final boolean selected) {
        if (toggle != null && toggle.getToggleGroup() == this && !toggle.selectedProperty().isBound()) {
            toggle.setSelected(selected);
            return true;
        }
        return false;
    }
    
    final void clearSelectedToggle() {
        if (!this.selectedToggle.getValue().isSelected()) {
            final Iterator<Toggle> iterator = this.getToggles().iterator();
            while (iterator.hasNext()) {
                if (iterator.next().isSelected()) {
                    return;
                }
            }
        }
        this.selectedToggle.set(null);
    }
    
    public final ObservableMap<Object, Object> getProperties() {
        if (this.properties == null) {
            this.properties = FXCollections.observableMap(new HashMap<Object, Object>());
        }
        return this.properties;
    }
    
    public boolean hasProperties() {
        return this.properties != null && !this.properties.isEmpty();
    }
    
    public void setUserData(final Object o) {
        this.getProperties().put(ToggleGroup.USER_DATA_KEY, o);
    }
    
    public Object getUserData() {
        return this.getProperties().get(ToggleGroup.USER_DATA_KEY);
    }
    
    static {
        USER_DATA_KEY = new Object();
    }
}
