// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.SizeConverter;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.ScrollBarSkin;
import com.sun.javafx.util.Utils;
import javafx.css.StyleableDoubleProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.scene.AccessibleRole;
import javafx.css.PseudoClass;
import javafx.geometry.Orientation;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.DoubleProperty;

public class ScrollBar extends Control
{
    private DoubleProperty min;
    private DoubleProperty max;
    private DoubleProperty value;
    private ObjectProperty<Orientation> orientation;
    private DoubleProperty unitIncrement;
    private DoubleProperty blockIncrement;
    private DoubleProperty visibleAmount;
    private static final String DEFAULT_STYLE_CLASS = "scroll-bar";
    private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE;
    private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE;
    
    public ScrollBar() {
        this.setWidth(20.0);
        this.setHeight(100.0);
        this.getStyleClass().setAll("scroll-bar");
        this.setAccessibleRole(AccessibleRole.SCROLL_BAR);
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
        this.pseudoClassStateChanged(ScrollBar.HORIZONTAL_PSEUDOCLASS_STATE, true);
    }
    
    public final void setMin(final double n) {
        this.minProperty().set(n);
    }
    
    public final double getMin() {
        return (this.min == null) ? 0.0 : this.min.get();
    }
    
    public final DoubleProperty minProperty() {
        if (this.min == null) {
            this.min = new SimpleDoubleProperty(this, "min");
        }
        return this.min;
    }
    
    public final void setMax(final double n) {
        this.maxProperty().set(n);
    }
    
    public final double getMax() {
        return (this.max == null) ? 100.0 : this.max.get();
    }
    
    public final DoubleProperty maxProperty() {
        if (this.max == null) {
            this.max = new SimpleDoubleProperty(this, "max", 100.0);
        }
        return this.max;
    }
    
    public final void setValue(final double n) {
        this.valueProperty().set(n);
    }
    
    public final double getValue() {
        return (this.value == null) ? 0.0 : this.value.get();
    }
    
    public final DoubleProperty valueProperty() {
        if (this.value == null) {
            this.value = new SimpleDoubleProperty(this, "value");
        }
        return this.value;
    }
    
    public final void setOrientation(final Orientation orientation) {
        this.orientationProperty().set(orientation);
    }
    
    public final Orientation getOrientation() {
        return (this.orientation == null) ? Orientation.HORIZONTAL : this.orientation.get();
    }
    
    public final ObjectProperty<Orientation> orientationProperty() {
        if (this.orientation == null) {
            this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL) {
                @Override
                protected void invalidated() {
                    final boolean b = this.get() == Orientation.VERTICAL;
                    ScrollBar.this.pseudoClassStateChanged(ScrollBar.VERTICAL_PSEUDOCLASS_STATE, b);
                    ScrollBar.this.pseudoClassStateChanged(ScrollBar.HORIZONTAL_PSEUDOCLASS_STATE, !b);
                }
                
                @Override
                public CssMetaData<ScrollBar, Orientation> getCssMetaData() {
                    return StyleableProperties.ORIENTATION;
                }
                
                @Override
                public Object getBean() {
                    return ScrollBar.this;
                }
                
                @Override
                public String getName() {
                    return "orientation";
                }
            };
        }
        return this.orientation;
    }
    
    public final void setUnitIncrement(final double n) {
        this.unitIncrementProperty().set(n);
    }
    
    public final double getUnitIncrement() {
        return (this.unitIncrement == null) ? 1.0 : this.unitIncrement.get();
    }
    
    public final DoubleProperty unitIncrementProperty() {
        if (this.unitIncrement == null) {
            this.unitIncrement = new StyleableDoubleProperty(1.0) {
                @Override
                public CssMetaData<ScrollBar, Number> getCssMetaData() {
                    return StyleableProperties.UNIT_INCREMENT;
                }
                
                @Override
                public Object getBean() {
                    return ScrollBar.this;
                }
                
                @Override
                public String getName() {
                    return "unitIncrement";
                }
            };
        }
        return this.unitIncrement;
    }
    
    public final void setBlockIncrement(final double n) {
        this.blockIncrementProperty().set(n);
    }
    
    public final double getBlockIncrement() {
        return (this.blockIncrement == null) ? 10.0 : this.blockIncrement.get();
    }
    
    public final DoubleProperty blockIncrementProperty() {
        if (this.blockIncrement == null) {
            this.blockIncrement = new StyleableDoubleProperty(10.0) {
                @Override
                public CssMetaData<ScrollBar, Number> getCssMetaData() {
                    return StyleableProperties.BLOCK_INCREMENT;
                }
                
                @Override
                public Object getBean() {
                    return ScrollBar.this;
                }
                
                @Override
                public String getName() {
                    return "blockIncrement";
                }
            };
        }
        return this.blockIncrement;
    }
    
    public final void setVisibleAmount(final double n) {
        this.visibleAmountProperty().set(n);
    }
    
    public final double getVisibleAmount() {
        return (this.visibleAmount == null) ? 15.0 : this.visibleAmount.get();
    }
    
    public final DoubleProperty visibleAmountProperty() {
        if (this.visibleAmount == null) {
            this.visibleAmount = new SimpleDoubleProperty(this, "visibleAmount");
        }
        return this.visibleAmount;
    }
    
    public void adjustValue(final double n) {
        final double d1 = (this.getMax() - this.getMin()) * Utils.clamp(0.0, n, 1.0) + this.getMin();
        if (Double.compare(d1, this.getValue()) != 0) {
            double n2;
            if (d1 > this.getValue()) {
                n2 = this.getValue() + this.getBlockIncrement();
            }
            else {
                n2 = this.getValue() - this.getBlockIncrement();
            }
            final boolean b = n > (this.getValue() - this.getMin()) / (this.getMax() - this.getMin());
            if (b && n2 > d1) {
                n2 = d1;
            }
            if (!b && n2 < d1) {
                n2 = d1;
            }
            this.setValue(Utils.clamp(this.getMin(), n2, this.getMax()));
        }
    }
    
    public void increment() {
        this.setValue(Utils.clamp(this.getMin(), this.getValue() + this.getUnitIncrement(), this.getMax()));
    }
    
    public void decrement() {
        this.setValue(Utils.clamp(this.getMin(), this.getValue() - this.getUnitIncrement(), this.getMax()));
    }
    
    private void blockIncrement() {
        this.adjustValue(this.getValue() + this.getBlockIncrement());
    }
    
    private void blockDecrement() {
        this.adjustValue(this.getValue() - this.getBlockIncrement());
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ScrollBarSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case VALUE: {
                return this.getValue();
            }
            case MAX_VALUE: {
                return this.getMax();
            }
            case MIN_VALUE: {
                return this.getMin();
            }
            case ORIENTATION: {
                return this.getOrientation();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case INCREMENT: {
                this.increment();
                break;
            }
            case DECREMENT: {
                this.decrement();
                break;
            }
            case BLOCK_INCREMENT: {
                this.blockIncrement();
                break;
            }
            case BLOCK_DECREMENT: {
                this.blockDecrement();
                break;
            }
            case SET_VALUE: {
                final Double n = (Double)array[0];
                if (n != null) {
                    this.setValue(n);
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    static {
        VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
        HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<ScrollBar, Orientation> ORIENTATION;
        private static final CssMetaData<ScrollBar, Number> UNIT_INCREMENT;
        private static final CssMetaData<ScrollBar, Number> BLOCK_INCREMENT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            ORIENTATION = new CssMetaData<ScrollBar, Orientation>((StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL) {
                @Override
                public Orientation getInitialValue(final ScrollBar scrollBar) {
                    return scrollBar.getOrientation();
                }
                
                @Override
                public boolean isSettable(final ScrollBar scrollBar) {
                    return scrollBar.orientation == null || !scrollBar.orientation.isBound();
                }
                
                @Override
                public StyleableProperty<Orientation> getStyleableProperty(final ScrollBar scrollBar) {
                    return (StyleableProperty<Orientation>)(StyleableProperty)scrollBar.orientationProperty();
                }
            };
            UNIT_INCREMENT = new CssMetaData<ScrollBar, Number>((StyleConverter)SizeConverter.getInstance(), (Number)1.0) {
                @Override
                public boolean isSettable(final ScrollBar scrollBar) {
                    return scrollBar.unitIncrement == null || !scrollBar.unitIncrement.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ScrollBar scrollBar) {
                    return (StyleableProperty<Number>)scrollBar.unitIncrementProperty();
                }
            };
            BLOCK_INCREMENT = new CssMetaData<ScrollBar, Number>((StyleConverter)SizeConverter.getInstance(), (Number)10.0) {
                @Override
                public boolean isSettable(final ScrollBar scrollBar) {
                    return scrollBar.blockIncrement == null || !scrollBar.blockIncrement.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ScrollBar scrollBar) {
                    return (StyleableProperty<Number>)scrollBar.blockIncrementProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.ORIENTATION);
            list.add(StyleableProperties.UNIT_INCREMENT);
            list.add(StyleableProperties.BLOCK_INCREMENT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
