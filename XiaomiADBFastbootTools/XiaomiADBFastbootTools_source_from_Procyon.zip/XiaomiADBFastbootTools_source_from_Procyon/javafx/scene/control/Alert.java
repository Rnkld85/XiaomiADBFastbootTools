// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.Observable;
import javafx.collections.ObservableList;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.NamedArg;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.beans.InvalidationListener;
import java.lang.ref.WeakReference;

public class Alert extends Dialog<ButtonType>
{
    private WeakReference<DialogPane> dialogPaneRef;
    private boolean installingDefaults;
    private boolean hasCustomButtons;
    private boolean hasCustomTitle;
    private boolean hasCustomHeaderText;
    private final InvalidationListener headerTextListener;
    private final InvalidationListener titleListener;
    private final ListChangeListener<ButtonType> buttonsListener;
    private final ObjectProperty<AlertType> alertType;
    
    public Alert(@NamedArg("alertType") final AlertType alertType) {
        this(alertType, "", new ButtonType[0]);
    }
    
    public Alert(@NamedArg("alertType") final AlertType alertType, @NamedArg("contentText") final String contentText, @NamedArg("buttonTypes") final ButtonType... array) {
        this.installingDefaults = false;
        this.hasCustomButtons = false;
        this.hasCustomTitle = false;
        this.hasCustomHeaderText = false;
        this.headerTextListener = (p0 -> {
            if (!this.installingDefaults) {
                this.hasCustomHeaderText = true;
            }
            return;
        });
        this.titleListener = (p0 -> {
            if (!this.installingDefaults) {
                this.hasCustomTitle = true;
            }
            return;
        });
        this.buttonsListener = (p0 -> {
            if (!this.installingDefaults) {
                this.hasCustomButtons = true;
            }
            return;
        });
        this.alertType = new SimpleObjectProperty<AlertType>((AlertType)null) {
            final String[] styleClasses = { "information", "warning", "error", "confirmation" };
            
            @Override
            protected void invalidated() {
                String title = "";
                String headerText = "";
                String s = "";
                ButtonType[] all = { ButtonType.OK };
                switch (Alert.this.getAlertType()) {
                    case NONE: {
                        all = new ButtonType[0];
                        break;
                    }
                    case INFORMATION: {
                        title = ControlResources.getString("Dialog.info.title");
                        headerText = ControlResources.getString("Dialog.info.header");
                        s = "information";
                        break;
                    }
                    case WARNING: {
                        title = ControlResources.getString("Dialog.warning.title");
                        headerText = ControlResources.getString("Dialog.warning.header");
                        s = "warning";
                        break;
                    }
                    case ERROR: {
                        title = ControlResources.getString("Dialog.error.title");
                        headerText = ControlResources.getString("Dialog.error.header");
                        s = "error";
                        break;
                    }
                    case CONFIRMATION: {
                        title = ControlResources.getString("Dialog.confirm.title");
                        headerText = ControlResources.getString("Dialog.confirm.header");
                        s = "confirmation";
                        all = new ButtonType[] { ButtonType.OK, ButtonType.CANCEL };
                        break;
                    }
                }
                Alert.this.installingDefaults = true;
                if (!Alert.this.hasCustomTitle) {
                    Alert.this.setTitle(title);
                }
                if (!Alert.this.hasCustomHeaderText) {
                    Alert.this.setHeaderText(headerText);
                }
                if (!Alert.this.hasCustomButtons) {
                    Alert.this.getButtonTypes().setAll(all);
                }
                final DialogPane dialogPane = Alert.this.getDialogPane();
                if (dialogPane != null) {
                    final ArrayList<Object> list = new ArrayList<Object>(Arrays.asList(this.styleClasses));
                    list.remove(s);
                    dialogPane.getStyleClass().removeAll(list);
                    if (!dialogPane.getStyleClass().contains(s)) {
                        dialogPane.getStyleClass().add(s);
                    }
                }
                Alert.this.installingDefaults = false;
            }
        };
        final DialogPane dialogPane = this.getDialogPane();
        dialogPane.setContentText(contentText);
        this.getDialogPane().getStyleClass().add("alert");
        this.dialogPaneRef = new WeakReference<DialogPane>(dialogPane);
        this.hasCustomButtons = (array != null && array.length > 0);
        if (this.hasCustomButtons) {
            for (int length = array.length, i = 0; i < length; ++i) {
                dialogPane.getButtonTypes().addAll(array[i]);
            }
        }
        this.setAlertType(alertType);
        this.dialogPaneProperty().addListener(p0 -> this.updateListeners());
        this.titleProperty().addListener(this.titleListener);
        this.updateListeners();
    }
    
    public final AlertType getAlertType() {
        return this.alertType.get();
    }
    
    public final void setAlertType(final AlertType value) {
        this.alertType.setValue(value);
    }
    
    public final ObjectProperty<AlertType> alertTypeProperty() {
        return this.alertType;
    }
    
    public final ObservableList<ButtonType> getButtonTypes() {
        return this.getDialogPane().getButtonTypes();
    }
    
    private void updateListeners() {
        final DialogPane dialogPane = this.dialogPaneRef.get();
        if (dialogPane != null) {
            dialogPane.headerTextProperty().removeListener(this.headerTextListener);
            dialogPane.getButtonTypes().removeListener(this.buttonsListener);
        }
        final DialogPane dialogPane2 = this.getDialogPane();
        if (dialogPane2 != null) {
            dialogPane2.headerTextProperty().addListener(this.headerTextListener);
            dialogPane2.getButtonTypes().addListener(this.buttonsListener);
        }
        this.dialogPaneRef = new WeakReference<DialogPane>(dialogPane2);
    }
    
    public enum AlertType
    {
        NONE, 
        INFORMATION, 
        WARNING, 
        CONFIRMATION, 
        ERROR;
    }
}
