// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.AccessibleAttribute;
import javafx.scene.AccessibleRole;

public class PasswordField extends TextField
{
    public PasswordField() {
        this.getStyleClass().add("password-field");
        this.setAccessibleRole(AccessibleRole.PASSWORD_FIELD);
    }
    
    @Override
    public void cut() {
    }
    
    @Override
    public void copy() {
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case TEXT: {
                return null;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
}
