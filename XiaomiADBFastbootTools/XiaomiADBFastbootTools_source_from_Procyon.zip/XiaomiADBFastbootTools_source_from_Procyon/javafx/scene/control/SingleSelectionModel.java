// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

public abstract class SingleSelectionModel<T> extends SelectionModel<T>
{
    @Override
    public void clearSelection() {
        this.updateSelectedIndex(-1);
    }
    
    @Override
    public void clearSelection(final int n) {
        if (this.getSelectedIndex() == n) {
            this.clearSelection();
        }
    }
    
    @Override
    public boolean isEmpty() {
        return this.getItemCount() == 0 || this.getSelectedIndex() == -1;
    }
    
    @Override
    public boolean isSelected(final int n) {
        return this.getSelectedIndex() == n;
    }
    
    @Override
    public void clearAndSelect(final int n) {
        this.select(n);
    }
    
    @Override
    public void select(final T t) {
        if (t == null) {
            this.setSelectedIndex(-1);
            this.setSelectedItem(null);
            return;
        }
        for (int itemCount = this.getItemCount(), i = 0; i < itemCount; ++i) {
            final T modelItem = this.getModelItem(i);
            if (modelItem != null && modelItem.equals(t)) {
                this.select(i);
                return;
            }
        }
        this.setSelectedItem(t);
    }
    
    @Override
    public void select(final int n) {
        if (n == -1) {
            this.clearSelection();
            return;
        }
        final int itemCount = this.getItemCount();
        if (itemCount == 0 || n < 0 || n >= itemCount) {
            return;
        }
        this.updateSelectedIndex(n);
    }
    
    @Override
    public void selectPrevious() {
        if (this.getSelectedIndex() == 0) {
            return;
        }
        this.select(this.getSelectedIndex() - 1);
    }
    
    @Override
    public void selectNext() {
        this.select(this.getSelectedIndex() + 1);
    }
    
    @Override
    public void selectFirst() {
        if (this.getItemCount() > 0) {
            this.select(0);
        }
    }
    
    @Override
    public void selectLast() {
        final int itemCount = this.getItemCount();
        if (itemCount > 0 && this.getSelectedIndex() < itemCount - 1) {
            this.select(itemCount - 1);
        }
    }
    
    protected abstract T getModelItem(final int p0);
    
    protected abstract int getItemCount();
    
    private void updateSelectedIndex(final int selectedIndex) {
        final int selectedIndex2 = this.getSelectedIndex();
        final Object selectedItem = this.getSelectedItem();
        this.setSelectedIndex(selectedIndex);
        if (selectedIndex2 != -1 || selectedItem == null || selectedIndex != -1) {
            this.setSelectedItem(this.getModelItem(this.getSelectedIndex()));
        }
    }
}
