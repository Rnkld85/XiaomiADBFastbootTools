// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.BooleanPropertyBase;
import javafx.beans.property.ObjectPropertyBase;
import javafx.scene.Node;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;

public class RadioMenuItem extends MenuItem implements Toggle
{
    private ObjectProperty<ToggleGroup> toggleGroup;
    private BooleanProperty selected;
    private static final String DEFAULT_STYLE_CLASS = "radio-menu-item";
    private static final String STYLE_CLASS_SELECTED = "selected";
    
    public RadioMenuItem() {
        this(null, null);
    }
    
    public RadioMenuItem(final String s) {
        this(s, null);
    }
    
    public RadioMenuItem(final String s, final Node node) {
        super(s, node);
        this.getStyleClass().add("radio-menu-item");
    }
    
    @Override
    public final void setToggleGroup(final ToggleGroup toggleGroup) {
        this.toggleGroupProperty().set(toggleGroup);
    }
    
    @Override
    public final ToggleGroup getToggleGroup() {
        return (this.toggleGroup == null) ? null : this.toggleGroup.get();
    }
    
    @Override
    public final ObjectProperty<ToggleGroup> toggleGroupProperty() {
        if (this.toggleGroup == null) {
            this.toggleGroup = new ObjectPropertyBase<ToggleGroup>() {
                private ToggleGroup old;
                
                @Override
                protected void invalidated() {
                    if (this.old != null) {
                        this.old.getToggles().remove(RadioMenuItem.this);
                    }
                    this.old = this.get();
                    if (this.get() != null && !this.get().getToggles().contains(RadioMenuItem.this)) {
                        this.get().getToggles().add(RadioMenuItem.this);
                    }
                }
                
                @Override
                public Object getBean() {
                    return RadioMenuItem.this;
                }
                
                @Override
                public String getName() {
                    return "toggleGroup";
                }
            };
        }
        return this.toggleGroup;
    }
    
    @Override
    public final void setSelected(final boolean b) {
        this.selectedProperty().set(b);
    }
    
    @Override
    public final boolean isSelected() {
        return this.selected != null && this.selected.get();
    }
    
    @Override
    public final BooleanProperty selectedProperty() {
        if (this.selected == null) {
            this.selected = new BooleanPropertyBase() {
                @Override
                protected void invalidated() {
                    if (RadioMenuItem.this.getToggleGroup() != null) {
                        if (this.get()) {
                            RadioMenuItem.this.getToggleGroup().selectToggle(RadioMenuItem.this);
                        }
                        else if (RadioMenuItem.this.getToggleGroup().getSelectedToggle() == RadioMenuItem.this) {
                            RadioMenuItem.this.getToggleGroup().clearSelectedToggle();
                        }
                    }
                    if (RadioMenuItem.this.isSelected()) {
                        RadioMenuItem.this.getStyleClass().add("selected");
                    }
                    else {
                        RadioMenuItem.this.getStyleClass().remove("selected");
                    }
                }
                
                @Override
                public Object getBean() {
                    return RadioMenuItem.this;
                }
                
                @Override
                public String getName() {
                    return "selected";
                }
            };
        }
        return this.selected;
    }
}
