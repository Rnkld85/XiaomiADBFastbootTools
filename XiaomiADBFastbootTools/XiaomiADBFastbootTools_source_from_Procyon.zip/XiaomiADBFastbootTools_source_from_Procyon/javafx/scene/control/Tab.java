// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.Observable;
import java.util.Collections;
import javafx.css.CssMetaData;
import javafx.css.PseudoClass;
import javafx.collections.ObservableSet;
import java.util.Set;
import java.util.Collection;
import java.util.ArrayList;
import javafx.event.EventDispatcher;
import javafx.event.EventDispatchChain;
import java.util.Map;
import java.util.HashMap;
import javafx.beans.property.BooleanPropertyBase;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleBooleanProperty;
import java.util.List;
import com.sun.javafx.scene.control.ControlAcceleratorSupport;
import javafx.beans.property.SimpleObjectProperty;
import java.lang.ref.WeakReference;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import com.sun.javafx.event.EventHandlerManager;
import javafx.collections.ObservableMap;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.beans.property.BooleanProperty;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.InvalidationListener;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.StringProperty;
import com.sun.javafx.beans.IDProperty;
import javafx.beans.DefaultProperty;
import javafx.css.Styleable;
import javafx.event.EventTarget;

@DefaultProperty("content")
@IDProperty("id")
public class Tab implements EventTarget, Styleable
{
    private StringProperty id;
    private StringProperty style;
    private ReadOnlyBooleanWrapper selected;
    private ReadOnlyObjectWrapper<TabPane> tabPane;
    private final InvalidationListener parentDisabledChangedListener;
    private StringProperty text;
    private ObjectProperty<Node> graphic;
    private ObjectProperty<Node> content;
    private ObjectProperty<ContextMenu> contextMenu;
    private BooleanProperty closable;
    public static final EventType<Event> SELECTION_CHANGED_EVENT;
    private ObjectProperty<EventHandler<Event>> onSelectionChanged;
    public static final EventType<Event> CLOSED_EVENT;
    private ObjectProperty<EventHandler<Event>> onClosed;
    private ObjectProperty<Tooltip> tooltip;
    private final ObservableList<String> styleClass;
    private BooleanProperty disable;
    private ReadOnlyBooleanWrapper disabled;
    public static final EventType<Event> TAB_CLOSE_REQUEST_EVENT;
    private ObjectProperty<EventHandler<Event>> onCloseRequest;
    private static final Object USER_DATA_KEY;
    private ObservableMap<Object, Object> properties;
    private final EventHandlerManager eventHandlerManager;
    private static final String DEFAULT_STYLE_CLASS = "tab";
    
    public Tab() {
        this(null);
    }
    
    public Tab(final String s) {
        this(s, null);
    }
    
    public Tab(final String text, final Node content) {
        this.parentDisabledChangedListener = (p0 -> this.updateDisabled());
        this.styleClass = FXCollections.observableArrayList();
        this.eventHandlerManager = new EventHandlerManager(this);
        this.setText(text);
        this.setContent(content);
        this.styleClass.addAll("tab");
    }
    
    public final void setId(final String s) {
        this.idProperty().set(s);
    }
    
    @Override
    public final String getId() {
        return (this.id == null) ? null : this.id.get();
    }
    
    public final StringProperty idProperty() {
        if (this.id == null) {
            this.id = new SimpleStringProperty(this, "id");
        }
        return this.id;
    }
    
    public final void setStyle(final String s) {
        this.styleProperty().set(s);
    }
    
    @Override
    public final String getStyle() {
        return (this.style == null) ? null : this.style.get();
    }
    
    public final StringProperty styleProperty() {
        if (this.style == null) {
            this.style = new SimpleStringProperty(this, "style");
        }
        return this.style;
    }
    
    final void setSelected(final boolean b) {
        this.selectedPropertyImpl().set(b);
    }
    
    public final boolean isSelected() {
        return this.selected != null && this.selected.get();
    }
    
    public final ReadOnlyBooleanProperty selectedProperty() {
        return this.selectedPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper selectedPropertyImpl() {
        if (this.selected == null) {
            this.selected = new ReadOnlyBooleanWrapper() {
                @Override
                protected void invalidated() {
                    if (Tab.this.getOnSelectionChanged() != null) {
                        Event.fireEvent(Tab.this, new Event(Tab.SELECTION_CHANGED_EVENT));
                    }
                }
                
                @Override
                public Object getBean() {
                    return Tab.this;
                }
                
                @Override
                public String getName() {
                    return "selected";
                }
            };
        }
        return this.selected;
    }
    
    final void setTabPane(final TabPane tabPane) {
        this.tabPanePropertyImpl().set(tabPane);
    }
    
    public final TabPane getTabPane() {
        return (this.tabPane == null) ? null : this.tabPane.get();
    }
    
    public final ReadOnlyObjectProperty<TabPane> tabPaneProperty() {
        return this.tabPanePropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<TabPane> tabPanePropertyImpl() {
        if (this.tabPane == null) {
            this.tabPane = new ReadOnlyObjectWrapper<TabPane>(this, "tabPane") {
                private WeakReference<TabPane> oldParent;
                
                @Override
                protected void invalidated() {
                    if (this.oldParent != null && this.oldParent.get() != null) {
                        this.oldParent.get().disabledProperty().removeListener(Tab.this.parentDisabledChangedListener);
                    }
                    Tab.this.updateDisabled();
                    final TabPane referent = this.get();
                    if (referent != null) {
                        referent.disabledProperty().addListener(Tab.this.parentDisabledChangedListener);
                    }
                    this.oldParent = new WeakReference<TabPane>(referent);
                    super.invalidated();
                }
            };
        }
        return this.tabPane;
    }
    
    public final void setText(final String s) {
        this.textProperty().set(s);
    }
    
    public final String getText() {
        return (this.text == null) ? null : this.text.get();
    }
    
    public final StringProperty textProperty() {
        if (this.text == null) {
            this.text = new SimpleStringProperty(this, "text");
        }
        return this.text;
    }
    
    public final void setGraphic(final Node node) {
        this.graphicProperty().set(node);
    }
    
    public final Node getGraphic() {
        return (this.graphic == null) ? null : this.graphic.get();
    }
    
    public final ObjectProperty<Node> graphicProperty() {
        if (this.graphic == null) {
            this.graphic = new SimpleObjectProperty<Node>(this, "graphic");
        }
        return this.graphic;
    }
    
    public final void setContent(final Node node) {
        this.contentProperty().set(node);
    }
    
    public final Node getContent() {
        return (this.content == null) ? null : this.content.get();
    }
    
    public final ObjectProperty<Node> contentProperty() {
        if (this.content == null) {
            this.content = new SimpleObjectProperty<Node>(this, "content") {
                @Override
                protected void invalidated() {
                    Tab.this.updateDisabled();
                }
            };
        }
        return this.content;
    }
    
    public final void setContextMenu(final ContextMenu contextMenu) {
        this.contextMenuProperty().set(contextMenu);
    }
    
    public final ContextMenu getContextMenu() {
        return (this.contextMenu == null) ? null : this.contextMenu.get();
    }
    
    public final ObjectProperty<ContextMenu> contextMenuProperty() {
        if (this.contextMenu == null) {
            this.contextMenu = new SimpleObjectProperty<ContextMenu>(this, "contextMenu") {
                private WeakReference<ContextMenu> contextMenuRef;
                
                @Override
                protected void invalidated() {
                    final ContextMenu contextMenu = (this.contextMenuRef == null) ? null : this.contextMenuRef.get();
                    if (contextMenu != null) {
                        ControlAcceleratorSupport.removeAcceleratorsFromScene(contextMenu.getItems(), Tab.this);
                    }
                    final ContextMenu referent = this.get();
                    this.contextMenuRef = new WeakReference<ContextMenu>(referent);
                    if (referent != null) {
                        ControlAcceleratorSupport.addAcceleratorsIntoScene(referent.getItems(), Tab.this);
                    }
                }
            };
        }
        return this.contextMenu;
    }
    
    public final void setClosable(final boolean b) {
        this.closableProperty().set(b);
    }
    
    public final boolean isClosable() {
        return this.closable == null || this.closable.get();
    }
    
    public final BooleanProperty closableProperty() {
        if (this.closable == null) {
            this.closable = new SimpleBooleanProperty(this, "closable", true);
        }
        return this.closable;
    }
    
    public final void setOnSelectionChanged(final EventHandler<Event> eventHandler) {
        this.onSelectionChangedProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnSelectionChanged() {
        return (this.onSelectionChanged == null) ? null : this.onSelectionChanged.get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onSelectionChangedProperty() {
        if (this.onSelectionChanged == null) {
            this.onSelectionChanged = new ObjectPropertyBase<EventHandler<Event>>() {
                @Override
                protected void invalidated() {
                    Tab.this.setEventHandler(Tab.SELECTION_CHANGED_EVENT, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Tab.this;
                }
                
                @Override
                public String getName() {
                    return "onSelectionChanged";
                }
            };
        }
        return this.onSelectionChanged;
    }
    
    public final void setOnClosed(final EventHandler<Event> eventHandler) {
        this.onClosedProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnClosed() {
        return (this.onClosed == null) ? null : this.onClosed.get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onClosedProperty() {
        if (this.onClosed == null) {
            this.onClosed = new ObjectPropertyBase<EventHandler<Event>>() {
                @Override
                protected void invalidated() {
                    Tab.this.setEventHandler(Tab.CLOSED_EVENT, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Tab.this;
                }
                
                @Override
                public String getName() {
                    return "onClosed";
                }
            };
        }
        return this.onClosed;
    }
    
    public final void setTooltip(final Tooltip value) {
        this.tooltipProperty().setValue(value);
    }
    
    public final Tooltip getTooltip() {
        return (this.tooltip == null) ? null : this.tooltip.getValue();
    }
    
    public final ObjectProperty<Tooltip> tooltipProperty() {
        if (this.tooltip == null) {
            this.tooltip = new SimpleObjectProperty<Tooltip>(this, "tooltip");
        }
        return this.tooltip;
    }
    
    public final void setDisable(final boolean b) {
        this.disableProperty().set(b);
    }
    
    public final boolean isDisable() {
        return this.disable != null && this.disable.get();
    }
    
    public final BooleanProperty disableProperty() {
        if (this.disable == null) {
            this.disable = new BooleanPropertyBase(false) {
                @Override
                protected void invalidated() {
                    Tab.this.updateDisabled();
                }
                
                @Override
                public Object getBean() {
                    return Tab.this;
                }
                
                @Override
                public String getName() {
                    return "disable";
                }
            };
        }
        return this.disable;
    }
    
    private final void setDisabled(final boolean b) {
        this.disabledPropertyImpl().set(b);
    }
    
    public final boolean isDisabled() {
        return this.disabled != null && this.disabled.get();
    }
    
    public final ReadOnlyBooleanProperty disabledProperty() {
        return this.disabledPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper disabledPropertyImpl() {
        if (this.disabled == null) {
            this.disabled = new ReadOnlyBooleanWrapper() {
                @Override
                public Object getBean() {
                    return Tab.this;
                }
                
                @Override
                public String getName() {
                    return "disabled";
                }
            };
        }
        return this.disabled;
    }
    
    private void updateDisabled() {
        final boolean b = this.isDisable() || (this.getTabPane() != null && this.getTabPane().isDisabled());
        this.setDisabled(b);
        final Node content = this.getContent();
        if (content != null) {
            content.setDisable(b);
        }
    }
    
    public final ObjectProperty<EventHandler<Event>> onCloseRequestProperty() {
        if (this.onCloseRequest == null) {
            this.onCloseRequest = new ObjectPropertyBase<EventHandler<Event>>() {
                @Override
                protected void invalidated() {
                    Tab.this.setEventHandler(Tab.TAB_CLOSE_REQUEST_EVENT, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Tab.this;
                }
                
                @Override
                public String getName() {
                    return "onCloseRequest";
                }
            };
        }
        return this.onCloseRequest;
    }
    
    public EventHandler<Event> getOnCloseRequest() {
        if (this.onCloseRequest == null) {
            return null;
        }
        return this.onCloseRequest.get();
    }
    
    public void setOnCloseRequest(final EventHandler<Event> eventHandler) {
        this.onCloseRequestProperty().set(eventHandler);
    }
    
    public final ObservableMap<Object, Object> getProperties() {
        if (this.properties == null) {
            this.properties = FXCollections.observableMap(new HashMap<Object, Object>());
        }
        return this.properties;
    }
    
    public boolean hasProperties() {
        return this.properties != null && !this.properties.isEmpty();
    }
    
    public void setUserData(final Object o) {
        this.getProperties().put(Tab.USER_DATA_KEY, o);
    }
    
    public Object getUserData() {
        return this.getProperties().get(Tab.USER_DATA_KEY);
    }
    
    @Override
    public ObservableList<String> getStyleClass() {
        return this.styleClass;
    }
    
    @Override
    public EventDispatchChain buildEventDispatchChain(final EventDispatchChain eventDispatchChain) {
        return eventDispatchChain.prepend(this.eventHandlerManager);
    }
    
     <E extends Event> void setEventHandler(final EventType<E> eventType, final EventHandler<E> eventHandler) {
        this.eventHandlerManager.setEventHandler(eventType, eventHandler);
    }
    
    Node lookup(final String s) {
        if (s == null) {
            return null;
        }
        Node node = null;
        if (this.getContent() != null) {
            node = this.getContent().lookup(s);
        }
        if (node == null && this.getGraphic() != null) {
            node = this.getGraphic().lookup(s);
        }
        return node;
    }
    
    List<Node> lookupAll(final String s) {
        final ArrayList<Object> list = (ArrayList<Object>)new ArrayList<Node>();
        if (this.getContent() != null) {
            final Set<Node> lookupAll = this.getContent().lookupAll(s);
            if (!lookupAll.isEmpty()) {
                list.addAll(lookupAll);
            }
        }
        if (this.getGraphic() != null) {
            final Set<Node> lookupAll2 = this.getGraphic().lookupAll(s);
            if (!lookupAll2.isEmpty()) {
                list.addAll(lookupAll2);
            }
        }
        return (List<Node>)list;
    }
    
    @Override
    public String getTypeSelector() {
        return "Tab";
    }
    
    @Override
    public Styleable getStyleableParent() {
        return this.getTabPane();
    }
    
    @Override
    public final ObservableSet<PseudoClass> getPseudoClassStates() {
        return FXCollections.emptyObservableSet();
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return Collections.emptyList();
    }
    
    static {
        SELECTION_CHANGED_EVENT = new EventType<Event>(Event.ANY, "SELECTION_CHANGED_EVENT");
        CLOSED_EVENT = new EventType<Event>(Event.ANY, "TAB_CLOSED");
        TAB_CLOSE_REQUEST_EVENT = new EventType<Event>(Event.ANY, "TAB_CLOSE_REQUEST_EVENT");
        USER_DATA_KEY = new Object();
    }
}
