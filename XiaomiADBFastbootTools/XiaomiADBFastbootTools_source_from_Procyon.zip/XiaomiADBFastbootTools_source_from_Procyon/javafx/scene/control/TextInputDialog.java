// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.Observable;
import javafx.application.Platform;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.geometry.Pos;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.scene.layout.Priority;
import javafx.beans.NamedArg;
import javafx.scene.layout.GridPane;

public class TextInputDialog extends Dialog<String>
{
    private final GridPane grid;
    private final Label label;
    private final TextField textField;
    private final String defaultValue;
    
    public TextInputDialog() {
        this("");
    }
    
    public TextInputDialog(@NamedArg("defaultValue") final String defaultValue) {
        final DialogPane dialogPane = this.getDialogPane();
        (this.textField = new TextField(defaultValue)).setMaxWidth(Double.MAX_VALUE);
        GridPane.setHgrow(this.textField, Priority.ALWAYS);
        GridPane.setFillWidth(this.textField, true);
        (this.label = DialogPane.createContentLabel(dialogPane.getContentText())).setPrefWidth(-1.0);
        this.label.textProperty().bind(dialogPane.contentTextProperty());
        this.defaultValue = defaultValue;
        (this.grid = new GridPane()).setHgap(10.0);
        this.grid.setMaxWidth(Double.MAX_VALUE);
        this.grid.setAlignment(Pos.CENTER_LEFT);
        dialogPane.contentTextProperty().addListener(p0 -> this.updateGrid());
        this.setTitle(ControlResources.getString("Dialog.confirm.title"));
        dialogPane.setHeaderText(ControlResources.getString("Dialog.confirm.header"));
        dialogPane.getStyleClass().add("text-input-dialog");
        dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        this.updateGrid();
        this.setResultConverter(buttonType -> (((buttonType == null) ? null : buttonType.getButtonData()) == ButtonBar.ButtonData.OK_DONE) ? this.textField.getText() : null);
    }
    
    public final TextField getEditor() {
        return this.textField;
    }
    
    public final String getDefaultValue() {
        return this.defaultValue;
    }
    
    private void updateGrid() {
        this.grid.getChildren().clear();
        this.grid.add(this.label, 0, 0);
        this.grid.add(this.textField, 1, 0);
        this.getDialogPane().setContent(this.grid);
        Platform.runLater(() -> this.textField.requestFocus());
    }
}
