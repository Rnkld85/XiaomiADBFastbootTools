// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.Observable;
import javafx.event.EventDispatcher;
import javafx.event.EventDispatchChain;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.event.EventTarget;
import java.util.Iterator;
import com.sun.javafx.scene.control.Logging;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import javafx.beans.property.ObjectPropertyBase;
import javafx.scene.Node;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.beans.DefaultProperty;

@DefaultProperty("items")
public class Menu extends MenuItem
{
    public static final EventType<Event> ON_SHOWING;
    public static final EventType<Event> ON_SHOWN;
    public static final EventType<Event> ON_HIDING;
    public static final EventType<Event> ON_HIDDEN;
    private ReadOnlyBooleanWrapper showing;
    private ObjectProperty<EventHandler<Event>> onShowing;
    private ObjectProperty<EventHandler<Event>> onShown;
    private ObjectProperty<EventHandler<Event>> onHiding;
    private ObjectProperty<EventHandler<Event>> onHidden;
    private final ObservableList<MenuItem> items;
    private static final String DEFAULT_STYLE_CLASS = "menu";
    private static final String STYLE_CLASS_SHOWING = "showing";
    
    public Menu() {
        this("");
    }
    
    public Menu(final String s) {
        this(s, null);
    }
    
    public Menu(final String s, final Node node) {
        this(s, node, (MenuItem[])null);
    }
    
    public Menu(final String s, final Node node, final MenuItem... array) {
        super(s, node);
        this.onShowing = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Menu.this.eventHandlerManager.setEventHandler(Menu.ON_SHOWING, ((ObjectPropertyBase<EventHandler<? super Event>>)this).get());
            }
            
            @Override
            public Object getBean() {
                return Menu.this;
            }
            
            @Override
            public String getName() {
                return "onShowing";
            }
        };
        this.onShown = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Menu.this.eventHandlerManager.setEventHandler(Menu.ON_SHOWN, ((ObjectPropertyBase<EventHandler<? super Event>>)this).get());
            }
            
            @Override
            public Object getBean() {
                return Menu.this;
            }
            
            @Override
            public String getName() {
                return "onShown";
            }
        };
        this.onHiding = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Menu.this.eventHandlerManager.setEventHandler(Menu.ON_HIDING, ((ObjectPropertyBase<EventHandler<? super Event>>)this).get());
            }
            
            @Override
            public Object getBean() {
                return Menu.this;
            }
            
            @Override
            public String getName() {
                return "onHiding";
            }
        };
        this.onHidden = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Menu.this.eventHandlerManager.setEventHandler(Menu.ON_HIDDEN, ((ObjectPropertyBase<EventHandler<? super Event>>)this).get());
            }
            
            @Override
            public Object getBean() {
                return Menu.this;
            }
            
            @Override
            public String getName() {
                return "onHidden";
            }
        };
        this.items = new TrackableObservableList<MenuItem>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<MenuItem> change) {
                while (change.next()) {
                    for (final MenuItem menuItem : change.getRemoved()) {
                        menuItem.setParentMenu(null);
                        menuItem.setParentPopup(null);
                    }
                    for (final MenuItem menuItem2 : change.getAddedSubList()) {
                        if (menuItem2.getParentMenu() != null) {
                            Logging.getControlsLogger().warning(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, menuItem2.getText(), menuItem2.getParentMenu().getText()));
                            menuItem2.getParentMenu().getItems().remove(menuItem2);
                        }
                        menuItem2.setParentMenu(Menu.this);
                        menuItem2.setParentPopup(Menu.this.getParentPopup());
                    }
                }
                if (Menu.this.getItems().size() == 0 && Menu.this.isShowing()) {
                    Menu.this.showingPropertyImpl().set(false);
                }
            }
        };
        this.getStyleClass().add("menu");
        if (array != null) {
            this.getItems().addAll(array);
        }
        int i = 0;
        this.parentPopupProperty().addListener(p0 -> {
            while (i < this.getItems().size()) {
                ((MenuItem)this.getItems().get(i)).setParentPopup(this.getParentPopup());
                ++i;
            }
        });
    }
    
    private void setShowing(final boolean b) {
        if (this.getItems().size() == 0 || (b && this.isShowing())) {
            return;
        }
        if (b) {
            if (this.getOnMenuValidation() != null) {
                Event.fireEvent(this, new Event(Menu.MENU_VALIDATION_EVENT));
                for (final MenuItem menuItem : this.getItems()) {
                    if (!(menuItem instanceof Menu) && menuItem.getOnMenuValidation() != null) {
                        Event.fireEvent(menuItem, new Event(MenuItem.MENU_VALIDATION_EVENT));
                    }
                }
            }
            Event.fireEvent(this, new Event(Menu.ON_SHOWING));
        }
        else {
            Event.fireEvent(this, new Event(Menu.ON_HIDING));
        }
        this.showingPropertyImpl().set(b);
        Event.fireEvent(this, b ? new Event(Menu.ON_SHOWN) : new Event(Menu.ON_HIDDEN));
    }
    
    public final boolean isShowing() {
        return this.showing != null && this.showing.get();
    }
    
    public final ReadOnlyBooleanProperty showingProperty() {
        return this.showingPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper showingPropertyImpl() {
        if (this.showing == null) {
            this.showing = new ReadOnlyBooleanWrapper() {
                @Override
                protected void invalidated() {
                    this.get();
                    if (Menu.this.isShowing()) {
                        Menu.this.getStyleClass().add("showing");
                    }
                    else {
                        Menu.this.getStyleClass().remove("showing");
                    }
                }
                
                @Override
                public Object getBean() {
                    return Menu.this;
                }
                
                @Override
                public String getName() {
                    return "showing";
                }
            };
        }
        return this.showing;
    }
    
    public final ObjectProperty<EventHandler<Event>> onShowingProperty() {
        return this.onShowing;
    }
    
    public final void setOnShowing(final EventHandler<Event> eventHandler) {
        this.onShowingProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnShowing() {
        return this.onShowingProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onShownProperty() {
        return this.onShown;
    }
    
    public final void setOnShown(final EventHandler<Event> eventHandler) {
        this.onShownProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnShown() {
        return this.onShownProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onHidingProperty() {
        return this.onHiding;
    }
    
    public final void setOnHiding(final EventHandler<Event> eventHandler) {
        this.onHidingProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnHiding() {
        return this.onHidingProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onHiddenProperty() {
        return this.onHidden;
    }
    
    public final void setOnHidden(final EventHandler<Event> eventHandler) {
        this.onHiddenProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnHidden() {
        return this.onHiddenProperty().get();
    }
    
    public final ObservableList<MenuItem> getItems() {
        return this.items;
    }
    
    public void show() {
        if (this.isDisable()) {
            return;
        }
        this.setShowing(true);
    }
    
    public void hide() {
        if (!this.isShowing()) {
            return;
        }
        for (final MenuItem menuItem : this.getItems()) {
            if (menuItem instanceof Menu) {
                ((Menu)menuItem).hide();
            }
        }
        this.setShowing(false);
    }
    
    @Override
    public <E extends Event> void addEventHandler(final EventType<E> eventType, final EventHandler<E> eventHandler) {
        this.eventHandlerManager.addEventHandler(eventType, eventHandler);
    }
    
    @Override
    public <E extends Event> void removeEventHandler(final EventType<E> eventType, final EventHandler<E> eventHandler) {
        this.eventHandlerManager.removeEventHandler(eventType, eventHandler);
    }
    
    @Override
    public EventDispatchChain buildEventDispatchChain(final EventDispatchChain eventDispatchChain) {
        return eventDispatchChain.prepend(this.eventHandlerManager);
    }
    
    static {
        ON_SHOWING = new EventType<Event>(Event.ANY, "MENU_ON_SHOWING");
        ON_SHOWN = new EventType<Event>(Event.ANY, "MENU_ON_SHOWN");
        ON_HIDING = new EventType<Event>(Event.ANY, "MENU_ON_HIDING");
        ON_HIDDEN = new EventType<Event>(Event.ANY, "MENU_ON_HIDDEN");
    }
}
