// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.collections.ListChangeListener;
import javafx.scene.input.MouseEvent;
import javafx.collections.ObservableList;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import com.sun.javafx.scene.ParentHelper;
import javafx.scene.Parent;
import com.sun.javafx.scene.traversal.ParentTraversalEngine;
import com.sun.javafx.scene.traversal.TraversalContext;
import com.sun.javafx.scene.traversal.Direction;
import com.sun.javafx.scene.traversal.Algorithm;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.event.EventTarget;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import com.sun.javafx.scene.control.FakeFocusTextField;
import javafx.scene.Node;
import javafx.scene.AccessibleRole;
import javafx.scene.AccessibleAction;
import javafx.css.PseudoClass;
import com.sun.javafx.scene.control.behavior.SpinnerBehavior;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Region;
import javafx.scene.control.TextField;
import javafx.scene.control.Spinner;
import javafx.scene.control.SkinBase;

public class SpinnerSkin<T> extends SkinBase<Spinner<T>>
{
    private TextField textField;
    private Region incrementArrow;
    private StackPane incrementArrowButton;
    private Region decrementArrow;
    private StackPane decrementArrowButton;
    private static final int ARROWS_ON_RIGHT_VERTICAL = 0;
    private static final int ARROWS_ON_LEFT_VERTICAL = 1;
    private static final int ARROWS_ON_RIGHT_HORIZONTAL = 2;
    private static final int ARROWS_ON_LEFT_HORIZONTAL = 3;
    private static final int SPLIT_ARROWS_VERTICAL = 4;
    private static final int SPLIT_ARROWS_HORIZONTAL = 5;
    private int layoutMode;
    private final SpinnerBehavior behavior;
    private static PseudoClass CONTAINS_FOCUS_PSEUDOCLASS_STATE;
    
    public SpinnerSkin(final Spinner<T> spinner) {
        super(spinner);
        this.layoutMode = 0;
        this.behavior = new SpinnerBehavior((Spinner<T>)spinner);
        this.textField = spinner.getEditor();
        this.getChildren().add(this.textField);
        this.updateStyleClass();
        spinner.getStyleClass().addListener(p0 -> this.updateStyleClass());
        (this.incrementArrow = new Region()).setFocusTraversable(false);
        this.incrementArrow.getStyleClass().setAll("increment-arrow");
        this.incrementArrow.setMaxWidth(Double.NEGATIVE_INFINITY);
        this.incrementArrow.setMaxHeight(Double.NEGATIVE_INFINITY);
        this.incrementArrow.setMouseTransparent(true);
        (this.incrementArrowButton = new StackPane() {
            @Override
            public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
                switch (accessibleAction) {
                    case FIRE: {
                        SpinnerSkin.this.getSkinnable().increment();
                        break;
                    }
                    default: {
                        super.executeAccessibleAction(accessibleAction, array);
                        break;
                    }
                }
            }
        }).setAccessibleRole(AccessibleRole.INCREMENT_BUTTON);
        this.incrementArrowButton.setFocusTraversable(false);
        this.incrementArrowButton.getStyleClass().setAll("increment-arrow-button");
        this.incrementArrowButton.getChildren().add(this.incrementArrow);
        this.incrementArrowButton.setOnMousePressed(p0 -> {
            this.getSkinnable().requestFocus();
            this.behavior.startSpinning(true);
            return;
        });
        this.incrementArrowButton.setOnMouseReleased(p0 -> this.behavior.stopSpinning());
        (this.decrementArrow = new Region()).setFocusTraversable(false);
        this.decrementArrow.getStyleClass().setAll("decrement-arrow");
        this.decrementArrow.setMaxWidth(Double.NEGATIVE_INFINITY);
        this.decrementArrow.setMaxHeight(Double.NEGATIVE_INFINITY);
        this.decrementArrow.setMouseTransparent(true);
        (this.decrementArrowButton = new StackPane() {
            @Override
            public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
                switch (accessibleAction) {
                    case FIRE: {
                        SpinnerSkin.this.getSkinnable().decrement();
                        break;
                    }
                    default: {
                        super.executeAccessibleAction(accessibleAction, array);
                        break;
                    }
                }
            }
        }).setAccessibleRole(AccessibleRole.DECREMENT_BUTTON);
        this.decrementArrowButton.setFocusTraversable(false);
        this.decrementArrowButton.getStyleClass().setAll("decrement-arrow-button");
        this.decrementArrowButton.getChildren().add(this.decrementArrow);
        this.decrementArrowButton.setOnMousePressed(p0 -> {
            this.getSkinnable().requestFocus();
            this.behavior.startSpinning(false);
            return;
        });
        this.decrementArrowButton.setOnMouseReleased(p0 -> this.behavior.stopSpinning());
        this.getChildren().addAll(this.incrementArrowButton, this.decrementArrowButton);
        spinner.focusedProperty().addListener((p0, p1, b) -> ((FakeFocusTextField)this.textField).setFakeFocus(b));
        spinner.addEventFilter(KeyEvent.ANY, keyEvent2 -> {
            if (spinner.isEditable()) {
                if (!keyEvent2.getTarget().equals(this.textField)) {
                    if (keyEvent2.getCode() != KeyCode.ESCAPE) {
                        this.textField.fireEvent(keyEvent2.copyFor(this.textField, this.textField));
                        if (keyEvent2.getCode() != KeyCode.ENTER) {
                            keyEvent2.consume();
                        }
                    }
                }
            }
            return;
        });
        this.textField.addEventFilter(KeyEvent.ANY, keyEvent -> {
            if (!spinner.isEditable()) {
                spinner.fireEvent(keyEvent.copyFor(spinner, spinner));
                keyEvent.consume();
            }
            return;
        });
        this.textField.focusedProperty().addListener((p1, p2, b2) -> {
            spinner.getProperties().put("FOCUSED", b2);
            if (!b2) {
                this.pseudoClassStateChanged(SpinnerSkin.CONTAINS_FOCUS_PSEUDOCLASS_STATE, false);
            }
            else {
                this.pseudoClassStateChanged(SpinnerSkin.CONTAINS_FOCUS_PSEUDOCLASS_STATE, true);
            }
            return;
        });
        this.textField.focusTraversableProperty().bind(spinner.editableProperty());
        ParentHelper.setTraversalEngine(spinner, new ParentTraversalEngine(spinner, new Algorithm() {
            @Override
            public Node select(final Node node, final Direction direction, final TraversalContext traversalContext) {
                return null;
            }
            
            @Override
            public Node selectFirst(final TraversalContext traversalContext) {
                return null;
            }
            
            @Override
            public Node selectLast(final TraversalContext traversalContext) {
                return null;
            }
        }));
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        final double a = this.incrementArrowButton.snappedLeftInset() + this.snapSizeX(this.incrementArrow.prefWidth(-1.0)) + this.incrementArrowButton.snappedRightInset();
        final double b = this.decrementArrowButton.snappedLeftInset() + this.snapSizeX(this.decrementArrow.prefWidth(-1.0)) + this.decrementArrowButton.snappedRightInset();
        final double max = Math.max(a, b);
        if (this.layoutMode == 0 || this.layoutMode == 1) {
            final double n5 = (this.layoutMode == 0) ? n : (n + max);
            final double n6 = (this.layoutMode == 0) ? (n + n3 - max) : n;
            final double floor = Math.floor(n4 / 2.0);
            this.textField.resizeRelocate(n5, n2, n3 - max, n4);
            this.incrementArrowButton.resize(max, floor);
            this.positionInArea(this.incrementArrowButton, n6, n2, max, floor, 0.0, HPos.CENTER, VPos.CENTER);
            this.decrementArrowButton.resize(max, floor);
            this.positionInArea(this.decrementArrowButton, n6, n2 + floor, max, n4 - floor, 0.0, HPos.CENTER, VPos.BOTTOM);
        }
        else if (this.layoutMode == 2 || this.layoutMode == 3) {
            final double n7 = a + b;
            final double n8 = (this.layoutMode == 2) ? n : (n + n7);
            final double n9 = (this.layoutMode == 2) ? (n + n3 - n7) : n;
            this.textField.resizeRelocate(n8, n2, n3 - n7, n4);
            this.decrementArrowButton.resize(b, n4);
            this.positionInArea(this.decrementArrowButton, n9, n2, b, n4, 0.0, HPos.CENTER, VPos.CENTER);
            this.incrementArrowButton.resize(a, n4);
            this.positionInArea(this.incrementArrowButton, n9 + b, n2, a, n4, 0.0, HPos.CENTER, VPos.CENTER);
        }
        else if (this.layoutMode == 4) {
            final double max2 = Math.max(this.incrementArrowButton.snappedTopInset() + this.snapSizeY(this.incrementArrow.prefHeight(-1.0)) + this.incrementArrowButton.snappedBottomInset(), this.decrementArrowButton.snappedTopInset() + this.snapSizeY(this.decrementArrow.prefHeight(-1.0)) + this.decrementArrowButton.snappedBottomInset());
            this.incrementArrowButton.resize(n3, max2);
            this.positionInArea(this.incrementArrowButton, n, n2, n3, max2, 0.0, HPos.CENTER, VPos.CENTER);
            this.textField.resizeRelocate(n, n2 + max2, n3, n4 - 2.0 * max2);
            this.decrementArrowButton.resize(n3, max2);
            this.positionInArea(this.decrementArrowButton, n, n4 - max2, n3, max2, 0.0, HPos.CENTER, VPos.CENTER);
        }
        else if (this.layoutMode == 5) {
            this.decrementArrowButton.resize(max, n4);
            this.positionInArea(this.decrementArrowButton, n, n2, max, n4, 0.0, HPos.CENTER, VPos.CENTER);
            this.textField.resizeRelocate(n + max, n2, n3 - 2.0 * max, n4);
            this.incrementArrowButton.resize(max, n4);
            this.positionInArea(this.incrementArrowButton, n3 - max, n2, max, n4, 0.0, HPos.CENTER, VPos.CENTER);
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.textField.minWidth(n);
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computePrefHeight(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n5 + this.textField.prefWidth(n) + n3;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        final double prefHeight = this.textField.prefHeight(n);
        double n6;
        if (this.layoutMode == 4) {
            n6 = n2 + this.incrementArrowButton.prefHeight(n) + prefHeight + this.decrementArrowButton.prefHeight(n) + n4;
        }
        else {
            n6 = n2 + prefHeight + n4;
        }
        return n6;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefWidth(n);
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefHeight(n);
    }
    
    @Override
    protected double computeBaselineOffset(final double n, final double n2, final double n3, final double n4) {
        return this.textField.getLayoutBounds().getMinY() + this.textField.getLayoutY() + this.textField.getBaselineOffset();
    }
    
    private void updateStyleClass() {
        final ObservableList<String> styleClass = this.getSkinnable().getStyleClass();
        if (styleClass.contains("arrows-on-left-vertical")) {
            this.layoutMode = 1;
        }
        else if (styleClass.contains("arrows-on-left-horizontal")) {
            this.layoutMode = 3;
        }
        else if (styleClass.contains("arrows-on-right-horizontal")) {
            this.layoutMode = 2;
        }
        else if (styleClass.contains("split-arrows-vertical")) {
            this.layoutMode = 4;
        }
        else if (styleClass.contains("split-arrows-horizontal")) {
            this.layoutMode = 5;
        }
        else {
            this.layoutMode = 0;
        }
    }
    
    static {
        SpinnerSkin.CONTAINS_FOCUS_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("contains-focus");
    }
}
