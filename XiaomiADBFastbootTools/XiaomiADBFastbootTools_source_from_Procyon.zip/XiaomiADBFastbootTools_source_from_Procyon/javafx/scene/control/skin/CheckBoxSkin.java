// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.Node;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.geometry.NodeOrientation;
import com.sun.javafx.scene.control.behavior.ButtonBehavior;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.layout.StackPane;
import javafx.scene.control.CheckBox;

public class CheckBoxSkin extends LabeledSkinBase<CheckBox>
{
    private final StackPane box;
    private StackPane innerbox;
    private final BehaviorBase<CheckBox> behavior;
    
    public CheckBoxSkin(final CheckBox checkBox) {
        super(checkBox);
        this.box = new StackPane();
        this.behavior = new ButtonBehavior<CheckBox>(checkBox);
        this.box.getStyleClass().setAll("box");
        this.innerbox = new StackPane();
        this.innerbox.getStyleClass().setAll("mark");
        this.innerbox.setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
        this.box.getChildren().add(this.innerbox);
        this.updateChildren();
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void updateChildren() {
        super.updateChildren();
        if (this.box != null) {
            this.getChildren().add(this.box);
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return super.computeMinWidth(n, n2, n3, n4, n5) + this.snapSizeX(this.box.minWidth(-1.0));
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Math.max(super.computeMinHeight(n - this.box.minWidth(-1.0), n2, n3, n4, n5), n2 + this.box.minHeight(-1.0) + n4);
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return super.computePrefWidth(n, n2, n3, n4, n5) + this.snapSizeX(this.box.prefWidth(-1.0));
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Math.max(super.computePrefHeight(n - this.box.prefWidth(-1.0), n2, n3, n4, n5), n2 + this.box.prefHeight(-1.0) + n4);
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double b) {
        final CheckBox checkBox = this.getSkinnable();
        final double snapSizeX = this.snapSizeX(this.box.prefWidth(-1.0));
        final double snapSizeY = this.snapSizeY(this.box.prefHeight(-1.0));
        final double min = Math.min(Math.max(checkBox.prefWidth(-1.0), checkBox.minWidth(-1.0)) - snapSizeX, n3 - this.snapSizeX(snapSizeX));
        final double max = Math.max(snapSizeY, Math.min(checkBox.prefHeight(min), b));
        final double n4 = Utils.computeXOffset(n3, min + snapSizeX, checkBox.getAlignment().getHpos()) + n;
        final double n5 = Utils.computeYOffset(b, max, checkBox.getAlignment().getVpos()) + n2;
        this.layoutLabelInArea(n4 + snapSizeX, n5, min, max, checkBox.getAlignment());
        this.box.resize(snapSizeX, snapSizeY);
        this.positionInArea(this.box, n4, n5, snapSizeX, max, 0.0, checkBox.getAlignment().getHpos(), checkBox.getAlignment().getVpos());
    }
}
