// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.beans.Observable;
import javafx.scene.input.Mnemonic;
import javafx.application.Platform;
import com.sun.javafx.PlatformUtil;
import javafx.scene.control.Label;
import javafx.scene.control.OverrunStyle;
import javafx.scene.AccessibleAttribute;
import javafx.geometry.Point2D;
import javafx.geometry.NodeOrientation;
import javafx.geometry.Orientation;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.text.Font;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.scene.control.ContentDisplay;
import javafx.scene.image.ImageView;
import javafx.beans.value.ObservableValue;
import javafx.scene.input.KeyCombination;
import javafx.scene.Scene;
import javafx.scene.shape.Line;
import com.sun.javafx.scene.control.behavior.TextBinding;
import javafx.scene.shape.Rectangle;
import javafx.beans.InvalidationListener;
import javafx.scene.Node;
import com.sun.javafx.scene.control.LabeledText;
import javafx.scene.control.SkinBase;
import javafx.scene.control.Labeled;

public abstract class LabeledSkinBase<C extends Labeled> extends SkinBase<C>
{
    LabeledText text;
    boolean invalidText;
    Node graphic;
    double textWidth;
    double ellipsisWidth;
    final InvalidationListener graphicPropertyChangedListener;
    private Rectangle textClip;
    private double wrapWidth;
    private double wrapHeight;
    private TextBinding bindings;
    private Line mnemonic_underscore;
    private boolean containsMnemonic;
    private Scene mnemonicScene;
    private KeyCombination mnemonicCode;
    private Node labeledNode;
    
    public LabeledSkinBase(final C c) {
        super(c);
        this.invalidText = true;
        this.textWidth = Double.NEGATIVE_INFINITY;
        this.ellipsisWidth = Double.NEGATIVE_INFINITY;
        this.graphicPropertyChangedListener = (p0 -> {
            this.invalidText = true;
            if (this.getSkinnable() != null) {
                this.getSkinnable().requestLayout();
            }
            return;
        });
        this.containsMnemonic = false;
        this.mnemonicScene = null;
        this.labeledNode = null;
        this.text = new LabeledText(c);
        this.updateChildren();
        this.registerChangeListener(c.ellipsisStringProperty(), p0 -> {
            this.textMetricsChanged();
            this.invalidateWidths();
            this.ellipsisWidth = Double.NEGATIVE_INFINITY;
            return;
        });
        this.registerChangeListener(c.widthProperty(), p0 -> {
            this.updateWrappingWidth();
            this.invalidText = true;
            return;
        });
        this.registerChangeListener(c.heightProperty(), p0 -> this.invalidText = true);
        this.registerChangeListener(c.fontProperty(), p0 -> {
            this.textMetricsChanged();
            this.invalidateWidths();
            this.ellipsisWidth = Double.NEGATIVE_INFINITY;
            return;
        });
        this.registerChangeListener(c.graphicProperty(), p0 -> {
            this.updateChildren();
            this.textMetricsChanged();
            return;
        });
        this.registerChangeListener(c.contentDisplayProperty(), p0 -> {
            this.updateChildren();
            this.textMetricsChanged();
            return;
        });
        this.registerChangeListener(c.labelPaddingProperty(), p0 -> this.textMetricsChanged());
        this.registerChangeListener(c.graphicTextGapProperty(), p0 -> this.textMetricsChanged());
        this.registerChangeListener(c.alignmentProperty(), p0 -> this.getSkinnable().requestLayout());
        this.registerChangeListener(c.mnemonicParsingProperty(), p0 -> {
            this.containsMnemonic = false;
            this.textMetricsChanged();
            return;
        });
        this.registerChangeListener(c.textProperty(), p0 -> {
            this.updateChildren();
            this.textMetricsChanged();
            this.invalidateWidths();
            return;
        });
        this.registerChangeListener(c.textAlignmentProperty(), p0 -> {});
        this.registerChangeListener(c.textOverrunProperty(), p0 -> this.textMetricsChanged());
        this.registerChangeListener(c.wrapTextProperty(), p0 -> {
            this.updateWrappingWidth();
            this.textMetricsChanged();
            return;
        });
        this.registerChangeListener(c.underlineProperty(), p0 -> this.textMetricsChanged());
        this.registerChangeListener(c.lineSpacingProperty(), p0 -> this.textMetricsChanged());
        this.registerChangeListener(c.sceneProperty(), p0 -> this.sceneChanged());
    }
    
    protected void updateChildren() {
        final Labeled labeled = this.getSkinnable();
        if (this.graphic != null) {
            this.graphic.layoutBoundsProperty().removeListener(this.graphicPropertyChangedListener);
        }
        this.graphic = labeled.getGraphic();
        if (this.graphic instanceof ImageView) {
            this.graphic.setMouseTransparent(true);
        }
        if (this.isIgnoreGraphic()) {
            if (labeled.getContentDisplay() == ContentDisplay.GRAPHIC_ONLY) {
                this.getChildren().clear();
            }
            else {
                this.getChildren().setAll(this.text);
            }
        }
        else {
            this.graphic.layoutBoundsProperty().addListener(this.graphicPropertyChangedListener);
            if (this.isIgnoreText()) {
                this.getChildren().setAll(this.graphic);
            }
            else {
                this.getChildren().setAll(this.graphic, this.text);
            }
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computeMinLabeledPartWidth(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computeMinLabeledPartHeight(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final Labeled labeled = this.getSkinnable();
        final Font font = this.text.getFont();
        String s = labeled.getText();
        final boolean b = s == null || s.isEmpty();
        double n6 = n5 + n3;
        if (!this.isIgnoreText()) {
            n6 += this.leftLabelPadding() + this.rightLabelPadding();
        }
        double computeTextWidth = 0.0;
        if (!b) {
            if (labeled.isMnemonicParsing() && s.contains("_") && s.indexOf("_") != s.length() - 1) {
                s = s.replaceFirst("_", "");
            }
            computeTextWidth = Utils.computeTextWidth(font, s, 0.0);
        }
        final double b2 = (this.graphic == null) ? 0.0 : Utils.boundedSize(this.graphic.prefWidth(-1.0), this.graphic.minWidth(-1.0), this.graphic.maxWidth(-1.0));
        if (this.isIgnoreGraphic()) {
            return computeTextWidth + n6;
        }
        if (this.isIgnoreText()) {
            return b2 + n6;
        }
        if (labeled.getContentDisplay() == ContentDisplay.LEFT || labeled.getContentDisplay() == ContentDisplay.RIGHT) {
            return computeTextWidth + labeled.getGraphicTextGap() + b2 + n6;
        }
        return Math.max(computeTextWidth, b2) + n6;
    }
    
    @Override
    protected double computePrefHeight(double n, final double n2, final double n3, final double n4, final double n5) {
        final Labeled labeled = this.getSkinnable();
        final Font font = this.text.getFont();
        final ContentDisplay contentDisplay = labeled.getContentDisplay();
        final double graphicTextGap = labeled.getGraphicTextGap();
        n -= n5 + n3;
        if (!this.isIgnoreText()) {
            n -= this.leftLabelPadding() + this.rightLabelPadding();
        }
        String s = labeled.getText();
        if (s != null && s.endsWith("\n")) {
            s = s.substring(0, s.length() - 1);
        }
        double n6 = n;
        if (!this.isIgnoreGraphic() && (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT)) {
            n6 -= this.graphic.prefWidth(-1.0) + graphicTextGap;
        }
        double n7;
        final double a = n7 = Utils.computeTextHeight(font, s, labeled.isWrapText() ? n6 : 0.0, labeled.getLineSpacing(), this.text.getBoundsType());
        if (!this.isIgnoreGraphic()) {
            final Node graphic = labeled.getGraphic();
            if (contentDisplay == ContentDisplay.TOP || contentDisplay == ContentDisplay.BOTTOM) {
                n7 = graphic.prefHeight(n) + graphicTextGap + a;
            }
            else {
                n7 = Math.max(a, graphic.prefHeight(n));
            }
        }
        double n8 = n2 + n4;
        if (!this.isIgnoreText()) {
            n8 += this.topLabelPadding() + this.bottomLabelPadding();
        }
        return n7 + n8;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefWidth(n);
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefHeight(n);
    }
    
    public double computeBaselineOffset(final double n, final double n2, final double n3, final double n4) {
        double baselineOffset;
        final double n5 = baselineOffset = this.text.getBaselineOffset();
        final Labeled labeled = this.getSkinnable();
        final Node graphic = labeled.getGraphic();
        if (!this.isIgnoreGraphic()) {
            final ContentDisplay contentDisplay = labeled.getContentDisplay();
            if (contentDisplay == ContentDisplay.TOP) {
                baselineOffset = graphic.prefHeight(-1.0) + labeled.getGraphicTextGap() + n5;
            }
            else if (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT) {
                baselineOffset = n5 + (graphic.prefHeight(-1.0) - this.text.prefHeight(-1.0)) / 2.0;
            }
        }
        double n6 = n + baselineOffset;
        if (!this.isIgnoreText()) {
            n6 += this.topLabelPadding();
        }
        return n6;
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        this.layoutLabelInArea(n, n2, n3, n4);
    }
    
    protected void layoutLabelInArea(final double n, final double n2, final double n3, final double n4) {
        this.layoutLabelInArea(n, n2, n3, n4, null);
    }
    
    protected void layoutLabelInArea(double n, double n2, double n3, double n4, Pos alignment) {
        final Labeled labeled = this.getSkinnable();
        final ContentDisplay contentDisplay = labeled.getContentDisplay();
        if (alignment == null) {
            alignment = labeled.getAlignment();
        }
        final HPos hPos = (alignment == null) ? HPos.LEFT : alignment.getHpos();
        final VPos vPos = (alignment == null) ? VPos.CENTER : alignment.getVpos();
        final boolean ignoreGraphic = this.isIgnoreGraphic();
        final boolean ignoreText = this.isIgnoreText();
        if (!ignoreText) {
            n += this.leftLabelPadding();
            n2 += this.topLabelPadding();
            n3 -= this.leftLabelPadding() + this.rightLabelPadding();
            n4 -= this.topLabelPadding() + this.bottomLabelPadding();
        }
        double a2;
        double a;
        if (ignoreGraphic) {
            a = (a2 = 0.0);
        }
        else if (ignoreText) {
            if (this.graphic.isResizable()) {
                final Orientation contentBias = this.graphic.getContentBias();
                if (contentBias == Orientation.HORIZONTAL) {
                    a2 = Utils.boundedSize(n3, this.graphic.minWidth(-1.0), this.graphic.maxWidth(-1.0));
                    a = Utils.boundedSize(n4, this.graphic.minHeight(a2), this.graphic.maxHeight(a2));
                }
                else if (contentBias == Orientation.VERTICAL) {
                    a = Utils.boundedSize(n4, this.graphic.minHeight(-1.0), this.graphic.maxHeight(-1.0));
                    a2 = Utils.boundedSize(n3, this.graphic.minWidth(a), this.graphic.maxWidth(a));
                }
                else {
                    a2 = Utils.boundedSize(n3, this.graphic.minWidth(-1.0), this.graphic.maxWidth(-1.0));
                    a = Utils.boundedSize(n4, this.graphic.minHeight(-1.0), this.graphic.maxHeight(-1.0));
                }
                this.graphic.resize(a2, a);
            }
            else {
                a2 = this.graphic.getLayoutBounds().getWidth();
                a = this.graphic.getLayoutBounds().getHeight();
            }
        }
        else {
            this.graphic.autosize();
            a2 = this.graphic.getLayoutBounds().getWidth();
            a = this.graphic.getLayoutBounds().getHeight();
        }
        double snapSizeX;
        double snapSizeY;
        if (ignoreText) {
            snapSizeY = (snapSizeX = 0.0);
            this.text.setText("");
        }
        else {
            this.updateDisplayedText(n3, n4);
            snapSizeX = this.snapSizeX(Math.min(this.text.getLayoutBounds().getWidth(), this.wrapWidth));
            snapSizeY = this.snapSizeY(Math.min(this.text.getLayoutBounds().getHeight(), this.wrapHeight));
        }
        final double n5 = (ignoreText || ignoreGraphic) ? 0.0 : labeled.getGraphicTextGap();
        double max = Math.max(a2, snapSizeX);
        double max2 = Math.max(a, snapSizeY);
        if (contentDisplay == ContentDisplay.TOP || contentDisplay == ContentDisplay.BOTTOM) {
            max2 = a + n5 + snapSizeY;
        }
        else if (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT) {
            max = a2 + n5 + snapSizeX;
        }
        double n6;
        if (hPos == HPos.LEFT) {
            n6 = n;
        }
        else if (hPos == HPos.RIGHT) {
            n6 = n + (n3 - max);
        }
        else {
            n6 = n + (n3 - max) / 2.0;
        }
        double n7;
        if (vPos == VPos.TOP) {
            n7 = n2;
        }
        else if (vPos == VPos.BOTTOM) {
            n7 = n2 + (n4 - max2);
        }
        else {
            n7 = n2 + (n4 - max2) / 2.0;
        }
        Point2D computeMnemonicPosition = null;
        double computeTextWidth = 0.0;
        double computeTextHeight = 0.0;
        if (this.containsMnemonic) {
            final Font font = this.text.getFont();
            final String text = this.bindings.getText();
            computeMnemonicPosition = Utils.computeMnemonicPosition(font, text, this.bindings.getMnemonicIndex(), this.wrapWidth, labeled.getLineSpacing());
            computeTextWidth = Utils.computeTextWidth(font, text.substring(this.bindings.getMnemonicIndex(), this.bindings.getMnemonicIndex() + 1), 0.0);
            computeTextHeight = Utils.computeTextHeight(font, "_", 0.0, this.text.getBoundsType());
        }
        if ((!ignoreGraphic || !ignoreText) && !this.text.isManaged()) {
            this.text.setManaged(true);
        }
        if (ignoreGraphic && ignoreText) {
            if (this.text.isManaged()) {
                this.text.setManaged(false);
            }
            this.text.relocate(this.snapPositionX(n6), this.snapPositionY(n7));
        }
        else if (ignoreGraphic) {
            this.text.relocate(this.snapPositionX(n6), this.snapPositionY(n7));
            if (this.containsMnemonic && computeMnemonicPosition != null) {
                this.mnemonic_underscore.setEndX(computeTextWidth - 2.0);
                this.mnemonic_underscore.relocate(this.snapPositionX(n6 + computeMnemonicPosition.getX()), this.snapPositionY(n7 + computeMnemonicPosition.getY()));
            }
        }
        else if (ignoreText) {
            this.text.relocate(this.snapPositionX(n6), this.snapPositionY(n7));
            this.graphic.relocate(this.snapPositionX(n6), this.snapPositionY(n7));
            if (this.containsMnemonic && computeMnemonicPosition != null) {
                this.mnemonic_underscore.setEndX(computeTextWidth);
                this.mnemonic_underscore.setStrokeWidth(computeTextHeight / 10.0);
                this.mnemonic_underscore.relocate(this.snapPositionX(n6 + computeMnemonicPosition.getX()), this.snapPositionY(n7 + computeMnemonicPosition.getY()));
            }
        }
        else {
            double n8 = 0.0;
            double n9 = 0.0;
            double n10 = 0.0;
            double n11 = 0.0;
            if (contentDisplay == ContentDisplay.TOP) {
                n8 = n6 + (max - a2) / 2.0;
                n10 = n6 + (max - snapSizeX) / 2.0;
                n9 = n7;
                n11 = n9 + a + n5;
            }
            else if (contentDisplay == ContentDisplay.RIGHT) {
                n10 = n6;
                n8 = n10 + snapSizeX + n5;
                n9 = n7 + (max2 - a) / 2.0;
                n11 = n7 + (max2 - snapSizeY) / 2.0;
            }
            else if (contentDisplay == ContentDisplay.BOTTOM) {
                n8 = n6 + (max - a2) / 2.0;
                n10 = n6 + (max - snapSizeX) / 2.0;
                n11 = n7;
                n9 = n11 + snapSizeY + n5;
            }
            else if (contentDisplay == ContentDisplay.LEFT) {
                n8 = n6;
                n10 = n8 + a2 + n5;
                n9 = n7 + (max2 - a) / 2.0;
                n11 = n7 + (max2 - snapSizeY) / 2.0;
            }
            else if (contentDisplay == ContentDisplay.CENTER) {
                n8 = n6 + (max - a2) / 2.0;
                n10 = n6 + (max - snapSizeX) / 2.0;
                n9 = n7 + (max2 - a) / 2.0;
                n11 = n7 + (max2 - snapSizeY) / 2.0;
            }
            this.text.relocate(this.snapPositionX(n10), this.snapPositionY(n11));
            if (this.containsMnemonic && computeMnemonicPosition != null) {
                this.mnemonic_underscore.setEndX(computeTextWidth);
                this.mnemonic_underscore.setStrokeWidth(computeTextHeight / 10.0);
                this.mnemonic_underscore.relocate(this.snapPositionX(n10 + computeMnemonicPosition.getX()), this.snapPositionY(n11 + computeMnemonicPosition.getY()));
            }
            this.graphic.relocate(this.snapPositionX(n8), this.snapPositionY(n9));
        }
        if (this.text != null && (this.text.getLayoutBounds().getHeight() > this.wrapHeight || this.text.getLayoutBounds().getWidth() > this.wrapWidth)) {
            if (this.textClip == null) {
                this.textClip = new Rectangle();
            }
            if (labeled.getEffectiveNodeOrientation() == NodeOrientation.LEFT_TO_RIGHT) {
                this.textClip.setX(this.text.getLayoutBounds().getMinX());
            }
            else {
                this.textClip.setX(this.text.getLayoutBounds().getMaxX() - this.wrapWidth);
            }
            this.textClip.setY(this.text.getLayoutBounds().getMinY());
            this.textClip.setWidth(this.wrapWidth);
            this.textClip.setHeight(this.wrapHeight);
            if (this.text.getClip() == null) {
                this.text.setClip(this.textClip);
            }
        }
        else if (this.text.getClip() != null) {
            this.text.setClip(null);
        }
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case TEXT: {
                final Labeled labeled = this.getSkinnable();
                final String accessibleText = labeled.getAccessibleText();
                if (accessibleText != null && !accessibleText.isEmpty()) {
                    return accessibleText;
                }
                if (this.bindings != null) {
                    final String text = this.bindings.getText();
                    if (text != null && !text.isEmpty()) {
                        return text;
                    }
                }
                final String text2 = labeled.getText();
                if (text2 != null && !text2.isEmpty()) {
                    return text2;
                }
                if (this.graphic != null) {
                    final Object queryAccessibleAttribute = this.graphic.queryAccessibleAttribute(AccessibleAttribute.TEXT, new Object[0]);
                    if (queryAccessibleAttribute != null) {
                        return queryAccessibleAttribute;
                    }
                }
                return null;
            }
            case MNEMONIC: {
                if (this.bindings != null) {
                    return this.bindings.getMnemonic();
                }
                return null;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    private double computeMinLabeledPartWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final Labeled labeled = this.getSkinnable();
        final ContentDisplay contentDisplay = labeled.getContentDisplay();
        final double graphicTextGap = labeled.getGraphicTextGap();
        double a = 0.0;
        final Font font = this.text.getFont();
        final OverrunStyle textOverrun = labeled.getTextOverrun();
        final String ellipsisString = labeled.getEllipsisString();
        final String text = labeled.getText();
        if (text != null && !text.isEmpty()) {
            if (textOverrun == OverrunStyle.CLIP) {
                if (this.textWidth == Double.NEGATIVE_INFINITY) {
                    this.textWidth = Utils.computeTextWidth(font, text.substring(0, 1), 0.0);
                }
                a = this.textWidth;
            }
            else {
                if (this.textWidth == Double.NEGATIVE_INFINITY) {
                    this.textWidth = Utils.computeTextWidth(font, text, 0.0);
                }
                if (this.ellipsisWidth == Double.NEGATIVE_INFINITY) {
                    this.ellipsisWidth = Utils.computeTextWidth(font, ellipsisString, 0.0);
                }
                a = Math.min(this.textWidth, this.ellipsisWidth);
            }
        }
        final Node graphic = labeled.getGraphic();
        double n6;
        if (this.isIgnoreGraphic()) {
            n6 = a;
        }
        else if (this.isIgnoreText()) {
            n6 = graphic.minWidth(-1.0);
        }
        else if (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT) {
            n6 = a + graphic.minWidth(-1.0) + graphicTextGap;
        }
        else {
            n6 = Math.max(a, graphic.minWidth(-1.0));
        }
        double n7 = n5 + n3;
        if (!this.isIgnoreText()) {
            n7 += this.leftLabelPadding() + this.rightLabelPadding();
        }
        return n6 + n7;
    }
    
    private double computeMinLabeledPartHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        final Labeled labeled = this.getSkinnable();
        final Font font = this.text.getFont();
        String s = labeled.getText();
        if (s != null && s.length() > 0) {
            final int index = s.indexOf(10);
            if (index >= 0) {
                s = s.substring(0, index);
            }
        }
        double n6;
        final double a = n6 = Utils.computeTextHeight(font, s, 0.0, labeled.getLineSpacing(), this.text.getBoundsType());
        if (!this.isIgnoreGraphic()) {
            final Node graphic = labeled.getGraphic();
            if (labeled.getContentDisplay() == ContentDisplay.TOP || labeled.getContentDisplay() == ContentDisplay.BOTTOM) {
                n6 = graphic.minHeight(n) + labeled.getGraphicTextGap() + a;
            }
            else {
                n6 = Math.max(a, graphic.minHeight(n));
            }
        }
        double n7 = n2 + n4;
        if (!this.isIgnoreText()) {
            n7 += this.topLabelPadding() - this.bottomLabelPadding();
        }
        return n6 + n7;
    }
    
    double topLabelPadding() {
        return this.snapSizeY(this.getSkinnable().getLabelPadding().getTop());
    }
    
    double bottomLabelPadding() {
        return this.snapSizeY(this.getSkinnable().getLabelPadding().getBottom());
    }
    
    double leftLabelPadding() {
        return this.snapSizeX(this.getSkinnable().getLabelPadding().getLeft());
    }
    
    double rightLabelPadding() {
        return this.snapSizeX(this.getSkinnable().getLabelPadding().getRight());
    }
    
    private void textMetricsChanged() {
        this.invalidText = true;
        this.getSkinnable().requestLayout();
    }
    
    void mnemonicTargetChanged() {
        if (this.containsMnemonic) {
            this.removeMnemonic();
            final Label skinnable = this.getSkinnable();
            if (skinnable instanceof Label) {
                this.labeledNode = skinnable.getLabelFor();
                this.addMnemonic();
            }
            else {
                this.labeledNode = null;
            }
        }
    }
    
    private void sceneChanged() {
        if (this.getSkinnable().getScene() != null && this.containsMnemonic) {
            this.addMnemonic();
        }
    }
    
    private void invalidateWidths() {
        this.textWidth = Double.NEGATIVE_INFINITY;
    }
    
    void updateDisplayedText() {
        this.updateDisplayedText(-1.0, -1.0);
    }
    
    private void updateDisplayedText(double b, double b2) {
        if (this.invalidText) {
            final Labeled labeled = this.getSkinnable();
            final String text = labeled.getText();
            int mnemonicIndex = -1;
            if (text != null && text.length() > 0) {
                this.bindings = new TextBinding(text);
                if (!PlatformUtil.isMac() && this.getSkinnable().isMnemonicParsing()) {
                    if (labeled instanceof Label) {
                        this.labeledNode = ((Label)labeled).getLabelFor();
                    }
                    else {
                        this.labeledNode = labeled;
                    }
                    if (this.labeledNode == null) {
                        this.labeledNode = labeled;
                    }
                    mnemonicIndex = this.bindings.getMnemonicIndex();
                }
            }
            if (this.containsMnemonic) {
                if (this.mnemonicScene != null && (mnemonicIndex == -1 || (this.bindings != null && !this.bindings.getMnemonicKeyCombination().equals(this.mnemonicCode)))) {
                    this.removeMnemonic();
                    this.containsMnemonic = false;
                }
            }
            else {
                this.removeMnemonic();
            }
            if (text != null && text.length() > 0 && mnemonicIndex >= 0 && !this.containsMnemonic) {
                this.containsMnemonic = true;
                this.mnemonicCode = this.bindings.getMnemonicKeyCombination();
                this.addMnemonic();
            }
            String s;
            if (this.containsMnemonic) {
                s = this.bindings.getText();
                if (this.mnemonic_underscore == null) {
                    (this.mnemonic_underscore = new Line()).setStartX(0.0);
                    this.mnemonic_underscore.setStartY(0.0);
                    this.mnemonic_underscore.setEndY(0.0);
                    this.mnemonic_underscore.getStyleClass().clear();
                    this.mnemonic_underscore.getStyleClass().setAll("mnemonic-underline");
                }
                if (!this.getChildren().contains(this.mnemonic_underscore)) {
                    this.getChildren().add(this.mnemonic_underscore);
                }
            }
            else {
                if (this.getSkinnable().isMnemonicParsing() && PlatformUtil.isMac() && this.bindings != null) {
                    s = this.bindings.getText();
                }
                else {
                    s = labeled.getText();
                }
                if (this.mnemonic_underscore != null && this.getChildren().contains(this.mnemonic_underscore)) {
                    Platform.runLater(() -> {
                        this.getChildren().remove(this.mnemonic_underscore);
                        this.mnemonic_underscore = null;
                        return;
                    });
                }
            }
            final int n = (s != null) ? s.length() : 0;
            boolean b3 = false;
            if (s != null && n > 0) {
                final int index = s.indexOf(10);
                if (index > -1 && index < n - 1) {
                    b3 = true;
                }
            }
            final boolean b4 = labeled.getContentDisplay() == ContentDisplay.LEFT || labeled.getContentDisplay() == ContentDisplay.RIGHT;
            double a = labeled.getWidth() - this.snappedLeftInset() - this.snappedRightInset();
            if (!this.isIgnoreText()) {
                a -= this.leftLabelPadding() + this.rightLabelPadding();
            }
            final double max = Math.max(a, 0.0);
            if (b == -1.0) {
                b = max;
            }
            double min = Math.min(this.computeMinLabeledPartWidth(-1.0, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset()), max);
            if (b4 && !this.isIgnoreGraphic()) {
                final double n2 = labeled.getGraphic().getLayoutBounds().getWidth() + labeled.getGraphicTextGap();
                b -= n2;
                min -= n2;
            }
            this.wrapWidth = Math.max(min, b);
            final boolean b5 = labeled.getContentDisplay() == ContentDisplay.TOP || labeled.getContentDisplay() == ContentDisplay.BOTTOM;
            double a2 = labeled.getHeight() - this.snappedTopInset() - this.snappedBottomInset();
            if (!this.isIgnoreText()) {
                a2 -= this.topLabelPadding() + this.bottomLabelPadding();
            }
            final double max2 = Math.max(a2, 0.0);
            if (b2 == -1.0) {
                b2 = max2;
            }
            double min2 = Math.min(this.computeMinLabeledPartHeight(this.wrapWidth, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset()), max2);
            if (b5 && labeled.getGraphic() != null) {
                final double n3 = labeled.getGraphic().getLayoutBounds().getHeight() + labeled.getGraphicTextGap();
                b2 -= n3;
                min2 -= n3;
            }
            this.wrapHeight = Math.max(min2, b2);
            this.updateWrappingWidth();
            final Font font = this.text.getFont();
            final OverrunStyle textOverrun = labeled.getTextOverrun();
            final String ellipsisString = labeled.getEllipsisString();
            String text2;
            if (labeled.isWrapText()) {
                text2 = Utils.computeClippedWrappedText(font, s, this.wrapWidth, this.wrapHeight, textOverrun, ellipsisString, this.text.getBoundsType());
            }
            else if (b3) {
                final StringBuilder sb = new StringBuilder();
                final String[] split = s.split("\n");
                for (int i = 0; i < split.length; ++i) {
                    sb.append(Utils.computeClippedText(font, split[i], this.wrapWidth, textOverrun, ellipsisString));
                    if (i < split.length - 1) {
                        sb.append('\n');
                    }
                }
                text2 = sb.toString();
            }
            else {
                text2 = Utils.computeClippedText(font, s, this.wrapWidth, textOverrun, ellipsisString);
            }
            if (text2 != null && text2.endsWith("\n")) {
                text2 = text2.substring(0, text2.length() - 1);
            }
            this.text.setText(text2);
            this.updateWrappingWidth();
            this.invalidText = false;
        }
    }
    
    private void addMnemonic() {
        if (this.labeledNode != null) {
            this.mnemonicScene = this.labeledNode.getScene();
            if (this.mnemonicScene != null) {
                this.mnemonicScene.addMnemonic(new Mnemonic(this.labeledNode, this.mnemonicCode));
            }
        }
    }
    
    private void removeMnemonic() {
        if (this.mnemonicScene != null && this.labeledNode != null) {
            this.mnemonicScene.removeMnemonic(new Mnemonic(this.labeledNode, this.mnemonicCode));
            this.mnemonicScene = null;
        }
    }
    
    private void updateWrappingWidth() {
        final Labeled labeled = this.getSkinnable();
        this.text.setWrappingWidth(0.0);
        if (labeled.isWrapText()) {
            this.text.setWrappingWidth(Math.min(this.text.prefWidth(-1.0), this.wrapWidth));
        }
    }
    
    boolean isIgnoreGraphic() {
        return this.graphic == null || !this.graphic.isManaged() || this.getSkinnable().getContentDisplay() == ContentDisplay.TEXT_ONLY;
    }
    
    boolean isIgnoreText() {
        final Labeled labeled = this.getSkinnable();
        final String text = labeled.getText();
        return text == null || text.equals("") || labeled.getContentDisplay() == ContentDisplay.GRAPHIC_ONLY;
    }
}
