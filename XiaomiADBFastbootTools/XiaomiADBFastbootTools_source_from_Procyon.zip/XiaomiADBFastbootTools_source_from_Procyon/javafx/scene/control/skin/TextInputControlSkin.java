// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.util.Collections;
import java.util.Collection;
import javafx.css.converter.BooleanConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.PaintConverter;
import javafx.event.ActionEvent;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import java.lang.ref.WeakReference;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.application.ConditionalFeature;
import com.sun.javafx.scene.control.Properties;
import java.security.AccessController;
import javafx.scene.AccessibleAction;
import javafx.css.Styleable;
import javafx.collections.ObservableList;
import javafx.scene.shape.Line;
import javafx.scene.shape.ClosePath;
import javafx.scene.shape.VLineTo;
import javafx.scene.shape.HLineTo;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.input.InputMethodHighlight;
import javafx.geometry.NodeOrientation;
import com.sun.javafx.scene.control.behavior.TextInputControlBehavior;
import java.util.Iterator;
import javafx.scene.input.InputMethodTextRun;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.shape.PathElement;
import javafx.scene.input.InputMethodRequests;
import javafx.scene.control.IndexRange;
import javafx.geometry.Rectangle2D;
import javafx.stage.Window;
import javafx.scene.Scene;
import javafx.geometry.Point2D;
import com.sun.javafx.scene.input.ExtendedInputMethodRequests;
import javafx.scene.Node;
import com.sun.javafx.scene.control.skin.FXVK;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.PlatformUtil;
import javafx.beans.binding.BooleanBinding;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.Observable;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.css.StyleableBooleanProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.scene.paint.Color;
import java.util.ArrayList;
import javafx.scene.paint.Paint;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.BooleanProperty;
import javafx.scene.shape.Shape;
import java.util.List;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Path;
import javafx.beans.value.ObservableBooleanValue;
import com.sun.javafx.tk.FontMetrics;
import javafx.beans.value.ObservableObjectValue;
import javafx.scene.control.SkinBase;
import javafx.scene.control.TextInputControl;

public abstract class TextInputControlSkin<T extends TextInputControl> extends SkinBase<T>
{
    static boolean preload;
    static final boolean SHOW_HANDLES;
    private static final boolean IS_FXVK_SUPPORTED;
    final ObservableObjectValue<FontMetrics> fontMetrics;
    private ObservableBooleanValue caretVisible;
    private CaretBlinking caretBlinking;
    final Path caretPath;
    StackPane caretHandle;
    StackPane selectionHandle1;
    StackPane selectionHandle2;
    private int imstart;
    private int imlength;
    private List<Shape> imattrs;
    private BooleanProperty blink;
    private final ObjectProperty<Paint> textFill;
    private final ObjectProperty<Paint> promptTextFill;
    private final ObjectProperty<Paint> highlightFill;
    private final ObjectProperty<Paint> highlightTextFill;
    private final BooleanProperty displayCaret;
    private BooleanProperty forwardBias;
    
    public TextInputControlSkin(final T t) {
        super(t);
        this.caretBlinking = new CaretBlinking(this.blinkProperty());
        this.caretPath = new Path();
        this.caretHandle = null;
        this.selectionHandle1 = null;
        this.selectionHandle2 = null;
        this.imattrs = new ArrayList<Shape>();
        this.textFill = new StyleableObjectProperty<Paint>((Paint)Color.BLACK) {
            @Override
            protected void invalidated() {
                TextInputControlSkin.this.updateTextFill();
            }
            
            @Override
            public Object getBean() {
                return TextInputControlSkin.this;
            }
            
            @Override
            public String getName() {
                return "textFill";
            }
            
            @Override
            public CssMetaData<TextInputControl, Paint> getCssMetaData() {
                return StyleableProperties.TEXT_FILL;
            }
        };
        this.promptTextFill = new StyleableObjectProperty<Paint>((Paint)Color.GRAY) {
            @Override
            public Object getBean() {
                return TextInputControlSkin.this;
            }
            
            @Override
            public String getName() {
                return "promptTextFill";
            }
            
            @Override
            public CssMetaData<TextInputControl, Paint> getCssMetaData() {
                return StyleableProperties.PROMPT_TEXT_FILL;
            }
        };
        this.highlightFill = new StyleableObjectProperty<Paint>((Paint)Color.DODGERBLUE) {
            @Override
            protected void invalidated() {
                TextInputControlSkin.this.updateHighlightFill();
            }
            
            @Override
            public Object getBean() {
                return TextInputControlSkin.this;
            }
            
            @Override
            public String getName() {
                return "highlightFill";
            }
            
            @Override
            public CssMetaData<TextInputControl, Paint> getCssMetaData() {
                return StyleableProperties.HIGHLIGHT_FILL;
            }
        };
        this.highlightTextFill = new StyleableObjectProperty<Paint>((Paint)Color.WHITE) {
            @Override
            protected void invalidated() {
                TextInputControlSkin.this.updateHighlightTextFill();
            }
            
            @Override
            public Object getBean() {
                return TextInputControlSkin.this;
            }
            
            @Override
            public String getName() {
                return "highlightTextFill";
            }
            
            @Override
            public CssMetaData<TextInputControl, Paint> getCssMetaData() {
                return StyleableProperties.HIGHLIGHT_TEXT_FILL;
            }
        };
        this.displayCaret = new StyleableBooleanProperty(true) {
            @Override
            public Object getBean() {
                return TextInputControlSkin.this;
            }
            
            @Override
            public String getName() {
                return "displayCaret";
            }
            
            @Override
            public CssMetaData<TextInputControl, Boolean> getCssMetaData() {
                return StyleableProperties.DISPLAY_CARET;
            }
        };
        this.forwardBias = new SimpleBooleanProperty(this, "forwardBias", true);
        this.fontMetrics = new ObjectBinding<FontMetrics>() {
            {
                this.bind(t.fontProperty());
            }
            
            @Override
            protected FontMetrics computeValue() {
                TextInputControlSkin.this.invalidateMetrics();
                return Toolkit.getToolkit().getFontLoader().getFontMetrics(t.getFont());
            }
        };
        this.caretVisible = new BooleanBinding() {
            {
                this.bind(t.focusedProperty(), t.anchorProperty(), t.caretPositionProperty(), t.disabledProperty(), t.editableProperty(), TextInputControlSkin.this.displayCaret, TextInputControlSkin.this.blinkProperty());
            }
            
            @Override
            protected boolean computeValue() {
                return !TextInputControlSkin.this.blinkProperty().get() && TextInputControlSkin.this.displayCaret.get() && t.isFocused() && (PlatformUtil.isWindows() || t.getCaretPosition() == t.getAnchor()) && !t.isDisabled() && t.isEditable();
            }
        };
        if (TextInputControlSkin.SHOW_HANDLES) {
            this.caretHandle = new StackPane();
            this.selectionHandle1 = new StackPane();
            this.selectionHandle2 = new StackPane();
            this.caretHandle.setManaged(false);
            this.selectionHandle1.setManaged(false);
            this.selectionHandle2.setManaged(false);
            this.caretHandle.visibleProperty().bind(new BooleanBinding() {
                {
                    this.bind(t.focusedProperty(), t.anchorProperty(), t.caretPositionProperty(), t.disabledProperty(), t.editableProperty(), t.lengthProperty(), TextInputControlSkin.this.displayCaret);
                }
                
                @Override
                protected boolean computeValue() {
                    return TextInputControlSkin.this.displayCaret.get() && t.isFocused() && t.getCaretPosition() == t.getAnchor() && !t.isDisabled() && t.isEditable() && t.getLength() > 0;
                }
            });
            this.selectionHandle1.visibleProperty().bind(new BooleanBinding() {
                {
                    this.bind(t.focusedProperty(), t.anchorProperty(), t.caretPositionProperty(), t.disabledProperty(), TextInputControlSkin.this.displayCaret);
                }
                
                @Override
                protected boolean computeValue() {
                    return TextInputControlSkin.this.displayCaret.get() && t.isFocused() && t.getCaretPosition() != t.getAnchor() && !t.isDisabled();
                }
            });
            this.selectionHandle2.visibleProperty().bind(new BooleanBinding() {
                {
                    this.bind(t.focusedProperty(), t.anchorProperty(), t.caretPositionProperty(), t.disabledProperty(), TextInputControlSkin.this.displayCaret);
                }
                
                @Override
                protected boolean computeValue() {
                    return TextInputControlSkin.this.displayCaret.get() && t.isFocused() && t.getCaretPosition() != t.getAnchor() && !t.isDisabled();
                }
            });
            this.caretHandle.getStyleClass().setAll("caret-handle");
            this.selectionHandle1.getStyleClass().setAll("selection-handle");
            this.selectionHandle2.getStyleClass().setAll("selection-handle");
            this.selectionHandle1.setId("selection-handle-1");
            this.selectionHandle2.setId("selection-handle-2");
        }
        if (TextInputControlSkin.IS_FXVK_SUPPORTED) {
            if (TextInputControlSkin.preload) {
                final Scene scene = t.getScene();
                if (scene != null && scene.getWindow() != null) {
                    FXVK.init(t);
                }
            }
            final Scene scene2;
            t.focusedProperty().addListener(p1 -> {
                if (FXVK.useFXVK()) {
                    this.getSkinnable().getScene();
                    if (t.isEditable() && t.isFocused()) {
                        FXVK.attach(t);
                    }
                    else if (scene2 == null || scene2.getWindow() == null || !scene2.getWindow().isFocused() || !(scene2.getFocusOwner() instanceof TextInputControl) || !((TextInputControl)scene2.getFocusOwner()).isEditable()) {
                        FXVK.detach();
                    }
                }
                return;
            });
        }
        if (t.getOnInputMethodTextChanged() == null) {
            t.setOnInputMethodTextChanged(inputMethodEvent -> this.handleInputMethodEvent(inputMethodEvent));
        }
        t.setInputMethodRequests(new ExtendedInputMethodRequests() {
            @Override
            public Point2D getTextLocation(final int n) {
                final Scene scene = TextInputControlSkin.this.getSkinnable().getScene();
                final Window window = scene.getWindow();
                final Rectangle2D characterBounds = TextInputControlSkin.this.getCharacterBounds(t.getSelection().getStart() + n);
                final Point2D localToScene = TextInputControlSkin.this.getSkinnable().localToScene(characterBounds.getMinX(), characterBounds.getMaxY());
                return new Point2D(window.getX() + scene.getX() + localToScene.getX(), window.getY() + scene.getY() + localToScene.getY());
            }
            
            @Override
            public int getLocationOffset(final int n, final int n2) {
                return TextInputControlSkin.this.getInsertionPoint(n, n2);
            }
            
            @Override
            public void cancelLatestCommittedText() {
            }
            
            @Override
            public String getSelectedText() {
                final TextInputControl textInputControl = TextInputControlSkin.this.getSkinnable();
                final IndexRange selection = textInputControl.getSelection();
                return textInputControl.getText(selection.getStart(), selection.getEnd());
            }
            
            @Override
            public int getInsertPositionOffset() {
                final int caretPosition = TextInputControlSkin.this.getSkinnable().getCaretPosition();
                if (caretPosition < TextInputControlSkin.this.imstart) {
                    return caretPosition;
                }
                if (caretPosition < TextInputControlSkin.this.imstart + TextInputControlSkin.this.imlength) {
                    return TextInputControlSkin.this.imstart;
                }
                return caretPosition - TextInputControlSkin.this.imlength;
            }
            
            @Override
            public String getCommittedText(final int n, final int n2) {
                final TextInputControl textInputControl = TextInputControlSkin.this.getSkinnable();
                if (n >= TextInputControlSkin.this.imstart) {
                    return textInputControl.getText(n + TextInputControlSkin.this.imlength, n2 + TextInputControlSkin.this.imlength);
                }
                if (n2 <= TextInputControlSkin.this.imstart) {
                    return textInputControl.getText(n, n2);
                }
                return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, textInputControl.getText(n, TextInputControlSkin.this.imstart), textInputControl.getText(TextInputControlSkin.this.imstart + TextInputControlSkin.this.imlength, n2 + TextInputControlSkin.this.imlength));
            }
            
            @Override
            public int getCommittedTextLength() {
                return TextInputControlSkin.this.getSkinnable().getText().length() - TextInputControlSkin.this.imlength;
            }
        });
    }
    
    private final void setBlink(final boolean b) {
        this.blinkProperty().set(b);
    }
    
    private final boolean isBlink() {
        return this.blinkProperty().get();
    }
    
    private final BooleanProperty blinkProperty() {
        if (this.blink == null) {
            this.blink = new SimpleBooleanProperty(this, "blink", true);
        }
        return this.blink;
    }
    
    protected final void setTextFill(final Paint paint) {
        this.textFill.set(paint);
    }
    
    protected final Paint getTextFill() {
        return this.textFill.get();
    }
    
    protected final ObjectProperty<Paint> textFillProperty() {
        return this.textFill;
    }
    
    protected final void setPromptTextFill(final Paint paint) {
        this.promptTextFill.set(paint);
    }
    
    protected final Paint getPromptTextFill() {
        return this.promptTextFill.get();
    }
    
    protected final ObjectProperty<Paint> promptTextFillProperty() {
        return this.promptTextFill;
    }
    
    protected final void setHighlightFill(final Paint paint) {
        this.highlightFill.set(paint);
    }
    
    protected final Paint getHighlightFill() {
        return this.highlightFill.get();
    }
    
    protected final ObjectProperty<Paint> highlightFillProperty() {
        return this.highlightFill;
    }
    
    protected final void setHighlightTextFill(final Paint paint) {
        this.highlightTextFill.set(paint);
    }
    
    protected final Paint getHighlightTextFill() {
        return this.highlightTextFill.get();
    }
    
    protected final ObjectProperty<Paint> highlightTextFillProperty() {
        return this.highlightTextFill;
    }
    
    private final void setDisplayCaret(final boolean b) {
        this.displayCaret.set(b);
    }
    
    private final boolean isDisplayCaret() {
        return this.displayCaret.get();
    }
    
    private final BooleanProperty displayCaretProperty() {
        return this.displayCaret;
    }
    
    protected final BooleanProperty forwardBiasProperty() {
        return this.forwardBias;
    }
    
    public final void setForwardBias(final boolean b) {
        this.forwardBias.set(b);
    }
    
    protected final boolean isForwardBias() {
        return this.forwardBias.get();
    }
    
    protected abstract PathElement[] getUnderlineShape(final int p0, final int p1);
    
    protected abstract PathElement[] getRangeShape(final int p0, final int p1);
    
    protected abstract void addHighlight(final List<? extends Node> p0, final int p1);
    
    protected abstract void removeHighlight(final List<? extends Node> p0);
    
    public abstract void moveCaret(final TextUnit p0, final Direction p1, final boolean p2);
    
    public Point2D getMenuPosition() {
        if (!TextInputControlSkin.SHOW_HANDLES) {
            throw new UnsupportedOperationException();
        }
        if (this.caretHandle.isVisible()) {
            return new Point2D(this.caretHandle.getLayoutX() + this.caretHandle.getWidth() / 2.0, this.caretHandle.getLayoutY());
        }
        if (this.selectionHandle1.isVisible() && this.selectionHandle2.isVisible()) {
            return new Point2D((this.selectionHandle1.getLayoutX() + this.selectionHandle1.getWidth() / 2.0 + this.selectionHandle2.getLayoutX() + this.selectionHandle2.getWidth() / 2.0) / 2.0, this.selectionHandle2.getLayoutY() + this.selectionHandle2.getHeight() / 2.0);
        }
        return null;
    }
    
    protected String maskText(final String s) {
        return s;
    }
    
    protected int getInsertionPoint(final double n, final double n2) {
        return 0;
    }
    
    public Rectangle2D getCharacterBounds(final int n) {
        return null;
    }
    
    protected void scrollCharacterToVisible(final int n) {
    }
    
    protected void invalidateMetrics() {
    }
    
    protected void updateTextFill() {
    }
    
    protected void updateHighlightFill() {
    }
    
    protected void updateHighlightTextFill() {
    }
    
    protected void handleInputMethodEvent(final InputMethodEvent inputMethodEvent) {
        final TextInputControl textInputControl = this.getSkinnable();
        if (textInputControl.isEditable() && !textInputControl.textProperty().isBound() && !textInputControl.isDisabled()) {
            if (PlatformUtil.isIOS()) {
                textInputControl.setText(inputMethodEvent.getCommitted());
                return;
            }
            if (this.imlength != 0) {
                this.removeHighlight(this.imattrs);
                this.imattrs.clear();
                textInputControl.selectRange(this.imstart, this.imstart + this.imlength);
            }
            if (inputMethodEvent.getCommitted().length() != 0) {
                textInputControl.replaceText(textInputControl.getSelection(), inputMethodEvent.getCommitted());
            }
            this.imstart = textInputControl.getSelection().getStart();
            final StringBuilder sb = new StringBuilder();
            final Iterator<InputMethodTextRun> iterator = inputMethodEvent.getComposed().iterator();
            while (iterator.hasNext()) {
                sb.append(iterator.next().getText());
            }
            textInputControl.replaceText(textInputControl.getSelection(), sb.toString());
            this.imlength = sb.length();
            if (this.imlength != 0) {
                int imstart = this.imstart;
                for (final InputMethodTextRun inputMethodTextRun : inputMethodEvent.getComposed()) {
                    final int n = imstart + inputMethodTextRun.getText().length();
                    this.createInputMethodAttributes(inputMethodTextRun.getHighlight(), imstart, n);
                    imstart = n;
                }
                this.addHighlight(this.imattrs, this.imstart);
                final int caretPosition = inputMethodEvent.getCaretPosition();
                if (caretPosition >= 0 && caretPosition < this.imlength) {
                    textInputControl.selectRange(this.imstart + caretPosition, this.imstart + caretPosition);
                }
            }
        }
    }
    
    public void setCaretAnimating(final boolean b) {
        if (b) {
            this.caretBlinking.start();
        }
        else {
            this.caretBlinking.stop();
            this.blinkProperty().set(true);
        }
    }
    
    TextInputControlBehavior getBehavior() {
        return null;
    }
    
    ObservableBooleanValue caretVisibleProperty() {
        return this.caretVisible;
    }
    
    boolean isRTL() {
        return this.getSkinnable().getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT;
    }
    
    private void createInputMethodAttributes(final InputMethodHighlight inputMethodHighlight, final int n, final int n2) {
        double x = 0.0;
        double n3 = 0.0;
        double y = 0.0;
        double n4 = 0.0;
        final PathElement[] underlineShape = this.getUnderlineShape(n, n2);
        for (int i = 0; i < underlineShape.length; ++i) {
            final PathElement pathElement = underlineShape[i];
            if (pathElement instanceof MoveTo) {
                n3 = (x = ((MoveTo)pathElement).getX());
                n4 = (y = ((MoveTo)pathElement).getY());
            }
            else if (pathElement instanceof LineTo) {
                x = ((x < ((LineTo)pathElement).getX()) ? x : ((LineTo)pathElement).getX());
                n3 = ((n3 > ((LineTo)pathElement).getX()) ? n3 : ((LineTo)pathElement).getX());
                y = ((y < ((LineTo)pathElement).getY()) ? y : ((LineTo)pathElement).getY());
                n4 = ((n4 > ((LineTo)pathElement).getY()) ? n4 : ((LineTo)pathElement).getY());
            }
            else if (pathElement instanceof HLineTo) {
                x = ((x < ((HLineTo)pathElement).getX()) ? x : ((HLineTo)pathElement).getX());
                n3 = ((n3 > ((HLineTo)pathElement).getX()) ? n3 : ((HLineTo)pathElement).getX());
            }
            else if (pathElement instanceof VLineTo) {
                y = ((y < ((VLineTo)pathElement).getY()) ? y : ((VLineTo)pathElement).getY());
                n4 = ((n4 > ((VLineTo)pathElement).getY()) ? n4 : ((VLineTo)pathElement).getY());
            }
            if (pathElement instanceof ClosePath || i == underlineShape.length - 1 || (i < underlineShape.length - 1 && underlineShape[i + 1] instanceof MoveTo)) {
                Shape shape = null;
                if (inputMethodHighlight == InputMethodHighlight.SELECTED_RAW) {
                    shape = new Path();
                    ((Path)shape).getElements().addAll(this.getRangeShape(n, n2));
                    shape.setFill(Color.BLUE);
                    shape.setOpacity(0.30000001192092896);
                }
                else if (inputMethodHighlight == InputMethodHighlight.UNSELECTED_RAW) {
                    shape = new Line(x + 2.0, n4 + 1.0, n3 - 2.0, n4 + 1.0);
                    shape.setStroke(this.textFill.get());
                    shape.setStrokeWidth(n4 - y);
                    final ObservableList<Double> strokeDashArray = shape.getStrokeDashArray();
                    strokeDashArray.add(2.0);
                    strokeDashArray.add(2.0);
                }
                else if (inputMethodHighlight == InputMethodHighlight.SELECTED_CONVERTED) {
                    shape = new Line(x + 2.0, n4 + 1.0, n3 - 2.0, n4 + 1.0);
                    shape.setStroke(this.textFill.get());
                    shape.setStrokeWidth((n4 - y) * 3.0);
                }
                else if (inputMethodHighlight == InputMethodHighlight.UNSELECTED_CONVERTED) {
                    shape = new Line(x + 2.0, n4 + 1.0, n3 - 2.0, n4 + 1.0);
                    shape.setStroke(this.textFill.get());
                    shape.setStrokeWidth(n4 - y);
                }
                if (shape != null) {
                    shape.setManaged(false);
                    this.imattrs.add(shape);
                }
            }
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case SHOW_TEXT_RANGE: {
                final Integer n = (Integer)array[0];
                final Integer n2 = (Integer)array[1];
                if (n != null && n2 != null) {
                    this.scrollCharacterToVisible(n2);
                    this.scrollCharacterToVisible(n);
                    this.scrollCharacterToVisible(n2);
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    static {
        TextInputControlSkin.preload = false;
        final String s;
        AccessController.doPrivileged(() -> {
            System.getProperty("com.sun.javafx.virtualKeyboard.preload");
            if (s != null && s.equalsIgnoreCase("PRERENDER")) {
                TextInputControlSkin.preload = true;
            }
            return null;
        });
        SHOW_HANDLES = (Properties.IS_TOUCH_SUPPORTED && !PlatformUtil.isIOS());
        IS_FXVK_SUPPORTED = Platform.isSupported(ConditionalFeature.VIRTUAL_KEYBOARD);
    }
    
    public enum TextUnit
    {
        CHARACTER, 
        WORD, 
        LINE, 
        PARAGRAPH, 
        PAGE;
    }
    
    public enum Direction
    {
        LEFT, 
        RIGHT, 
        UP, 
        DOWN, 
        BEGINNING, 
        END;
    }
    
    private static final class CaretBlinking
    {
        private final Timeline caretTimeline;
        private final WeakReference<BooleanProperty> blinkPropertyRef;
        
        public CaretBlinking(final BooleanProperty referent) {
            this.blinkPropertyRef = new WeakReference<BooleanProperty>(referent);
            (this.caretTimeline = new Timeline()).setCycleCount(-1);
            this.caretTimeline.getKeyFrames().addAll(new KeyFrame(Duration.ZERO, p0 -> this.setBlink(false), new KeyValue[0]), new KeyFrame(Duration.seconds(0.5), p0 -> this.setBlink(true), new KeyValue[0]), new KeyFrame(Duration.seconds(1.0), new KeyValue[0]));
        }
        
        public void start() {
            this.caretTimeline.play();
        }
        
        public void stop() {
            this.caretTimeline.stop();
        }
        
        private void setBlink(final boolean b) {
            final BooleanProperty booleanProperty = this.blinkPropertyRef.get();
            if (booleanProperty == null) {
                this.caretTimeline.stop();
                return;
            }
            booleanProperty.set(b);
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TextInputControl, Paint> TEXT_FILL;
        private static final CssMetaData<TextInputControl, Paint> PROMPT_TEXT_FILL;
        private static final CssMetaData<TextInputControl, Paint> HIGHLIGHT_FILL;
        private static final CssMetaData<TextInputControl, Paint> HIGHLIGHT_TEXT_FILL;
        private static final CssMetaData<TextInputControl, Boolean> DISPLAY_CARET;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            TEXT_FILL = new CssMetaData<TextInputControl, Paint>((StyleConverter)PaintConverter.getInstance(), (Paint)Color.BLACK) {
                @Override
                public boolean isSettable(final TextInputControl textInputControl) {
                    final TextInputControlSkin textInputControlSkin = (TextInputControlSkin)textInputControl.getSkin();
                    return textInputControlSkin.textFill == null || !textInputControlSkin.textFill.isBound();
                }
                
                @Override
                public StyleableProperty<Paint> getStyleableProperty(final TextInputControl textInputControl) {
                    return (StyleableProperty<Paint>)(StyleableProperty)((TextInputControlSkin)textInputControl.getSkin()).textFill;
                }
            };
            PROMPT_TEXT_FILL = new CssMetaData<TextInputControl, Paint>((StyleConverter)PaintConverter.getInstance(), (Paint)Color.GRAY) {
                @Override
                public boolean isSettable(final TextInputControl textInputControl) {
                    final TextInputControlSkin textInputControlSkin = (TextInputControlSkin)textInputControl.getSkin();
                    return textInputControlSkin.promptTextFill == null || !textInputControlSkin.promptTextFill.isBound();
                }
                
                @Override
                public StyleableProperty<Paint> getStyleableProperty(final TextInputControl textInputControl) {
                    return (StyleableProperty<Paint>)(StyleableProperty)((TextInputControlSkin)textInputControl.getSkin()).promptTextFill;
                }
            };
            HIGHLIGHT_FILL = new CssMetaData<TextInputControl, Paint>((StyleConverter)PaintConverter.getInstance(), (Paint)Color.DODGERBLUE) {
                @Override
                public boolean isSettable(final TextInputControl textInputControl) {
                    final TextInputControlSkin textInputControlSkin = (TextInputControlSkin)textInputControl.getSkin();
                    return textInputControlSkin.highlightFill == null || !textInputControlSkin.highlightFill.isBound();
                }
                
                @Override
                public StyleableProperty<Paint> getStyleableProperty(final TextInputControl textInputControl) {
                    return (StyleableProperty<Paint>)(StyleableProperty)((TextInputControlSkin)textInputControl.getSkin()).highlightFill;
                }
            };
            HIGHLIGHT_TEXT_FILL = new CssMetaData<TextInputControl, Paint>((StyleConverter)PaintConverter.getInstance(), (Paint)Color.WHITE) {
                @Override
                public boolean isSettable(final TextInputControl textInputControl) {
                    final TextInputControlSkin textInputControlSkin = (TextInputControlSkin)textInputControl.getSkin();
                    return textInputControlSkin.highlightTextFill == null || !textInputControlSkin.highlightTextFill.isBound();
                }
                
                @Override
                public StyleableProperty<Paint> getStyleableProperty(final TextInputControl textInputControl) {
                    return (StyleableProperty<Paint>)(StyleableProperty)((TextInputControlSkin)textInputControl.getSkin()).highlightTextFill;
                }
            };
            DISPLAY_CARET = new CssMetaData<TextInputControl, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final TextInputControl textInputControl) {
                    final TextInputControlSkin textInputControlSkin = (TextInputControlSkin)textInputControl.getSkin();
                    return textInputControlSkin.displayCaret == null || !textInputControlSkin.displayCaret.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final TextInputControl textInputControl) {
                    return (StyleableProperty<Boolean>)((TextInputControlSkin)textInputControl.getSkin()).displayCaret;
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(SkinBase.getClassCssMetaData());
            list.add(StyleableProperties.TEXT_FILL);
            list.add(StyleableProperties.PROMPT_TEXT_FILL);
            list.add(StyleableProperties.HIGHLIGHT_FILL);
            list.add(StyleableProperties.HIGHLIGHT_TEXT_FILL);
            list.add(StyleableProperties.DISPLAY_CARET);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
