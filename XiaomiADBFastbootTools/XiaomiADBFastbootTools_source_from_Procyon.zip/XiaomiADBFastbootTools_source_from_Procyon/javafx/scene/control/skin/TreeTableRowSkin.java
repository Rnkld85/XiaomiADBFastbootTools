// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.util.Collections;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.scene.control.IndexedCell;
import java.util.Iterator;
import java.lang.ref.Reference;
import javafx.scene.control.TreeTablePosition;
import java.util.ArrayList;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import java.util.List;
import javafx.beans.property.ObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TableColumnBase;
import java.util.Collection;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.scene.control.TreeTableView;
import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.control.behavior.TreeTableRowBehavior;
import javafx.beans.property.DoubleProperty;
import javafx.beans.InvalidationListener;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.Node;
import javafx.scene.control.TreeTableCell;
import javafx.scene.control.TreeTableRow;
import javafx.scene.control.TreeItem;

public class TreeTableRowSkin<T> extends TableRowSkinBase<TreeItem<T>, TreeTableRow<T>, TreeTableCell<T, ?>>
{
    private TreeItem<?> treeItem;
    private boolean disclosureNodeDirty;
    private Node graphic;
    private final BehaviorBase<TreeTableRow<T>> behavior;
    private TreeTableViewSkin treeTableViewSkin;
    private boolean childrenDirty;
    private final InvalidationListener graphicListener;
    private DoubleProperty indent;
    
    public TreeTableRowSkin(final TreeTableRow<T> treeTableRow) {
        super(treeTableRow);
        this.disclosureNodeDirty = true;
        this.childrenDirty = false;
        this.graphicListener = (p0 -> {
            this.disclosureNodeDirty = true;
            this.getSkinnable().requestLayout();
            return;
        });
        this.indent = null;
        this.behavior = (BehaviorBase<TreeTableRow<T>>)new TreeTableRowBehavior((TreeTableRow<Object>)treeTableRow);
        this.updateTreeItem();
        this.updateTableViewSkin();
        this.registerChangeListener(treeTableRow.treeTableViewProperty(), p0 -> this.updateTableViewSkin());
        this.registerChangeListener(treeTableRow.indexProperty(), p0 -> this.updateCells = true);
        this.registerChangeListener(treeTableRow.treeItemProperty(), p0 -> this.updateTreeItem());
        this.setupTreeTableViewListeners();
    }
    
    private void setupTreeTableViewListeners() {
        final TreeTableView treeTableView = this.getSkinnable().getTreeTableView();
        if (treeTableView == null) {
            this.getSkinnable().treeTableViewProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(final Observable observable) {
                    TreeTableRowSkin.this.getSkinnable().treeTableViewProperty().removeListener(this);
                    TreeTableRowSkin.this.setupTreeTableViewListeners();
                }
            });
        }
        else {
            this.registerChangeListener(treeTableView.treeColumnProperty(), p0 -> {
                this.isDirty = (1 != 0);
                this.getSkinnable().requestLayout();
                return;
            });
            final DoubleProperty fixedCellSizeProperty = this.getTreeTableView().fixedCellSizeProperty();
            if (fixedCellSizeProperty != null) {
                this.registerChangeListener(fixedCellSizeProperty, p1 -> {
                    this.fixedCellSize = fixedCellSizeProperty.get();
                    this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0);
                    return;
                });
                this.fixedCellSize = fixedCellSizeProperty.get();
                this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0);
                this.registerChangeListener(this.getVirtualFlow().widthProperty(), p1 -> treeTableView.requestLayout());
            }
        }
    }
    
    public final void setIndent(final double n) {
        this.indentProperty().set(n);
    }
    
    public final double getIndent() {
        return (this.indent == null) ? 10.0 : this.indent.get();
    }
    
    public final DoubleProperty indentProperty() {
        if (this.indent == null) {
            this.indent = new StyleableDoubleProperty(10.0) {
                @Override
                public Object getBean() {
                    return TreeTableRowSkin.this;
                }
                
                @Override
                public String getName() {
                    return "indent";
                }
                
                @Override
                public CssMetaData<TreeTableRow<?>, Number> getCssMetaData() {
                    return StyleableProperties.INDENT;
                }
            };
        }
        return this.indent;
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void updateChildren() {
        super.updateChildren();
        this.updateDisclosureNodeAndGraphic();
        if (this.childrenDirty) {
            this.childrenDirty = false;
            if (this.cells.isEmpty()) {
                this.getChildren().clear();
            }
            else {
                this.getChildren().addAll((Collection<?>)this.cells);
            }
        }
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        if (this.disclosureNodeDirty) {
            this.updateDisclosureNodeAndGraphic();
            this.disclosureNodeDirty = false;
        }
        final Node disclosureNode = this.getDisclosureNode();
        if (disclosureNode != null && disclosureNode.getScene() == null) {
            this.updateDisclosureNodeAndGraphic();
        }
        super.layoutChildren(n, n2, n3, n4);
    }
    
    @Override
    protected TreeTableCell<T, ?> createCell(final TableColumnBase tableColumnBase) {
        final TreeTableColumn<T, ?> treeTableColumn = (TreeTableColumn<T, ?>)tableColumnBase;
        final TreeTableCell<T, ?> treeTableCell = treeTableColumn.getCellFactory().call(treeTableColumn);
        treeTableCell.updateTreeTableColumn(treeTableColumn);
        treeTableCell.updateTreeTableView(treeTableColumn.getTreeTableView());
        return treeTableCell;
    }
    
    @Override
    void updateCells(final boolean b) {
        super.updateCells(b);
        if (b) {
            this.childrenDirty = true;
            this.updateChildren();
        }
    }
    
    @Override
    boolean isIndentationRequired() {
        return true;
    }
    
    @Override
    TableColumnBase getTreeColumn() {
        return this.getTreeTableView().getTreeColumn();
    }
    
    @Override
    int getIndentationLevel(final TreeTableRow<T> treeTableRow) {
        return this.getTreeTableView().getTreeItemLevel(treeTableRow.getTreeItem());
    }
    
    @Override
    double getIndentationPerLevel() {
        return this.getIndent();
    }
    
    @Override
    Node getDisclosureNode() {
        return this.getSkinnable().getDisclosureNode();
    }
    
    @Override
    boolean isDisclosureNodeVisible() {
        return this.getDisclosureNode() != null && this.treeItem != null && !this.treeItem.isLeaf();
    }
    
    @Override
    boolean isShowRoot() {
        return this.getTreeTableView().isShowRoot();
    }
    
    @Override
    protected ObservableList<TreeTableColumn<T, ?>> getVisibleLeafColumns() {
        return (this.getTreeTableView() == null) ? FXCollections.emptyObservableList() : this.getTreeTableView().getVisibleLeafColumns();
    }
    
    @Override
    protected void updateCell(final TreeTableCell<T, ?> treeTableCell, final TreeTableRow<T> treeTableRow) {
        treeTableCell.updateTreeTableRow(treeTableRow);
    }
    
    @Override
    protected TreeTableColumn<T, ?> getTableColumn(final TreeTableCell treeTableCell) {
        return treeTableCell.getTableColumn();
    }
    
    @Override
    protected ObjectProperty<Node> graphicProperty() {
        if (this.getSkinnable() == null) {
            return null;
        }
        if (this.treeItem == null) {
            return null;
        }
        return this.treeItem.graphicProperty();
    }
    
    private void updateTreeItem() {
        if (this.treeItem != null) {
            this.treeItem.graphicProperty().removeListener(this.graphicListener);
        }
        this.treeItem = this.getSkinnable().getTreeItem();
        if (this.treeItem != null) {
            this.treeItem.graphicProperty().addListener(this.graphicListener);
        }
    }
    
    private TreeTableView<T> getTreeTableView() {
        return this.getSkinnable().getTreeTableView();
    }
    
    private void updateDisclosureNodeAndGraphic() {
        if (this.getSkinnable().isEmpty()) {
            this.getChildren().remove(this.graphic);
            return;
        }
        final ObjectProperty<Node> graphicProperty = this.graphicProperty();
        final Node graphic = (graphicProperty == null) ? null : graphicProperty.get();
        if (graphic != null) {
            if (graphic != this.graphic) {
                this.getChildren().remove(this.graphic);
            }
            if (!this.getChildren().contains(graphic)) {
                this.getChildren().add(graphic);
                this.graphic = graphic;
            }
        }
        final Node disclosureNode = this.getSkinnable().getDisclosureNode();
        if (disclosureNode != null) {
            final boolean visible = this.treeItem != null && !this.treeItem.isLeaf();
            disclosureNode.setVisible(visible);
            if (!visible) {
                this.getChildren().remove(disclosureNode);
            }
            else if (disclosureNode.getParent() == null) {
                this.getChildren().add(disclosureNode);
                disclosureNode.toFront();
            }
            else {
                disclosureNode.toBack();
            }
            if (disclosureNode.getScene() != null) {
                disclosureNode.applyCss();
            }
        }
    }
    
    private void updateTableViewSkin() {
        final TreeTableView treeTableView = this.getSkinnable().getTreeTableView();
        if (treeTableView != null && treeTableView.getSkin() instanceof TreeTableViewSkin) {
            this.treeTableViewSkin = (TreeTableViewSkin)treeTableView.getSkin();
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        final TreeTableView treeTableView = this.getSkinnable().getTreeTableView();
        switch (accessibleAttribute) {
            case SELECTED_ITEMS: {
                final ArrayList<TreeTableCell> list = new ArrayList<TreeTableCell>();
                final int index = this.getSkinnable().getIndex();
                final Iterator iterator = treeTableView.getSelectionModel().getSelectedCells().iterator();
                if (iterator.hasNext()) {
                    final TreeTablePosition treeTablePosition = iterator.next();
                    if (treeTablePosition.getRow() == index) {
                        TreeTableColumn key = treeTablePosition.getTableColumn();
                        if (key == null) {
                            key = treeTableView.getVisibleLeafColumn(0);
                        }
                        final TreeTableCell treeTableCell = (TreeTableCell)this.cellsMap.get(key).get();
                        if (treeTableCell != null) {
                            list.add(treeTableCell);
                        }
                    }
                    return FXCollections.observableArrayList((Collection<?>)list);
                }
            }
            case CELL_AT_ROW_COLUMN: {
                final TreeTableColumn visibleLeafColumn = treeTableView.getVisibleLeafColumn((int)array[1]);
                if (this.cellsMap.containsKey(visibleLeafColumn)) {
                    return this.cellsMap.get(visibleLeafColumn).get();
                }
                return null;
            }
            case FOCUS_ITEM: {
                TreeTableColumn treeTableColumn = treeTableView.getFocusModel().getFocusedCell().getTableColumn();
                if (treeTableColumn == null) {
                    treeTableColumn = treeTableView.getVisibleLeafColumn(0);
                }
                if (this.cellsMap.containsKey(treeTableColumn)) {
                    return this.cellsMap.get(treeTableColumn).get();
                }
                return null;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TreeTableRow<?>, Number> INDENT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            INDENT = new CssMetaData<TreeTableRow<?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)10.0) {
                @Override
                public boolean isSettable(final TreeTableRow<?> treeTableRow) {
                    final DoubleProperty indentProperty = ((TreeTableRowSkin)treeTableRow.getSkin()).indentProperty();
                    return indentProperty == null || !indentProperty.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TreeTableRow<?> treeTableRow) {
                    return (StyleableProperty<Number>)((TreeTableRowSkin)treeTableRow.getSkin()).indentProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(CellSkinBase.getClassCssMetaData());
            list.add(StyleableProperties.INDENT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
