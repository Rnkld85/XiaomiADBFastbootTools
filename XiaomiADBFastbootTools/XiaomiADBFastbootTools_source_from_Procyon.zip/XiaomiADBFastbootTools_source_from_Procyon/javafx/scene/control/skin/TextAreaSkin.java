// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.geometry.Orientation;
import javafx.scene.layout.Region;
import javafx.scene.control.IndexRange;
import javafx.collections.ListChangeListener;
import javafx.scene.text.TextBoundsType;
import com.sun.javafx.scene.control.behavior.TextInputControlBehavior;
import com.sun.javafx.tk.FontMetrics;
import javafx.geometry.VPos;
import javafx.application.Platform;
import javafx.geometry.Rectangle2D;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.scene.AccessibleAttribute;
import java.util.Collection;
import java.util.List;
import javafx.scene.shape.PathElement;
import com.sun.javafx.PlatformUtil;
import java.util.Iterator;
import javafx.scene.paint.Paint;
import javafx.scene.text.HitInfo;
import javafx.scene.input.MouseEvent;
import javafx.collections.ObservableList;
import javafx.geometry.Point2D;
import javafx.beans.binding.BooleanBinding;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.beans.binding.DoubleBinding;
import javafx.beans.value.ObservableValue;
import javafx.scene.input.ScrollEvent;
import javafx.scene.Node;
import javafx.beans.Observable;
import javafx.beans.binding.IntegerBinding;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.animation.Timeline;
import javafx.geometry.VerticalDirection;
import javafx.geometry.Bounds;
import javafx.scene.control.ScrollPane;
import javafx.beans.value.ObservableIntegerValue;
import javafx.beans.value.ObservableBooleanValue;
import javafx.scene.text.Text;
import javafx.scene.Group;
import com.sun.javafx.scene.control.behavior.TextAreaBehavior;
import javafx.scene.shape.Path;
import javafx.scene.control.TextArea;

public class TextAreaSkin extends TextInputControlSkin<TextArea>
{
    private static final Path tmpCaretPath;
    private final TextArea textArea;
    private static final boolean USE_MULTIPLE_NODES = false;
    private final TextAreaBehavior behavior;
    private double computedMinWidth;
    private double computedMinHeight;
    private double computedPrefWidth;
    private double computedPrefHeight;
    private double widthForComputedPrefHeight;
    private double characterWidth;
    private double lineHeight;
    private ContentView contentView;
    private Group paragraphNodes;
    private Text promptNode;
    private ObservableBooleanValue usePromptText;
    private ObservableIntegerValue caretPosition;
    private Group selectionHighlightGroup;
    private ScrollPane scrollPane;
    private Bounds oldViewportBounds;
    private VerticalDirection scrollDirection;
    private Path characterBoundingPath;
    private Timeline scrollSelectionTimeline;
    private EventHandler<ActionEvent> scrollSelectionHandler;
    private double pressX;
    private double pressY;
    private boolean handlePressed;
    double targetCaretX;
    
    public TextAreaSkin(final TextArea textArea) {
        super(textArea);
        this.computedMinWidth = Double.NEGATIVE_INFINITY;
        this.computedMinHeight = Double.NEGATIVE_INFINITY;
        this.computedPrefWidth = Double.NEGATIVE_INFINITY;
        this.computedPrefHeight = Double.NEGATIVE_INFINITY;
        this.widthForComputedPrefHeight = Double.NEGATIVE_INFINITY;
        this.contentView = new ContentView();
        this.paragraphNodes = new Group();
        this.selectionHighlightGroup = new Group();
        this.scrollDirection = null;
        this.characterBoundingPath = new Path();
        this.scrollSelectionTimeline = new Timeline();
        this.scrollSelectionHandler = (p0 -> {
            switch (this.scrollDirection) {
            }
            return;
        });
        this.targetCaretX = -1.0;
        (this.behavior = new TextAreaBehavior(textArea)).setTextAreaSkin(this);
        this.textArea = textArea;
        (this.caretPosition = new IntegerBinding() {
            {
                this.bind(textArea.caretPositionProperty());
            }
            
            @Override
            protected int computeValue() {
                return textArea.getCaretPosition();
            }
        }).addListener((p1, p2, p3) -> {
            this.targetCaretX = -1.0;
            if (textArea.getWidth() > 0.0) {
                this.setForwardBias(true);
            }
            return;
        });
        this.forwardBiasProperty().addListener(p1 -> {
            if (textArea.getWidth() > 0.0) {
                this.updateTextNodeCaretPos(textArea.getCaretPosition());
            }
            return;
        });
        (this.scrollPane = new ScrollPane()).setFitToWidth(textArea.isWrapText());
        this.scrollPane.setContent(this.contentView);
        this.getChildren().add(this.scrollPane);
        this.getSkinnable().addEventFilter(ScrollEvent.ANY, scrollEvent -> {
            if (scrollEvent.isDirect() && this.handlePressed) {
                scrollEvent.consume();
            }
            return;
        });
        this.selectionHighlightGroup.setManaged(false);
        this.selectionHighlightGroup.setVisible(false);
        this.contentView.getChildren().add(this.selectionHighlightGroup);
        this.paragraphNodes.setManaged(false);
        this.contentView.getChildren().add(this.paragraphNodes);
        this.caretPath.setManaged(false);
        this.caretPath.setStrokeWidth(1.0);
        this.caretPath.fillProperty().bind((ObservableValue<?>)this.textFillProperty());
        this.caretPath.strokeProperty().bind((ObservableValue<?>)this.textFillProperty());
        this.caretPath.opacityProperty().bind(new DoubleBinding() {
            {
                this.bind(TextAreaSkin.this.caretVisibleProperty());
            }
            
            @Override
            protected double computeValue() {
                return TextAreaSkin.this.caretVisibleProperty().get() ? 1.0 : 0.0;
            }
        });
        this.contentView.getChildren().add(this.caretPath);
        if (TextAreaSkin.SHOW_HANDLES) {
            this.contentView.getChildren().addAll(this.caretHandle, this.selectionHandle1, this.selectionHandle2);
        }
        this.scrollPane.hvalueProperty().addListener((p0, p1, n) -> this.getSkinnable().setScrollLeft(n.doubleValue() * this.getScrollLeftMax()));
        this.scrollPane.vvalueProperty().addListener((p0, p1, n2) -> this.getSkinnable().setScrollTop(n2.doubleValue() * this.getScrollTopMax()));
        this.scrollSelectionTimeline.setCycleCount(-1);
        final ObservableList<KeyFrame> keyFrames = this.scrollSelectionTimeline.getKeyFrames();
        keyFrames.clear();
        keyFrames.add(new KeyFrame(Duration.millis(350.0), this.scrollSelectionHandler, new KeyValue[0]));
        for (int i = 0, n5 = 1; i < n5; ++i) {
            this.addParagraphNode(i, ((n5 == 1) ? textArea.textProperty().getValueSafe() : textArea.getParagraphs().get(i)).toString());
        }
        textArea.selectionProperty().addListener((p1, p2, p3) -> {
            textArea.requestLayout();
            this.contentView.requestLayout();
            return;
        });
        textArea.wrapTextProperty().addListener((p0, p1, b) -> {
            this.invalidateMetrics();
            this.scrollPane.setFitToWidth(b);
            return;
        });
        textArea.prefColumnCountProperty().addListener((p0, p1, p2) -> {
            this.invalidateMetrics();
            this.updatePrefViewportWidth();
            return;
        });
        textArea.prefRowCountProperty().addListener((p0, p1, p2) -> {
            this.invalidateMetrics();
            this.updatePrefViewportHeight();
            return;
        });
        this.updateFontMetrics();
        this.fontMetrics.addListener(p0 -> this.updateFontMetrics());
        this.contentView.paddingProperty().addListener(p0 -> {
            this.updatePrefViewportWidth();
            this.updatePrefViewportHeight();
            return;
        });
        final Bounds oldViewportBounds;
        this.scrollPane.viewportBoundsProperty().addListener(p0 -> {
            if (this.scrollPane.getViewportBounds() != null) {
                this.scrollPane.getViewportBounds();
                if (this.oldViewportBounds == null || this.oldViewportBounds.getWidth() != oldViewportBounds.getWidth() || this.oldViewportBounds.getHeight() != oldViewportBounds.getHeight()) {
                    this.invalidateMetrics();
                    this.oldViewportBounds = oldViewportBounds;
                    this.contentView.requestLayout();
                }
            }
            return;
        });
        textArea.scrollTopProperty().addListener((p0, p1, n3) -> this.scrollPane.setVvalue((n3.doubleValue() < this.getScrollTopMax()) ? (n3.doubleValue() / this.getScrollTopMax()) : 1.0));
        textArea.scrollLeftProperty().addListener((p0, p1, n4) -> this.scrollPane.setHvalue((n4.doubleValue() < this.getScrollLeftMax()) ? (n4.doubleValue() / this.getScrollLeftMax()) : 1.0));
        textArea.textProperty().addListener(p1 -> {
            this.invalidateMetrics();
            this.paragraphNodes.getChildren().get(0).setText(textArea.textProperty().getValueSafe());
            this.contentView.requestLayout();
            return;
        });
        this.usePromptText = new BooleanBinding() {
            {
                this.bind(textArea.textProperty(), textArea.promptTextProperty());
            }
            
            @Override
            protected boolean computeValue() {
                final String text = textArea.getText();
                final String promptText = textArea.getPromptText();
                return (text == null || text.isEmpty()) && promptText != null && !promptText.isEmpty();
            }
        };
        if (this.usePromptText.get()) {
            this.createPromptNode();
        }
        this.usePromptText.addListener(p1 -> {
            this.createPromptNode();
            textArea.requestLayout();
            return;
        });
        this.updateHighlightFill();
        this.updatePrefViewportWidth();
        this.updatePrefViewportHeight();
        if (textArea.isFocused()) {
            this.setCaretAnimating(true);
        }
        if (TextAreaSkin.SHOW_HANDLES) {
            this.selectionHandle1.setRotate(180.0);
            final EventHandler<? super MouseEvent> onMousePressed = mouseEvent -> {
                this.pressX = mouseEvent.getX();
                this.pressY = mouseEvent.getY();
                this.handlePressed = (1 != 0);
                mouseEvent.consume();
                return;
            };
            final EventHandler<? super MouseEvent> onMouseReleased = p0 -> this.handlePressed = (0 != 0);
            this.caretHandle.setOnMousePressed(onMousePressed);
            this.selectionHandle1.setOnMousePressed(onMousePressed);
            this.selectionHandle2.setOnMousePressed(onMousePressed);
            this.caretHandle.setOnMouseReleased(onMouseReleased);
            this.selectionHandle1.setOnMouseReleased(onMouseReleased);
            this.selectionHandle2.setOnMouseReleased(onMouseReleased);
            final Text text;
            final Point2D point2D;
            this.caretHandle.setOnMouseDragged(mouseEvent2 -> {
                this.getTextNode();
                text.localToScene(0.0, 0.0);
                this.positionCaret(text.hitTest(this.translateCaretPosition(new Point2D(mouseEvent2.getSceneX() - point2D.getX() - this.pressX + this.caretHandle.getWidth() / 2.0, mouseEvent2.getSceneY() - point2D.getY() - this.pressY - 6.0))), false);
                mouseEvent2.consume();
                return;
            });
            final TextArea textArea2;
            final Text text2;
            final Point2D point2D2;
            final HitInfo hitInfo;
            final int n6;
            this.selectionHandle1.setOnMouseDragged(mouseEvent3 -> {
                textArea2 = this.getSkinnable();
                this.getTextNode();
                text2.localToScene(0.0, 0.0);
                text2.hitTest(this.translateCaretPosition(new Point2D(mouseEvent3.getSceneX() - point2D2.getX() - this.pressX + this.selectionHandle1.getWidth() / 2.0, mouseEvent3.getSceneY() - point2D2.getY() - this.pressY + this.selectionHandle1.getHeight() + 5.0)));
                if (textArea2.getAnchor() < textArea2.getCaretPosition()) {
                    textArea2.selectRange(textArea2.getCaretPosition(), textArea2.getAnchor());
                }
                hitInfo.getCharIndex();
                if (n6 > 0 && n6 >= textArea2.getAnchor()) {
                    textArea2.getAnchor();
                }
                this.positionCaret(hitInfo, true);
                mouseEvent3.consume();
                return;
            });
            final TextArea textArea3;
            final Text text3;
            final Point2D point2D3;
            final HitInfo hitInfo2;
            final int n7;
            this.selectionHandle2.setOnMouseDragged(mouseEvent4 -> {
                textArea3 = this.getSkinnable();
                this.getTextNode();
                text3.localToScene(0.0, 0.0);
                text3.hitTest(this.translateCaretPosition(new Point2D(mouseEvent4.getSceneX() - point2D3.getX() - this.pressX + this.selectionHandle2.getWidth() / 2.0, mouseEvent4.getSceneY() - point2D3.getY() - this.pressY - 6.0)));
                if (textArea3.getAnchor() > textArea3.getCaretPosition()) {
                    textArea3.selectRange(textArea3.getCaretPosition(), textArea3.getAnchor());
                }
                hitInfo2.getCharIndex();
                if (n7 > 0) {
                    if (n7 <= textArea3.getAnchor() + 1) {
                        Math.min(textArea3.getAnchor() + 2, textArea3.getLength());
                    }
                    this.positionCaret(hitInfo2, true);
                }
                mouseEvent4.consume();
            });
        }
    }
    
    @Override
    protected void invalidateMetrics() {
        this.computedMinWidth = Double.NEGATIVE_INFINITY;
        this.computedMinHeight = Double.NEGATIVE_INFINITY;
        this.computedPrefWidth = Double.NEGATIVE_INFINITY;
        this.computedPrefHeight = Double.NEGATIVE_INFINITY;
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        this.scrollPane.resizeRelocate(n, n2, n3, n4);
    }
    
    @Override
    protected void updateHighlightFill() {
        final Iterator<Node> iterator = this.selectionHighlightGroup.getChildren().iterator();
        while (iterator.hasNext()) {
            ((Path)iterator.next()).setFill(this.highlightFillProperty().get());
        }
    }
    
    public HitInfo getIndex(final double n, final double n2) {
        final Text textNode = this.getTextNode();
        return textNode.hitTest(this.translateCaretPosition(new Point2D(n - textNode.getLayoutX(), n2 - this.getTextTranslateY())));
    }
    
    @Override
    public void moveCaret(final TextUnit textUnit, final Direction direction, final boolean b) {
        Label_0392: {
            switch (textUnit) {
                case CHARACTER: {
                    switch (direction) {
                        case LEFT:
                        case RIGHT: {
                            this.nextCharacterVisually(direction == Direction.RIGHT);
                            break Label_0392;
                        }
                        default: {
                            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/skin/TextInputControlSkin$Direction;)Ljava/lang/String;, direction));
                        }
                    }
                    break;
                }
                case LINE: {
                    switch (direction) {
                        case UP: {
                            this.previousLine(b);
                            break Label_0392;
                        }
                        case DOWN: {
                            this.nextLine(b);
                            break Label_0392;
                        }
                        case BEGINNING: {
                            this.lineStart(b, b && PlatformUtil.isMac());
                            break Label_0392;
                        }
                        case END: {
                            this.lineEnd(b, b && PlatformUtil.isMac());
                            break Label_0392;
                        }
                        default: {
                            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/skin/TextInputControlSkin$Direction;)Ljava/lang/String;, direction));
                        }
                    }
                    break;
                }
                case PAGE: {
                    switch (direction) {
                        case UP: {
                            this.previousPage(b);
                            break Label_0392;
                        }
                        case DOWN: {
                            this.nextPage(b);
                            break Label_0392;
                        }
                        default: {
                            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/skin/TextInputControlSkin$Direction;)Ljava/lang/String;, direction));
                        }
                    }
                    break;
                }
                case PARAGRAPH: {
                    switch (direction) {
                        case UP: {
                            this.paragraphStart(true, b);
                            break Label_0392;
                        }
                        case DOWN: {
                            this.paragraphEnd(true, b);
                            break Label_0392;
                        }
                        case BEGINNING: {
                            this.paragraphStart(false, b);
                            break Label_0392;
                        }
                        case END: {
                            this.paragraphEnd(false, b);
                            break Label_0392;
                        }
                        default: {
                            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/skin/TextInputControlSkin$Direction;)Ljava/lang/String;, direction));
                        }
                    }
                    break;
                }
                default: {
                    throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/skin/TextInputControlSkin$TextUnit;)Ljava/lang/String;, textUnit));
                }
            }
        }
    }
    
    private void nextCharacterVisually(boolean b) {
        if (this.isRTL()) {
            b = !b;
        }
        final Text textNode = this.getTextNode();
        Bounds bounds = this.caretPath.getLayoutBounds();
        if (this.caretPath.getElements().size() == 4) {
            bounds = new Path(new PathElement[] { this.caretPath.getElements().get(0), this.caretPath.getElements().get(1) }).getLayoutBounds();
        }
        final HitInfo hitTest = textNode.hitTest(new Point2D(b ? bounds.getMaxX() : bounds.getMinX(), (bounds.getMinY() + bounds.getMaxY()) / 2.0));
        final boolean leading = hitTest.isLeading();
        final Path path = new Path(textNode.rangeShape(hitTest.getCharIndex(), hitTest.getCharIndex() + 1));
        if ((b && path.getLayoutBounds().getMaxX() > bounds.getMaxX()) || (!b && path.getLayoutBounds().getMinX() < bounds.getMinX())) {
            this.positionCaret(hitTest.getInsertionIndex(), !leading, false, false);
        }
        else {
            final int caretPosition = this.textArea.getCaretPosition();
            this.targetCaretX = (b ? 0.0 : Double.MAX_VALUE);
            this.downLines(b ? 1 : -1, false, false);
            this.targetCaretX = -1.0;
            if (caretPosition == this.textArea.getCaretPosition()) {
                if (b) {
                    this.textArea.forward();
                }
                else {
                    this.textArea.backward();
                }
            }
        }
    }
    
    private void downLines(final int n, final boolean b, final boolean b2) {
        final Text textNode = this.getTextNode();
        final Bounds layoutBounds = this.caretPath.getLayoutBounds();
        double n2 = (layoutBounds.getMinY() + layoutBounds.getMaxY()) / 2.0 + n * this.lineHeight;
        if (n2 < 0.0) {
            n2 = 0.0;
        }
        final double targetCaretX = (this.targetCaretX >= 0.0) ? this.targetCaretX : layoutBounds.getMaxX();
        final HitInfo hitTest = textNode.hitTest(this.translateCaretPosition(new Point2D(targetCaretX, n2)));
        final int charIndex = hitTest.getCharIndex();
        final int caretPosition = textNode.getCaretPosition();
        final boolean caretBias = textNode.isCaretBias();
        textNode.setCaretBias(hitTest.isLeading());
        textNode.setCaretPosition(charIndex);
        TextAreaSkin.tmpCaretPath.getElements().clear();
        TextAreaSkin.tmpCaretPath.getElements().addAll(textNode.getCaretShape());
        TextAreaSkin.tmpCaretPath.setLayoutX(textNode.getLayoutX());
        TextAreaSkin.tmpCaretPath.setLayoutY(textNode.getLayoutY());
        final Bounds layoutBounds2 = TextAreaSkin.tmpCaretPath.getLayoutBounds();
        final double n3 = (layoutBounds2.getMinY() + layoutBounds2.getMaxY()) / 2.0;
        textNode.setCaretBias(caretBias);
        textNode.setCaretPosition(caretPosition);
        if (n == 0 || (n > 0 && n3 > layoutBounds.getMaxY()) || (n < 0 && n3 < layoutBounds.getMinY())) {
            this.positionCaret(hitTest.getInsertionIndex(), hitTest.isLeading(), b, b2);
            this.targetCaretX = targetCaretX;
        }
    }
    
    private void previousLine(final boolean b) {
        this.downLines(-1, b, false);
    }
    
    private void nextLine(final boolean b) {
        this.downLines(1, b, false);
    }
    
    private void previousPage(final boolean b) {
        this.downLines(-(int)(this.scrollPane.getViewportBounds().getHeight() / this.lineHeight), b, false);
    }
    
    private void nextPage(final boolean b) {
        this.downLines((int)(this.scrollPane.getViewportBounds().getHeight() / this.lineHeight), b, false);
    }
    
    private void lineStart(final boolean b, final boolean b2) {
        this.targetCaretX = 0.0;
        this.downLines(0, b, b2);
        this.targetCaretX = -1.0;
    }
    
    private void lineEnd(final boolean b, final boolean b2) {
        this.targetCaretX = Double.MAX_VALUE;
        this.downLines(0, b, b2);
        this.targetCaretX = -1.0;
    }
    
    private void paragraphStart(final boolean b, final boolean b2) {
        final TextArea textArea = this.getSkinnable();
        final String valueSafe = textArea.textProperty().getValueSafe();
        int caretPosition = textArea.getCaretPosition();
        if (caretPosition > 0) {
            if (b && valueSafe.codePointAt(caretPosition - 1) == 10) {
                --caretPosition;
            }
            while (caretPosition > 0 && valueSafe.codePointAt(caretPosition - 1) != 10) {
                --caretPosition;
            }
            if (b2) {
                textArea.selectPositionCaret(caretPosition);
            }
            else {
                textArea.positionCaret(caretPosition);
                this.setForwardBias(true);
            }
        }
    }
    
    private void paragraphEnd(final boolean b, final boolean b2) {
        final TextArea textArea = this.getSkinnable();
        final String valueSafe = textArea.textProperty().getValueSafe();
        int caretPosition = textArea.getCaretPosition();
        final int length = valueSafe.length();
        boolean b3 = false;
        final boolean windows = PlatformUtil.isWindows();
        if (caretPosition < length) {
            if (b && valueSafe.codePointAt(caretPosition) == 10) {
                ++caretPosition;
                b3 = true;
            }
            if (!windows || !b3) {
                while (caretPosition < length && valueSafe.codePointAt(caretPosition) != 10) {
                    ++caretPosition;
                }
                if (windows && caretPosition < length) {
                    ++caretPosition;
                }
            }
            if (b2) {
                textArea.selectPositionCaret(caretPosition);
            }
            else {
                textArea.positionCaret(caretPosition);
            }
        }
    }
    
    @Override
    protected PathElement[] getUnderlineShape(final int n, final int n2) {
        int n3 = 0;
        for (final Text text : this.paragraphNodes.getChildren()) {
            final int n4 = n3 + text.textProperty().getValueSafe().length();
            if (n4 >= n) {
                return text.underlineShape(n - n3, n2 - n3);
            }
            n3 = n4 + 1;
        }
        return null;
    }
    
    @Override
    protected PathElement[] getRangeShape(final int n, final int n2) {
        int n3 = 0;
        for (final Text text : this.paragraphNodes.getChildren()) {
            final int n4 = n3 + text.textProperty().getValueSafe().length();
            if (n4 >= n) {
                return text.rangeShape(n - n3, n2 - n3);
            }
            n3 = n4 + 1;
        }
        return null;
    }
    
    @Override
    protected void addHighlight(final List<? extends Node> list, final int n) {
        int n2 = 0;
        Node node = null;
        for (final Text text : this.paragraphNodes.getChildren()) {
            final int n3 = n2 + text.textProperty().getValueSafe().length();
            if (n3 >= n) {
                node = text;
                break;
            }
            n2 = n3 + 1;
        }
        if (node != null) {
            for (final Node node2 : list) {
                node2.setLayoutX(node.getLayoutX());
                node2.setLayoutY(node.getLayoutY());
            }
        }
        this.contentView.getChildren().addAll((Collection<?>)list);
    }
    
    @Override
    protected void removeHighlight(final List<? extends Node> list) {
        this.contentView.getChildren().removeAll(list);
    }
    
    @Override
    public Point2D getMenuPosition() {
        this.contentView.layoutChildren();
        Point2D menuPosition = super.getMenuPosition();
        if (menuPosition != null) {
            menuPosition = new Point2D(Math.max(0.0, menuPosition.getX() - this.contentView.snappedLeftInset() - this.getSkinnable().getScrollLeft()), Math.max(0.0, menuPosition.getY() - this.contentView.snappedTopInset() - this.getSkinnable().getScrollTop()));
        }
        return menuPosition;
    }
    
    public Bounds getCaretBounds() {
        return this.getSkinnable().sceneToLocal(this.caretPath.localToScene(this.caretPath.getBoundsInLocal()));
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case LINE_FOR_OFFSET:
            case LINE_START:
            case LINE_END:
            case BOUNDS_FOR_RANGE:
            case OFFSET_AT_POINT: {
                return this.getTextNode().queryAccessibleAttribute(accessibleAttribute, array);
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
        throw new UnsupportedOperationException();
    }
    
    public double computeBaselineOffset(final double n, final double n2, final double n3, final double n4) {
        return Utils.getAscent(this.getSkinnable().getFont(), this.paragraphNodes.getChildren().get(0).getBoundsType()) + this.contentView.snappedTopInset() + this.textArea.snappedTopInset();
    }
    
    private char getCharacter(final int n) {
        final int size = this.paragraphNodes.getChildren().size();
        int i = 0;
        int index = n;
        String text = null;
        while (i < size) {
            text = this.paragraphNodes.getChildren().get(i).getText();
            final int n2 = text.length() + 1;
            if (index < n2) {
                break;
            }
            index -= n2;
            ++i;
        }
        return (index == text.length()) ? '\n' : text.charAt(index);
    }
    
    @Override
    protected int getInsertionPoint(final double n, final double n2) {
        final TextArea textArea = this.getSkinnable();
        final int size = this.paragraphNodes.getChildren().size();
        int nextInsertionPoint = -1;
        if (size > 0) {
            if (n2 < this.contentView.snappedTopInset()) {
                nextInsertionPoint = this.getNextInsertionPoint(this.paragraphNodes.getChildren().get(0), n, -1, VerticalDirection.DOWN);
            }
            else if (n2 > this.contentView.snappedTopInset() + this.contentView.getHeight()) {
                final Text text = this.paragraphNodes.getChildren().get(size - 1);
                nextInsertionPoint = this.getNextInsertionPoint(text, n, -1, VerticalDirection.UP) + (textArea.getLength() - text.getText().length());
            }
            else {
                int n3 = 0;
                for (int i = 0; i < size; ++i) {
                    final Text text2 = this.paragraphNodes.getChildren().get(i);
                    final double n4 = text2.getLayoutY() + text2.getBoundsInLocal().getMinY();
                    if (n2 >= n4 && n2 < n4 + text2.getBoundsInLocal().getHeight()) {
                        nextInsertionPoint = this.getInsertionPoint(text2, n - text2.getLayoutX(), n2 - text2.getLayoutY()) + n3;
                        break;
                    }
                    n3 += text2.getText().length() + 1;
                }
            }
        }
        return nextInsertionPoint;
    }
    
    public void positionCaret(final HitInfo hitInfo, final boolean b) {
        this.positionCaret(hitInfo.getInsertionIndex(), hitInfo.isLeading(), b, false);
    }
    
    private void positionCaret(int n, boolean forwardBias, final boolean b, final boolean b2) {
        final boolean b3 = n > 0 && n <= this.getSkinnable().getLength() && this.getSkinnable().getText().codePointAt(n - 1) == 10;
        if (!forwardBias && b3) {
            forwardBias = true;
            --n;
        }
        if (b) {
            if (b2) {
                this.getSkinnable().extendSelection(n);
            }
            else {
                this.getSkinnable().selectPositionCaret(n);
            }
        }
        else {
            this.getSkinnable().positionCaret(n);
        }
        this.setForwardBias(forwardBias);
    }
    
    @Override
    public Rectangle2D getCharacterBounds(final int i) {
        final TextArea textArea = this.getSkinnable();
        int size = this.paragraphNodes.getChildren().size();
        int n = textArea.getLength() + 1;
        Text text;
        do {
            text = this.paragraphNodes.getChildren().get(--size);
            n -= text.getText().length() + 1;
        } while (i < n);
        int n2 = i - n;
        boolean b = false;
        if (n2 == text.getText().length()) {
            --n2;
            b = true;
        }
        this.characterBoundingPath.getElements().clear();
        this.characterBoundingPath.getElements().addAll(text.rangeShape(n2, n2 + 1));
        this.characterBoundingPath.setLayoutX(text.getLayoutX());
        this.characterBoundingPath.setLayoutY(text.getLayoutY());
        final Bounds boundsInLocal = this.characterBoundingPath.getBoundsInLocal();
        double n3 = boundsInLocal.getMinX() + text.getLayoutX() - textArea.getScrollLeft();
        final double n4 = boundsInLocal.getMinY() + text.getLayoutY() - textArea.getScrollTop();
        double n5 = boundsInLocal.isEmpty() ? 0.0 : boundsInLocal.getWidth();
        final double n6 = boundsInLocal.isEmpty() ? 0.0 : boundsInLocal.getHeight();
        if (b) {
            n3 += n5;
            n5 = 0.0;
        }
        return new Rectangle2D(n3, n4, n5, n6);
    }
    
    @Override
    protected void scrollCharacterToVisible(final int n) {
        Platform.runLater(() -> {
            if (this.getSkinnable().getLength() != 0) {
                this.scrollBoundsToVisible(this.getCharacterBounds(n));
            }
        });
    }
    
    @Override
    TextAreaBehavior getBehavior() {
        return this.behavior;
    }
    
    private void createPromptNode() {
        if (this.promptNode == null && this.usePromptText.get()) {
            this.promptNode = new Text();
            this.contentView.getChildren().add(0, this.promptNode);
            this.promptNode.setManaged(false);
            this.promptNode.getStyleClass().add("text");
            this.promptNode.visibleProperty().bind(this.usePromptText);
            this.promptNode.fontProperty().bind((ObservableValue<?>)this.getSkinnable().fontProperty());
            this.promptNode.textProperty().bind(this.getSkinnable().promptTextProperty());
            this.promptNode.fillProperty().bind((ObservableValue<?>)this.promptTextFillProperty());
        }
    }
    
    private void addParagraphNode(final int n, final String s) {
        final TextArea textArea = this.getSkinnable();
        final Text text = new Text(s);
        text.setTextOrigin(VPos.TOP);
        text.setManaged(false);
        text.getStyleClass().add("text");
        text.boundsTypeProperty().addListener((p0, p1, p2) -> {
            this.invalidateMetrics();
            this.updateFontMetrics();
            return;
        });
        this.paragraphNodes.getChildren().add(n, text);
        text.fontProperty().bind((ObservableValue<?>)textArea.fontProperty());
        text.fillProperty().bind((ObservableValue<?>)this.textFillProperty());
        text.selectionFillProperty().bind((ObservableValue<?>)this.highlightTextFillProperty());
    }
    
    private double getScrollTopMax() {
        return Math.max(0.0, this.contentView.getHeight() - this.scrollPane.getViewportBounds().getHeight());
    }
    
    private double getScrollLeftMax() {
        return Math.max(0.0, this.contentView.getWidth() - this.scrollPane.getViewportBounds().getWidth());
    }
    
    private int getInsertionPoint(final Text text, final double n, final double n2) {
        return text.hitTest(new Point2D(n, n2)).getInsertionIndex();
    }
    
    private int getNextInsertionPoint(final Text text, final double n, final int n2, final VerticalDirection verticalDirection) {
        return 0;
    }
    
    private void scrollCaretToVisible() {
        final TextArea textArea = this.getSkinnable();
        final Bounds layoutBounds = this.caretPath.getLayoutBounds();
        double n = layoutBounds.getMinX() - textArea.getScrollLeft();
        double n2 = layoutBounds.getMinY() - textArea.getScrollTop();
        double width = layoutBounds.getWidth();
        double height = layoutBounds.getHeight();
        if (TextAreaSkin.SHOW_HANDLES) {
            if (this.caretHandle.isVisible()) {
                height += this.caretHandle.getHeight();
            }
            else if (this.selectionHandle1.isVisible() && this.selectionHandle2.isVisible()) {
                n -= this.selectionHandle1.getWidth() / 2.0;
                n2 -= this.selectionHandle1.getHeight();
                width += this.selectionHandle1.getWidth() / 2.0 + this.selectionHandle2.getWidth() / 2.0;
                height += this.selectionHandle1.getHeight() + this.selectionHandle2.getHeight();
            }
        }
        if (width > 0.0 && height > 0.0) {
            this.scrollBoundsToVisible(new Rectangle2D(n, n2, width, height));
        }
    }
    
    private void scrollBoundsToVisible(final Rectangle2D rectangle2D) {
        final TextArea textArea = this.getSkinnable();
        final Bounds viewportBounds = this.scrollPane.getViewportBounds();
        final double width = viewportBounds.getWidth();
        final double height = viewportBounds.getHeight();
        final double scrollTop = textArea.getScrollTop();
        final double scrollLeft = textArea.getScrollLeft();
        final double n = 6.0;
        if (rectangle2D.getMinY() < 0.0) {
            double scrollTop2 = scrollTop + rectangle2D.getMinY();
            if (scrollTop2 <= this.contentView.snappedTopInset()) {
                scrollTop2 = 0.0;
            }
            textArea.setScrollTop(scrollTop2);
        }
        else if (this.contentView.snappedTopInset() + rectangle2D.getMaxY() > height) {
            double scrollTopMax = scrollTop + this.contentView.snappedTopInset() + rectangle2D.getMaxY() - height;
            if (scrollTopMax >= this.getScrollTopMax() - this.contentView.snappedBottomInset()) {
                scrollTopMax = this.getScrollTopMax();
            }
            textArea.setScrollTop(scrollTopMax);
        }
        if (rectangle2D.getMinX() < 0.0) {
            double scrollLeft2 = scrollLeft + rectangle2D.getMinX() - n;
            if (scrollLeft2 <= this.contentView.snappedLeftInset() + n) {
                scrollLeft2 = 0.0;
            }
            textArea.setScrollLeft(scrollLeft2);
        }
        else if (this.contentView.snappedLeftInset() + rectangle2D.getMaxX() > width) {
            double scrollLeftMax = scrollLeft + this.contentView.snappedLeftInset() + rectangle2D.getMaxX() - width + n;
            if (scrollLeftMax >= this.getScrollLeftMax() - this.contentView.snappedRightInset() - n) {
                scrollLeftMax = this.getScrollLeftMax();
            }
            textArea.setScrollLeft(scrollLeftMax);
        }
    }
    
    private void updatePrefViewportWidth() {
        this.scrollPane.setPrefViewportWidth(this.getSkinnable().getPrefColumnCount() * this.characterWidth + this.contentView.snappedLeftInset() + this.contentView.snappedRightInset());
        this.scrollPane.setMinViewportWidth(this.characterWidth + this.contentView.snappedLeftInset() + this.contentView.snappedRightInset());
    }
    
    private void updatePrefViewportHeight() {
        this.scrollPane.setPrefViewportHeight(this.getSkinnable().getPrefRowCount() * this.lineHeight + this.contentView.snappedTopInset() + this.contentView.snappedBottomInset());
        this.scrollPane.setMinViewportHeight(this.lineHeight + this.contentView.snappedTopInset() + this.contentView.snappedBottomInset());
    }
    
    private void updateFontMetrics() {
        this.lineHeight = Utils.getLineHeight(this.getSkinnable().getFont(), this.paragraphNodes.getChildren().get(0).getBoundsType());
        this.characterWidth = this.fontMetrics.get().getCharWidth('W');
    }
    
    private double getTextTranslateX() {
        return this.contentView.snappedLeftInset();
    }
    
    private double getTextTranslateY() {
        return this.contentView.snappedTopInset();
    }
    
    private double getTextLeft() {
        return 0.0;
    }
    
    private Point2D translateCaretPosition(final Point2D point2D) {
        return point2D;
    }
    
    private Text getTextNode() {
        return this.paragraphNodes.getChildren().get(0);
    }
    
    private void updateTextNodeCaretPos(final int caretPosition) {
        final Text textNode = this.getTextNode();
        if (this.isForwardBias()) {
            textNode.setCaretPosition(caretPosition);
        }
        else {
            textNode.setCaretPosition(caretPosition - 1);
        }
        textNode.caretBiasProperty().set(this.isForwardBias());
    }
    
    static {
        tmpCaretPath = new Path();
    }
    
    private class ContentView extends Region
    {
        private ContentView() {
            this.getStyleClass().add("content");
            this.addEventHandler(MouseEvent.MOUSE_PRESSED, mouseEvent -> {
                TextAreaSkin.this.behavior.mousePressed(mouseEvent);
                mouseEvent.consume();
                return;
            });
            this.addEventHandler(MouseEvent.MOUSE_RELEASED, mouseEvent2 -> {
                TextAreaSkin.this.behavior.mouseReleased(mouseEvent2);
                mouseEvent2.consume();
                return;
            });
            this.addEventHandler(MouseEvent.MOUSE_DRAGGED, mouseEvent3 -> {
                TextAreaSkin.this.behavior.mouseDragged(mouseEvent3);
                mouseEvent3.consume();
            });
        }
        
        @Override
        protected ObservableList<Node> getChildren() {
            return super.getChildren();
        }
        
        @Override
        public Orientation getContentBias() {
            return Orientation.HORIZONTAL;
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            if (TextAreaSkin.this.computedPrefWidth < 0.0) {
                double max = 0.0;
                for (final Text text : TextAreaSkin.this.paragraphNodes.getChildren()) {
                    max = Math.max(max, Utils.computeTextWidth(text.getFont(), text.getText(), 0.0));
                }
                final double a = max + (this.snappedLeftInset() + this.snappedRightInset());
                final Bounds viewportBounds = TextAreaSkin.this.scrollPane.getViewportBounds();
                TextAreaSkin.this.computedPrefWidth = Math.max(a, (viewportBounds != null) ? viewportBounds.getWidth() : 0.0);
            }
            return TextAreaSkin.this.computedPrefWidth;
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            if (n != TextAreaSkin.this.widthForComputedPrefHeight) {
                TextAreaSkin.this.invalidateMetrics();
                TextAreaSkin.this.widthForComputedPrefHeight = n;
            }
            if (TextAreaSkin.this.computedPrefHeight < 0.0) {
                double max;
                if (n == -1.0) {
                    max = 0.0;
                }
                else {
                    max = Math.max(n - (this.snappedLeftInset() + this.snappedRightInset()), 0.0);
                }
                double n2 = 0.0;
                for (final Text text : TextAreaSkin.this.paragraphNodes.getChildren()) {
                    n2 += Utils.computeTextHeight(text.getFont(), text.getText(), max, text.getBoundsType());
                }
                final double a = n2 + (this.snappedTopInset() + this.snappedBottomInset());
                final Bounds viewportBounds = TextAreaSkin.this.scrollPane.getViewportBounds();
                TextAreaSkin.this.computedPrefHeight = Math.max(a, (viewportBounds != null) ? viewportBounds.getHeight() : 0.0);
            }
            return TextAreaSkin.this.computedPrefHeight;
        }
        
        @Override
        protected double computeMinWidth(final double n) {
            if (TextAreaSkin.this.computedMinWidth < 0.0) {
                TextAreaSkin.this.computedMinWidth = Math.min(TextAreaSkin.this.characterWidth + (this.snappedLeftInset() + this.snappedRightInset()), this.computePrefWidth(n));
            }
            return TextAreaSkin.this.computedMinWidth;
        }
        
        @Override
        protected double computeMinHeight(final double n) {
            if (TextAreaSkin.this.computedMinHeight < 0.0) {
                TextAreaSkin.this.computedMinHeight = Math.min(TextAreaSkin.this.lineHeight + (this.snappedTopInset() + this.snappedBottomInset()), this.computePrefHeight(n));
            }
            return TextAreaSkin.this.computedMinHeight;
        }
        
        public void layoutChildren() {
            final TextArea textArea = TextAreaSkin.this.getSkinnable();
            final double width = this.getWidth();
            final double snappedTopInset = this.snappedTopInset();
            final double snappedLeftInset = this.snappedLeftInset();
            final double max = Math.max(width - (snappedLeftInset + this.snappedRightInset()), 0.0);
            double layoutY = snappedTopInset;
            final ObservableList<Node> children = TextAreaSkin.this.paragraphNodes.getChildren();
            for (int i = 0; i < children.size(); ++i) {
                final Text text = (Text)children.get(i);
                text.setWrappingWidth(max);
                final Bounds boundsInLocal = text.getBoundsInLocal();
                text.setLayoutX(snappedLeftInset);
                text.setLayoutY(layoutY);
                layoutY += boundsInLocal.getHeight();
            }
            if (TextAreaSkin.this.promptNode != null) {
                TextAreaSkin.this.promptNode.setLayoutX(snappedLeftInset);
                TextAreaSkin.this.promptNode.setLayoutY(snappedTopInset + TextAreaSkin.this.promptNode.getBaselineOffset());
                TextAreaSkin.this.promptNode.setWrappingWidth(max);
            }
            final IndexRange selection = textArea.getSelection();
            final Bounds boundsInParent = TextAreaSkin.this.caretPath.getBoundsInParent();
            TextAreaSkin.this.selectionHighlightGroup.getChildren().clear();
            final int j = textArea.getCaretPosition();
            final int k = textArea.getAnchor();
            if (TextInputControlSkin.SHOW_HANDLES) {
                if (selection.getLength() > 0) {
                    TextAreaSkin.this.selectionHandle1.resize(TextAreaSkin.this.selectionHandle1.prefWidth(-1.0), TextAreaSkin.this.selectionHandle1.prefHeight(-1.0));
                    TextAreaSkin.this.selectionHandle2.resize(TextAreaSkin.this.selectionHandle2.prefWidth(-1.0), TextAreaSkin.this.selectionHandle2.prefHeight(-1.0));
                }
                else {
                    TextAreaSkin.this.caretHandle.resize(TextAreaSkin.this.caretHandle.prefWidth(-1.0), TextAreaSkin.this.caretHandle.prefHeight(-1.0));
                }
                if (selection.getLength() > 0) {
                    int size = children.size();
                    int n = textArea.getLength() + 1;
                    Text text2;
                    do {
                        text2 = children.get(--size);
                        n -= text2.getText().length() + 1;
                    } while (k < n);
                    TextAreaSkin.this.updateTextNodeCaretPos(k - n);
                    TextAreaSkin.this.caretPath.getElements().clear();
                    TextAreaSkin.this.caretPath.getElements().addAll(text2.getCaretShape());
                    TextAreaSkin.this.caretPath.setLayoutX(text2.getLayoutX());
                    TextAreaSkin.this.caretPath.setLayoutY(text2.getLayoutY());
                    final Bounds boundsInParent2 = TextAreaSkin.this.caretPath.getBoundsInParent();
                    if (j < k) {
                        TextAreaSkin.this.selectionHandle2.setLayoutX(boundsInParent2.getMinX() - TextAreaSkin.this.selectionHandle2.getWidth() / 2.0);
                        TextAreaSkin.this.selectionHandle2.setLayoutY(boundsInParent2.getMaxY() - 1.0);
                    }
                    else {
                        TextAreaSkin.this.selectionHandle1.setLayoutX(boundsInParent2.getMinX() - TextAreaSkin.this.selectionHandle1.getWidth() / 2.0);
                        TextAreaSkin.this.selectionHandle1.setLayoutY(boundsInParent2.getMinY() - TextAreaSkin.this.selectionHandle1.getHeight() + 1.0);
                    }
                }
            }
            int size2 = children.size();
            int n2 = textArea.getLength() + 1;
            Text text3;
            do {
                text3 = children.get(--size2);
                n2 -= text3.getText().length() + 1;
            } while (j < n2);
            TextAreaSkin.this.updateTextNodeCaretPos(j - n2);
            TextAreaSkin.this.caretPath.getElements().clear();
            TextAreaSkin.this.caretPath.getElements().addAll(text3.getCaretShape());
            TextAreaSkin.this.caretPath.setLayoutX(text3.getLayoutX());
            text3.setLayoutX(2.0 * text3.getLayoutX() - text3.getBoundsInParent().getMinX());
            TextAreaSkin.this.caretPath.setLayoutY(text3.getLayoutY());
            if (boundsInParent == null || !boundsInParent.equals(TextAreaSkin.this.caretPath.getBoundsInParent())) {
                TextAreaSkin.this.scrollCaretToVisible();
            }
            int selectionStart = selection.getStart();
            int a = selection.getEnd();
            for (int l = 0; l < children.size(); ++l) {
                final Text text4 = children.get(l);
                final int b = text4.getText().length() + 1;
                if (a > selectionStart && selectionStart < b) {
                    text4.setSelectionStart(selectionStart);
                    text4.setSelectionEnd(Math.min(a, b));
                    final Path path = new Path();
                    path.setManaged(false);
                    path.setStroke(null);
                    final PathElement[] selectionShape = text4.getSelectionShape();
                    if (selectionShape != null) {
                        path.getElements().addAll(selectionShape);
                    }
                    TextAreaSkin.this.selectionHighlightGroup.getChildren().add(path);
                    TextAreaSkin.this.selectionHighlightGroup.setVisible(true);
                    path.setLayoutX(text4.getLayoutX());
                    path.setLayoutY(text4.getLayoutY());
                    TextAreaSkin.this.updateHighlightFill();
                }
                else {
                    text4.setSelectionStart(-1);
                    text4.setSelectionEnd(-1);
                    TextAreaSkin.this.selectionHighlightGroup.setVisible(false);
                }
                selectionStart = Math.max(0, selectionStart - b);
                a = Math.max(0, a - b);
            }
            if (TextInputControlSkin.SHOW_HANDLES) {
                final Bounds boundsInParent3 = TextAreaSkin.this.caretPath.getBoundsInParent();
                if (selection.getLength() > 0) {
                    if (j < k) {
                        TextAreaSkin.this.selectionHandle1.setLayoutX(boundsInParent3.getMinX() - TextAreaSkin.this.selectionHandle1.getWidth() / 2.0);
                        TextAreaSkin.this.selectionHandle1.setLayoutY(boundsInParent3.getMinY() - TextAreaSkin.this.selectionHandle1.getHeight() + 1.0);
                    }
                    else {
                        TextAreaSkin.this.selectionHandle2.setLayoutX(boundsInParent3.getMinX() - TextAreaSkin.this.selectionHandle2.getWidth() / 2.0);
                        TextAreaSkin.this.selectionHandle2.setLayoutY(boundsInParent3.getMaxY() - 1.0);
                    }
                }
                else {
                    TextAreaSkin.this.caretHandle.setLayoutX(boundsInParent3.getMinX() - TextAreaSkin.this.caretHandle.getWidth() / 2.0 + 1.0);
                    TextAreaSkin.this.caretHandle.setLayoutY(boundsInParent3.getMaxY());
                }
            }
            if (TextAreaSkin.this.scrollPane.getPrefViewportWidth() == 0.0 || TextAreaSkin.this.scrollPane.getPrefViewportHeight() == 0.0) {
                TextAreaSkin.this.updatePrefViewportWidth();
                TextAreaSkin.this.updatePrefViewportHeight();
                if ((this.getParent() != null && TextAreaSkin.this.scrollPane.getPrefViewportWidth() > 0.0) || TextAreaSkin.this.scrollPane.getPrefViewportHeight() > 0.0) {
                    this.getParent().requestLayout();
                }
            }
            final Bounds viewportBounds = TextAreaSkin.this.scrollPane.getViewportBounds();
            final boolean fitToWidth = TextAreaSkin.this.scrollPane.isFitToWidth();
            final boolean fitToHeight = TextAreaSkin.this.scrollPane.isFitToHeight();
            final boolean b2 = textArea.isWrapText() || this.computePrefWidth(-1.0) <= viewportBounds.getWidth();
            final boolean b3 = this.computePrefHeight(width) <= viewportBounds.getHeight();
            if (fitToWidth != b2 || fitToHeight != b3) {
                final boolean fitToWidth2;
                final boolean fitToHeight2;
                Platform.runLater(() -> {
                    TextAreaSkin.this.scrollPane.setFitToWidth(fitToWidth2);
                    TextAreaSkin.this.scrollPane.setFitToHeight(fitToHeight2);
                    return;
                });
                this.getParent().requestLayout();
            }
        }
    }
}
