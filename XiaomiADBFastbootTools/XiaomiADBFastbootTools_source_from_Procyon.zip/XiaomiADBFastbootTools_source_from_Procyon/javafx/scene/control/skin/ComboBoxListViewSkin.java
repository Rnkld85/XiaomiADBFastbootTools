// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.beans.Observable;
import javafx.event.EventTarget;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.SelectionMode;
import javafx.scene.AccessibleRole;
import javafx.scene.control.MultipleSelectionModel;
import javafx.collections.FXCollections;
import com.sun.javafx.scene.control.behavior.ComboBoxBaseBehavior;
import javafx.scene.control.Control;
import javafx.scene.Node;
import javafx.util.StringConverter;
import javafx.scene.control.TextField;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.beans.value.ObservableValue;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.control.ComboBoxBase;
import javafx.css.PseudoClass;
import javafx.beans.property.BooleanProperty;
import javafx.collections.WeakListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;
import com.sun.javafx.scene.control.behavior.ComboBoxListViewBehavior;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import javafx.scene.control.ListCell;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;

public class ComboBoxListViewSkin<T> extends ComboBoxPopupControl<T>
{
    private static final String COMBO_BOX_ROWS_TO_MEASURE_WIDTH_KEY = "comboBoxRowsToMeasureWidth";
    private final ComboBox<T> comboBox;
    private ObservableList<T> comboBoxItems;
    private ListCell<T> buttonCell;
    private Callback<ListView<T>, ListCell<T>> cellFactory;
    private final ListView<T> listView;
    private ObservableList<T> listViewItems;
    private boolean listSelectionLock;
    private boolean listViewSelectionDirty;
    private final ComboBoxListViewBehavior behavior;
    private boolean itemCountDirty;
    private final ListChangeListener<T> listViewItemsListener;
    private final InvalidationListener itemsObserver;
    private final WeakListChangeListener<T> weakListViewItemsListener;
    private final BooleanProperty hideOnClick;
    private static final PseudoClass PSEUDO_CLASS_SELECTED;
    private static final PseudoClass PSEUDO_CLASS_EMPTY;
    private static final PseudoClass PSEUDO_CLASS_FILLED;
    
    public ComboBoxListViewSkin(final ComboBox<T> comboBox) {
        super(comboBox);
        this.listSelectionLock = false;
        this.listViewSelectionDirty = false;
        this.listViewItemsListener = new ListChangeListener<T>() {
            @Override
            public void onChanged(final Change<? extends T> change) {
                ComboBoxListViewSkin.this.itemCountDirty = true;
                ComboBoxListViewSkin.this.getSkinnable().requestLayout();
            }
        };
        this.weakListViewItemsListener = new WeakListChangeListener<T>(this.listViewItemsListener);
        this.hideOnClick = new SimpleBooleanProperty(this, "hideOnClick", true);
        this.behavior = new ComboBoxListViewBehavior((ComboBox<T>)comboBox);
        this.comboBox = comboBox;
        this.updateComboBoxItems();
        this.itemsObserver = (p0 -> {
            this.updateComboBoxItems();
            this.updateListViewItems();
            return;
        });
        comboBox.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver));
        (this.listView = this.createListView()).setManaged(false);
        this.getChildren().add(this.listView);
        this.updateListViewItems();
        this.updateCellFactory();
        this.updateButtonCell();
        this.updateValue();
        this.registerChangeListener(comboBox.itemsProperty(), p0 -> {
            this.updateComboBoxItems();
            this.updateListViewItems();
            return;
        });
        this.registerChangeListener(comboBox.promptTextProperty(), p0 -> this.updateDisplayNode());
        this.registerChangeListener(comboBox.cellFactoryProperty(), p0 -> this.updateCellFactory());
        this.registerChangeListener(comboBox.visibleRowCountProperty(), p0 -> {
            if (this.listView == null) {
                return;
            }
            else {
                this.listView.requestLayout();
                return;
            }
        });
        this.registerChangeListener(comboBox.converterProperty(), p0 -> this.updateListViewItems());
        this.registerChangeListener(comboBox.buttonCellProperty(), p0 -> {
            this.updateButtonCell();
            this.updateDisplayArea();
            return;
        });
        this.registerChangeListener(comboBox.valueProperty(), p1 -> {
            this.updateValue();
            comboBox.fireEvent(new ActionEvent());
            return;
        });
        this.registerChangeListener(comboBox.editableProperty(), p0 -> this.updateEditable());
        if (this.comboBox.isShowing()) {
            this.show();
        }
        this.comboBox.sceneProperty().addListener(observableValue -> {
            if (observableValue.getValue() == null) {
                this.comboBox.hide();
            }
        });
    }
    
    public final BooleanProperty hideOnClickProperty() {
        return this.hideOnClick;
    }
    
    public final boolean isHideOnClick() {
        return this.hideOnClick.get();
    }
    
    public final void setHideOnClick(final boolean b) {
        this.hideOnClick.set(b);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected TextField getEditor() {
        return this.getSkinnable().isEditable() ? this.getSkinnable().getEditor() : null;
    }
    
    @Override
    protected StringConverter<T> getConverter() {
        return (StringConverter<T>)this.getSkinnable().getConverter();
    }
    
    @Override
    public Node getDisplayNode() {
        Control control;
        if (this.comboBox.isEditable()) {
            control = this.getEditableInputNode();
        }
        else {
            control = this.buttonCell;
        }
        this.updateDisplayNode();
        return control;
    }
    
    public Node getPopupContent() {
        return this.listView;
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        this.reconfigurePopup();
        return 50.0;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final double max = Math.max(super.computePrefWidth(n, n2, n3, n4, n5), this.listView.prefWidth(n));
        this.reconfigurePopup();
        return max;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        this.reconfigurePopup();
        return super.computeMaxWidth(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        this.reconfigurePopup();
        return super.computeMinHeight(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        this.reconfigurePopup();
        return super.computePrefHeight(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        this.reconfigurePopup();
        return super.computeMaxHeight(n, n2, n3, n4, n5);
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        if (this.listViewSelectionDirty) {
            try {
                this.listSelectionLock = true;
                final T selectedItem = this.comboBox.getSelectionModel().getSelectedItem();
                this.listView.getSelectionModel().clearSelection();
                this.listView.getSelectionModel().select(selectedItem);
            }
            finally {
                this.listSelectionLock = false;
                this.listViewSelectionDirty = false;
            }
        }
        super.layoutChildren(n, n2, n3, n4);
    }
    
    @Override
    void updateDisplayNode() {
        if (this.getEditor() != null) {
            super.updateDisplayNode();
        }
        else {
            final T value = this.comboBox.getValue();
            final int indexOfComboBoxValueInItemsList = this.getIndexOfComboBoxValueInItemsList();
            if (indexOfComboBoxValueInItemsList > -1) {
                this.buttonCell.setItem(null);
                this.buttonCell.updateIndex(indexOfComboBoxValueInItemsList);
            }
            else {
                this.buttonCell.updateIndex(-1);
                final boolean updateDisplayText = this.updateDisplayText(this.buttonCell, value, false);
                this.buttonCell.pseudoClassStateChanged(ComboBoxListViewSkin.PSEUDO_CLASS_EMPTY, updateDisplayText);
                this.buttonCell.pseudoClassStateChanged(ComboBoxListViewSkin.PSEUDO_CLASS_FILLED, !updateDisplayText);
                this.buttonCell.pseudoClassStateChanged(ComboBoxListViewSkin.PSEUDO_CLASS_SELECTED, true);
            }
        }
    }
    
    @Override
    ComboBoxBaseBehavior getBehavior() {
        return this.behavior;
    }
    
    private void updateComboBoxItems() {
        this.comboBoxItems = this.comboBox.getItems();
        this.comboBoxItems = ((this.comboBoxItems == null) ? FXCollections.emptyObservableList() : this.comboBoxItems);
    }
    
    private void updateListViewItems() {
        if (this.listViewItems != null) {
            this.listViewItems.removeListener(this.weakListViewItemsListener);
        }
        this.listViewItems = this.comboBoxItems;
        this.listView.setItems(this.listViewItems);
        if (this.listViewItems != null) {
            this.listViewItems.addListener(this.weakListViewItemsListener);
        }
        this.itemCountDirty = true;
        this.getSkinnable().requestLayout();
    }
    
    private void updateValue() {
        final T value = this.comboBox.getValue();
        final MultipleSelectionModel<T> selectionModel = this.listView.getSelectionModel();
        final int indexOfComboBoxValueInItemsList = this.getIndexOfComboBoxValueInItemsList();
        if (value == null && indexOfComboBoxValueInItemsList == -1) {
            selectionModel.clearSelection();
        }
        else if (indexOfComboBoxValueInItemsList == -1) {
            this.listSelectionLock = true;
            selectionModel.clearSelection();
            this.listSelectionLock = false;
        }
        else {
            final int selectedIndex = this.comboBox.getSelectionModel().getSelectedIndex();
            if (selectedIndex >= 0 && selectedIndex < this.comboBoxItems.size()) {
                final Object value2 = this.comboBoxItems.get(selectedIndex);
                if ((value2 != null && value2.equals(value)) || (value2 == null && value == null)) {
                    selectionModel.select(selectedIndex);
                }
                else {
                    selectionModel.select(value);
                }
            }
            else {
                final int index = this.comboBoxItems.indexOf(value);
                if (index == -1) {
                    this.updateDisplayNode();
                }
                else {
                    selectionModel.select(index);
                }
            }
        }
    }
    
    private boolean updateDisplayText(final ListCell<T> listCell, final T t, final boolean b) {
        if (b) {
            if (listCell == null) {
                return true;
            }
            listCell.setGraphic(null);
            listCell.setText(null);
            return true;
        }
        else {
            if (t instanceof Node) {
                final Node graphic = listCell.getGraphic();
                final Node node = (Node)t;
                if (graphic == null || !graphic.equals(node)) {
                    listCell.setText(null);
                    listCell.setGraphic(node);
                }
                return node == null;
            }
            final StringConverter<T> converter = this.comboBox.getConverter();
            final String promptText = this.comboBox.getPromptText();
            final String text = (t == null && promptText != null) ? promptText : ((converter == null) ? ((t == null) ? null : t.toString()) : converter.toString(t));
            listCell.setText(text);
            listCell.setGraphic(null);
            return text == null || text.isEmpty();
        }
    }
    
    private int getIndexOfComboBoxValueInItemsList() {
        return this.comboBoxItems.indexOf(this.comboBox.getValue());
    }
    
    private void updateButtonCell() {
        (this.buttonCell = ((this.comboBox.getButtonCell() != null) ? this.comboBox.getButtonCell() : this.getDefaultCellFactory().call(this.listView))).setMouseTransparent(true);
        this.buttonCell.updateListView(this.listView);
        this.buttonCell.setAccessibleRole(AccessibleRole.NODE);
    }
    
    private void updateCellFactory() {
        final Callback<ListView<T>, ListCell<T>> cellFactory = this.comboBox.getCellFactory();
        this.cellFactory = ((cellFactory != null) ? cellFactory : this.getDefaultCellFactory());
        this.listView.setCellFactory(this.cellFactory);
    }
    
    private Callback<ListView<T>, ListCell<T>> getDefaultCellFactory() {
        return new Callback<ListView<T>, ListCell<T>>() {
            @Override
            public ListCell<T> call(final ListView<T> listView) {
                return new ListCell<T>() {
                    public void updateItem(final T t, final boolean b) {
                        super.updateItem(t, b);
                        ComboBoxListViewSkin.this.updateDisplayText(this, t, b);
                    }
                };
            }
        };
    }
    
    private ListView<T> createListView() {
        final ListView<T> listView = new ListView<T>() {
            {
                this.getProperties().put("selectFirstRowByDefault", false);
            }
            
            @Override
            protected double computeMinHeight(final double n) {
                return 30.0;
            }
            
            @Override
            protected double computePrefWidth(final double n) {
                double n2;
                if (this.getSkin() instanceof ListViewSkin) {
                    final ListViewSkin listViewSkin = (ListViewSkin)this.getSkin();
                    if (ComboBoxListViewSkin.this.itemCountDirty) {
                        listViewSkin.updateItemCount();
                        ComboBoxListViewSkin.this.itemCountDirty = false;
                    }
                    int intValue = -1;
                    if (ComboBoxListViewSkin.this.comboBox.getProperties().containsKey("comboBoxRowsToMeasureWidth")) {
                        intValue = (int)ComboBoxListViewSkin.this.comboBox.getProperties().get("comboBoxRowsToMeasureWidth");
                    }
                    n2 = Math.max(ComboBoxListViewSkin.this.comboBox.getWidth(), listViewSkin.getMaxCellWidth(intValue) + 30.0);
                }
                else {
                    n2 = Math.max(100.0, ComboBoxListViewSkin.this.comboBox.getWidth());
                }
                if (this.getItems().isEmpty() && this.getPlaceholder() != null) {
                    n2 = Math.max(super.computePrefWidth(n), n2);
                }
                return Math.max(50.0, n2);
            }
            
            @Override
            protected double computePrefHeight(final double n) {
                return ComboBoxListViewSkin.this.getListViewPrefHeight();
            }
        };
        listView.setId("list-view");
        listView.placeholderProperty().bind((ObservableValue<?>)this.comboBox.placeholderProperty());
        listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listView.setFocusTraversable(false);
        listView.getSelectionModel().selectedIndexProperty().addListener(p0 -> {
            if (this.listSelectionLock) {
                return;
            }
            else {
                this.comboBox.getSelectionModel().select(this.listView.getSelectionModel().getSelectedIndex());
                this.updateDisplayNode();
                this.comboBox.notifyAccessibleAttributeChanged(AccessibleAttribute.TEXT);
                return;
            }
        });
        this.comboBox.getSelectionModel().selectedItemProperty().addListener(p0 -> this.listViewSelectionDirty = true);
        final Parent parent;
        final ObservableList list;
        listView.addEventFilter(MouseEvent.MOUSE_RELEASED, mouseEvent -> {
            mouseEvent.getTarget();
            if (parent instanceof Parent) {
                parent.getStyleClass();
                if (list.contains("thumb") || list.contains("track") || list.contains("decrement-arrow") || list.contains("increment-arrow")) {
                    return;
                }
            }
            if (this.isHideOnClick()) {
                this.comboBox.hide();
            }
            return;
        });
        listView.setOnKeyPressed(keyEvent -> {
            if (keyEvent.getCode() == KeyCode.ENTER || keyEvent.getCode() == KeyCode.SPACE || keyEvent.getCode() == KeyCode.ESCAPE) {
                this.comboBox.hide();
            }
            return;
        });
        return listView;
    }
    
    private double getListViewPrefHeight() {
        double n;
        if (this.listView.getSkin() instanceof VirtualContainerBase) {
            n = ((VirtualContainerBase)this.listView.getSkin()).getVirtualFlowPreferredHeight(this.comboBox.getVisibleRowCount());
        }
        else {
            n = Math.min(this.comboBoxItems.size() * 25, 200.0);
        }
        return n;
    }
    
    ListView<T> getListView() {
        return this.listView;
    }
    
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case FOCUS_ITEM: {
                if (this.comboBox.isShowing()) {
                    return this.listView.queryAccessibleAttribute(accessibleAttribute, array);
                }
                return null;
            }
            case TEXT: {
                final String accessibleText = this.comboBox.getAccessibleText();
                if (accessibleText != null && !accessibleText.isEmpty()) {
                    return accessibleText;
                }
                String promptText = this.comboBox.isEditable() ? this.getEditor().getText() : this.buttonCell.getText();
                if (promptText == null || promptText.isEmpty()) {
                    promptText = this.comboBox.getPromptText();
                }
                return promptText;
            }
            case SELECTION_START: {
                return (this.getEditor() != null) ? Integer.valueOf(this.getEditor().getSelection().getStart()) : null;
            }
            case SELECTION_END: {
                return (this.getEditor() != null) ? Integer.valueOf(this.getEditor().getSelection().getEnd()) : null;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        PSEUDO_CLASS_SELECTED = PseudoClass.getPseudoClass("selected");
        PSEUDO_CLASS_EMPTY = PseudoClass.getPseudoClass("empty");
        PSEUDO_CLASS_FILLED = PseudoClass.getPseudoClass("filled");
    }
}
