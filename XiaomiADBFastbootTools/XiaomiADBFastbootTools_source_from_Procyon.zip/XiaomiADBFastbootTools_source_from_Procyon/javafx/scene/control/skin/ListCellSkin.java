// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.geometry.Orientation;
import javafx.scene.control.ListView;
import javafx.beans.value.ObservableValue;
import javafx.beans.Observable;
import javafx.beans.InvalidationListener;
import com.sun.javafx.scene.control.behavior.ListCellBehavior;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.ListCell;

public class ListCellSkin<T> extends CellSkinBase<ListCell<T>>
{
    private double fixedCellSize;
    private boolean fixedCellSizeEnabled;
    private final BehaviorBase<ListCell<T>> behavior;
    
    public ListCellSkin(final ListCell<T> listCell) {
        super(listCell);
        this.behavior = (BehaviorBase<ListCell<T>>)new ListCellBehavior((ListCell<Object>)listCell);
        this.setupListeners();
    }
    
    private void setupListeners() {
        final ListView listView = this.getSkinnable().getListView();
        if (listView == null) {
            this.getSkinnable().listViewProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(final Observable observable) {
                    ListCellSkin.this.getSkinnable().listViewProperty().removeListener(this);
                    ListCellSkin.this.setupListeners();
                }
            });
        }
        else {
            this.fixedCellSize = listView.getFixedCellSize();
            this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0);
            this.registerChangeListener(listView.fixedCellSizeProperty(), p0 -> {
                this.fixedCellSize = this.getSkinnable().getListView().getFixedCellSize();
                this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0);
            });
        }
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final double computePrefWidth = super.computePrefWidth(n, n2, n3, n4, n5);
        final ListView listView = this.getSkinnable().getListView();
        return (listView == null) ? 0.0 : ((listView.getOrientation() == Orientation.VERTICAL) ? computePrefWidth : Math.max(computePrefWidth, this.getCellSize()));
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.fixedCellSizeEnabled) {
            return this.fixedCellSize;
        }
        final double cellSize = this.getCellSize();
        return (cellSize == 24.0) ? super.computePrefHeight(n, n2, n3, n4, n5) : cellSize;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.fixedCellSizeEnabled) {
            return this.fixedCellSize;
        }
        return super.computeMinHeight(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.fixedCellSizeEnabled) {
            return this.fixedCellSize;
        }
        return super.computeMaxHeight(n, n2, n3, n4, n5);
    }
}
