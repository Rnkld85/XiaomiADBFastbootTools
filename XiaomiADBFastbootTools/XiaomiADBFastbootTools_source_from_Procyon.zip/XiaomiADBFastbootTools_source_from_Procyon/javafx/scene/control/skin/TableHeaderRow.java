// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.input.MouseEvent;
import javafx.beans.Observable;
import java.util.Collection;
import javafx.beans.property.Property;
import java.util.Iterator;
import javafx.collections.ObservableList;
import java.util.ArrayList;
import javafx.geometry.Insets;
import javafx.scene.control.Control;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.geometry.Side;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import java.util.List;
import java.util.Collections;
import javafx.scene.Node;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.StringProperty;
import java.util.HashMap;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.BooleanProperty;
import javafx.collections.WeakListChangeListener;
import javafx.beans.WeakInvalidationListener;
import javafx.collections.ListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.scene.control.ContextMenu;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.TableColumnBase;
import java.util.Map;
import javafx.scene.layout.StackPane;

public class TableHeaderRow extends StackPane
{
    private final String MENU_SEPARATOR;
    private final VirtualFlow flow;
    final TableViewSkinBase<?, ?, ?, ?, ?> tableSkin;
    private Map<TableColumnBase, CheckMenuItem> columnMenuItems;
    private double scrollX;
    private double tableWidth;
    private Rectangle clip;
    private TableColumnHeader reorderingRegion;
    private StackPane dragHeader;
    private final Label dragHeaderLabel;
    private Region filler;
    private Pane cornerRegion;
    private ContextMenu columnPopupMenu;
    boolean columnDragLock;
    private InvalidationListener tableWidthListener;
    private InvalidationListener tablePaddingListener;
    private ListChangeListener visibleLeafColumnsListener;
    private final ListChangeListener tableColumnsListener;
    private final InvalidationListener columnTextListener;
    private final WeakInvalidationListener weakTableWidthListener;
    private final WeakInvalidationListener weakTablePaddingListener;
    private final WeakListChangeListener weakVisibleLeafColumnsListener;
    private final WeakListChangeListener weakTableColumnsListener;
    private final WeakInvalidationListener weakColumnTextListener;
    private BooleanProperty reordering;
    private ReadOnlyObjectWrapper<NestedTableColumnHeader> rootHeader;
    
    public TableHeaderRow(final TableViewSkinBase tableSkin) {
        this.MENU_SEPARATOR = ControlResources.getString("TableView.nestedColumnControlMenuSeparator");
        this.columnMenuItems = new HashMap<TableColumnBase, CheckMenuItem>();
        this.dragHeaderLabel = new Label();
        this.columnDragLock = false;
        this.tableWidthListener = (p0 -> this.updateTableWidth());
        this.tablePaddingListener = (p0 -> this.updateTableWidth());
        this.visibleLeafColumnsListener = (p0 -> this.getRootHeader().setHeadersNeedUpdate());
        this.tableColumnsListener = (change -> {
            while (change.next()) {
                this.updateTableColumnListeners(change.getAddedSubList(), change.getRemoved());
            }
            return;
        });
        final TableColumnBase tableColumnBase;
        final CheckMenuItem checkMenuItem;
        this.columnTextListener = (stringProperty -> {
            tableColumnBase = (TableColumnBase)stringProperty.getBean();
            checkMenuItem = this.columnMenuItems.get(tableColumnBase);
            if (checkMenuItem != null) {
                checkMenuItem.setText(this.getText(tableColumnBase.getText(), tableColumnBase));
            }
            return;
        });
        this.weakTableWidthListener = new WeakInvalidationListener(this.tableWidthListener);
        this.weakTablePaddingListener = new WeakInvalidationListener(this.tablePaddingListener);
        this.weakVisibleLeafColumnsListener = new WeakListChangeListener(this.visibleLeafColumnsListener);
        this.weakTableColumnsListener = new WeakListChangeListener(this.tableColumnsListener);
        this.weakColumnTextListener = new WeakInvalidationListener(this.columnTextListener);
        this.reordering = new SimpleBooleanProperty((Object)this, "reordering", false) {
            @Override
            protected void invalidated() {
                final TableColumnHeader reorderingRegion = TableHeaderRow.this.getReorderingRegion();
                if (reorderingRegion != null) {
                    final double n = (reorderingRegion.getNestedColumnHeader() != null) ? reorderingRegion.getNestedColumnHeader().getHeight() : TableHeaderRow.this.getReorderingRegion().getHeight();
                    TableHeaderRow.this.dragHeader.resize(TableHeaderRow.this.dragHeader.getWidth(), n);
                    TableHeaderRow.this.dragHeader.setTranslateY(TableHeaderRow.this.getHeight() - n);
                }
                TableHeaderRow.this.dragHeader.setVisible(TableHeaderRow.this.isReordering());
            }
        };
        this.rootHeader = new ReadOnlyObjectWrapper<NestedTableColumnHeader>(this, "rootHeader");
        this.tableSkin = (TableViewSkinBase<?, ?, ?, ?, ?>)tableSkin;
        this.flow = tableSkin.flow;
        this.getStyleClass().setAll("column-header-background");
        (this.clip = new Rectangle()).setSmooth(false);
        this.clip.heightProperty().bind(this.heightProperty());
        this.setClip(this.clip);
        this.updateTableWidth();
        this.tableSkin.getSkinnable().widthProperty().addListener(this.weakTableWidthListener);
        this.tableSkin.getSkinnable().paddingProperty().addListener(this.weakTablePaddingListener);
        TableSkinUtils.getVisibleLeafColumns((TableViewSkinBase<?, ?, ?, ?, TableColumnBase>)tableSkin).addListener(this.weakVisibleLeafColumnsListener);
        this.columnPopupMenu = new ContextMenu();
        this.updateTableColumnListeners(TableSkinUtils.getColumns(this.tableSkin), Collections.emptyList());
        TableSkinUtils.getVisibleLeafColumns((TableViewSkinBase<?, ?, ?, ?, TableColumnBase>)tableSkin).addListener(this.weakTableColumnsListener);
        TableSkinUtils.getColumns(this.tableSkin).addListener(this.weakTableColumnsListener);
        (this.dragHeader = new StackPane()).setVisible(false);
        this.dragHeader.getStyleClass().setAll("column-drag-header");
        this.dragHeader.setManaged(false);
        this.dragHeader.setMouseTransparent(true);
        this.dragHeader.getChildren().add(this.dragHeaderLabel);
        final NestedTableColumnHeader rootHeader = this.createRootHeader();
        this.setRootHeader(rootHeader);
        rootHeader.setFocusTraversable(false);
        rootHeader.setTableHeaderRow(this);
        this.filler = new Region();
        this.filler.getStyleClass().setAll("filler");
        this.setOnMousePressed(p1 -> tableSkin.getSkinnable().requestFocus());
        final StackPane stackPane = new StackPane();
        stackPane.setSnapToPixel(false);
        stackPane.getStyleClass().setAll("show-hide-column-image");
        this.cornerRegion = new StackPane() {
            @Override
            protected void layoutChildren() {
                stackPane.resize(stackPane.snappedLeftInset() + stackPane.snappedRightInset(), stackPane.snappedTopInset() + stackPane.snappedBottomInset());
                this.positionInArea(stackPane, 0.0, 0.0, this.getWidth(), this.getHeight() - 3.0, 0.0, HPos.CENTER, VPos.CENTER);
            }
        };
        this.cornerRegion.getStyleClass().setAll("show-hide-columns-button");
        this.cornerRegion.getChildren().addAll(stackPane);
        final BooleanProperty tableMenuButtonVisibleProperty = TableSkinUtils.tableMenuButtonVisibleProperty(tableSkin);
        if (tableMenuButtonVisibleProperty != null) {
            this.cornerRegion.visibleProperty().bind(tableMenuButtonVisibleProperty);
        }
        this.cornerRegion.setOnMousePressed(mouseEvent -> {
            this.columnPopupMenu.show(this.cornerRegion, Side.BOTTOM, 0.0, 0.0);
            mouseEvent.consume();
            return;
        });
        this.getChildren().addAll(this.filler, rootHeader, this.cornerRegion, this.dragHeader);
    }
    
    final void setReordering(final boolean b) {
        this.reordering.set(b);
    }
    
    final boolean isReordering() {
        return this.reordering.get();
    }
    
    final BooleanProperty reorderingProperty() {
        return this.reordering;
    }
    
    private final ReadOnlyObjectProperty<NestedTableColumnHeader> rootHeaderProperty() {
        return this.rootHeader.getReadOnlyProperty();
    }
    
    final NestedTableColumnHeader getRootHeader() {
        return this.rootHeader.get();
    }
    
    private final void setRootHeader(final NestedTableColumnHeader nestedTableColumnHeader) {
        this.rootHeader.set(nestedTableColumnHeader);
    }
    
    @Override
    protected void layoutChildren() {
        final double scrollX = this.scrollX;
        final double snapSizeX = this.snapSizeX(this.getRootHeader().prefWidth(-1.0));
        final double n = this.getHeight() - this.snappedTopInset() - this.snappedBottomInset();
        final double snapSizeX2 = this.snapSizeX(this.flow.getVbar().prefWidth(-1.0));
        this.getRootHeader().resizeRelocate(scrollX, this.snappedTopInset(), snapSizeX, n);
        final Control skinnable = this.tableSkin.getSkinnable();
        if (skinnable == null) {
            return;
        }
        final BooleanProperty tableMenuButtonVisibleProperty = TableSkinUtils.tableMenuButtonVisibleProperty(this.tableSkin);
        final double n2 = this.tableWidth - snapSizeX + this.filler.getInsets().getLeft() - (skinnable.snappedLeftInset() + skinnable.snappedRightInset()) - ((tableMenuButtonVisibleProperty != null && tableMenuButtonVisibleProperty.get()) ? snapSizeX2 : 0.0);
        this.filler.setVisible(n2 > 0.0);
        if (n2 > 0.0) {
            this.filler.resizeRelocate(scrollX + snapSizeX, this.snappedTopInset(), n2, n);
        }
        this.cornerRegion.resizeRelocate(this.tableWidth - snapSizeX2, this.snappedTopInset(), snapSizeX2, n);
    }
    
    @Override
    protected double computePrefWidth(final double n) {
        return this.getRootHeader().prefWidth(n);
    }
    
    @Override
    protected double computeMinHeight(final double n) {
        return this.computePrefHeight(n);
    }
    
    @Override
    protected double computePrefHeight(final double n) {
        final double prefHeight = this.getRootHeader().prefHeight(n);
        return this.snappedTopInset() + ((prefHeight == 0.0) ? 24.0 : prefHeight) + this.snappedBottomInset();
    }
    
    void updateScrollX() {
        this.scrollX = (this.flow.getHbar().isVisible() ? (-this.flow.getHbar().getValue()) : 0.0);
        this.requestLayout();
        this.layout();
    }
    
    private void updateTableWidth() {
        final Control skinnable = this.tableSkin.getSkinnable();
        if (skinnable == null) {
            this.tableWidth = 0.0;
        }
        else {
            final Insets insets = (skinnable.getInsets() == null) ? Insets.EMPTY : skinnable.getInsets();
            this.tableWidth = this.snapSizeX(skinnable.getWidth()) - (this.snapSizeX(insets.getLeft()) + this.snapSizeX(insets.getRight()));
        }
        this.clip.setWidth(this.tableWidth);
    }
    
    protected NestedTableColumnHeader createRootHeader() {
        return new NestedTableColumnHeader(null);
    }
    
    TableColumnHeader getReorderingRegion() {
        return this.reorderingRegion;
    }
    
    void setReorderingColumn(final TableColumnBase tableColumnBase) {
        this.dragHeaderLabel.setText((tableColumnBase == null) ? "" : tableColumnBase.getText());
    }
    
    void setReorderingRegion(final TableColumnHeader reorderingRegion) {
        this.reorderingRegion = reorderingRegion;
        if (reorderingRegion != null) {
            this.dragHeader.resize(reorderingRegion.getWidth(), this.dragHeader.getHeight());
        }
    }
    
    void setDragHeaderX(final double translateX) {
        this.dragHeader.setTranslateX(translateX);
    }
    
    TableColumnHeader getColumnHeaderFor(final TableColumnBase<?, ?> tableColumnBase) {
        if (tableColumnBase == null) {
            return null;
        }
        final ArrayList<TableColumnBase<?, ?>> list = new ArrayList<TableColumnBase<?, ?>>();
        list.add(tableColumnBase);
        for (TableColumnBase<?, ?> tableColumnBase2 = tableColumnBase.getParentColumn(); tableColumnBase2 != null; tableColumnBase2 = tableColumnBase2.getParentColumn()) {
            list.add(0, tableColumnBase2);
        }
        TableColumnHeader tableColumnHeader = this.getRootHeader();
        for (int i = 0; i < list.size(); ++i) {
            tableColumnHeader = this.getColumnHeaderFor((TableColumnBase<?, ?>)list.get(i), tableColumnHeader);
        }
        return tableColumnHeader;
    }
    
    private TableColumnHeader getColumnHeaderFor(final TableColumnBase<?, ?> tableColumnBase, final TableColumnHeader tableColumnHeader) {
        if (tableColumnHeader instanceof NestedTableColumnHeader) {
            final ObservableList<TableColumnHeader> columnHeaders = ((NestedTableColumnHeader)tableColumnHeader).getColumnHeaders();
            for (int i = 0; i < columnHeaders.size(); ++i) {
                final TableColumnHeader tableColumnHeader2 = columnHeaders.get(i);
                if (tableColumnHeader2.getTableColumn() == tableColumnBase) {
                    return tableColumnHeader2;
                }
            }
        }
        return null;
    }
    
    private void updateTableColumnListeners(final List<? extends TableColumnBase<?, ?>> list, final List<? extends TableColumnBase<?, ?>> list2) {
        final Iterator<? extends TableColumnBase<?, ?>> iterator = list2.iterator();
        while (iterator.hasNext()) {
            this.remove((TableColumnBase<?, ?>)iterator.next());
        }
        this.rebuildColumnMenu();
    }
    
    private void remove(final TableColumnBase<?, ?> tableColumnBase) {
        if (tableColumnBase == null) {
            return;
        }
        final CheckMenuItem checkMenuItem = this.columnMenuItems.remove(tableColumnBase);
        if (checkMenuItem != null) {
            tableColumnBase.textProperty().removeListener(this.weakColumnTextListener);
            checkMenuItem.selectedProperty().unbindBidirectional(tableColumnBase.visibleProperty());
            this.columnPopupMenu.getItems().remove(checkMenuItem);
        }
        if (!tableColumnBase.getColumns().isEmpty()) {
            final Iterator<TableColumnBase<?, ?>> iterator = tableColumnBase.getColumns().iterator();
            while (iterator.hasNext()) {
                this.remove(iterator.next());
            }
        }
    }
    
    private void rebuildColumnMenu() {
        this.columnPopupMenu.getItems().clear();
        for (final TableColumnBase<?, ?> tableColumnBase : TableSkinUtils.getColumns(this.tableSkin)) {
            if (tableColumnBase.getColumns().isEmpty()) {
                this.createMenuItem(tableColumnBase);
            }
            else {
                final Iterator<TableColumnBase<?, ?>> iterator2 = this.getLeafColumns(tableColumnBase).iterator();
                while (iterator2.hasNext()) {
                    this.createMenuItem(iterator2.next());
                }
            }
        }
    }
    
    private List<TableColumnBase<?, ?>> getLeafColumns(final TableColumnBase<?, ?> tableColumnBase) {
        final ArrayList<Object> list = new ArrayList<Object>();
        for (final TableColumnBase<?, ?> tableColumnBase2 : tableColumnBase.getColumns()) {
            if (tableColumnBase2.getColumns().isEmpty()) {
                list.add(tableColumnBase2);
            }
            else {
                list.addAll(this.getLeafColumns(tableColumnBase2));
            }
        }
        return (List<TableColumnBase<?, ?>>)list;
    }
    
    private void createMenuItem(final TableColumnBase<?, ?> tableColumnBase) {
        CheckMenuItem checkMenuItem = this.columnMenuItems.get(tableColumnBase);
        if (checkMenuItem == null) {
            checkMenuItem = new CheckMenuItem();
            this.columnMenuItems.put(tableColumnBase, checkMenuItem);
        }
        checkMenuItem.setText(this.getText(tableColumnBase.getText(), tableColumnBase));
        tableColumnBase.textProperty().addListener(this.weakColumnTextListener);
        checkMenuItem.setDisable(tableColumnBase.visibleProperty().isBound());
        checkMenuItem.setSelected(tableColumnBase.isVisible());
        final CheckMenuItem checkMenuItem2;
        checkMenuItem.selectedProperty().addListener(p2 -> {
            if (tableColumnBase.visibleProperty().isBound()) {
                return;
            }
            else {
                tableColumnBase.setVisible(checkMenuItem2.isSelected());
                return;
            }
        });
        final CheckMenuItem checkMenuItem3;
        tableColumnBase.visibleProperty().addListener(p2 -> checkMenuItem3.setSelected(tableColumnBase.isVisible()));
        this.columnPopupMenu.getItems().add(checkMenuItem);
    }
    
    private String getText(final String s, final TableColumnBase tableColumnBase) {
        String s2 = s;
        for (TableColumnBase tableColumnBase2 = tableColumnBase.getParentColumn(); tableColumnBase2 != null; tableColumnBase2 = tableColumnBase2.getParentColumn()) {
            if (this.isColumnVisibleInHeader(tableColumnBase2, TableSkinUtils.getColumns(this.tableSkin))) {
                s2 = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, tableColumnBase2.getText(), this.MENU_SEPARATOR, s2);
            }
        }
        return s2;
    }
    
    private boolean isColumnVisibleInHeader(final TableColumnBase tableColumnBase, final List list) {
        if (tableColumnBase == null) {
            return false;
        }
        for (int i = 0; i < list.size(); ++i) {
            final TableColumnBase obj = list.get(i);
            if (tableColumnBase.equals(obj)) {
                return true;
            }
            if (!obj.getColumns().isEmpty() && this.isColumnVisibleInHeader(tableColumnBase, obj.getColumns())) {
                return true;
            }
        }
        return false;
    }
}
