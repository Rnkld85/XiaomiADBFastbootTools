// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.geometry.NodeOrientation;
import javafx.scene.Cursor;
import javafx.beans.value.ObservableBooleanValue;
import javafx.scene.paint.Paint;
import javafx.scene.paint.Color;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.TableView;
import javafx.util.Callback;
import javafx.scene.Node;
import java.util.Collection;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import java.util.Iterator;
import javafx.beans.value.ObservableValue;
import java.util.WeakHashMap;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.collections.WeakListChangeListener;
import javafx.collections.ListChangeListener;
import javafx.scene.shape.Rectangle;
import java.util.Map;
import javafx.scene.control.TableColumnBase;
import javafx.collections.ObservableList;

public class NestedTableColumnHeader extends TableColumnHeader
{
    static final String DEFAULT_STYLE_CLASS = "nested-column-header";
    private static final int DRAG_RECT_WIDTH = 4;
    private static final String TABLE_COLUMN_KEY = "TableColumn";
    private static final String TABLE_COLUMN_HEADER_KEY = "TableColumnHeader";
    private ObservableList<? extends TableColumnBase> columns;
    private TableColumnHeader label;
    private ObservableList<TableColumnHeader> columnHeaders;
    private ObservableList<TableColumnHeader> unmodifiableColumnHeaders;
    private double lastX;
    private double dragAnchorX;
    private Map<TableColumnBase<?, ?>, Rectangle> dragRects;
    boolean updateColumns;
    private final ListChangeListener<TableColumnBase> columnsListener;
    private final WeakListChangeListener weakColumnsListener;
    private static final EventHandler<MouseEvent> rectMousePressed;
    private static final EventHandler<MouseEvent> rectMouseDragged;
    private static final EventHandler<MouseEvent> rectMouseReleased;
    private static final EventHandler<MouseEvent> rectCursorChangeListener;
    
    public NestedTableColumnHeader(final TableColumnBase tableColumnBase) {
        super(tableColumnBase);
        this.lastX = 0.0;
        this.dragAnchorX = 0.0;
        this.dragRects = new WeakHashMap<TableColumnBase<?, ?>, Rectangle>();
        this.updateColumns = true;
        this.columnsListener = (p0 -> this.setHeadersNeedUpdate());
        this.weakColumnsListener = new WeakListChangeListener((ListChangeListener<E>)this.columnsListener);
        this.setFocusTraversable(false);
        (this.label = this.createTableColumnHeader(this.getTableColumn())).setTableHeaderRow(this.getTableHeaderRow());
        this.label.setParentHeader(this.getParentHeader());
        this.label.setNestedColumnHeader(this);
        if (this.getTableColumn() != null) {
            this.changeListenerHandler.registerChangeListener(this.getTableColumn().textProperty(), p0 -> this.label.setVisible(this.getTableColumn().getText() != null && !this.getTableColumn().getText().isEmpty()));
        }
    }
    
    @Override
    void dispose() {
        super.dispose();
        if (this.label != null) {
            this.label.dispose();
        }
        if (this.getColumns() != null) {
            this.getColumns().removeListener(this.weakColumnsListener);
        }
        for (int i = 0; i < this.getColumnHeaders().size(); ++i) {
            ((TableColumnHeader)this.getColumnHeaders().get(i)).dispose();
        }
        for (final Rectangle rectangle : this.dragRects.values()) {
            if (rectangle != null) {
                rectangle.visibleProperty().unbind();
            }
        }
        this.dragRects.clear();
        this.getChildren().clear();
        this.changeListenerHandler.dispose();
    }
    
    public final ObservableList<TableColumnHeader> getColumnHeaders() {
        if (this.columnHeaders == null) {
            this.columnHeaders = FXCollections.observableArrayList();
            this.unmodifiableColumnHeaders = FXCollections.unmodifiableObservableList(this.columnHeaders);
        }
        return this.unmodifiableColumnHeaders;
    }
    
    @Override
    protected void layoutChildren() {
        final double n = this.getWidth() - this.snappedLeftInset() - this.snappedRightInset();
        final double n2 = this.getHeight() - this.snappedTopInset() - this.snappedBottomInset();
        int n3 = 0;
        if (this.label.isVisible() && this.getTableColumn() != null) {
            n3 = (int)this.label.prefHeight(-1.0);
            this.label.resize(n, n3);
            this.label.relocate(this.snappedLeftInset(), this.snappedTopInset());
        }
        double snappedLeftInset = this.snappedLeftInset();
        final double snapSizeY = this.snapSizeY(n2 - n3);
        for (int i = 0; i < this.getColumnHeaders().size(); ++i) {
            final TableColumnHeader tableColumnHeader = this.getColumnHeaders().get(i);
            if (tableColumnHeader.isVisible()) {
                final double prefWidth = tableColumnHeader.prefWidth(snapSizeY);
                tableColumnHeader.resize(prefWidth, snapSizeY);
                tableColumnHeader.relocate(snappedLeftInset, n3 + this.snappedTopInset());
                snappedLeftInset += prefWidth;
                final Rectangle rectangle = this.dragRects.get(tableColumnHeader.getTableColumn());
                if (rectangle != null) {
                    rectangle.setHeight(tableColumnHeader.getDragRectHeight());
                    rectangle.relocate(snappedLeftInset - 2.0, this.snappedTopInset() + n3);
                }
            }
        }
    }
    
    @Override
    protected double computePrefWidth(final double n) {
        this.checkState();
        double n2 = 0.0;
        if (this.getColumns() != null) {
            for (final TableColumnHeader tableColumnHeader : this.getColumnHeaders()) {
                if (tableColumnHeader.isVisible()) {
                    n2 += tableColumnHeader.computePrefWidth(n);
                }
            }
        }
        return n2;
    }
    
    @Override
    protected double computePrefHeight(final double n) {
        this.checkState();
        double max = 0.0;
        if (this.getColumnHeaders() != null) {
            final Iterator<TableColumnHeader> iterator = this.getColumnHeaders().iterator();
            while (iterator.hasNext()) {
                max = Math.max(max, iterator.next().prefHeight(-1.0));
            }
        }
        double prefHeight = 0.0;
        if (this.label.isVisible() && this.getTableColumn() != null) {
            prefHeight = this.label.prefHeight(-1.0);
        }
        return max + prefHeight + this.snappedTopInset() + this.snappedBottomInset();
    }
    
    protected TableColumnHeader createTableColumnHeader(final TableColumnBase tableColumnBase) {
        return (tableColumnBase == null || tableColumnBase.getColumns().isEmpty() || tableColumnBase == this.getTableColumn()) ? new TableColumnHeader(tableColumnBase) : new NestedTableColumnHeader(tableColumnBase);
    }
    
    @Override
    void initStyleClasses() {
        this.getStyleClass().setAll("nested-column-header");
        this.installTableColumnStyleClassListener();
    }
    
    @Override
    void setTableHeaderRow(final TableHeaderRow tableHeaderRow) {
        super.setTableHeaderRow(tableHeaderRow);
        if (this.getTableSkin() != null) {
            this.changeListenerHandler.registerChangeListener(TableSkinUtils.columnResizePolicyProperty(this.getTableSkin()), p0 -> this.updateContent());
        }
        this.label.setTableHeaderRow(tableHeaderRow);
        final Iterator<TableColumnHeader> iterator = this.getColumnHeaders().iterator();
        while (iterator.hasNext()) {
            iterator.next().setTableHeaderRow(tableHeaderRow);
        }
    }
    
    @Override
    void setParentHeader(final NestedTableColumnHeader nestedTableColumnHeader) {
        super.setParentHeader(nestedTableColumnHeader);
        this.label.setParentHeader(nestedTableColumnHeader);
    }
    
    ObservableList<? extends TableColumnBase> getColumns() {
        return this.columns;
    }
    
    void setColumns(final ObservableList<? extends TableColumnBase> columns) {
        if (this.columns != null) {
            this.columns.removeListener(this.weakColumnsListener);
        }
        this.columns = columns;
        if (this.columns != null) {
            this.columns.addListener(this.weakColumnsListener);
        }
    }
    
    void updateTableColumnHeaders() {
        if (this.getTableColumn() == null && this.getTableSkin() != null) {
            this.setColumns(TableSkinUtils.getColumns(this.getTableSkin()));
        }
        else if (this.getTableColumn() != null) {
            this.setColumns(this.getTableColumn().getColumns());
        }
        if (this.getColumns().isEmpty()) {
            for (int i = 0; i < this.getColumnHeaders().size(); ++i) {
                ((TableColumnHeader)this.getColumnHeaders().get(i)).dispose();
            }
            final NestedTableColumnHeader parentHeader = this.getParentHeader();
            if (parentHeader != null) {
                final ObservableList<TableColumnHeader> columnHeaders = parentHeader.getColumnHeaders();
                final int index = columnHeaders.indexOf(this);
                if (index >= 0 && index < columnHeaders.size()) {
                    columnHeaders.set(index, this.createColumnHeader(this.getTableColumn()));
                }
            }
            else {
                this.columnHeaders.clear();
            }
        }
        else {
            final ArrayList<TableColumnHeader> list = new ArrayList<TableColumnHeader>(this.getColumnHeaders());
            final ArrayList<Object> all = new ArrayList<Object>();
            for (int j = 0; j < this.getColumns().size(); ++j) {
                final TableColumnBase<?, ?> tableColumnBase = this.getColumns().get(j);
                if (tableColumnBase != null) {
                    if (tableColumnBase.isVisible()) {
                        boolean b = false;
                        for (int k = 0; k < list.size(); ++k) {
                            final TableColumnHeader tableColumnHeader = list.get(k);
                            if (tableColumnHeader.represents(tableColumnBase)) {
                                all.add(tableColumnHeader);
                                b = true;
                                break;
                            }
                        }
                        if (!b) {
                            all.add(this.createColumnHeader(tableColumnBase));
                        }
                    }
                }
            }
            this.columnHeaders.setAll((Collection<? extends TableColumnHeader>)all);
            list.removeAll(all);
            for (int l = 0; l < list.size(); ++l) {
                ((TableColumnHeader)list.get(l)).dispose();
            }
        }
        this.updateContent();
        final Iterator<TableColumnHeader> iterator = (Iterator<TableColumnHeader>)this.getColumnHeaders().iterator();
        while (iterator.hasNext()) {
            iterator.next().applyCss();
        }
    }
    
    @Override
    boolean represents(final TableColumnBase<?, ?> tableColumnBase) {
        if (tableColumnBase.getColumns().isEmpty()) {
            return false;
        }
        if (tableColumnBase != this.getTableColumn()) {
            return false;
        }
        final int size = tableColumnBase.getColumns().size();
        if (size != this.getColumnHeaders().size()) {
            return false;
        }
        for (int i = 0; i < size; ++i) {
            if (!((TableColumnHeader)this.getColumnHeaders().get(i)).represents((TableColumnBase<?, ?>)tableColumnBase.getColumns().get(i))) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    double getDragRectHeight() {
        return this.label.prefHeight(-1.0);
    }
    
    void setHeadersNeedUpdate() {
        this.updateColumns = true;
        for (int i = 0; i < this.getColumnHeaders().size(); ++i) {
            final TableColumnHeader tableColumnHeader = this.getColumnHeaders().get(i);
            if (tableColumnHeader instanceof NestedTableColumnHeader) {
                ((NestedTableColumnHeader)tableColumnHeader).setHeadersNeedUpdate();
            }
        }
        this.requestLayout();
    }
    
    private void updateContent() {
        final ArrayList<TableColumnHeader> all = new ArrayList<TableColumnHeader>();
        all.add(this.label);
        all.addAll((Collection<?>)this.getColumnHeaders());
        if (this.isColumnResizingEnabled()) {
            this.rebuildDragRects();
            all.addAll((Collection<?>)this.dragRects.values());
        }
        this.getChildren().setAll(all);
    }
    
    private void rebuildDragRects() {
        if (!this.isColumnResizingEnabled()) {
            return;
        }
        this.getChildren().removeAll(this.dragRects.values());
        final Iterator<Rectangle> iterator = this.dragRects.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().visibleProperty().unbind();
        }
        this.dragRects.clear();
        final ObservableList<? extends TableColumnBase> columns = this.getColumns();
        if (columns == null) {
            return;
        }
        boolean b = false;
        final TableViewSkinBase<?, ?, ?, ?, ?> tableSkin = this.getTableSkin();
        final Callback callback = TableSkinUtils.columnResizePolicyProperty(tableSkin).get();
        if (callback != null) {
            b = ((tableSkin instanceof TableViewSkin) ? TableView.CONSTRAINED_RESIZE_POLICY.equals(callback) : (tableSkin instanceof TreeTableViewSkin && TreeTableView.CONSTRAINED_RESIZE_POLICY.equals(callback)));
        }
        if (b && TableSkinUtils.getVisibleLeafColumns(tableSkin).size() == 1) {
            return;
        }
        for (int n = 0; n < columns.size() && (!b || n != this.getColumns().size() - 1); ++n) {
            final TableColumnBase<?, ?> tableColumnBase = columns.get(n);
            final Rectangle rectangle = new Rectangle();
            rectangle.getProperties().put("TableColumn", tableColumnBase);
            rectangle.getProperties().put("TableColumnHeader", this);
            rectangle.setWidth(4.0);
            rectangle.setHeight(this.getHeight() - this.label.getHeight());
            rectangle.setFill(Color.TRANSPARENT);
            rectangle.visibleProperty().bind(tableColumnBase.visibleProperty().and(tableColumnBase.resizableProperty()));
            rectangle.setOnMousePressed(NestedTableColumnHeader.rectMousePressed);
            rectangle.setOnMouseDragged(NestedTableColumnHeader.rectMouseDragged);
            rectangle.setOnMouseReleased(NestedTableColumnHeader.rectMouseReleased);
            rectangle.setOnMouseEntered(NestedTableColumnHeader.rectCursorChangeListener);
            rectangle.setOnMouseExited(NestedTableColumnHeader.rectCursorChangeListener);
            this.dragRects.put(tableColumnBase, rectangle);
        }
    }
    
    private void checkState() {
        if (this.updateColumns) {
            this.updateTableColumnHeaders();
            this.updateColumns = false;
        }
    }
    
    private TableColumnHeader createColumnHeader(final TableColumnBase tableColumnBase) {
        final TableColumnHeader tableColumnHeader = this.createTableColumnHeader(tableColumnBase);
        tableColumnHeader.setTableHeaderRow(this.getTableHeaderRow());
        tableColumnHeader.setParentHeader(this);
        return tableColumnHeader;
    }
    
    private boolean isColumnResizingEnabled() {
        return true;
    }
    
    private void columnResizingStarted(final double layoutX) {
        this.setCursor(Cursor.H_RESIZE);
        this.columnReorderLine.setLayoutX(layoutX);
    }
    
    private void columnResizing(final TableColumnBase tableColumnBase, final MouseEvent mouseEvent) {
        double lastX = mouseEvent.getSceneX() - this.dragAnchorX;
        if (this.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) {
            lastX = -lastX;
        }
        if (TableSkinUtils.resizeColumn(this.getTableSkin(), tableColumnBase, lastX - this.lastX)) {
            this.lastX = lastX;
        }
    }
    
    private void columnResizingComplete(final TableColumnBase tableColumnBase, final MouseEvent mouseEvent) {
        this.setCursor(null);
        this.columnReorderLine.setTranslateX(0.0);
        this.columnReorderLine.setLayoutX(0.0);
        this.lastX = 0.0;
    }
    
    static {
        final Rectangle rectangle;
        final TableColumnBase<?, ?> tableColumnBase;
        final NestedTableColumnHeader nestedTableColumnHeader;
        Rectangle rectangle2;
        double n;
        rectMousePressed = (mouseEvent -> {
            rectangle = (Rectangle)mouseEvent.getSource();
            tableColumnBase = rectangle.getProperties().get("TableColumn");
            nestedTableColumnHeader = rectangle.getProperties().get("TableColumnHeader");
            if (!nestedTableColumnHeader.isColumnResizingEnabled()) {
                return;
            }
            else if (nestedTableColumnHeader.getTableHeaderRow().columnDragLock) {
                return;
            }
            else if (mouseEvent.isConsumed()) {
                return;
            }
            else {
                mouseEvent.consume();
                if (mouseEvent.getClickCount() == 2 && mouseEvent.isPrimaryButtonDown()) {
                    TableSkinUtils.resizeColumnToFitContent(nestedTableColumnHeader.getTableSkin(), tableColumnBase, -1);
                }
                else {
                    rectangle2 = (Rectangle)mouseEvent.getSource();
                    n = nestedTableColumnHeader.getTableHeaderRow().sceneToLocal(rectangle2.localToScene(rectangle2.getBoundsInLocal())).getMinX() + 2.0;
                    nestedTableColumnHeader.dragAnchorX = mouseEvent.getSceneX();
                    nestedTableColumnHeader.columnResizingStarted(n);
                }
                return;
            }
        });
        final Rectangle rectangle3;
        final TableColumnBase tableColumnBase2;
        final NestedTableColumnHeader nestedTableColumnHeader2;
        rectMouseDragged = (mouseEvent2 -> {
            rectangle3 = (Rectangle)mouseEvent2.getSource();
            tableColumnBase2 = rectangle3.getProperties().get("TableColumn");
            nestedTableColumnHeader2 = rectangle3.getProperties().get("TableColumnHeader");
            if (!nestedTableColumnHeader2.isColumnResizingEnabled()) {
                return;
            }
            else if (nestedTableColumnHeader2.getTableHeaderRow().columnDragLock) {
                return;
            }
            else if (mouseEvent2.isConsumed()) {
                return;
            }
            else {
                mouseEvent2.consume();
                nestedTableColumnHeader2.columnResizing(tableColumnBase2, mouseEvent2);
                return;
            }
        });
        final Rectangle rectangle4;
        final TableColumnBase tableColumnBase3;
        final NestedTableColumnHeader nestedTableColumnHeader3;
        rectMouseReleased = (mouseEvent3 -> {
            rectangle4 = (Rectangle)mouseEvent3.getSource();
            tableColumnBase3 = rectangle4.getProperties().get("TableColumn");
            nestedTableColumnHeader3 = rectangle4.getProperties().get("TableColumnHeader");
            if (!nestedTableColumnHeader3.isColumnResizingEnabled()) {
                return;
            }
            else if (nestedTableColumnHeader3.getTableHeaderRow().columnDragLock) {
                return;
            }
            else if (mouseEvent3.isConsumed()) {
                return;
            }
            else {
                mouseEvent3.consume();
                nestedTableColumnHeader3.columnResizingComplete(tableColumnBase3, mouseEvent3);
                return;
            }
        });
        final Rectangle rectangle5;
        final TableColumnBase tableColumnBase4;
        final NestedTableColumnHeader nestedTableColumnHeader4;
        rectCursorChangeListener = (mouseEvent4 -> {
            rectangle5 = (Rectangle)mouseEvent4.getSource();
            tableColumnBase4 = rectangle5.getProperties().get("TableColumn");
            nestedTableColumnHeader4 = rectangle5.getProperties().get("TableColumnHeader");
            if (!nestedTableColumnHeader4.getTableHeaderRow().columnDragLock) {
                if (nestedTableColumnHeader4.getCursor() == null) {
                    rectangle5.setCursor((nestedTableColumnHeader4.isColumnResizingEnabled() && rectangle5.isHover() && tableColumnBase4.isResizable()) ? Cursor.H_RESIZE : null);
                }
            }
        });
    }
}
