// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.scene.control.Labeled;
import javafx.scene.Scene;
import javafx.scene.control.Skin;
import com.sun.javafx.scene.control.ContextMenuContent;
import com.sun.javafx.scene.control.behavior.MenuButtonBehaviorBase;
import javafx.application.Platform;
import com.sun.javafx.scene.control.skin.Utils;
import com.sun.javafx.scene.NodeHelper;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.control.ControlAcceleratorSupport;
import java.util.Collection;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.MenuItem;
import javafx.collections.ListChangeListener;
import javafx.scene.control.ContextMenu;
import javafx.scene.layout.StackPane;
import com.sun.javafx.scene.control.LabeledImpl;
import javafx.scene.control.SkinBase;
import javafx.scene.control.MenuButton;

public class MenuButtonSkinBase<C extends MenuButton> extends SkinBase<C>
{
    final LabeledImpl label;
    final StackPane arrow;
    final StackPane arrowButton;
    ContextMenu popup;
    boolean behaveLikeButton;
    private ListChangeListener<MenuItem> itemsChangedListener;
    boolean requestFocusOnFirstMenuItem;
    
    public MenuButtonSkinBase(final C labelFor) {
        super(labelFor);
        this.behaveLikeButton = false;
        this.requestFocusOnFirstMenuItem = false;
        if (labelFor.getOnMousePressed() == null) {
            final MenuButtonBehaviorBase menuButtonBehaviorBase;
            labelFor.addEventHandler(MouseEvent.MOUSE_PRESSED, mouseEvent -> {
                this.getBehavior();
                if (menuButtonBehaviorBase != null) {
                    menuButtonBehaviorBase.mousePressed(mouseEvent, this.behaveLikeButton);
                }
                return;
            });
        }
        if (labelFor.getOnMouseReleased() == null) {
            final MenuButtonBehaviorBase menuButtonBehaviorBase2;
            labelFor.addEventHandler(MouseEvent.MOUSE_RELEASED, mouseEvent2 -> {
                this.getBehavior();
                if (menuButtonBehaviorBase2 != null) {
                    menuButtonBehaviorBase2.mouseReleased(mouseEvent2, this.behaveLikeButton);
                }
                return;
            });
        }
        (this.label = new MenuLabeledImpl(this.getSkinnable())).setMnemonicParsing(labelFor.isMnemonicParsing());
        this.label.setLabelFor(labelFor);
        this.arrow = new StackPane();
        this.arrow.getStyleClass().setAll("arrow");
        this.arrow.setMaxWidth(Double.NEGATIVE_INFINITY);
        this.arrow.setMaxHeight(Double.NEGATIVE_INFINITY);
        this.arrowButton = new StackPane();
        this.arrowButton.getStyleClass().setAll("arrow-button");
        this.arrowButton.getChildren().add(this.arrow);
        this.popup = new ContextMenu();
        this.popup.getItems().clear();
        this.popup.getItems().addAll((Collection<?>)this.getSkinnable().getItems());
        this.getChildren().clear();
        this.getChildren().addAll(this.label, this.arrowButton);
        this.getSkinnable().requestLayout();
        this.itemsChangedListener = (change -> {
            while (change.next()) {
                this.popup.getItems().removeAll(change.getRemoved());
                this.popup.getItems().addAll(change.getFrom(), (Collection<?>)change.getAddedSubList());
            }
            return;
        });
        labelFor.getItems().addListener(this.itemsChangedListener);
        if (this.getSkinnable().getScene() != null) {
            ControlAcceleratorSupport.addAcceleratorsIntoScene(this.getSkinnable().getItems(), this.getSkinnable());
        }
        labelFor.sceneProperty().addListener((p0, p1, p2) -> {
            if (this.getSkinnable() != null && this.getSkinnable().getScene() != null) {
                ControlAcceleratorSupport.addAcceleratorsIntoScene(this.getSkinnable().getItems(), this.getSkinnable());
            }
            return;
        });
        this.registerChangeListener(labelFor.showingProperty(), p0 -> {
            if (this.getSkinnable().isShowing()) {
                this.show();
            }
            else {
                this.hide();
            }
            return;
        });
        this.registerChangeListener(labelFor.focusedProperty(), p0 -> {
            if (!this.getSkinnable().isFocused() && this.getSkinnable().isShowing()) {
                this.hide();
            }
            if (!this.getSkinnable().isFocused() && this.popup.isShowing()) {
                this.hide();
            }
            return;
        });
        this.registerChangeListener(labelFor.mnemonicParsingProperty(), p0 -> {
            this.label.setMnemonicParsing(this.getSkinnable().isMnemonicParsing());
            this.getSkinnable().requestLayout();
            return;
        });
        this.registerChangeListener(this.popup.showingProperty(), p0 -> {
            if (!this.popup.isShowing() && this.getSkinnable().isShowing()) {
                this.getSkinnable().hide();
            }
            if (this.popup.isShowing()) {
                Utils.addMnemonics(this.popup, this.getSkinnable().getScene(), NodeHelper.isShowMnemonics(this.getSkinnable()));
            }
            else {
                Platform.runLater(() -> Utils.removeMnemonics(this.popup, this.getSkinnable().getScene()));
            }
        });
    }
    
    @Override
    public void dispose() {
        this.getSkinnable().getItems().removeListener(this.itemsChangedListener);
        super.dispose();
        if (this.popup != null) {
            if (this.popup.getSkin() != null && this.popup.getSkin().getNode() != null) {
                ((ContextMenuContent)this.popup.getSkin().getNode()).dispose();
            }
            this.popup.setSkin(null);
            this.popup = null;
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n5 + this.label.minWidth(n) + this.snapSizeX(this.arrowButton.minWidth(n)) + n3;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n2 + Math.max(this.label.minHeight(n), this.snapSizeY(this.arrowButton.minHeight(-1.0))) + n4;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n5 + this.label.prefWidth(n) + this.snapSizeX(this.arrowButton.prefWidth(n)) + n3;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n2 + Math.max(this.label.prefHeight(n), this.snapSizeY(this.arrowButton.prefHeight(-1.0))) + n4;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefWidth(n);
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefHeight(n);
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        final double snapSizeX = this.snapSizeX(this.arrowButton.prefWidth(-1.0));
        this.label.resizeRelocate(n, n2, n3 - snapSizeX, n4);
        this.arrowButton.resizeRelocate(n + (n3 - snapSizeX), n2, snapSizeX, n4);
    }
    
    MenuButtonBehaviorBase<C> getBehavior() {
        return null;
    }
    
    private void show() {
        if (!this.popup.isShowing()) {
            this.popup.show(this.getSkinnable(), this.getSkinnable().getPopupSide(), 0.0, 0.0);
        }
    }
    
    private void hide() {
        if (this.popup.isShowing()) {
            this.popup.hide();
        }
    }
    
    void requestFocusOnFirstMenuItem() {
        this.requestFocusOnFirstMenuItem = true;
    }
    
    void putFocusOnFirstMenuItem() {
        final Skin<?> skin = this.popup.getSkin();
        if (skin instanceof ContextMenuSkin) {
            final Node node = skin.getNode();
            if (node instanceof ContextMenuContent) {
                ((ContextMenuContent)node).requestFocusOnIndex(0);
            }
        }
    }
    
    private static class MenuLabeledImpl extends LabeledImpl
    {
        MenuButton button;
        
        public MenuLabeledImpl(final MenuButton button) {
            super(button);
            this.button = button;
            this.addEventHandler(ActionEvent.ACTION, actionEvent -> {
                this.button.fireEvent(new ActionEvent());
                actionEvent.consume();
            });
        }
    }
}
