// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import com.sun.javafx.scene.control.behavior.ToggleButtonBehavior;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.ToggleButton;

public class ToggleButtonSkin extends LabeledSkinBase<ToggleButton>
{
    private final BehaviorBase<ToggleButton> behavior;
    
    public ToggleButtonSkin(final ToggleButton toggleButton) {
        super(toggleButton);
        this.behavior = new ToggleButtonBehavior<ToggleButton>(toggleButton);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
}
