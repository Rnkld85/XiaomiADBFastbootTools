// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import com.sun.javafx.scene.control.behavior.ButtonBehavior;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.Hyperlink;

public class HyperlinkSkin extends LabeledSkinBase<Hyperlink>
{
    private final BehaviorBase<Hyperlink> behavior;
    
    public HyperlinkSkin(final Hyperlink hyperlink) {
        super(hyperlink);
        this.behavior = new ButtonBehavior<Hyperlink>(hyperlink);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
}
