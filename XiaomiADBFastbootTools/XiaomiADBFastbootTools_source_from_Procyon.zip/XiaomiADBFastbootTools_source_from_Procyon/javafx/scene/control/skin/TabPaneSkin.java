// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.InvalidationListener;
import javafx.scene.input.ContextMenuEvent;
import com.sun.javafx.util.Utils;
import javafx.scene.layout.Region;
import javafx.event.Event;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleRole;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.DoubleProperty;
import javafx.collections.WeakListChangeListener;
import com.sun.javafx.scene.control.LambdaMultiplePropertyChangeListenerHandler;
import javafx.scene.control.Tooltip;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.ScrollEvent;
import java.util.Collections;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.scene.control.ContextMenu;
import com.sun.javafx.scene.control.TabObservableList;
import javafx.geometry.Bounds;
import javafx.scene.input.MouseButton;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import javafx.scene.input.SwipeEvent;
import com.sun.javafx.scene.control.Properties;
import javafx.animation.KeyFrame;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import java.util.Collection;
import java.util.ArrayList;
import javafx.animation.Timeline;
import java.util.List;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.geometry.Pos;
import javafx.scene.transform.Rotate;
import javafx.geometry.Side;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import java.util.Iterator;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import javafx.util.Duration;
import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.animation.Animation;
import javafx.scene.layout.StackPane;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.css.PseudoClass;
import javafx.beans.property.ObjectProperty;
import com.sun.javafx.scene.control.behavior.TabPaneBehavior;
import javafx.scene.control.Tab;
import javafx.scene.shape.Rectangle;
import javafx.collections.ObservableList;
import javafx.scene.control.TabPane;
import javafx.scene.control.SkinBase;

public class TabPaneSkin extends SkinBase<TabPane>
{
    static int CLOSE_BTN_SIZE;
    private static final double ANIMATION_SPEED = 150.0;
    private static final int SPACER = 10;
    private TabHeaderArea tabHeaderArea;
    private ObservableList<TabContentRegion> tabContentRegions;
    private Rectangle clipRect;
    private Rectangle tabHeaderAreaClipRect;
    private Tab selectedTab;
    private boolean isSelectingTab;
    private final TabPaneBehavior behavior;
    private ObjectProperty<TabAnimation> openTabAnimation;
    private ObjectProperty<TabAnimation> closeTabAnimation;
    private static final PseudoClass SELECTED_PSEUDOCLASS_STATE;
    private static final PseudoClass TOP_PSEUDOCLASS_STATE;
    private static final PseudoClass BOTTOM_PSEUDOCLASS_STATE;
    private static final PseudoClass LEFT_PSEUDOCLASS_STATE;
    private static final PseudoClass RIGHT_PSEUDOCLASS_STATE;
    private static final PseudoClass DISABLED_PSEUDOCLASS_STATE;
    private EventHandler<MouseEvent> headerDraggedHandler;
    private EventHandler<MouseEvent> headerMousePressedHandler;
    private EventHandler<MouseEvent> headerMouseReleasedHandler;
    private int dragTabHeaderIndex;
    private TabHeaderSkin dragTabHeader;
    private TabHeaderSkin dropTabHeader;
    private StackPane headersRegion;
    private DragState dragState;
    private final int MIN_TO_MAX = 1;
    private final int MAX_TO_MIN = -1;
    private int xLayoutDirection;
    private double dragEventPrevLoc;
    private int prevDragDirection;
    private final double DRAG_DIST_THRESHOLD = 0.75;
    private final double ANIM_DURATION = 120.0;
    private TabHeaderSkin dropAnimHeader;
    private Tab swapTab;
    private double dropHeaderSourceX;
    private double dropHeaderTransitionX;
    private final Animation dropHeaderAnim;
    private double dragHeaderStartX;
    private double dragHeaderDestX;
    private double dragHeaderSourceX;
    private double dragHeaderTransitionX;
    private final Animation dragHeaderAnim;
    private ListChangeListener childListener;
    
    public TabPaneSkin(final TabPane tabPane) {
        super(tabPane);
        this.openTabAnimation = new StyleableObjectProperty<TabAnimation>(TabAnimation.GROW) {
            @Override
            public CssMetaData<TabPane, TabAnimation> getCssMetaData() {
                return StyleableProperties.OPEN_TAB_ANIMATION;
            }
            
            @Override
            public Object getBean() {
                return TabPaneSkin.this;
            }
            
            @Override
            public String getName() {
                return "openTabAnimation";
            }
        };
        this.closeTabAnimation = new StyleableObjectProperty<TabAnimation>(TabAnimation.GROW) {
            @Override
            public CssMetaData<TabPane, TabAnimation> getCssMetaData() {
                return StyleableProperties.CLOSE_TAB_ANIMATION;
            }
            
            @Override
            public Object getBean() {
                return TabPaneSkin.this;
            }
            
            @Override
            public String getName() {
                return "closeTabAnimation";
            }
        };
        this.headerDraggedHandler = this::handleHeaderDragged;
        this.headerMousePressedHandler = this::handleHeaderMousePressed;
        this.headerMouseReleasedHandler = this::handleHeaderMouseReleased;
        this.prevDragDirection = 1;
        this.dropHeaderAnim = new Transition() {
            {
                this.setInterpolator(Interpolator.EASE_BOTH);
                this.setCycleDuration(Duration.millis(120.0));
                this.setOnFinished(p0 -> TabPaneSkin.this.completeHeaderReordering());
            }
            
            @Override
            protected void interpolate(final double n) {
                TabPaneSkin.this.dropAnimHeader.setLayoutX(TabPaneSkin.this.dropHeaderSourceX + TabPaneSkin.this.dropHeaderTransitionX * n);
            }
        };
        this.dragHeaderAnim = new Transition() {
            {
                this.setInterpolator(Interpolator.EASE_OUT);
                this.setCycleDuration(Duration.millis(120.0));
                this.setOnFinished(p0 -> TabPaneSkin.this.resetDrag());
            }
            
            @Override
            protected void interpolate(final double n) {
                TabPaneSkin.this.dragTabHeader.setLayoutX(TabPaneSkin.this.dragHeaderSourceX + TabPaneSkin.this.dragHeaderTransitionX * n);
            }
        };
        this.childListener = new ListChangeListener<Node>() {
            @Override
            public void onChanged(final Change<? extends Node> change) {
                while (change.next()) {
                    if (change.wasAdded()) {
                        final Iterator<? extends Node> iterator = change.getAddedSubList().iterator();
                        while (iterator.hasNext()) {
                            TabPaneSkin.this.addReorderListeners((Node)iterator.next());
                        }
                    }
                    if (change.wasRemoved()) {
                        final Iterator<? extends Node> iterator2 = change.getRemoved().iterator();
                        while (iterator2.hasNext()) {
                            TabPaneSkin.this.removeReorderListeners((Node)iterator2.next());
                        }
                    }
                }
            }
        };
        this.behavior = new TabPaneBehavior(tabPane);
        this.clipRect = new Rectangle(tabPane.getWidth(), tabPane.getHeight());
        this.getSkinnable().setClip(this.clipRect);
        this.tabContentRegions = FXCollections.observableArrayList();
        final Iterator<Tab> iterator = this.getSkinnable().getTabs().iterator();
        while (iterator.hasNext()) {
            this.addTabContent(iterator.next());
        }
        this.tabHeaderAreaClipRect = new Rectangle();
        (this.tabHeaderArea = new TabHeaderArea()).setClip(this.tabHeaderAreaClipRect);
        this.getChildren().add(this.tabHeaderArea);
        if (this.getSkinnable().getTabs().size() == 0) {
            this.tabHeaderArea.setVisible(false);
        }
        this.initializeTabListener();
        this.registerChangeListener(tabPane.getSelectionModel().selectedItemProperty(), p0 -> {
            this.isSelectingTab = true;
            this.selectedTab = this.getSkinnable().getSelectionModel().getSelectedItem();
            this.getSkinnable().requestLayout();
            return;
        });
        this.registerChangeListener(tabPane.sideProperty(), p0 -> this.updateTabPosition());
        this.registerChangeListener(tabPane.widthProperty(), p0 -> this.clipRect.setWidth(this.getSkinnable().getWidth()));
        this.registerChangeListener(tabPane.heightProperty(), p0 -> this.clipRect.setHeight(this.getSkinnable().getHeight()));
        this.selectedTab = this.getSkinnable().getSelectionModel().getSelectedItem();
        if (this.selectedTab == null && this.getSkinnable().getSelectionModel().getSelectedIndex() != -1) {
            this.getSkinnable().getSelectionModel().select(this.getSkinnable().getSelectionModel().getSelectedIndex());
            this.selectedTab = this.getSkinnable().getSelectionModel().getSelectedItem();
        }
        if (this.selectedTab == null) {
            this.getSkinnable().getSelectionModel().selectFirst();
        }
        this.selectedTab = this.getSkinnable().getSelectionModel().getSelectedItem();
        this.isSelectingTab = false;
        this.initializeSwipeHandlers();
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        double max = 0.0;
        final Iterator<TabContentRegion> iterator = this.tabContentRegions.iterator();
        while (iterator.hasNext()) {
            max = Math.max(max, this.snapSizeX(iterator.next().prefWidth(-1.0)));
        }
        final boolean horizontal = this.isHorizontal();
        final double b = horizontal ? this.snapSizeX(this.tabHeaderArea.prefWidth(-1.0)) : this.snapSizeY(this.tabHeaderArea.prefHeight(-1.0));
        return this.snapSizeX(horizontal ? Math.max(max, b) : (max + b)) + n3 + n5;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double max = 0.0;
        final Iterator<TabContentRegion> iterator = this.tabContentRegions.iterator();
        while (iterator.hasNext()) {
            max = Math.max(max, this.snapSizeY(iterator.next().prefHeight(-1.0)));
        }
        final boolean horizontal = this.isHorizontal();
        final double b = horizontal ? this.snapSizeY(this.tabHeaderArea.prefHeight(-1.0)) : this.snapSizeX(this.tabHeaderArea.prefWidth(-1.0));
        return this.snapSizeY(horizontal ? (max + this.snapSizeY(b)) : Math.max(max, b)) + n2 + n4;
    }
    
    public double computeBaselineOffset(final double n, final double n2, final double n3, final double n4) {
        if (this.getSkinnable().getSide() == Side.TOP) {
            return this.tabHeaderArea.getBaselineOffset() + n;
        }
        return 0.0;
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double width, final double width2) {
        final Side side = this.getSkinnable().getSide();
        final double height = side.isHorizontal() ? this.snapSizeY(this.tabHeaderArea.prefHeight(-1.0)) : this.snapSizeX(this.tabHeaderArea.prefHeight(-1.0));
        final double n3 = side.equals(Side.RIGHT) ? (n + width - height) : n;
        final double n4 = side.equals(Side.BOTTOM) ? (n2 + width2 - height) : n2;
        final double snappedLeftInset = this.snappedLeftInset();
        final double snappedTopInset = this.snappedTopInset();
        if (side == Side.TOP) {
            this.tabHeaderArea.resize(width, height);
            this.tabHeaderArea.relocate(n3, n4);
            this.tabHeaderArea.getTransforms().clear();
            this.tabHeaderArea.getTransforms().add(new Rotate(getRotation(Side.TOP)));
        }
        else if (side == Side.BOTTOM) {
            this.tabHeaderArea.resize(width, height);
            this.tabHeaderArea.relocate(width + snappedLeftInset, n4 - height);
            this.tabHeaderArea.getTransforms().clear();
            this.tabHeaderArea.getTransforms().add(new Rotate(getRotation(Side.BOTTOM), 0.0, height));
        }
        else if (side == Side.LEFT) {
            this.tabHeaderArea.resize(width2, height);
            this.tabHeaderArea.relocate(n3 + height, width2 - height + snappedTopInset);
            this.tabHeaderArea.getTransforms().clear();
            this.tabHeaderArea.getTransforms().add(new Rotate(getRotation(Side.LEFT), 0.0, height));
        }
        else if (side == Side.RIGHT) {
            this.tabHeaderArea.resize(width2, height);
            this.tabHeaderArea.relocate(n3, n2 - height);
            this.tabHeaderArea.getTransforms().clear();
            this.tabHeaderArea.getTransforms().add(new Rotate(getRotation(Side.RIGHT), 0.0, height));
        }
        this.tabHeaderAreaClipRect.setX(0.0);
        this.tabHeaderAreaClipRect.setY(0.0);
        if (this.isHorizontal()) {
            this.tabHeaderAreaClipRect.setWidth(width);
        }
        else {
            this.tabHeaderAreaClipRect.setWidth(width2);
        }
        this.tabHeaderAreaClipRect.setHeight(height);
        double n5 = 0.0;
        double n6 = 0.0;
        if (side == Side.TOP) {
            n5 = n;
            n6 = n2 + height;
            if (this.isFloatingStyleClass()) {
                --n6;
            }
        }
        else if (side == Side.BOTTOM) {
            n5 = n;
            n6 = n2 + snappedTopInset;
            if (this.isFloatingStyleClass()) {
                n6 = 1.0 + snappedTopInset;
            }
        }
        else if (side == Side.LEFT) {
            n5 = n + height;
            n6 = n2;
            if (this.isFloatingStyleClass()) {
                --n5;
            }
        }
        else if (side == Side.RIGHT) {
            n5 = n + snappedLeftInset;
            n6 = n2;
            if (this.isFloatingStyleClass()) {
                n5 = 1.0 + snappedLeftInset;
            }
        }
        final double width3 = width - (this.isHorizontal() ? 0.0 : height);
        final double height2 = width2 - (this.isHorizontal() ? height : 0.0);
        for (int i = 0; i < this.tabContentRegions.size(); ++i) {
            final TabContentRegion tabContentRegion = this.tabContentRegions.get(i);
            tabContentRegion.setAlignment(Pos.TOP_LEFT);
            if (tabContentRegion.getClip() != null) {
                ((Rectangle)tabContentRegion.getClip()).setWidth(width3);
                ((Rectangle)tabContentRegion.getClip()).setHeight(height2);
            }
            tabContentRegion.resize(width3, height2);
            tabContentRegion.relocate(n5, n6);
        }
    }
    
    private static int getRotation(final Side side) {
        switch (side) {
            case TOP: {
                return 0;
            }
            case BOTTOM: {
                return 180;
            }
            case LEFT: {
                return -90;
            }
            case RIGHT: {
                return 90;
            }
            default: {
                return 0;
            }
        }
    }
    
    private static Node clone(final Node node) {
        if (node == null) {
            return null;
        }
        if (node instanceof ImageView) {
            final ImageView imageView = (ImageView)node;
            final ImageView imageView2 = new ImageView();
            imageView2.imageProperty().bind((ObservableValue<?>)imageView.imageProperty());
            return imageView2;
        }
        if (node instanceof Label) {
            final Label label = (Label)node;
            final Label label2 = new Label(label.getText(), clone(label.getGraphic()));
            label2.textProperty().bind(label.textProperty());
            return label2;
        }
        return null;
    }
    
    private void removeTabs(final List<? extends Tab> list) {
        for (final Tab tab : list) {
            this.stopCurrentAnimation(tab);
            final TabHeaderSkin access$200 = this.tabHeaderArea.getTabHeaderSkin(tab);
            if (access$200 != null) {
                access$200.isClosing = true;
                access$200.removeListeners(tab);
                this.removeTabContent(tab);
                final TabHeaderSkin tabHeaderSkin;
                final Tab tab2;
                final EventHandler<ActionEvent> eventHandler = p2 -> {
                    tabHeaderSkin.animationState = TabAnimationState.NONE;
                    this.tabHeaderArea.removeTab(tab2);
                    this.tabHeaderArea.requestLayout();
                    if (this.getSkinnable().getTabs().isEmpty()) {
                        this.tabHeaderArea.setVisible((boolean)(0 != 0));
                    }
                    return;
                };
                if (this.closeTabAnimation.get() == TabAnimation.GROW) {
                    access$200.animationState = TabAnimationState.HIDING;
                    (access$200.currentAnimation = this.createTimeline(access$200, Duration.millis(150.0), 0.0, eventHandler)).play();
                }
                else {
                    eventHandler.handle(null);
                }
            }
        }
    }
    
    private void stopCurrentAnimation(final Tab tab) {
        final TabHeaderSkin access$200 = this.tabHeaderArea.getTabHeaderSkin(tab);
        if (access$200 != null) {
            final Timeline access$201 = access$200.currentAnimation;
            if (access$201 != null && access$201.getStatus() == Animation.Status.RUNNING) {
                access$201.getOnFinished().handle(null);
                access$201.stop();
                access$200.currentAnimation = null;
            }
        }
    }
    
    private void addTabs(final List<? extends Tab> list, final int n) {
        int n2 = 0;
        for (final TabHeaderSkin tabHeaderSkin : new ArrayList<Object>(this.tabHeaderArea.headersRegion.getChildren())) {
            if (tabHeaderSkin.animationState == TabAnimationState.HIDING) {
                this.stopCurrentAnimation(tabHeaderSkin.tab);
            }
        }
        for (final Tab tab : list) {
            this.stopCurrentAnimation(tab);
            if (!this.tabHeaderArea.isVisible()) {
                this.tabHeaderArea.setVisible(true);
            }
            this.tabHeaderArea.addTab(tab, n + n2++);
            this.addTabContent(tab);
            final TabHeaderSkin access$200 = this.tabHeaderArea.getTabHeaderSkin(tab);
            if (access$200 != null) {
                if (this.openTabAnimation.get() == TabAnimation.GROW) {
                    access$200.animationState = TabAnimationState.SHOWING;
                    access$200.animationTransition.setValue(0.0);
                    access$200.setVisible(true);
                    final TabHeaderSkin tabHeaderSkin2;
                    access$200.currentAnimation = this.createTimeline(access$200, Duration.millis(150.0), 1.0, p1 -> {
                        tabHeaderSkin2.animationState = TabAnimationState.NONE;
                        tabHeaderSkin2.setVisible(true);
                        tabHeaderSkin2.inner.requestLayout();
                        return;
                    });
                    access$200.currentAnimation.play();
                }
                else {
                    access$200.setVisible(true);
                    access$200.inner.requestLayout();
                }
            }
        }
    }
    
    private void initializeTabListener() {
        final ArrayList list;
        final ArrayList<Tab> list2;
        TabPane tabPane;
        int initialCapacity;
        Tab tab;
        ArrayList list3;
        TabAnimation tabAnimation;
        TabAnimation tabAnimation2;
        int i = 0;
        final List<? extends Tab> list4;
        int from = 0;
        final Iterator<TabContentRegion> iterator;
        TabContentRegion tabContentRegion;
        this.getSkinnable().getTabs().addListener(change -> {
            list = new ArrayList<Tab>();
            list2 = new ArrayList<Tab>();
            while (change.next()) {
                if (change.wasPermutated() && this.dragState != DragState.REORDER) {
                    tabPane = this.getSkinnable();
                    tabPane.getTabs();
                    initialCapacity = change.getTo() - change.getFrom();
                    tab = tabPane.getSelectionModel().getSelectedItem();
                    list3 = new ArrayList<Tab>(initialCapacity);
                    this.getSkinnable().getSelectionModel().clearSelection();
                    tabAnimation = this.openTabAnimation.get();
                    tabAnimation2 = this.closeTabAnimation.get();
                    this.openTabAnimation.set(TabAnimation.NONE);
                    this.closeTabAnimation.set(TabAnimation.NONE);
                    change.getFrom();
                    while (i < change.getTo()) {
                        list3.add((Tab)list4.get(i));
                        ++i;
                    }
                    this.removeTabs((List<? extends Tab>)list3);
                    this.addTabs((List<? extends Tab>)list3, change.getFrom());
                    this.openTabAnimation.set(tabAnimation);
                    this.closeTabAnimation.set(tabAnimation2);
                    this.getSkinnable().getSelectionModel().select(tab);
                }
                if (change.wasRemoved()) {
                    list.addAll(change.getRemoved());
                }
                if (change.wasAdded()) {
                    list2.addAll((Collection<?>)change.getAddedSubList());
                    from = change.getFrom();
                }
            }
            list.removeAll(list2);
            this.removeTabs(list);
            if (!list2.isEmpty()) {
                this.tabContentRegions.iterator();
                while (iterator.hasNext()) {
                    tabContentRegion = iterator.next();
                    if (!this.tabHeaderArea.getTabHeaderSkin(tabContentRegion.getTab()).isClosing && list2.contains(tabContentRegion.getTab())) {
                        list2.remove(tabContentRegion.getTab());
                    }
                }
                this.addTabs(list2, (from == -1) ? this.tabContentRegions.size() : from);
            }
            this.getSkinnable().requestLayout();
        });
    }
    
    private void addTabContent(final Tab tab) {
        final TabContentRegion tabContentRegion = new TabContentRegion(tab);
        tabContentRegion.setClip(new Rectangle());
        this.tabContentRegions.add(tabContentRegion);
        this.getChildren().add(0, tabContentRegion);
    }
    
    private void removeTabContent(final Tab obj) {
        for (final TabContentRegion tabContentRegion : this.tabContentRegions) {
            if (tabContentRegion.getTab().equals(obj)) {
                tabContentRegion.removeListeners(obj);
                this.getChildren().remove(tabContentRegion);
                this.tabContentRegions.remove(tabContentRegion);
                break;
            }
        }
    }
    
    private void updateTabPosition() {
        this.tabHeaderArea.setScrollOffset(0.0);
        this.getSkinnable().applyCss();
        this.getSkinnable().requestLayout();
    }
    
    private Timeline createTimeline(final TabHeaderSkin tabHeaderSkin, final Duration duration, final double d, final EventHandler<ActionEvent> onFinished) {
        final Timeline timeline = new Timeline();
        timeline.setCycleCount(1);
        final KeyValue keyValue = new KeyValue((WritableValue<T>)tabHeaderSkin.animationTransition, (T)d, Interpolator.LINEAR);
        timeline.getKeyFrames().clear();
        timeline.getKeyFrames().add(new KeyFrame(duration, new KeyValue[] { keyValue }));
        timeline.setOnFinished(onFinished);
        return timeline;
    }
    
    private boolean isHorizontal() {
        final Side side = this.getSkinnable().getSide();
        return Side.TOP.equals(side) || Side.BOTTOM.equals(side);
    }
    
    private void initializeSwipeHandlers() {
        if (Properties.IS_TOUCH_SUPPORTED) {
            this.getSkinnable().addEventHandler(SwipeEvent.SWIPE_LEFT, p0 -> this.behavior.selectNextTab());
            this.getSkinnable().addEventHandler(SwipeEvent.SWIPE_RIGHT, p0 -> this.behavior.selectPreviousTab());
        }
    }
    
    private boolean isFloatingStyleClass() {
        return this.getSkinnable().getStyleClass().contains("floating");
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case FOCUS_ITEM: {
                return this.tabHeaderArea.getTabHeaderSkin(this.selectedTab);
            }
            case ITEM_COUNT: {
                return this.tabHeaderArea.headersRegion.getChildren().size();
            }
            case ITEM_AT_INDEX: {
                final Integer n = (Integer)array[0];
                if (n == null) {
                    return null;
                }
                return this.tabHeaderArea.headersRegion.getChildren().get(n);
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    private void addReorderListeners(final Node node) {
        node.addEventHandler(MouseEvent.MOUSE_PRESSED, this.headerMousePressedHandler);
        node.addEventHandler(MouseEvent.MOUSE_RELEASED, this.headerMouseReleasedHandler);
        node.addEventHandler(MouseEvent.MOUSE_DRAGGED, this.headerDraggedHandler);
    }
    
    private void removeReorderListeners(final Node node) {
        node.removeEventHandler(MouseEvent.MOUSE_PRESSED, this.headerMousePressedHandler);
        node.removeEventHandler(MouseEvent.MOUSE_RELEASED, this.headerMouseReleasedHandler);
        node.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this.headerDraggedHandler);
    }
    
    private void updateListeners() {
        if (this.getSkinnable().getTabDragPolicy() == TabPane.TabDragPolicy.FIXED || this.getSkinnable().getTabDragPolicy() == null) {
            final Iterator<Node> iterator = this.headersRegion.getChildren().iterator();
            while (iterator.hasNext()) {
                this.removeReorderListeners(iterator.next());
            }
            this.headersRegion.getChildren().removeListener(this.childListener);
        }
        else if (this.getSkinnable().getTabDragPolicy() == TabPane.TabDragPolicy.REORDER) {
            final Iterator<Node> iterator2 = this.headersRegion.getChildren().iterator();
            while (iterator2.hasNext()) {
                this.addReorderListeners(iterator2.next());
            }
            this.headersRegion.getChildren().addListener(this.childListener);
        }
    }
    
    private void setupReordering(final StackPane headersRegion) {
        this.dragState = DragState.NONE;
        this.headersRegion = headersRegion;
        this.updateListeners();
        this.getSkinnable().tabDragPolicyProperty().addListener((p0, tabDragPolicy, tabDragPolicy2) -> {
            if (tabDragPolicy != tabDragPolicy2) {
                this.updateListeners();
            }
        });
    }
    
    private void handleHeaderMousePressed(final MouseEvent mouseEvent) {
        if (mouseEvent.getButton().equals(MouseButton.PRIMARY)) {
            ((StackPane)mouseEvent.getSource()).setMouseTransparent(true);
            this.startDrag(mouseEvent);
        }
    }
    
    private void handleHeaderMouseReleased(final MouseEvent mouseEvent) {
        if (mouseEvent.getButton().equals(MouseButton.PRIMARY)) {
            ((StackPane)mouseEvent.getSource()).setMouseTransparent(false);
            this.stopDrag();
            mouseEvent.consume();
        }
    }
    
    private void handleHeaderDragged(final MouseEvent mouseEvent) {
        if (mouseEvent.getButton().equals(MouseButton.PRIMARY)) {
            this.perfromDrag(mouseEvent);
        }
    }
    
    private double getDragDelta(final double n, final double n2) {
        if (this.getSkinnable().getSide().equals(Side.TOP) || this.getSkinnable().getSide().equals(Side.RIGHT)) {
            return n - n2;
        }
        return n2 - n;
    }
    
    private int deriveTabHeaderLayoutXDirection() {
        if (this.getSkinnable().getSide().equals(Side.TOP) || this.getSkinnable().getSide().equals(Side.RIGHT)) {
            return 1;
        }
        return -1;
    }
    
    private void perfromDrag(final MouseEvent mouseEvent) {
        final double headerRegionLocalX = this.getHeaderRegionLocalX(mouseEvent);
        final double dragDelta = this.getDragDelta(headerRegionLocalX, this.dragEventPrevLoc);
        int prevDragDirection;
        if (dragDelta > 0.0) {
            prevDragDirection = 1;
        }
        else {
            prevDragDirection = -1;
        }
        if (this.prevDragDirection != prevDragDirection) {
            this.stopAnim(this.dropHeaderAnim);
            this.prevDragDirection = prevDragDirection;
        }
        final double layoutX = this.dragTabHeader.getLayoutX() + this.xLayoutDirection * dragDelta;
        if (layoutX >= 0.0 && layoutX + this.dragTabHeader.getWidth() <= this.headersRegion.getWidth()) {
            this.dragState = DragState.REORDER;
            this.dragTabHeader.setLayoutX(layoutX);
            final Bounds boundsInParent = this.dragTabHeader.getBoundsInParent();
            if (prevDragDirection == 1) {
                for (int i = this.dragTabHeaderIndex + 1; i < this.headersRegion.getChildren().size(); ++i) {
                    this.dropTabHeader = (TabHeaderSkin)this.headersRegion.getChildren().get(i);
                    if (this.dropAnimHeader != this.dropTabHeader) {
                        final Bounds boundsInParent2 = this.dropTabHeader.getBoundsInParent();
                        double n;
                        if (this.xLayoutDirection == 1) {
                            n = boundsInParent.getMaxX() - boundsInParent2.getMinX();
                        }
                        else {
                            n = boundsInParent2.getMaxX() - boundsInParent.getMinX();
                        }
                        if (n <= boundsInParent2.getWidth() * 0.75) {
                            break;
                        }
                        this.stopAnim(this.dropHeaderAnim);
                        this.dropHeaderTransitionX = this.xLayoutDirection * -boundsInParent.getWidth();
                        if (this.xLayoutDirection == 1) {
                            this.dragHeaderDestX = boundsInParent2.getMaxX() - boundsInParent.getWidth();
                        }
                        else {
                            this.dragHeaderDestX = boundsInParent2.getMinX();
                        }
                        this.startHeaderReorderingAnim();
                    }
                }
            }
            else {
                for (int j = this.dragTabHeaderIndex - 1; j >= 0; --j) {
                    this.dropTabHeader = (TabHeaderSkin)this.headersRegion.getChildren().get(j);
                    if (this.dropAnimHeader != this.dropTabHeader) {
                        final Bounds boundsInParent3 = this.dropTabHeader.getBoundsInParent();
                        double n2;
                        if (this.xLayoutDirection == 1) {
                            n2 = boundsInParent3.getMaxX() - boundsInParent.getMinX();
                        }
                        else {
                            n2 = boundsInParent.getMaxX() - boundsInParent3.getMinX();
                        }
                        if (n2 <= boundsInParent3.getWidth() * 0.75) {
                            break;
                        }
                        this.stopAnim(this.dropHeaderAnim);
                        this.dropHeaderTransitionX = this.xLayoutDirection * boundsInParent.getWidth();
                        if (this.xLayoutDirection == 1) {
                            this.dragHeaderDestX = boundsInParent3.getMinX();
                        }
                        else {
                            this.dragHeaderDestX = boundsInParent3.getMaxX() - boundsInParent.getWidth();
                        }
                        this.startHeaderReorderingAnim();
                    }
                }
            }
        }
        this.dragEventPrevLoc = headerRegionLocalX;
        mouseEvent.consume();
    }
    
    private void startDrag(final MouseEvent mouseEvent) {
        this.stopAnim(this.dropHeaderAnim);
        this.stopAnim(this.dragHeaderAnim);
        this.dragTabHeader = (TabHeaderSkin)mouseEvent.getSource();
        if (this.dragTabHeader != null) {
            this.dragState = DragState.START;
            this.swapTab = null;
            this.xLayoutDirection = this.deriveTabHeaderLayoutXDirection();
            this.dragEventPrevLoc = this.getHeaderRegionLocalX(mouseEvent);
            this.dragTabHeaderIndex = this.headersRegion.getChildren().indexOf(this.dragTabHeader);
            this.dragTabHeader.setViewOrder(0.0);
            final double layoutX = this.dragTabHeader.getLayoutX();
            this.dragHeaderDestX = layoutX;
            this.dragHeaderStartX = layoutX;
        }
    }
    
    private double getHeaderRegionLocalX(final MouseEvent mouseEvent) {
        return this.headersRegion.sceneToLocal(mouseEvent.getSceneX(), mouseEvent.getSceneY()).getX();
    }
    
    private void stopDrag() {
        if (this.dragState == DragState.START) {
            this.resetDrag();
            return;
        }
        this.dragHeaderSourceX = this.dragTabHeader.getLayoutX();
        this.dragHeaderTransitionX = this.dragHeaderDestX - this.dragHeaderSourceX;
        this.dragHeaderAnim.playFromStart();
        if (this.dragHeaderStartX != this.dragHeaderDestX) {
            ((TabObservableList)this.getSkinnable().getTabs()).reorder(this.dragTabHeader.tab, this.swapTab);
            this.swapTab = null;
        }
    }
    
    private void resetDrag() {
        this.dragState = DragState.NONE;
        this.dragTabHeader.setViewOrder(1.0);
        this.dragTabHeader = null;
        this.dropTabHeader = null;
        this.headersRegion.requestLayout();
    }
    
    private void startHeaderReorderingAnim() {
        this.dropAnimHeader = this.dropTabHeader;
        this.swapTab = this.dropAnimHeader.tab;
        this.dropHeaderSourceX = this.dropAnimHeader.getLayoutX();
        this.dropHeaderAnim.playFromStart();
    }
    
    private void completeHeaderReordering() {
        if (this.dropAnimHeader != null) {
            this.headersRegion.getChildren().remove(this.dropAnimHeader);
            this.headersRegion.getChildren().add(this.dragTabHeaderIndex, this.dropAnimHeader);
            this.dropAnimHeader = null;
            this.headersRegion.requestLayout();
            this.dragTabHeaderIndex = this.headersRegion.getChildren().indexOf(this.dragTabHeader);
        }
    }
    
    private void stopAnim(final Animation animation) {
        if (animation.getStatus() == Animation.Status.RUNNING) {
            animation.getOnFinished().handle(null);
            animation.stop();
        }
    }
    
    ContextMenu test_getTabsMenu() {
        return this.tabHeaderArea.controlButtons.popup;
    }
    
    static {
        TabPaneSkin.CLOSE_BTN_SIZE = 16;
        SELECTED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("selected");
        TOP_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("top");
        BOTTOM_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("bottom");
        LEFT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("left");
        RIGHT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("right");
        DISABLED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("disabled");
    }
    
    private enum TabAnimation
    {
        NONE, 
        GROW;
    }
    
    private enum TabAnimationState
    {
        SHOWING, 
        HIDING, 
        NONE;
    }
    
    private static class StyleableProperties
    {
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        private static final CssMetaData<TabPane, TabAnimation> OPEN_TAB_ANIMATION;
        private static final CssMetaData<TabPane, TabAnimation> CLOSE_TAB_ANIMATION;
        
        static {
            OPEN_TAB_ANIMATION = new CssMetaData<TabPane, TabAnimation>((StyleConverter)new EnumConverter(TabAnimation.class), TabAnimation.GROW) {
                @Override
                public boolean isSettable(final TabPane tabPane) {
                    return true;
                }
                
                @Override
                public StyleableProperty<TabAnimation> getStyleableProperty(final TabPane tabPane) {
                    return (StyleableProperty<TabAnimation>)(StyleableProperty)((TabPaneSkin)tabPane.getSkin()).openTabAnimation;
                }
            };
            CLOSE_TAB_ANIMATION = new CssMetaData<TabPane, TabAnimation>((StyleConverter)new EnumConverter(TabAnimation.class), TabAnimation.GROW) {
                @Override
                public boolean isSettable(final TabPane tabPane) {
                    return true;
                }
                
                @Override
                public StyleableProperty<TabAnimation> getStyleableProperty(final TabPane tabPane) {
                    return (StyleableProperty<TabAnimation>)(StyleableProperty)((TabPaneSkin)tabPane.getSkin()).closeTabAnimation;
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(SkinBase.getClassCssMetaData());
            list.add(StyleableProperties.OPEN_TAB_ANIMATION);
            list.add(StyleableProperties.CLOSE_TAB_ANIMATION);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    class TabHeaderArea extends StackPane
    {
        private Rectangle headerClip;
        private StackPane headersRegion;
        private StackPane headerBackground;
        private TabControlButtons controlButtons;
        private boolean measureClosingTabs;
        private double scrollOffset;
        
        public TabHeaderArea() {
            this.measureClosingTabs = false;
            this.getStyleClass().setAll("tab-header-area");
            this.setManaged(false);
            final TabPane tabPane = TabPaneSkin.this.getSkinnable();
            this.headerClip = new Rectangle();
            this.headersRegion = new StackPane() {
                @Override
                protected double computePrefWidth(final double n) {
                    double n2 = 0.0;
                    for (final TabHeaderSkin tabHeaderSkin : this.getChildren()) {
                        if (tabHeaderSkin.isVisible() && (TabHeaderArea.this.measureClosingTabs || !tabHeaderSkin.isClosing)) {
                            n2 += tabHeaderSkin.prefWidth(n);
                        }
                    }
                    return this.snapSize(n2) + this.snappedLeftInset() + this.snappedRightInset();
                }
                
                @Override
                protected double computePrefHeight(final double n) {
                    double max = 0.0;
                    final Iterator<Node> iterator = this.getChildren().iterator();
                    while (iterator.hasNext()) {
                        max = Math.max(max, ((TabHeaderSkin)iterator.next()).prefHeight(n));
                    }
                    return this.snapSize(max) + this.snappedTopInset() + this.snappedBottomInset();
                }
                
                @Override
                protected void layoutChildren() {
                    if (TabHeaderArea.this.tabsFit()) {
                        TabHeaderArea.this.setScrollOffset(0.0);
                    }
                    else if (TabPaneSkin.this.isSelectingTab) {
                        TabHeaderArea.this.ensureSelectedTabIsVisible();
                    }
                    else {
                        TabHeaderArea.this.validateScrollOffset();
                    }
                    TabPaneSkin.this.isSelectingTab = false;
                    final Side side = TabPaneSkin.this.getSkinnable().getSide();
                    final double snapSize = this.snapSize(this.prefHeight(-1.0));
                    double n = (side.equals(Side.LEFT) || side.equals(Side.BOTTOM)) ? (this.snapSize(this.getWidth()) - TabHeaderArea.this.getScrollOffset()) : TabHeaderArea.this.getScrollOffset();
                    TabHeaderArea.this.updateHeaderClip();
                    for (final TabHeaderSkin tabHeaderSkin : this.getChildren()) {
                        final double snapSize2 = this.snapSize(tabHeaderSkin.prefWidth(-1.0) * tabHeaderSkin.animationTransition.get());
                        final double snapSize3 = this.snapSize(tabHeaderSkin.prefHeight(-1.0));
                        tabHeaderSkin.resize(snapSize2, snapSize3);
                        final double n2 = side.equals(Side.BOTTOM) ? 0.0 : (snapSize - snapSize3 - this.snappedBottomInset());
                        if (side.equals(Side.LEFT) || side.equals(Side.BOTTOM)) {
                            n -= snapSize2;
                            if (TabPaneSkin.this.dragState == DragState.REORDER && (tabHeaderSkin == TabPaneSkin.this.dragTabHeader || tabHeaderSkin == TabPaneSkin.this.dropAnimHeader)) {
                                continue;
                            }
                            tabHeaderSkin.relocate(n, n2);
                        }
                        else {
                            if (TabPaneSkin.this.dragState != DragState.REORDER || (tabHeaderSkin != TabPaneSkin.this.dragTabHeader && tabHeaderSkin != TabPaneSkin.this.dropAnimHeader)) {
                                tabHeaderSkin.relocate(n, n2);
                            }
                            n += snapSize2;
                        }
                    }
                }
            };
            this.headersRegion.getStyleClass().setAll("headers-region");
            this.headersRegion.setClip(this.headerClip);
            TabPaneSkin.this.setupReordering(this.headersRegion);
            this.headerBackground = new StackPane();
            this.headerBackground.getStyleClass().setAll("tab-header-background");
            int n = 0;
            final Iterator<Object> iterator = tabPane.getTabs().iterator();
            while (iterator.hasNext()) {
                this.addTab(iterator.next(), n++);
            }
            (this.controlButtons = new TabControlButtons()).setVisible(false);
            if (this.controlButtons.isVisible()) {
                this.controlButtons.setVisible(true);
            }
            this.getChildren().addAll(this.headerBackground, this.headersRegion, this.controlButtons);
            final Side side;
            this.addEventHandler(ScrollEvent.SCROLL, scrollEvent -> {
                TabPaneSkin.this.getSkinnable().getSide();
                switch ((side == null) ? Side.TOP : side) {
                    default: {
                        this.setScrollOffset(this.scrollOffset + scrollEvent.getDeltaY());
                        break;
                    }
                    case LEFT:
                    case RIGHT: {
                        this.setScrollOffset(this.scrollOffset - scrollEvent.getDeltaY());
                        break;
                    }
                }
            });
        }
        
        private void updateHeaderClip() {
            final Side side = TabPaneSkin.this.getSkinnable().getSide();
            double x = 0.0;
            final double y = 0.0;
            double radius = 0.0;
            final double firstTabIndent = this.firstTabIndent();
            double snapSize = this.snapSize(this.controlButtons.prefWidth(-1.0));
            this.measureClosingTabs = true;
            final double snapSize2 = this.snapSize(this.headersRegion.prefWidth(-1.0));
            this.measureClosingTabs = false;
            final double snapSize3 = this.snapSize(this.headersRegion.prefHeight(-1.0));
            if (snapSize > 0.0) {
                snapSize += 10.0;
            }
            if (this.headersRegion.getEffect() instanceof DropShadow) {
                radius = ((DropShadow)this.headersRegion.getEffect()).getRadius();
            }
            final double n = this.snapSize(this.getWidth()) - snapSize - firstTabIndent;
            double width;
            double height;
            if (side.equals(Side.LEFT) || side.equals(Side.BOTTOM)) {
                if (snapSize2 < n) {
                    width = snapSize2 + radius;
                }
                else {
                    x = snapSize2 - n;
                    width = n + radius;
                }
                height = snapSize3;
            }
            else {
                x = -radius;
                width = ((snapSize2 < n) ? snapSize2 : n) + radius;
                height = snapSize3;
            }
            this.headerClip.setX(x);
            this.headerClip.setY(y);
            this.headerClip.setWidth(width);
            this.headerClip.setHeight(height);
        }
        
        private void addTab(final Tab tab, final int n) {
            this.headersRegion.getChildren().add(n, new TabHeaderSkin(tab));
        }
        
        private void removeTab(final Tab tab) {
            final TabHeaderSkin tabHeaderSkin = this.getTabHeaderSkin(tab);
            if (tabHeaderSkin != null) {
                this.headersRegion.getChildren().remove(tabHeaderSkin);
            }
        }
        
        private TabHeaderSkin getTabHeaderSkin(final Tab obj) {
            for (final TabHeaderSkin tabHeaderSkin : this.headersRegion.getChildren()) {
                if (tabHeaderSkin.getTab().equals(obj)) {
                    return tabHeaderSkin;
                }
            }
            return null;
        }
        
        private boolean tabsFit() {
            return this.snapSize(this.headersRegion.prefWidth(-1.0)) + this.snapSize(this.controlButtons.prefWidth(-1.0)) + this.firstTabIndent() + 10.0 < this.getWidth();
        }
        
        private void ensureSelectedTabIsVisible() {
            final double n = this.snapSize(TabPaneSkin.this.isHorizontal() ? TabPaneSkin.this.getSkinnable().getWidth() : TabPaneSkin.this.getSkinnable().getHeight()) - this.snapSize(this.controlButtons.getWidth()) - this.firstTabIndent() - 10.0;
            double n2 = 0.0;
            double n3 = 0.0;
            double n4 = 0.0;
            for (final TabHeaderSkin tabHeaderSkin : this.headersRegion.getChildren()) {
                final double snapSize = this.snapSize(tabHeaderSkin.prefWidth(-1.0));
                if (TabPaneSkin.this.selectedTab != null && TabPaneSkin.this.selectedTab.equals(tabHeaderSkin.getTab())) {
                    n3 = n2;
                    n4 = snapSize;
                }
                n2 += snapSize;
            }
            final double scrollOffset = this.getScrollOffset();
            final double n5 = n3;
            final double n6 = n3 + n4;
            final double n7 = n;
            if (n5 < -scrollOffset) {
                this.setScrollOffset(-n5);
            }
            else if (n6 > n7 - scrollOffset) {
                this.setScrollOffset(n7 - n6);
            }
        }
        
        public double getScrollOffset() {
            return this.scrollOffset;
        }
        
        private void validateScrollOffset() {
            this.setScrollOffset(this.getScrollOffset());
        }
        
        private void setScrollOffset(final double n) {
            final double n2 = this.snapSize(TabPaneSkin.this.isHorizontal() ? TabPaneSkin.this.getSkinnable().getWidth() : TabPaneSkin.this.getSkinnable().getHeight()) - this.snapSize(this.controlButtons.getWidth()) - this.firstTabIndent() - 10.0;
            double n3 = 0.0;
            final Iterator<Node> iterator = this.headersRegion.getChildren().iterator();
            while (iterator.hasNext()) {
                n3 += this.snapSize(((TabHeaderSkin)iterator.next()).prefWidth(-1.0));
            }
            double scrollOffset;
            if (n2 - n > n3 && n < 0.0) {
                scrollOffset = n2 - n3;
            }
            else if (n > 0.0) {
                scrollOffset = 0.0;
            }
            else {
                scrollOffset = n;
            }
            if (Math.abs(scrollOffset - this.scrollOffset) > 0.001) {
                this.scrollOffset = scrollOffset;
                this.headersRegion.requestLayout();
            }
        }
        
        private double firstTabIndent() {
            switch (TabPaneSkin.this.getSkinnable().getSide()) {
                case TOP:
                case BOTTOM: {
                    return this.snappedLeftInset();
                }
                case LEFT:
                case RIGHT: {
                    return this.snappedTopInset();
                }
                default: {
                    return 0.0;
                }
            }
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            return this.snapSize(this.headersRegion.prefWidth(n)) + this.controlButtons.prefWidth(n) + this.firstTabIndent() + 10.0 + (TabPaneSkin.this.isHorizontal() ? (this.snappedLeftInset() + this.snappedRightInset()) : (this.snappedTopInset() + this.snappedBottomInset()));
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            return this.snapSize(this.headersRegion.prefHeight(-1.0)) + (TabPaneSkin.this.isHorizontal() ? (this.snappedTopInset() + this.snappedBottomInset()) : (this.snappedLeftInset() + this.snappedRightInset()));
        }
        
        @Override
        public double getBaselineOffset() {
            if (TabPaneSkin.this.getSkinnable().getSide() == Side.TOP) {
                return this.headersRegion.getBaselineOffset() + this.snappedTopInset();
            }
            return 0.0;
        }
        
        @Override
        protected void layoutChildren() {
            final double snappedLeftInset = this.snappedLeftInset();
            final double snappedRightInset = this.snappedRightInset();
            final double snappedTopInset = this.snappedTopInset();
            final double snappedBottomInset = this.snappedBottomInset();
            final double n = this.snapSize(this.getWidth()) - (TabPaneSkin.this.isHorizontal() ? (snappedLeftInset + snappedRightInset) : (snappedTopInset + snappedBottomInset));
            final double n2 = this.snapSize(this.getHeight()) - (TabPaneSkin.this.isHorizontal() ? (snappedTopInset + snappedBottomInset) : (snappedLeftInset + snappedRightInset));
            final double snapSize = this.snapSize(this.prefHeight(-1.0));
            final double snapSize2 = this.snapSize(this.headersRegion.prefWidth(-1.0));
            final double snapSize3 = this.snapSize(this.headersRegion.prefHeight(-1.0));
            this.controlButtons.showTabsMenu(!this.tabsFit());
            this.updateHeaderClip();
            this.headersRegion.requestLayout();
            final double snapSize4 = this.snapSize(this.controlButtons.prefWidth(-1.0));
            final double prefHeight = this.controlButtons.prefHeight(snapSize4);
            this.controlButtons.resize(snapSize4, prefHeight);
            this.headersRegion.resize(snapSize2, snapSize3);
            if (TabPaneSkin.this.isFloatingStyleClass()) {
                this.headerBackground.setVisible(false);
            }
            else {
                this.headerBackground.resize(this.snapSize(this.getWidth()), this.snapSize(this.getHeight()));
                this.headerBackground.setVisible(true);
            }
            double n3 = 0.0;
            double n4 = 0.0;
            double n5 = 0.0;
            double n6 = 0.0;
            final Side side = TabPaneSkin.this.getSkinnable().getSide();
            if (side.equals(Side.TOP)) {
                n3 = snappedLeftInset;
                n4 = snapSize - snapSize3 - snappedBottomInset;
                n5 = n - snapSize4 + snappedLeftInset;
                n6 = this.snapSize(this.getHeight()) - prefHeight - snappedBottomInset;
            }
            else if (side.equals(Side.RIGHT)) {
                n3 = snappedTopInset;
                n4 = snapSize - snapSize3 - snappedLeftInset;
                n5 = n - snapSize4 + snappedTopInset;
                n6 = this.snapSize(this.getHeight()) - prefHeight - snappedLeftInset;
            }
            else if (side.equals(Side.BOTTOM)) {
                n3 = this.snapSize(this.getWidth()) - snapSize2 - snappedLeftInset;
                n4 = snapSize - snapSize3 - snappedTopInset;
                n5 = snappedRightInset;
                n6 = this.snapSize(this.getHeight()) - prefHeight - snappedTopInset;
            }
            else if (side.equals(Side.LEFT)) {
                n3 = this.snapSize(this.getWidth()) - snapSize2 - snappedTopInset;
                n4 = snapSize - snapSize3 - snappedRightInset;
                n5 = snappedLeftInset;
                n6 = this.snapSize(this.getHeight()) - prefHeight - snappedRightInset;
            }
            if (this.headerBackground.isVisible()) {
                this.positionInArea(this.headerBackground, 0.0, 0.0, this.snapSize(this.getWidth()), this.snapSize(this.getHeight()), 0.0, HPos.CENTER, VPos.CENTER);
            }
            this.positionInArea(this.headersRegion, n3, n4, n, n2, 0.0, HPos.LEFT, VPos.CENTER);
            this.positionInArea(this.controlButtons, n5, n6, snapSize4, prefHeight, 0.0, HPos.CENTER, VPos.CENTER);
        }
    }
    
    class TabHeaderSkin extends StackPane
    {
        private final Tab tab;
        private Label label;
        private StackPane closeBtn;
        private StackPane inner;
        private Tooltip oldTooltip;
        private Tooltip tooltip;
        private Rectangle clip;
        private boolean isClosing;
        private LambdaMultiplePropertyChangeListenerHandler listener;
        private final ListChangeListener<String> styleClassListener;
        private final WeakListChangeListener<String> weakStyleClassListener;
        private final DoubleProperty animationTransition;
        private TabAnimationState animationState;
        private Timeline currentAnimation;
        
        public Tab getTab() {
            return this.tab;
        }
        
        public TabHeaderSkin(final Tab tab) {
            this.isClosing = false;
            this.listener = new LambdaMultiplePropertyChangeListenerHandler();
            this.styleClassListener = new ListChangeListener<String>() {
                @Override
                public void onChanged(final Change<? extends String> change) {
                    TabHeaderSkin.this.getStyleClass().setAll(TabHeaderSkin.this.tab.getStyleClass());
                }
            };
            this.weakStyleClassListener = new WeakListChangeListener<String>(this.styleClassListener);
            this.animationTransition = new SimpleDoubleProperty((Object)this, "animationTransition", 1.0) {
                @Override
                protected void invalidated() {
                    TabHeaderSkin.this.requestLayout();
                }
            };
            this.animationState = TabAnimationState.NONE;
            this.getStyleClass().setAll(tab.getStyleClass());
            this.setId(tab.getId());
            this.setStyle(tab.getStyle());
            this.setAccessibleRole(AccessibleRole.TAB_ITEM);
            this.setViewOrder(1.0);
            this.tab = tab;
            this.setClip(this.clip = new Rectangle());
            this.label = new Label(tab.getText(), tab.getGraphic());
            this.label.getStyleClass().setAll("tab-label");
            (this.closeBtn = new StackPane() {
                @Override
                protected double computePrefWidth(final double n) {
                    return TabPaneSkin.CLOSE_BTN_SIZE;
                }
                
                @Override
                protected double computePrefHeight(final double n) {
                    return TabPaneSkin.CLOSE_BTN_SIZE;
                }
                
                @Override
                public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
                    switch (accessibleAction) {
                        case FIRE: {
                            final Tab tab = TabHeaderSkin.this.getTab();
                            if (TabPaneSkin.this.behavior.canCloseTab(tab)) {
                                TabPaneSkin.this.behavior.closeTab(tab);
                                this.setOnMousePressed(null);
                                break;
                            }
                            break;
                        }
                        default: {
                            super.executeAccessibleAction(accessibleAction, array);
                            break;
                        }
                    }
                }
            }).setAccessibleRole(AccessibleRole.BUTTON);
            this.closeBtn.setAccessibleText(ControlResources.getString("Accessibility.title.TabPane.CloseButton"));
            this.closeBtn.getStyleClass().setAll("tab-close-button");
            this.closeBtn.setOnMousePressed(new EventHandler<MouseEvent>() {
                @Override
                public void handle(final MouseEvent mouseEvent) {
                    final Tab tab = TabHeaderSkin.this.getTab();
                    if (mouseEvent.getButton().equals(MouseButton.PRIMARY) && TabPaneSkin.this.behavior.canCloseTab(tab)) {
                        TabPaneSkin.this.behavior.closeTab(tab);
                        TabHeaderSkin.this.setOnMousePressed(null);
                        mouseEvent.consume();
                    }
                }
            });
            this.updateGraphicRotation();
            final Region region = new Region();
            region.setMouseTransparent(true);
            region.getStyleClass().add("focus-indicator");
            this.inner = new StackPane() {
                @Override
                protected void layoutChildren() {
                    final TabPane tabPane = TabPaneSkin.this.getSkinnable();
                    final double snappedTopInset = this.snappedTopInset();
                    final double snappedRightInset = this.snappedRightInset();
                    final double snappedBottomInset = this.snappedBottomInset();
                    final double snappedLeftInset = this.snappedLeftInset();
                    final double a = this.getWidth() - (snappedLeftInset + snappedRightInset);
                    final double n = this.getHeight() - (snappedTopInset + snappedBottomInset);
                    final double snapSize = this.snapSize(TabHeaderSkin.this.label.prefWidth(-1.0));
                    final double snapSize2 = this.snapSize(TabHeaderSkin.this.label.prefHeight(-1.0));
                    final double n2 = TabHeaderSkin.this.showCloseButton() ? this.snapSize(TabHeaderSkin.this.closeBtn.prefWidth(-1.0)) : 0.0;
                    final double b = TabHeaderSkin.this.showCloseButton() ? this.snapSize(TabHeaderSkin.this.closeBtn.prefHeight(-1.0)) : 0.0;
                    final double snapSize3 = this.snapSize(tabPane.getTabMinWidth());
                    final double snapSize4 = this.snapSize(tabPane.getTabMaxWidth());
                    final double snapSize5 = this.snapSize(tabPane.getTabMaxHeight());
                    double n3 = snapSize;
                    double n4 = snapSize;
                    double a2 = snapSize2;
                    final double n5 = n3 + n2;
                    final double max = Math.max(a2, b);
                    if (n5 > snapSize4 && snapSize4 != Double.MAX_VALUE) {
                        n3 = snapSize4 - n2;
                        n4 = snapSize4 - n2;
                    }
                    else if (n5 < snapSize3) {
                        n3 = snapSize3 - n2;
                    }
                    if (max > snapSize5 && snapSize5 != Double.MAX_VALUE) {
                        a2 = snapSize5;
                    }
                    if (TabHeaderSkin.this.animationState != TabAnimationState.NONE) {
                        n3 *= TabHeaderSkin.this.animationTransition.get();
                        TabHeaderSkin.this.closeBtn.setVisible(false);
                    }
                    else {
                        TabHeaderSkin.this.closeBtn.setVisible(TabHeaderSkin.this.showCloseButton());
                    }
                    TabHeaderSkin.this.label.resize(n4, a2);
                    final double n6 = snappedLeftInset;
                    final double n7 = ((snapSize4 < Double.MAX_VALUE) ? Math.min(a, snapSize4) : a) - snappedRightInset - n2;
                    this.positionInArea(TabHeaderSkin.this.label, n6, snappedTopInset, n3, n, 0.0, HPos.CENTER, VPos.CENTER);
                    if (TabHeaderSkin.this.closeBtn.isVisible()) {
                        TabHeaderSkin.this.closeBtn.resize(n2, b);
                        this.positionInArea(TabHeaderSkin.this.closeBtn, n7, snappedTopInset, n2, n, 0.0, HPos.CENTER, VPos.CENTER);
                    }
                    final int n8 = Utils.isMac() ? 2 : 3;
                    final int n9 = Utils.isMac() ? 2 : 1;
                    region.resizeRelocate(snappedLeftInset - n9, snappedTopInset + n8, a + 2 * n9, n - 2 * n8);
                }
            };
            this.inner.getStyleClass().add("tab-container");
            this.inner.setRotate(TabPaneSkin.this.getSkinnable().getSide().equals(Side.BOTTOM) ? 180.0 : 0.0);
            this.inner.getChildren().addAll(this.label, this.closeBtn, region);
            this.getChildren().addAll(this.inner);
            this.tooltip = tab.getTooltip();
            if (this.tooltip != null) {
                Tooltip.install(this, this.tooltip);
                this.oldTooltip = this.tooltip;
            }
            this.listener.registerChangeListener(tab.closableProperty(), p0 -> {
                this.inner.requestLayout();
                this.requestLayout();
                return;
            });
            this.listener.registerChangeListener(tab.selectedProperty(), p1 -> {
                this.pseudoClassStateChanged(TabPaneSkin.SELECTED_PSEUDOCLASS_STATE, tab.isSelected());
                this.inner.requestLayout();
                this.requestLayout();
                return;
            });
            this.listener.registerChangeListener(tab.textProperty(), p0 -> this.label.setText(this.getTab().getText()));
            this.listener.registerChangeListener(tab.graphicProperty(), p0 -> this.label.setGraphic(this.getTab().getGraphic()));
            this.listener.registerChangeListener(tab.tooltipProperty(), p1 -> {
                if (this.oldTooltip != null) {
                    Tooltip.uninstall(this, this.oldTooltip);
                }
                this.tooltip = tab.getTooltip();
                if (this.tooltip != null) {
                    Tooltip.install(this, this.tooltip);
                    this.oldTooltip = this.tooltip;
                }
                return;
            });
            this.listener.registerChangeListener(tab.disabledProperty(), p0 -> this.updateTabDisabledState());
            this.listener.registerChangeListener(tab.getTabPane().disabledProperty(), p0 -> this.updateTabDisabledState());
            this.listener.registerChangeListener(tab.styleProperty(), p1 -> this.setStyle(tab.getStyle()));
            tab.getStyleClass().addListener(this.weakStyleClassListener);
            this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabClosingPolicyProperty(), p0 -> {
                this.inner.requestLayout();
                this.requestLayout();
                return;
            });
            final Side side;
            this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().sideProperty(), p0 -> {
                TabPaneSkin.this.getSkinnable().getSide();
                this.pseudoClassStateChanged(TabPaneSkin.TOP_PSEUDOCLASS_STATE, side == Side.TOP);
                this.pseudoClassStateChanged(TabPaneSkin.RIGHT_PSEUDOCLASS_STATE, side == Side.RIGHT);
                this.pseudoClassStateChanged(TabPaneSkin.BOTTOM_PSEUDOCLASS_STATE, side == Side.BOTTOM);
                this.pseudoClassStateChanged(TabPaneSkin.LEFT_PSEUDOCLASS_STATE, side == Side.LEFT);
                this.inner.setRotate((side == Side.BOTTOM) ? 180.0 : 0.0);
                if (TabPaneSkin.this.getSkinnable().isRotateGraphic()) {
                    this.updateGraphicRotation();
                }
                return;
            });
            this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().rotateGraphicProperty(), p0 -> this.updateGraphicRotation());
            this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabMinWidthProperty(), p0 -> {
                this.requestLayout();
                TabPaneSkin.this.getSkinnable().requestLayout();
                return;
            });
            this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabMaxWidthProperty(), p0 -> {
                this.requestLayout();
                TabPaneSkin.this.getSkinnable().requestLayout();
                return;
            });
            this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabMinHeightProperty(), p0 -> {
                this.requestLayout();
                TabPaneSkin.this.getSkinnable().requestLayout();
                return;
            });
            this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabMaxHeightProperty(), p0 -> {
                this.requestLayout();
                TabPaneSkin.this.getSkinnable().requestLayout();
                return;
            });
            this.getProperties().put(Tab.class, tab);
            this.getProperties().put(ContextMenu.class, tab.getContextMenu());
            this.setOnContextMenuRequested(contextMenuEvent -> {
                if (this.getTab().getContextMenu() != null) {
                    this.getTab().getContextMenu().show(this.inner, contextMenuEvent.getScreenX(), contextMenuEvent.getScreenY());
                    contextMenuEvent.consume();
                }
                return;
            });
            this.setOnMousePressed(new EventHandler<MouseEvent>() {
                @Override
                public void handle(final MouseEvent mouseEvent) {
                    final Tab tab = TabHeaderSkin.this.getTab();
                    if (tab.isDisable()) {
                        return;
                    }
                    if ((mouseEvent.getButton().equals(MouseButton.MIDDLE) || mouseEvent.getButton().equals(MouseButton.PRIMARY)) && tab.getContextMenu() != null && tab.getContextMenu().isShowing()) {
                        tab.getContextMenu().hide();
                    }
                    if (mouseEvent.getButton().equals(MouseButton.MIDDLE)) {
                        if (TabHeaderSkin.this.showCloseButton() && TabPaneSkin.this.behavior.canCloseTab(tab)) {
                            TabHeaderSkin.this.removeListeners(tab);
                            TabPaneSkin.this.behavior.closeTab(tab);
                        }
                    }
                    else if (mouseEvent.getButton().equals(MouseButton.PRIMARY)) {
                        TabPaneSkin.this.behavior.selectTab(tab);
                    }
                }
            });
            this.pseudoClassStateChanged(TabPaneSkin.SELECTED_PSEUDOCLASS_STATE, tab.isSelected());
            this.pseudoClassStateChanged(TabPaneSkin.DISABLED_PSEUDOCLASS_STATE, tab.isDisabled());
            final Side side2 = TabPaneSkin.this.getSkinnable().getSide();
            this.pseudoClassStateChanged(TabPaneSkin.TOP_PSEUDOCLASS_STATE, side2 == Side.TOP);
            this.pseudoClassStateChanged(TabPaneSkin.RIGHT_PSEUDOCLASS_STATE, side2 == Side.RIGHT);
            this.pseudoClassStateChanged(TabPaneSkin.BOTTOM_PSEUDOCLASS_STATE, side2 == Side.BOTTOM);
            this.pseudoClassStateChanged(TabPaneSkin.LEFT_PSEUDOCLASS_STATE, side2 == Side.LEFT);
        }
        
        private void updateTabDisabledState() {
            this.pseudoClassStateChanged(TabPaneSkin.DISABLED_PSEUDOCLASS_STATE, this.tab.isDisabled());
            this.inner.requestLayout();
            this.requestLayout();
        }
        
        private void updateGraphicRotation() {
            if (this.label.getGraphic() != null) {
                this.label.getGraphic().setRotate(TabPaneSkin.this.getSkinnable().isRotateGraphic() ? 0.0 : ((double)(TabPaneSkin.this.getSkinnable().getSide().equals(Side.RIGHT) ? -90.0f : (TabPaneSkin.this.getSkinnable().getSide().equals(Side.LEFT) ? 90.0f : 0.0f))));
            }
        }
        
        private boolean showCloseButton() {
            return this.tab.isClosable() && (TabPaneSkin.this.getSkinnable().getTabClosingPolicy().equals(TabPane.TabClosingPolicy.ALL_TABS) || (TabPaneSkin.this.getSkinnable().getTabClosingPolicy().equals(TabPane.TabClosingPolicy.SELECTED_TAB) && this.tab.isSelected()));
        }
        
        private void removeListeners(final Tab tab) {
            this.listener.dispose();
            this.inner.getChildren().clear();
            this.getChildren().clear();
            this.setOnContextMenuRequested(null);
            this.setOnMousePressed(null);
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            final double snapSize = this.snapSize(TabPaneSkin.this.getSkinnable().getTabMinWidth());
            final double snapSize2 = this.snapSize(TabPaneSkin.this.getSkinnable().getTabMaxWidth());
            final double snappedRightInset = this.snappedRightInset();
            final double snappedLeftInset = this.snappedLeftInset();
            double snapSize3 = this.snapSize(this.label.prefWidth(-1.0));
            if (this.showCloseButton()) {
                snapSize3 += this.snapSize(this.closeBtn.prefWidth(-1.0));
            }
            if (snapSize3 > snapSize2) {
                snapSize3 = snapSize2;
            }
            else if (snapSize3 < snapSize) {
                snapSize3 = snapSize;
            }
            return snapSize3 + (snappedRightInset + snappedLeftInset);
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            final double snapSize = this.snapSize(TabPaneSkin.this.getSkinnable().getTabMinHeight());
            final double snapSize2 = this.snapSize(TabPaneSkin.this.getSkinnable().getTabMaxHeight());
            final double snappedTopInset = this.snappedTopInset();
            final double snappedBottomInset = this.snappedBottomInset();
            double snapSize3 = this.snapSize(this.label.prefHeight(n));
            if (snapSize3 > snapSize2) {
                snapSize3 = snapSize2;
            }
            else if (snapSize3 < snapSize) {
                snapSize3 = snapSize;
            }
            return snapSize3 + (snappedTopInset + snappedBottomInset);
        }
        
        @Override
        protected void layoutChildren() {
            this.inner.resize((this.snapSize(this.getWidth()) - this.snappedRightInset() - this.snappedLeftInset()) * this.animationTransition.getValue(), this.snapSize(this.getHeight()) - this.snappedTopInset() - this.snappedBottomInset());
            this.inner.relocate(this.snappedLeftInset(), this.snappedTopInset());
        }
        
        @Override
        protected void setWidth(final double n) {
            super.setWidth(n);
            this.clip.setWidth(n);
        }
        
        @Override
        protected void setHeight(final double n) {
            super.setHeight(n);
            this.clip.setHeight(n);
        }
        
        @Override
        public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
            switch (accessibleAttribute) {
                case TEXT: {
                    return this.getTab().getText();
                }
                case SELECTED: {
                    return TabPaneSkin.this.selectedTab == this.getTab();
                }
                default: {
                    return super.queryAccessibleAttribute(accessibleAttribute, array);
                }
            }
        }
        
        @Override
        public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
            switch (accessibleAction) {
                case REQUEST_FOCUS: {
                    TabPaneSkin.this.getSkinnable().getSelectionModel().select(this.getTab());
                    break;
                }
                default: {
                    super.executeAccessibleAction(accessibleAction, array);
                    break;
                }
            }
        }
    }
    
    static class TabContentRegion extends StackPane
    {
        private Tab tab;
        private InvalidationListener tabContentListener;
        private InvalidationListener tabSelectedListener;
        private WeakInvalidationListener weakTabContentListener;
        private WeakInvalidationListener weakTabSelectedListener;
        
        public Tab getTab() {
            return this.tab;
        }
        
        public TabContentRegion(final Tab tab) {
            this.tabContentListener = (p0 -> this.updateContent());
            this.tabSelectedListener = new InvalidationListener() {
                @Override
                public void invalidated(final Observable observable) {
                    TabContentRegion.this.setVisible(TabContentRegion.this.tab.isSelected());
                }
            };
            this.weakTabContentListener = new WeakInvalidationListener(this.tabContentListener);
            this.weakTabSelectedListener = new WeakInvalidationListener(this.tabSelectedListener);
            this.getStyleClass().setAll("tab-content-area");
            this.setManaged(false);
            this.tab = tab;
            this.updateContent();
            this.setVisible(tab.isSelected());
            tab.selectedProperty().addListener(this.weakTabSelectedListener);
            tab.contentProperty().addListener(this.weakTabContentListener);
        }
        
        private void updateContent() {
            final Node content = this.getTab().getContent();
            if (content == null) {
                this.getChildren().clear();
            }
            else {
                this.getChildren().setAll(content);
            }
        }
        
        private void removeListeners(final Tab tab) {
            tab.selectedProperty().removeListener(this.weakTabSelectedListener);
            tab.contentProperty().removeListener(this.weakTabContentListener);
        }
    }
    
    class TabControlButtons extends StackPane
    {
        private StackPane inner;
        private StackPane downArrow;
        private Pane downArrowBtn;
        private boolean showControlButtons;
        private ContextMenu popup;
        private boolean showTabsMenu;
        
        public TabControlButtons() {
            this.showTabsMenu = false;
            this.getStyleClass().setAll("control-buttons-tab");
            final TabPane tabPane = TabPaneSkin.this.getSkinnable();
            this.downArrowBtn = new Pane();
            this.downArrowBtn.getStyleClass().setAll("tab-down-button");
            this.downArrowBtn.setVisible(this.isShowTabsMenu());
            (this.downArrow = new StackPane()).setManaged(false);
            this.downArrow.getStyleClass().setAll("arrow");
            this.downArrow.setRotate(tabPane.getSide().equals(Side.BOTTOM) ? 180.0 : 0.0);
            this.downArrowBtn.getChildren().add(this.downArrow);
            this.downArrowBtn.setOnMouseClicked(p0 -> this.showPopupMenu());
            this.setupPopupMenu();
            this.inner = new StackPane() {
                @Override
                protected double computePrefWidth(final double n) {
                    final double n2 = TabControlButtons.this.isShowTabsMenu() ? (this.snapSize(TabControlButtons.this.downArrow.prefWidth(this.getHeight())) + this.snapSize(TabControlButtons.this.downArrowBtn.prefWidth(this.getHeight()))) : 0.0;
                    double n3 = 0.0;
                    if (TabControlButtons.this.isShowTabsMenu()) {
                        n3 += n2;
                    }
                    if (n3 > 0.0) {
                        n3 += this.snappedLeftInset() + this.snappedRightInset();
                    }
                    return n3;
                }
                
                @Override
                protected double computePrefHeight(final double n) {
                    double max = 0.0;
                    if (TabControlButtons.this.isShowTabsMenu()) {
                        max = Math.max(max, this.snapSize(TabControlButtons.this.downArrowBtn.prefHeight(n)));
                    }
                    if (max > 0.0) {
                        max += this.snappedTopInset() + this.snappedBottomInset();
                    }
                    return max;
                }
                
                @Override
                protected void layoutChildren() {
                    if (TabControlButtons.this.isShowTabsMenu()) {
                        final double n = 0.0;
                        final double snappedTopInset = this.snappedTopInset();
                        this.positionArrow(TabControlButtons.this.downArrowBtn, TabControlButtons.this.downArrow, n, snappedTopInset, this.snapSize(this.getWidth()) - n + this.snappedLeftInset(), this.snapSize(this.getHeight()) - snappedTopInset + this.snappedBottomInset());
                    }
                }
                
                private void positionArrow(final Pane pane, final StackPane stackPane, final double n, final double n2, final double n3, final double n4) {
                    pane.resize(n3, n4);
                    this.positionInArea(pane, n, n2, n3, n4, 0.0, HPos.CENTER, VPos.CENTER);
                    stackPane.resize(this.snapSize(stackPane.prefWidth(-1.0)), this.snapSize(stackPane.prefHeight(-1.0)));
                    this.positionInArea(stackPane, pane.snappedLeftInset(), pane.snappedTopInset(), n3 - pane.snappedLeftInset() - pane.snappedRightInset(), n4 - pane.snappedTopInset() - pane.snappedBottomInset(), 0.0, HPos.CENTER, VPos.CENTER);
                }
            };
            this.inner.getStyleClass().add("container");
            this.inner.getChildren().add(this.downArrowBtn);
            this.getChildren().add(this.inner);
            tabPane.sideProperty().addListener(p0 -> this.downArrow.setRotate(TabPaneSkin.this.getSkinnable().getSide().equals(Side.BOTTOM) ? 180.0 : 0.0));
            tabPane.getTabs().addListener(p0 -> this.setupPopupMenu());
            this.showControlButtons = false;
            if (this.isShowTabsMenu()) {
                this.showControlButtons = true;
                this.requestLayout();
            }
            this.getProperties().put(ContextMenu.class, this.popup);
        }
        
        private void showTabsMenu(final boolean showTabsMenu) {
            final boolean showTabsMenu2 = this.isShowTabsMenu();
            this.showTabsMenu = showTabsMenu;
            if (this.showTabsMenu && !showTabsMenu2) {
                this.downArrowBtn.setVisible(true);
                this.showControlButtons = true;
                this.inner.requestLayout();
                TabPaneSkin.this.tabHeaderArea.requestLayout();
            }
            else if (!this.showTabsMenu && showTabsMenu2) {
                this.hideControlButtons();
            }
        }
        
        private boolean isShowTabsMenu() {
            return this.showTabsMenu;
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            double snapSize = this.snapSize(this.inner.prefWidth(n));
            if (snapSize > 0.0) {
                snapSize += this.snappedLeftInset() + this.snappedRightInset();
            }
            return snapSize;
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            return Math.max(TabPaneSkin.this.getSkinnable().getTabMinHeight(), this.snapSize(this.inner.prefHeight(n))) + this.snappedTopInset() + this.snappedBottomInset();
        }
        
        @Override
        protected void layoutChildren() {
            final double snappedLeftInset = this.snappedLeftInset();
            final double snappedTopInset = this.snappedTopInset();
            final double n = this.snapSize(this.getWidth()) - snappedLeftInset + this.snappedRightInset();
            final double n2 = this.snapSize(this.getHeight()) - snappedTopInset + this.snappedBottomInset();
            if (this.showControlButtons) {
                this.showControlButtons();
                this.showControlButtons = false;
            }
            this.inner.resize(n, n2);
            this.positionInArea(this.inner, snappedLeftInset, snappedTopInset, n, n2, 0.0, HPos.CENTER, VPos.BOTTOM);
        }
        
        private void showControlButtons() {
            this.setVisible(true);
            if (this.popup == null) {
                this.setupPopupMenu();
            }
        }
        
        private void hideControlButtons() {
            if (this.isShowTabsMenu()) {
                this.showControlButtons = true;
            }
            else {
                this.setVisible(false);
                this.clearPopupMenu();
                this.popup = null;
            }
            this.requestLayout();
        }
        
        private void setupPopupMenu() {
            if (this.popup == null) {
                this.popup = new ContextMenu();
            }
            this.clearPopupMenu();
            final ToggleGroup toggleGroup = new ToggleGroup();
            final ObservableList<TabMenuItem> observableArrayList = FXCollections.observableArrayList();
            final Iterator<Tab> iterator = (Iterator<Tab>)TabPaneSkin.this.getSkinnable().getTabs().iterator();
            while (iterator.hasNext()) {
                final TabMenuItem tabMenuItem = new TabMenuItem(iterator.next());
                tabMenuItem.setToggleGroup(toggleGroup);
                final Tab tab;
                tabMenuItem.setOnAction(p1 -> TabPaneSkin.this.getSkinnable().getSelectionModel().select(tab));
                observableArrayList.add(tabMenuItem);
            }
            this.popup.getItems().addAll((Collection<?>)observableArrayList);
        }
        
        private void clearPopupMenu() {
            final Iterator<MenuItem> iterator = this.popup.getItems().iterator();
            while (iterator.hasNext()) {
                ((TabMenuItem)iterator.next()).dispose();
            }
            this.popup.getItems().clear();
        }
        
        private void showPopupMenu() {
            for (final TabMenuItem tabMenuItem : this.popup.getItems()) {
                if (TabPaneSkin.this.selectedTab.equals(tabMenuItem.getTab())) {
                    tabMenuItem.setSelected(true);
                    break;
                }
            }
            this.popup.show(this.downArrowBtn, Side.BOTTOM, 0.0, 0.0);
        }
    }
    
    static class TabMenuItem extends RadioMenuItem
    {
        Tab tab;
        private InvalidationListener disableListener;
        private WeakInvalidationListener weakDisableListener;
        
        public TabMenuItem(final Tab tab) {
            super(tab.getText(), clone(tab.getGraphic()));
            this.disableListener = new InvalidationListener() {
                @Override
                public void invalidated(final Observable observable) {
                    TabMenuItem.this.setDisable(TabMenuItem.this.tab.isDisable());
                }
            };
            this.weakDisableListener = new WeakInvalidationListener(this.disableListener);
            this.tab = tab;
            this.setDisable(tab.isDisable());
            tab.disableProperty().addListener(this.weakDisableListener);
            this.textProperty().bind(tab.textProperty());
        }
        
        public Tab getTab() {
            return this.tab;
        }
        
        public void dispose() {
            this.textProperty().unbind();
            this.tab.disableProperty().removeListener(this.weakDisableListener);
            this.tab = null;
        }
    }
    
    private enum DragState
    {
        NONE, 
        START, 
        REORDER;
    }
}
