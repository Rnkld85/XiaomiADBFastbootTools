// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.collections.FXCollections;
import javafx.scene.control.Tooltip;
import javafx.scene.shape.StrokeType;
import javafx.scene.paint.Paint;
import com.sun.javafx.scene.control.skin.Utils;
import com.sun.javafx.scene.NodeHelper;
import javafx.geometry.Side;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.StackPane;
import java.util.Iterator;
import com.sun.javafx.scene.ParentHelper;
import javafx.scene.Parent;
import com.sun.javafx.scene.traversal.ParentTraversalEngine;
import com.sun.javafx.scene.traversal.TraversalContext;
import com.sun.javafx.scene.traversal.Direction;
import com.sun.javafx.scene.traversal.Algorithm;
import java.util.List;
import javafx.collections.ObservableList;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.MenuItem;
import javafx.geometry.Bounds;
import javafx.geometry.NodeOrientation;
import javafx.scene.layout.VBox;
import javafx.collections.ListChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventTarget;
import javafx.stage.WindowEvent;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import com.sun.javafx.scene.control.Properties;
import javafx.scene.paint.Color;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.PopupControl;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.GridPane;
import javafx.scene.control.ColorPicker;
import com.sun.javafx.scene.control.CustomColorDialog;
import javafx.scene.control.Hyperlink;
import javafx.scene.layout.Region;

class ColorPalette extends Region
{
    private static final int SQUARE_SIZE = 15;
    ColorPickerGrid colorPickerGrid;
    final Hyperlink customColorLink;
    CustomColorDialog customColorDialog;
    private ColorPicker colorPicker;
    private final GridPane standardColorGrid;
    private final GridPane customColorGrid;
    private final Separator separator;
    private final Label customColorLabel;
    private PopupControl popupControl;
    private ColorSquare focusedSquare;
    private ContextMenu contextMenu;
    private Color mouseDragColor;
    private boolean dragDetected;
    private int customColorNumber;
    private int customColorRows;
    private int customColorLastRowLength;
    private final ColorSquare hoverSquare;
    private static final int NUM_OF_COLUMNS = 12;
    private static double[] RAW_VALUES;
    private static final int NUM_OF_COLORS;
    private static final int NUM_OF_ROWS;
    
    public ColorPalette(final ColorPicker colorPicker) {
        this.customColorLink = new Hyperlink(Properties.getColorPickerString("customColorLink"));
        this.customColorDialog = null;
        this.standardColorGrid = new GridPane();
        this.customColorGrid = new GridPane();
        this.separator = new Separator();
        this.customColorLabel = new Label(Properties.getColorPickerString("customColorLabel"));
        this.contextMenu = null;
        this.mouseDragColor = null;
        this.dragDetected = false;
        this.customColorNumber = 0;
        this.customColorRows = 0;
        this.customColorLastRowLength = 0;
        this.hoverSquare = new ColorSquare();
        this.getStyleClass().add("color-palette-region");
        this.colorPicker = colorPicker;
        this.colorPickerGrid = new ColorPickerGrid();
        this.colorPickerGrid.getChildren().get(0).requestFocus();
        this.customColorLabel.setAlignment(Pos.CENTER_LEFT);
        this.customColorLink.setPrefWidth(this.colorPickerGrid.prefWidth(-1.0));
        this.customColorLink.setAlignment(Pos.CENTER);
        this.customColorLink.setFocusTraversable(true);
        this.customColorLink.setVisited(true);
        this.customColorLink.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(final ActionEvent p0) {
                // 
                // This method could not be decompiled.
                // 
                // Original Bytecode:
                // 
                //     1: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //     4: getfield        javafx/scene/control/skin/ColorPalette.customColorDialog:Lcom/sun/javafx/scene/control/CustomColorDialog;
                //     7: ifnonnull       93
                //    10: aload_0        
                //    11: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //    14: new             Lcom/sun/javafx/scene/control/CustomColorDialog;
                //    17: dup            
                //    18: aload_0        
                //    19: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //    22: invokestatic    javafx/scene/control/skin/ColorPalette.access$000:(Ljavafx/scene/control/skin/ColorPalette;)Ljavafx/scene/control/PopupControl;
                //    25: invokespecial   com/sun/javafx/scene/control/CustomColorDialog.<init>:(Ljavafx/stage/Window;)V
                //    28: putfield        javafx/scene/control/skin/ColorPalette.customColorDialog:Lcom/sun/javafx/scene/control/CustomColorDialog;
                //    31: aload_0        
                //    32: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //    35: getfield        javafx/scene/control/skin/ColorPalette.customColorDialog:Lcom/sun/javafx/scene/control/CustomColorDialog;
                //    38: invokevirtual   com/sun/javafx/scene/control/CustomColorDialog.customColorProperty:()Ljavafx/beans/property/ObjectProperty;
                //    41: aload_0        
                //    42: aload_0        
                //    43: getfield        javafx/scene/control/skin/ColorPalette$1.val$colorPicker:Ljavafx/scene/control/ColorPicker;
                //    46: invokedynamic   BootstrapMethod #0, changed:(Ljavafx/scene/control/skin/ColorPalette$1;Ljavafx/scene/control/ColorPicker;)Ljavafx/beans/value/ChangeListener;
                //    51: invokevirtual   javafx/beans/property/ObjectProperty.addListener:(Ljavafx/beans/value/ChangeListener;)V
                //    54: aload_0        
                //    55: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //    58: getfield        javafx/scene/control/skin/ColorPalette.customColorDialog:Lcom/sun/javafx/scene/control/CustomColorDialog;
                //    61: aload_0        
                //    62: aload_0        
                //    63: getfield        javafx/scene/control/skin/ColorPalette$1.val$colorPicker:Ljavafx/scene/control/ColorPicker;
                //    66: invokedynamic   BootstrapMethod #1, run:(Ljavafx/scene/control/skin/ColorPalette$1;Ljavafx/scene/control/ColorPicker;)Ljava/lang/Runnable;
                //    71: invokevirtual   com/sun/javafx/scene/control/CustomColorDialog.setOnSave:(Ljava/lang/Runnable;)V
                //    74: aload_0        
                //    75: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //    78: getfield        javafx/scene/control/skin/ColorPalette.customColorDialog:Lcom/sun/javafx/scene/control/CustomColorDialog;
                //    81: aload_0        
                //    82: getfield        javafx/scene/control/skin/ColorPalette$1.val$colorPicker:Ljavafx/scene/control/ColorPicker;
                //    85: invokedynamic   BootstrapMethod #2, run:(Ljavafx/scene/control/ColorPicker;)Ljava/lang/Runnable;
                //    90: invokevirtual   com/sun/javafx/scene/control/CustomColorDialog.setOnUse:(Ljava/lang/Runnable;)V
                //    93: aload_0        
                //    94: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //    97: getfield        javafx/scene/control/skin/ColorPalette.customColorDialog:Lcom/sun/javafx/scene/control/CustomColorDialog;
                //   100: aload_0        
                //   101: getfield        javafx/scene/control/skin/ColorPalette$1.val$colorPicker:Ljavafx/scene/control/ColorPicker;
                //   104: invokevirtual   javafx/scene/control/ColorPicker.valueProperty:()Ljavafx/beans/property/ObjectProperty;
                //   107: invokevirtual   javafx/beans/property/ObjectProperty.get:()Ljava/lang/Object;
                //   110: checkcast       Ljavafx/scene/paint/Color;
                //   113: invokevirtual   com/sun/javafx/scene/control/CustomColorDialog.setCurrentColor:(Ljavafx/scene/paint/Color;)V
                //   116: aload_0        
                //   117: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //   120: invokestatic    javafx/scene/control/skin/ColorPalette.access$000:(Ljavafx/scene/control/skin/ColorPalette;)Ljavafx/scene/control/PopupControl;
                //   123: ifnull          137
                //   126: aload_0        
                //   127: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //   130: invokestatic    javafx/scene/control/skin/ColorPalette.access$000:(Ljavafx/scene/control/skin/ColorPalette;)Ljavafx/scene/control/PopupControl;
                //   133: iconst_0       
                //   134: invokevirtual   javafx/scene/control/PopupControl.setAutoHide:(Z)V
                //   137: aload_0        
                //   138: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //   141: getfield        javafx/scene/control/skin/ColorPalette.customColorDialog:Lcom/sun/javafx/scene/control/CustomColorDialog;
                //   144: invokevirtual   com/sun/javafx/scene/control/CustomColorDialog.show:()V
                //   147: aload_0        
                //   148: getfield        javafx/scene/control/skin/ColorPalette$1.this$0:Ljavafx/scene/control/skin/ColorPalette;
                //   151: getfield        javafx/scene/control/skin/ColorPalette.customColorDialog:Lcom/sun/javafx/scene/control/CustomColorDialog;
                //   154: aload_0        
                //   155: invokedynamic   BootstrapMethod #3, handle:(Ljavafx/scene/control/skin/ColorPalette$1;)Ljavafx/event/EventHandler;
                //   160: invokevirtual   com/sun/javafx/scene/control/CustomColorDialog.setOnHidden:(Ljavafx/event/EventHandler;)V
                //   163: return         
                //    StackMapTable: 00 02 FB 00 5D 2B
                // 
                // The error that occurred was:
                // 
                // java.lang.IllegalStateException: Could not infer any expression.
                //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
                //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
                //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
                //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformCall(AstMethodBodyBuilder.java:1164)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:1009)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:294)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
        });
        this.initNavigation();
        this.buildStandardColors();
        this.standardColorGrid.getStyleClass().add("color-picker-grid");
        this.standardColorGrid.setVisible(true);
        this.customColorGrid.getStyleClass().add("color-picker-grid");
        this.customColorGrid.setVisible(false);
        this.buildCustomColors();
        colorPicker.getCustomColors().addListener(new ListChangeListener<Color>() {
            @Override
            public void onChanged(final Change<? extends Color> change) {
                ColorPalette.this.buildCustomColors();
            }
        });
        final VBox vBox = new VBox();
        vBox.getStyleClass().add("color-palette");
        vBox.getChildren().addAll(this.standardColorGrid, this.colorPickerGrid, this.customColorLabel, this.customColorGrid, this.separator, this.customColorLink);
        this.hoverSquare.setMouseTransparent(true);
        this.hoverSquare.getStyleClass().addAll("hover-square");
        this.setFocusedSquare(null);
        this.getChildren().addAll(vBox, this.hoverSquare);
    }
    
    private void setFocusedSquare(final ColorSquare focusedSquare) {
        if (focusedSquare == this.focusedSquare) {
            return;
        }
        this.focusedSquare = focusedSquare;
        this.hoverSquare.setVisible(this.focusedSquare != null);
        if (this.focusedSquare == null) {
            return;
        }
        if (!this.focusedSquare.isFocused()) {
            this.focusedSquare.requestFocus();
        }
        this.hoverSquare.rectangle.setFill(this.focusedSquare.rectangle.getFill());
        final Bounds localToScene = focusedSquare.localToScene(focusedSquare.getLayoutBounds());
        double n = localToScene.getMinX();
        final double minY = localToScene.getMinY();
        final double n2 = (this.hoverSquare.getScaleX() == 1.0) ? 0.0 : (this.hoverSquare.getWidth() / 4.0);
        double n3;
        if (this.colorPicker.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) {
            n = this.focusedSquare.getLayoutX();
            n3 = -this.focusedSquare.getWidth() + n2;
        }
        else {
            n3 = this.focusedSquare.getWidth() / 2.0 + n2;
        }
        this.hoverSquare.setLayoutX(this.snapPositionX(n) - n3);
        this.hoverSquare.setLayoutY(this.snapPositionY(minY) - this.focusedSquare.getHeight() / 2.0 + ((this.hoverSquare.getScaleY() == 1.0) ? 0.0 : (this.focusedSquare.getHeight() / 4.0)));
    }
    
    private void buildStandardColors() {
        final Color[] array = { Color.AQUA, Color.TEAL, Color.BLUE, Color.NAVY, Color.FUCHSIA, Color.PURPLE, Color.RED, Color.MAROON, Color.YELLOW, Color.OLIVE, Color.GREEN, Color.LIME };
        this.standardColorGrid.getChildren().clear();
        for (int i = 0; i < 12; ++i) {
            this.standardColorGrid.add(new ColorSquare(array[i], i, ColorType.STANDARD), i, 0);
        }
    }
    
    private void buildCustomColors() {
        final ObservableList<Color> customColors = this.colorPicker.getCustomColors();
        this.customColorNumber = customColors.size();
        this.customColorGrid.getChildren().clear();
        if (customColors.isEmpty()) {
            this.customColorLabel.setVisible(false);
            this.customColorLabel.setManaged(false);
            this.customColorGrid.setVisible(false);
            this.customColorGrid.setManaged(false);
            return;
        }
        this.customColorLabel.setVisible(true);
        this.customColorLabel.setManaged(true);
        this.customColorGrid.setVisible(true);
        this.customColorGrid.setManaged(true);
        if (this.contextMenu == null) {
            final MenuItem menuItem = new MenuItem(Properties.getColorPickerString("removeColor"));
            menuItem.setOnAction(p1 -> {
                customColors.remove(((ColorSquare)this.contextMenu.getOwnerNode()).rectangle.getFill());
                this.buildCustomColors();
                return;
            });
            this.contextMenu = new ContextMenu(new MenuItem[] { menuItem });
        }
        int n = 0;
        int n2 = 0;
        final int n3 = customColors.size() % 12;
        final int n4 = (n3 == 0) ? 0 : (12 - n3);
        this.customColorLastRowLength = ((n3 == 0) ? 12 : n3);
        for (int i = 0; i < customColors.size(); ++i) {
            final ColorSquare colorSquare = new ColorSquare(customColors.get(i), i, ColorType.CUSTOM);
            final List list;
            final ColorSquare colorSquare2;
            colorSquare.addEventHandler(KeyEvent.KEY_PRESSED, keyEvent -> {
                if (keyEvent.getCode() == KeyCode.DELETE) {
                    list.remove(colorSquare2.rectangle.getFill());
                    this.buildCustomColors();
                }
                return;
            });
            this.customColorGrid.add(colorSquare, n, n2);
            if (++n == 12) {
                n = 0;
                ++n2;
            }
        }
        for (int j = 0; j < n4; ++j) {
            final ColorSquare colorSquare3 = new ColorSquare();
            colorSquare3.setDisable(true);
            this.customColorGrid.add(colorSquare3, n, n2);
            ++n;
        }
        this.customColorRows = n2 + 1;
        this.requestLayout();
    }
    
    private void initNavigation() {
        this.setOnKeyPressed(keyEvent -> {
            switch (keyEvent.getCode()) {
                case SPACE:
                case ENTER: {
                    this.processSelectKey(keyEvent);
                    keyEvent.consume();
                    break;
                }
            }
            return;
        });
        ParentHelper.setTraversalEngine(this, new ParentTraversalEngine(this, new Algorithm() {
            @Override
            public Node select(final Node node, final Direction direction, final TraversalContext traversalContext) {
                final Node selectInSubtree = traversalContext.selectInSubtree(traversalContext.getRoot(), node, direction);
                switch (direction) {
                    case NEXT:
                    case NEXT_IN_LINE:
                    case PREVIOUS: {
                        return selectInSubtree;
                    }
                    case LEFT:
                    case RIGHT:
                    case UP:
                    case DOWN: {
                        if (node instanceof ColorSquare) {
                            final Node processArrow = this.processArrow((ColorSquare)node, direction);
                            return (processArrow != null) ? processArrow : selectInSubtree;
                        }
                        return selectInSubtree;
                    }
                    default: {
                        return null;
                    }
                }
            }
            
            private Node processArrow(final ColorSquare colorSquare, Direction directionForNodeOrientation) {
                int n;
                int index;
                if (colorSquare.colorType == ColorType.STANDARD) {
                    n = 0;
                    index = colorSquare.index;
                }
                else {
                    n = colorSquare.index / 12;
                    index = colorSquare.index % 12;
                }
                directionForNodeOrientation = directionForNodeOrientation.getDirectionForNodeOrientation(ColorPalette.this.colorPicker.getEffectiveNodeOrientation());
                if (!this.isAtBorder(directionForNodeOrientation, n, index, colorSquare.colorType == ColorType.CUSTOM)) {
                    return null;
                }
                int n2 = n;
                int n3 = index;
                boolean b = colorSquare.colorType == ColorType.CUSTOM;
                boolean b2 = colorSquare.colorType == ColorType.STANDARD;
                switch (directionForNodeOrientation) {
                    case LEFT:
                    case RIGHT: {
                        if (colorSquare.colorType == ColorType.STANDARD) {
                            n2 = 0;
                            n3 = ((directionForNodeOrientation == Direction.LEFT) ? 11 : 0);
                            break;
                        }
                        if (colorSquare.colorType == ColorType.CUSTOM) {
                            n2 = Math.floorMod((directionForNodeOrientation == Direction.LEFT) ? (n - 1) : (n + 1), ColorPalette.this.customColorRows);
                            n3 = ((directionForNodeOrientation == Direction.LEFT) ? ((n2 == ColorPalette.this.customColorRows - 1) ? (ColorPalette.this.customColorLastRowLength - 1) : 11) : 0);
                            break;
                        }
                        n2 = Math.floorMod((directionForNodeOrientation == Direction.LEFT) ? (n - 1) : (n + 1), ColorPalette.NUM_OF_ROWS);
                        n3 = ((directionForNodeOrientation == Direction.LEFT) ? 11 : 0);
                        break;
                    }
                    case UP: {
                        if (colorSquare.colorType == ColorType.NORMAL && n == 0) {
                            b2 = true;
                            break;
                        }
                        break;
                    }
                    case DOWN: {
                        if (ColorPalette.this.customColorNumber > 0) {
                            b = true;
                            n2 = 0;
                            n3 = ((ColorPalette.this.customColorRows > 1) ? index : Math.min(ColorPalette.this.customColorLastRowLength - 1, index));
                            break;
                        }
                        return null;
                    }
                }
                if (b) {
                    return (Node)ColorPalette.this.customColorGrid.getChildren().get(n2 * 12 + n3);
                }
                if (b2) {
                    return (Node)ColorPalette.this.standardColorGrid.getChildren().get(n3);
                }
                return (Node)ColorPalette.this.colorPickerGrid.getChildren().get(n2 * 12 + n3);
            }
            
            private boolean isAtBorder(final Direction direction, final int n, final int n2, final boolean b) {
                switch (direction) {
                    case LEFT: {
                        return n2 == 0;
                    }
                    case RIGHT: {
                        return (b && n == ColorPalette.this.customColorRows - 1) ? (n2 == ColorPalette.this.customColorLastRowLength - 1) : (n2 == 11);
                    }
                    case UP: {
                        return !b && n == 0;
                    }
                    case DOWN: {
                        return !b && n == ColorPalette.NUM_OF_ROWS - 1;
                    }
                    default: {
                        return false;
                    }
                }
            }
            
            @Override
            public Node selectFirst(final TraversalContext traversalContext) {
                return ColorPalette.this.standardColorGrid.getChildren().get(0);
            }
            
            @Override
            public Node selectLast(final TraversalContext traversalContext) {
                return ColorPalette.this.customColorLink;
            }
        }));
    }
    
    private void processSelectKey(final KeyEvent keyEvent) {
        if (this.focusedSquare != null) {
            this.focusedSquare.selectColor(keyEvent);
        }
    }
    
    public void setPopupControl(final PopupControl popupControl) {
        this.popupControl = popupControl;
    }
    
    public ColorPickerGrid getColorGrid() {
        return this.colorPickerGrid;
    }
    
    public boolean isCustomColorDialogShowing() {
        return this.customColorDialog != null && this.customColorDialog.isVisible();
    }
    
    public void updateSelection(final Color color) {
        this.setFocusedSquare(null);
        final Iterator<GridPane> iterator = List.of(this.standardColorGrid, this.colorPickerGrid, this.customColorGrid).iterator();
        while (iterator.hasNext()) {
            final ColorSquare colorSquare = this.findColorSquare(iterator.next(), color);
            if (colorSquare != null) {
                this.setFocusedSquare(colorSquare);
            }
        }
    }
    
    private ColorSquare findColorSquare(final GridPane gridPane, final Color obj) {
        for (final ColorSquare colorSquare : gridPane.getChildren()) {
            if (colorSquare.rectangle.getFill().equals(obj)) {
                return colorSquare;
            }
        }
        return null;
    }
    
    static {
        ColorPalette.RAW_VALUES = new double[] { 255.0, 255.0, 255.0, 242.0, 242.0, 242.0, 230.0, 230.0, 230.0, 204.0, 204.0, 204.0, 179.0, 179.0, 179.0, 153.0, 153.0, 153.0, 128.0, 128.0, 128.0, 102.0, 102.0, 102.0, 77.0, 77.0, 77.0, 51.0, 51.0, 51.0, 26.0, 26.0, 26.0, 0.0, 0.0, 0.0, 0.0, 51.0, 51.0, 0.0, 26.0, 128.0, 26.0, 0.0, 104.0, 51.0, 0.0, 51.0, 77.0, 0.0, 26.0, 153.0, 0.0, 0.0, 153.0, 51.0, 0.0, 153.0, 77.0, 0.0, 153.0, 102.0, 0.0, 153.0, 153.0, 0.0, 102.0, 102.0, 0.0, 0.0, 51.0, 0.0, 26.0, 77.0, 77.0, 26.0, 51.0, 153.0, 51.0, 26.0, 128.0, 77.0, 26.0, 77.0, 102.0, 26.0, 51.0, 179.0, 26.0, 26.0, 179.0, 77.0, 26.0, 179.0, 102.0, 26.0, 179.0, 128.0, 26.0, 179.0, 179.0, 26.0, 128.0, 128.0, 26.0, 26.0, 77.0, 26.0, 51.0, 102.0, 102.0, 51.0, 77.0, 179.0, 77.0, 51.0, 153.0, 102.0, 51.0, 102.0, 128.0, 51.0, 77.0, 204.0, 51.0, 51.0, 204.0, 102.0, 51.0, 204.0, 128.0, 51.0, 204.0, 153.0, 51.0, 204.0, 204.0, 51.0, 153.0, 153.0, 51.0, 51.0, 102.0, 51.0, 77.0, 128.0, 128.0, 77.0, 102.0, 204.0, 102.0, 77.0, 179.0, 128.0, 77.0, 128.0, 153.0, 77.0, 102.0, 230.0, 77.0, 77.0, 230.0, 128.0, 77.0, 230.0, 153.0, 77.0, 230.0, 179.0, 77.0, 230.0, 230.0, 77.0, 179.0, 179.0, 77.0, 77.0, 128.0, 77.0, 102.0, 153.0, 153.0, 102.0, 128.0, 230.0, 128.0, 102.0, 204.0, 153.0, 102.0, 153.0, 179.0, 102.0, 128.0, 255.0, 102.0, 102.0, 255.0, 153.0, 102.0, 255.0, 179.0, 102.0, 255.0, 204.0, 102.0, 255.0, 255.0, 77.0, 204.0, 204.0, 102.0, 102.0, 153.0, 102.0, 128.0, 179.0, 179.0, 128.0, 153.0, 255.0, 153.0, 128.0, 230.0, 179.0, 128.0, 179.0, 204.0, 128.0, 153.0, 255.0, 128.0, 128.0, 255.0, 153.0, 128.0, 255.0, 204.0, 128.0, 255.0, 230.0, 102.0, 255.0, 255.0, 102.0, 230.0, 230.0, 128.0, 128.0, 179.0, 128.0, 153.0, 204.0, 204.0, 153.0, 179.0, 255.0, 179.0, 153.0, 255.0, 204.0, 153.0, 204.0, 230.0, 153.0, 179.0, 255.0, 153.0, 153.0, 255.0, 179.0, 128.0, 255.0, 204.0, 153.0, 255.0, 230.0, 128.0, 255.0, 255.0, 128.0, 230.0, 230.0, 153.0, 153.0, 204.0, 153.0, 179.0, 230.0, 230.0, 179.0, 204.0, 255.0, 204.0, 179.0, 255.0, 230.0, 179.0, 230.0, 230.0, 179.0, 204.0, 255.0, 179.0, 179.0, 255.0, 179.0, 153.0, 255.0, 230.0, 179.0, 255.0, 230.0, 153.0, 255.0, 255.0, 153.0, 230.0, 230.0, 179.0, 179.0, 230.0, 179.0, 204.0, 255.0, 255.0, 204.0, 230.0, 255.0, 230.0, 204.0, 255.0, 255.0, 204.0, 255.0, 255.0, 204.0, 230.0, 255.0, 204.0, 204.0, 255.0, 204.0, 179.0, 255.0, 230.0, 204.0, 255.0, 255.0, 179.0, 255.0, 255.0, 204.0, 230.0, 230.0, 204.0, 204.0, 255.0, 204.0 };
        NUM_OF_COLORS = ColorPalette.RAW_VALUES.length / 3;
        NUM_OF_ROWS = ColorPalette.NUM_OF_COLORS / 12;
    }
    
    enum ColorType
    {
        NORMAL, 
        STANDARD, 
        CUSTOM;
    }
    
    class ColorSquare extends StackPane
    {
        Rectangle rectangle;
        int index;
        boolean isEmpty;
        ColorType colorType;
        
        public ColorSquare(final ColorPalette colorPalette) {
            this(colorPalette, null, -1, ColorType.NORMAL);
        }
        
        public ColorSquare(final ColorPalette colorPalette, final Color color, final int n) {
            this(colorPalette, color, n, ColorType.NORMAL);
        }
        
        public ColorSquare(final Color fill, final int index, final ColorType colorType) {
            this.colorType = ColorType.NORMAL;
            this.getStyleClass().add("color-square");
            if (fill != null) {
                this.setFocusTraversable(true);
                this.focusedProperty().addListener((p0, p1, b) -> ColorPalette.this.setFocusedSquare(((boolean)b) ? this : null));
                this.addEventHandler(MouseEvent.MOUSE_ENTERED, p0 -> ColorPalette.this.setFocusedSquare(this));
                this.addEventHandler(MouseEvent.MOUSE_EXITED, p0 -> ColorPalette.this.setFocusedSquare(null));
                Color value;
                this.addEventHandler(MouseEvent.MOUSE_RELEASED, mouseEvent -> {
                    if (!ColorPalette.this.dragDetected && mouseEvent.getButton() == MouseButton.PRIMARY && mouseEvent.getClickCount() == 1) {
                        if (!this.isEmpty) {
                            value = (Color)this.rectangle.getFill();
                            ColorPalette.this.colorPicker.setValue(value);
                            ColorPalette.this.colorPicker.fireEvent(new ActionEvent());
                            ColorPalette.this.updateSelection(value);
                            mouseEvent.consume();
                        }
                        ColorPalette.this.colorPicker.hide();
                    }
                    else if ((mouseEvent.getButton() == MouseButton.SECONDARY || mouseEvent.getButton() == MouseButton.MIDDLE) && this.colorType == ColorType.CUSTOM && ColorPalette.this.contextMenu != null) {
                        if (!ColorPalette.this.contextMenu.isShowing()) {
                            ColorPalette.this.contextMenu.show(this, Side.RIGHT, 0.0, 0.0);
                            Utils.addMnemonics(ColorPalette.this.contextMenu, this.getScene(), NodeHelper.isShowMnemonics(ColorPalette.this.colorPicker));
                        }
                        else {
                            ColorPalette.this.contextMenu.hide();
                            Utils.removeMnemonics(ColorPalette.this.contextMenu, this.getScene());
                        }
                    }
                    return;
                });
            }
            this.index = index;
            this.colorType = colorType;
            this.rectangle = new Rectangle(15.0, 15.0);
            if (fill == null) {
                this.rectangle.setFill(Color.WHITE);
                this.isEmpty = true;
            }
            else {
                this.rectangle.setFill(fill);
            }
            this.rectangle.setStrokeType(StrokeType.INSIDE);
            final String tooltipString = ColorPickerSkin.tooltipString(fill);
            Tooltip.install(this, new Tooltip((tooltipString == null) ? "" : tooltipString));
            this.rectangle.getStyleClass().add("color-rect");
            this.getChildren().add(this.rectangle);
        }
        
        public void selectColor(final KeyEvent keyEvent) {
            if (this.rectangle.getFill() != null) {
                if (this.rectangle.getFill() instanceof Color) {
                    ColorPalette.this.colorPicker.setValue((Color)this.rectangle.getFill());
                    ColorPalette.this.colorPicker.fireEvent(new ActionEvent());
                }
                keyEvent.consume();
            }
            ColorPalette.this.colorPicker.hide();
        }
    }
    
    class ColorPickerGrid extends GridPane
    {
        private final List<ColorSquare> squares;
        
        public ColorPickerGrid() {
            this.getStyleClass().add("color-picker-grid");
            this.setId("ColorCustomizerColorGrid");
            int n = 0;
            int n2 = 0;
            this.squares = (List<ColorSquare>)FXCollections.observableArrayList();
            final int n3 = ColorPalette.RAW_VALUES.length / 3;
            final Color[] array = new Color[n3];
            for (int i = 0; i < n3; ++i) {
                array[i] = new Color(ColorPalette.RAW_VALUES[i * 3] / 255.0, ColorPalette.RAW_VALUES[i * 3 + 1] / 255.0, ColorPalette.RAW_VALUES[i * 3 + 2] / 255.0, 1.0);
                this.squares.add(new ColorSquare(array[i], i));
            }
            final Iterator<ColorSquare> iterator = this.squares.iterator();
            while (iterator.hasNext()) {
                this.add(iterator.next(), n, n2);
                if (++n == 12) {
                    n = 0;
                    ++n2;
                }
            }
            this.setOnMouseDragged(mouseEvent -> {
                if (!ColorPalette.this.dragDetected) {
                    ColorPalette.this.dragDetected = true;
                    ColorPalette.this.mouseDragColor = ColorPalette.this.colorPicker.getValue();
                }
                ColorPalette.this.colorPicker.setValue((Color)this.squares.get(com.sun.javafx.util.Utils.clamp(0, (int)mouseEvent.getX() / 16, 11) + com.sun.javafx.util.Utils.clamp(0, (int)mouseEvent.getY() / 16, ColorPalette.NUM_OF_ROWS - 1) * 12).rectangle.getFill());
                ColorPalette.this.updateSelection(ColorPalette.this.colorPicker.getValue());
                return;
            });
            this.addEventHandler(MouseEvent.MOUSE_RELEASED, mouseEvent2 -> {
                if (ColorPalette.this.colorPickerGrid.getBoundsInLocal().contains(mouseEvent2.getX(), mouseEvent2.getY())) {
                    ColorPalette.this.updateSelection(ColorPalette.this.colorPicker.getValue());
                    ColorPalette.this.colorPicker.fireEvent(new ActionEvent());
                    ColorPalette.this.colorPicker.hide();
                }
                else if (ColorPalette.this.mouseDragColor != null) {
                    ColorPalette.this.colorPicker.setValue(ColorPalette.this.mouseDragColor);
                    ColorPalette.this.updateSelection(ColorPalette.this.mouseDragColor);
                }
                ColorPalette.this.dragDetected = false;
            });
        }
        
        public List<ColorSquare> getSquares() {
            return this.squares;
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            return 192.0;
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            return 16 * ColorPalette.NUM_OF_ROWS;
        }
    }
}
