// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.text.Text;
import com.sun.javafx.scene.control.behavior.DateCellBehavior;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.DateCell;

public class DateCellSkin extends CellSkinBase<DateCell>
{
    private final BehaviorBase<DateCell> behavior;
    
    public DateCellSkin(final DateCell dateCell) {
        super(dateCell);
        this.behavior = new DateCellBehavior(dateCell);
        dateCell.setMaxWidth(Double.MAX_VALUE);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void updateChildren() {
        super.updateChildren();
        final Text text = this.getSkinnable().getProperties().get("DateCell.secondaryText");
        if (text != null) {
            text.setManaged(false);
            this.getChildren().add(text);
        }
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        super.layoutChildren(n, n2, n3, n4);
        final Text text = this.getSkinnable().getProperties().get("DateCell.secondaryText");
        if (text != null) {
            text.relocate(this.snapPositionX(n + n3 - this.rightLabelPadding() - text.getLayoutBounds().getWidth()), this.snapPositionY(n2 + n4 - this.bottomLabelPadding() - text.getLayoutBounds().getHeight()));
        }
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.snapSizeX(Math.max(super.computePrefWidth(n, n2, n3, n4, n5), this.cellSize()));
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.snapSizeY(Math.max(super.computePrefHeight(n, n2, n3, n4, n5), this.cellSize()));
    }
    
    private double cellSize() {
        double cellSize = this.getCellSize();
        if (this.getSkinnable().getProperties().get("DateCell.secondaryText") != null && cellSize == 24.0) {
            cellSize = 36.0;
        }
        return cellSize;
    }
}
