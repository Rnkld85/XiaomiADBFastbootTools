// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.scene.control.SkinBase;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.Styleable;
import java.util.List;
import javafx.css.CssMetaData;
import javafx.css.StyleOrigin;
import javafx.css.StyleableDoubleProperty;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.DoubleProperty;
import javafx.scene.control.Cell;

public class CellSkinBase<C extends Cell> extends LabeledSkinBase<C>
{
    private DoubleProperty cellSize;
    static final double DEFAULT_CELL_SIZE = 24.0;
    
    public CellSkinBase(final C c) {
        super(c);
        this.consumeMouseEvents(false);
    }
    
    public final double getCellSize() {
        return (this.cellSize == null) ? 24.0 : this.cellSize.get();
    }
    
    public final ReadOnlyDoubleProperty cellSizeProperty() {
        return this.cellSizePropertyImpl();
    }
    
    private DoubleProperty cellSizePropertyImpl() {
        if (this.cellSize == null) {
            this.cellSize = new StyleableDoubleProperty(24.0) {
                @Override
                public void applyStyle(final StyleOrigin styleOrigin, final Number n) {
                    final double n2 = (n == null) ? 24.0 : n.doubleValue();
                    super.applyStyle(styleOrigin, (n2 <= 0.0) ? 24.0 : n2);
                }
                
                @Override
                public void set(final double n) {
                    super.set(n);
                    CellSkinBase.this.getSkinnable().requestLayout();
                }
                
                @Override
                public Object getBean() {
                    return CellSkinBase.this;
                }
                
                @Override
                public String getName() {
                    return "cellSize";
                }
                
                @Override
                public CssMetaData<Cell<?>, Number> getCssMetaData() {
                    return StyleableProperties.CELL_SIZE;
                }
            };
        }
        return this.cellSize;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Cell<?>, Number> CELL_SIZE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            CELL_SIZE = new CssMetaData<Cell<?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)24.0) {
                @Override
                public boolean isSettable(final Cell<?> cell) {
                    final CellSkinBase cellSkinBase = (CellSkinBase)cell.getSkin();
                    return cellSkinBase.cellSize == null || !cellSkinBase.cellSize.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Cell<?> cell) {
                    return (StyleableProperty<Number>)((CellSkinBase)cell.getSkin()).cellSizePropertyImpl();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(SkinBase.getClassCssMetaData());
            list.add(StyleableProperties.CELL_SIZE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
