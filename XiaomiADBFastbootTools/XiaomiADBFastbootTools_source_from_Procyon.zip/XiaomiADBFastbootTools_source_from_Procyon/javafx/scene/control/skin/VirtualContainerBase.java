// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.control.ScrollToEvent;
import javafx.scene.control.SkinBase;
import javafx.scene.control.IndexedCell;
import javafx.scene.control.Control;

public abstract class VirtualContainerBase<C extends Control, I extends IndexedCell> extends SkinBase<C>
{
    private boolean itemCountDirty;
    private final VirtualFlow<I> flow;
    
    public VirtualContainerBase(final C c) {
        super(c);
        this.flow = this.createVirtualFlow();
        c.addEventHandler(ScrollToEvent.scrollToTopIndex(), scrollToEvent -> {
            if (this.itemCountDirty) {
                this.updateItemCount();
                this.itemCountDirty = false;
            }
            this.flow.scrollToTop(scrollToEvent.getScrollTarget());
        });
    }
    
    protected abstract int getItemCount();
    
    protected abstract void updateItemCount();
    
    protected VirtualFlow<I> createVirtualFlow() {
        return new VirtualFlow<I>();
    }
    
    protected final VirtualFlow<I> getVirtualFlow() {
        return this.flow;
    }
    
    protected final void markItemCountDirty() {
        this.itemCountDirty = true;
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        this.checkState();
    }
    
    double getMaxCellWidth(final int n) {
        return this.snappedLeftInset() + this.flow.getMaxCellWidth(n) + this.snappedRightInset();
    }
    
    double getVirtualFlowPreferredHeight(final int n) {
        double n2 = 1.0;
        for (int n3 = 0; n3 < n && n3 < this.getItemCount(); ++n3) {
            n2 += this.flow.getCellLength(n3);
        }
        return n2 + this.snappedTopInset() + this.snappedBottomInset();
    }
    
    void checkState() {
        if (this.itemCountDirty) {
            this.updateItemCount();
            this.itemCountDirty = false;
        }
    }
    
    void requestRebuildCells() {
        this.flow.rebuildCells();
    }
}
