// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.Node;
import javafx.geometry.Orientation;
import javafx.beans.value.ObservableValue;
import javafx.scene.layout.Region;
import javafx.scene.control.Separator;
import javafx.scene.control.SkinBase;

public class SeparatorSkin extends SkinBase<Separator>
{
    private static final double DEFAULT_LENGTH = 10.0;
    private final Region line;
    
    public SeparatorSkin(final Separator separator) {
        super(separator);
        this.line = new Region();
        this.line.getStyleClass().setAll("line");
        this.getChildren().add(this.line);
        this.registerChangeListener(separator.orientationProperty(), p0 -> this.getSkinnable().requestLayout());
        this.registerChangeListener(separator.halignmentProperty(), p0 -> this.getSkinnable().requestLayout());
        this.registerChangeListener(separator.valignmentProperty(), p0 -> this.getSkinnable().requestLayout());
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        final Separator separator = this.getSkinnable();
        if (separator.getOrientation() == Orientation.HORIZONTAL) {
            this.line.resize(n3, this.line.prefHeight(-1.0));
        }
        else {
            this.line.resize(this.line.prefWidth(-1.0), n4);
        }
        this.positionInArea(this.line, n, n2, n3, n4, 0.0, separator.getHalignment(), separator.getValignment());
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computePrefWidth(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computePrefHeight(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return ((this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? this.line.prefWidth(-1.0) : 10.0) + n5 + n3;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return ((this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? 10.0 : this.line.prefHeight(-1.0)) + n2 + n4;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final Separator separator = this.getSkinnable();
        return (separator.getOrientation() == Orientation.VERTICAL) ? separator.prefWidth(n) : Double.MAX_VALUE;
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        final Separator separator = this.getSkinnable();
        return (separator.getOrientation() == Orientation.VERTICAL) ? Double.MAX_VALUE : separator.prefHeight(n);
    }
}
