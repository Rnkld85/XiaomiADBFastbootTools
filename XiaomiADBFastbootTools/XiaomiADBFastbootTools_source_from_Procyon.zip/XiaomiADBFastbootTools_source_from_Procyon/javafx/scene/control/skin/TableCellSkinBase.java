// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.beans.Observable;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.control.TableColumnBase;
import javafx.scene.Node;
import javafx.beans.value.ObservableValue;
import javafx.scene.shape.Rectangle;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.InvalidationListener;
import javafx.scene.control.IndexedCell;

public abstract class TableCellSkinBase<S, T, C extends IndexedCell<T>> extends CellSkinBase<C>
{
    boolean isDeferToParentForPrefWidth;
    private InvalidationListener columnWidthListener;
    private WeakInvalidationListener weakColumnWidthListener;
    
    public TableCellSkinBase(final C c) {
        super(c);
        this.isDeferToParentForPrefWidth = false;
        this.columnWidthListener = (p0 -> this.getSkinnable().requestLayout());
        this.weakColumnWidthListener = new WeakInvalidationListener(this.columnWidthListener);
        final Rectangle clip = new Rectangle();
        clip.widthProperty().bind(c.widthProperty());
        clip.heightProperty().bind(c.heightProperty());
        this.getSkinnable().setClip(clip);
        final TableColumnBase<S, T> tableColumn = this.getTableColumn();
        if (tableColumn != null) {
            tableColumn.widthProperty().addListener(this.weakColumnWidthListener);
        }
        if (c.getProperties().containsKey("deferToParentPrefWidth")) {
            this.isDeferToParentForPrefWidth = true;
        }
    }
    
    public abstract ReadOnlyObjectProperty<? extends TableColumnBase<S, T>> tableColumnProperty();
    
    public final TableColumnBase<S, T> getTableColumn() {
        return this.tableColumnProperty().get();
    }
    
    @Override
    public void dispose() {
        final TableColumnBase<S, T> tableColumn = this.getTableColumn();
        if (tableColumn != null) {
            tableColumn.widthProperty().removeListener(this.weakColumnWidthListener);
        }
        super.dispose();
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        this.layoutLabelInArea(n, n2, n3, n4 - this.getSkinnable().getPadding().getBottom());
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.isDeferToParentForPrefWidth) {
            return super.computePrefWidth(n, n2, n3, n4, n5);
        }
        final TableColumnBase<S, T> tableColumn = this.getTableColumn();
        return (tableColumn == null) ? 0.0 : this.snapSizeX(tableColumn.getWidth());
    }
}
