// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.input.InputMethodEvent;
import javafx.beans.Observable;
import javafx.scene.input.KeyCode;
import javafx.geometry.Bounds;
import javafx.beans.InvalidationListener;
import javafx.scene.AccessibleAttribute;
import javafx.stage.WindowEvent;
import javafx.css.Styleable;
import javafx.scene.control.Skinnable;
import javafx.scene.control.Skin;
import javafx.scene.layout.Region;
import com.sun.javafx.util.Utils;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.geometry.Point2D;
import com.sun.javafx.scene.input.ExtendedInputMethodRequests;
import javafx.scene.input.InputMethodRequests;
import javafx.beans.value.ObservableValue;
import javafx.util.StringConverter;
import com.sun.javafx.scene.ParentHelper;
import javafx.scene.Parent;
import com.sun.javafx.scene.traversal.ParentTraversalEngine;
import com.sun.javafx.scene.traversal.TraversalContext;
import com.sun.javafx.scene.traversal.Direction;
import javafx.scene.Node;
import com.sun.javafx.scene.traversal.Algorithm;
import javafx.scene.input.KeyEvent;
import com.sun.javafx.scene.control.FakeFocusTextField;
import javafx.event.Event;
import javafx.event.EventTarget;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBoxBase;
import javafx.scene.control.PopupControl;

public abstract class ComboBoxPopupControl<T> extends ComboBoxBaseSkin<T>
{
    PopupControl popup;
    private boolean popupNeedsReconfiguring;
    private final ComboBoxBase<T> comboBoxBase;
    private TextField textField;
    private String initialTextFieldValue;
    private EventHandler<MouseEvent> textFieldMouseEventHandler;
    private EventHandler<DragEvent> textFieldDragEventHandler;
    
    public ComboBoxPopupControl(final ComboBoxBase<T> comboBoxBase) {
        super(comboBoxBase);
        this.popupNeedsReconfiguring = true;
        this.initialTextFieldValue = null;
        final ComboBoxBase obj;
        this.textFieldMouseEventHandler = (mouseEvent -> {
            obj = this.getSkinnable();
            if (!mouseEvent.getTarget().equals(obj)) {
                obj.fireEvent(mouseEvent.copyFor(obj, obj));
                mouseEvent.consume();
            }
            return;
        });
        final ComboBoxBase obj2;
        this.textFieldDragEventHandler = (dragEvent -> {
            obj2 = this.getSkinnable();
            if (!dragEvent.getTarget().equals(obj2)) {
                obj2.fireEvent(dragEvent.copyFor(obj2, obj2));
                dragEvent.consume();
            }
            return;
        });
        this.comboBoxBase = comboBoxBase;
        this.textField = ((this.getEditor() != null) ? this.getEditableInputNode() : null);
        if (this.textField != null) {
            this.getChildren().add(this.textField);
        }
        this.comboBoxBase.focusedProperty().addListener((p0, p1, b) -> {
            if (this.getEditor() != null) {
                ((FakeFocusTextField)this.textField).setFakeFocus(b);
            }
            return;
        });
        this.comboBoxBase.addEventFilter(KeyEvent.ANY, keyEvent -> {
            if (this.textField == null || this.getEditor() == null) {
                this.handleKeyEvent(keyEvent, false);
            }
            else if (!keyEvent.getTarget().equals(this.textField)) {
                switch (keyEvent.getCode()) {
                    case ESCAPE:
                    case F10: {
                        break;
                    }
                    case ENTER: {
                        this.handleKeyEvent(keyEvent, true);
                        break;
                    }
                    default: {
                        this.textField.fireEvent(keyEvent.copyFor(this.textField, this.textField));
                        keyEvent.consume();
                        break;
                    }
                }
            }
            return;
        });
        if (this.comboBoxBase.getOnInputMethodTextChanged() == null) {
            this.comboBoxBase.setOnInputMethodTextChanged(inputMethodEvent -> {
                if (this.textField != null && this.getEditor() != null && this.comboBoxBase.getScene().getFocusOwner() == this.comboBoxBase && this.textField.getOnInputMethodTextChanged() != null) {
                    this.textField.getOnInputMethodTextChanged().handle(inputMethodEvent);
                }
                return;
            });
        }
        ParentHelper.setTraversalEngine(this.comboBoxBase, new ParentTraversalEngine(this.comboBoxBase, new Algorithm() {
            @Override
            public Node select(final Node node, final Direction direction, final TraversalContext traversalContext) {
                return null;
            }
            
            @Override
            public Node selectFirst(final TraversalContext traversalContext) {
                return null;
            }
            
            @Override
            public Node selectLast(final TraversalContext traversalContext) {
                return null;
            }
        }));
        this.updateEditable();
    }
    
    protected abstract Node getPopupContent();
    
    protected abstract TextField getEditor();
    
    protected abstract StringConverter<T> getConverter();
    
    @Override
    public void show() {
        if (this.getSkinnable() == null) {
            throw new IllegalStateException("ComboBox is null");
        }
        if (this.getPopupContent() == null) {
            throw new IllegalStateException("Popup node is null");
        }
        if (this.getPopup().isShowing()) {
            return;
        }
        this.positionAndShowPopup();
    }
    
    @Override
    public void hide() {
        if (this.popup != null && this.popup.isShowing()) {
            this.popup.hide();
        }
    }
    
    PopupControl getPopup() {
        if (this.popup == null) {
            this.createPopup();
        }
        return this.popup;
    }
    
    TextField getEditableInputNode() {
        if (this.textField == null && this.getEditor() != null) {
            (this.textField = this.getEditor()).setFocusTraversable(false);
            this.textField.promptTextProperty().bind(this.comboBoxBase.promptTextProperty());
            this.textField.tooltipProperty().bind((ObservableValue<?>)this.comboBoxBase.tooltipProperty());
            this.textField.getProperties().put("TextInputControlBehavior.disableForwardToParent", true);
            this.initialTextFieldValue = this.textField.getText();
        }
        return this.textField;
    }
    
    void setTextFromTextFieldIntoComboBoxValue() {
        if (this.getEditor() != null) {
            final StringConverter<T> converter = this.getConverter();
            if (converter != null) {
                T value;
                final T obj = value = this.comboBoxBase.getValue();
                final String text = this.textField.getText();
                if (obj == null && (text == null || text.isEmpty())) {
                    value = null;
                }
                else {
                    try {
                        value = converter.fromString(text);
                    }
                    catch (Exception ex) {}
                }
                if ((value != null || obj != null) && (value == null || !value.equals(obj))) {
                    this.comboBoxBase.setValue(value);
                }
                this.updateDisplayNode();
            }
        }
    }
    
    void updateDisplayNode() {
        if (this.textField != null && this.getEditor() != null) {
            final T value = this.comboBoxBase.getValue();
            final StringConverter<T> converter = this.getConverter();
            if (this.initialTextFieldValue != null && !this.initialTextFieldValue.isEmpty()) {
                this.textField.setText(this.initialTextFieldValue);
                this.initialTextFieldValue = null;
            }
            else {
                final String string = converter.toString(value);
                if (value == null || string == null) {
                    this.textField.setText("");
                }
                else if (!string.equals(this.textField.getText())) {
                    this.textField.setText(string);
                }
            }
        }
    }
    
    void updateEditable() {
        final TextField editor = this.getEditor();
        if (this.getEditor() == null) {
            if (this.textField != null) {
                this.textField.removeEventFilter(MouseEvent.DRAG_DETECTED, this.textFieldMouseEventHandler);
                this.textField.removeEventFilter(DragEvent.ANY, this.textFieldDragEventHandler);
                this.comboBoxBase.setInputMethodRequests(null);
            }
        }
        else if (editor != null) {
            editor.addEventFilter(MouseEvent.DRAG_DETECTED, this.textFieldMouseEventHandler);
            editor.addEventFilter(DragEvent.ANY, this.textFieldDragEventHandler);
            this.comboBoxBase.setInputMethodRequests(new ExtendedInputMethodRequests() {
                @Override
                public Point2D getTextLocation(final int n) {
                    return editor.getInputMethodRequests().getTextLocation(n);
                }
                
                @Override
                public int getLocationOffset(final int n, final int n2) {
                    return editor.getInputMethodRequests().getLocationOffset(n, n2);
                }
                
                @Override
                public void cancelLatestCommittedText() {
                    editor.getInputMethodRequests().cancelLatestCommittedText();
                }
                
                @Override
                public String getSelectedText() {
                    return editor.getInputMethodRequests().getSelectedText();
                }
                
                @Override
                public int getInsertPositionOffset() {
                    return ((ExtendedInputMethodRequests)editor.getInputMethodRequests()).getInsertPositionOffset();
                }
                
                @Override
                public String getCommittedText(final int n, final int n2) {
                    return ((ExtendedInputMethodRequests)editor.getInputMethodRequests()).getCommittedText(n, n2);
                }
                
                @Override
                public int getCommittedTextLength() {
                    return ((ExtendedInputMethodRequests)editor.getInputMethodRequests()).getCommittedTextLength();
                }
            });
        }
        this.textField = editor;
    }
    
    private Point2D getPrefPopupPosition() {
        return Utils.pointRelativeTo(this.getSkinnable(), this.getPopupContent(), HPos.CENTER, VPos.BOTTOM, 0.0, 0.0, true);
    }
    
    private void positionAndShowPopup() {
        final ComboBoxBase comboBoxBase = this.getSkinnable();
        if (comboBoxBase.getScene() == null) {
            return;
        }
        final PopupControl popup = this.getPopup();
        popup.getScene().setNodeOrientation(this.getSkinnable().getEffectiveNodeOrientation());
        final Node popupContent = this.getPopupContent();
        this.sizePopup();
        final Point2D prefPopupPosition = this.getPrefPopupPosition();
        this.popupNeedsReconfiguring = true;
        this.reconfigurePopup();
        popup.show(comboBoxBase.getScene().getWindow(), this.snapPositionX(prefPopupPosition.getX()), this.snapPositionY(prefPopupPosition.getY()));
        popupContent.requestFocus();
        this.sizePopup();
    }
    
    private void sizePopup() {
        final Node popupContent = this.getPopupContent();
        if (popupContent instanceof Region) {
            final Region region = (Region)popupContent;
            final double snapSizeY = this.snapSizeY(region.prefHeight(0.0));
            final double snapSizeY2 = this.snapSizeY(region.minHeight(0.0));
            final double snapSizeY3 = this.snapSizeY(Math.min(Math.max(snapSizeY, snapSizeY2), Math.max(snapSizeY2, this.snapSizeY(region.maxHeight(0.0)))));
            final double snapSizeX = this.snapSizeX(region.prefWidth(snapSizeY3));
            final double snapSizeX2 = this.snapSizeX(region.minWidth(snapSizeY3));
            popupContent.resize(this.snapSizeX(Math.min(Math.max(snapSizeX, snapSizeX2), Math.max(snapSizeX2, this.snapSizeX(region.maxWidth(snapSizeY3))))), snapSizeY3);
        }
        else {
            popupContent.autosize();
        }
    }
    
    private void createPopup() {
        this.popup = new PopupControl() {
            {
                this.setSkin(new Skin<Skinnable>() {
                    @Override
                    public Skinnable getSkinnable() {
                        return ComboBoxPopupControl.this.getSkinnable();
                    }
                    
                    @Override
                    public Node getNode() {
                        return ComboBoxPopupControl.this.getPopupContent();
                    }
                    
                    @Override
                    public void dispose() {
                    }
                });
            }
            
            @Override
            public Styleable getStyleableParent() {
                return ComboBoxPopupControl.this.getSkinnable();
            }
        };
        this.popup.getStyleClass().add("combo-box-popup");
        this.popup.setConsumeAutoHidingEvents(false);
        this.popup.setAutoHide(true);
        this.popup.setAutoFix(true);
        this.popup.setHideOnEscape(true);
        this.popup.setOnAutoHide(p0 -> this.getBehavior().onAutoHide(this.popup));
        this.popup.addEventHandler(MouseEvent.MOUSE_CLICKED, p0 -> this.getBehavior().onAutoHide(this.popup));
        this.popup.addEventHandler(WindowEvent.WINDOW_HIDDEN, p0 -> this.getSkinnable().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_NODE));
        final InvalidationListener invalidationListener = p0 -> {
            this.popupNeedsReconfiguring = (1 != 0);
            this.reconfigurePopup();
            return;
        };
        this.getSkinnable().layoutXProperty().addListener(invalidationListener);
        this.getSkinnable().layoutYProperty().addListener(invalidationListener);
        this.getSkinnable().widthProperty().addListener(invalidationListener);
        this.getSkinnable().heightProperty().addListener(invalidationListener);
        this.getSkinnable().sceneProperty().addListener(observableValue -> {
            if (observableValue.getValue() == null) {
                this.hide();
            }
            else if (this.getSkinnable().isShowing()) {
                this.show();
            }
        });
    }
    
    void reconfigurePopup() {
        if (this.popup == null) {
            return;
        }
        if (!this.popup.isShowing()) {
            return;
        }
        if (!this.popupNeedsReconfiguring) {
            return;
        }
        this.popupNeedsReconfiguring = false;
        final Point2D prefPopupPosition = this.getPrefPopupPosition();
        final Node popupContent = this.getPopupContent();
        final double prefWidth = popupContent.prefWidth(-1.0);
        final double prefHeight = popupContent.prefHeight(-1.0);
        if (prefPopupPosition.getX() > -1.0) {
            this.popup.setAnchorX(prefPopupPosition.getX());
        }
        if (prefPopupPosition.getY() > -1.0) {
            this.popup.setAnchorY(prefPopupPosition.getY());
        }
        if (prefWidth > -1.0) {
            this.popup.setMinWidth(prefWidth);
        }
        if (prefHeight > -1.0) {
            this.popup.setMinHeight(prefHeight);
        }
        final Bounds layoutBounds = popupContent.getLayoutBounds();
        final double width = layoutBounds.getWidth();
        final double height = layoutBounds.getHeight();
        final double n = (width < prefWidth) ? prefWidth : width;
        final double n2 = (height < prefHeight) ? prefHeight : height;
        if (n != width || n2 != height) {
            popupContent.resize(n, n2);
            if (popupContent instanceof Region) {
                ((Region)popupContent).setMinSize(n, n2);
                ((Region)popupContent).setPrefSize(n, n2);
            }
        }
    }
    
    private void handleKeyEvent(final KeyEvent keyEvent, final boolean b) {
        if (keyEvent.getCode() == KeyCode.ENTER) {
            if (keyEvent.isConsumed() || keyEvent.getEventType() != KeyEvent.KEY_RELEASED) {
                return;
            }
            this.setTextFromTextFieldIntoComboBoxValue();
            if (b && this.comboBoxBase.getOnAction() != null) {
                keyEvent.consume();
            }
            else if (this.textField != null) {
                this.textField.fireEvent(keyEvent);
            }
        }
        else if (keyEvent.getCode() == KeyCode.F4) {
            if (keyEvent.getEventType() == KeyEvent.KEY_RELEASED) {
                if (this.comboBoxBase.isShowing()) {
                    this.comboBoxBase.hide();
                }
                else {
                    this.comboBoxBase.show();
                }
            }
            keyEvent.consume();
        }
        else if ((keyEvent.getCode() == KeyCode.F10 || keyEvent.getCode() == KeyCode.ESCAPE) && b) {
            keyEvent.consume();
        }
    }
}
