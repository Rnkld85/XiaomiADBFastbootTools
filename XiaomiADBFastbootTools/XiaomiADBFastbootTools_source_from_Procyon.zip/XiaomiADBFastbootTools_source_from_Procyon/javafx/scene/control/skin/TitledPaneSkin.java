// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.control.SkinBase;
import javafx.scene.input.MouseEvent;
import javafx.geometry.Insets;
import javafx.scene.text.Font;
import javafx.scene.control.Labeled;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.scene.Cursor;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ContextMenu;
import javafx.scene.input.MouseButton;
import javafx.beans.Observable;
import javafx.beans.binding.DoubleBinding;
import com.sun.javafx.PlatformUtil;
import javafx.event.ActionEvent;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.animation.Animation;
import javafx.scene.control.Accordion;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.shape.Rectangle;
import javafx.animation.Timeline;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;
import com.sun.javafx.scene.control.behavior.TitledPaneBehavior;
import javafx.util.Duration;
import javafx.scene.control.TitledPane;

public class TitledPaneSkin extends LabeledSkinBase<TitledPane>
{
    private static final Duration TRANSITION_DURATION;
    private static final boolean CACHE_ANIMATION;
    private final TitledPaneBehavior behavior;
    private final TitleRegion titleRegion;
    private final StackPane contentContainer;
    private Node content;
    private Timeline timeline;
    private double transitionStartValue;
    private Rectangle clipRect;
    private Pos pos;
    private HPos hpos;
    private VPos vpos;
    private DoubleProperty transition;
    private double prefHeightFromAccordion;
    
    public TitledPaneSkin(final TitledPane titledPane) {
        super(titledPane);
        this.prefHeightFromAccordion = 0.0;
        this.behavior = new TitledPaneBehavior(titledPane);
        this.clipRect = new Rectangle();
        this.transitionStartValue = 0.0;
        this.titleRegion = new TitleRegion();
        this.content = this.getSkinnable().getContent();
        (this.contentContainer = new StackPane() {
            {
                this.getStyleClass().setAll("content");
                if (TitledPaneSkin.this.content != null) {
                    this.getChildren().setAll(TitledPaneSkin.this.content);
                }
            }
        }).setClip(this.clipRect);
        this.updateClip();
        if (titledPane.isExpanded()) {
            this.setTransition(1.0);
            this.setExpanded(titledPane.isExpanded());
        }
        else {
            this.setTransition(0.0);
            if (this.content != null) {
                this.content.setVisible(false);
            }
        }
        this.getChildren().setAll(this.contentContainer, this.titleRegion);
        this.registerChangeListener(titledPane.contentProperty(), p0 -> {
            this.content = this.getSkinnable().getContent();
            if (this.content == null) {
                this.contentContainer.getChildren().clear();
            }
            else {
                this.contentContainer.getChildren().setAll(this.content);
            }
            return;
        });
        this.registerChangeListener(titledPane.expandedProperty(), p0 -> this.setExpanded(this.getSkinnable().isExpanded()));
        this.registerChangeListener(titledPane.collapsibleProperty(), p0 -> this.titleRegion.update());
        this.registerChangeListener(titledPane.alignmentProperty(), p0 -> {
            this.pos = this.getSkinnable().getAlignment();
            this.hpos = this.pos.getHpos();
            this.vpos = this.pos.getVpos();
            return;
        });
        this.registerChangeListener(titledPane.widthProperty(), p0 -> this.updateClip());
        this.registerChangeListener(titledPane.heightProperty(), p0 -> this.updateClip());
        this.registerChangeListener(this.titleRegion.alignmentProperty(), p0 -> {
            this.pos = this.titleRegion.getAlignment();
            this.hpos = this.pos.getHpos();
            this.vpos = this.pos.getVpos();
            return;
        });
        this.pos = titledPane.getAlignment();
        this.hpos = ((this.pos == null) ? HPos.LEFT : this.pos.getHpos());
        this.vpos = ((this.pos == null) ? VPos.CENTER : this.pos.getVpos());
    }
    
    private final void setTransition(final double n) {
        this.transitionProperty().set(n);
    }
    
    private final double getTransition() {
        return (this.transition == null) ? 0.0 : this.transition.get();
    }
    
    private final DoubleProperty transitionProperty() {
        if (this.transition == null) {
            this.transition = new SimpleDoubleProperty(this, "transition", 0.0) {
                @Override
                protected void invalidated() {
                    TitledPaneSkin.this.contentContainer.requestLayout();
                }
            };
        }
        return this.transition;
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void updateChildren() {
        if (this.titleRegion != null) {
            this.titleRegion.update();
        }
    }
    
    @Override
    protected void layoutChildren(final double n, double n2, final double n3, final double n4) {
        final double snapSizeY = this.snapSizeY(this.titleRegion.prefHeight(-1.0));
        this.titleRegion.resize(n3, snapSizeY);
        this.positionInArea(this.titleRegion, n, n2, n3, snapSizeY, 0.0, HPos.LEFT, VPos.CENTER);
        this.titleRegion.requestLayout();
        double n5 = (n4 - snapSizeY) * this.getTransition();
        if (this.isInsideAccordion() && this.prefHeightFromAccordion != 0.0) {
            n5 = (this.prefHeightFromAccordion - snapSizeY) * this.getTransition();
        }
        final double snapSizeY2 = this.snapSizeY(n5);
        n2 += snapSizeY;
        this.contentContainer.resize(n3, snapSizeY2);
        this.clipRect.setHeight(snapSizeY2);
        this.positionInArea(this.contentContainer, n, n2, n3, snapSizeY2, 0.0, HPos.CENTER, VPos.CENTER);
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Math.max(this.snapSizeX(this.titleRegion.prefWidth(n)), this.snapSizeX(this.contentContainer.minWidth(n))) + n5 + n3;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.snapSizeY(this.titleRegion.prefHeight(n)) + this.snapSizeY(this.contentContainer.minHeight(n) * this.getTransition()) + n2 + n4;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Math.max(this.snapSizeX(this.titleRegion.prefWidth(n)), this.snapSizeX(this.contentContainer.prefWidth(n))) + n5 + n3;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.snapSizeY(this.titleRegion.prefHeight(n)) + this.snapSizeY(this.contentContainer.prefHeight(n) * this.getTransition()) + n2 + n4;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Double.MAX_VALUE;
    }
    
    private void updateClip() {
        this.clipRect.setWidth(this.getSkinnable().getWidth());
        this.clipRect.setHeight(this.contentContainer.getHeight());
    }
    
    private void setExpanded(final boolean visible) {
        if (!this.getSkinnable().isCollapsible()) {
            this.setTransition(1.0);
            return;
        }
        if (this.getSkinnable().isAnimated()) {
            this.transitionStartValue = this.getTransition();
            this.doAnimationTransition();
        }
        else {
            if (visible) {
                this.setTransition(1.0);
            }
            else {
                this.setTransition(0.0);
            }
            if (this.content != null) {
                this.content.setVisible(visible);
            }
            this.getSkinnable().requestLayout();
        }
    }
    
    private boolean isInsideAccordion() {
        return this.getSkinnable().getParent() != null && this.getSkinnable().getParent() instanceof Accordion;
    }
    
    double getTitleRegionSize(final double n) {
        return this.snapSizeY(this.titleRegion.prefHeight(n)) + this.snappedTopInset() + this.snappedBottomInset();
    }
    
    void setMaxTitledPaneHeightForAccordion(final double prefHeightFromAccordion) {
        this.prefHeightFromAccordion = prefHeightFromAccordion;
    }
    
    double getTitledPaneHeightForAccordion() {
        final double snapSizeY = this.snapSizeY(this.titleRegion.prefHeight(-1.0));
        return snapSizeY + this.snapSizeY((this.prefHeightFromAccordion - snapSizeY) * this.getTransition()) + this.snappedTopInset() + this.snappedBottomInset();
    }
    
    private void doAnimationTransition() {
        if (this.content == null) {
            return;
        }
        Duration duration;
        if (this.timeline != null && this.timeline.getStatus() != Animation.Status.STOPPED) {
            duration = this.timeline.getCurrentTime();
            this.timeline.stop();
        }
        else {
            duration = TitledPaneSkin.TRANSITION_DURATION;
        }
        (this.timeline = new Timeline()).setCycleCount(1);
        KeyFrame keyFrame;
        KeyFrame keyFrame2;
        if (this.getSkinnable().isExpanded()) {
            keyFrame = new KeyFrame(Duration.ZERO, p0 -> {
                if (TitledPaneSkin.CACHE_ANIMATION) {
                    this.content.setCache((boolean)(1 != 0));
                }
                this.content.setVisible((boolean)(1 != 0));
                return;
            }, new KeyValue[] { new KeyValue((WritableValue<T>)this.transitionProperty(), (T)this.transitionStartValue) });
            keyFrame2 = new KeyFrame(duration, p0 -> {
                if (TitledPaneSkin.CACHE_ANIMATION) {
                    this.content.setCache((boolean)(0 != 0));
                }
                return;
            }, new KeyValue[] { new KeyValue((WritableValue<T>)this.transitionProperty(), (T)1, Interpolator.LINEAR) });
        }
        else {
            keyFrame = new KeyFrame(Duration.ZERO, p0 -> {
                if (TitledPaneSkin.CACHE_ANIMATION) {
                    this.content.setCache((boolean)(1 != 0));
                }
                return;
            }, new KeyValue[] { new KeyValue((WritableValue<T>)this.transitionProperty(), (T)this.transitionStartValue) });
            keyFrame2 = new KeyFrame(duration, p0 -> {
                this.content.setVisible((boolean)(0 != 0));
                if (TitledPaneSkin.CACHE_ANIMATION) {
                    this.content.setCache((boolean)(0 != 0));
                }
                return;
            }, new KeyValue[] { new KeyValue((WritableValue<T>)this.transitionProperty(), (T)0, Interpolator.LINEAR) });
        }
        this.timeline.getKeyFrames().setAll(keyFrame, keyFrame2);
        this.timeline.play();
    }
    
    static {
        TRANSITION_DURATION = new Duration(350.0);
        CACHE_ANIMATION = PlatformUtil.isEmbedded();
    }
    
    class TitleRegion extends StackPane
    {
        private final StackPane arrowRegion;
        
        public TitleRegion() {
            this.getStyleClass().setAll("title");
            (this.arrowRegion = new StackPane()).setId("arrowRegion");
            this.arrowRegion.getStyleClass().setAll("arrow-button");
            final StackPane stackPane = new StackPane();
            stackPane.setId("arrow");
            stackPane.getStyleClass().setAll("arrow");
            this.arrowRegion.getChildren().setAll(stackPane);
            stackPane.rotateProperty().bind(new DoubleBinding() {
                {
                    this.bind(TitledPaneSkin.this.transitionProperty());
                }
                
                @Override
                protected double computeValue() {
                    return -90.0 * (1.0 - TitledPaneSkin.this.getTransition());
                }
            });
            this.setAlignment(Pos.CENTER_LEFT);
            final ContextMenu contextMenu;
            this.setOnMouseReleased(mouseEvent -> {
                if (mouseEvent.getButton() != MouseButton.PRIMARY) {
                    return;
                }
                else {
                    TitledPaneSkin.this.getSkinnable().getContextMenu();
                    if (contextMenu != null) {
                        contextMenu.hide();
                    }
                    if (TitledPaneSkin.this.getSkinnable().isCollapsible() && TitledPaneSkin.this.getSkinnable().isFocused()) {
                        TitledPaneSkin.this.behavior.toggle();
                    }
                    return;
                }
            });
            this.update();
        }
        
        private void update() {
            this.getChildren().clear();
            final TitledPane titledPane = TitledPaneSkin.this.getSkinnable();
            if (titledPane.isCollapsible()) {
                this.getChildren().add(this.arrowRegion);
            }
            if (TitledPaneSkin.this.graphic != null) {
                TitledPaneSkin.this.graphic.layoutBoundsProperty().removeListener(TitledPaneSkin.this.graphicPropertyChangedListener);
            }
            TitledPaneSkin.this.graphic = titledPane.getGraphic();
            if (TitledPaneSkin.this.isIgnoreGraphic()) {
                if (titledPane.getContentDisplay() == ContentDisplay.GRAPHIC_ONLY) {
                    this.getChildren().clear();
                    this.getChildren().add(this.arrowRegion);
                }
                else {
                    this.getChildren().add(TitledPaneSkin.this.text);
                }
            }
            else {
                TitledPaneSkin.this.graphic.layoutBoundsProperty().addListener(TitledPaneSkin.this.graphicPropertyChangedListener);
                if (TitledPaneSkin.this.isIgnoreText()) {
                    this.getChildren().add(TitledPaneSkin.this.graphic);
                }
                else {
                    this.getChildren().addAll(TitledPaneSkin.this.graphic, TitledPaneSkin.this.text);
                }
            }
            this.setCursor(TitledPaneSkin.this.getSkinnable().isCollapsible() ? Cursor.HAND : Cursor.DEFAULT);
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            final double snappedLeftInset = this.snappedLeftInset();
            final double snappedRightInset = this.snappedRightInset();
            double snapSize = 0.0;
            final double labelPrefWidth = this.labelPrefWidth(n);
            if (this.arrowRegion != null) {
                snapSize = this.snapSize(this.arrowRegion.prefWidth(n));
            }
            return snappedLeftInset + snapSize + labelPrefWidth + snappedRightInset;
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            final double snappedTopInset = this.snappedTopInset();
            final double snappedBottomInset = this.snappedBottomInset();
            double snapSize = 0.0;
            final double labelPrefHeight = this.labelPrefHeight(n);
            if (this.arrowRegion != null) {
                snapSize = this.snapSize(this.arrowRegion.prefHeight(n));
            }
            return snappedTopInset + Math.max(snapSize, labelPrefHeight) + snappedBottomInset;
        }
        
        @Override
        protected void layoutChildren() {
            final double snappedTopInset = this.snappedTopInset();
            final double snappedBottomInset = this.snappedBottomInset();
            final double snappedLeftInset = this.snappedLeftInset();
            final double n = this.getWidth() - (snappedLeftInset + this.snappedRightInset());
            final double n2 = this.getHeight() - (snappedTopInset + snappedBottomInset);
            final double snapSize = this.snapSize(this.arrowRegion.prefWidth(-1.0));
            final double snapSize2 = this.snapSize(this.arrowRegion.prefHeight(-1.0));
            final double snapSize3 = this.snapSize(Math.min(n - snapSize / 2.0, this.labelPrefWidth(-1.0)));
            final double snapSize4 = this.snapSize(this.labelPrefHeight(-1.0));
            double n3 = snappedLeftInset + snapSize + Utils.computeXOffset(n - snapSize, snapSize3, TitledPaneSkin.this.hpos);
            if (HPos.CENTER == TitledPaneSkin.this.hpos) {
                n3 = snappedLeftInset + Utils.computeXOffset(n, snapSize3, TitledPaneSkin.this.hpos);
            }
            final double n4 = snappedTopInset + Utils.computeYOffset(n2, Math.max(snapSize2, snapSize4), TitledPaneSkin.this.vpos);
            this.arrowRegion.resize(snapSize, snapSize2);
            this.positionInArea(this.arrowRegion, snappedLeftInset, snappedTopInset, snapSize, n2, 0.0, HPos.CENTER, VPos.CENTER);
            TitledPaneSkin.this.layoutLabelInArea(n3, n4, snapSize3, n2, TitledPaneSkin.this.pos);
        }
        
        private double labelPrefWidth(final double n) {
            final Labeled labeled = ((SkinBase<Labeled>)TitledPaneSkin.this).getSkinnable();
            final Font font = TitledPaneSkin.this.text.getFont();
            final String text = labeled.getText();
            final boolean b = text == null || text.isEmpty();
            final Insets labelPadding = labeled.getLabelPadding();
            final double n2 = labelPadding.getLeft() + labelPadding.getRight();
            final double a = b ? 0.0 : Utils.computeTextWidth(font, text, 0.0);
            final Node graphic = labeled.getGraphic();
            if (TitledPaneSkin.this.isIgnoreGraphic()) {
                return a + n2;
            }
            if (TitledPaneSkin.this.isIgnoreText()) {
                return graphic.prefWidth(-1.0) + n2;
            }
            if (labeled.getContentDisplay() == ContentDisplay.LEFT || labeled.getContentDisplay() == ContentDisplay.RIGHT) {
                return a + labeled.getGraphicTextGap() + graphic.prefWidth(-1.0) + n2;
            }
            return Math.max(a, graphic.prefWidth(-1.0)) + n2;
        }
        
        private double labelPrefHeight(double n) {
            final Labeled labeled = ((SkinBase<Labeled>)TitledPaneSkin.this).getSkinnable();
            final Font font = TitledPaneSkin.this.text.getFont();
            final ContentDisplay contentDisplay = labeled.getContentDisplay();
            final double graphicTextGap = labeled.getGraphicTextGap();
            final Insets labelPadding = labeled.getLabelPadding();
            final double n2 = this.snappedLeftInset() + this.snappedRightInset() + labelPadding.getLeft() + labelPadding.getRight();
            String s = labeled.getText();
            if (s != null && s.endsWith("\n")) {
                s = s.substring(0, s.length() - 1);
            }
            if (!TitledPaneSkin.this.isIgnoreGraphic() && (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT)) {
                n -= TitledPaneSkin.this.graphic.prefWidth(-1.0) + graphicTextGap;
            }
            n -= n2;
            double n3;
            final double a = n3 = Utils.computeTextHeight(font, s, labeled.isWrapText() ? n : 0.0, TitledPaneSkin.this.text.getBoundsType());
            if (!TitledPaneSkin.this.isIgnoreGraphic()) {
                final Node graphic = labeled.getGraphic();
                if (contentDisplay == ContentDisplay.TOP || contentDisplay == ContentDisplay.BOTTOM) {
                    n3 = graphic.prefHeight(-1.0) + graphicTextGap + a;
                }
                else {
                    n3 = Math.max(a, graphic.prefHeight(-1.0));
                }
            }
            return n3 + labelPadding.getTop() + labelPadding.getBottom();
        }
    }
}
