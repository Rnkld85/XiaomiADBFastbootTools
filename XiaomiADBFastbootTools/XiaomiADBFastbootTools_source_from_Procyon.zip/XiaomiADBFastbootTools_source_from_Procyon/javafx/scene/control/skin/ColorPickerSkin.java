// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.scene.control.SkinBase;
import javafx.css.converter.SizeConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.geometry.Pos;
import com.sun.javafx.scene.control.Properties;
import java.util.HashMap;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.paint.Paint;
import javafx.collections.ObservableList;
import com.sun.javafx.scene.control.behavior.ComboBoxBaseBehavior;
import java.util.Iterator;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.beans.property.StringProperty;
import javafx.scene.Node;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.css.StyleManager;
import javafx.scene.image.ImageView;
import javafx.css.StyleOrigin;
import javafx.css.CssMetaData;
import javafx.css.StyleableBooleanProperty;
import javafx.scene.control.ComboBoxBase;
import javafx.scene.control.ColorPicker;
import java.util.Map;
import javafx.css.StyleableDoubleProperty;
import javafx.css.StyleableStringProperty;
import javafx.beans.property.BooleanProperty;
import com.sun.javafx.scene.control.behavior.ColorPickerBehavior;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;

public class ColorPickerSkin extends ComboBoxPopupControl<Color>
{
    private Label displayNode;
    private StackPane pickerColorBox;
    private Rectangle colorRect;
    private ColorPalette popupContent;
    private final ColorPickerBehavior behavior;
    BooleanProperty colorLabelVisible;
    private final StyleableStringProperty imageUrl;
    private final StyleableDoubleProperty colorRectWidth;
    private final StyleableDoubleProperty colorRectHeight;
    private final StyleableDoubleProperty colorRectX;
    private final StyleableDoubleProperty colorRectY;
    private static final Map<Color, String> colorNameMap;
    private static final Map<Color, String> cssNameMap;
    
    public ColorPickerSkin(final ColorPicker colorPicker) {
        super(colorPicker);
        this.colorLabelVisible = new StyleableBooleanProperty(true) {
            public void invalidated() {
                if (ColorPickerSkin.this.displayNode != null) {
                    if (ColorPickerSkin.this.colorLabelVisible.get()) {
                        ColorPickerSkin.this.displayNode.setText(ColorPickerSkin.colorDisplayName(((SkinBase<ColorPicker>)ColorPickerSkin.this).getSkinnable().getValue()));
                    }
                    else {
                        ColorPickerSkin.this.displayNode.setText("");
                    }
                }
            }
            
            @Override
            public Object getBean() {
                return ColorPickerSkin.this;
            }
            
            @Override
            public String getName() {
                return "colorLabelVisible";
            }
            
            @Override
            public CssMetaData<ColorPicker, Boolean> getCssMetaData() {
                return StyleableProperties.COLOR_LABEL_VISIBLE;
            }
        };
        this.imageUrl = new StyleableStringProperty() {
            @Override
            public void applyStyle(final StyleOrigin styleOrigin, final String s) {
                super.applyStyle(styleOrigin, s);
                if (s == null) {
                    if (ColorPickerSkin.this.pickerColorBox.getChildren().size() == 2) {
                        ColorPickerSkin.this.pickerColorBox.getChildren().remove(1);
                    }
                }
                else if (ColorPickerSkin.this.pickerColorBox.getChildren().size() == 2) {
                    ColorPickerSkin.this.pickerColorBox.getChildren().get(1).setImage(StyleManager.getInstance().getCachedImage(s));
                }
                else {
                    ColorPickerSkin.this.pickerColorBox.getChildren().add(new ImageView(StyleManager.getInstance().getCachedImage(s)));
                }
            }
            
            @Override
            public Object getBean() {
                return ColorPickerSkin.this;
            }
            
            @Override
            public String getName() {
                return "imageUrl";
            }
            
            @Override
            public CssMetaData<ColorPicker, String> getCssMetaData() {
                return StyleableProperties.GRAPHIC;
            }
        };
        this.colorRectWidth = new StyleableDoubleProperty(12.0) {
            @Override
            protected void invalidated() {
                if (ColorPickerSkin.this.pickerColorBox != null) {
                    ColorPickerSkin.this.pickerColorBox.requestLayout();
                }
            }
            
            @Override
            public CssMetaData<ColorPicker, Number> getCssMetaData() {
                return StyleableProperties.COLOR_RECT_WIDTH;
            }
            
            @Override
            public Object getBean() {
                return ColorPickerSkin.this;
            }
            
            @Override
            public String getName() {
                return "colorRectWidth";
            }
        };
        this.colorRectHeight = new StyleableDoubleProperty(12.0) {
            @Override
            protected void invalidated() {
                if (ColorPickerSkin.this.pickerColorBox != null) {
                    ColorPickerSkin.this.pickerColorBox.requestLayout();
                }
            }
            
            @Override
            public CssMetaData<ColorPicker, Number> getCssMetaData() {
                return StyleableProperties.COLOR_RECT_HEIGHT;
            }
            
            @Override
            public Object getBean() {
                return ColorPickerSkin.this;
            }
            
            @Override
            public String getName() {
                return "colorRectHeight";
            }
        };
        this.colorRectX = new StyleableDoubleProperty(0.0) {
            @Override
            protected void invalidated() {
                if (ColorPickerSkin.this.pickerColorBox != null) {
                    ColorPickerSkin.this.pickerColorBox.requestLayout();
                }
            }
            
            @Override
            public CssMetaData<ColorPicker, Number> getCssMetaData() {
                return StyleableProperties.COLOR_RECT_X;
            }
            
            @Override
            public Object getBean() {
                return ColorPickerSkin.this;
            }
            
            @Override
            public String getName() {
                return "colorRectX";
            }
        };
        this.colorRectY = new StyleableDoubleProperty(0.0) {
            @Override
            protected void invalidated() {
                if (ColorPickerSkin.this.pickerColorBox != null) {
                    ColorPickerSkin.this.pickerColorBox.requestLayout();
                }
            }
            
            @Override
            public CssMetaData<ColorPicker, Number> getCssMetaData() {
                return StyleableProperties.COLOR_RECT_Y;
            }
            
            @Override
            public Object getBean() {
                return ColorPickerSkin.this;
            }
            
            @Override
            public String getName() {
                return "colorRectY";
            }
        };
        this.behavior = new ColorPickerBehavior(colorPicker);
        this.updateComboBoxMode();
        this.registerChangeListener(colorPicker.valueProperty(), p0 -> this.updateColor());
        this.displayNode = new Label();
        this.displayNode.getStyleClass().add("color-picker-label");
        this.displayNode.setManaged(false);
        this.pickerColorBox = new PickerColorBox();
        this.pickerColorBox.getStyleClass().add("picker-color");
        this.colorRect = new Rectangle(12.0, 12.0);
        this.colorRect.getStyleClass().add("picker-color-rect");
        this.updateColor();
        this.pickerColorBox.getChildren().add(this.colorRect);
        this.displayNode.setGraphic(this.pickerColorBox);
        if (colorPicker.isShowing()) {
            this.show();
        }
    }
    
    private final StringProperty imageUrlProperty() {
        return this.imageUrl;
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (!this.colorLabelVisible.get()) {
            return super.computePrefWidth(n, n2, n3, n4, n5);
        }
        final String text = this.displayNode.getText();
        double max = 0.0;
        final Iterator<String> iterator = ColorPickerSkin.colorNameMap.values().iterator();
        while (iterator.hasNext()) {
            this.displayNode.setText(iterator.next());
            max = Math.max(max, super.computePrefWidth(n, n2, n3, n4, n5));
        }
        this.displayNode.setText(Utils.formatHexString(Color.BLACK));
        final double max2 = Math.max(max, super.computePrefWidth(n, n2, n3, n4, n5));
        this.displayNode.setText(text);
        return max2;
    }
    
    @Override
    protected Node getPopupContent() {
        if (this.popupContent == null) {
            (this.popupContent = new ColorPalette(((SkinBase<ColorPicker>)this).getSkinnable())).setPopupControl(this.getPopup());
        }
        return this.popupContent;
    }
    
    @Override
    public void show() {
        super.show();
        this.popupContent.updateSelection(((SkinBase<ColorPicker>)this).getSkinnable().getValue());
    }
    
    @Override
    public Node getDisplayNode() {
        return this.displayNode;
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        this.updateComboBoxMode();
        super.layoutChildren(n, n2, n3, n4);
    }
    
    @Override
    void focusLost() {
    }
    
    @Override
    ComboBoxBaseBehavior getBehavior() {
        return this.behavior;
    }
    
    private void updateComboBoxMode() {
        final ObservableList<String> styleClass = ((SkinBase<ComboBoxBase<?>>)this).getSkinnable().getStyleClass();
        if (styleClass.contains("button")) {
            this.setMode(ComboBoxMode.BUTTON);
        }
        else if (styleClass.contains("split-button")) {
            this.setMode(ComboBoxMode.SPLITBUTTON);
        }
    }
    
    static String colorDisplayName(final Color color) {
        if (color != null) {
            String formatHexString = ColorPickerSkin.colorNameMap.get(color);
            if (formatHexString == null) {
                formatHexString = Utils.formatHexString(color);
            }
            return formatHexString;
        }
        return null;
    }
    
    static String tooltipString(final Color color) {
        if (color != null) {
            String s = "";
            final String s2 = ColorPickerSkin.colorNameMap.get(color);
            if (s2 != null) {
                s = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, s2);
            }
            String s3 = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, Utils.formatHexString(color));
            final String s4 = ColorPickerSkin.cssNameMap.get(color);
            if (s4 != null) {
                s3 = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s3, s4);
            }
            return s3;
        }
        return null;
    }
    
    private void updateColor() {
        final ColorPicker colorPicker = ((SkinBase<ColorPicker>)this).getSkinnable();
        this.colorRect.setFill(((ComboBoxBase<Paint>)colorPicker).getValue());
        if (this.colorLabelVisible.get()) {
            this.displayNode.setText(colorDisplayName(colorPicker.getValue()));
        }
        else {
            this.displayNode.setText("");
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected StringConverter<Color> getConverter() {
        return null;
    }
    
    @Override
    protected TextField getEditor() {
        return null;
    }
    
    static {
        colorNameMap = new HashMap<Color, String>(30);
        cssNameMap = new HashMap<Color, String>(139);
        ColorPickerSkin.colorNameMap.put(Color.TRANSPARENT, Properties.getColorPickerString("colorName.transparent"));
        ColorPickerSkin.colorNameMap.put(Color.BLACK, Properties.getColorPickerString("colorName.black"));
        ColorPickerSkin.colorNameMap.put(Color.BLUE, Properties.getColorPickerString("colorName.blue"));
        ColorPickerSkin.colorNameMap.put(Color.CYAN, Properties.getColorPickerString("colorName.cyan"));
        ColorPickerSkin.colorNameMap.put(Color.DARKBLUE, Properties.getColorPickerString("colorName.darkblue"));
        ColorPickerSkin.colorNameMap.put(Color.DARKCYAN, Properties.getColorPickerString("colorName.darkcyan"));
        ColorPickerSkin.colorNameMap.put(Color.DARKGRAY, Properties.getColorPickerString("colorName.darkgray"));
        ColorPickerSkin.colorNameMap.put(Color.DARKGREEN, Properties.getColorPickerString("colorName.darkgreen"));
        ColorPickerSkin.colorNameMap.put(Color.DARKMAGENTA, Properties.getColorPickerString("colorName.darkmagenta"));
        ColorPickerSkin.colorNameMap.put(Color.DARKRED, Properties.getColorPickerString("colorName.darkred"));
        ColorPickerSkin.colorNameMap.put(Color.GRAY, Properties.getColorPickerString("colorName.gray"));
        ColorPickerSkin.colorNameMap.put(Color.GREEN, Properties.getColorPickerString("colorName.green"));
        ColorPickerSkin.colorNameMap.put(Color.LIGHTBLUE, Properties.getColorPickerString("colorName.lightblue"));
        ColorPickerSkin.colorNameMap.put(Color.LIGHTCYAN, Properties.getColorPickerString("colorName.lightcyan"));
        ColorPickerSkin.colorNameMap.put(Color.LIGHTGRAY, Properties.getColorPickerString("colorName.lightgray"));
        ColorPickerSkin.colorNameMap.put(Color.LIGHTGREEN, Properties.getColorPickerString("colorName.lightgreen"));
        ColorPickerSkin.colorNameMap.put(Color.LIGHTYELLOW, Properties.getColorPickerString("colorName.lightyellow"));
        ColorPickerSkin.colorNameMap.put(Color.LIME, Properties.getColorPickerString("colorName.lime"));
        ColorPickerSkin.colorNameMap.put(Color.MAGENTA, Properties.getColorPickerString("colorName.magenta"));
        ColorPickerSkin.colorNameMap.put(Color.MAROON, Properties.getColorPickerString("colorName.maroon"));
        ColorPickerSkin.colorNameMap.put(Color.MEDIUMBLUE, Properties.getColorPickerString("colorName.mediumblue"));
        ColorPickerSkin.colorNameMap.put(Color.NAVY, Properties.getColorPickerString("colorName.navy"));
        ColorPickerSkin.colorNameMap.put(Color.OLIVE, Properties.getColorPickerString("colorName.olive"));
        ColorPickerSkin.colorNameMap.put(Color.ORANGE, Properties.getColorPickerString("colorName.orange"));
        ColorPickerSkin.colorNameMap.put(Color.PINK, Properties.getColorPickerString("colorName.pink"));
        ColorPickerSkin.colorNameMap.put(Color.PURPLE, Properties.getColorPickerString("colorName.purple"));
        ColorPickerSkin.colorNameMap.put(Color.RED, Properties.getColorPickerString("colorName.red"));
        ColorPickerSkin.colorNameMap.put(Color.TEAL, Properties.getColorPickerString("colorName.teal"));
        ColorPickerSkin.colorNameMap.put(Color.WHITE, Properties.getColorPickerString("colorName.white"));
        ColorPickerSkin.colorNameMap.put(Color.YELLOW, Properties.getColorPickerString("colorName.yellow"));
        ColorPickerSkin.cssNameMap.put(Color.ALICEBLUE, "aliceblue");
        ColorPickerSkin.cssNameMap.put(Color.ANTIQUEWHITE, "antiquewhite");
        ColorPickerSkin.cssNameMap.put(Color.AQUAMARINE, "aquamarine");
        ColorPickerSkin.cssNameMap.put(Color.AZURE, "azure");
        ColorPickerSkin.cssNameMap.put(Color.BEIGE, "beige");
        ColorPickerSkin.cssNameMap.put(Color.BISQUE, "bisque");
        ColorPickerSkin.cssNameMap.put(Color.BLACK, "black");
        ColorPickerSkin.cssNameMap.put(Color.BLANCHEDALMOND, "blanchedalmond");
        ColorPickerSkin.cssNameMap.put(Color.BLUE, "blue");
        ColorPickerSkin.cssNameMap.put(Color.BLUEVIOLET, "blueviolet");
        ColorPickerSkin.cssNameMap.put(Color.BROWN, "brown");
        ColorPickerSkin.cssNameMap.put(Color.BURLYWOOD, "burlywood");
        ColorPickerSkin.cssNameMap.put(Color.CADETBLUE, "cadetblue");
        ColorPickerSkin.cssNameMap.put(Color.CHARTREUSE, "chartreuse");
        ColorPickerSkin.cssNameMap.put(Color.CHOCOLATE, "chocolate");
        ColorPickerSkin.cssNameMap.put(Color.CORAL, "coral");
        ColorPickerSkin.cssNameMap.put(Color.CORNFLOWERBLUE, "cornflowerblue");
        ColorPickerSkin.cssNameMap.put(Color.CORNSILK, "cornsilk");
        ColorPickerSkin.cssNameMap.put(Color.CRIMSON, "crimson");
        ColorPickerSkin.cssNameMap.put(Color.CYAN, "cyan");
        ColorPickerSkin.cssNameMap.put(Color.DARKBLUE, "darkblue");
        ColorPickerSkin.cssNameMap.put(Color.DARKCYAN, "darkcyan");
        ColorPickerSkin.cssNameMap.put(Color.DARKGOLDENROD, "darkgoldenrod");
        ColorPickerSkin.cssNameMap.put(Color.DARKGRAY, "darkgray");
        ColorPickerSkin.cssNameMap.put(Color.DARKGREEN, "darkgreen");
        ColorPickerSkin.cssNameMap.put(Color.DARKKHAKI, "darkkhaki");
        ColorPickerSkin.cssNameMap.put(Color.DARKMAGENTA, "darkmagenta");
        ColorPickerSkin.cssNameMap.put(Color.DARKOLIVEGREEN, "darkolivegreen");
        ColorPickerSkin.cssNameMap.put(Color.DARKORANGE, "darkorange");
        ColorPickerSkin.cssNameMap.put(Color.DARKORCHID, "darkorchid");
        ColorPickerSkin.cssNameMap.put(Color.DARKRED, "darkred");
        ColorPickerSkin.cssNameMap.put(Color.DARKSALMON, "darksalmon");
        ColorPickerSkin.cssNameMap.put(Color.DARKSEAGREEN, "darkseagreen");
        ColorPickerSkin.cssNameMap.put(Color.DARKSLATEBLUE, "darkslateblue");
        ColorPickerSkin.cssNameMap.put(Color.DARKSLATEGRAY, "darkslategray");
        ColorPickerSkin.cssNameMap.put(Color.DARKTURQUOISE, "darkturquoise");
        ColorPickerSkin.cssNameMap.put(Color.DARKVIOLET, "darkviolet");
        ColorPickerSkin.cssNameMap.put(Color.DEEPPINK, "deeppink");
        ColorPickerSkin.cssNameMap.put(Color.DEEPSKYBLUE, "deepskyblue");
        ColorPickerSkin.cssNameMap.put(Color.DIMGRAY, "dimgray");
        ColorPickerSkin.cssNameMap.put(Color.DODGERBLUE, "dodgerblue");
        ColorPickerSkin.cssNameMap.put(Color.FIREBRICK, "firebrick");
        ColorPickerSkin.cssNameMap.put(Color.FLORALWHITE, "floralwhite");
        ColorPickerSkin.cssNameMap.put(Color.FORESTGREEN, "forestgreen");
        ColorPickerSkin.cssNameMap.put(Color.GAINSBORO, "gainsboro");
        ColorPickerSkin.cssNameMap.put(Color.GHOSTWHITE, "ghostwhite");
        ColorPickerSkin.cssNameMap.put(Color.GOLD, "gold");
        ColorPickerSkin.cssNameMap.put(Color.GOLDENROD, "goldenrod");
        ColorPickerSkin.cssNameMap.put(Color.GRAY, "gray");
        ColorPickerSkin.cssNameMap.put(Color.GREEN, "green");
        ColorPickerSkin.cssNameMap.put(Color.GREENYELLOW, "greenyellow");
        ColorPickerSkin.cssNameMap.put(Color.HONEYDEW, "honeydew");
        ColorPickerSkin.cssNameMap.put(Color.HOTPINK, "hotpink");
        ColorPickerSkin.cssNameMap.put(Color.INDIANRED, "indianred");
        ColorPickerSkin.cssNameMap.put(Color.INDIGO, "indigo");
        ColorPickerSkin.cssNameMap.put(Color.IVORY, "ivory");
        ColorPickerSkin.cssNameMap.put(Color.KHAKI, "khaki");
        ColorPickerSkin.cssNameMap.put(Color.LAVENDER, "lavender");
        ColorPickerSkin.cssNameMap.put(Color.LAVENDERBLUSH, "lavenderblush");
        ColorPickerSkin.cssNameMap.put(Color.LAWNGREEN, "lawngreen");
        ColorPickerSkin.cssNameMap.put(Color.LEMONCHIFFON, "lemonchiffon");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTBLUE, "lightblue");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTCORAL, "lightcoral");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTCYAN, "lightcyan");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTGOLDENRODYELLOW, "lightgoldenrodyellow");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTGRAY, "lightgray");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTGREEN, "lightgreen");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTPINK, "lightpink");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTSALMON, "lightsalmon");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTSEAGREEN, "lightseagreen");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTSKYBLUE, "lightskyblue");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTSLATEGRAY, "lightslategray");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTSTEELBLUE, "lightsteelblue");
        ColorPickerSkin.cssNameMap.put(Color.LIGHTYELLOW, "lightyellow");
        ColorPickerSkin.cssNameMap.put(Color.LIME, "lime");
        ColorPickerSkin.cssNameMap.put(Color.LIMEGREEN, "limegreen");
        ColorPickerSkin.cssNameMap.put(Color.LINEN, "linen");
        ColorPickerSkin.cssNameMap.put(Color.MAGENTA, "magenta");
        ColorPickerSkin.cssNameMap.put(Color.MAROON, "maroon");
        ColorPickerSkin.cssNameMap.put(Color.MEDIUMAQUAMARINE, "mediumaquamarine");
        ColorPickerSkin.cssNameMap.put(Color.MEDIUMBLUE, "mediumblue");
        ColorPickerSkin.cssNameMap.put(Color.MEDIUMORCHID, "mediumorchid");
        ColorPickerSkin.cssNameMap.put(Color.MEDIUMPURPLE, "mediumpurple");
        ColorPickerSkin.cssNameMap.put(Color.MEDIUMSEAGREEN, "mediumseagreen");
        ColorPickerSkin.cssNameMap.put(Color.MEDIUMSLATEBLUE, "mediumslateblue");
        ColorPickerSkin.cssNameMap.put(Color.MEDIUMSPRINGGREEN, "mediumspringgreen");
        ColorPickerSkin.cssNameMap.put(Color.MEDIUMTURQUOISE, "mediumturquoise");
        ColorPickerSkin.cssNameMap.put(Color.MEDIUMVIOLETRED, "mediumvioletred");
        ColorPickerSkin.cssNameMap.put(Color.MIDNIGHTBLUE, "midnightblue");
        ColorPickerSkin.cssNameMap.put(Color.MINTCREAM, "mintcream");
        ColorPickerSkin.cssNameMap.put(Color.MISTYROSE, "mistyrose");
        ColorPickerSkin.cssNameMap.put(Color.MOCCASIN, "moccasin");
        ColorPickerSkin.cssNameMap.put(Color.NAVAJOWHITE, "navajowhite");
        ColorPickerSkin.cssNameMap.put(Color.NAVY, "navy");
        ColorPickerSkin.cssNameMap.put(Color.OLDLACE, "oldlace");
        ColorPickerSkin.cssNameMap.put(Color.OLIVE, "olive");
        ColorPickerSkin.cssNameMap.put(Color.OLIVEDRAB, "olivedrab");
        ColorPickerSkin.cssNameMap.put(Color.ORANGE, "orange");
        ColorPickerSkin.cssNameMap.put(Color.ORANGERED, "orangered");
        ColorPickerSkin.cssNameMap.put(Color.ORCHID, "orchid");
        ColorPickerSkin.cssNameMap.put(Color.PALEGOLDENROD, "palegoldenrod");
        ColorPickerSkin.cssNameMap.put(Color.PALEGREEN, "palegreen");
        ColorPickerSkin.cssNameMap.put(Color.PALETURQUOISE, "paleturquoise");
        ColorPickerSkin.cssNameMap.put(Color.PALEVIOLETRED, "palevioletred");
        ColorPickerSkin.cssNameMap.put(Color.PAPAYAWHIP, "papayawhip");
        ColorPickerSkin.cssNameMap.put(Color.PEACHPUFF, "peachpuff");
        ColorPickerSkin.cssNameMap.put(Color.PERU, "peru");
        ColorPickerSkin.cssNameMap.put(Color.PINK, "pink");
        ColorPickerSkin.cssNameMap.put(Color.PLUM, "plum");
        ColorPickerSkin.cssNameMap.put(Color.POWDERBLUE, "powderblue");
        ColorPickerSkin.cssNameMap.put(Color.PURPLE, "purple");
        ColorPickerSkin.cssNameMap.put(Color.RED, "red");
        ColorPickerSkin.cssNameMap.put(Color.ROSYBROWN, "rosybrown");
        ColorPickerSkin.cssNameMap.put(Color.ROYALBLUE, "royalblue");
        ColorPickerSkin.cssNameMap.put(Color.SADDLEBROWN, "saddlebrown");
        ColorPickerSkin.cssNameMap.put(Color.SALMON, "salmon");
        ColorPickerSkin.cssNameMap.put(Color.SANDYBROWN, "sandybrown");
        ColorPickerSkin.cssNameMap.put(Color.SEAGREEN, "seagreen");
        ColorPickerSkin.cssNameMap.put(Color.SEASHELL, "seashell");
        ColorPickerSkin.cssNameMap.put(Color.SIENNA, "sienna");
        ColorPickerSkin.cssNameMap.put(Color.SILVER, "silver");
        ColorPickerSkin.cssNameMap.put(Color.SKYBLUE, "skyblue");
        ColorPickerSkin.cssNameMap.put(Color.SLATEBLUE, "slateblue");
        ColorPickerSkin.cssNameMap.put(Color.SLATEGRAY, "slategray");
        ColorPickerSkin.cssNameMap.put(Color.SNOW, "snow");
        ColorPickerSkin.cssNameMap.put(Color.SPRINGGREEN, "springgreen");
        ColorPickerSkin.cssNameMap.put(Color.STEELBLUE, "steelblue");
        ColorPickerSkin.cssNameMap.put(Color.TAN, "tan");
        ColorPickerSkin.cssNameMap.put(Color.TEAL, "teal");
        ColorPickerSkin.cssNameMap.put(Color.THISTLE, "thistle");
        ColorPickerSkin.cssNameMap.put(Color.TOMATO, "tomato");
        ColorPickerSkin.cssNameMap.put(Color.TRANSPARENT, "transparent");
        ColorPickerSkin.cssNameMap.put(Color.TURQUOISE, "turquoise");
        ColorPickerSkin.cssNameMap.put(Color.VIOLET, "violet");
        ColorPickerSkin.cssNameMap.put(Color.WHEAT, "wheat");
        ColorPickerSkin.cssNameMap.put(Color.WHITE, "white");
        ColorPickerSkin.cssNameMap.put(Color.WHITESMOKE, "whitesmoke");
        ColorPickerSkin.cssNameMap.put(Color.YELLOW, "yellow");
        ColorPickerSkin.cssNameMap.put(Color.YELLOWGREEN, "yellowgreen");
    }
    
    private class PickerColorBox extends StackPane
    {
        @Override
        protected void layoutChildren() {
            final double snappedTopInset = this.snappedTopInset();
            final double snappedLeftInset = this.snappedLeftInset();
            final double width = this.getWidth();
            final double height = this.getHeight();
            final double snappedRightInset = this.snappedRightInset();
            final double snappedBottomInset = this.snappedBottomInset();
            ColorPickerSkin.this.colorRect.setX(this.snapPosition(ColorPickerSkin.this.colorRectX.get()));
            ColorPickerSkin.this.colorRect.setY(this.snapPosition(ColorPickerSkin.this.colorRectY.get()));
            ColorPickerSkin.this.colorRect.setWidth(this.snapSize(ColorPickerSkin.this.colorRectWidth.get()));
            ColorPickerSkin.this.colorRect.setHeight(this.snapSize(ColorPickerSkin.this.colorRectHeight.get()));
            if (this.getChildren().size() == 2) {
                final ImageView imageView = this.getChildren().get(1);
                final Pos alignment = StackPane.getAlignment(imageView);
                this.layoutInArea(imageView, snappedLeftInset, snappedTopInset, width - snappedLeftInset - snappedRightInset, height - snappedTopInset - snappedBottomInset, 0.0, StackPane.getMargin(imageView), (alignment != null) ? alignment.getHpos() : this.getAlignment().getHpos(), (alignment != null) ? alignment.getVpos() : this.getAlignment().getVpos());
                ColorPickerSkin.this.colorRect.setLayoutX(imageView.getLayoutX());
                ColorPickerSkin.this.colorRect.setLayoutY(imageView.getLayoutY());
            }
            else {
                final Pos alignment2 = StackPane.getAlignment(ColorPickerSkin.this.colorRect);
                this.layoutInArea(ColorPickerSkin.this.colorRect, snappedLeftInset, snappedTopInset, width - snappedLeftInset - snappedRightInset, height - snappedTopInset - snappedBottomInset, 0.0, StackPane.getMargin(ColorPickerSkin.this.colorRect), (alignment2 != null) ? alignment2.getHpos() : this.getAlignment().getHpos(), (alignment2 != null) ? alignment2.getVpos() : this.getAlignment().getVpos());
            }
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<ColorPicker, Boolean> COLOR_LABEL_VISIBLE;
        private static final CssMetaData<ColorPicker, Number> COLOR_RECT_WIDTH;
        private static final CssMetaData<ColorPicker, Number> COLOR_RECT_HEIGHT;
        private static final CssMetaData<ColorPicker, Number> COLOR_RECT_X;
        private static final CssMetaData<ColorPicker, Number> COLOR_RECT_Y;
        private static final CssMetaData<ColorPicker, String> GRAPHIC;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            COLOR_LABEL_VISIBLE = new CssMetaData<ColorPicker, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final ColorPicker colorPicker) {
                    final ColorPickerSkin colorPickerSkin = (ColorPickerSkin)colorPicker.getSkin();
                    return colorPickerSkin.colorLabelVisible == null || !colorPickerSkin.colorLabelVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final ColorPicker colorPicker) {
                    return (StyleableProperty<Boolean>)((ColorPickerSkin)colorPicker.getSkin()).colorLabelVisible;
                }
            };
            COLOR_RECT_WIDTH = new CssMetaData<ColorPicker, Number>((StyleConverter)SizeConverter.getInstance(), (Number)12.0) {
                @Override
                public boolean isSettable(final ColorPicker colorPicker) {
                    return !((ColorPickerSkin)colorPicker.getSkin()).colorRectWidth.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ColorPicker colorPicker) {
                    return ((ColorPickerSkin)colorPicker.getSkin()).colorRectWidth;
                }
            };
            COLOR_RECT_HEIGHT = new CssMetaData<ColorPicker, Number>((StyleConverter)SizeConverter.getInstance(), (Number)12.0) {
                @Override
                public boolean isSettable(final ColorPicker colorPicker) {
                    return !((ColorPickerSkin)colorPicker.getSkin()).colorRectHeight.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ColorPicker colorPicker) {
                    return ((ColorPickerSkin)colorPicker.getSkin()).colorRectHeight;
                }
            };
            COLOR_RECT_X = new CssMetaData<ColorPicker, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0) {
                @Override
                public boolean isSettable(final ColorPicker colorPicker) {
                    return !((ColorPickerSkin)colorPicker.getSkin()).colorRectX.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ColorPicker colorPicker) {
                    return ((ColorPickerSkin)colorPicker.getSkin()).colorRectX;
                }
            };
            COLOR_RECT_Y = new CssMetaData<ColorPicker, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0) {
                @Override
                public boolean isSettable(final ColorPicker colorPicker) {
                    return !((ColorPickerSkin)colorPicker.getSkin()).colorRectY.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ColorPicker colorPicker) {
                    return ((ColorPickerSkin)colorPicker.getSkin()).colorRectY;
                }
            };
            GRAPHIC = new CssMetaData<ColorPicker, String>((StyleConverter)javafx.css.converter.StringConverter.getInstance()) {
                @Override
                public boolean isSettable(final ColorPicker colorPicker) {
                    return !((ColorPickerSkin)colorPicker.getSkin()).imageUrl.isBound();
                }
                
                @Override
                public StyleableProperty<String> getStyleableProperty(final ColorPicker colorPicker) {
                    return ((ColorPickerSkin)colorPicker.getSkin()).imageUrl;
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(SkinBase.getClassCssMetaData());
            list.add(StyleableProperties.COLOR_LABEL_VISIBLE);
            list.add(StyleableProperties.COLOR_RECT_WIDTH);
            list.add(StyleableProperties.COLOR_RECT_HEIGHT);
            list.add(StyleableProperties.COLOR_RECT_X);
            list.add(StyleableProperties.COLOR_RECT_Y);
            list.add(StyleableProperties.GRAPHIC);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
