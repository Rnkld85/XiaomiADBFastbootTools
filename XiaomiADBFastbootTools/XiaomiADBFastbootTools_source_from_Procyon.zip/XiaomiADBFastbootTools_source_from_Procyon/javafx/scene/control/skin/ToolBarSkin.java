// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.util.Collections;
import java.util.ArrayList;
import javafx.css.converter.EnumConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.KeyEvent;
import javafx.geometry.Side;
import javafx.scene.input.KeyCode;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.scene.AccessibleRole;
import javafx.scene.control.ContextMenu;
import javafx.scene.layout.StackPane;
import javafx.collections.ListChangeListener;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Separator;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.css.StyleableObjectProperty;
import javafx.css.CssMetaData;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.css.StyleableDoubleProperty;
import javafx.geometry.Orientation;
import java.util.Iterator;
import java.util.Collection;
import com.sun.javafx.scene.ParentHelper;
import com.sun.javafx.scene.traversal.Direction;
import javafx.scene.Parent;
import com.sun.javafx.scene.NodeHelper;
import javafx.scene.Node;
import com.sun.javafx.scene.traversal.TraversalContext;
import com.sun.javafx.scene.traversal.Algorithm;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import com.sun.javafx.scene.control.behavior.ToolBarBehavior;
import javafx.geometry.Pos;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import com.sun.javafx.scene.traversal.ParentTraversalEngine;
import javafx.scene.control.MenuItem;
import javafx.collections.ObservableList;
import javafx.scene.layout.Pane;
import javafx.scene.control.ToolBar;
import javafx.scene.control.SkinBase;

public class ToolBarSkin extends SkinBase<ToolBar>
{
    private Pane box;
    private ToolBarOverflowMenu overflowMenu;
    private boolean overflow;
    private double previousWidth;
    private double previousHeight;
    private double savedPrefWidth;
    private double savedPrefHeight;
    private ObservableList<MenuItem> overflowMenuItems;
    private boolean needsUpdate;
    private final ParentTraversalEngine engine;
    private final BehaviorBase<ToolBar> behavior;
    private DoubleProperty spacing;
    private ObjectProperty<Pos> boxAlignment;
    
    public ToolBarSkin(final ToolBar toolBar) {
        super(toolBar);
        this.overflow = false;
        this.previousWidth = 0.0;
        this.previousHeight = 0.0;
        this.savedPrefWidth = 0.0;
        this.savedPrefHeight = 0.0;
        this.needsUpdate = false;
        this.behavior = new ToolBarBehavior(toolBar);
        this.overflowMenuItems = FXCollections.observableArrayList();
        this.initialize();
        this.registerChangeListener(toolBar.orientationProperty(), p0 -> this.initialize());
        this.engine = new ParentTraversalEngine(((SkinBase<Parent>)this).getSkinnable(), new Algorithm() {
            private Node selectPrev(final int n, final TraversalContext traversalContext) {
                for (int i = n; i >= 0; --i) {
                    final Node node = ToolBarSkin.this.box.getChildren().get(i);
                    if (!node.isDisabled()) {
                        if (NodeHelper.isTreeShowing(node)) {
                            if (node instanceof Parent) {
                                final Node selectLastInParent = traversalContext.selectLastInParent((Parent)node);
                                if (selectLastInParent != null) {
                                    return selectLastInParent;
                                }
                            }
                            if (node.isFocusTraversable()) {
                                return node;
                            }
                        }
                    }
                }
                return null;
            }
            
            private Node selectNext(final int n, final TraversalContext traversalContext) {
                for (int i = n; i < ToolBarSkin.this.box.getChildren().size(); ++i) {
                    final Node node = ToolBarSkin.this.box.getChildren().get(i);
                    if (!node.isDisabled()) {
                        if (NodeHelper.isTreeShowing(node)) {
                            if (node.isFocusTraversable()) {
                                return node;
                            }
                            if (node instanceof Parent) {
                                final Node selectFirstInParent = traversalContext.selectFirstInParent((Parent)node);
                                if (selectFirstInParent != null) {
                                    return selectFirstInParent;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            
            @Override
            public Node select(final Node node, Direction next_IN_LINE, final TraversalContext traversalContext) {
                final ObservableList<Node> children = ToolBarSkin.this.box.getChildren();
                if (node == ToolBarSkin.this.overflowMenu) {
                    if (next_IN_LINE.isForward()) {
                        return null;
                    }
                    final Node selectPrev = this.selectPrev(children.size() - 1, traversalContext);
                    if (selectPrev != null) {
                        return selectPrev;
                    }
                }
                int n = children.indexOf(node);
                if (n < 0) {
                    Parent parent;
                    for (parent = node.getParent(); !children.contains(parent); parent = parent.getParent()) {}
                    final Node selectInSubtree = traversalContext.selectInSubtree(parent, node, next_IN_LINE);
                    if (selectInSubtree != null) {
                        return selectInSubtree;
                    }
                    n = children.indexOf(parent);
                    if (next_IN_LINE == Direction.NEXT) {
                        next_IN_LINE = Direction.NEXT_IN_LINE;
                    }
                }
                if (n >= 0) {
                    if (next_IN_LINE.isForward()) {
                        final Node selectNext = this.selectNext(n + 1, traversalContext);
                        if (selectNext != null) {
                            return selectNext;
                        }
                        if (ToolBarSkin.this.overflow) {
                            ToolBarSkin.this.overflowMenu.requestFocus();
                            return ToolBarSkin.this.overflowMenu;
                        }
                    }
                    else {
                        final Node selectPrev2 = this.selectPrev(n - 1, traversalContext);
                        if (selectPrev2 != null) {
                            return selectPrev2;
                        }
                    }
                }
                return null;
            }
            
            @Override
            public Node selectFirst(final TraversalContext traversalContext) {
                final Node selectNext = this.selectNext(0, traversalContext);
                if (selectNext != null) {
                    return selectNext;
                }
                if (ToolBarSkin.this.overflow) {
                    return ToolBarSkin.this.overflowMenu;
                }
                return null;
            }
            
            @Override
            public Node selectLast(final TraversalContext traversalContext) {
                if (ToolBarSkin.this.overflow) {
                    return ToolBarSkin.this.overflowMenu;
                }
                return this.selectPrev(ToolBarSkin.this.box.getChildren().size() - 1, traversalContext);
            }
        });
        ParentHelper.setTraversalEngine(((SkinBase<Parent>)this).getSkinnable(), this.engine);
        toolBar.focusedProperty().addListener((p0, p1, b) -> {
            if (b) {
                if (!this.box.getChildren().isEmpty()) {
                    this.box.getChildren().get(0).requestFocus();
                }
                else {
                    this.overflowMenu.requestFocus();
                }
            }
            return;
        });
        final Iterator<Node> iterator;
        toolBar.getItems().addListener(change -> {
            while (change.next()) {
                change.getRemoved().iterator();
                while (iterator.hasNext()) {
                    this.box.getChildren().remove(iterator.next());
                }
                this.box.getChildren().addAll((Collection<?>)change.getAddedSubList());
            }
            this.needsUpdate = true;
            this.getSkinnable().requestLayout();
        });
    }
    
    private double snapSpacing(final double n) {
        if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
            return this.snapSpaceY(n);
        }
        return this.snapSpaceX(n);
    }
    
    private final void setSpacing(final double n) {
        this.spacingProperty().set(this.snapSpacing(n));
    }
    
    private final double getSpacing() {
        return (this.spacing == null) ? 0.0 : this.snapSpacing(this.spacing.get());
    }
    
    private final DoubleProperty spacingProperty() {
        if (this.spacing == null) {
            this.spacing = new StyleableDoubleProperty() {
                @Override
                protected void invalidated() {
                    final double value = this.get();
                    if (ToolBarSkin.this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                        ((VBox)ToolBarSkin.this.box).setSpacing(value);
                    }
                    else {
                        ((HBox)ToolBarSkin.this.box).setSpacing(value);
                    }
                }
                
                @Override
                public Object getBean() {
                    return ToolBarSkin.this;
                }
                
                @Override
                public String getName() {
                    return "spacing";
                }
                
                @Override
                public CssMetaData<ToolBar, Number> getCssMetaData() {
                    return StyleableProperties.SPACING;
                }
            };
        }
        return this.spacing;
    }
    
    private final void setBoxAlignment(final Pos pos) {
        this.boxAlignmentProperty().set(pos);
    }
    
    private final Pos getBoxAlignment() {
        return (this.boxAlignment == null) ? Pos.TOP_LEFT : this.boxAlignment.get();
    }
    
    private final ObjectProperty<Pos> boxAlignmentProperty() {
        if (this.boxAlignment == null) {
            this.boxAlignment = new StyleableObjectProperty<Pos>(Pos.TOP_LEFT) {
                public void invalidated() {
                    final Pos pos = this.get();
                    if (ToolBarSkin.this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                        ((VBox)ToolBarSkin.this.box).setAlignment(pos);
                    }
                    else {
                        ((HBox)ToolBarSkin.this.box).setAlignment(pos);
                    }
                }
                
                @Override
                public Object getBean() {
                    return ToolBarSkin.this;
                }
                
                @Override
                public String getName() {
                    return "boxAlignment";
                }
                
                @Override
                public CssMetaData<ToolBar, Pos> getCssMetaData() {
                    return StyleableProperties.ALIGNMENT;
                }
            };
        }
        return this.boxAlignment;
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return (this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? this.computePrefWidth(-1.0, n2, n3, n4, n5) : (this.snapSizeX(this.overflowMenu.prefWidth(-1.0)) + n5 + n3);
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return (this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? (this.snapSizeY(this.overflowMenu.prefHeight(-1.0)) + n2 + n4) : this.computePrefHeight(-1.0, n2, n3, n4, n5);
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        final ToolBar toolBar = this.getSkinnable();
        if (toolBar.getOrientation() == Orientation.HORIZONTAL) {
            for (final Node node : toolBar.getItems()) {
                if (!node.isManaged()) {
                    continue;
                }
                n6 += this.snapSizeX(node.prefWidth(-1.0)) + this.getSpacing();
            }
            n6 -= this.getSpacing();
        }
        else {
            for (final Node node2 : toolBar.getItems()) {
                if (!node2.isManaged()) {
                    continue;
                }
                n6 = Math.max(n6, this.snapSizeX(node2.prefWidth(-1.0)));
            }
            if (toolBar.getItems().size() > 0) {
                this.savedPrefWidth = n6;
            }
            else {
                n6 = this.savedPrefWidth;
            }
        }
        return n5 + n6 + n3;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        final ToolBar toolBar = this.getSkinnable();
        if (toolBar.getOrientation() == Orientation.VERTICAL) {
            for (final Node node : toolBar.getItems()) {
                if (!node.isManaged()) {
                    continue;
                }
                n6 += this.snapSizeY(node.prefHeight(-1.0)) + this.getSpacing();
            }
            n6 -= this.getSpacing();
        }
        else {
            for (final Node node2 : toolBar.getItems()) {
                if (!node2.isManaged()) {
                    continue;
                }
                n6 = Math.max(n6, this.snapSizeY(node2.prefHeight(-1.0)));
            }
            if (toolBar.getItems().size() > 0) {
                this.savedPrefHeight = n6;
            }
            else {
                n6 = this.savedPrefHeight;
            }
        }
        return n2 + n6 + n4;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return (this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? this.snapSizeX(this.getSkinnable().prefWidth(-1.0)) : Double.MAX_VALUE;
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return (this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? Double.MAX_VALUE : this.snapSizeY(this.getSkinnable().prefHeight(-1.0));
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        final ToolBar toolBar = this.getSkinnable();
        if (toolBar.getOrientation() == Orientation.VERTICAL) {
            if (this.snapSizeY(toolBar.getHeight()) != this.previousHeight || this.needsUpdate) {
                ((VBox)this.box).setSpacing(this.getSpacing());
                ((VBox)this.box).setAlignment(this.getBoxAlignment());
                this.previousHeight = this.snapSizeY(toolBar.getHeight());
                this.addNodesToToolBar();
            }
        }
        else if (this.snapSizeX(toolBar.getWidth()) != this.previousWidth || this.needsUpdate) {
            ((HBox)this.box).setSpacing(this.getSpacing());
            ((HBox)this.box).setAlignment(this.getBoxAlignment());
            this.previousWidth = this.snapSizeX(toolBar.getWidth());
            this.addNodesToToolBar();
        }
        this.needsUpdate = false;
        double savedPrefWidth = n3;
        double savedPrefHeight = n4;
        if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
            savedPrefHeight -= (this.overflow ? this.snapSizeY(this.overflowMenu.prefHeight(-1.0)) : 0.0);
        }
        else {
            savedPrefWidth -= (this.overflow ? this.snapSizeX(this.overflowMenu.prefWidth(-1.0)) : 0.0);
        }
        this.box.resize(savedPrefWidth, savedPrefHeight);
        this.positionInArea(this.box, n, n2, savedPrefWidth, savedPrefHeight, 0.0, HPos.CENTER, VPos.CENTER);
        if (this.overflow) {
            final double snapSizeX = this.snapSizeX(this.overflowMenu.prefWidth(-1.0));
            final double snapSizeY = this.snapSizeY(this.overflowMenu.prefHeight(-1.0));
            double n5;
            double n6;
            if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                if (savedPrefWidth == 0.0) {
                    savedPrefWidth = this.savedPrefWidth;
                }
                final HPos hpos = ((VBox)this.box).getAlignment().getHpos();
                if (HPos.LEFT.equals(hpos)) {
                    n5 = n + Math.abs((savedPrefWidth - snapSizeX) / 2.0);
                }
                else if (HPos.RIGHT.equals(hpos)) {
                    n5 = this.snapSizeX(toolBar.getWidth()) - this.snappedRightInset() - savedPrefWidth + Math.abs((savedPrefWidth - snapSizeX) / 2.0);
                }
                else {
                    n5 = n + Math.abs((this.snapSizeX(toolBar.getWidth()) - n + this.snappedRightInset() - snapSizeX) / 2.0);
                }
                n6 = this.snapSizeY(toolBar.getHeight()) - snapSizeY - n2;
            }
            else {
                if (savedPrefHeight == 0.0) {
                    savedPrefHeight = this.savedPrefHeight;
                }
                final VPos vpos = ((HBox)this.box).getAlignment().getVpos();
                if (VPos.TOP.equals(vpos)) {
                    n6 = n2 + Math.abs((savedPrefHeight - snapSizeY) / 2.0);
                }
                else if (VPos.BOTTOM.equals(vpos)) {
                    n6 = this.snapSizeY(toolBar.getHeight()) - this.snappedBottomInset() - savedPrefHeight + Math.abs((savedPrefHeight - snapSizeY) / 2.0);
                }
                else {
                    n6 = n2 + Math.abs((savedPrefHeight - snapSizeY) / 2.0);
                }
                n5 = this.snapSizeX(toolBar.getWidth()) - snapSizeX - this.snappedRightInset();
            }
            this.overflowMenu.resize(snapSizeX, snapSizeY);
            this.positionInArea(this.overflowMenu, n5, n6, snapSizeX, snapSizeY, 0.0, HPos.CENTER, VPos.CENTER);
        }
    }
    
    private void initialize() {
        if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
            this.box = new VBox();
        }
        else {
            this.box = new HBox();
        }
        this.box.getStyleClass().add("container");
        this.box.getChildren().addAll((Collection<?>)this.getSkinnable().getItems());
        (this.overflowMenu = new ToolBarOverflowMenu(this.overflowMenuItems)).setVisible(false);
        this.overflowMenu.setManaged(false);
        this.getChildren().clear();
        this.getChildren().add(this.box);
        this.getChildren().add(this.overflowMenu);
        this.previousWidth = 0.0;
        this.previousHeight = 0.0;
        this.savedPrefWidth = 0.0;
        this.savedPrefHeight = 0.0;
        this.needsUpdate = true;
        this.getSkinnable().requestLayout();
    }
    
    private void addNodesToToolBar() {
        final ToolBar toolBar = this.getSkinnable();
        double n;
        if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
            n = this.snapSizeY(toolBar.getHeight()) - this.snappedTopInset() - this.snappedBottomInset() + this.getSpacing();
        }
        else {
            n = this.snapSizeX(toolBar.getWidth()) - this.snappedLeftInset() - this.snappedRightInset() + this.getSpacing();
        }
        double n2 = 0.0;
        boolean b = false;
        for (final Node node : this.getSkinnable().getItems()) {
            if (!node.isManaged()) {
                continue;
            }
            if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                n2 += this.snapSizeY(node.prefHeight(-1.0)) + this.getSpacing();
            }
            else {
                n2 += this.snapSizeX(node.prefWidth(-1.0)) + this.getSpacing();
            }
            if (n2 > n) {
                b = true;
                break;
            }
        }
        if (b) {
            double n3;
            if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                n3 = n - this.snapSizeY(this.overflowMenu.prefHeight(-1.0));
            }
            else {
                n3 = n - this.snapSizeX(this.overflowMenu.prefWidth(-1.0));
            }
            n = n3 - this.getSpacing();
        }
        double n4 = 0.0;
        this.overflowMenuItems.clear();
        this.box.getChildren().clear();
        for (final Node node2 : this.getSkinnable().getItems()) {
            node2.getStyleClass().remove("menu-item");
            node2.getStyleClass().remove("custom-menu-item");
            if (node2.isManaged()) {
                if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                    n4 += this.snapSizeY(node2.prefHeight(-1.0)) + this.getSpacing();
                }
                else {
                    n4 += this.snapSizeX(node2.prefWidth(-1.0)) + this.getSpacing();
                }
            }
            if (n4 <= n) {
                this.box.getChildren().add(node2);
            }
            else {
                if (node2.isFocused()) {
                    if (!this.box.getChildren().isEmpty()) {
                        final Node selectLast = this.engine.selectLast();
                        if (selectLast != null) {
                            selectLast.requestFocus();
                        }
                    }
                    else {
                        this.overflowMenu.requestFocus();
                    }
                }
                if (node2 instanceof Separator) {
                    this.overflowMenuItems.add(new SeparatorMenuItem());
                }
                else {
                    final CustomMenuItem customMenuItem = new CustomMenuItem(node2);
                    final String typeSelector = node2.getTypeSelector();
                    switch (typeSelector) {
                        case "Button":
                        case "Hyperlink":
                        case "Label": {
                            customMenuItem.setHideOnClick(true);
                            break;
                        }
                        default: {
                            customMenuItem.setHideOnClick(false);
                            break;
                        }
                    }
                    this.overflowMenuItems.add(customMenuItem);
                }
            }
        }
        this.overflow = (this.overflowMenuItems.size() > 0);
        if (!this.overflow && this.overflowMenu.isFocused()) {
            final Node selectLast2 = this.engine.selectLast();
            if (selectLast2 != null) {
                selectLast2.requestFocus();
            }
        }
        this.overflowMenu.setVisible(this.overflow);
        this.overflowMenu.setManaged(this.overflow);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case OVERFLOW_BUTTON: {
                return this.overflowMenu;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    protected void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case SHOW_MENU: {
                this.overflowMenu.fire();
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    class ToolBarOverflowMenu extends StackPane
    {
        private StackPane downArrow;
        private ContextMenu popup;
        private ObservableList<MenuItem> menuItems;
        
        public ToolBarOverflowMenu(final ObservableList<MenuItem> menuItems) {
            this.getStyleClass().setAll("tool-bar-overflow-button");
            this.setAccessibleRole(AccessibleRole.BUTTON);
            this.setAccessibleText(ControlResources.getString("Accessibility.title.ToolBar.OverflowButton"));
            this.setFocusTraversable(true);
            this.menuItems = menuItems;
            this.downArrow = new StackPane();
            this.downArrow.getStyleClass().setAll("arrow");
            this.downArrow.setOnMousePressed(p0 -> this.fire());
            this.setOnKeyPressed(keyEvent -> {
                if (KeyCode.SPACE.equals(keyEvent.getCode())) {
                    if (!this.popup.isShowing()) {
                        this.popup.getItems().clear();
                        this.popup.getItems().addAll((Collection<?>)this.menuItems);
                        this.popup.show(this.downArrow, Side.BOTTOM, 0.0, 0.0);
                    }
                    keyEvent.consume();
                }
                else if (KeyCode.ESCAPE.equals(keyEvent.getCode())) {
                    if (this.popup.isShowing()) {
                        this.popup.hide();
                    }
                    keyEvent.consume();
                }
                else if (KeyCode.ENTER.equals(keyEvent.getCode())) {
                    this.fire();
                    keyEvent.consume();
                }
                return;
            });
            this.visibleProperty().addListener((p0, p1, b) -> {
                if (b && ToolBarSkin.this.box.getChildren().isEmpty()) {
                    this.setFocusTraversable(true);
                }
                return;
            });
            this.popup = new ContextMenu();
            this.setVisible(false);
            this.setManaged(false);
            this.getChildren().add(this.downArrow);
        }
        
        private void fire() {
            if (this.popup.isShowing()) {
                this.popup.hide();
            }
            else {
                this.popup.getItems().clear();
                this.popup.getItems().addAll((Collection<?>)this.menuItems);
                this.popup.show(this.downArrow, Side.BOTTOM, 0.0, 0.0);
            }
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            return this.snappedLeftInset() + this.snappedRightInset();
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            return this.snappedTopInset() + this.snappedBottomInset();
        }
        
        @Override
        protected void layoutChildren() {
            final double snapSize = this.snapSize(this.downArrow.prefWidth(-1.0));
            final double snapSize2 = this.snapSize(this.downArrow.prefHeight(-1.0));
            final double n = (this.snapSize(this.getWidth()) - snapSize) / 2.0;
            final double n2 = (this.snapSize(this.getHeight()) - snapSize2) / 2.0;
            if (ToolBarSkin.this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                this.downArrow.setRotate(0.0);
            }
            this.downArrow.resize(snapSize, snapSize2);
            this.positionInArea(this.downArrow, n, n2, snapSize, snapSize2, 0.0, HPos.CENTER, VPos.CENTER);
        }
        
        @Override
        public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
            switch (accessibleAction) {
                case FIRE: {
                    this.fire();
                    break;
                }
                default: {
                    super.executeAccessibleAction(accessibleAction, new Object[0]);
                    break;
                }
            }
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<ToolBar, Number> SPACING;
        private static final CssMetaData<ToolBar, Pos> ALIGNMENT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            SPACING = new CssMetaData<ToolBar, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final ToolBar toolBar) {
                    final ToolBarSkin toolBarSkin = (ToolBarSkin)toolBar.getSkin();
                    return toolBarSkin.spacing == null || !toolBarSkin.spacing.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ToolBar toolBar) {
                    return (StyleableProperty<Number>)((ToolBarSkin)toolBar.getSkin()).spacingProperty();
                }
            };
            ALIGNMENT = new CssMetaData<ToolBar, Pos>((StyleConverter)new EnumConverter(Pos.class), Pos.TOP_LEFT) {
                @Override
                public boolean isSettable(final ToolBar toolBar) {
                    final ToolBarSkin toolBarSkin = (ToolBarSkin)toolBar.getSkin();
                    return toolBarSkin.boxAlignment == null || !toolBarSkin.boxAlignment.isBound();
                }
                
                @Override
                public StyleableProperty<Pos> getStyleableProperty(final ToolBar toolBar) {
                    return (StyleableProperty<Pos>)(StyleableProperty)((ToolBarSkin)toolBar.getSkin()).boxAlignmentProperty();
                }
            };
            final ArrayList<Object> list = new ArrayList<Object>(SkinBase.getClassCssMetaData());
            final String property = StyleableProperties.ALIGNMENT.getProperty();
            for (int i = 0; i < list.size(); ++i) {
                final CssMetaData cssMetaData = list.get(i);
                if (property.equals(cssMetaData.getProperty())) {
                    list.remove(cssMetaData);
                }
            }
            list.add(StyleableProperties.SPACING);
            list.add(StyleableProperties.ALIGNMENT);
            STYLEABLES = Collections.unmodifiableList((List<? extends CssMetaData<? extends Styleable, ?>>)list);
        }
    }
}
