// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.SizeConverter;
import javafx.css.converter.EnumConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.scene.AccessibleAction;
import javafx.scene.control.Tooltip;
import javafx.scene.AccessibleRole;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;
import javafx.scene.control.ToggleButton;
import javafx.scene.text.Font;
import javafx.geometry.Pos;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.scene.control.Toggle;
import java.util.Iterator;
import javafx.geometry.Insets;
import javafx.scene.control.Control;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.event.EventType;
import java.util.Objects;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.beans.Observable;
import javafx.css.Styleable;
import java.util.List;
import javafx.application.Platform;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.animation.KeyFrame;
import javafx.scene.layout.Region;
import javafx.scene.input.TouchEvent;
import javafx.scene.AccessibleAttribute;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.css.StyleableObjectProperty;
import javafx.css.StyleableBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.event.Event;
import javafx.geometry.Side;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import com.sun.javafx.scene.control.behavior.PaginationBehavior;
import javafx.scene.shape.Rectangle;
import javafx.animation.Timeline;
import javafx.scene.layout.StackPane;
import javafx.animation.Interpolator;
import javafx.util.Duration;
import javafx.scene.control.Pagination;
import javafx.scene.control.SkinBase;

public class PaginationSkin extends SkinBase<Pagination>
{
    private static final Duration DURATION;
    private static final double SWIPE_THRESHOLD = 0.3;
    private static final double TOUCH_THRESHOLD = 15.0;
    private static final Interpolator interpolator;
    private Pagination pagination;
    private StackPane currentStackPane;
    private StackPane nextStackPane;
    private Timeline timeline;
    private Rectangle clipRect;
    private NavigationControl navigation;
    private int fromIndex;
    private int previousIndex;
    private int currentIndex;
    private int toIndex;
    private int pageCount;
    private int maxPageIndicatorCount;
    private double startTouchPos;
    private double lastTouchPos;
    private long startTouchTime;
    private long lastTouchTime;
    private double touchVelocity;
    private boolean touchThresholdBroken;
    private int touchEventId;
    private boolean nextPageReached;
    private boolean setInitialDirection;
    private int direction;
    private int currentAnimatedIndex;
    private boolean hasPendingAnimation;
    private boolean animate;
    private final PaginationBehavior behavior;
    private EventHandler<ActionEvent> swipeAnimationEndEventHandler;
    private EventHandler<ActionEvent> clampAnimationEndEventHandler;
    private final DoubleProperty arrowButtonGap;
    private BooleanProperty arrowsVisible;
    private BooleanProperty pageInformationVisible;
    private ObjectProperty<Side> pageInformationAlignment;
    private BooleanProperty tooltipVisible;
    private static final Boolean DEFAULT_ARROW_VISIBLE;
    private static final Boolean DEFAULT_PAGE_INFORMATION_VISIBLE;
    private static final Side DEFAULT_PAGE_INFORMATION_ALIGNMENT;
    private static final Boolean DEFAULT_TOOLTIP_VISIBLE;
    
    public PaginationSkin(final Pagination pagination) {
        super(pagination);
        this.touchEventId = -1;
        this.nextPageReached = false;
        this.setInitialDirection = false;
        this.hasPendingAnimation = false;
        this.animate = true;
        this.swipeAnimationEndEventHandler = new EventHandler<ActionEvent>() {
            @Override
            public void handle(final ActionEvent actionEvent) {
                PaginationSkin.this.swapPanes();
                PaginationSkin.this.timeline = null;
                if (PaginationSkin.this.hasPendingAnimation) {
                    PaginationSkin.this.animateSwitchPage();
                    PaginationSkin.this.hasPendingAnimation = false;
                }
            }
        };
        this.clampAnimationEndEventHandler = new EventHandler<ActionEvent>() {
            @Override
            public void handle(final ActionEvent actionEvent) {
                PaginationSkin.this.currentStackPane.setTranslateX(0.0);
                PaginationSkin.this.nextStackPane.setTranslateX(0.0);
                PaginationSkin.this.nextStackPane.setVisible(false);
                PaginationSkin.this.timeline = null;
            }
        };
        this.arrowButtonGap = new StyleableDoubleProperty(60.0) {
            @Override
            public Object getBean() {
                return PaginationSkin.this;
            }
            
            @Override
            public String getName() {
                return "arrowButtonGap";
            }
            
            @Override
            public CssMetaData<Pagination, Number> getCssMetaData() {
                return StyleableProperties.ARROW_BUTTON_GAP;
            }
        };
        this.behavior = new PaginationBehavior(pagination);
        this.clipRect = new Rectangle();
        this.getSkinnable().setClip(this.clipRect);
        this.pagination = pagination;
        this.currentStackPane = new StackPane();
        this.currentStackPane.getStyleClass().add("page");
        this.nextStackPane = new StackPane();
        this.nextStackPane.getStyleClass().add("page");
        this.nextStackPane.setVisible(false);
        this.resetIndexes(true);
        this.navigation = new NavigationControl();
        this.getChildren().addAll(this.currentStackPane, this.nextStackPane, this.navigation);
        pagination.maxPageIndicatorCountProperty().addListener(p0 -> this.resetIndiciesAndNav());
        this.registerChangeListener(pagination.widthProperty(), p0 -> this.clipRect.setWidth(this.getSkinnable().getWidth()));
        this.registerChangeListener(pagination.heightProperty(), p0 -> this.clipRect.setHeight(this.getSkinnable().getHeight()));
        this.registerChangeListener(pagination.pageCountProperty(), p0 -> this.resetIndiciesAndNav());
        this.registerChangeListener(pagination.pageFactoryProperty(), p0 -> {
            if (this.animate && this.timeline != null) {
                this.timeline.setRate(8.0);
                this.timeline.setOnFinished(p0 -> this.resetIndiciesAndNav());
                return;
            }
            else {
                this.resetIndiciesAndNav();
                return;
            }
        });
        this.initializeSwipeAndTouchHandlers();
    }
    
    private final DoubleProperty arrowButtonGapProperty() {
        return this.arrowButtonGap;
    }
    
    private final double getArrowButtonGap() {
        return this.arrowButtonGap.get();
    }
    
    private final void setArrowButtonGap(final double n) {
        this.arrowButtonGap.set(n);
    }
    
    private final void setArrowsVisible(final boolean b) {
        this.arrowsVisibleProperty().set(b);
    }
    
    private final boolean isArrowsVisible() {
        return (this.arrowsVisible == null) ? PaginationSkin.DEFAULT_ARROW_VISIBLE : this.arrowsVisible.get();
    }
    
    private final BooleanProperty arrowsVisibleProperty() {
        if (this.arrowsVisible == null) {
            this.arrowsVisible = new StyleableBooleanProperty((boolean)PaginationSkin.DEFAULT_ARROW_VISIBLE) {
                @Override
                protected void invalidated() {
                    PaginationSkin.this.getSkinnable().requestLayout();
                }
                
                @Override
                public CssMetaData<Pagination, Boolean> getCssMetaData() {
                    return StyleableProperties.ARROWS_VISIBLE;
                }
                
                @Override
                public Object getBean() {
                    return PaginationSkin.this;
                }
                
                @Override
                public String getName() {
                    return "arrowVisible";
                }
            };
        }
        return this.arrowsVisible;
    }
    
    private final void setPageInformationVisible(final boolean b) {
        this.pageInformationVisibleProperty().set(b);
    }
    
    private final boolean isPageInformationVisible() {
        return (this.pageInformationVisible == null) ? PaginationSkin.DEFAULT_PAGE_INFORMATION_VISIBLE : this.pageInformationVisible.get();
    }
    
    private final BooleanProperty pageInformationVisibleProperty() {
        if (this.pageInformationVisible == null) {
            this.pageInformationVisible = new StyleableBooleanProperty((boolean)PaginationSkin.DEFAULT_PAGE_INFORMATION_VISIBLE) {
                @Override
                protected void invalidated() {
                    PaginationSkin.this.getSkinnable().requestLayout();
                }
                
                @Override
                public CssMetaData<Pagination, Boolean> getCssMetaData() {
                    return StyleableProperties.PAGE_INFORMATION_VISIBLE;
                }
                
                @Override
                public Object getBean() {
                    return PaginationSkin.this;
                }
                
                @Override
                public String getName() {
                    return "pageInformationVisible";
                }
            };
        }
        return this.pageInformationVisible;
    }
    
    private final void setPageInformationAlignment(final Side side) {
        this.pageInformationAlignmentProperty().set(side);
    }
    
    private final Side getPageInformationAlignment() {
        return (this.pageInformationAlignment == null) ? PaginationSkin.DEFAULT_PAGE_INFORMATION_ALIGNMENT : this.pageInformationAlignment.get();
    }
    
    private final ObjectProperty<Side> pageInformationAlignmentProperty() {
        if (this.pageInformationAlignment == null) {
            this.pageInformationAlignment = new StyleableObjectProperty<Side>(Side.BOTTOM) {
                @Override
                protected void invalidated() {
                    PaginationSkin.this.getSkinnable().requestLayout();
                }
                
                @Override
                public CssMetaData<Pagination, Side> getCssMetaData() {
                    return StyleableProperties.PAGE_INFORMATION_ALIGNMENT;
                }
                
                @Override
                public Object getBean() {
                    return PaginationSkin.this;
                }
                
                @Override
                public String getName() {
                    return "pageInformationAlignment";
                }
            };
        }
        return this.pageInformationAlignment;
    }
    
    private final void setTooltipVisible(final boolean b) {
        this.tooltipVisibleProperty().set(b);
    }
    
    private final boolean isTooltipVisible() {
        return (this.tooltipVisible == null) ? PaginationSkin.DEFAULT_TOOLTIP_VISIBLE : this.tooltipVisible.get();
    }
    
    private final BooleanProperty tooltipVisibleProperty() {
        if (this.tooltipVisible == null) {
            this.tooltipVisible = new StyleableBooleanProperty((boolean)PaginationSkin.DEFAULT_TOOLTIP_VISIBLE) {
                @Override
                protected void invalidated() {
                    PaginationSkin.this.getSkinnable().requestLayout();
                }
                
                @Override
                public CssMetaData<Pagination, Boolean> getCssMetaData() {
                    return StyleableProperties.TOOLTIP_VISIBLE;
                }
                
                @Override
                public Object getBean() {
                    return PaginationSkin.this;
                }
                
                @Override
                public String getName() {
                    return "tooltipVisible";
                }
            };
        }
        return this.tooltipVisible;
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n5 + Math.max(this.currentStackPane.minWidth(n), this.navigation.isVisible() ? this.snapSizeX(this.navigation.minWidth(n)) : 0.0) + n3;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n2 + this.currentStackPane.minHeight(n) + (this.navigation.isVisible() ? this.snapSizeY(this.navigation.minHeight(n)) : 0.0) + n4;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n5 + Math.max(this.currentStackPane.prefWidth(n), this.navigation.isVisible() ? this.snapSizeX(this.navigation.prefWidth(n)) : 0.0) + n3;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n2 + this.currentStackPane.prefHeight(n) + (this.navigation.isVisible() ? this.snapSizeY(this.navigation.prefHeight(n)) : 0.0) + n4;
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        final double n5 = this.navigation.isVisible() ? this.snapSizeY(this.navigation.prefHeight(-1.0)) : 0.0;
        final double snapSizeY = this.snapSizeY(n4 - n5);
        this.layoutInArea(this.currentStackPane, n, n2, n3, snapSizeY, 0.0, HPos.CENTER, VPos.CENTER);
        this.layoutInArea(this.nextStackPane, n, n2, n3, snapSizeY, 0.0, HPos.CENTER, VPos.CENTER);
        this.layoutInArea(this.navigation, n, snapSizeY, n3, n5, 0.0, HPos.CENTER, VPos.CENTER);
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case FOCUS_ITEM: {
                return this.navigation.indicatorButtons.getSelectedToggle();
            }
            case ITEM_COUNT: {
                return this.navigation.indicatorButtons.getToggles().size();
            }
            case ITEM_AT_INDEX: {
                final Integer n = (Integer)array[0];
                if (n == null) {
                    return null;
                }
                return this.navigation.indicatorButtons.getToggles().get(n);
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    private void selectNext() {
        if (this.getCurrentPageIndex() < this.getPageCount() - 1) {
            this.pagination.setCurrentPageIndex(this.getCurrentPageIndex() + 1);
        }
    }
    
    private void selectPrevious() {
        if (this.getCurrentPageIndex() > 0) {
            this.pagination.setCurrentPageIndex(this.getCurrentPageIndex() - 1);
        }
    }
    
    private void resetIndiciesAndNav() {
        this.resetIndexes(false);
        this.navigation.initializePageIndicators();
        this.navigation.updatePageIndicators();
    }
    
    private void initializeSwipeAndTouchHandlers() {
        final Pagination pagination = this.getSkinnable();
        final double n;
        final long n2;
        this.getSkinnable().addEventHandler(TouchEvent.TOUCH_PRESSED, touchEvent -> {
            if (this.touchEventId == -1) {
                this.touchEventId = touchEvent.getTouchPoint().getId();
            }
            if (this.touchEventId != touchEvent.getTouchPoint().getId()) {
                return;
            }
            else {
                touchEvent.getTouchPoint().getX();
                this.startTouchPos = n;
                this.lastTouchPos = n;
                System.currentTimeMillis();
                this.startTouchTime = n2;
                this.lastTouchTime = n2;
                this.touchThresholdBroken = false;
                touchEvent.consume();
                return;
            }
        });
        double a;
        final Region region;
        double n3;
        final double translateX;
        final double translateX2;
        final double translateX3;
        final double translateX4;
        this.getSkinnable().addEventHandler(TouchEvent.TOUCH_MOVED, touchEvent2 -> {
            if (this.touchEventId != touchEvent2.getTouchPoint().getId()) {
                return;
            }
            else {
                this.touchVelocity = (touchEvent2.getTouchPoint().getX() - this.lastTouchPos) / (System.currentTimeMillis() - this.lastTouchTime);
                this.lastTouchPos = touchEvent2.getTouchPoint().getX();
                this.lastTouchTime = System.currentTimeMillis();
                a = touchEvent2.getTouchPoint().getX() - this.startTouchPos;
                if (!this.touchThresholdBroken && Math.abs(a) > 15.0) {
                    this.touchThresholdBroken = true;
                }
                if (this.touchThresholdBroken) {
                    n3 = region.getWidth() - (this.snappedLeftInset() + this.snappedRightInset());
                    if (!this.setInitialDirection) {
                        this.setInitialDirection = true;
                        this.direction = ((a < 0.0) ? 1 : -1);
                    }
                    if (a < 0.0) {
                        if (this.direction == -1) {
                            this.nextStackPane.getChildren().clear();
                            this.direction = 1;
                        }
                        if (Math.abs(a) <= n3) {
                            this.nextPageReached = false;
                        }
                        else {
                            this.nextPageReached = true;
                        }
                        this.currentStackPane.setTranslateX(translateX);
                        if (this.getCurrentPageIndex() < this.getPageCount() - 1) {
                            this.createPage(this.nextStackPane, this.currentIndex + 1);
                            this.nextStackPane.setVisible(true);
                            this.nextStackPane.setTranslateX(translateX2);
                        }
                        else {
                            this.currentStackPane.setTranslateX(0.0);
                        }
                    }
                    else {
                        if (this.direction == 1) {
                            this.nextStackPane.getChildren().clear();
                            this.direction = -1;
                        }
                        if (Math.abs(a) <= n3) {
                            this.nextPageReached = false;
                        }
                        else {
                            this.nextPageReached = true;
                        }
                        this.currentStackPane.setTranslateX(translateX3);
                        if (this.getCurrentPageIndex() != 0) {
                            this.createPage(this.nextStackPane, this.currentIndex - 1);
                            this.nextStackPane.setVisible(true);
                            this.nextStackPane.setTranslateX(translateX4);
                        }
                        else {
                            this.currentStackPane.setTranslateX(0.0);
                        }
                    }
                }
                touchEvent2.consume();
                return;
            }
        });
        double n4;
        long n5;
        double n6;
        final Region region2;
        double n7;
        final double n8;
        final double n9;
        this.getSkinnable().addEventHandler(TouchEvent.TOUCH_RELEASED, touchEvent3 -> {
            if (this.touchEventId == touchEvent3.getTouchPoint().getId()) {
                this.touchEventId = -1;
                this.setInitialDirection = false;
                if (this.touchThresholdBroken) {
                    n4 = touchEvent3.getTouchPoint().getX() - this.startTouchPos;
                    n5 = System.currentTimeMillis() - this.startTouchTime;
                    n6 = ((n5 < 300L) ? (n4 / n5) : this.touchVelocity) * 500.0;
                    n7 = region2.getWidth() - (this.snappedLeftInset() + this.snappedRightInset());
                    Math.abs(n6 / n7);
                    Math.abs(n4 / n7);
                    if (n8 > 0.3 || n9 > 0.3) {
                        if (this.startTouchPos > touchEvent3.getTouchPoint().getX()) {
                            this.selectNext();
                        }
                        else {
                            this.selectPrevious();
                        }
                    }
                    else {
                        this.animateClamping(this.startTouchPos > touchEvent3.getTouchPoint().getSceneX());
                    }
                }
                touchEvent3.consume();
            }
        });
    }
    
    private void resetIndexes(final boolean b) {
        this.maxPageIndicatorCount = this.getMaxPageIndicatorCount();
        this.pageCount = this.getPageCount();
        if (this.pageCount > this.maxPageIndicatorCount) {
            this.pageCount = this.maxPageIndicatorCount;
        }
        this.fromIndex = 0;
        this.previousIndex = 0;
        this.currentIndex = (b ? this.getCurrentPageIndex() : 0);
        this.toIndex = this.pageCount - 1;
        if (this.pageCount == Integer.MAX_VALUE && this.maxPageIndicatorCount == Integer.MAX_VALUE) {
            this.toIndex = 0;
        }
        final boolean animate = this.animate;
        if (animate) {
            this.animate = false;
        }
        this.currentStackPane.getChildren().clear();
        this.nextStackPane.getChildren().clear();
        this.pagination.setCurrentPageIndex(this.currentIndex);
        this.createPage(this.currentStackPane, this.currentIndex);
        if (animate) {
            this.animate = true;
        }
    }
    
    private boolean createPage(final StackPane stackPane, final int i) {
        if (this.pagination.getPageFactory() == null || !stackPane.getChildren().isEmpty()) {
            return false;
        }
        final Node node = this.pagination.getPageFactory().call(i);
        if (node != null) {
            stackPane.getChildren().setAll(node);
            return true;
        }
        final boolean animate = this.animate;
        if (animate) {
            this.animate = false;
        }
        if (this.pagination.getPageFactory().call(this.previousIndex) != null) {
            this.pagination.setCurrentPageIndex(this.previousIndex);
        }
        else {
            this.pagination.setCurrentPageIndex(0);
        }
        if (animate) {
            this.animate = true;
        }
        return false;
    }
    
    private int getPageCount() {
        if (this.getSkinnable().getPageCount() < 1) {
            return 1;
        }
        return this.getSkinnable().getPageCount();
    }
    
    private int getMaxPageIndicatorCount() {
        return this.getSkinnable().getMaxPageIndicatorCount();
    }
    
    private int getCurrentPageIndex() {
        return this.getSkinnable().getCurrentPageIndex();
    }
    
    private void animateSwitchPage() {
        if (this.timeline != null) {
            this.timeline.setRate(8.0);
            this.hasPendingAnimation = true;
            return;
        }
        if (!this.nextStackPane.isVisible() && !this.createPage(this.nextStackPane, this.currentAnimatedIndex)) {
            return;
        }
        if (this.nextPageReached) {
            this.swapPanes();
            this.nextPageReached = false;
            return;
        }
        this.nextStackPane.setCache(true);
        this.currentStackPane.setCache(true);
        final boolean b;
        KeyValue[] array;
        final KeyValue keyValue;
        final Object o;
        final KeyValue keyValue2;
        final Object o2;
        final Duration duration;
        final KeyFrame keyFrame2;
        final KeyFrame keyFrame3;
        KeyValue[] array2;
        final KeyValue keyValue3;
        final Object o4;
        final KeyValue keyValue4;
        final Object o5;
        final Duration duration2;
        final KeyFrame keyFrame5;
        final KeyFrame keyFrame6;
        Platform.runLater(() -> {
            b = (this.nextStackPane.getTranslateX() != 0.0);
            if (this.currentAnimatedIndex > this.previousIndex) {
                if (!b) {
                    this.nextStackPane.setTranslateX(this.currentStackPane.getWidth());
                }
                this.nextStackPane.setVisible(true);
                this.timeline = new Timeline();
                // new(javafx.animation.KeyFrame.class)
                Duration.millis(0.0);
                array = new KeyValue[2];
                new KeyValue((WritableValue<Double>)this.currentStackPane.translateXProperty(), b ? this.currentStackPane.getTranslateX() : 0.0, PaginationSkin.interpolator);
                array[o] = keyValue;
                new KeyValue((WritableValue<Double>)this.nextStackPane.translateXProperty(), b ? this.nextStackPane.getTranslateX() : this.currentStackPane.getWidth(), PaginationSkin.interpolator);
                array[o2] = keyValue2;
                new KeyFrame(duration, array);
                new KeyFrame(PaginationSkin.DURATION, this.swipeAnimationEndEventHandler, new KeyValue[] { new KeyValue((WritableValue<T>)this.currentStackPane.translateXProperty(), (T)(-this.currentStackPane.getWidth()), PaginationSkin.interpolator), new KeyValue((WritableValue<T>)this.nextStackPane.translateXProperty(), (T)0, PaginationSkin.interpolator) });
                this.timeline.getKeyFrames().setAll(keyFrame2, keyFrame3);
                this.timeline.play();
            }
            else {
                if (!b) {
                    this.nextStackPane.setTranslateX(-this.currentStackPane.getWidth());
                }
                this.nextStackPane.setVisible(true);
                this.timeline = new Timeline();
                // new(javafx.animation.KeyFrame.class)
                Duration.millis(0.0);
                array2 = new KeyValue[2];
                new KeyValue((WritableValue<Double>)this.currentStackPane.translateXProperty(), b ? this.currentStackPane.getTranslateX() : 0.0, PaginationSkin.interpolator);
                array2[o4] = keyValue3;
                new KeyValue((WritableValue<Double>)this.nextStackPane.translateXProperty(), b ? this.nextStackPane.getTranslateX() : (-this.currentStackPane.getWidth()), PaginationSkin.interpolator);
                array2[o5] = keyValue4;
                new KeyFrame(duration2, array2);
                new KeyFrame(PaginationSkin.DURATION, this.swipeAnimationEndEventHandler, new KeyValue[] { new KeyValue((WritableValue<T>)this.currentStackPane.translateXProperty(), (T)this.currentStackPane.getWidth(), PaginationSkin.interpolator), new KeyValue((WritableValue<T>)this.nextStackPane.translateXProperty(), (T)0, PaginationSkin.interpolator) });
                this.timeline.getKeyFrames().setAll(keyFrame5, keyFrame6);
                this.timeline.play();
            }
        });
    }
    
    private void swapPanes() {
        final StackPane currentStackPane = this.currentStackPane;
        this.currentStackPane = this.nextStackPane;
        this.nextStackPane = currentStackPane;
        this.currentStackPane.setTranslateX(0.0);
        this.currentStackPane.setCache(false);
        this.nextStackPane.setTranslateX(0.0);
        this.nextStackPane.setCache(false);
        this.nextStackPane.setVisible(false);
        this.nextStackPane.getChildren().clear();
    }
    
    private void animateClamping(final boolean b) {
        if (b) {
            this.timeline = new Timeline();
            this.timeline.getKeyFrames().setAll(new KeyFrame(Duration.millis(0.0), new KeyValue[] { new KeyValue((WritableValue<T>)this.currentStackPane.translateXProperty(), (T)this.currentStackPane.getTranslateX(), PaginationSkin.interpolator), new KeyValue((WritableValue<T>)this.nextStackPane.translateXProperty(), (T)this.nextStackPane.getTranslateX(), PaginationSkin.interpolator) }), new KeyFrame(PaginationSkin.DURATION, this.clampAnimationEndEventHandler, new KeyValue[] { new KeyValue((WritableValue<T>)this.currentStackPane.translateXProperty(), (T)0, PaginationSkin.interpolator), new KeyValue((WritableValue<T>)this.nextStackPane.translateXProperty(), (T)this.currentStackPane.getWidth(), PaginationSkin.interpolator) }));
            this.timeline.play();
        }
        else {
            this.timeline = new Timeline();
            this.timeline.getKeyFrames().setAll(new KeyFrame(Duration.millis(0.0), new KeyValue[] { new KeyValue((WritableValue<T>)this.currentStackPane.translateXProperty(), (T)this.currentStackPane.getTranslateX(), PaginationSkin.interpolator), new KeyValue((WritableValue<T>)this.nextStackPane.translateXProperty(), (T)this.nextStackPane.getTranslateX(), PaginationSkin.interpolator) }), new KeyFrame(PaginationSkin.DURATION, this.clampAnimationEndEventHandler, new KeyValue[] { new KeyValue((WritableValue<T>)this.currentStackPane.translateXProperty(), (T)0, PaginationSkin.interpolator), new KeyValue((WritableValue<T>)this.nextStackPane.translateXProperty(), (T)(-this.currentStackPane.getWidth()), PaginationSkin.interpolator) }));
            this.timeline.play();
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    static {
        DURATION = new Duration(125.0);
        interpolator = Interpolator.SPLINE(0.4829, 0.5709, 0.6803, 0.9928);
        DEFAULT_ARROW_VISIBLE = Boolean.FALSE;
        DEFAULT_PAGE_INFORMATION_VISIBLE = Boolean.FALSE;
        DEFAULT_PAGE_INFORMATION_ALIGNMENT = Side.BOTTOM;
        DEFAULT_TOOLTIP_VISIBLE = Boolean.FALSE;
    }
    
    class NavigationControl extends StackPane
    {
        private HBox controlBox;
        private Button leftArrowButton;
        private StackPane leftArrow;
        private Button rightArrowButton;
        private StackPane rightArrow;
        private ToggleGroup indicatorButtons;
        private Label pageInformation;
        private double minButtonSize;
        private int previousIndicatorCount;
        
        public NavigationControl() {
            this.minButtonSize = -1.0;
            this.previousIndicatorCount = 0;
            this.getStyleClass().setAll("pagination-control");
            final EventType<MouseEvent> mouse_PRESSED = MouseEvent.MOUSE_PRESSED;
            final PaginationBehavior access$1400 = PaginationSkin.this.behavior;
            Objects.requireNonNull(access$1400);
            this.addEventHandler((EventType<Event>)mouse_PRESSED, (EventHandler<? super Event>)access$1400::mousePressed);
            this.controlBox = new HBox();
            this.controlBox.getStyleClass().add("control-box");
            (this.leftArrowButton = new Button()).setAccessibleText(ControlResources.getString("Accessibility.title.Pagination.PreviousButton"));
            this.minButtonSize = this.leftArrowButton.getFont().getSize() * 2.0;
            final Iterator<Node> iterator;
            this.leftArrowButton.fontProperty().addListener((p0, p1, font) -> {
                this.minButtonSize = font.getSize() * 2.0;
                this.controlBox.getChildren().iterator();
                while (iterator.hasNext()) {
                    ((Control)iterator.next()).setMinSize(this.minButtonSize, this.minButtonSize);
                }
                this.requestLayout();
                return;
            });
            this.leftArrowButton.setMinSize(this.minButtonSize, this.minButtonSize);
            this.leftArrowButton.prefWidthProperty().bind(this.leftArrowButton.minWidthProperty());
            this.leftArrowButton.prefHeightProperty().bind(this.leftArrowButton.minHeightProperty());
            this.leftArrowButton.getStyleClass().add("left-arrow-button");
            this.leftArrowButton.setFocusTraversable(false);
            HBox.setMargin(this.leftArrowButton, new Insets(0.0, this.snapSize(PaginationSkin.this.arrowButtonGap.get()), 0.0, 0.0));
            (this.leftArrow = new StackPane()).setMaxSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
            this.leftArrowButton.setGraphic(this.leftArrow);
            this.leftArrow.getStyleClass().add("left-arrow");
            (this.rightArrowButton = new Button()).setAccessibleText(ControlResources.getString("Accessibility.title.Pagination.NextButton"));
            this.rightArrowButton.setMinSize(this.minButtonSize, this.minButtonSize);
            this.rightArrowButton.prefWidthProperty().bind(this.rightArrowButton.minWidthProperty());
            this.rightArrowButton.prefHeightProperty().bind(this.rightArrowButton.minHeightProperty());
            this.rightArrowButton.getStyleClass().add("right-arrow-button");
            this.rightArrowButton.setFocusTraversable(false);
            HBox.setMargin(this.rightArrowButton, new Insets(0.0, 0.0, 0.0, this.snapSize(PaginationSkin.this.arrowButtonGap.get())));
            (this.rightArrow = new StackPane()).setMaxSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
            this.rightArrowButton.setGraphic(this.rightArrow);
            this.rightArrow.getStyleClass().add("right-arrow");
            this.indicatorButtons = new ToggleGroup();
            this.pageInformation = new Label();
            this.pageInformation.getStyleClass().add("page-information");
            this.getChildren().addAll(this.controlBox, this.pageInformation);
            this.initializeNavigationHandlers();
            this.initializePageIndicators();
            this.updatePageIndex();
            PaginationSkin.this.arrowButtonGap.addListener((p0, p1, n) -> {
                if (n.doubleValue() == 0.0) {
                    HBox.setMargin(this.leftArrowButton, null);
                    HBox.setMargin(this.rightArrowButton, null);
                }
                else {
                    HBox.setMargin(this.leftArrowButton, new Insets(0.0, this.snapSize(n.doubleValue()), 0.0, 0.0));
                    HBox.setMargin(this.rightArrowButton, new Insets(0.0, 0.0, 0.0, this.snapSize(n.doubleValue())));
                }
            });
        }
        
        private void initializeNavigationHandlers() {
            this.leftArrowButton.setOnAction(p0 -> {
                PaginationSkin.this.getNode().requestFocus();
                PaginationSkin.this.selectPrevious();
                this.requestLayout();
                return;
            });
            this.rightArrowButton.setOnAction(p0 -> {
                PaginationSkin.this.getNode().requestFocus();
                PaginationSkin.this.selectNext();
                this.requestLayout();
                return;
            });
            PaginationSkin.this.pagination.currentPageIndexProperty().addListener((p0, n, n2) -> {
                PaginationSkin.this.previousIndex = n.intValue();
                PaginationSkin.this.currentIndex = n2.intValue();
                this.updatePageIndex();
                if (PaginationSkin.this.animate) {
                    PaginationSkin.this.currentAnimatedIndex = PaginationSkin.this.currentIndex;
                    PaginationSkin.this.animateSwitchPage();
                }
                else {
                    PaginationSkin.this.createPage(PaginationSkin.this.currentStackPane, PaginationSkin.this.currentIndex);
                }
            });
        }
        
        private void initializePageIndicators() {
            this.previousIndicatorCount = 0;
            this.controlBox.getChildren().clear();
            this.clearIndicatorButtons();
            this.controlBox.getChildren().add(this.leftArrowButton);
            for (int i = PaginationSkin.this.fromIndex; i <= PaginationSkin.this.toIndex; ++i) {
                final IndicatorButton indicatorButton = new IndicatorButton(i);
                indicatorButton.setMinSize(this.minButtonSize, this.minButtonSize);
                indicatorButton.setToggleGroup(this.indicatorButtons);
                this.controlBox.getChildren().add(indicatorButton);
            }
            this.controlBox.getChildren().add(this.rightArrowButton);
        }
        
        private void clearIndicatorButtons() {
            for (final Toggle toggle : this.indicatorButtons.getToggles()) {
                if (toggle instanceof IndicatorButton) {
                    ((IndicatorButton)toggle).release();
                }
            }
            this.indicatorButtons.getToggles().clear();
        }
        
        private void updatePageIndicators() {
            for (int i = 0; i < this.indicatorButtons.getToggles().size(); ++i) {
                final IndicatorButton indicatorButton = this.indicatorButtons.getToggles().get(i);
                if (indicatorButton.getPageNumber() == PaginationSkin.this.currentIndex) {
                    indicatorButton.setSelected(true);
                    this.updatePageInformation();
                    break;
                }
            }
            PaginationSkin.this.getSkinnable().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
        }
        
        private void updatePageIndex() {
            if (PaginationSkin.this.pageCount == PaginationSkin.this.maxPageIndicatorCount && this.changePageSet()) {
                this.initializePageIndicators();
            }
            this.updatePageIndicators();
            this.requestLayout();
        }
        
        private void updatePageInformation() {
            this.pageInformation.setText(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, Integer.toString(PaginationSkin.this.currentIndex + 1), (PaginationSkin.this.getPageCount() == Integer.MAX_VALUE) ? "..." : Integer.toString(PaginationSkin.this.getPageCount())));
        }
        
        private void layoutPageIndicators() {
            final double n = this.snapSize(this.getWidth()) - (this.snappedLeftInset() + this.snappedRightInset());
            final double snappedLeftInset = this.controlBox.snappedLeftInset();
            final double snappedRightInset = this.controlBox.snappedRightInset();
            final double snapSize = this.snapSize(Utils.boundedSize(this.leftArrowButton.prefWidth(-1.0), this.leftArrowButton.minWidth(-1.0), this.leftArrowButton.maxWidth(-1.0)));
            final double snapSize2 = this.snapSize(Utils.boundedSize(this.rightArrowButton.prefWidth(-1.0), this.rightArrowButton.minWidth(-1.0), this.rightArrowButton.maxWidth(-1.0)));
            final double snapSize3 = this.snapSize(this.controlBox.getSpacing());
            double n2 = n - (snappedLeftInset + snapSize + 2.0 * PaginationSkin.this.arrowButtonGap.get() + snapSize3 + snapSize2 + snappedRightInset);
            if (PaginationSkin.this.isPageInformationVisible() && (Side.LEFT.equals(PaginationSkin.this.getPageInformationAlignment()) || Side.RIGHT.equals(PaginationSkin.this.getPageInformationAlignment()))) {
                n2 -= this.snapSize(this.pageInformation.prefWidth(-1.0));
            }
            double n3 = 0.0;
            int previousIndicatorCount = 0;
            for (int i = 0; i < PaginationSkin.this.getMaxPageIndicatorCount(); ++i) {
                final int n4 = (i < this.indicatorButtons.getToggles().size()) ? i : (this.indicatorButtons.getToggles().size() - 1);
                double n5 = this.minButtonSize;
                if (n4 != -1) {
                    final IndicatorButton indicatorButton = this.indicatorButtons.getToggles().get(n4);
                    n5 = this.snapSize(Utils.boundedSize(indicatorButton.prefWidth(-1.0), indicatorButton.minWidth(-1.0), indicatorButton.maxWidth(-1.0)));
                }
                n3 += n5 + snapSize3;
                if (n3 > n2) {
                    break;
                }
                ++previousIndicatorCount;
            }
            if (previousIndicatorCount == 0) {
                previousIndicatorCount = 1;
            }
            if (previousIndicatorCount != this.previousIndicatorCount) {
                if (previousIndicatorCount < PaginationSkin.this.getMaxPageIndicatorCount()) {
                    PaginationSkin.this.maxPageIndicatorCount = previousIndicatorCount;
                }
                else {
                    PaginationSkin.this.maxPageIndicatorCount = PaginationSkin.this.getMaxPageIndicatorCount();
                }
                int n6;
                if (PaginationSkin.this.pageCount > PaginationSkin.this.maxPageIndicatorCount) {
                    PaginationSkin.this.pageCount = PaginationSkin.this.maxPageIndicatorCount;
                    n6 = PaginationSkin.this.maxPageIndicatorCount - 1;
                }
                else if (previousIndicatorCount > PaginationSkin.this.getPageCount()) {
                    PaginationSkin.this.pageCount = PaginationSkin.this.getPageCount();
                    n6 = PaginationSkin.this.getPageCount() - 1;
                }
                else {
                    PaginationSkin.this.pageCount = previousIndicatorCount;
                    n6 = previousIndicatorCount - 1;
                }
                if (PaginationSkin.this.currentIndex >= PaginationSkin.this.toIndex) {
                    PaginationSkin.this.toIndex = PaginationSkin.this.currentIndex;
                    PaginationSkin.this.fromIndex = PaginationSkin.this.toIndex - n6;
                }
                else if (PaginationSkin.this.currentIndex <= PaginationSkin.this.fromIndex) {
                    PaginationSkin.this.fromIndex = PaginationSkin.this.currentIndex;
                    PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + n6;
                }
                else {
                    PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + n6;
                }
                if (PaginationSkin.this.toIndex > PaginationSkin.this.getPageCount() - 1) {
                    PaginationSkin.this.toIndex = PaginationSkin.this.getPageCount() - 1;
                }
                if (PaginationSkin.this.fromIndex < 0) {
                    PaginationSkin.this.fromIndex = 0;
                    PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + n6;
                }
                this.initializePageIndicators();
                this.updatePageIndicators();
                this.previousIndicatorCount = previousIndicatorCount;
            }
        }
        
        private boolean changePageSet() {
            final int indexToIndicatorButtonsIndex = this.indexToIndicatorButtonsIndex(PaginationSkin.this.currentIndex);
            final int n = PaginationSkin.this.maxPageIndicatorCount - 1;
            if (PaginationSkin.this.previousIndex < PaginationSkin.this.currentIndex && indexToIndicatorButtonsIndex == 0 && n != 0 && indexToIndicatorButtonsIndex % n == 0) {
                PaginationSkin.this.fromIndex = PaginationSkin.this.currentIndex;
                PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + n;
            }
            else if (PaginationSkin.this.currentIndex < PaginationSkin.this.previousIndex && indexToIndicatorButtonsIndex == n && n != 0 && indexToIndicatorButtonsIndex % n == 0) {
                PaginationSkin.this.toIndex = PaginationSkin.this.currentIndex;
                PaginationSkin.this.fromIndex = PaginationSkin.this.toIndex - n;
            }
            else {
                if (PaginationSkin.this.currentIndex >= PaginationSkin.this.fromIndex && PaginationSkin.this.currentIndex <= PaginationSkin.this.toIndex) {
                    return false;
                }
                PaginationSkin.this.fromIndex = PaginationSkin.this.currentIndex - indexToIndicatorButtonsIndex;
                PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + n;
            }
            if (PaginationSkin.this.toIndex > PaginationSkin.this.getPageCount() - 1) {
                if (PaginationSkin.this.fromIndex > PaginationSkin.this.getPageCount() - 1) {
                    return false;
                }
                PaginationSkin.this.toIndex = PaginationSkin.this.getPageCount() - 1;
            }
            if (PaginationSkin.this.fromIndex < 0) {
                PaginationSkin.this.fromIndex = 0;
                PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + n;
            }
            return true;
        }
        
        private int indexToIndicatorButtonsIndex(final int n) {
            if (n >= PaginationSkin.this.fromIndex && n <= PaginationSkin.this.toIndex) {
                return n - PaginationSkin.this.fromIndex;
            }
            int n2 = 0;
            int access$1700 = PaginationSkin.this.fromIndex;
            int access$1701 = PaginationSkin.this.toIndex;
            if (PaginationSkin.this.currentIndex > PaginationSkin.this.previousIndex) {
                while (access$1700 < PaginationSkin.this.getPageCount() && access$1701 < PaginationSkin.this.getPageCount()) {
                    access$1700 += n2;
                    access$1701 += n2;
                    if (n >= access$1700 && n <= access$1701) {
                        if (n == access$1700) {
                            return 0;
                        }
                        if (n == access$1701) {
                            return PaginationSkin.this.maxPageIndicatorCount - 1;
                        }
                        return n - access$1700;
                    }
                    else {
                        n2 += PaginationSkin.this.maxPageIndicatorCount;
                    }
                }
            }
            else {
                while (access$1700 > 0 && access$1701 > 0) {
                    access$1700 -= n2;
                    access$1701 -= n2;
                    if (n >= access$1700 && n <= access$1701) {
                        if (n == access$1700) {
                            return 0;
                        }
                        if (n == access$1701) {
                            return PaginationSkin.this.maxPageIndicatorCount - 1;
                        }
                        return n - access$1700;
                    }
                    else {
                        n2 += PaginationSkin.this.maxPageIndicatorCount;
                    }
                }
            }
            return PaginationSkin.this.maxPageIndicatorCount - 1;
        }
        
        private Pos sideToPos(final Side other) {
            if (Side.TOP.equals(other)) {
                return Pos.TOP_CENTER;
            }
            if (Side.RIGHT.equals(other)) {
                return Pos.CENTER_RIGHT;
            }
            if (Side.BOTTOM.equals(other)) {
                return Pos.BOTTOM_CENTER;
            }
            return Pos.CENTER_LEFT;
        }
        
        @Override
        protected double computeMinWidth(final double n) {
            final double snappedLeftInset = this.snappedLeftInset();
            final double snappedRightInset = this.snappedRightInset();
            final double snapSize = this.snapSize(Utils.boundedSize(this.leftArrowButton.prefWidth(-1.0), this.leftArrowButton.minWidth(-1.0), this.leftArrowButton.maxWidth(-1.0)));
            final double snapSize2 = this.snapSize(Utils.boundedSize(this.rightArrowButton.prefWidth(-1.0), this.rightArrowButton.minWidth(-1.0), this.rightArrowButton.maxWidth(-1.0)));
            final double snapSize3 = this.snapSize(this.controlBox.getSpacing());
            double snapSize4 = 0.0;
            final Side access$2400 = PaginationSkin.this.getPageInformationAlignment();
            if (Side.LEFT.equals(access$2400) || Side.RIGHT.equals(access$2400)) {
                snapSize4 = this.snapSize(this.pageInformation.prefWidth(-1.0));
            }
            return snappedLeftInset + snapSize + 2.0 * PaginationSkin.this.arrowButtonGap.get() + this.minButtonSize + 2.0 * snapSize3 + snapSize2 + snappedRightInset + snapSize4;
        }
        
        @Override
        protected double computeMinHeight(final double n) {
            return this.computePrefHeight(n);
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            final double snappedLeftInset = this.snappedLeftInset();
            final double snappedRightInset = this.snappedRightInset();
            final double snapSize = this.snapSize(this.controlBox.prefWidth(n));
            double snapSize2 = 0.0;
            final Side access$2400 = PaginationSkin.this.getPageInformationAlignment();
            if (Side.LEFT.equals(access$2400) || Side.RIGHT.equals(access$2400)) {
                snapSize2 = this.snapSize(this.pageInformation.prefWidth(-1.0));
            }
            return snappedLeftInset + snapSize + snappedRightInset + snapSize2;
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            final double snappedTopInset = this.snappedTopInset();
            final double snappedBottomInset = this.snappedBottomInset();
            final double snapSize = this.snapSize(this.controlBox.prefHeight(n));
            double snapSize2 = 0.0;
            final Side access$2400 = PaginationSkin.this.getPageInformationAlignment();
            if (Side.TOP.equals(access$2400) || Side.BOTTOM.equals(access$2400)) {
                snapSize2 = this.snapSize(this.pageInformation.prefHeight(-1.0));
            }
            return snappedTopInset + snapSize + snapSize2 + snappedBottomInset;
        }
        
        @Override
        protected void layoutChildren() {
            final double snappedTopInset = this.snappedTopInset();
            final double snappedBottomInset = this.snappedBottomInset();
            final double snappedLeftInset = this.snappedLeftInset();
            final double snappedRightInset = this.snappedRightInset();
            final double n = this.snapSize(this.getWidth()) - (snappedLeftInset + snappedRightInset);
            final double n2 = this.snapSize(this.getHeight()) - (snappedTopInset + snappedBottomInset);
            final double snapSize = this.snapSize(this.controlBox.prefWidth(-1.0));
            final double snapSize2 = this.snapSize(this.controlBox.prefHeight(-1.0));
            final double snapSize3 = this.snapSize(this.pageInformation.prefWidth(-1.0));
            final double snapSize4 = this.snapSize(this.pageInformation.prefHeight(-1.0));
            this.leftArrowButton.setDisable(false);
            this.rightArrowButton.setDisable(false);
            if (PaginationSkin.this.currentIndex == 0) {
                this.leftArrowButton.setDisable(true);
            }
            if (PaginationSkin.this.currentIndex == PaginationSkin.this.getPageCount() - 1) {
                this.rightArrowButton.setDisable(true);
            }
            this.applyCss();
            this.leftArrowButton.setVisible(PaginationSkin.this.isArrowsVisible());
            this.rightArrowButton.setVisible(PaginationSkin.this.isArrowsVisible());
            this.pageInformation.setVisible(PaginationSkin.this.isPageInformationVisible());
            this.layoutPageIndicators();
            final HPos hpos = this.controlBox.getAlignment().getHpos();
            final VPos vpos = this.controlBox.getAlignment().getVpos();
            final double n3 = snappedLeftInset + Utils.computeXOffset(n, snapSize, hpos);
            double n4 = snappedTopInset + Utils.computeYOffset(n2, snapSize2, vpos);
            if (PaginationSkin.this.isPageInformationVisible()) {
                final Pos sideToPos = this.sideToPos(PaginationSkin.this.getPageInformationAlignment());
                final HPos hpos2 = sideToPos.getHpos();
                final VPos vpos2 = sideToPos.getVpos();
                double n5 = snappedLeftInset + Utils.computeXOffset(n, snapSize3, hpos2);
                double n6 = snappedTopInset + Utils.computeYOffset(n2, snapSize4, vpos2);
                if (Side.TOP.equals(PaginationSkin.this.getPageInformationAlignment())) {
                    n6 = snappedTopInset;
                    n4 = snappedTopInset + snapSize4;
                }
                else if (Side.RIGHT.equals(PaginationSkin.this.getPageInformationAlignment())) {
                    n5 = n - snappedRightInset - snapSize3;
                }
                else if (Side.BOTTOM.equals(PaginationSkin.this.getPageInformationAlignment())) {
                    n4 = snappedTopInset;
                    n6 = snappedTopInset + snapSize2;
                }
                else if (Side.LEFT.equals(PaginationSkin.this.getPageInformationAlignment())) {
                    n5 = snappedLeftInset;
                }
                this.layoutInArea(this.pageInformation, n5, n6, snapSize3, snapSize4, 0.0, hpos2, vpos2);
            }
            this.layoutInArea(this.controlBox, n3, n4, snapSize, snapSize2, 0.0, hpos, vpos);
        }
    }
    
    class IndicatorButton extends ToggleButton
    {
        private final ListChangeListener<String> updateSkinIndicatorType;
        private final ChangeListener<Boolean> updateTooltipVisibility;
        private int pageNumber;
        
        public IndicatorButton(final int pageNumber) {
            this.updateSkinIndicatorType = (p0 -> this.setIndicatorType());
            this.updateTooltipVisibility = ((p0, p1, b) -> this.setTooltipVisible(b));
            this.pageNumber = pageNumber;
            this.setFocusTraversable(false);
            this.setIndicatorType();
            this.setTooltipVisible(PaginationSkin.this.isTooltipVisible());
            PaginationSkin.this.getSkinnable().getStyleClass().addListener(this.updateSkinIndicatorType);
            this.setOnAction(p0 -> {
                PaginationSkin.this.getNode().requestFocus();
                if (PaginationSkin.this.getCurrentPageIndex() != this.pageNumber) {
                    PaginationSkin.this.pagination.setCurrentPageIndex(this.pageNumber);
                    this.requestLayout();
                }
                return;
            });
            PaginationSkin.this.tooltipVisibleProperty().addListener(this.updateTooltipVisibility);
            this.prefHeightProperty().bind(this.minHeightProperty());
            this.setAccessibleRole(AccessibleRole.PAGE_ITEM);
        }
        
        private void setIndicatorType() {
            if (PaginationSkin.this.getSkinnable().getStyleClass().contains("bullet")) {
                this.getStyleClass().remove("number-button");
                this.getStyleClass().add("bullet-button");
                this.setText(null);
                this.prefWidthProperty().bind(this.minWidthProperty());
            }
            else {
                this.getStyleClass().remove("bullet-button");
                this.getStyleClass().add("number-button");
                this.setText(Integer.toString(this.pageNumber + 1));
                this.prefWidthProperty().unbind();
            }
        }
        
        private void setTooltipVisible(final boolean b) {
            if (b) {
                this.setTooltip(new Tooltip(Integer.toString(this.pageNumber + 1)));
            }
            else {
                this.setTooltip(null);
            }
        }
        
        public int getPageNumber() {
            return this.pageNumber;
        }
        
        @Override
        public void fire() {
            if (this.getToggleGroup() == null || !this.isSelected()) {
                super.fire();
            }
        }
        
        public void release() {
            PaginationSkin.this.getSkinnable().getStyleClass().removeListener(this.updateSkinIndicatorType);
            PaginationSkin.this.tooltipVisibleProperty().removeListener(this.updateTooltipVisibility);
        }
        
        @Override
        public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
            switch (accessibleAttribute) {
                case TEXT: {
                    return this.getText();
                }
                case SELECTED: {
                    return this.isSelected();
                }
                default: {
                    return super.queryAccessibleAttribute(accessibleAttribute, array);
                }
            }
        }
        
        @Override
        public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
            switch (accessibleAction) {
                case REQUEST_FOCUS: {
                    PaginationSkin.this.getSkinnable().setCurrentPageIndex(this.pageNumber);
                    break;
                }
                default: {
                    super.executeAccessibleAction(accessibleAction, new Object[0]);
                    break;
                }
            }
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Pagination, Boolean> ARROWS_VISIBLE;
        private static final CssMetaData<Pagination, Boolean> PAGE_INFORMATION_VISIBLE;
        private static final CssMetaData<Pagination, Side> PAGE_INFORMATION_ALIGNMENT;
        private static final CssMetaData<Pagination, Boolean> TOOLTIP_VISIBLE;
        private static final CssMetaData<Pagination, Number> ARROW_BUTTON_GAP;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            ARROWS_VISIBLE = new CssMetaData<Pagination, Boolean>((StyleConverter)BooleanConverter.getInstance(), PaginationSkin.DEFAULT_ARROW_VISIBLE) {
                @Override
                public boolean isSettable(final Pagination pagination) {
                    final PaginationSkin paginationSkin = (PaginationSkin)pagination.getSkin();
                    return paginationSkin.arrowsVisible == null || !paginationSkin.arrowsVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Pagination pagination) {
                    return (StyleableProperty<Boolean>)((PaginationSkin)pagination.getSkin()).arrowsVisibleProperty();
                }
            };
            PAGE_INFORMATION_VISIBLE = new CssMetaData<Pagination, Boolean>((StyleConverter)BooleanConverter.getInstance(), PaginationSkin.DEFAULT_PAGE_INFORMATION_VISIBLE) {
                @Override
                public boolean isSettable(final Pagination pagination) {
                    final PaginationSkin paginationSkin = (PaginationSkin)pagination.getSkin();
                    return paginationSkin.pageInformationVisible == null || !paginationSkin.pageInformationVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Pagination pagination) {
                    return (StyleableProperty<Boolean>)((PaginationSkin)pagination.getSkin()).pageInformationVisibleProperty();
                }
            };
            PAGE_INFORMATION_ALIGNMENT = new CssMetaData<Pagination, Side>((StyleConverter)new EnumConverter(Side.class), PaginationSkin.DEFAULT_PAGE_INFORMATION_ALIGNMENT) {
                @Override
                public boolean isSettable(final Pagination pagination) {
                    final PaginationSkin paginationSkin = (PaginationSkin)pagination.getSkin();
                    return paginationSkin.pageInformationAlignment == null || !paginationSkin.pageInformationAlignment.isBound();
                }
                
                @Override
                public StyleableProperty<Side> getStyleableProperty(final Pagination pagination) {
                    return (StyleableProperty<Side>)(StyleableProperty)((PaginationSkin)pagination.getSkin()).pageInformationAlignmentProperty();
                }
            };
            TOOLTIP_VISIBLE = new CssMetaData<Pagination, Boolean>((StyleConverter)BooleanConverter.getInstance(), PaginationSkin.DEFAULT_TOOLTIP_VISIBLE) {
                @Override
                public boolean isSettable(final Pagination pagination) {
                    final PaginationSkin paginationSkin = (PaginationSkin)pagination.getSkin();
                    return paginationSkin.tooltipVisible == null || !paginationSkin.tooltipVisible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Pagination pagination) {
                    return (StyleableProperty<Boolean>)((PaginationSkin)pagination.getSkin()).tooltipVisibleProperty();
                }
            };
            ARROW_BUTTON_GAP = new CssMetaData<Pagination, Number>((StyleConverter)SizeConverter.getInstance(), (Number)4) {
                @Override
                public boolean isSettable(final Pagination pagination) {
                    final PaginationSkin paginationSkin = (PaginationSkin)pagination.getSkin();
                    return paginationSkin.arrowButtonGap == null || !paginationSkin.arrowButtonGap.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Pagination pagination) {
                    return (StyleableProperty<Number>)((PaginationSkin)pagination.getSkin()).arrowButtonGapProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(SkinBase.getClassCssMetaData());
            list.add(StyleableProperties.ARROWS_VISIBLE);
            list.add(StyleableProperties.PAGE_INFORMATION_VISIBLE);
            list.add(StyleableProperties.PAGE_INFORMATION_ALIGNMENT);
            list.add(StyleableProperties.TOOLTIP_VISIBLE);
            list.add(StyleableProperties.ARROW_BUTTON_GAP);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
