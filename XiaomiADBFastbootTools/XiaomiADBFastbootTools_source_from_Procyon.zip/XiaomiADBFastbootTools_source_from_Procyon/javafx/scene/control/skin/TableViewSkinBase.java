// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.security.AccessController;
import javafx.scene.AccessibleAttribute;
import java.util.Iterator;
import javafx.application.Platform;
import javafx.scene.control.TablePositionBase;
import javafx.scene.control.TableFocusModel;
import javafx.scene.control.TableSelectionModel;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.beans.value.ObservableObjectValue;
import javafx.collections.ObservableMap;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ScrollToEvent;
import javafx.beans.Observable;
import javafx.beans.property.ObjectProperty;
import java.lang.ref.WeakReference;
import javafx.collections.ObservableList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.beans.WeakInvalidationListener;
import javafx.collections.WeakListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;
import javafx.collections.MapChangeListener;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.util.Callback;
import javafx.scene.layout.Region;
import javafx.scene.control.TableColumnBase;
import javafx.scene.control.IndexedCell;
import javafx.scene.control.Control;

public abstract class TableViewSkinBase<M, S, C extends Control, I extends IndexedCell<M>, TC extends TableColumnBase<S, ?>> extends VirtualContainerBase<C, I>
{
    private static final double GOLDEN_RATIO_MULTIPLIER = 0.618033987;
    private static final boolean IS_PANNABLE;
    private final String EMPTY_TABLE_TEXT;
    private final String NO_COLUMNS_TEXT;
    VirtualFlow<I> flow;
    private boolean contentWidthDirty;
    private Region columnReorderLine;
    private Region columnReorderOverlay;
    private TableHeaderRow tableHeaderRow;
    private Callback<C, I> rowFactory;
    private StackPane placeholderRegion;
    private Label placeholderLabel;
    private int visibleColCount;
    boolean needCellsRecreated;
    boolean needCellsReconfigured;
    private int itemCount;
    private MapChangeListener<Object, Object> propertiesMapListener;
    private ListChangeListener<S> rowCountListener;
    private ListChangeListener<TC> visibleLeafColumnsListener;
    private InvalidationListener widthListener;
    private InvalidationListener itemsChangeListener;
    private WeakListChangeListener<S> weakRowCountListener;
    private WeakListChangeListener<TC> weakVisibleLeafColumnsListener;
    private WeakInvalidationListener weakWidthListener;
    private WeakInvalidationListener weakItemsChangeListener;
    
    public TableViewSkinBase(final C c) {
        super(c);
        this.EMPTY_TABLE_TEXT = ControlResources.getString("TableView.noContent");
        this.NO_COLUMNS_TEXT = ControlResources.getString("TableView.noColumns");
        this.contentWidthDirty = true;
        this.needCellsRecreated = true;
        this.needCellsReconfigured = false;
        this.itemCount = -1;
        this.propertiesMapListener = (change -> {
            if (!change.wasAdded()) {
                return;
            }
            else {
                if ("refreshKey".equals(change.getKey())) {
                    this.refreshView();
                    this.getSkinnable().getProperties().remove("refreshKey");
                }
                else if ("recreateKey".equals(change.getKey())) {
                    this.needCellsRecreated = true;
                    this.refreshView();
                    this.getSkinnable().getProperties().remove("recreateKey");
                }
                return;
            }
        });
        this.rowCountListener = (change2 -> {
            while (change2.next()) {
                if (change2.wasReplaced()) {
                    this.itemCount = 0;
                    break;
                }
                else if (change2.getRemovedSize() == this.itemCount) {
                    this.itemCount = 0;
                    break;
                }
                else {
                    continue;
                }
            }
            if (this.getSkinnable() instanceof TableView) {
                this.getSkinnable().edit(-1, null);
            }
            this.markItemCountDirty();
            this.getSkinnable().requestLayout();
            return;
        });
        this.visibleLeafColumnsListener = (change3 -> {
            this.updateVisibleColumnCount();
            while (change3.next()) {
                this.updateVisibleLeafColumnWidthListeners(change3.getAddedSubList(), change3.getRemoved());
            }
            return;
        });
        this.widthListener = (p0 -> {
            this.needCellsReconfigured = true;
            if (this.getSkinnable() != null) {
                this.getSkinnable().requestLayout();
            }
            return;
        });
        this.weakRowCountListener = new WeakListChangeListener<S>(this.rowCountListener);
        this.weakVisibleLeafColumnsListener = new WeakListChangeListener<TC>(this.visibleLeafColumnsListener);
        this.weakWidthListener = new WeakInvalidationListener(this.widthListener);
        (this.flow = this.getVirtualFlow()).setPannable(TableViewSkinBase.IS_PANNABLE);
        this.flow.getHbar().valueProperty().addListener(p0 -> this.horizontalScroll());
        this.flow.getHbar().setUnitIncrement(15.0);
        this.flow.getHbar().setBlockIncrement(80.0);
        this.columnReorderLine = new Region();
        this.columnReorderLine.getStyleClass().setAll("column-resize-line");
        this.columnReorderLine.setManaged(false);
        this.columnReorderLine.setVisible(false);
        this.columnReorderOverlay = new Region();
        this.columnReorderOverlay.getStyleClass().setAll("column-overlay");
        this.columnReorderOverlay.setVisible(false);
        this.columnReorderOverlay.setManaged(false);
        (this.tableHeaderRow = this.createTableHeaderRow()).setFocusTraversable(false);
        this.getChildren().addAll(this.tableHeaderRow, this.flow, this.columnReorderOverlay, this.columnReorderLine);
        this.updateVisibleColumnCount();
        this.updateVisibleLeafColumnWidthListeners(this.getVisibleLeafColumns(), (List<? extends TC>)FXCollections.emptyObservableList());
        this.tableHeaderRow.reorderingProperty().addListener(p0 -> this.getSkinnable().requestLayout());
        this.getVisibleLeafColumns().addListener(this.weakVisibleLeafColumnsListener);
        final ObjectProperty<ObservableList<Object>> itemsProperty = TableSkinUtils.itemsProperty(this);
        this.updateTableItems(null, itemsProperty.get());
        this.itemsChangeListener = new InvalidationListener() {
            private WeakReference<ObservableList<S>> weakItemsRef = new WeakReference<ObservableList<S>>((ObservableList<S>)itemsProperty.get());
            
            @Override
            public void invalidated(final Observable observable) {
                final ObservableList list = this.weakItemsRef.get();
                this.weakItemsRef = new WeakReference<ObservableList<S>>((ObservableList<S>)itemsProperty.get());
                TableViewSkinBase.this.updateTableItems(list, (ObservableList)itemsProperty.get());
            }
        };
        itemsProperty.addListener(this.weakItemsChangeListener = new WeakInvalidationListener(this.itemsChangeListener));
        final ObservableMap<Object, Object> properties = c.getProperties();
        properties.remove("refreshKey");
        properties.remove("recreateKey");
        properties.addListener(this.propertiesMapListener);
        c.addEventHandler(ScrollToEvent.scrollToColumn(), scrollToEvent -> this.scrollHorizontally(scrollToEvent.getScrollTarget()));
        final InvalidationListener invalidationListener = p0 -> {
            this.contentWidthDirty = (1 != 0);
            this.getSkinnable().requestLayout();
            return;
        };
        this.flow.widthProperty().addListener(invalidationListener);
        this.flow.getVbar().widthProperty().addListener(invalidationListener);
        final Callback<C, I> rowFactory;
        final ObservableObjectValue<Callback<C, I>> observableObjectValue;
        this.registerChangeListener(TableSkinUtils.rowFactoryProperty((TableViewSkinBase<?, ?, Control, IndexedCell, ?>)this), p1 -> {
            rowFactory = this.rowFactory;
            this.rowFactory = observableObjectValue.get();
            if (rowFactory != this.rowFactory) {
                this.requestRebuildCells();
            }
            return;
        });
        this.registerChangeListener(TableSkinUtils.placeholderProperty(this), p0 -> this.updatePlaceholderRegionVisibility());
        this.registerChangeListener(this.flow.getVbar().visibleProperty(), p0 -> this.updateContentWidth());
    }
    
    @Override
    public void dispose() {
        final ObjectProperty<ObservableList<Object>> itemsProperty = TableSkinUtils.itemsProperty(this);
        this.getVisibleLeafColumns().removeListener(this.weakVisibleLeafColumnsListener);
        itemsProperty.removeListener(this.weakItemsChangeListener);
        this.getSkinnable().getProperties().removeListener(this.propertiesMapListener);
        this.updateTableItems(itemsProperty.get(), null);
        super.dispose();
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return 400.0;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final double computePrefHeight = this.computePrefHeight(-1.0, n2, n3, n4, n5);
        final ObservableList<? extends TC> visibleLeafColumns = this.getVisibleLeafColumns();
        if (visibleLeafColumns == null || visibleLeafColumns.isEmpty()) {
            return computePrefHeight * 0.618033987;
        }
        double a = n5 + n3;
        for (int i = 0; i < visibleLeafColumns.size(); ++i) {
            final TableColumnBase tableColumnBase = visibleLeafColumns.get(i);
            a += Math.max(tableColumnBase.getPrefWidth(), tableColumnBase.getMinWidth());
        }
        return Math.max(a, computePrefHeight * 0.618033987);
    }
    
    @Override
    protected void layoutChildren(final double n, double n2, final double n3, final double n4) {
        final Control skinnable = this.getSkinnable();
        if (skinnable == null) {
            return;
        }
        super.layoutChildren(n, n2, n3, n4);
        if (this.needCellsRecreated) {
            this.flow.recreateCells();
        }
        else if (this.needCellsReconfigured) {
            this.flow.reconfigureCells();
        }
        this.needCellsRecreated = false;
        this.needCellsReconfigured = false;
        final double n5 = skinnable.getLayoutBounds().getHeight() / 2.0;
        final double prefHeight = this.tableHeaderRow.prefHeight(-1.0);
        this.layoutInArea(this.tableHeaderRow, n, n2, n3, prefHeight, n5, HPos.CENTER, VPos.CENTER);
        n2 += prefHeight;
        final double floor = Math.floor(n4 - prefHeight);
        if (this.getItemCount() == 0 || this.visibleColCount == 0) {
            this.layoutInArea(this.placeholderRegion, n, n2, n3, floor, n5, HPos.CENTER, VPos.CENTER);
        }
        else {
            this.layoutInArea(this.flow, n, n2, n3, floor, n5, HPos.CENTER, VPos.CENTER);
        }
        if (this.tableHeaderRow.getReorderingRegion() != null) {
            final TableColumnHeader reorderingRegion = this.tableHeaderRow.getReorderingRegion();
            if (reorderingRegion.getTableColumn() != null) {
                final TableColumnHeader reorderingRegion2 = this.tableHeaderRow.getReorderingRegion();
                final double minX = this.tableHeaderRow.sceneToLocal(reorderingRegion2.localToScene(reorderingRegion2.getBoundsInLocal())).getMinX();
                double width = reorderingRegion.getWidth();
                if (minX < 0.0) {
                    width += minX;
                }
                final double layoutX = (minX < 0.0) ? 0.0 : minX;
                if (layoutX + width > n3) {
                    width = n3 - layoutX;
                    if (this.flow.getVbar().isVisible()) {
                        width -= this.flow.getVbar().getWidth() - 1.0;
                    }
                }
                double n6 = floor;
                if (this.flow.getHbar().isVisible()) {
                    n6 -= this.flow.getHbar().getHeight();
                }
                this.columnReorderOverlay.resize(width, n6);
                this.columnReorderOverlay.setLayoutX(layoutX);
                this.columnReorderOverlay.setLayoutY(this.tableHeaderRow.getHeight());
            }
            this.columnReorderLine.resizeRelocate(0.0, this.columnReorderLine.snappedTopInset(), this.columnReorderLine.snappedLeftInset() + this.columnReorderLine.snappedRightInset(), n4 - (this.flow.getHbar().isVisible() ? (this.flow.getHbar().getHeight() - 1.0) : 0.0));
        }
        this.columnReorderLine.setVisible(this.tableHeaderRow.isReordering());
        this.columnReorderOverlay.setVisible(this.tableHeaderRow.isReordering());
        this.checkContentWidthState();
    }
    
    protected TableHeaderRow createTableHeaderRow() {
        return new TableHeaderRow(this);
    }
    
    final TableHeaderRow getTableHeaderRow() {
        return this.tableHeaderRow;
    }
    
    private TableSelectionModel<S> getSelectionModel() {
        return TableSkinUtils.getSelectionModel(this);
    }
    
    private TableFocusModel<M, ?> getFocusModel() {
        return TableSkinUtils.getFocusModel((TableViewSkinBase<M, ?, ?, ?, ?>)this);
    }
    
    private TablePositionBase<? extends TC> getFocusedCell() {
        return (TablePositionBase<? extends TC>)TableSkinUtils.getFocusedCell((TableViewSkinBase<?, Object, ?, ?, TableColumnBase>)this);
    }
    
    private ObservableList<? extends TC> getVisibleLeafColumns() {
        return TableSkinUtils.getVisibleLeafColumns((TableViewSkinBase<?, ?, ?, ?, ? extends TC>)this);
    }
    
    @Override
    protected void updateItemCount() {
        this.updatePlaceholderRegionVisibility();
        final int itemCount = this.itemCount;
        final int itemCount2 = this.getItemCount();
        this.itemCount = itemCount2;
        if (this.itemCount == 0) {
            this.flow.getHbar().setValue(0.0);
        }
        this.flow.setCellCount(itemCount2);
        if (itemCount2 != itemCount) {
            this.requestRebuildCells();
        }
        else {
            this.needCellsReconfigured = true;
        }
    }
    
    private void checkContentWidthState() {
        if (this.contentWidthDirty || this.getItemCount() == 0) {
            this.updateContentWidth();
            this.contentWidthDirty = false;
        }
    }
    
    void horizontalScroll() {
        this.tableHeaderRow.updateScrollX();
    }
    
    void onFocusPreviousCell() {
        final TableFocusModel<M, ?> focusModel = this.getFocusModel();
        if (focusModel == null) {
            return;
        }
        this.flow.scrollTo(focusModel.getFocusedIndex());
    }
    
    void onFocusNextCell() {
        final TableFocusModel<M, ?> focusModel = this.getFocusModel();
        if (focusModel == null) {
            return;
        }
        this.flow.scrollTo(focusModel.getFocusedIndex());
    }
    
    void onSelectPreviousCell() {
        final TableSelectionModel<S> selectionModel = this.getSelectionModel();
        if (selectionModel == null) {
            return;
        }
        this.flow.scrollTo(selectionModel.getSelectedIndex());
    }
    
    void onSelectNextCell() {
        final TableSelectionModel<S> selectionModel = this.getSelectionModel();
        if (selectionModel == null) {
            return;
        }
        this.flow.scrollTo(selectionModel.getSelectedIndex());
    }
    
    void onSelectLeftCell() {
        this.scrollHorizontally();
    }
    
    void onSelectRightCell() {
        this.scrollHorizontally();
    }
    
    void onMoveToFirstCell() {
        this.flow.scrollTo(0);
        this.flow.setPosition(0.0);
    }
    
    void onMoveToLastCell() {
        this.flow.scrollTo(this.getItemCount());
        this.flow.setPosition(1.0);
    }
    
    private void updateTableItems(final ObservableList<S> list, final ObservableList<S> list2) {
        if (list != null) {
            list.removeListener(this.weakRowCountListener);
        }
        if (list2 != null) {
            list2.addListener(this.weakRowCountListener);
        }
        this.markItemCountDirty();
        this.getSkinnable().requestLayout();
    }
    
    Region getColumnReorderLine() {
        return this.columnReorderLine;
    }
    
    int onScrollPageDown(final boolean b) {
        if (this.getSelectionModel() == null) {
            return -1;
        }
        final int itemCount = this.getItemCount();
        IndexedCell<M> lastVisibleCellWithinViewPort = this.flow.getLastVisibleCellWithinViewPort();
        if (lastVisibleCellWithinViewPort == null) {
            return -1;
        }
        final int index = lastVisibleCellWithinViewPort.getIndex();
        final int n = (index >= itemCount) ? (itemCount - 1) : index;
        boolean b2;
        if (b) {
            b2 = (lastVisibleCellWithinViewPort.isFocused() || this.isCellFocused(n));
        }
        else {
            b2 = (lastVisibleCellWithinViewPort.isSelected() || this.isCellSelected(n));
        }
        if (b2 && this.isLeadIndex(b, n)) {
            this.flow.scrollToTop((I)lastVisibleCellWithinViewPort);
            final IndexedCell<M> lastVisibleCellWithinViewPort2 = this.flow.getLastVisibleCellWithinViewPort();
            lastVisibleCellWithinViewPort = ((lastVisibleCellWithinViewPort2 == null) ? lastVisibleCellWithinViewPort : lastVisibleCellWithinViewPort2);
        }
        final int index2 = lastVisibleCellWithinViewPort.getIndex();
        final int n2 = (index2 >= itemCount) ? (itemCount - 1) : index2;
        this.flow.scrollTo(n2);
        return n2;
    }
    
    int onScrollPageUp(final boolean b) {
        IndexedCell<M> firstVisibleCellWithinViewPort = this.flow.getFirstVisibleCellWithinViewPort();
        if (firstVisibleCellWithinViewPort == null) {
            return -1;
        }
        final int index = firstVisibleCellWithinViewPort.getIndex();
        boolean b2;
        if (b) {
            b2 = (firstVisibleCellWithinViewPort.isFocused() || this.isCellFocused(index));
        }
        else {
            b2 = (firstVisibleCellWithinViewPort.isSelected() || this.isCellSelected(index));
        }
        if (b2 && this.isLeadIndex(b, index)) {
            this.flow.scrollToBottom((I)firstVisibleCellWithinViewPort);
            final IndexedCell<M> firstVisibleCellWithinViewPort2 = this.flow.getFirstVisibleCellWithinViewPort();
            firstVisibleCellWithinViewPort = ((firstVisibleCellWithinViewPort2 == null) ? firstVisibleCellWithinViewPort : firstVisibleCellWithinViewPort2);
        }
        final int index2 = firstVisibleCellWithinViewPort.getIndex();
        this.flow.scrollTo(index2);
        return index2;
    }
    
    private boolean isLeadIndex(final boolean b, final int n) {
        final TableSelectionModel<S> selectionModel = this.getSelectionModel();
        final TableFocusModel<M, ?> focusModel = this.getFocusModel();
        return (b && focusModel.getFocusedIndex() == n) || (!b && selectionModel.getSelectedIndex() == n);
    }
    
    private void updateVisibleColumnCount() {
        this.visibleColCount = this.getVisibleLeafColumns().size();
        this.updatePlaceholderRegionVisibility();
        this.requestRebuildCells();
    }
    
    private void updateVisibleLeafColumnWidthListeners(final List<? extends TC> list, final List<? extends TC> list2) {
        for (int i = 0; i < list2.size(); ++i) {
            ((TableColumnBase)list2.get(i)).widthProperty().removeListener(this.weakWidthListener);
        }
        for (int j = 0; j < list.size(); ++j) {
            ((TableColumnBase)list.get(j)).widthProperty().addListener(this.weakWidthListener);
        }
        this.requestRebuildCells();
    }
    
    final void updatePlaceholderRegionVisibility() {
        final boolean visible = this.visibleColCount == 0 || this.getItemCount() == 0;
        if (visible) {
            if (this.placeholderRegion == null) {
                this.placeholderRegion = new StackPane();
                this.placeholderRegion.getStyleClass().setAll("placeholder");
                this.getChildren().add(this.placeholderRegion);
            }
            final Node node = TableSkinUtils.placeholderProperty(this).get();
            if (node == null) {
                if (this.placeholderLabel == null) {
                    this.placeholderLabel = new Label();
                }
                this.placeholderLabel.setText((this.visibleColCount == 0) ? this.NO_COLUMNS_TEXT : this.EMPTY_TABLE_TEXT);
                this.placeholderRegion.getChildren().setAll(this.placeholderLabel);
            }
            else {
                this.placeholderRegion.getChildren().setAll(node);
            }
        }
        this.flow.setVisible(!visible);
        if (this.placeholderRegion != null) {
            this.placeholderRegion.setVisible(visible);
        }
    }
    
    private void updateContentWidth() {
        double width = this.flow.getWidth();
        if (this.flow.getVbar().isVisible()) {
            width -= this.flow.getVbar().getWidth();
        }
        if (width <= 0.0) {
            width = this.getSkinnable().getWidth() - (this.snappedLeftInset() + this.snappedRightInset());
        }
        this.getSkinnable().getProperties().put("TableView.contentWidth", Math.floor(Math.max(0.0, width)));
    }
    
    private void refreshView() {
        this.markItemCountDirty();
        final Control skinnable = this.getSkinnable();
        if (skinnable != null) {
            skinnable.requestLayout();
        }
    }
    
    void scrollHorizontally() {
        if (this.getFocusModel() == null) {
            return;
        }
        this.scrollHorizontally(this.getFocusedCell().getTableColumn());
    }
    
    void scrollHorizontally(final TC obj) {
        if (obj == null || !obj.isVisible()) {
            return;
        }
        final Control skinnable = this.getSkinnable();
        final TableColumnHeader columnHeader = this.tableHeaderRow.getColumnHeaderFor(obj);
        if (columnHeader == null || columnHeader.getWidth() <= 0.0) {
            Platform.runLater(() -> this.scrollHorizontally(obj));
            return;
        }
        double n = 0.0;
        for (final TableColumnBase tableColumnBase : this.getVisibleLeafColumns()) {
            if (tableColumnBase.equals(obj)) {
                break;
            }
            n += tableColumnBase.getWidth();
        }
        final double n2 = n + obj.getWidth();
        final double n3 = skinnable.getWidth() - this.snappedLeftInset() - this.snappedRightInset();
        final double value = this.flow.getHbar().getValue();
        final double max = this.flow.getHbar().getMax();
        double value2;
        if (n < value && n >= 0.0) {
            value2 = n;
        }
        else {
            final double n4 = (n < 0.0 || n2 > n3) ? (n - value) : 0.0;
            value2 = ((value + n4 > max) ? max : (value + n4));
        }
        this.flow.getHbar().setValue(value2);
    }
    
    private boolean isCellSelected(final int n) {
        final TableSelectionModel<S> selectionModel = this.getSelectionModel();
        if (selectionModel == null) {
            return false;
        }
        if (!selectionModel.isCellSelectionEnabled()) {
            return false;
        }
        for (int size = this.getVisibleLeafColumns().size(), i = 0; i < size; ++i) {
            if (selectionModel.isSelected(n, TableSkinUtils.getVisibleLeafColumn((TableViewSkinBase<?, Object, ?, ?, TableColumnBase<S, ?>>)this, i))) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isCellFocused(final int n) {
        final TableFocusModel<M, ?> tableFocusModel = this.getFocusModel();
        if (tableFocusModel == null) {
            return false;
        }
        for (int size = this.getVisibleLeafColumns().size(), i = 0; i < size; ++i) {
            if (tableFocusModel.isFocused(n, TableSkinUtils.getVisibleLeafColumn((TableViewSkinBase<?, Object, ?, ?, TableColumnBase>)this, i))) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case FOCUS_ITEM: {
                int focusedIndex = this.getFocusModel().getFocusedIndex();
                if (focusedIndex == -1) {
                    if (this.placeholderRegion != null && this.placeholderRegion.isVisible()) {
                        return this.placeholderRegion.getChildren().get(0);
                    }
                    if (this.getItemCount() <= 0) {
                        return null;
                    }
                    focusedIndex = 0;
                }
                return this.flow.getPrivateCell(focusedIndex);
            }
            case CELL_AT_ROW_COLUMN: {
                return this.flow.getPrivateCell((int)array[0]);
            }
            case COLUMN_AT_INDEX: {
                return this.getTableHeaderRow().getColumnHeaderFor(TableSkinUtils.getVisibleLeafColumn((TableViewSkinBase<?, Object, ?, ?, TableColumnBase<?, ?>>)this, (int)array[0]));
            }
            case HEADER: {
                return this.getTableHeaderRow();
            }
            case VERTICAL_SCROLLBAR: {
                return this.flow.getVbar();
            }
            case HORIZONTAL_SCROLLBAR: {
                return this.flow.getHbar();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        IS_PANNABLE = AccessController.doPrivileged(() -> Boolean.getBoolean("javafx.scene.control.skin.TableViewSkin.pannable"));
    }
}
