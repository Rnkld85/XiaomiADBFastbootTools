// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.security.AccessController;
import javafx.scene.control.FocusModel;
import javafx.beans.Observable;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.InvalidationListener;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.Node;
import javafx.scene.AccessibleAction;
import java.util.Iterator;
import javafx.collections.ObservableList;
import java.util.Collection;
import javafx.collections.FXCollections;
import java.util.ArrayList;
import javafx.scene.AccessibleAttribute;
import javafx.collections.ObservableMap;
import javafx.event.EventType;
import javafx.beans.value.ObservableValue;
import javafx.scene.input.MouseEvent;
import javafx.event.WeakEventHandler;
import javafx.event.EventHandler;
import javafx.collections.MapChangeListener;
import com.sun.javafx.scene.control.behavior.TreeViewBehavior;
import javafx.scene.control.TreeItem;
import java.lang.ref.WeakReference;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeView;

public class TreeViewSkin<T> extends VirtualContainerBase<TreeView<T>, TreeCell<T>>
{
    private static final boolean IS_PANNABLE;
    private final VirtualFlow<TreeCell<T>> flow;
    private WeakReference<TreeItem<T>> weakRoot;
    private final TreeViewBehavior<T> behavior;
    private MapChangeListener<Object, Object> propertiesMapListener;
    private EventHandler<TreeItem.TreeModificationEvent<T>> rootListener;
    private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakRootListener;
    
    public TreeViewSkin(final TreeView treeView) {
        super(treeView);
        this.propertiesMapListener = (change -> {
            if (!change.wasAdded()) {
                return;
            }
            else {
                if ("recreateKey".equals(change.getKey())) {
                    this.requestRebuildCells();
                    this.getSkinnable().getProperties().remove("recreateKey");
                }
                return;
            }
        });
        EventType superType = null;
        this.rootListener = (treeModificationEvent -> {
            if (treeModificationEvent.wasAdded() && treeModificationEvent.wasRemoved() && treeModificationEvent.getAddedSize() == treeModificationEvent.getRemovedSize()) {
                this.markItemCountDirty();
                this.getSkinnable().requestLayout();
            }
            else if (treeModificationEvent.getEventType().equals(TreeItem.valueChangedEvent())) {
                this.requestRebuildCells();
            }
            else {
                treeModificationEvent.getEventType();
                while (superType != null) {
                    if (superType.equals(TreeItem.expandedItemCountChangeEvent())) {
                        this.markItemCountDirty();
                        this.getSkinnable().requestLayout();
                        break;
                    }
                    else {
                        superType = superType.getSuperType();
                    }
                }
            }
            this.getSkinnable().edit(null);
            return;
        });
        this.behavior = new TreeViewBehavior<T>((TreeView<Object>)treeView);
        (this.flow = this.getVirtualFlow()).setPannable(TreeViewSkin.IS_PANNABLE);
        this.flow.setCellFactory(this::createCell);
        this.flow.setFixedCellSize(treeView.getFixedCellSize());
        this.getChildren().add(this.flow);
        this.setRoot(this.getSkinnable().getRoot());
        final EventHandler<? super MouseEvent> eventHandler = p1 -> {
            if (treeView.getEditingItem() != null) {
                treeView.edit(null);
            }
            if (treeView.isFocusTraversable()) {
                treeView.requestFocus();
            }
            return;
        };
        this.flow.getVbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        this.flow.getHbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        final ObservableMap<Object, Object> properties = treeView.getProperties();
        properties.remove("recreateKey");
        properties.addListener(this.propertiesMapListener);
        this.behavior.setOnFocusPreviousRow(() -> this.onFocusPreviousCell());
        this.behavior.setOnFocusNextRow(() -> this.onFocusNextCell());
        this.behavior.setOnMoveToFirstCell(() -> this.onMoveToFirstCell());
        this.behavior.setOnMoveToLastCell(() -> this.onMoveToLastCell());
        this.behavior.setOnScrollPageDown(this::onScrollPageDown);
        this.behavior.setOnScrollPageUp(this::onScrollPageUp);
        this.behavior.setOnSelectPreviousRow(() -> this.onSelectPreviousCell());
        this.behavior.setOnSelectNextRow(() -> this.onSelectNextCell());
        this.registerChangeListener(treeView.rootProperty(), p0 -> this.setRoot(this.getSkinnable().getRoot()));
        this.registerChangeListener(treeView.showRootProperty(), p0 -> {
            if (!this.getSkinnable().isShowRoot() && this.getRoot() != null) {
                this.getRoot().setExpanded(true);
            }
            this.updateItemCount();
            return;
        });
        this.registerChangeListener(treeView.cellFactoryProperty(), p0 -> this.flow.recreateCells());
        this.registerChangeListener(treeView.fixedCellSizeProperty(), p0 -> this.flow.setFixedCellSize(this.getSkinnable().getFixedCellSize()));
        this.updateItemCount();
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computePrefHeight(-1.0, n2, n3, n4, n5) * 0.618033987;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return 400.0;
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        super.layoutChildren(n, n2, n3, n4);
        this.flow.resizeRelocate(n, n2, n3, n4);
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case FOCUS_ITEM: {
                int focusedIndex = this.getSkinnable().getFocusModel().getFocusedIndex();
                if (focusedIndex == -1) {
                    if (this.getItemCount() <= 0) {
                        return null;
                    }
                    focusedIndex = 0;
                }
                return this.flow.getPrivateCell(focusedIndex);
            }
            case ROW_AT_INDEX: {
                final int intValue = (int)array[0];
                return (intValue < 0) ? null : this.flow.getPrivateCell(intValue);
            }
            case SELECTED_ITEMS: {
                final ObservableList selectedIndices = this.getSkinnable().getSelectionModel().getSelectedIndices();
                final ArrayList list = new ArrayList<TreeCell<T>>(selectedIndices.size());
                final Iterator<Integer> iterator = selectedIndices.iterator();
                while (iterator.hasNext()) {
                    final TreeCell<T> treeCell = this.flow.getPrivateCell(iterator.next());
                    if (treeCell != null) {
                        list.add(treeCell);
                    }
                }
                return FXCollections.observableArrayList((Collection<?>)list);
            }
            case VERTICAL_SCROLLBAR: {
                return this.flow.getVbar();
            }
            case HORIZONTAL_SCROLLBAR: {
                return this.flow.getHbar();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    protected void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case SHOW_ITEM: {
                final Node node = (Node)array[0];
                if (node instanceof TreeCell) {
                    this.flow.scrollTo(((TreeCell)node).getIndex());
                    break;
                }
                break;
            }
            case SET_SELECTED_ITEMS: {
                final ObservableList list = (ObservableList)array[0];
                if (list != null) {
                    final MultipleSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
                    if (selectionModel != null) {
                        selectionModel.clearSelection();
                        for (final Node node2 : list) {
                            if (node2 instanceof TreeCell) {
                                selectionModel.select(((TreeCell)node2).getIndex());
                            }
                        }
                    }
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    private TreeCell<T> createCell(final VirtualFlow<TreeCell<T>> virtualFlow) {
        TreeCell<?> defaultCellImpl;
        if (this.getSkinnable().getCellFactory() != null) {
            defaultCellImpl = this.getSkinnable().getCellFactory().call(this.getSkinnable());
        }
        else {
            defaultCellImpl = this.createDefaultCellImpl();
        }
        if (defaultCellImpl.getDisclosureNode() == null) {
            final StackPane disclosureNode = new StackPane();
            disclosureNode.getStyleClass().setAll("tree-disclosure-node");
            final StackPane stackPane = new StackPane();
            stackPane.getStyleClass().setAll("arrow");
            disclosureNode.getChildren().add(stackPane);
            defaultCellImpl.setDisclosureNode(disclosureNode);
        }
        defaultCellImpl.updateTreeView(this.getSkinnable());
        return (TreeCell<T>)defaultCellImpl;
    }
    
    private TreeItem<T> getRoot() {
        return (this.weakRoot == null) ? null : this.weakRoot.get();
    }
    
    private void setRoot(final TreeItem<T> referent) {
        if (this.getRoot() != null && this.weakRootListener != null) {
            this.getRoot().removeEventHandler(TreeItem.treeNotificationEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakRootListener);
        }
        this.weakRoot = new WeakReference<TreeItem<T>>(referent);
        if (this.getRoot() != null) {
            this.weakRootListener = new WeakEventHandler<TreeItem.TreeModificationEvent<T>>(this.rootListener);
            this.getRoot().addEventHandler(TreeItem.treeNotificationEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakRootListener);
        }
        this.updateItemCount();
    }
    
    @Override
    protected int getItemCount() {
        return this.getSkinnable().getExpandedItemCount();
    }
    
    @Override
    protected void updateItemCount() {
        final int itemCount = this.getItemCount();
        this.requestRebuildCells();
        this.flow.setCellCount(itemCount);
        this.getSkinnable().requestLayout();
    }
    
    private TreeCell<T> createDefaultCellImpl() {
        return new TreeCell<T>() {
            private HBox hbox;
            private WeakReference<TreeItem<T>> treeItemRef;
            private InvalidationListener treeItemGraphicListener = p0 -> this.updateDisplay(this.getItem(), this.isEmpty());
            private InvalidationListener treeItemListener = new InvalidationListener() {
                @Override
                public void invalidated(final Observable observable) {
                    final TreeItem treeItem = (TreeCell.this.treeItemRef == null) ? null : ((TreeItem)TreeCell.this.treeItemRef.get());
                    if (treeItem != null) {
                        treeItem.graphicProperty().removeListener(TreeCell.this.weakTreeItemGraphicListener);
                    }
                    final TreeItem<T> treeItem2 = TreeCell.this.getTreeItem();
                    if (treeItem2 != null) {
                        treeItem2.graphicProperty().addListener(TreeCell.this.weakTreeItemGraphicListener);
                        TreeCell.this.treeItemRef = (WeakReference<TreeItem<T>>)new WeakReference((T)treeItem2);
                    }
                }
            };
            private WeakInvalidationListener weakTreeItemGraphicListener = new WeakInvalidationListener(this.treeItemGraphicListener);
            private WeakInvalidationListener weakTreeItemListener = new WeakInvalidationListener(this.treeItemListener);
            
            {
                this.treeItemProperty().addListener(this.weakTreeItemListener);
                if (this.getTreeItem() != null) {
                    this.getTreeItem().graphicProperty().addListener(this.weakTreeItemGraphicListener);
                }
            }
            
            private void updateDisplay(final T t, final boolean b) {
                if (t == null || b) {
                    this.hbox = null;
                    this.setText(null);
                    this.setGraphic(null);
                }
                else {
                    final TreeItem<T> treeItem = this.getTreeItem();
                    final Node graphic = (treeItem == null) ? null : treeItem.getGraphic();
                    if (graphic != null) {
                        if (t instanceof Node) {
                            this.setText(null);
                            if (this.hbox == null) {
                                this.hbox = new HBox(3.0);
                            }
                            this.hbox.getChildren().setAll(graphic, (Node)t);
                            this.setGraphic(this.hbox);
                        }
                        else {
                            this.hbox = null;
                            this.setText(t.toString());
                            this.setGraphic(graphic);
                        }
                    }
                    else {
                        this.hbox = null;
                        if (t instanceof Node) {
                            this.setText(null);
                            this.setGraphic((Node)t);
                        }
                        else {
                            this.setText(t.toString());
                            this.setGraphic(null);
                        }
                    }
                }
            }
            
            public void updateItem(final T t, final boolean b) {
                super.updateItem(t, b);
                this.updateDisplay(t, b);
            }
        };
    }
    
    private void onFocusPreviousCell() {
        final FocusModel focusModel = this.getSkinnable().getFocusModel();
        if (focusModel == null) {
            return;
        }
        this.flow.scrollTo(focusModel.getFocusedIndex());
    }
    
    private void onFocusNextCell() {
        final FocusModel focusModel = this.getSkinnable().getFocusModel();
        if (focusModel == null) {
            return;
        }
        this.flow.scrollTo(focusModel.getFocusedIndex());
    }
    
    private void onSelectPreviousCell() {
        this.flow.scrollTo(this.getSkinnable().getSelectionModel().getSelectedIndex());
    }
    
    private void onSelectNextCell() {
        this.flow.scrollTo(this.getSkinnable().getSelectionModel().getSelectedIndex());
    }
    
    private void onMoveToFirstCell() {
        this.flow.scrollTo(0);
        this.flow.setPosition(0.0);
    }
    
    private void onMoveToLastCell() {
        this.flow.scrollTo(this.getItemCount());
        this.flow.setPosition(1.0);
    }
    
    private int onScrollPageDown(final boolean b) {
        TreeCell<T> treeCell = this.flow.getLastVisibleCellWithinViewPort();
        if (treeCell == null) {
            return -1;
        }
        final MultipleSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
        final FocusModel focusModel = this.getSkinnable().getFocusModel();
        if (selectionModel == null || focusModel == null) {
            return -1;
        }
        final int index = treeCell.getIndex();
        boolean b2;
        if (b) {
            b2 = (treeCell.isFocused() || focusModel.isFocused(index));
        }
        else {
            b2 = (treeCell.isSelected() || selectionModel.isSelected(index));
        }
        if (b2 && ((b && focusModel.getFocusedIndex() == index) || (!b && selectionModel.getSelectedIndex() == index))) {
            this.flow.scrollToTop(treeCell);
            final TreeCell<T> treeCell2 = this.flow.getLastVisibleCellWithinViewPort();
            treeCell = ((treeCell2 == null) ? treeCell : treeCell2);
        }
        final int index2 = treeCell.getIndex();
        this.flow.scrollTo(treeCell);
        return index2;
    }
    
    private int onScrollPageUp(final boolean b) {
        TreeCell<T> treeCell = this.flow.getFirstVisibleCellWithinViewPort();
        if (treeCell == null) {
            return -1;
        }
        final MultipleSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
        final FocusModel focusModel = this.getSkinnable().getFocusModel();
        if (selectionModel == null || focusModel == null) {
            return -1;
        }
        final int index = treeCell.getIndex();
        boolean b2;
        if (b) {
            b2 = (treeCell.isFocused() || focusModel.isFocused(index));
        }
        else {
            b2 = (treeCell.isSelected() || selectionModel.isSelected(index));
        }
        if (b2 && ((b && focusModel.getFocusedIndex() == index) || (!b && selectionModel.getSelectedIndex() == index))) {
            this.flow.scrollToBottom(treeCell);
            final TreeCell<T> treeCell2 = this.flow.getFirstVisibleCellWithinViewPort();
            treeCell = ((treeCell2 == null) ? treeCell : treeCell2);
        }
        final int index2 = treeCell.getIndex();
        this.flow.scrollTo(treeCell);
        return index2;
    }
    
    static {
        IS_PANNABLE = AccessController.doPrivileged(() -> Boolean.getBoolean("javafx.scene.control.skin.TreeViewSkin.pannable"));
    }
}
