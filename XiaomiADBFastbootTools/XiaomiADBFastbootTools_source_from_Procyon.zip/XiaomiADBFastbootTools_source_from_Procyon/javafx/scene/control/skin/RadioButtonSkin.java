// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.Node;
import com.sun.javafx.scene.control.skin.Utils;
import com.sun.javafx.scene.control.behavior.ToggleButtonBehavior;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.layout.StackPane;
import javafx.scene.control.RadioButton;

public class RadioButtonSkin extends LabeledSkinBase<RadioButton>
{
    private StackPane radio;
    private final BehaviorBase<RadioButton> behavior;
    
    public RadioButtonSkin(final RadioButton radioButton) {
        super(radioButton);
        this.behavior = new ToggleButtonBehavior<RadioButton>(radioButton);
        this.radio = createRadio();
        this.updateChildren();
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void updateChildren() {
        super.updateChildren();
        if (this.radio != null) {
            this.getChildren().add(this.radio);
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return super.computeMinWidth(n, n2, n3, n4, n5) + this.snapSizeX(this.radio.minWidth(-1.0));
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Math.max(this.snapSizeY(super.computeMinHeight(n - this.radio.minWidth(-1.0), n2, n3, n4, n5)), n2 + this.radio.minHeight(-1.0) + n4);
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return super.computePrefWidth(n, n2, n3, n4, n5) + this.snapSizeX(this.radio.prefWidth(-1.0));
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Math.max(this.snapSizeY(super.computePrefHeight(n - this.radio.prefWidth(-1.0), n2, n3, n4, n5)), n2 + this.radio.prefHeight(-1.0) + n4);
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double b) {
        final RadioButton radioButton = this.getSkinnable();
        final double prefWidth = this.radio.prefWidth(-1.0);
        final double prefHeight = this.radio.prefHeight(-1.0);
        final double min = Math.min(Math.max(radioButton.prefWidth(-1.0), radioButton.minWidth(-1.0)) - prefWidth, n3 - this.snapSizeX(prefWidth));
        final double max = Math.max(prefHeight, Math.min(radioButton.prefHeight(min), b));
        final double n4 = Utils.computeXOffset(n3, min + prefWidth, radioButton.getAlignment().getHpos()) + n;
        final double n5 = Utils.computeYOffset(b, max, radioButton.getAlignment().getVpos()) + n2;
        this.layoutLabelInArea(n4 + prefWidth, n5, min, max, radioButton.getAlignment());
        this.radio.resize(this.snapSizeX(prefWidth), this.snapSizeY(prefHeight));
        this.positionInArea(this.radio, n4, n5, prefWidth, max, 0.0, radioButton.getAlignment().getHpos(), radioButton.getAlignment().getVpos());
    }
    
    private static StackPane createRadio() {
        final StackPane stackPane = new StackPane();
        stackPane.getStyleClass().setAll("radio");
        stackPane.setSnapToPixel(false);
        final StackPane stackPane2 = new StackPane();
        stackPane2.getStyleClass().setAll("dot");
        stackPane.getChildren().clear();
        stackPane.getChildren().addAll(stackPane2);
        return stackPane;
    }
}
