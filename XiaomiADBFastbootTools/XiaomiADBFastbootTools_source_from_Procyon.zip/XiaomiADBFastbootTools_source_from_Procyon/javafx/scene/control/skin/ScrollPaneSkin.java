// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.Parent;
import javafx.event.EventDispatchChain;
import javafx.event.ActionEvent;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.event.EventDispatcher;
import javafx.event.EventHandler;
import javafx.scene.input.TouchEvent;
import javafx.animation.Animation;
import javafx.event.Event;
import javafx.scene.input.ScrollEvent;
import com.sun.javafx.util.Utils;
import javafx.scene.input.MouseEvent;
import javafx.geometry.Orientation;
import com.sun.javafx.scene.ParentHelper;
import com.sun.javafx.scene.traversal.ParentTraversalEngine;
import javafx.scene.AccessibleAttribute;
import javafx.geometry.Insets;
import javafx.geometry.BoundingBox;
import com.sun.javafx.scene.control.Properties;
import javafx.beans.property.DoublePropertyBase;
import java.util.function.Consumer;
import com.sun.javafx.scene.control.behavior.ScrollPaneBehavior;
import javafx.beans.value.ObservableValue;
import javafx.beans.Observable;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Bounds;
import javafx.beans.value.ChangeListener;
import javafx.beans.InvalidationListener;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.shape.Rectangle;
import javafx.scene.Cursor;
import javafx.scene.control.ScrollBar;
import javafx.scene.layout.StackPane;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.Node;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SkinBase;

public class ScrollPaneSkin extends SkinBase<ScrollPane>
{
    private static final double DEFAULT_PREF_SIZE = 100.0;
    private static final double DEFAULT_MIN_SIZE = 36.0;
    private static final double DEFAULT_SB_BREADTH = 12.0;
    private static final double DEFAULT_EMBEDDED_SB_BREADTH = 8.0;
    private static final double PAN_THRESHOLD = 0.5;
    private Node scrollNode;
    private final BehaviorBase<ScrollPane> behavior;
    private double nodeWidth;
    private double nodeHeight;
    private boolean nodeSizeInvalid;
    private double posX;
    private double posY;
    private boolean hsbvis;
    private boolean vsbvis;
    private double hsbHeight;
    private double vsbWidth;
    private StackPane viewRect;
    private StackPane viewContent;
    private double contentWidth;
    private double contentHeight;
    private StackPane corner;
    ScrollBar hsb;
    ScrollBar vsb;
    double pressX;
    double pressY;
    double ohvalue;
    double ovvalue;
    private Cursor saveCursor;
    private boolean dragDetected;
    private boolean touchDetected;
    private boolean mouseDown;
    Rectangle clipRect;
    Timeline sbTouchTimeline;
    KeyFrame sbTouchKF1;
    KeyFrame sbTouchKF2;
    Timeline contentsToViewTimeline;
    KeyFrame contentsToViewKF1;
    KeyFrame contentsToViewKF2;
    KeyFrame contentsToViewKF3;
    private boolean tempVisibility;
    private final InvalidationListener nodeListener;
    private final ChangeListener<Bounds> boundsChangeListener;
    private DoubleProperty contentPosX;
    private DoubleProperty contentPosY;
    
    public ScrollPaneSkin(final ScrollPane scrollPane) {
        super(scrollPane);
        this.nodeSizeInvalid = true;
        this.saveCursor = null;
        this.dragDetected = false;
        this.touchDetected = false;
        this.mouseDown = false;
        this.nodeListener = new InvalidationListener() {
            @Override
            public void invalidated(final Observable observable) {
                if (!ScrollPaneSkin.this.nodeSizeInvalid) {
                    final Bounds layoutBounds = ScrollPaneSkin.this.scrollNode.getLayoutBounds();
                    final double width = layoutBounds.getWidth();
                    final double height = layoutBounds.getHeight();
                    if (ScrollPaneSkin.this.vsbvis != ScrollPaneSkin.this.determineVerticalSBVisible() || ScrollPaneSkin.this.hsbvis != ScrollPaneSkin.this.determineHorizontalSBVisible() || (width != 0.0 && ScrollPaneSkin.this.nodeWidth != width) || (height != 0.0 && ScrollPaneSkin.this.nodeHeight != height)) {
                        ScrollPaneSkin.this.getSkinnable().requestLayout();
                    }
                    else if (!ScrollPaneSkin.this.dragDetected) {
                        ScrollPaneSkin.this.updateVerticalSB();
                        ScrollPaneSkin.this.updateHorizontalSB();
                    }
                }
            }
        };
        this.boundsChangeListener = new ChangeListener<Bounds>() {
            @Override
            public void changed(final ObservableValue<? extends Bounds> observableValue, final Bounds bounds, final Bounds bounds2) {
                final double height = bounds.getHeight();
                final double height2 = bounds2.getHeight();
                if (height > 0.0 && height != height2) {
                    final double value = SkinBase.this.snapPositionY(SkinBase.this.snappedTopInset() - ScrollPaneSkin.this.posY / (ScrollPaneSkin.this.vsb.getMax() - ScrollPaneSkin.this.vsb.getMin()) * (height - ScrollPaneSkin.this.contentHeight)) / SkinBase.this.snapPositionY(SkinBase.this.snappedTopInset() - ScrollPaneSkin.this.posY / (ScrollPaneSkin.this.vsb.getMax() - ScrollPaneSkin.this.vsb.getMin()) * (height2 - ScrollPaneSkin.this.contentHeight)) * ScrollPaneSkin.this.vsb.getValue();
                    if (value < 0.0) {
                        ScrollPaneSkin.this.vsb.setValue(0.0);
                    }
                    else if (value < 1.0) {
                        ScrollPaneSkin.this.vsb.setValue(value);
                    }
                    else if (value > 1.0) {
                        ScrollPaneSkin.this.vsb.setValue(1.0);
                    }
                }
                final double width = bounds.getWidth();
                final double width2 = bounds2.getWidth();
                if (width > 0.0 && width != width2) {
                    final double value2 = SkinBase.this.snapPositionX(SkinBase.this.snappedLeftInset() - ScrollPaneSkin.this.posX / (ScrollPaneSkin.this.hsb.getMax() - ScrollPaneSkin.this.hsb.getMin()) * (width - ScrollPaneSkin.this.contentWidth)) / SkinBase.this.snapPositionX(SkinBase.this.snappedLeftInset() - ScrollPaneSkin.this.posX / (ScrollPaneSkin.this.hsb.getMax() - ScrollPaneSkin.this.hsb.getMin()) * (width2 - ScrollPaneSkin.this.contentWidth)) * ScrollPaneSkin.this.hsb.getValue();
                    if (value2 < 0.0) {
                        ScrollPaneSkin.this.hsb.setValue(0.0);
                    }
                    else if (value2 < 1.0) {
                        ScrollPaneSkin.this.hsb.setValue(value2);
                    }
                    else if (value2 > 1.0) {
                        ScrollPaneSkin.this.hsb.setValue(1.0);
                    }
                }
            }
        };
        this.behavior = new ScrollPaneBehavior(scrollPane);
        this.initialize();
        final Consumer<ObservableValue<?>> consumer = p0 -> this.getSkinnable().requestLayout();
        this.registerChangeListener(scrollPane.contentProperty(), p0 -> {
            if (this.scrollNode != this.getSkinnable().getContent()) {
                if (this.scrollNode != null) {
                    this.scrollNode.layoutBoundsProperty().removeListener(this.nodeListener);
                    this.scrollNode.layoutBoundsProperty().removeListener(this.boundsChangeListener);
                    this.viewContent.getChildren().remove(this.scrollNode);
                }
                this.scrollNode = this.getSkinnable().getContent();
                if (this.scrollNode != null) {
                    this.nodeWidth = this.snapSizeX(this.scrollNode.getLayoutBounds().getWidth());
                    this.nodeHeight = this.snapSizeY(this.scrollNode.getLayoutBounds().getHeight());
                    this.viewContent.getChildren().setAll(this.scrollNode);
                    this.scrollNode.layoutBoundsProperty().addListener(this.nodeListener);
                    this.scrollNode.layoutBoundsProperty().addListener(this.boundsChangeListener);
                }
            }
            this.getSkinnable().requestLayout();
            return;
        });
        this.registerChangeListener(scrollPane.fitToWidthProperty(), p0 -> {
            this.getSkinnable().requestLayout();
            this.viewRect.requestLayout();
            return;
        });
        this.registerChangeListener(scrollPane.fitToHeightProperty(), p0 -> {
            this.getSkinnable().requestLayout();
            this.viewRect.requestLayout();
            return;
        });
        this.registerChangeListener(scrollPane.hbarPolicyProperty(), p0 -> this.getSkinnable().requestLayout());
        this.registerChangeListener(scrollPane.vbarPolicyProperty(), p0 -> this.getSkinnable().requestLayout());
        this.registerChangeListener(scrollPane.hvalueProperty(), p0 -> this.hsb.setValue(this.getSkinnable().getHvalue()));
        this.registerChangeListener(scrollPane.hmaxProperty(), p0 -> this.hsb.setMax(this.getSkinnable().getHmax()));
        this.registerChangeListener(scrollPane.hminProperty(), p0 -> this.hsb.setMin(this.getSkinnable().getHmin()));
        this.registerChangeListener(scrollPane.vvalueProperty(), p0 -> this.vsb.setValue(this.getSkinnable().getVvalue()));
        this.registerChangeListener(scrollPane.vmaxProperty(), p0 -> this.vsb.setMax(this.getSkinnable().getVmax()));
        this.registerChangeListener(scrollPane.vminProperty(), p0 -> this.vsb.setMin(this.getSkinnable().getVmin()));
        this.registerChangeListener(scrollPane.prefViewportWidthProperty(), consumer);
        this.registerChangeListener(scrollPane.prefViewportHeightProperty(), consumer);
        this.registerChangeListener(scrollPane.minViewportWidthProperty(), consumer);
        this.registerChangeListener(scrollPane.minViewportHeightProperty(), consumer);
    }
    
    private final void setContentPosX(final double n) {
        this.contentPosXProperty().set(n);
    }
    
    private final double getContentPosX() {
        return (this.contentPosX == null) ? 0.0 : this.contentPosX.get();
    }
    
    private final DoubleProperty contentPosXProperty() {
        if (this.contentPosX == null) {
            this.contentPosX = new DoublePropertyBase() {
                @Override
                protected void invalidated() {
                    ScrollPaneSkin.this.hsb.setValue(ScrollPaneSkin.this.getContentPosX());
                    ScrollPaneSkin.this.getSkinnable().requestLayout();
                }
                
                @Override
                public Object getBean() {
                    return ScrollPaneSkin.this;
                }
                
                @Override
                public String getName() {
                    return "contentPosX";
                }
            };
        }
        return this.contentPosX;
    }
    
    private final void setContentPosY(final double n) {
        this.contentPosYProperty().set(n);
    }
    
    private final double getContentPosY() {
        return (this.contentPosY == null) ? 0.0 : this.contentPosY.get();
    }
    
    private final DoubleProperty contentPosYProperty() {
        if (this.contentPosY == null) {
            this.contentPosY = new DoublePropertyBase() {
                @Override
                protected void invalidated() {
                    ScrollPaneSkin.this.vsb.setValue(ScrollPaneSkin.this.getContentPosY());
                    ScrollPaneSkin.this.getSkinnable().requestLayout();
                }
                
                @Override
                public Object getBean() {
                    return ScrollPaneSkin.this;
                }
                
                @Override
                public String getName() {
                    return "contentPosY";
                }
            };
        }
        return this.contentPosY;
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    public final ScrollBar getHorizontalScrollBar() {
        return this.hsb;
    }
    
    public final ScrollBar getVerticalScrollBar() {
        return this.vsb;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final ScrollPane scrollPane = this.getSkinnable();
        final double a = this.computeVsbSizeHint(scrollPane) + this.snappedLeftInset() + this.snappedRightInset();
        if (scrollPane.getPrefViewportWidth() > 0.0) {
            return scrollPane.getPrefViewportWidth() + a;
        }
        if (scrollPane.getContent() != null) {
            return scrollPane.getContent().prefWidth(n) + a;
        }
        return Math.max(a, 100.0);
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        final ScrollPane scrollPane = this.getSkinnable();
        final double a = this.computeHsbSizeHint(scrollPane) + this.snappedTopInset() + this.snappedBottomInset();
        if (scrollPane.getPrefViewportHeight() > 0.0) {
            return scrollPane.getPrefViewportHeight() + a;
        }
        if (scrollPane.getContent() != null) {
            return scrollPane.getContent().prefHeight(n) + a;
        }
        return Math.max(a, 100.0);
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final ScrollPane scrollPane = this.getSkinnable();
        final double n6 = this.computeVsbSizeHint(scrollPane) + this.snappedLeftInset() + this.snappedRightInset();
        if (scrollPane.getMinViewportWidth() > 0.0) {
            return scrollPane.getMinViewportWidth() + n6;
        }
        final double minWidth = this.corner.minWidth(-1.0);
        return (minWidth > 0.0) ? (3.0 * minWidth) : 36.0;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        final ScrollPane scrollPane = this.getSkinnable();
        final double n6 = this.computeHsbSizeHint(scrollPane) + this.snappedTopInset() + this.snappedBottomInset();
        if (scrollPane.getMinViewportHeight() > 0.0) {
            return scrollPane.getMinViewportHeight() + n6;
        }
        final double minHeight = this.corner.minHeight(-1.0);
        return (minHeight > 0.0) ? (3.0 * minHeight) : 36.0;
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double contentWidth, final double contentHeight) {
        final ScrollPane scrollPane = this.getSkinnable();
        final Insets padding = scrollPane.getPadding();
        final double snapSizeX = this.snapSizeX(padding.getRight());
        final double snapSizeX2 = this.snapSizeX(padding.getLeft());
        final double snapSizeY = this.snapSizeY(padding.getTop());
        final double snapSizeY2 = this.snapSizeY(padding.getBottom());
        this.vsb.setMin(scrollPane.getVmin());
        this.vsb.setMax(scrollPane.getVmax());
        this.hsb.setMin(scrollPane.getHmin());
        this.hsb.setMax(scrollPane.getHmax());
        this.contentWidth = contentWidth;
        this.contentHeight = contentHeight;
        double n3 = 0.0;
        double n4 = 0.0;
        this.computeScrollNodeSize(this.contentWidth, this.contentHeight);
        this.computeScrollBarSize();
        for (int i = 0; i < 2; ++i) {
            this.vsbvis = this.determineVerticalSBVisible();
            this.hsbvis = this.determineHorizontalSBVisible();
            if (this.vsbvis && !Properties.IS_TOUCH_SUPPORTED) {
                this.contentWidth = contentWidth - this.vsbWidth;
            }
            n3 = contentWidth + snapSizeX2 + snapSizeX - (this.vsbvis ? this.vsbWidth : 0.0);
            if (this.hsbvis && !Properties.IS_TOUCH_SUPPORTED) {
                this.contentHeight = contentHeight - this.hsbHeight;
            }
            n4 = contentHeight + snapSizeY + snapSizeY2 - (this.hsbvis ? this.hsbHeight : 0.0);
        }
        if (this.scrollNode != null && this.scrollNode.isResizable()) {
            if (this.vsbvis && this.hsbvis) {
                this.computeScrollNodeSize(this.contentWidth, this.contentHeight);
            }
            else if (this.hsbvis && !this.vsbvis) {
                this.computeScrollNodeSize(this.contentWidth, this.contentHeight);
                this.vsbvis = this.determineVerticalSBVisible();
                if (this.vsbvis) {
                    this.contentWidth -= this.vsbWidth;
                    n3 -= this.vsbWidth;
                    this.computeScrollNodeSize(this.contentWidth, this.contentHeight);
                }
            }
            else if (this.vsbvis && !this.hsbvis) {
                this.computeScrollNodeSize(this.contentWidth, this.contentHeight);
                this.hsbvis = this.determineHorizontalSBVisible();
                if (this.hsbvis) {
                    this.contentHeight -= this.hsbHeight;
                    n4 -= this.hsbHeight;
                    this.computeScrollNodeSize(this.contentWidth, this.contentHeight);
                }
            }
        }
        final double n5 = this.snappedLeftInset() - snapSizeX2;
        final double n6 = this.snappedTopInset() - snapSizeY;
        this.vsb.setVisible(this.vsbvis);
        if (this.vsbvis) {
            this.vsb.resizeRelocate(this.snappedLeftInset() + contentWidth - this.vsbWidth + ((snapSizeX < 1.0) ? 0.0 : (snapSizeX - 1.0)), n6, this.vsbWidth, n4);
        }
        this.updateVerticalSB();
        this.hsb.setVisible(this.hsbvis);
        if (this.hsbvis) {
            this.hsb.resizeRelocate(n5, this.snappedTopInset() + contentHeight - this.hsbHeight + ((snapSizeY2 < 1.0) ? 0.0 : (snapSizeY2 - 1.0)), n3, this.hsbHeight);
        }
        this.updateHorizontalSB();
        this.viewRect.resizeRelocate(this.snappedLeftInset(), this.snappedTopInset(), this.snapSizeX(this.contentWidth), this.snapSizeY(this.contentHeight));
        this.resetClip();
        if (this.vsbvis && this.hsbvis) {
            this.corner.setVisible(true);
            this.corner.resizeRelocate(this.snapPositionX(this.vsb.getLayoutX()), this.snapPositionY(this.hsb.getLayoutY()), this.snapSizeX(this.vsbWidth), this.snapSizeY(this.hsbHeight));
        }
        else {
            this.corner.setVisible(false);
        }
        scrollPane.setViewportBounds(new BoundingBox(this.snapPositionX(this.viewContent.getLayoutX()), this.snapPositionY(this.viewContent.getLayoutY()), this.snapSizeX(this.contentWidth), this.snapSizeY(this.contentHeight)));
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case VERTICAL_SCROLLBAR: {
                return this.vsb;
            }
            case HORIZONTAL_SCROLLBAR: {
                return this.hsb;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    private void initialize() {
        final ScrollPane scrollPane = this.getSkinnable();
        this.scrollNode = scrollPane.getContent();
        final ParentTraversalEngine parentTraversalEngine = new ParentTraversalEngine(((SkinBase<Parent>)this).getSkinnable());
        parentTraversalEngine.addTraverseListener((p0, bounds) -> this.scrollBoundsIntoView(bounds));
        ParentHelper.setTraversalEngine(((SkinBase<Parent>)this).getSkinnable(), parentTraversalEngine);
        if (this.scrollNode != null) {
            this.scrollNode.layoutBoundsProperty().addListener(this.nodeListener);
            this.scrollNode.layoutBoundsProperty().addListener(this.boundsChangeListener);
        }
        (this.viewRect = new StackPane() {
            @Override
            protected void layoutChildren() {
                ScrollPaneSkin.this.viewContent.resize(this.getWidth(), this.getHeight());
            }
        }).setManaged(false);
        this.viewRect.setCache(true);
        this.viewRect.getStyleClass().add("viewport");
        this.clipRect = new Rectangle();
        this.viewRect.setClip(this.clipRect);
        this.hsb = new ScrollBar();
        (this.vsb = new ScrollBar()).setOrientation(Orientation.VERTICAL);
        final EventHandler<? super MouseEvent> eventHandler = p0 -> {
            if (this.getSkinnable().isFocusTraversable()) {
                this.getSkinnable().requestFocus();
            }
            return;
        };
        this.hsb.addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        this.vsb.addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        this.corner = new StackPane();
        this.corner.getStyleClass().setAll("corner");
        this.viewContent = new StackPane() {
            @Override
            public void requestLayout() {
                ScrollPaneSkin.this.nodeSizeInvalid = true;
                super.requestLayout();
                ScrollPaneSkin.this.getSkinnable().requestLayout();
            }
            
            @Override
            protected void layoutChildren() {
                if (ScrollPaneSkin.this.nodeSizeInvalid) {
                    ScrollPaneSkin.this.computeScrollNodeSize(this.getWidth(), this.getHeight());
                }
                if (ScrollPaneSkin.this.scrollNode != null && ScrollPaneSkin.this.scrollNode.isResizable()) {
                    ScrollPaneSkin.this.scrollNode.resize(this.snapSize(ScrollPaneSkin.this.nodeWidth), this.snapSize(ScrollPaneSkin.this.nodeHeight));
                    if (ScrollPaneSkin.this.vsbvis != ScrollPaneSkin.this.determineVerticalSBVisible() || ScrollPaneSkin.this.hsbvis != ScrollPaneSkin.this.determineHorizontalSBVisible()) {
                        ScrollPaneSkin.this.getSkinnable().requestLayout();
                    }
                }
                if (ScrollPaneSkin.this.scrollNode != null) {
                    ScrollPaneSkin.this.scrollNode.relocate(0.0, 0.0);
                }
            }
        };
        this.viewRect.getChildren().add(this.viewContent);
        if (this.scrollNode != null) {
            this.viewContent.getChildren().add(this.scrollNode);
            this.viewRect.nodeOrientationProperty().bind((ObservableValue<?>)this.scrollNode.nodeOrientationProperty());
        }
        this.getChildren().clear();
        this.getChildren().addAll(this.viewRect, this.vsb, this.hsb, this.corner);
        this.vsb.valueProperty().addListener(p0 -> {
            if (!Properties.IS_TOUCH_SUPPORTED) {
                this.posY = Utils.clamp(this.getSkinnable().getVmin(), this.vsb.getValue(), this.getSkinnable().getVmax());
            }
            else {
                this.posY = this.vsb.getValue();
            }
            this.updatePosY();
            return;
        });
        this.hsb.valueProperty().addListener(p0 -> {
            if (!Properties.IS_TOUCH_SUPPORTED) {
                this.posX = Utils.clamp(this.getSkinnable().getHmin(), this.hsb.getValue(), this.getSkinnable().getHmax());
            }
            else {
                this.posX = this.hsb.getValue();
            }
            this.updatePosX();
            return;
        });
        this.viewRect.setOnMousePressed(mouseEvent -> {
            this.mouseDown = true;
            if (Properties.IS_TOUCH_SUPPORTED) {
                this.startSBReleasedAnimation();
            }
            this.pressX = mouseEvent.getX();
            this.pressY = mouseEvent.getY();
            this.ohvalue = this.hsb.getValue();
            this.ovvalue = this.vsb.getValue();
            return;
        });
        this.viewRect.setOnDragDetected(p0 -> {
            if (Properties.IS_TOUCH_SUPPORTED) {
                this.startSBReleasedAnimation();
            }
            if (this.getSkinnable().isPannable()) {
                this.dragDetected = true;
                if (this.saveCursor == null) {
                    this.saveCursor = this.getSkinnable().getCursor();
                    if (this.saveCursor == null) {
                        this.saveCursor = Cursor.DEFAULT;
                    }
                    this.getSkinnable().setCursor(Cursor.MOVE);
                    this.getSkinnable().requestLayout();
                }
            }
            return;
        });
        this.viewRect.addEventFilter(MouseEvent.MOUSE_RELEASED, p0 -> {
            this.mouseDown = false;
            if (this.dragDetected) {
                if (this.saveCursor != null) {
                    this.getSkinnable().setCursor(this.saveCursor);
                    this.saveCursor = null;
                    this.getSkinnable().requestLayout();
                }
                this.dragDetected = false;
            }
            if ((this.posY > this.getSkinnable().getVmax() || this.posY < this.getSkinnable().getVmin() || this.posX > this.getSkinnable().getHmax() || this.posX < this.getSkinnable().getHmin()) && !this.touchDetected) {
                this.startContentsToViewport();
            }
            return;
        });
        double a;
        double a2;
        double n;
        double n2;
        this.viewRect.setOnMouseDragged(mouseEvent2 -> {
            if (Properties.IS_TOUCH_SUPPORTED) {
                this.startSBReleasedAnimation();
            }
            if (this.getSkinnable().isPannable() || Properties.IS_TOUCH_SUPPORTED) {
                a = this.pressX - mouseEvent2.getX();
                a2 = this.pressY - mouseEvent2.getY();
                if (this.hsb.getVisibleAmount() > 0.0 && this.hsb.getVisibleAmount() < this.hsb.getMax() && Math.abs(a) > 0.5) {
                    if (this.isReverseNodeOrientation()) {
                        a = -a;
                    }
                    n = this.ohvalue + a / (this.nodeWidth - this.viewRect.getWidth()) * (this.hsb.getMax() - this.hsb.getMin());
                    if (!Properties.IS_TOUCH_SUPPORTED) {
                        if (n > this.hsb.getMax()) {
                            n = this.hsb.getMax();
                        }
                        else if (n < this.hsb.getMin()) {
                            n = this.hsb.getMin();
                        }
                        this.hsb.setValue(n);
                    }
                    else {
                        this.hsb.setValue(n);
                    }
                }
                if (this.vsb.getVisibleAmount() > 0.0 && this.vsb.getVisibleAmount() < this.vsb.getMax() && Math.abs(a2) > 0.5) {
                    n2 = this.ovvalue + a2 / (this.nodeHeight - this.viewRect.getHeight()) * (this.vsb.getMax() - this.vsb.getMin());
                    if (!Properties.IS_TOUCH_SUPPORTED) {
                        if (n2 > this.vsb.getMax()) {
                            n2 = this.vsb.getMax();
                        }
                        else if (n2 < this.vsb.getMin()) {
                            n2 = this.vsb.getMin();
                        }
                        this.vsb.setValue(n2);
                    }
                    else {
                        this.vsb.setValue(n2);
                    }
                }
            }
            mouseEvent2.consume();
            return;
        });
        final EventDispatcher eventDispatcher = (event, p1) -> event;
        final EventDispatcher eventDispatcher2;
        final EventDispatcher eventDispatcher3;
        this.hsb.setEventDispatcher((scrollEvent2, eventDispatchChain) -> {
            this.hsb.getEventDispatcher();
            if (scrollEvent2.getEventType() == ScrollEvent.SCROLL && !scrollEvent2.isDirect()) {
                eventDispatchChain = eventDispatchChain.prepend(eventDispatcher2);
                eventDispatchChain = eventDispatchChain.prepend(eventDispatcher3);
                return eventDispatchChain.dispatchEvent(scrollEvent2);
            }
            else {
                return eventDispatcher3.dispatchEvent(scrollEvent2, eventDispatchChain);
            }
        });
        final EventDispatcher eventDispatcher4;
        final EventDispatcher eventDispatcher5;
        this.vsb.setEventDispatcher((scrollEvent3, eventDispatchChain2) -> {
            this.vsb.getEventDispatcher();
            if (scrollEvent3.getEventType() == ScrollEvent.SCROLL && !scrollEvent3.isDirect()) {
                eventDispatchChain2 = eventDispatchChain2.prepend(eventDispatcher4);
                eventDispatchChain2 = eventDispatchChain2.prepend(eventDispatcher5);
                return eventDispatchChain2.dispatchEvent(scrollEvent3);
            }
            else {
                return eventDispatcher5.dispatchEvent(scrollEvent3, eventDispatchChain2);
            }
        });
        double n3;
        double n4;
        double n5;
        double n6;
        double n7;
        double n8;
        this.viewRect.addEventHandler(ScrollEvent.SCROLL, scrollEvent -> {
            if (Properties.IS_TOUCH_SUPPORTED) {
                this.startSBReleasedAnimation();
            }
            if (this.vsb.getVisibleAmount() < this.vsb.getMax()) {
                n3 = this.getSkinnable().getVmax() - this.getSkinnable().getVmin();
                if (this.nodeHeight > 0.0) {
                    n4 = n3 / this.nodeHeight;
                }
                else {
                    n4 = 0.0;
                }
                n5 = this.vsb.getValue() + -scrollEvent.getDeltaY() * n4;
                if (!Properties.IS_TOUCH_SUPPORTED) {
                    if ((scrollEvent.getDeltaY() > 0.0 && this.vsb.getValue() > this.vsb.getMin()) || (scrollEvent.getDeltaY() < 0.0 && this.vsb.getValue() < this.vsb.getMax())) {
                        this.vsb.setValue(n5);
                        scrollEvent.consume();
                    }
                }
                else if (!scrollEvent.isInertia() || (scrollEvent.isInertia() && (this.contentsToViewTimeline == null || this.contentsToViewTimeline.getStatus() == Animation.Status.STOPPED))) {
                    this.vsb.setValue(n5);
                    if ((n5 > this.vsb.getMax() || n5 < this.vsb.getMin()) && !this.mouseDown && !this.touchDetected) {
                        this.startContentsToViewport();
                    }
                    scrollEvent.consume();
                }
            }
            if (this.hsb.getVisibleAmount() < this.hsb.getMax()) {
                n6 = this.getSkinnable().getHmax() - this.getSkinnable().getHmin();
                if (this.nodeWidth > 0.0) {
                    n7 = n6 / this.nodeWidth;
                }
                else {
                    n7 = 0.0;
                }
                n8 = this.hsb.getValue() + -scrollEvent.getDeltaX() * n7;
                if (!Properties.IS_TOUCH_SUPPORTED) {
                    if ((scrollEvent.getDeltaX() > 0.0 && this.hsb.getValue() > this.hsb.getMin()) || (scrollEvent.getDeltaX() < 0.0 && this.hsb.getValue() < this.hsb.getMax())) {
                        this.hsb.setValue(n8);
                        scrollEvent.consume();
                    }
                }
                else if (!scrollEvent.isInertia() || (scrollEvent.isInertia() && (this.contentsToViewTimeline == null || this.contentsToViewTimeline.getStatus() == Animation.Status.STOPPED))) {
                    this.hsb.setValue(n8);
                    if ((n8 > this.hsb.getMax() || n8 < this.hsb.getMin()) && !this.mouseDown && !this.touchDetected) {
                        this.startContentsToViewport();
                    }
                    scrollEvent.consume();
                }
            }
            return;
        });
        this.getSkinnable().addEventHandler(TouchEvent.TOUCH_PRESSED, touchEvent -> {
            this.touchDetected = true;
            this.startSBReleasedAnimation();
            touchEvent.consume();
            return;
        });
        this.getSkinnable().addEventHandler(TouchEvent.TOUCH_RELEASED, touchEvent2 -> {
            this.touchDetected = false;
            touchEvent2.consume();
            return;
        });
        this.consumeMouseEvents(false);
        this.hsb.setValue(scrollPane.getHvalue());
        this.vsb.setValue(scrollPane.getVvalue());
    }
    
    void scrollBoundsIntoView(final Bounds bounds) {
        double n = 0.0;
        double n2 = 0.0;
        if (bounds.getMaxX() > this.contentWidth) {
            n = bounds.getMinX() - this.snappedLeftInset();
        }
        if (bounds.getMinX() < this.snappedLeftInset()) {
            n = bounds.getMaxX() - this.contentWidth - this.snappedLeftInset();
        }
        if (bounds.getMaxY() > this.snappedTopInset() + this.contentHeight) {
            n2 = bounds.getMinY() - this.snappedTopInset();
        }
        if (bounds.getMinY() < this.snappedTopInset()) {
            n2 = bounds.getMaxY() - this.contentHeight - this.snappedTopInset();
        }
        if (n != 0.0) {
            final double d = n * (this.hsb.getMax() - this.hsb.getMin()) / (this.nodeWidth - this.contentWidth);
            this.hsb.setValue(this.hsb.getValue() + (d + -1.0 * Math.signum(d) * this.hsb.getUnitIncrement() / 5.0));
            this.getSkinnable().requestLayout();
        }
        if (n2 != 0.0) {
            final double d2 = n2 * (this.vsb.getMax() - this.vsb.getMin()) / (this.nodeHeight - this.contentHeight);
            this.vsb.setValue(this.vsb.getValue() + (d2 + -1.0 * Math.signum(d2) * this.vsb.getUnitIncrement() / 5.0));
            this.getSkinnable().requestLayout();
        }
    }
    
    private double computeHsbSizeHint(final ScrollPane scrollPane) {
        return (scrollPane.getHbarPolicy() == ScrollPane.ScrollBarPolicy.ALWAYS || (scrollPane.getHbarPolicy() == ScrollPane.ScrollBarPolicy.AS_NEEDED && (scrollPane.getPrefViewportHeight() > 0.0 || scrollPane.getMinViewportHeight() > 0.0))) ? this.hsb.prefHeight(-1.0) : 0.0;
    }
    
    private double computeVsbSizeHint(final ScrollPane scrollPane) {
        return (scrollPane.getVbarPolicy() == ScrollPane.ScrollBarPolicy.ALWAYS || (scrollPane.getVbarPolicy() == ScrollPane.ScrollBarPolicy.AS_NEEDED && (scrollPane.getPrefViewportWidth() > 0.0 || scrollPane.getMinViewportWidth() > 0.0))) ? this.vsb.prefWidth(-1.0) : 0.0;
    }
    
    private void computeScrollNodeSize(final double n, final double n2) {
        if (this.scrollNode != null) {
            if (this.scrollNode.isResizable()) {
                final ScrollPane scrollPane = this.getSkinnable();
                final Orientation contentBias = this.scrollNode.getContentBias();
                if (contentBias == null) {
                    this.nodeWidth = this.snapSizeX(com.sun.javafx.scene.control.skin.Utils.boundedSize(scrollPane.isFitToWidth() ? n : this.scrollNode.prefWidth(-1.0), this.scrollNode.minWidth(-1.0), this.scrollNode.maxWidth(-1.0)));
                    this.nodeHeight = this.snapSizeY(com.sun.javafx.scene.control.skin.Utils.boundedSize(scrollPane.isFitToHeight() ? n2 : this.scrollNode.prefHeight(-1.0), this.scrollNode.minHeight(-1.0), this.scrollNode.maxHeight(-1.0)));
                }
                else if (contentBias == Orientation.HORIZONTAL) {
                    this.nodeWidth = this.snapSizeX(com.sun.javafx.scene.control.skin.Utils.boundedSize(scrollPane.isFitToWidth() ? n : this.scrollNode.prefWidth(-1.0), this.scrollNode.minWidth(-1.0), this.scrollNode.maxWidth(-1.0)));
                    this.nodeHeight = this.snapSizeY(com.sun.javafx.scene.control.skin.Utils.boundedSize(scrollPane.isFitToHeight() ? n2 : this.scrollNode.prefHeight(this.nodeWidth), this.scrollNode.minHeight(this.nodeWidth), this.scrollNode.maxHeight(this.nodeWidth)));
                }
                else {
                    this.nodeHeight = this.snapSizeY(com.sun.javafx.scene.control.skin.Utils.boundedSize(scrollPane.isFitToHeight() ? n2 : this.scrollNode.prefHeight(-1.0), this.scrollNode.minHeight(-1.0), this.scrollNode.maxHeight(-1.0)));
                    this.nodeWidth = this.snapSizeX(com.sun.javafx.scene.control.skin.Utils.boundedSize(scrollPane.isFitToWidth() ? n : this.scrollNode.prefWidth(this.nodeHeight), this.scrollNode.minWidth(this.nodeHeight), this.scrollNode.maxWidth(this.nodeHeight)));
                }
            }
            else {
                this.nodeWidth = this.snapSizeX(this.scrollNode.getLayoutBounds().getWidth());
                this.nodeHeight = this.snapSizeY(this.scrollNode.getLayoutBounds().getHeight());
            }
            this.nodeSizeInvalid = false;
        }
    }
    
    private boolean isReverseNodeOrientation() {
        return this.scrollNode != null && this.getSkinnable().getEffectiveNodeOrientation() != this.scrollNode.getEffectiveNodeOrientation();
    }
    
    private boolean determineHorizontalSBVisible() {
        final ScrollPane scrollPane = this.getSkinnable();
        if (Properties.IS_TOUCH_SUPPORTED) {
            return this.tempVisibility && this.nodeWidth > this.contentWidth;
        }
        final ScrollPane.ScrollBarPolicy hbarPolicy = scrollPane.getHbarPolicy();
        return ScrollPane.ScrollBarPolicy.NEVER != hbarPolicy && (ScrollPane.ScrollBarPolicy.ALWAYS == hbarPolicy || ((scrollPane.isFitToWidth() && this.scrollNode != null && this.scrollNode.isResizable()) ? (this.nodeWidth > this.contentWidth && this.scrollNode.minWidth(-1.0) > this.contentWidth) : (this.nodeWidth > this.contentWidth)));
    }
    
    private boolean determineVerticalSBVisible() {
        final ScrollPane scrollPane = this.getSkinnable();
        if (Properties.IS_TOUCH_SUPPORTED) {
            return this.tempVisibility && this.nodeHeight > this.contentHeight;
        }
        final ScrollPane.ScrollBarPolicy vbarPolicy = scrollPane.getVbarPolicy();
        return ScrollPane.ScrollBarPolicy.NEVER != vbarPolicy && (ScrollPane.ScrollBarPolicy.ALWAYS == vbarPolicy || ((scrollPane.isFitToHeight() && this.scrollNode != null && this.scrollNode.isResizable()) ? (this.nodeHeight > this.contentHeight && this.scrollNode.minHeight(-1.0) > this.contentHeight) : (this.nodeHeight > this.contentHeight)));
    }
    
    private void computeScrollBarSize() {
        this.vsbWidth = this.snapSizeX(this.vsb.prefWidth(-1.0));
        if (this.vsbWidth == 0.0) {
            if (Properties.IS_TOUCH_SUPPORTED) {
                this.vsbWidth = 8.0;
            }
            else {
                this.vsbWidth = 12.0;
            }
        }
        this.hsbHeight = this.snapSizeY(this.hsb.prefHeight(-1.0));
        if (this.hsbHeight == 0.0) {
            if (Properties.IS_TOUCH_SUPPORTED) {
                this.hsbHeight = 8.0;
            }
            else {
                this.hsbHeight = 12.0;
            }
        }
    }
    
    private void updateHorizontalSB() {
        final double n = this.nodeWidth * (this.hsb.getMax() - this.hsb.getMin());
        if (n > 0.0) {
            this.hsb.setVisibleAmount(this.contentWidth / n);
            this.hsb.setBlockIncrement(0.9 * this.hsb.getVisibleAmount());
            this.hsb.setUnitIncrement(0.1 * this.hsb.getVisibleAmount());
        }
        else {
            this.hsb.setVisibleAmount(0.0);
            this.hsb.setBlockIncrement(0.0);
            this.hsb.setUnitIncrement(0.0);
        }
        if (this.hsb.isVisible()) {
            this.updatePosX();
        }
        else if (this.nodeWidth > this.contentWidth) {
            this.updatePosX();
        }
        else {
            this.viewContent.setLayoutX(0.0);
        }
    }
    
    private void updateVerticalSB() {
        final double n = this.nodeHeight * (this.vsb.getMax() - this.vsb.getMin());
        if (n > 0.0) {
            this.vsb.setVisibleAmount(this.contentHeight / n);
            this.vsb.setBlockIncrement(0.9 * this.vsb.getVisibleAmount());
            this.vsb.setUnitIncrement(0.1 * this.vsb.getVisibleAmount());
        }
        else {
            this.vsb.setVisibleAmount(0.0);
            this.vsb.setBlockIncrement(0.0);
            this.vsb.setUnitIncrement(0.0);
        }
        if (this.vsb.isVisible()) {
            this.updatePosY();
        }
        else if (this.nodeHeight > this.contentHeight) {
            this.updatePosY();
        }
        else {
            this.viewContent.setLayoutY(0.0);
        }
    }
    
    private double updatePosX() {
        final ScrollPane scrollPane = this.getSkinnable();
        this.viewContent.setLayoutX(this.snapPositionX(Math.min(-(this.isReverseNodeOrientation() ? (this.hsb.getMax() - (this.posX - this.hsb.getMin())) : this.posX) / (this.hsb.getMax() - this.hsb.getMin()) * (this.nodeWidth - this.contentWidth), 0.0)));
        if (!scrollPane.hvalueProperty().isBound()) {
            scrollPane.setHvalue(Utils.clamp(scrollPane.getHmin(), this.posX, scrollPane.getHmax()));
        }
        return this.posX;
    }
    
    private double updatePosY() {
        final ScrollPane scrollPane = this.getSkinnable();
        this.viewContent.setLayoutY(this.snapPositionY(Math.min(-this.posY / (this.vsb.getMax() - this.vsb.getMin()) * (this.nodeHeight - this.contentHeight), 0.0)));
        if (!scrollPane.vvalueProperty().isBound()) {
            scrollPane.setVvalue(Utils.clamp(scrollPane.getVmin(), this.posY, scrollPane.getVmax()));
        }
        return this.posY;
    }
    
    private void resetClip() {
        this.clipRect.setWidth(this.snapSizeX(this.contentWidth));
        this.clipRect.setHeight(this.snapSizeY(this.contentHeight));
    }
    
    private void startSBReleasedAnimation() {
        if (this.sbTouchTimeline == null) {
            this.sbTouchTimeline = new Timeline();
            this.sbTouchKF1 = new KeyFrame(Duration.millis(0.0), p0 -> {
                this.tempVisibility = true;
                if (this.touchDetected || this.mouseDown) {
                    this.sbTouchTimeline.playFromStart();
                }
                return;
            }, new KeyValue[0]);
            this.sbTouchKF2 = new KeyFrame(Duration.millis(1000.0), p0 -> {
                this.tempVisibility = false;
                this.getSkinnable().requestLayout();
                return;
            }, new KeyValue[0]);
            this.sbTouchTimeline.getKeyFrames().addAll(this.sbTouchKF1, this.sbTouchKF2);
        }
        this.sbTouchTimeline.playFromStart();
    }
    
    private void startContentsToViewport() {
        double d = this.posX;
        double d2 = this.posY;
        this.setContentPosX(this.posX);
        this.setContentPosY(this.posY);
        if (this.posY > this.getSkinnable().getVmax()) {
            d2 = this.getSkinnable().getVmax();
        }
        else if (this.posY < this.getSkinnable().getVmin()) {
            d2 = this.getSkinnable().getVmin();
        }
        if (this.posX > this.getSkinnable().getHmax()) {
            d = this.getSkinnable().getHmax();
        }
        else if (this.posX < this.getSkinnable().getHmin()) {
            d = this.getSkinnable().getHmin();
        }
        if (!Properties.IS_TOUCH_SUPPORTED) {
            this.startSBReleasedAnimation();
        }
        if (this.contentsToViewTimeline != null) {
            this.contentsToViewTimeline.stop();
        }
        this.contentsToViewTimeline = new Timeline();
        this.contentsToViewKF1 = new KeyFrame(Duration.millis(50.0), new KeyValue[0]);
        this.contentsToViewKF2 = new KeyFrame(Duration.millis(150.0), p0 -> this.getSkinnable().requestLayout(), new KeyValue[] { new KeyValue((WritableValue<T>)this.contentPosX, (T)d), new KeyValue((WritableValue<T>)this.contentPosY, (T)d2) });
        this.contentsToViewKF3 = new KeyFrame(Duration.millis(1500.0), new KeyValue[0]);
        this.contentsToViewTimeline.getKeyFrames().addAll(this.contentsToViewKF1, this.contentsToViewKF2, this.contentsToViewKF3);
        this.contentsToViewTimeline.playFromStart();
    }
}
