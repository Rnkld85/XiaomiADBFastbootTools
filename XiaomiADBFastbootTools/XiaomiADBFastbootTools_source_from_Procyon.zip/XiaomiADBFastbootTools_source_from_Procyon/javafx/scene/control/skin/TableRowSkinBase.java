// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import com.sun.javafx.PlatformUtil;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.Observable;
import javafx.animation.FadeTransition;
import java.lang.ref.WeakReference;
import javafx.scene.control.Skin;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import java.util.Iterator;
import java.util.Collection;
import javafx.css.StyleOrigin;
import javafx.geometry.Pos;
import javafx.css.StyleableObjectProperty;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableList;
import javafx.beans.value.ObservableValue;
import java.util.ArrayList;
import javafx.collections.WeakListChangeListener;
import javafx.collections.ListChangeListener;
import java.util.List;
import java.lang.ref.Reference;
import java.util.WeakHashMap;
import javafx.scene.control.TableColumnBase;
import java.util.Map;
import javafx.util.Duration;
import javafx.scene.control.IndexedCell;

public abstract class TableRowSkinBase<T, C extends IndexedCell, R extends IndexedCell> extends CellSkinBase<C>
{
    private static boolean IS_STUB_TOOLKIT;
    private static boolean DO_ANIMATIONS;
    private static final Duration FADE_DURATION;
    static final Map<TableColumnBase<?, ?>, Double> maxDisclosureWidthMap;
    private static final int DEFAULT_FULL_REFRESH_COUNTER = 100;
    WeakHashMap<TableColumnBase, Reference<R>> cellsMap;
    final List<R> cells;
    private int fullRefreshCounter;
    boolean isDirty;
    boolean updateCells;
    double fixedCellSize;
    boolean fixedCellSizeEnabled;
    private ListChangeListener<TableColumnBase> visibleLeafColumnsListener;
    private WeakListChangeListener<TableColumnBase> weakVisibleLeafColumnsListener;
    
    public TableRowSkinBase(final C c) {
        super(c);
        this.cells = new ArrayList<R>();
        this.fullRefreshCounter = 100;
        this.isDirty = false;
        this.updateCells = false;
        this.visibleLeafColumnsListener = (p0 -> {
            this.isDirty = true;
            this.getSkinnable().requestLayout();
            return;
        });
        this.weakVisibleLeafColumnsListener = new WeakListChangeListener<TableColumnBase>(this.visibleLeafColumnsListener);
        this.getSkinnable().setPickOnBounds(false);
        this.recreateCells();
        this.updateCells(true);
        this.getVisibleLeafColumns().addListener(this.weakVisibleLeafColumnsListener);
        c.itemProperty().addListener(p0 -> this.requestCellUpdate());
        this.registerChangeListener(c.indexProperty(), p0 -> {
            if (this.getSkinnable().isEmpty()) {
                this.requestCellUpdate();
            }
        });
    }
    
    protected abstract R createCell(final TableColumnBase<T, ?> p0);
    
    protected abstract void updateCell(final R p0, final C p1);
    
    protected abstract TableColumnBase<T, ?> getTableColumn(final R p0);
    
    protected abstract ObservableList<? extends TableColumnBase> getVisibleLeafColumns();
    
    protected ObjectProperty<Node> graphicProperty() {
        return null;
    }
    
    @Override
    protected void layoutChildren(double n, final double n2, final double n3, final double n4) {
        this.checkState();
        if (this.cellsMap.isEmpty()) {
            return;
        }
        final ObservableList<? extends TableColumnBase> visibleLeafColumns = this.getVisibleLeafColumns();
        if (visibleLeafColumns.isEmpty()) {
            super.layoutChildren(n, n2, n3, n4);
            return;
        }
        final IndexedCell indexedCell = this.getSkinnable();
        double n5 = 0.0;
        double prefWidth = 0.0;
        final boolean indentationRequired = this.isIndentationRequired();
        final boolean disclosureNodeVisible = this.isDisclosureNodeVisible();
        int n6 = 0;
        Node disclosureNode = null;
        if (indentationRequired) {
            final TableColumnBase treeColumn = this.getTreeColumn();
            final int n7 = (treeColumn == null) ? 0 : visibleLeafColumns.indexOf(treeColumn);
            n6 = ((n7 < 0) ? 0 : n7);
            int indentationLevel = this.getIndentationLevel((C)indexedCell);
            if (!this.isShowRoot()) {
                --indentationLevel;
            }
            n5 = indentationLevel * this.getIndentationPerLevel();
            final double n8 = prefWidth = (TableRowSkinBase.maxDisclosureWidthMap.containsKey(treeColumn) ? TableRowSkinBase.maxDisclosureWidthMap.get(treeColumn) : 0.0);
            disclosureNode = this.getDisclosureNode();
            if (disclosureNode != null) {
                disclosureNode.setVisible(disclosureNodeVisible);
                if (disclosureNodeVisible) {
                    prefWidth = disclosureNode.prefWidth(n4);
                    if (prefWidth > n8) {
                        TableRowSkinBase.maxDisclosureWidthMap.put(treeColumn, prefWidth);
                        final VirtualFlow<C> virtualFlow = this.getVirtualFlow();
                        this.getSkinnable().getIndex();
                        for (int i = 0; i < virtualFlow.cells.size(); ++i) {
                            final IndexedCell indexedCell2 = virtualFlow.cells.get(i);
                            if (indexedCell2 != null) {
                                if (!indexedCell2.isEmpty()) {
                                    indexedCell2.requestLayout();
                                    indexedCell2.layout();
                                }
                            }
                        }
                    }
                }
            }
        }
        final double n9 = this.snappedTopInset() + this.snappedBottomInset();
        final double n10 = this.snappedLeftInset() + this.snappedRightInset();
        final double height = indexedCell.getHeight();
        if (indexedCell.getIndex() < 0) {
            return;
        }
        for (int j = 0; j < this.cells.size(); ++j) {
            final IndexedCell indexedCell3 = this.cells.get(j);
            final TableColumnBase<T, ?> tableColumn = this.getTableColumn((R)indexedCell3);
            boolean columnPartiallyOrFullyVisible = true;
            double fixedCellSize;
            if (this.fixedCellSizeEnabled) {
                columnPartiallyOrFullyVisible = this.isColumnPartiallyOrFullyVisible(tableColumn);
                fixedCellSize = this.fixedCellSize;
            }
            else {
                fixedCellSize = this.snapSizeY(Math.max(height, indexedCell3.prefHeight(-1.0))) - this.snapSizeY(n9);
            }
            double n11;
            if (columnPartiallyOrFullyVisible) {
                if (this.fixedCellSizeEnabled && indexedCell3.getParent() == null) {
                    this.getChildren().add(indexedCell3);
                }
                n11 = indexedCell3.prefWidth(fixedCellSize) - this.snapSizeX(n10);
                final boolean b = n4 <= 24.0;
                final StyleOrigin styleOrigin = ((StyleableObjectProperty)indexedCell3.alignmentProperty()).getStyleOrigin();
                if (!b && styleOrigin == null) {
                    indexedCell3.setAlignment(Pos.TOP_LEFT);
                }
                if (indentationRequired && j == n6) {
                    if (disclosureNodeVisible) {
                        final double prefHeight = disclosureNode.prefHeight(prefWidth);
                        if (n11 > 0.0 && n11 < prefWidth + n5) {
                            this.fadeOut(disclosureNode);
                        }
                        else {
                            this.fadeIn(disclosureNode);
                            disclosureNode.resize(prefWidth, prefHeight);
                            disclosureNode.relocate(n + n5, b ? (n4 / 2.0 - prefHeight / 2.0) : (n2 + indexedCell3.getPadding().getTop()));
                            disclosureNode.toFront();
                        }
                    }
                    final ObjectProperty<Node> graphicProperty = this.graphicProperty();
                    final Node node = (graphicProperty == null) ? null : graphicProperty.get();
                    if (node != null) {
                        final double n12 = node.prefWidth(-1.0) + 3.0;
                        final double prefHeight2 = node.prefHeight(n12);
                        if (n11 > 0.0 && n11 < prefWidth + n5 + n12) {
                            this.fadeOut(node);
                        }
                        else {
                            this.fadeIn(node);
                            node.relocate(n + n5 + prefWidth, b ? (n4 / 2.0 - prefHeight2 / 2.0) : (n2 + indexedCell3.getPadding().getTop()));
                            node.toFront();
                        }
                    }
                }
                indexedCell3.resize(n11, fixedCellSize);
                indexedCell3.relocate(n, this.snappedTopInset());
                indexedCell3.requestLayout();
            }
            else {
                n11 = this.snapSizeX(indexedCell3.prefWidth(-1.0)) - this.snapSizeX(n10);
                if (this.fixedCellSizeEnabled) {
                    this.getChildren().remove(indexedCell3);
                }
            }
            n += n11;
        }
    }
    
    int getIndentationLevel(final C c) {
        return 0;
    }
    
    double getIndentationPerLevel() {
        return 0.0;
    }
    
    boolean isIndentationRequired() {
        return false;
    }
    
    TableColumnBase getTreeColumn() {
        return null;
    }
    
    Node getDisclosureNode() {
        return null;
    }
    
    boolean isDisclosureNodeVisible() {
        return false;
    }
    
    boolean isShowRoot() {
        return true;
    }
    
    void updateCells(final boolean b) {
        if (b) {
            if (this.fullRefreshCounter == 0) {
                this.recreateCells();
            }
            --this.fullRefreshCounter;
        }
        final boolean empty = this.cells.isEmpty();
        this.cells.clear();
        final IndexedCell indexedCell = this.getSkinnable();
        final int index = indexedCell.getIndex();
        final ObservableList<? extends TableColumnBase> visibleLeafColumns = this.getVisibleLeafColumns();
        for (int i = 0; i < visibleLeafColumns.size(); ++i) {
            final TableColumnBase<T, ?> key = visibleLeafColumns.get(i);
            IndexedCell cellAndCache = null;
            if (this.cellsMap.containsKey(key)) {
                cellAndCache = this.cellsMap.get(key).get();
                if (cellAndCache == null) {
                    this.cellsMap.remove(key);
                }
            }
            if (cellAndCache == null) {
                cellAndCache = this.createCellAndCache(key);
            }
            this.updateCell((R)cellAndCache, (C)indexedCell);
            cellAndCache.updateIndex(index);
            this.cells.add((R)cellAndCache);
        }
        if (this.fixedCellSizeEnabled) {
            final ArrayList<R> list = new ArrayList<R>();
            for (final IndexedCell indexedCell2 : this.getChildren()) {
                if (!(indexedCell2 instanceof IndexedCell)) {
                    continue;
                }
                if (this.getTableColumn((R)indexedCell2).isVisible()) {
                    continue;
                }
                list.add((R)indexedCell2);
            }
            this.getChildren().removeAll(list);
        }
        else if (!this.fixedCellSizeEnabled && (b || empty)) {
            this.getChildren().setAll(this.cells);
        }
    }
    
    VirtualFlow<C> getVirtualFlow() {
        for (Parent parent = this.getSkinnable(); parent != null; parent = parent.getParent()) {
            if (parent instanceof VirtualFlow) {
                return (VirtualFlow<C>)parent;
            }
        }
        return null;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        final Iterator<R> iterator = this.cells.iterator();
        while (iterator.hasNext()) {
            n6 += iterator.next().prefWidth(n);
        }
        return n6;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.fixedCellSizeEnabled) {
            return this.fixedCellSize;
        }
        this.checkState();
        if (this.getCellSize() < 24.0) {
            return this.getCellSize();
        }
        double max = 0.0;
        for (int size = this.cells.size(), i = 0; i < size; ++i) {
            max = Math.max(max, this.cells.get(i).prefHeight(-1.0));
        }
        return Math.max(max, Math.max(this.getCellSize(), this.getSkinnable().minHeight(-1.0)));
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.fixedCellSizeEnabled) {
            return this.fixedCellSize;
        }
        this.checkState();
        if (this.getCellSize() < 24.0) {
            return this.getCellSize();
        }
        double max = 0.0;
        for (int size = this.cells.size(), i = 0; i < size; ++i) {
            max = Math.max(max, this.cells.get(i).minHeight(-1.0));
        }
        return max;
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.fixedCellSizeEnabled) {
            return this.fixedCellSize;
        }
        return super.computeMaxHeight(n, n2, n3, n4, n5);
    }
    
    final void checkState() {
        if (this.isDirty) {
            this.updateCells(true);
            this.isDirty = false;
            this.updateCells = false;
        }
        else if (this.updateCells) {
            this.updateCells(false);
            this.updateCells = false;
        }
    }
    
    private boolean isColumnPartiallyOrFullyVisible(final TableColumnBase obj) {
        if (obj == null || !obj.isVisible()) {
            return false;
        }
        final VirtualFlow<C> virtualFlow = this.getVirtualFlow();
        final double n = (virtualFlow == null) ? 0.0 : virtualFlow.getHbar().getValue();
        double n2 = 0.0;
        final ObservableList<? extends TableColumnBase> visibleLeafColumns = this.getVisibleLeafColumns();
        for (int i = 0; i < visibleLeafColumns.size(); ++i) {
            final TableColumnBase tableColumnBase = visibleLeafColumns.get(i);
            if (tableColumnBase.equals(obj)) {
                break;
            }
            n2 += tableColumnBase.getWidth();
        }
        final double n3 = n2 + obj.getWidth();
        final Insets padding = this.getSkinnable().getPadding();
        final double n4 = this.getSkinnable().getWidth() - padding.getLeft() + padding.getRight();
        return (n2 >= n || n3 > n) && (n2 < n4 + n || n3 <= n4 + n);
    }
    
    private void requestCellUpdate() {
        this.updateCells = true;
        this.getSkinnable().requestLayout();
        final int index = this.getSkinnable().getIndex();
        for (int i = 0; i < this.cells.size(); ++i) {
            this.cells.get(i).updateIndex(index);
        }
    }
    
    private void recreateCells() {
        if (this.cellsMap != null) {
            final Iterator<Reference<R>> iterator = this.cellsMap.values().iterator();
            while (iterator.hasNext()) {
                final IndexedCell indexedCell = iterator.next().get();
                if (indexedCell != null) {
                    indexedCell.updateIndex(-1);
                    indexedCell.getSkin().dispose();
                    indexedCell.setSkin(null);
                }
            }
            this.cellsMap.clear();
        }
        final ObservableList<? extends TableColumnBase> visibleLeafColumns = this.getVisibleLeafColumns();
        this.cellsMap = new WeakHashMap<TableColumnBase, Reference<R>>(visibleLeafColumns.size());
        this.fullRefreshCounter = 100;
        this.getChildren().clear();
        for (final TableColumnBase<T, ?> key : visibleLeafColumns) {
            if (this.cellsMap.containsKey(key)) {
                continue;
            }
            this.createCellAndCache(key);
        }
    }
    
    private R createCellAndCache(final TableColumnBase<T, ?> key) {
        final IndexedCell cell = this.createCell(key);
        this.cellsMap.put(key, new WeakReference<R>((R)cell));
        return (R)cell;
    }
    
    private void fadeOut(final Node node) {
        if (node.getOpacity() < 1.0) {
            return;
        }
        if (!TableRowSkinBase.DO_ANIMATIONS) {
            node.setOpacity(0.0);
            return;
        }
        final FadeTransition fadeTransition = new FadeTransition(TableRowSkinBase.FADE_DURATION, node);
        fadeTransition.setToValue(0.0);
        fadeTransition.play();
    }
    
    private void fadeIn(final Node node) {
        if (node.getOpacity() > 0.0) {
            return;
        }
        if (!TableRowSkinBase.DO_ANIMATIONS) {
            node.setOpacity(1.0);
            return;
        }
        final FadeTransition fadeTransition = new FadeTransition(TableRowSkinBase.FADE_DURATION, node);
        fadeTransition.setToValue(1.0);
        fadeTransition.play();
    }
    
    static {
        TableRowSkinBase.IS_STUB_TOOLKIT = Toolkit.getToolkit().toString().contains("StubToolkit");
        TableRowSkinBase.DO_ANIMATIONS = (!TableRowSkinBase.IS_STUB_TOOLKIT && !PlatformUtil.isEmbedded());
        FADE_DURATION = Duration.millis(200.0);
        maxDisclosureWidthMap = new WeakHashMap<TableColumnBase<?, ?>, Double>();
    }
}
