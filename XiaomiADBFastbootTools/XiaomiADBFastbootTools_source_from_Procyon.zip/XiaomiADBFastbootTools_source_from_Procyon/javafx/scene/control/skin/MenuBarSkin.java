// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.Parent;
import java.util.Collections;
import javafx.css.converter.EnumConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import java.security.AccessControlContext;
import java.security.AccessController;
import com.sun.javafx.FXPermissions;
import java.security.Permission;
import javafx.beans.Observable;
import javafx.collections.MapChangeListener;
import javafx.util.Pair;
import java.util.Optional;
import javafx.scene.AccessibleAttribute;
import com.sun.javafx.scene.SceneHelper;
import java.util.Map;
import javafx.beans.property.Property;
import java.util.Collection;
import javafx.application.Platform;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import javafx.scene.Node;
import javafx.scene.control.SeparatorMenuItem;
import javafx.css.StyleableObjectProperty;
import javafx.css.StyleableDoubleProperty;
import javafx.beans.InvalidationListener;
import javafx.beans.property.ReadOnlyProperty;
import com.sun.javafx.scene.control.GlobalMenuAdapter;
import javafx.scene.control.Skin;
import javafx.geometry.Bounds;
import java.util.Iterator;
import com.sun.javafx.scene.ParentHelper;
import com.sun.javafx.scene.traversal.ParentTraversalEngine;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCombination;
import com.sun.javafx.tk.Toolkit;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.control.skin.Utils;
import com.sun.javafx.scene.traversal.Direction;
import javafx.geometry.NodeOrientation;
import javafx.scene.control.MenuButton;
import javafx.scene.control.CustomMenuItem;
import javafx.css.Styleable;
import javafx.css.CssMetaData;
import javafx.geometry.Pos;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.DoubleProperty;
import javafx.scene.control.MenuItem;
import javafx.collections.ListChangeListener;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.beans.value.ChangeListener;
import javafx.event.EventHandler;
import javafx.beans.value.WeakChangeListener;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.KeyEvent;
import javafx.event.WeakEventHandler;
import com.sun.javafx.menu.MenuBase;
import java.util.List;
import java.lang.ref.Reference;
import javafx.stage.Stage;
import java.util.WeakHashMap;
import com.sun.javafx.scene.control.MenuBarButton;
import javafx.scene.control.Menu;
import javafx.scene.layout.HBox;
import javafx.stage.Window;
import javafx.collections.ObservableList;
import javafx.scene.control.MenuBar;
import javafx.scene.control.SkinBase;

public class MenuBarSkin extends SkinBase<MenuBar>
{
    private static final ObservableList<Window> stages;
    private final HBox container;
    private Menu openMenu;
    private MenuBarButton openMenuButton;
    private Menu focusedMenu;
    private int focusedMenuIndex;
    private static WeakHashMap<Stage, Reference<MenuBarSkin>> systemMenuMap;
    private static List<MenuBase> wrappedDefaultMenus;
    private static Stage currentMenuBarStage;
    private List<MenuBase> wrappedMenus;
    private WeakEventHandler<KeyEvent> weakSceneKeyEventHandler;
    private WeakEventHandler<MouseEvent> weakSceneMouseEventHandler;
    private WeakEventHandler<KeyEvent> weakSceneAltKeyEventHandler;
    private WeakChangeListener<Boolean> weakWindowFocusListener;
    private WeakChangeListener<Window> weakWindowSceneListener;
    private EventHandler<KeyEvent> keyEventHandler;
    private EventHandler<KeyEvent> altKeyEventHandler;
    private EventHandler<MouseEvent> mouseEventHandler;
    private ChangeListener<Boolean> menuBarFocusedPropertyListener;
    private ChangeListener<Scene> sceneChangeListener;
    private ChangeListener<Boolean> menuVisibilityChangeListener;
    private boolean pendingDismiss;
    private boolean altKeyPressed;
    private EventHandler<ActionEvent> menuActionEventHandler;
    private ListChangeListener<MenuItem> menuItemListener;
    Runnable firstMenuRunnable;
    private DoubleProperty spacing;
    private ObjectProperty<Pos> containerAlignment;
    private static final CssMetaData<MenuBar, Number> SPACING;
    private static final CssMetaData<MenuBar, Pos> ALIGNMENT;
    private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
    
    public MenuBarSkin(final MenuBar menuBar) {
        super(menuBar);
        this.focusedMenuIndex = -1;
        this.pendingDismiss = false;
        this.altKeyPressed = false;
        this.menuActionEventHandler = (actionEvent -> {
            if (actionEvent.getSource() instanceof CustomMenuItem) {
                if (!((CustomMenuItem)actionEvent.getSource()).isHideOnClick()) {
                    return;
                }
            }
            this.unSelectMenus();
            return;
        });
        final Iterator<MenuItem> iterator;
        final Iterator<MenuItem> iterator2;
        this.menuItemListener = (change -> {
            while (change.next()) {
                change.getAddedSubList().iterator();
                while (iterator.hasNext()) {
                    this.updateActionListeners(iterator.next(), true);
                }
                change.getRemoved().iterator();
                while (iterator2.hasNext()) {
                    this.updateActionListeners(iterator2.next(), false);
                }
            }
            return;
        });
        this.firstMenuRunnable = new Runnable() {
            @Override
            public void run() {
                if (MenuBarSkin.this.container.getChildren().size() > 0 && MenuBarSkin.this.container.getChildren().get(0) instanceof MenuButton) {
                    if (MenuBarSkin.this.focusedMenuIndex != 0) {
                        MenuBarSkin.this.unSelectMenus();
                        MenuBarSkin.this.menuModeStart(0);
                        MenuBarSkin.this.openMenuButton = MenuBarSkin.this.container.getChildren().get(0);
                        MenuBarSkin.this.openMenuButton.setHover();
                    }
                    else {
                        MenuBarSkin.this.unSelectMenus();
                    }
                }
            }
        };
        this.container = new HBox();
        this.container.getStyleClass().add("container");
        this.getChildren().add(this.container);
        boolean b3;
        boolean b4;
        this.keyEventHandler = (keyEvent2 -> {
            if (this.focusedMenu != null) {
                switch (keyEvent2.getCode()) {
                    case LEFT: {
                        b3 = (menuBar.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT);
                        if (menuBar.getScene().getWindow().isFocused()) {
                            if (this.openMenu != null && !this.openMenu.isShowing()) {
                                if (b3) {
                                    this.moveToMenu(Direction.NEXT, false);
                                }
                                else {
                                    this.moveToMenu(Direction.PREVIOUS, false);
                                }
                                keyEvent2.consume();
                                return;
                            }
                            else if (b3) {
                                this.moveToMenu(Direction.NEXT, true);
                            }
                            else {
                                this.moveToMenu(Direction.PREVIOUS, true);
                            }
                        }
                        keyEvent2.consume();
                        break;
                    }
                    case RIGHT: {
                        b4 = (menuBar.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT);
                        if (menuBar.getScene().getWindow().isFocused()) {
                            if (this.openMenu != null && !this.openMenu.isShowing()) {
                                if (b4) {
                                    this.moveToMenu(Direction.PREVIOUS, false);
                                }
                                else {
                                    this.moveToMenu(Direction.NEXT, false);
                                }
                                keyEvent2.consume();
                                return;
                            }
                            else if (b4) {
                                this.moveToMenu(Direction.PREVIOUS, true);
                            }
                            else {
                                this.moveToMenu(Direction.NEXT, true);
                            }
                        }
                        keyEvent2.consume();
                        break;
                    }
                    case DOWN: {
                        if (menuBar.getScene().getWindow().isFocused() && this.focusedMenuIndex != -1) {
                            this.showMenu(this.getSkinnable().getMenus().get(this.focusedMenuIndex), true);
                            keyEvent2.consume();
                            break;
                        }
                        else {
                            break;
                        }
                        break;
                    }
                    case ESCAPE: {
                        this.unSelectMenus();
                        keyEvent2.consume();
                        break;
                    }
                }
            }
            return;
        });
        this.menuBarFocusedPropertyListener = ((p0, p1, b) -> {
            if (b) {
                this.unSelectMenus();
                this.menuModeStart(0);
                this.openMenuButton = this.container.getChildren().get(0);
                this.setFocusedMenuIndex(0);
                this.openMenuButton.setHover();
            }
            else {
                this.unSelectMenus();
            }
            return;
        });
        this.weakSceneKeyEventHandler = new WeakEventHandler<KeyEvent>(this.keyEventHandler);
        Utils.executeOnceWhenPropertyIsNonNull(menuBar.sceneProperty(), scene -> scene.addEventFilter(KeyEvent.KEY_PRESSED, this.weakSceneKeyEventHandler));
        final Bounds bounds;
        this.mouseEventHandler = (mouseEvent -> {
            this.container.localToScreen(this.container.getLayoutBounds());
            if (bounds == null || !bounds.contains(mouseEvent.getScreenX(), mouseEvent.getScreenY())) {
                this.unSelectMenus();
            }
            return;
        });
        this.weakSceneMouseEventHandler = new WeakEventHandler<MouseEvent>(this.mouseEventHandler);
        Utils.executeOnceWhenPropertyIsNonNull(menuBar.sceneProperty(), scene2 -> scene2.addEventFilter(MouseEvent.MOUSE_CLICKED, this.weakSceneMouseEventHandler));
        this.weakWindowFocusListener = new WeakChangeListener<Boolean>((p0, p1, b2) -> {
            if (!b2) {
                this.unSelectMenus();
            }
            return;
        });
        Utils.executeOnceWhenPropertyIsNonNull(menuBar.sceneProperty(), scene3 -> {
            if (scene3.getWindow() != null) {
                scene3.getWindow().focusedProperty().addListener(this.weakWindowFocusListener);
            }
            else {
                this.weakWindowSceneListener = new WeakChangeListener<Window>((p0, window, window2) -> {
                    if (window != null) {
                        window.focusedProperty().removeListener(this.weakWindowFocusListener);
                    }
                    if (window2 != null) {
                        window2.focusedProperty().addListener(this.weakWindowFocusListener);
                    }
                    return;
                });
                scene3.windowProperty().addListener(this.weakWindowSceneListener);
            }
            return;
        });
        this.menuVisibilityChangeListener = ((p0, p1, p2) -> this.rebuildUI());
        this.rebuildUI();
        menuBar.getMenus().addListener(p0 -> this.rebuildUI());
        if (Toolkit.getToolkit().getSystemMenu().isSupported()) {
            menuBar.useSystemMenuBarProperty().addListener(p0 -> this.rebuildUI());
        }
        if (com.sun.javafx.util.Utils.isMac()) {
            KeyCombination.keyCombination("ctrl+F10");
        }
        else {
            KeyCombination.keyCombination("F10");
        }
        this.altKeyEventHandler = (keyEvent -> {
            if (keyEvent.getEventType() == KeyEvent.KEY_PRESSED) {
                this.altKeyPressed = false;
                if (keyEvent.getCode() == KeyCode.ALT && !keyEvent.isConsumed()) {
                    if (this.focusedMenuIndex == -1) {
                        this.altKeyPressed = true;
                    }
                    this.unSelectMenus();
                }
            }
            else if (keyEvent.getEventType() == KeyEvent.KEY_RELEASED) {
                if (this.altKeyPressed && keyEvent.getCode() == KeyCode.ALT && !keyEvent.isConsumed()) {
                    this.firstMenuRunnable.run();
                }
                this.altKeyPressed = false;
            }
            return;
        });
        this.weakSceneAltKeyEventHandler = new WeakEventHandler<KeyEvent>(this.altKeyEventHandler);
        final KeyCombination keyCombination;
        Utils.executeOnceWhenPropertyIsNonNull(menuBar.sceneProperty(), scene4 -> {
            scene4.getAccelerators().put(keyCombination, this.firstMenuRunnable);
            scene4.addEventHandler(KeyEvent.ANY, this.weakSceneAltKeyEventHandler);
            return;
        });
        final ParentTraversalEngine parentTraversalEngine = new ParentTraversalEngine(((SkinBase<Parent>)this).getSkinnable());
        parentTraversalEngine.addTraverseListener((p0, p1) -> {
            if (this.openMenu != null) {
                this.openMenu.hide();
            }
            this.setFocusedMenuIndex(0);
            return;
        });
        ParentHelper.setTraversalEngine(((SkinBase<Parent>)this).getSkinnable(), parentTraversalEngine);
        final KeyCombination keyCombination2;
        menuBar.sceneProperty().addListener((p1, scene5, scene6) -> {
            if (scene5 != null) {
                if (this.weakSceneKeyEventHandler != null) {
                    scene5.removeEventFilter(KeyEvent.KEY_PRESSED, this.weakSceneKeyEventHandler);
                }
                if (this.weakSceneMouseEventHandler != null) {
                    scene5.removeEventFilter(MouseEvent.MOUSE_CLICKED, this.weakSceneMouseEventHandler);
                }
                if (this.weakSceneAltKeyEventHandler != null) {
                    scene5.removeEventHandler(KeyEvent.ANY, this.weakSceneAltKeyEventHandler);
                }
            }
            if (scene5 != null) {
                scene5.getAccelerators().remove(keyCombination2);
            }
            if (scene6 != null) {
                scene6.getAccelerators().put(keyCombination2, this.firstMenuRunnable);
            }
        });
    }
    
    private void showMenu(final Menu menu) {
        this.showMenu(menu, false);
    }
    
    private void showMenu(final Menu openMenu, final boolean b) {
        if (this.openMenu == openMenu) {
            return;
        }
        if (this.openMenu != null) {
            this.openMenu.hide();
        }
        this.openMenu = openMenu;
        if (!openMenu.isShowing() && !this.isMenuEmpty(openMenu)) {
            if (b) {
                final Skin<?> skin = this.getNodeForMenu(this.focusedMenuIndex).getSkin();
                if (skin instanceof MenuButtonSkinBase) {
                    ((MenuButtonSkinBase)skin).requestFocusOnFirstMenuItem();
                }
            }
            this.openMenu.show();
        }
    }
    
    private void setFocusedMenuIndex(final int focusedMenuIndex) {
        this.focusedMenuIndex = focusedMenuIndex;
        this.focusedMenu = ((focusedMenuIndex == -1) ? null : this.getSkinnable().getMenus().get(focusedMenuIndex));
        if (this.focusedMenu != null && this.focusedMenuIndex != -1) {
            (this.openMenuButton = this.container.getChildren().get(this.focusedMenuIndex)).setHover();
        }
    }
    
    public static void setDefaultSystemMenuBar(final MenuBar menuBar) {
        if (Toolkit.getToolkit().getSystemMenu().isSupported()) {
            MenuBarSkin.wrappedDefaultMenus.clear();
            final Iterator<Menu> iterator = menuBar.getMenus().iterator();
            while (iterator.hasNext()) {
                MenuBarSkin.wrappedDefaultMenus.add(GlobalMenuAdapter.adapt(iterator.next()));
            }
            final Iterator<Menu> iterator2;
            menuBar.getMenus().addListener(p1 -> {
                MenuBarSkin.wrappedDefaultMenus.clear();
                menuBar.getMenus().iterator();
                while (iterator2.hasNext()) {
                    MenuBarSkin.wrappedDefaultMenus.add(GlobalMenuAdapter.adapt(iterator2.next()));
                }
            });
        }
    }
    
    private static MenuBarSkin getMenuBarSkin(final Stage key) {
        if (MenuBarSkin.systemMenuMap == null) {
            return null;
        }
        final Reference<MenuBarSkin> reference = MenuBarSkin.systemMenuMap.get(key);
        return (reference == null) ? null : reference.get();
    }
    
    private static void setSystemMenu(Stage currentMenuBarStage) {
        if (currentMenuBarStage != null && currentMenuBarStage.isFocused()) {
            while (currentMenuBarStage != null && currentMenuBarStage.getOwner() instanceof Stage) {
                final MenuBarSkin menuBarSkin = getMenuBarSkin(currentMenuBarStage);
                if (menuBarSkin != null && menuBarSkin.wrappedMenus != null) {
                    break;
                }
                currentMenuBarStage = (Stage)currentMenuBarStage.getOwner();
            }
        }
        else {
            currentMenuBarStage = null;
        }
        if (currentMenuBarStage != MenuBarSkin.currentMenuBarStage) {
            List<MenuBase> menus = null;
            if (currentMenuBarStage != null) {
                final MenuBarSkin menuBarSkin2 = getMenuBarSkin(currentMenuBarStage);
                if (menuBarSkin2 != null) {
                    menus = menuBarSkin2.wrappedMenus;
                }
            }
            if (menus == null) {
                menus = MenuBarSkin.wrappedDefaultMenus;
            }
            Toolkit.getToolkit().getSystemMenu().setMenus(menus);
            MenuBarSkin.currentMenuBarStage = currentMenuBarStage;
        }
    }
    
    private static void initSystemMenuBar() {
        MenuBarSkin.systemMenuMap = new WeakHashMap<Stage, Reference<MenuBarSkin>>();
        final InvalidationListener invalidationListener = readOnlyProperty -> setSystemMenu((Stage)readOnlyProperty.getBean());
        final Iterator<Window> iterator = (Iterator<Window>)MenuBarSkin.stages.iterator();
        while (iterator.hasNext()) {
            iterator.next().focusedProperty().addListener(invalidationListener);
        }
        final Iterator<Window> iterator2;
        final InvalidationListener invalidationListener2;
        final Iterator<Window> iterator3;
        Window window;
        MenuBarSkin.stages.addListener(change -> {
            while (change.next()) {
                change.getRemoved().iterator();
                while (iterator2.hasNext()) {
                    iterator2.next().focusedProperty().removeListener(invalidationListener2);
                }
                change.getAddedSubList().iterator();
                while (iterator3.hasNext()) {
                    window = iterator3.next();
                    window.focusedProperty().addListener(invalidationListener2);
                    setSystemMenu((Stage)window);
                }
            }
        });
    }
    
    public final void setSpacing(final double n) {
        this.spacingProperty().set(this.snapSpaceX(n));
    }
    
    public final double getSpacing() {
        return (this.spacing == null) ? 0.0 : this.snapSpaceX(this.spacing.get());
    }
    
    public final DoubleProperty spacingProperty() {
        if (this.spacing == null) {
            this.spacing = new StyleableDoubleProperty() {
                @Override
                protected void invalidated() {
                    MenuBarSkin.this.container.setSpacing(this.get());
                }
                
                @Override
                public Object getBean() {
                    return MenuBarSkin.this;
                }
                
                @Override
                public String getName() {
                    return "spacing";
                }
                
                @Override
                public CssMetaData<MenuBar, Number> getCssMetaData() {
                    return MenuBarSkin.SPACING;
                }
            };
        }
        return this.spacing;
    }
    
    public final void setContainerAlignment(final Pos pos) {
        this.containerAlignmentProperty().set(pos);
    }
    
    public final Pos getContainerAlignment() {
        return (this.containerAlignment == null) ? Pos.TOP_LEFT : this.containerAlignment.get();
    }
    
    public final ObjectProperty<Pos> containerAlignmentProperty() {
        if (this.containerAlignment == null) {
            this.containerAlignment = new StyleableObjectProperty<Pos>(Pos.TOP_LEFT) {
                public void invalidated() {
                    MenuBarSkin.this.container.setAlignment(this.get());
                }
                
                @Override
                public Object getBean() {
                    return MenuBarSkin.this;
                }
                
                @Override
                public String getName() {
                    return "containerAlignment";
                }
                
                @Override
                public CssMetaData<MenuBar, Pos> getCssMetaData() {
                    return MenuBarSkin.ALIGNMENT;
                }
            };
        }
        return this.containerAlignment;
    }
    
    @Override
    public void dispose() {
        this.cleanUpSystemMenu();
        super.dispose();
    }
    
    @Override
    protected double snappedTopInset() {
        return this.container.getChildren().isEmpty() ? 0.0 : super.snappedTopInset();
    }
    
    @Override
    protected double snappedBottomInset() {
        return this.container.getChildren().isEmpty() ? 0.0 : super.snappedBottomInset();
    }
    
    @Override
    protected double snappedLeftInset() {
        return this.container.getChildren().isEmpty() ? 0.0 : super.snappedLeftInset();
    }
    
    @Override
    protected double snappedRightInset() {
        return this.container.getChildren().isEmpty() ? 0.0 : super.snappedRightInset();
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        this.container.resizeRelocate(n, n2, n3, n4);
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.container.minWidth(n) + this.snappedLeftInset() + this.snappedRightInset();
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.container.prefWidth(n) + this.snappedLeftInset() + this.snappedRightInset();
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.container.minHeight(n) + this.snappedTopInset() + this.snappedBottomInset();
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.container.prefHeight(n) + this.snappedTopInset() + this.snappedBottomInset();
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefHeight(-1.0);
    }
    
    MenuButton getNodeForMenu(final int n) {
        if (n < this.container.getChildren().size()) {
            return this.container.getChildren().get(n);
        }
        return null;
    }
    
    int getFocusedMenuIndex() {
        return this.focusedMenuIndex;
    }
    
    private boolean menusContainCustomMenuItem() {
        final Iterator<Menu> iterator = this.getSkinnable().getMenus().iterator();
        while (iterator.hasNext()) {
            if (this.menuContainsCustomMenuItem(iterator.next())) {
                System.err.println("Warning: MenuBar ignored property useSystemMenuBar because menus contain CustomMenuItem");
                return true;
            }
        }
        return false;
    }
    
    private boolean menuContainsCustomMenuItem(final Menu menu) {
        for (final MenuItem menuItem : menu.getItems()) {
            if (menuItem instanceof CustomMenuItem && !(menuItem instanceof SeparatorMenuItem)) {
                return true;
            }
            if (menuItem instanceof Menu && this.menuContainsCustomMenuItem((Menu)menuItem)) {
                return true;
            }
        }
        return false;
    }
    
    private int getMenuBarButtonIndex(final MenuBarButton menuBarButton) {
        for (int i = 0; i < this.container.getChildren().size(); ++i) {
            if (menuBarButton == this.container.getChildren().get(i)) {
                return i;
            }
        }
        return -1;
    }
    
    private void updateActionListeners(final MenuItem menuItem, final boolean b) {
        if (menuItem instanceof Menu) {
            final Menu menu = (Menu)menuItem;
            if (b) {
                menu.getItems().addListener(this.menuItemListener);
            }
            else {
                menu.getItems().removeListener(this.menuItemListener);
            }
            final Iterator<Object> iterator = menu.getItems().iterator();
            while (iterator.hasNext()) {
                this.updateActionListeners(iterator.next(), b);
            }
        }
        else if (b) {
            menuItem.addEventHandler(ActionEvent.ACTION, this.menuActionEventHandler);
        }
        else {
            menuItem.removeEventHandler(ActionEvent.ACTION, this.menuActionEventHandler);
        }
    }
    
    private void rebuildUI() {
        this.getSkinnable().focusedProperty().removeListener(this.menuBarFocusedPropertyListener);
        for (final Menu menu : this.getSkinnable().getMenus()) {
            this.updateActionListeners(menu, false);
            menu.visibleProperty().removeListener(this.menuVisibilityChangeListener);
        }
        for (final MenuBarButton menuBarButton : this.container.getChildren()) {
            menuBarButton.hide();
            menuBarButton.menu.showingProperty().removeListener(menuBarButton.menuListener);
            menuBarButton.disableProperty().unbind();
            menuBarButton.textProperty().unbind();
            menuBarButton.graphicProperty().unbind();
            menuBarButton.styleProperty().unbind();
            menuBarButton.dispose();
            menuBarButton.setSkin(null);
        }
        this.container.getChildren().clear();
        Label_0320: {
            if (Toolkit.getToolkit().getSystemMenu().isSupported()) {
                final Scene scene3 = this.getSkinnable().getScene();
                if (scene3 != null) {
                    if (this.sceneChangeListener == null) {
                        Stage stage;
                        final MenuBarSkin menuBarSkin;
                        Stage stage2;
                        final Iterator<Menu> iterator3;
                        this.sceneChangeListener = ((p0, scene, scene2) -> {
                            if (scene != null && scene.getWindow() instanceof Stage) {
                                stage = (Stage)scene.getWindow();
                                getMenuBarSkin(stage);
                                if (menuBarSkin == this) {
                                    menuBarSkin.wrappedMenus = null;
                                    MenuBarSkin.systemMenuMap.remove(stage);
                                    if (MenuBarSkin.currentMenuBarStage == stage) {
                                        MenuBarSkin.currentMenuBarStage = null;
                                        setSystemMenu(stage);
                                    }
                                }
                                else if (menuBarSkin != null && menuBarSkin.getSkinnable() != null && menuBarSkin.getSkinnable().isUseSystemMenuBar()) {
                                    menuBarSkin.getSkinnable().setUseSystemMenuBar(false);
                                }
                            }
                            if (scene2 != null && this.getSkinnable().isUseSystemMenuBar() && !this.menusContainCustomMenuItem() && scene2.getWindow() instanceof Stage) {
                                stage2 = (Stage)scene2.getWindow();
                                if (MenuBarSkin.systemMenuMap == null) {
                                    initSystemMenuBar();
                                }
                                this.wrappedMenus = new ArrayList<MenuBase>();
                                MenuBarSkin.systemMenuMap.put(stage2, new WeakReference<MenuBarSkin>(this));
                                this.getSkinnable().getMenus().iterator();
                                while (iterator3.hasNext()) {
                                    this.wrappedMenus.add(GlobalMenuAdapter.adapt(iterator3.next()));
                                }
                                MenuBarSkin.currentMenuBarStage = null;
                                setSystemMenu(stage2);
                                this.getSkinnable().requestLayout();
                                Platform.runLater(() -> this.getSkinnable().requestLayout());
                            }
                            return;
                        });
                        this.getSkinnable().sceneProperty().addListener(this.sceneChangeListener);
                    }
                    this.sceneChangeListener.changed(this.getSkinnable().sceneProperty(), scene3, scene3);
                    if (MenuBarSkin.currentMenuBarStage != null) {
                        if (getMenuBarSkin(MenuBarSkin.currentMenuBarStage) != this) {
                            break Label_0320;
                        }
                    }
                    else if (!this.getSkinnable().isUseSystemMenuBar()) {
                        break Label_0320;
                    }
                    return;
                }
                if (MenuBarSkin.currentMenuBarStage != null && getMenuBarSkin(MenuBarSkin.currentMenuBarStage) == this) {
                    setSystemMenu(null);
                }
            }
        }
        this.getSkinnable().focusedProperty().addListener(this.menuBarFocusedPropertyListener);
        for (final Menu menu2 : this.getSkinnable().getMenus()) {
            menu2.visibleProperty().addListener(this.menuVisibilityChangeListener);
            if (!menu2.isVisible()) {
                continue;
            }
            final MenuBarButton menuBarButton2 = new MenuBarButton(this, menu2);
            menuBarButton2.setFocusTraversable(false);
            menuBarButton2.getStyleClass().add("menu");
            menuBarButton2.setStyle(menu2.getStyle());
            menuBarButton2.getItems().setAll(menu2.getItems());
            this.container.getChildren().add(menuBarButton2);
            final Menu menu3;
            final Object o;
            menuBarButton2.menuListener = ((p2, p3, p4) -> {
                if (menu3.isShowing()) {
                    ((MenuButton)o).show();
                    this.menuModeStart(this.container.getChildren().indexOf(o));
                }
                else {
                    ((MenuButton)o).hide();
                }
                return;
            });
            menuBarButton2.menu = menu2;
            menu2.showingProperty().addListener(menuBarButton2.menuListener);
            menuBarButton2.disableProperty().bindBidirectional(menu2.disableProperty());
            menuBarButton2.textProperty().bind(menu2.textProperty());
            menuBarButton2.graphicProperty().bind((ObservableValue<?>)menu2.graphicProperty());
            menuBarButton2.styleProperty().bind(menu2.styleProperty());
            final Node node;
            final Menu menu4;
            menuBarButton2.getProperties().addListener(change -> {
                if (change.wasAdded() && "autoHide".equals(change.getKey())) {
                    node.getProperties().remove("autoHide");
                    menu4.hide();
                }
                return;
            });
            final MenuBarButton openMenuButton;
            final Menu menu5;
            menuBarButton2.showingProperty().addListener((p2, p3, b) -> {
                if (b) {
                    if (this.openMenuButton == null && this.focusedMenuIndex != -1) {
                        this.openMenuButton = this.container.getChildren().get(this.focusedMenuIndex);
                    }
                    if (this.openMenuButton != null && this.openMenuButton != openMenuButton) {
                        this.openMenuButton.clearHover();
                    }
                    this.openMenuButton = openMenuButton;
                    this.showMenu(menu5);
                }
                else {
                    this.openMenu = null;
                    this.openMenuButton = null;
                }
                return;
            });
            final MenuBarButton menuBarButton3;
            final Menu menu6;
            menuBarButton2.setOnMousePressed(p2 -> {
                this.pendingDismiss = menuBarButton3.isShowing();
                if (menuBarButton3.getScene().getWindow().isFocused()) {
                    this.showMenu(menu6);
                    this.menuModeStart(this.getMenuBarButtonIndex(menuBarButton3));
                }
                return;
            });
            menuBarButton2.setOnMouseReleased(p1 -> {
                if (menuBarButton2.getScene().getWindow().isFocused() && this.pendingDismiss) {
                    this.resetOpenMenu();
                }
                this.pendingDismiss = (0 != 0);
                return;
            });
            final MenuBarButton openMenuButton2;
            final Menu menu7;
            menuBarButton2.setOnMouseEntered(p2 -> {
                if (openMenuButton2.getScene() != null && openMenuButton2.getScene().getWindow() != null && openMenuButton2.getScene().getWindow().isFocused()) {
                    if (this.openMenuButton != null && this.openMenuButton != openMenuButton2) {
                        this.openMenuButton.clearHover();
                        this.openMenuButton = null;
                        this.openMenuButton = openMenuButton2;
                    }
                    this.updateFocusedIndex();
                    if (this.openMenu != null && this.openMenu != menu7) {
                        this.showMenu(menu7);
                    }
                }
                return;
            });
            this.updateActionListeners(menu2, true);
        }
        this.getSkinnable().requestLayout();
    }
    
    private void cleanUpSystemMenu() {
        if (this.sceneChangeListener != null && this.getSkinnable() != null) {
            this.getSkinnable().sceneProperty().removeListener(this.sceneChangeListener);
            this.sceneChangeListener = null;
        }
        if (MenuBarSkin.currentMenuBarStage != null && getMenuBarSkin(MenuBarSkin.currentMenuBarStage) == this) {
            setSystemMenu(null);
        }
        if (MenuBarSkin.systemMenuMap != null) {
            final Iterator<Map.Entry<Stage, Reference<MenuBarSkin>>> iterator = MenuBarSkin.systemMenuMap.entrySet().iterator();
            while (iterator.hasNext()) {
                final Reference<MenuBarSkin> reference = iterator.next().getValue();
                final MenuBarSkin menuBarSkin = (reference != null) ? reference.get() : null;
                if (menuBarSkin == null || menuBarSkin == this) {
                    iterator.remove();
                }
            }
        }
    }
    
    private boolean isMenuEmpty(final Menu menu) {
        boolean b = true;
        if (menu != null) {
            for (final MenuItem menuItem : menu.getItems()) {
                if (menuItem != null && menuItem.isVisible()) {
                    b = false;
                }
            }
        }
        return b;
    }
    
    private void resetOpenMenu() {
        if (this.openMenu != null) {
            this.openMenu.hide();
            this.openMenu = null;
        }
    }
    
    private void unSelectMenus() {
        this.clearMenuButtonHover();
        if (this.focusedMenuIndex == -1) {
            return;
        }
        if (this.openMenu != null) {
            this.openMenu.hide();
            this.openMenu = null;
        }
        if (this.openMenuButton != null) {
            this.openMenuButton.clearHover();
            this.openMenuButton = null;
        }
        this.menuModeEnd();
    }
    
    private void menuModeStart(final int focusedMenuIndex) {
        if (this.focusedMenuIndex == -1) {
            SceneHelper.getSceneAccessor().setTransientFocusContainer(this.getSkinnable().getScene(), ((SkinBase<Node>)this).getSkinnable());
        }
        this.setFocusedMenuIndex(focusedMenuIndex);
    }
    
    private void menuModeEnd() {
        if (this.focusedMenuIndex != -1) {
            SceneHelper.getSceneAccessor().setTransientFocusContainer(this.getSkinnable().getScene(), null);
            this.getSkinnable().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_NODE);
        }
        this.setFocusedMenuIndex(-1);
    }
    
    private void moveToMenu(final Direction direction, final boolean b) {
        final boolean b2;
        this.findSibling(direction, this.focusedMenuIndex).ifPresent(pair -> {
            b2 = (b && this.focusedMenu.isShowing());
            this.setFocusedMenuIndex(pair.getValue());
            if (b2) {
                this.showMenu((Menu)pair.getKey(), false);
            }
        });
    }
    
    private Optional<Pair<Menu, Integer>> findSibling(final Direction direction, int n) {
        if (n == -1) {
            return Optional.empty();
        }
        final int size = this.getSkinnable().getMenus().size();
        int i = 0;
        int j = 0;
        while (i < size) {
            ++i;
            j = (n + (direction.isForward() ? 1 : -1)) % size;
            if (j == -1) {
                j = size - 1;
            }
            if (!((Menu)this.getSkinnable().getMenus().get(j)).isDisable()) {
                break;
            }
            n = j;
        }
        this.clearMenuButtonHover();
        return Optional.of(new Pair<Menu, Integer>(this.getSkinnable().getMenus().get(j), j));
    }
    
    private void updateFocusedIndex() {
        int focusedMenuIndex = 0;
        final Iterator<Node> iterator = (Iterator<Node>)this.container.getChildren().iterator();
        while (iterator.hasNext()) {
            if (iterator.next().isHover()) {
                this.setFocusedMenuIndex(focusedMenuIndex);
                return;
            }
            ++focusedMenuIndex;
        }
        this.menuModeEnd();
    }
    
    private void clearMenuButtonHover() {
        for (final Node node : this.container.getChildren()) {
            if (node.isHover()) {
                ((MenuBarButton)node).clearHover();
                ((MenuBarButton)node).disarm();
            }
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return MenuBarSkin.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case FOCUS_NODE: {
                return this.openMenuButton;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        stages = AccessController.doPrivileged(() -> Window.getWindows(), null, FXPermissions.ACCESS_WINDOW_LIST_PERMISSION).filtered(window -> window instanceof Stage);
        MenuBarSkin.wrappedDefaultMenus = new ArrayList<MenuBase>();
        SPACING = new CssMetaData<MenuBar, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
            @Override
            public boolean isSettable(final MenuBar menuBar) {
                final MenuBarSkin menuBarSkin = (MenuBarSkin)menuBar.getSkin();
                return menuBarSkin.spacing == null || !menuBarSkin.spacing.isBound();
            }
            
            @Override
            public StyleableProperty<Number> getStyleableProperty(final MenuBar menuBar) {
                return (StyleableProperty<Number>)((MenuBarSkin)menuBar.getSkin()).spacingProperty();
            }
        };
        ALIGNMENT = new CssMetaData<MenuBar, Pos>((StyleConverter)new EnumConverter(Pos.class), Pos.TOP_LEFT) {
            @Override
            public boolean isSettable(final MenuBar menuBar) {
                final MenuBarSkin menuBarSkin = (MenuBarSkin)menuBar.getSkin();
                return menuBarSkin.containerAlignment == null || !menuBarSkin.containerAlignment.isBound();
            }
            
            @Override
            public StyleableProperty<Pos> getStyleableProperty(final MenuBar menuBar) {
                return (StyleableProperty<Pos>)(StyleableProperty)((MenuBarSkin)menuBar.getSkin()).containerAlignmentProperty();
            }
        };
        final ArrayList<Object> list = new ArrayList<Object>(SkinBase.getClassCssMetaData());
        final String property = MenuBarSkin.ALIGNMENT.getProperty();
        for (int i = 0; i < list.size(); ++i) {
            final CssMetaData cssMetaData = list.get(i);
            if (property.equals(cssMetaData.getProperty())) {
                list.remove(cssMetaData);
            }
        }
        list.add(MenuBarSkin.SPACING);
        list.add(MenuBarSkin.ALIGNMENT);
        STYLEABLES = Collections.unmodifiableList((List<? extends CssMetaData<? extends Styleable, ?>>)list);
    }
}
