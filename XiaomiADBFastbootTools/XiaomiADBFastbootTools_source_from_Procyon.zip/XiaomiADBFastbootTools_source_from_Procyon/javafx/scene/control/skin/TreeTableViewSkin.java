// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.layout.StackPane;
import javafx.scene.control.TableColumnBase;
import javafx.scene.control.TreeTableCell;
import javafx.scene.Node;
import javafx.scene.AccessibleAction;
import java.util.Iterator;
import java.util.Collection;
import javafx.collections.FXCollections;
import javafx.scene.control.TreeTablePosition;
import java.util.ArrayList;
import javafx.scene.AccessibleAttribute;
import javafx.event.EventType;
import javafx.beans.value.ObservableValue;
import javafx.scene.input.MouseEvent;
import javafx.event.WeakEventHandler;
import javafx.event.EventHandler;
import com.sun.javafx.scene.control.behavior.TreeTableViewBehavior;
import java.lang.ref.WeakReference;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import com.sun.javafx.scene.control.TreeTableViewBackingList;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableRow;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.TreeItem;

public class TreeTableViewSkin<T> extends TableViewSkinBase<T, TreeItem<T>, TreeTableView<T>, TreeTableRow<T>, TreeTableColumn<T, ?>>
{
    TreeTableViewBackingList<T> tableBackingList;
    ObjectProperty<ObservableList<TreeItem<T>>> tableBackingListProperty;
    private WeakReference<TreeItem<T>> weakRootRef;
    private final TreeTableViewBehavior<T> behavior;
    private EventHandler<TreeItem.TreeModificationEvent<T>> rootListener;
    private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakRootListener;
    
    public TreeTableViewSkin(final TreeTableView<T> treeTableView) {
        super(treeTableView);
        EventType superType = null;
        this.rootListener = (treeModificationEvent -> {
            if (treeModificationEvent.wasAdded() && treeModificationEvent.wasRemoved() && treeModificationEvent.getAddedSize() == treeModificationEvent.getRemovedSize()) {
                this.markItemCountDirty();
                this.getSkinnable().requestLayout();
            }
            else if (treeModificationEvent.getEventType().equals(TreeItem.valueChangedEvent())) {
                this.requestRebuildCells();
            }
            else {
                treeModificationEvent.getEventType();
                while (superType != null) {
                    if (superType.equals(TreeItem.expandedItemCountChangeEvent())) {
                        this.markItemCountDirty();
                        this.getSkinnable().requestLayout();
                        break;
                    }
                    else {
                        superType = superType.getSuperType();
                    }
                }
            }
            this.getSkinnable().edit(-1, null);
            return;
        });
        this.behavior = new TreeTableViewBehavior<T>(treeTableView);
        this.flow.setFixedCellSize(treeTableView.getFixedCellSize());
        this.flow.setCellFactory(p0 -> this.createCell());
        this.setRoot(this.getSkinnable().getRoot());
        final EventHandler<? super MouseEvent> eventHandler = p1 -> {
            if (treeTableView.getEditingCell() != null) {
                treeTableView.edit(-1, null);
            }
            if (treeTableView.isFocusTraversable()) {
                treeTableView.requestFocus();
            }
            return;
        };
        this.flow.getVbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        this.flow.getHbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        this.behavior.setOnFocusPreviousRow(() -> this.onFocusPreviousCell());
        this.behavior.setOnFocusNextRow(() -> this.onFocusNextCell());
        this.behavior.setOnMoveToFirstCell(() -> this.onMoveToFirstCell());
        this.behavior.setOnMoveToLastCell(() -> this.onMoveToLastCell());
        this.behavior.setOnScrollPageDown(b -> this.onScrollPageDown(b));
        this.behavior.setOnScrollPageUp(b2 -> this.onScrollPageUp(b2));
        this.behavior.setOnSelectPreviousRow(() -> this.onSelectPreviousCell());
        this.behavior.setOnSelectNextRow(() -> this.onSelectNextCell());
        this.behavior.setOnSelectLeftCell(() -> this.onSelectLeftCell());
        this.behavior.setOnSelectRightCell(() -> this.onSelectRightCell());
        this.registerChangeListener(treeTableView.rootProperty(), p0 -> {
            this.getSkinnable().edit(-1, null);
            this.setRoot(this.getSkinnable().getRoot());
            return;
        });
        this.registerChangeListener(treeTableView.showRootProperty(), p0 -> {
            if (!this.getSkinnable().isShowRoot() && this.getRoot() != null) {
                this.getRoot().setExpanded(true);
            }
            this.updateItemCount();
            return;
        });
        this.registerChangeListener(treeTableView.rowFactoryProperty(), p0 -> this.flow.recreateCells());
        this.registerChangeListener(treeTableView.expandedItemCountProperty(), p0 -> this.markItemCountDirty());
        this.registerChangeListener(treeTableView.fixedCellSizeProperty(), p0 -> this.flow.setFixedCellSize(this.getSkinnable().getFixedCellSize()));
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case ROW_AT_INDEX: {
                final int intValue = (int)array[0];
                return (intValue < 0) ? null : this.flow.getPrivateCell(intValue);
            }
            case SELECTED_ITEMS: {
                final ArrayList<TreeTableRow> list = new ArrayList<TreeTableRow>();
                final Iterator iterator = this.getSkinnable().getSelectionModel().getSelectedCells().iterator();
                while (iterator.hasNext()) {
                    final TreeTableRow treeTableRow = (TreeTableRow)this.flow.getPrivateCell(iterator.next().getRow());
                    if (treeTableRow != null) {
                        list.add(treeTableRow);
                    }
                }
                return FXCollections.observableArrayList((Collection<?>)list);
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    protected void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case SHOW_ITEM: {
                final Node node = (Node)array[0];
                if (node instanceof TreeTableCell) {
                    this.flow.scrollTo(((TreeTableCell)node).getIndex());
                    break;
                }
                break;
            }
            case SET_SELECTED_ITEMS: {
                final ObservableList list = (ObservableList)array[0];
                if (list != null) {
                    final TreeTableView.TreeTableViewSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
                    if (selectionModel != null) {
                        selectionModel.clearSelection();
                        for (final Node node2 : list) {
                            if (node2 instanceof TreeTableCell) {
                                final TreeTableCell treeTableCell = (TreeTableCell)node2;
                                selectionModel.select(treeTableCell.getIndex(), treeTableCell.getTableColumn());
                            }
                        }
                    }
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    private TreeTableRow<T> createCell() {
        final TreeTableView<T> treeTableView = this.getSkinnable();
        TreeTableRow<T> treeTableRow;
        if (treeTableView.getRowFactory() != null) {
            treeTableRow = treeTableView.getRowFactory().call(treeTableView);
        }
        else {
            treeTableRow = new TreeTableRow<T>();
        }
        if (treeTableRow.getDisclosureNode() == null) {
            final StackPane disclosureNode = new StackPane();
            disclosureNode.getStyleClass().setAll("tree-disclosure-node");
            disclosureNode.setMouseTransparent(true);
            final StackPane stackPane = new StackPane();
            stackPane.getStyleClass().setAll("arrow");
            disclosureNode.getChildren().add(stackPane);
            treeTableRow.setDisclosureNode(disclosureNode);
        }
        treeTableRow.updateTreeTableView(treeTableView);
        return treeTableRow;
    }
    
    private TreeItem<T> getRoot() {
        return (this.weakRootRef == null) ? null : this.weakRootRef.get();
    }
    
    private void setRoot(final TreeItem<T> referent) {
        if (this.getRoot() != null && this.weakRootListener != null) {
            this.getRoot().removeEventHandler(TreeItem.treeNotificationEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakRootListener);
        }
        this.weakRootRef = new WeakReference<TreeItem<T>>(referent);
        if (this.getRoot() != null) {
            this.weakRootListener = new WeakEventHandler<TreeItem.TreeModificationEvent<T>>(this.rootListener);
            this.getRoot().addEventHandler(TreeItem.treeNotificationEvent(), (EventHandler<TreeItem.TreeModificationEvent<Object>>)this.weakRootListener);
        }
        this.updateItemCount();
    }
    
    @Override
    protected int getItemCount() {
        return this.getSkinnable().getExpandedItemCount();
    }
    
    @Override
    void horizontalScroll() {
        super.horizontalScroll();
        if (this.getSkinnable().getFixedCellSize() > 0.0) {
            this.flow.requestCellLayout();
        }
    }
    
    @Override
    protected void updateItemCount() {
        this.updatePlaceholderRegionVisibility();
        this.tableBackingList.resetSize();
        final int cellCount = this.flow.getCellCount();
        final int itemCount = this.getItemCount();
        this.flow.setCellCount(itemCount);
        if (itemCount == cellCount) {
            this.needCellsReconfigured = true;
        }
    }
}
