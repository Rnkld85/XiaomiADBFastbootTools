// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.transform.Scale;
import javafx.scene.transform.Transform;
import java.util.Iterator;
import javafx.scene.layout.Pane;
import javafx.event.ActionEvent;
import javafx.collections.ObservableList;
import javafx.animation.KeyFrame;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.collections.FXCollections;
import javafx.animation.Timeline;
import javafx.geometry.NodeOrientation;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Shape;
import javafx.scene.text.TextBoundsType;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.geometry.VPos;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Arc;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.layout.Region;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.BooleanConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.PaintConverter;
import java.util.function.Consumer;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import javafx.beans.value.ObservableValue;
import javafx.css.StyleableBooleanProperty;
import javafx.css.StyleableIntegerProperty;
import javafx.scene.paint.Color;
import javafx.css.StyleableObjectProperty;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.css.Styleable;
import java.util.List;
import javafx.css.CssMetaData;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.scene.paint.Paint;
import javafx.beans.property.ObjectProperty;
import javafx.animation.Animation;
import javafx.util.Duration;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.SkinBase;

public class ProgressIndicatorSkin extends SkinBase<ProgressIndicator>
{
    private final String DONE;
    final Duration CLIPPED_DELAY;
    final Duration UNCLIPPED_DELAY;
    private IndeterminateSpinner spinner;
    private DeterminateIndicator determinateIndicator;
    private ProgressIndicator control;
    Animation indeterminateTransition;
    private ObjectProperty<Paint> progressColor;
    private IntegerProperty indeterminateSegmentCount;
    private final BooleanProperty spinEnabled;
    private static final CssMetaData<ProgressIndicator, Paint> PROGRESS_COLOR;
    private static final CssMetaData<ProgressIndicator, Number> INDETERMINATE_SEGMENT_COUNT;
    private static final CssMetaData<ProgressIndicator, Boolean> SPIN_ENABLED;
    private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
    
    public ProgressIndicatorSkin(final ProgressIndicator control) {
        super(control);
        this.DONE = ControlResources.getString("ProgressIndicator.doneString");
        this.CLIPPED_DELAY = new Duration(300.0);
        this.UNCLIPPED_DELAY = new Duration(0.0);
        this.progressColor = new StyleableObjectProperty<Paint>((Paint)null) {
            @Override
            protected void invalidated() {
                final Paint fillOverride = this.get();
                if (fillOverride != null && !(fillOverride instanceof Color)) {
                    if (this.isBound()) {
                        this.unbind();
                    }
                    this.set(null);
                    throw new IllegalArgumentException("Only Color objects are supported");
                }
                if (ProgressIndicatorSkin.this.spinner != null) {
                    ProgressIndicatorSkin.this.spinner.setFillOverride(fillOverride);
                }
                if (ProgressIndicatorSkin.this.determinateIndicator != null) {
                    ProgressIndicatorSkin.this.determinateIndicator.setFillOverride(fillOverride);
                }
            }
            
            @Override
            public Object getBean() {
                return ProgressIndicatorSkin.this;
            }
            
            @Override
            public String getName() {
                return "progressColorProperty";
            }
            
            @Override
            public CssMetaData<ProgressIndicator, Paint> getCssMetaData() {
                return ProgressIndicatorSkin.PROGRESS_COLOR;
            }
        };
        this.indeterminateSegmentCount = new StyleableIntegerProperty(8) {
            @Override
            protected void invalidated() {
                if (ProgressIndicatorSkin.this.spinner != null) {
                    ProgressIndicatorSkin.this.spinner.rebuild();
                }
            }
            
            @Override
            public Object getBean() {
                return ProgressIndicatorSkin.this;
            }
            
            @Override
            public String getName() {
                return "indeterminateSegmentCount";
            }
            
            @Override
            public CssMetaData<ProgressIndicator, Number> getCssMetaData() {
                return ProgressIndicatorSkin.INDETERMINATE_SEGMENT_COUNT;
            }
        };
        this.spinEnabled = new StyleableBooleanProperty(false) {
            @Override
            protected void invalidated() {
                if (ProgressIndicatorSkin.this.spinner != null) {
                    ProgressIndicatorSkin.this.spinner.setSpinEnabled(this.get());
                }
            }
            
            @Override
            public CssMetaData<ProgressIndicator, Boolean> getCssMetaData() {
                return ProgressIndicatorSkin.SPIN_ENABLED;
            }
            
            @Override
            public Object getBean() {
                return ProgressIndicatorSkin.this;
            }
            
            @Override
            public String getName() {
                return "spinEnabled";
            }
        };
        this.control = control;
        this.registerChangeListener(control.indeterminateProperty(), p0 -> this.initialize());
        this.registerChangeListener(control.progressProperty(), p0 -> this.updateProgress());
        this.registerChangeListener(NodeHelper.treeShowingProperty(control), p0 -> this.updateAnimation());
        this.registerChangeListener(control.sceneProperty(), p0 -> this.updateAnimation());
        this.initialize();
        this.updateAnimation();
    }
    
    Paint getProgressColor() {
        return this.progressColor.get();
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.indeterminateTransition != null) {
            this.indeterminateTransition.stop();
            this.indeterminateTransition = null;
        }
        if (this.spinner != null) {
            this.spinner = null;
        }
        this.control = null;
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        if (this.spinner != null && this.control.isIndeterminate()) {
            this.spinner.layoutChildren();
            this.spinner.resizeRelocate(0.0, 0.0, n3, n4);
        }
        else if (this.determinateIndicator != null) {
            this.determinateIndicator.layoutChildren();
            this.determinateIndicator.resizeRelocate(0.0, 0.0, n3, n4);
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        if (this.spinner != null && this.control.isIndeterminate()) {
            n6 = this.spinner.minWidth(-1.0);
        }
        else if (this.determinateIndicator != null) {
            n6 = this.determinateIndicator.minWidth(-1.0);
        }
        return n6;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        if (this.spinner != null && this.control.isIndeterminate()) {
            n6 = this.spinner.minHeight(-1.0);
        }
        else if (this.determinateIndicator != null) {
            n6 = this.determinateIndicator.minHeight(-1.0);
        }
        return n6;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        if (this.spinner != null && this.control.isIndeterminate()) {
            n6 = this.spinner.prefWidth(n);
        }
        else if (this.determinateIndicator != null) {
            n6 = this.determinateIndicator.prefWidth(n);
        }
        return n6;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        if (this.spinner != null && this.control.isIndeterminate()) {
            n6 = this.spinner.prefHeight(n);
        }
        else if (this.determinateIndicator != null) {
            n6 = this.determinateIndicator.prefHeight(n);
        }
        return n6;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computePrefWidth(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computePrefHeight(n, n2, n3, n4, n5);
    }
    
    void initialize() {
        if (this.control.isIndeterminate()) {
            this.determinateIndicator = null;
            this.spinner = new IndeterminateSpinner(this.spinEnabled.get(), (Paint)this.progressColor.get());
            this.getChildren().setAll(this.spinner);
            if (NodeHelper.isTreeShowing(this.control) && this.indeterminateTransition != null) {
                this.indeterminateTransition.play();
            }
        }
        else {
            if (this.spinner != null) {
                if (this.indeterminateTransition != null) {
                    this.indeterminateTransition.stop();
                }
                this.spinner = null;
            }
            this.determinateIndicator = new DeterminateIndicator(this.control, this, this.progressColor.get());
            this.getChildren().setAll(this.determinateIndicator);
        }
    }
    
    void updateProgress() {
        if (this.determinateIndicator != null) {
            this.determinateIndicator.updateProgress(this.control.getProgress());
        }
    }
    
    void createIndeterminateTimeline() {
        if (this.spinner != null) {
            this.spinner.rebuildTimeline();
        }
    }
    
    void pauseTimeline(final boolean b) {
        if (this.getSkinnable().isIndeterminate()) {
            if (this.indeterminateTransition == null) {
                this.createIndeterminateTimeline();
            }
            if (b) {
                this.indeterminateTransition.pause();
            }
            else {
                this.indeterminateTransition.play();
            }
        }
    }
    
    void updateAnimation() {
        final ProgressIndicator progressIndicator = this.getSkinnable();
        final boolean b = NodeHelper.isTreeShowing(progressIndicator) && progressIndicator.getScene() != null;
        if (this.indeterminateTransition != null) {
            this.pauseTimeline(!b);
        }
        else if (b) {
            this.createIndeterminateTimeline();
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return ProgressIndicatorSkin.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    static {
        PROGRESS_COLOR = new CssMetaData<ProgressIndicator, Paint>((StyleConverter)PaintConverter.getInstance(), (Paint)null) {
            @Override
            public boolean isSettable(final ProgressIndicator progressIndicator) {
                final ProgressIndicatorSkin progressIndicatorSkin = (ProgressIndicatorSkin)progressIndicator.getSkin();
                return progressIndicatorSkin.progressColor == null || !progressIndicatorSkin.progressColor.isBound();
            }
            
            @Override
            public StyleableProperty<Paint> getStyleableProperty(final ProgressIndicator progressIndicator) {
                return (StyleableProperty<Paint>)(StyleableProperty)((ProgressIndicatorSkin)progressIndicator.getSkin()).progressColor;
            }
        };
        INDETERMINATE_SEGMENT_COUNT = new CssMetaData<ProgressIndicator, Number>((StyleConverter)SizeConverter.getInstance(), (Number)8) {
            @Override
            public boolean isSettable(final ProgressIndicator progressIndicator) {
                final ProgressIndicatorSkin progressIndicatorSkin = (ProgressIndicatorSkin)progressIndicator.getSkin();
                return progressIndicatorSkin.indeterminateSegmentCount == null || !progressIndicatorSkin.indeterminateSegmentCount.isBound();
            }
            
            @Override
            public StyleableProperty<Number> getStyleableProperty(final ProgressIndicator progressIndicator) {
                return (StyleableProperty<Number>)((ProgressIndicatorSkin)progressIndicator.getSkin()).indeterminateSegmentCount;
            }
        };
        SPIN_ENABLED = new CssMetaData<ProgressIndicator, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
            @Override
            public boolean isSettable(final ProgressIndicator progressIndicator) {
                final ProgressIndicatorSkin progressIndicatorSkin = (ProgressIndicatorSkin)progressIndicator.getSkin();
                return progressIndicatorSkin.spinEnabled == null || !progressIndicatorSkin.spinEnabled.isBound();
            }
            
            @Override
            public StyleableProperty<Boolean> getStyleableProperty(final ProgressIndicator progressIndicator) {
                return (StyleableProperty<Boolean>)((ProgressIndicatorSkin)progressIndicator.getSkin()).spinEnabled;
            }
        };
        final ArrayList<CssMetaData<ProgressIndicator, Number>> list = new ArrayList<CssMetaData<ProgressIndicator, Number>>((Collection<? extends CssMetaData<ProgressIndicator, Number>>)SkinBase.getClassCssMetaData());
        list.add(ProgressIndicatorSkin.PROGRESS_COLOR);
        list.add((CssMetaData<ProgressIndicator, Paint>)ProgressIndicatorSkin.INDETERMINATE_SEGMENT_COUNT);
        list.add((CssMetaData<ProgressIndicator, Paint>)ProgressIndicatorSkin.SPIN_ENABLED);
        STYLEABLES = Collections.unmodifiableList((List<?>)list);
    }
    
    private final class DeterminateIndicator extends Region
    {
        private double textGap;
        private int intProgress;
        private int degProgress;
        private Text text;
        private StackPane indicator;
        private StackPane progress;
        private StackPane tick;
        private Arc arcShape;
        private Circle indicatorCircle;
        private double doneTextWidth;
        private double doneTextHeight;
        
        public DeterminateIndicator(final ProgressIndicator progressIndicator, final ProgressIndicatorSkin progressIndicatorSkin, final Paint fillOverride) {
            this.textGap = 2.0;
            this.getStyleClass().add("determinate-indicator");
            this.intProgress = (int)Math.round(progressIndicator.getProgress() * 100.0);
            this.degProgress = (int)(360.0 * progressIndicator.getProgress());
            this.getChildren().clear();
            (this.text = new Text((progressIndicator.getProgress() >= 1.0) ? ProgressIndicatorSkin.this.DONE : invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, this.intProgress))).setTextOrigin(VPos.TOP);
            this.text.getStyleClass().setAll("text", "percentage");
            ProgressIndicatorSkin.this.registerChangeListener(this.text.fontProperty(), p0 -> {
                this.doneTextWidth = Utils.computeTextWidth(this.text.getFont(), ProgressIndicatorSkin.this.DONE, 0.0);
                this.doneTextHeight = Utils.computeTextHeight(this.text.getFont(), ProgressIndicatorSkin.this.DONE, 0.0, TextBoundsType.LOGICAL_VERTICAL_CENTER);
                return;
            });
            (this.indicator = new StackPane()).setScaleShape(false);
            this.indicator.setCenterShape(false);
            this.indicator.getStyleClass().setAll("indicator");
            this.indicatorCircle = new Circle();
            this.indicator.setShape(this.indicatorCircle);
            (this.arcShape = new Arc()).setType(ArcType.ROUND);
            this.arcShape.setStartAngle(90.0);
            this.progress = new StackPane();
            this.progress.getStyleClass().setAll("progress");
            this.progress.setScaleShape(false);
            this.progress.setCenterShape(false);
            this.progress.setShape(this.arcShape);
            this.progress.getChildren().clear();
            this.setFillOverride(fillOverride);
            this.tick = new StackPane();
            this.tick.getStyleClass().setAll("tick");
            this.getChildren().setAll(this.indicator, this.progress, this.text, this.tick);
            this.updateProgress(progressIndicator.getProgress());
        }
        
        private void setFillOverride(final Paint paint) {
            if (paint instanceof Color) {
                final Color color = (Color)paint;
                this.progress.setStyle(invokedynamic(makeConcatWithConstants:(IIID)Ljava/lang/String;, (int)(255.0 * color.getRed()), (int)(255.0 * color.getGreen()), (int)(255.0 * color.getBlue()), color.getOpacity()));
            }
            else {
                this.progress.setStyle(null);
            }
        }
        
        @Override
        public boolean usesMirroring() {
            return false;
        }
        
        private void updateProgress(final double n) {
            this.intProgress = (int)Math.round(n * 100.0);
            this.text.setText((n >= 1.0) ? ProgressIndicatorSkin.this.DONE : invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, this.intProgress));
            this.degProgress = (int)(360.0 * n);
            this.arcShape.setLength(-this.degProgress);
            this.requestLayout();
        }
        
        @Override
        protected void layoutChildren() {
            final double snappedLeftInset = ProgressIndicatorSkin.this.control.snappedLeftInset();
            final double snappedRightInset = ProgressIndicatorSkin.this.control.snappedRightInset();
            final double snappedTopInset = ProgressIndicatorSkin.this.control.snappedTopInset();
            final double snappedBottomInset = ProgressIndicatorSkin.this.control.snappedBottomInset();
            final double n = ProgressIndicatorSkin.this.control.getWidth() - snappedLeftInset - snappedRightInset;
            final double n2 = ProgressIndicatorSkin.this.control.getHeight() - snappedTopInset - snappedBottomInset - this.textGap - this.doneTextHeight;
            final double a = n / 2.0;
            final double floor = Math.floor(Math.min(a, n2 / 2.0));
            final double snapPosition = this.snapPosition(snappedLeftInset + a);
            final double snapPosition2 = this.snapPosition(snappedTopInset + floor);
            final double snapSize = this.snapSize(Math.min(Math.min(floor - this.indicator.snappedLeftInset(), floor - this.indicator.snappedRightInset()), Math.min(floor - this.indicator.snappedTopInset(), floor - this.indicator.snappedBottomInset())));
            this.indicatorCircle.setRadius(floor);
            this.indicator.setLayoutX(snapPosition);
            this.indicator.setLayoutY(snapPosition2);
            this.arcShape.setRadiusX(snapSize);
            this.arcShape.setRadiusY(snapSize);
            this.progress.setLayoutX(snapPosition);
            this.progress.setLayoutY(snapPosition2);
            final double snapSize2 = this.snapSize(Math.min(Math.min(snapSize - this.progress.snappedLeftInset(), snapSize - this.progress.snappedRightInset()), Math.min(snapSize - this.progress.snappedTopInset(), snapSize - this.progress.snappedBottomInset())));
            final double ceil = Math.ceil(Math.sqrt(snapSize2 * snapSize2 / 2.0));
            this.tick.setLayoutX(snapPosition - ceil);
            this.tick.setLayoutY(snapPosition2 - ceil);
            this.tick.resize(ceil + ceil, ceil + ceil);
            this.tick.setVisible(ProgressIndicatorSkin.this.control.getProgress() >= 1.0);
            final double width = this.text.getLayoutBounds().getWidth();
            final double height = this.text.getLayoutBounds().getHeight();
            if (ProgressIndicatorSkin.this.control.getWidth() >= width && ProgressIndicatorSkin.this.control.getHeight() >= height) {
                if (!this.text.isVisible()) {
                    this.text.setVisible(true);
                }
                this.text.setLayoutY(this.snapPosition(snapPosition2 + floor + this.textGap));
                this.text.setLayoutX(this.snapPosition(snapPosition - width / 2.0));
            }
            else if (this.text.isVisible()) {
                this.text.setVisible(false);
            }
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            final double snappedLeftInset = ProgressIndicatorSkin.this.control.snappedLeftInset();
            final double snappedRightInset = ProgressIndicatorSkin.this.control.snappedRightInset();
            final double snapSize = this.snapSize(Math.max(Math.max(this.indicator.snappedLeftInset(), this.indicator.snappedRightInset()), Math.max(this.indicator.snappedTopInset(), this.indicator.snappedBottomInset())));
            final double snapSize2 = this.snapSize(Math.max(Math.max(this.progress.snappedLeftInset(), this.progress.snappedRightInset()), Math.max(this.progress.snappedTopInset(), this.progress.snappedBottomInset())));
            return snappedLeftInset + Math.max(snapSize + snapSize2 + this.tick.snappedLeftInset() + this.tick.snappedRightInset() + snapSize2 + snapSize, this.doneTextWidth) + snappedRightInset;
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            final double snappedTopInset = ProgressIndicatorSkin.this.control.snappedTopInset();
            final double snappedBottomInset = ProgressIndicatorSkin.this.control.snappedBottomInset();
            final double snapSize = this.snapSize(Math.max(Math.max(this.indicator.snappedLeftInset(), this.indicator.snappedRightInset()), Math.max(this.indicator.snappedTopInset(), this.indicator.snappedBottomInset())));
            final double snapSize2 = this.snapSize(Math.max(Math.max(this.progress.snappedLeftInset(), this.progress.snappedRightInset()), Math.max(this.progress.snappedTopInset(), this.progress.snappedBottomInset())));
            return snappedTopInset + (snapSize + snapSize2 + this.tick.snappedTopInset() + this.tick.snappedBottomInset() + snapSize2 + snapSize) + this.textGap + this.doneTextHeight + snappedBottomInset;
        }
        
        @Override
        protected double computeMaxWidth(final double n) {
            return this.computePrefWidth(n);
        }
        
        @Override
        protected double computeMaxHeight(final double n) {
            return this.computePrefHeight(n);
        }
    }
    
    private final class IndeterminateSpinner extends Region
    {
        private IndicatorPaths pathsG;
        private final List<Double> opacities;
        private boolean spinEnabled;
        private Paint fillOverride;
        
        private IndeterminateSpinner(final boolean spinEnabled, final Paint fillOverride) {
            this.opacities = new ArrayList<Double>();
            this.spinEnabled = false;
            this.fillOverride = null;
            this.spinEnabled = spinEnabled;
            this.fillOverride = fillOverride;
            this.setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
            this.getStyleClass().setAll("spinner");
            this.pathsG = new IndicatorPaths();
            this.getChildren().add(this.pathsG);
            this.rebuild();
            this.rebuildTimeline();
        }
        
        public void setFillOverride(final Paint fillOverride) {
            this.fillOverride = fillOverride;
            this.rebuild();
        }
        
        public void setSpinEnabled(final boolean spinEnabled) {
            this.spinEnabled = spinEnabled;
            this.rebuildTimeline();
        }
        
        private void rebuildTimeline() {
            if (this.spinEnabled) {
                if (ProgressIndicatorSkin.this.indeterminateTransition == null) {
                    (ProgressIndicatorSkin.this.indeterminateTransition = new Timeline()).setCycleCount(-1);
                    ProgressIndicatorSkin.this.indeterminateTransition.setDelay(ProgressIndicatorSkin.this.UNCLIPPED_DELAY);
                }
                else {
                    ProgressIndicatorSkin.this.indeterminateTransition.stop();
                    ((Timeline)ProgressIndicatorSkin.this.indeterminateTransition).getKeyFrames().clear();
                }
                final ObservableList<KeyFrame> observableArrayList = FXCollections.observableArrayList();
                observableArrayList.add(new KeyFrame(Duration.millis(1.0), new KeyValue[] { new KeyValue((WritableValue<T>)this.pathsG.rotateProperty(), (T)360) }));
                observableArrayList.add(new KeyFrame(Duration.millis(3900.0), new KeyValue[] { new KeyValue((WritableValue<T>)this.pathsG.rotateProperty(), (T)0) }));
                for (int i = 100; i <= 3900; i += 100) {
                    observableArrayList.add(new KeyFrame(Duration.millis(i), p0 -> this.shiftColors(), new KeyValue[0]));
                }
                ((Timeline)ProgressIndicatorSkin.this.indeterminateTransition).getKeyFrames().setAll(observableArrayList);
                ProgressIndicatorSkin.this.indeterminateTransition.playFromStart();
            }
            else if (ProgressIndicatorSkin.this.indeterminateTransition != null) {
                ProgressIndicatorSkin.this.indeterminateTransition.stop();
                ((Timeline)ProgressIndicatorSkin.this.indeterminateTransition).getKeyFrames().clear();
                ProgressIndicatorSkin.this.indeterminateTransition = null;
            }
        }
        
        @Override
        protected void layoutChildren() {
            final double n = ProgressIndicatorSkin.this.control.getWidth() - ProgressIndicatorSkin.this.control.snappedLeftInset() - ProgressIndicatorSkin.this.control.snappedRightInset();
            final double n2 = ProgressIndicatorSkin.this.control.getHeight() - ProgressIndicatorSkin.this.control.snappedTopInset() - ProgressIndicatorSkin.this.control.snappedBottomInset();
            final double prefWidth = this.pathsG.prefWidth(-1.0);
            final double prefHeight = this.pathsG.prefHeight(-1.0);
            double n3;
            if ((n3 = n / prefWidth) * prefHeight > n2) {
                n3 = n2 / prefHeight;
            }
            final double n4 = prefWidth * n3;
            final double n5 = prefHeight * n3;
            this.pathsG.resizeRelocate((n - n4) / 2.0, (n2 - n5) / 2.0, n4, n5);
        }
        
        private void rebuild() {
            final int value = ProgressIndicatorSkin.this.indeterminateSegmentCount.get();
            this.opacities.clear();
            this.pathsG.getChildren().clear();
            final double n = 0.8 / (value - 1);
            for (int i = 0; i < value; ++i) {
                final Region region = new Region();
                region.setScaleShape(false);
                region.setCenterShape(false);
                region.getStyleClass().addAll(new String[] { "segment", invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, i) });
                if (this.fillOverride instanceof Color) {
                    final Color color = (Color)this.fillOverride;
                    region.setStyle(invokedynamic(makeConcatWithConstants:(IIID)Ljava/lang/String;, (int)(255.0 * color.getRed()), (int)(255.0 * color.getGreen()), (int)(255.0 * color.getBlue()), color.getOpacity()));
                }
                else {
                    region.setStyle(null);
                }
                this.pathsG.getChildren().add(region);
                this.opacities.add(Math.max(0.1, 1.0 - n * i));
            }
        }
        
        private void shiftColors() {
            if (this.opacities.size() <= 0) {
                return;
            }
            final int value = ProgressIndicatorSkin.this.indeterminateSegmentCount.get();
            Collections.rotate(this.opacities, -1);
            for (int i = 0; i < value; ++i) {
                ((Node)this.pathsG.getChildren().get(i)).setOpacity(this.opacities.get(i));
            }
        }
        
        private class IndicatorPaths extends Pane
        {
            @Override
            protected double computePrefWidth(final double n) {
                double n2 = 0.0;
                for (final Node node : this.getChildren()) {
                    if (node instanceof Region) {
                        final Region region = (Region)node;
                        if (region.getShape() != null) {
                            n2 = Math.max(n2, region.getShape().getLayoutBounds().getMaxX());
                        }
                        else {
                            n2 = Math.max(n2, region.prefWidth(n));
                        }
                    }
                }
                return n2;
            }
            
            @Override
            protected double computePrefHeight(final double n) {
                double n2 = 0.0;
                for (final Node node : this.getChildren()) {
                    if (node instanceof Region) {
                        final Region region = (Region)node;
                        if (region.getShape() != null) {
                            n2 = Math.max(n2, region.getShape().getLayoutBounds().getMaxY());
                        }
                        else {
                            n2 = Math.max(n2, region.prefHeight(n));
                        }
                    }
                }
                return n2;
            }
            
            @Override
            protected void layoutChildren() {
                final double n = this.getWidth() / this.computePrefWidth(-1.0);
                for (final Node node : this.getChildren()) {
                    if (node instanceof Region) {
                        final Region region = (Region)node;
                        if (region.getShape() != null) {
                            region.resize(region.getShape().getLayoutBounds().getMaxX(), region.getShape().getLayoutBounds().getMaxY());
                            region.getTransforms().setAll(new Scale(n, n, 0.0, 0.0));
                        }
                        else {
                            region.autosize();
                        }
                    }
                }
            }
        }
    }
}
