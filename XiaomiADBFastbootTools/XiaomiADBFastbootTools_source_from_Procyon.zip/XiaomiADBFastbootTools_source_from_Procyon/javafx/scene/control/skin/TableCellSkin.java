// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.control.TableColumn;
import javafx.beans.property.ReadOnlyObjectProperty;
import com.sun.javafx.scene.control.behavior.TableCellBehavior;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.TableCell;

public class TableCellSkin<S, T> extends TableCellSkinBase<S, T, TableCell<S, T>>
{
    private final BehaviorBase<TableCell<S, T>> behavior;
    
    public TableCellSkin(final TableCell<S, T> tableCell) {
        super(tableCell);
        this.behavior = (BehaviorBase<TableCell<S, T>>)new TableCellBehavior((TableCell<Object, Object>)tableCell);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    public ReadOnlyObjectProperty<TableColumn<S, T>> tableColumnProperty() {
        return this.getSkinnable().tableColumnProperty();
    }
}
