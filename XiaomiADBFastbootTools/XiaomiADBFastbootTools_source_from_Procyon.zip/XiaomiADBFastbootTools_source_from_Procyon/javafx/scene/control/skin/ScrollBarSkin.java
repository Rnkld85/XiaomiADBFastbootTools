// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.layout.Region;
import javafx.scene.input.MouseEvent;
import javafx.scene.Node;
import javafx.scene.input.ScrollEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleRole;
import javafx.scene.AccessibleAttribute;
import com.sun.javafx.util.Utils;
import com.sun.javafx.scene.control.Properties;
import javafx.geometry.Orientation;
import java.util.function.Consumer;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Point2D;
import javafx.scene.layout.StackPane;
import com.sun.javafx.scene.control.behavior.ScrollBarBehavior;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.SkinBase;

public class ScrollBarSkin extends SkinBase<ScrollBar>
{
    private final ScrollBarBehavior behavior;
    private StackPane thumb;
    private StackPane trackBackground;
    private StackPane track;
    private EndButton incButton;
    private EndButton decButton;
    private double trackLength;
    private double thumbLength;
    private double preDragThumbPos;
    private Point2D dragStart;
    private double trackPos;
    
    public ScrollBarSkin(final ScrollBar scrollBar) {
        super(scrollBar);
        this.behavior = new ScrollBarBehavior(scrollBar);
        this.initialize();
        this.getSkinnable().requestLayout();
        final Consumer<ObservableValue<?>> consumer = p0 -> {
            this.positionThumb();
            this.getSkinnable().requestLayout();
            return;
        };
        this.registerChangeListener(scrollBar.minProperty(), consumer);
        this.registerChangeListener(scrollBar.maxProperty(), consumer);
        this.registerChangeListener(scrollBar.visibleAmountProperty(), consumer);
        this.registerChangeListener(scrollBar.valueProperty(), p0 -> this.positionThumb());
        this.registerChangeListener(scrollBar.orientationProperty(), p0 -> this.getSkinnable().requestLayout());
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        final ScrollBar scrollBar = this.getSkinnable();
        double n5;
        if (scrollBar.getMax() > scrollBar.getMin()) {
            n5 = scrollBar.getVisibleAmount() / (scrollBar.getMax() - scrollBar.getMin());
        }
        else {
            n5 = 1.0;
        }
        if (scrollBar.getOrientation() == Orientation.VERTICAL) {
            if (!Properties.IS_TOUCH_SUPPORTED) {
                final double snapSizeY = this.snapSizeY(this.decButton.prefHeight(-1.0));
                final double snapSizeY2 = this.snapSizeY(this.incButton.prefHeight(-1.0));
                this.decButton.resize(n3, snapSizeY);
                this.incButton.resize(n3, snapSizeY2);
                this.trackLength = this.snapSizeY(n4 - (snapSizeY + snapSizeY2));
                this.thumbLength = this.snapSizeY(Utils.clamp(this.minThumbLength(), this.trackLength * n5, this.trackLength));
                this.trackBackground.resizeRelocate(this.snapPositionX(n), this.snapPositionY(n2), n3, this.trackLength + snapSizeY + snapSizeY2);
                this.decButton.relocate(this.snapPositionX(n), this.snapPositionY(n2));
                this.incButton.relocate(this.snapPositionX(n), this.snapPositionY(n2 + n4 - snapSizeY2));
                this.track.resizeRelocate(this.snapPositionX(n), this.snapPositionY(n2 + snapSizeY), n3, this.trackLength);
                this.thumb.resize(this.snapSizeX((n >= 0.0) ? n3 : (n3 + n)), this.thumbLength);
                this.positionThumb();
            }
            else {
                this.trackLength = this.snapSizeY(n4);
                this.thumbLength = this.snapSizeY(Utils.clamp(this.minThumbLength(), this.trackLength * n5, this.trackLength));
                this.track.resizeRelocate(this.snapPositionX(n), this.snapPositionY(n2), n3, this.trackLength);
                this.thumb.resize(this.snapSizeX((n >= 0.0) ? n3 : (n3 + n)), this.thumbLength);
                this.positionThumb();
            }
        }
        else {
            if (!Properties.IS_TOUCH_SUPPORTED) {
                final double snapSizeX = this.snapSizeX(this.decButton.prefWidth(-1.0));
                final double snapSizeX2 = this.snapSizeX(this.incButton.prefWidth(-1.0));
                this.decButton.resize(snapSizeX, n4);
                this.incButton.resize(snapSizeX2, n4);
                this.trackLength = this.snapSizeX(n3 - (snapSizeX + snapSizeX2));
                this.thumbLength = this.snapSizeX(Utils.clamp(this.minThumbLength(), this.trackLength * n5, this.trackLength));
                this.trackBackground.resizeRelocate(this.snapPositionX(n), this.snapPositionY(n2), this.trackLength + snapSizeX + snapSizeX2, n4);
                this.decButton.relocate(this.snapPositionX(n), this.snapPositionY(n2));
                this.incButton.relocate(this.snapPositionX(n + n3 - snapSizeX2), this.snapPositionY(n2));
                this.track.resizeRelocate(this.snapPositionX(n + snapSizeX), this.snapPositionY(n2), this.trackLength, n4);
                this.thumb.resize(this.thumbLength, this.snapSizeY((n2 >= 0.0) ? n4 : (n4 + n2)));
                this.positionThumb();
            }
            else {
                this.trackLength = this.snapSizeX(n3);
                this.thumbLength = this.snapSizeX(Utils.clamp(this.minThumbLength(), this.trackLength * n5, this.trackLength));
                this.track.resizeRelocate(this.snapPositionX(n), this.snapPositionY(n2), this.trackLength, n4);
                this.thumb.resize(this.thumbLength, this.snapSizeY((n2 >= 0.0) ? n4 : (n4 + n2)));
                this.positionThumb();
            }
            scrollBar.resize(this.snapSizeX(scrollBar.getWidth()), this.snapSizeY(scrollBar.getHeight()));
        }
        if ((scrollBar.getOrientation() == Orientation.VERTICAL && n4 >= this.computeMinHeight(-1.0, (int)n2, this.snappedRightInset(), this.snappedBottomInset(), (int)n) - (n2 + this.snappedBottomInset())) || (scrollBar.getOrientation() == Orientation.HORIZONTAL && n3 >= this.computeMinWidth(-1.0, (int)n2, this.snappedRightInset(), this.snappedBottomInset(), (int)n) - (n + this.snappedRightInset()))) {
            this.trackBackground.setVisible(true);
            this.track.setVisible(true);
            this.thumb.setVisible(true);
            if (!Properties.IS_TOUCH_SUPPORTED) {
                this.incButton.setVisible(true);
                this.decButton.setVisible(true);
            }
        }
        else {
            this.trackBackground.setVisible(false);
            this.track.setVisible(false);
            this.thumb.setVisible(false);
            if (!Properties.IS_TOUCH_SUPPORTED) {
                if (n4 >= this.decButton.computeMinWidth(-1.0)) {
                    this.decButton.setVisible(true);
                }
                else {
                    this.decButton.setVisible(false);
                }
                if (n4 >= this.incButton.computeMinWidth(-1.0)) {
                    this.incButton.setVisible(true);
                }
                else {
                    this.incButton.setVisible(false);
                }
            }
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
            return this.getBreadth();
        }
        if (!Properties.IS_TOUCH_SUPPORTED) {
            return this.decButton.minWidth(-1.0) + this.incButton.minWidth(-1.0) + this.minTrackLength() + n5 + n3;
        }
        return this.minTrackLength() + n5 + n3;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.getSkinnable().getOrientation() != Orientation.VERTICAL) {
            return this.getBreadth();
        }
        if (!Properties.IS_TOUCH_SUPPORTED) {
            return this.decButton.minHeight(-1.0) + this.incButton.minHeight(-1.0) + this.minTrackLength() + n2 + n4;
        }
        return this.minTrackLength() + n2 + n4;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return (this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? this.getBreadth() : (100.0 + n5 + n3);
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return (this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? (100.0 + n2 + n4) : this.getBreadth();
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final ScrollBar scrollBar = this.getSkinnable();
        return (scrollBar.getOrientation() == Orientation.VERTICAL) ? scrollBar.prefWidth(-1.0) : Double.MAX_VALUE;
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        final ScrollBar scrollBar = this.getSkinnable();
        return (scrollBar.getOrientation() == Orientation.VERTICAL) ? Double.MAX_VALUE : scrollBar.prefHeight(-1.0);
    }
    
    private void initialize() {
        this.track = new StackPane();
        this.track.getStyleClass().setAll("track");
        this.trackBackground = new StackPane();
        this.trackBackground.getStyleClass().setAll("track-background");
        this.thumb = new StackPane() {
            @Override
            public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
                switch (accessibleAttribute) {
                    case VALUE: {
                        return ScrollBarSkin.this.getSkinnable().getValue();
                    }
                    default: {
                        return super.queryAccessibleAttribute(accessibleAttribute, array);
                    }
                }
            }
        };
        this.thumb.getStyleClass().setAll("thumb");
        this.thumb.setAccessibleRole(AccessibleRole.THUMB);
        if (!Properties.IS_TOUCH_SUPPORTED) {
            (this.incButton = new EndButton("increment-button", "increment-arrow") {
                @Override
                public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
                    switch (accessibleAction) {
                        case FIRE: {
                            ScrollBarSkin.this.getSkinnable().increment();
                            break;
                        }
                        default: {
                            super.executeAccessibleAction(accessibleAction, array);
                            break;
                        }
                    }
                }
            }).setAccessibleRole(AccessibleRole.INCREMENT_BUTTON);
            this.incButton.setOnMousePressed(mouseEvent -> {
                if (!this.thumb.isVisible() || this.trackLength > this.thumbLength) {
                    this.behavior.incButtonPressed();
                }
                mouseEvent.consume();
                return;
            });
            this.incButton.setOnMouseReleased(mouseEvent2 -> {
                if (!this.thumb.isVisible() || this.trackLength > this.thumbLength) {
                    this.behavior.incButtonReleased();
                }
                mouseEvent2.consume();
                return;
            });
            (this.decButton = new EndButton("decrement-button", "decrement-arrow") {
                @Override
                public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
                    switch (accessibleAction) {
                        case FIRE: {
                            ScrollBarSkin.this.getSkinnable().decrement();
                            break;
                        }
                        default: {
                            super.executeAccessibleAction(accessibleAction, array);
                            break;
                        }
                    }
                }
            }).setAccessibleRole(AccessibleRole.DECREMENT_BUTTON);
            this.decButton.setOnMousePressed(mouseEvent3 -> {
                if (!this.thumb.isVisible() || this.trackLength > this.thumbLength) {
                    this.behavior.decButtonPressed();
                }
                mouseEvent3.consume();
                return;
            });
            this.decButton.setOnMouseReleased(mouseEvent4 -> {
                if (!this.thumb.isVisible() || this.trackLength > this.thumbLength) {
                    this.behavior.decButtonReleased();
                }
                mouseEvent4.consume();
                return;
            });
        }
        this.track.setOnMousePressed(mouseEvent5 -> {
            if (!this.thumb.isPressed() && mouseEvent5.getButton() == MouseButton.PRIMARY) {
                if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                    if (this.trackLength != 0.0) {
                        this.behavior.trackPress(mouseEvent5.getY() / this.trackLength);
                        mouseEvent5.consume();
                    }
                }
                else if (this.trackLength != 0.0) {
                    this.behavior.trackPress(mouseEvent5.getX() / this.trackLength);
                    mouseEvent5.consume();
                }
            }
            return;
        });
        this.track.setOnMouseReleased(mouseEvent6 -> {
            this.behavior.trackRelease();
            mouseEvent6.consume();
            return;
        });
        this.thumb.setOnMousePressed(mouseEvent7 -> {
            if (mouseEvent7.isSynthesized()) {
                mouseEvent7.consume();
                return;
            }
            else {
                if (this.getSkinnable().getMax() > this.getSkinnable().getMin()) {
                    this.dragStart = this.thumb.localToParent(mouseEvent7.getX(), mouseEvent7.getY());
                    this.preDragThumbPos = (Utils.clamp(this.getSkinnable().getMin(), this.getSkinnable().getValue(), this.getSkinnable().getMax()) - this.getSkinnable().getMin()) / (this.getSkinnable().getMax() - this.getSkinnable().getMin());
                    mouseEvent7.consume();
                }
                return;
            }
        });
        final Point2D point2D;
        this.thumb.setOnMouseDragged(mouseEvent8 -> {
            if (mouseEvent8.isSynthesized()) {
                mouseEvent8.consume();
                return;
            }
            else {
                if (this.getSkinnable().getMax() > this.getSkinnable().getMin()) {
                    if (this.trackLength > this.thumbLength) {
                        this.thumb.localToParent(mouseEvent8.getX(), mouseEvent8.getY());
                        if (this.dragStart == null) {
                            this.dragStart = this.thumb.localToParent(mouseEvent8.getX(), mouseEvent8.getY());
                        }
                        this.behavior.thumbDragged(this.preDragThumbPos + ((this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? (point2D.getY() - this.dragStart.getY()) : (point2D.getX() - this.dragStart.getX())) / (this.trackLength - this.thumbLength));
                    }
                    mouseEvent8.consume();
                }
                return;
            }
        });
        this.thumb.setOnScrollStarted(scrollEvent -> {
            if (scrollEvent.isDirect() && this.getSkinnable().getMax() > this.getSkinnable().getMin()) {
                this.dragStart = this.thumb.localToParent(scrollEvent.getX(), scrollEvent.getY());
                this.preDragThumbPos = (Utils.clamp(this.getSkinnable().getMin(), this.getSkinnable().getValue(), this.getSkinnable().getMax()) - this.getSkinnable().getMin()) / (this.getSkinnable().getMax() - this.getSkinnable().getMin());
                scrollEvent.consume();
            }
            return;
        });
        final Point2D point2D2;
        this.thumb.setOnScroll(scrollEvent2 -> {
            if (scrollEvent2.isDirect() && this.getSkinnable().getMax() > this.getSkinnable().getMin()) {
                if (this.trackLength > this.thumbLength) {
                    this.thumb.localToParent(scrollEvent2.getX(), scrollEvent2.getY());
                    if (this.dragStart == null) {
                        this.dragStart = this.thumb.localToParent(scrollEvent2.getX(), scrollEvent2.getY());
                    }
                    this.behavior.thumbDragged(this.preDragThumbPos + ((this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? (point2D2.getY() - this.dragStart.getY()) : (point2D2.getX() - this.dragStart.getX())) / (this.trackLength - this.thumbLength));
                }
                scrollEvent2.consume();
                return;
            }
            else {
                return;
            }
        });
        final double a;
        final double a2;
        double n;
        ScrollBar scrollBar;
        double n2;
        this.getSkinnable().addEventHandler(ScrollEvent.SCROLL, scrollEvent3 -> {
            if (this.trackLength > this.thumbLength) {
                scrollEvent3.getDeltaX();
                scrollEvent3.getDeltaY();
                n = ((Math.abs(a) < Math.abs(a2)) ? a2 : a);
                scrollBar = this.getSkinnable();
                n2 = ((this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? a2 : n);
                if (scrollEvent3.isDirect()) {
                    if (this.trackLength > this.thumbLength) {
                        this.behavior.thumbDragged(((this.getSkinnable().getOrientation() == Orientation.VERTICAL) ? scrollEvent3.getY() : scrollEvent3.getX()) / this.trackLength);
                        scrollEvent3.consume();
                    }
                }
                else if (n2 > 0.0 && scrollBar.getValue() > scrollBar.getMin()) {
                    scrollBar.decrement();
                    scrollEvent3.consume();
                }
                else if (n2 < 0.0 && scrollBar.getValue() < scrollBar.getMax()) {
                    scrollBar.increment();
                    scrollEvent3.consume();
                }
            }
            return;
        });
        this.getChildren().clear();
        if (!Properties.IS_TOUCH_SUPPORTED) {
            this.getChildren().addAll(this.trackBackground, this.incButton, this.decButton, this.track, this.thumb);
        }
        else {
            this.getChildren().addAll(this.track, this.thumb);
        }
    }
    
    double getBreadth() {
        if (!Properties.IS_TOUCH_SUPPORTED) {
            if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                return Math.max(this.decButton.prefWidth(-1.0), this.incButton.prefWidth(-1.0)) + this.snappedLeftInset() + this.snappedRightInset();
            }
            return Math.max(this.decButton.prefHeight(-1.0), this.incButton.prefHeight(-1.0)) + this.snappedTopInset() + this.snappedBottomInset();
        }
        else {
            if (this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
                return Math.max(8.0, 8.0) + this.snappedLeftInset() + this.snappedRightInset();
            }
            return Math.max(8.0, 8.0) + this.snappedTopInset() + this.snappedBottomInset();
        }
    }
    
    double minThumbLength() {
        return 1.5 * this.getBreadth();
    }
    
    double minTrackLength() {
        return 2.0 * this.getBreadth();
    }
    
    void positionThumb() {
        final ScrollBar scrollBar = this.getSkinnable();
        final double clamp = Utils.clamp(scrollBar.getMin(), scrollBar.getValue(), scrollBar.getMax());
        this.trackPos = ((scrollBar.getMax() - scrollBar.getMin() > 0.0) ? ((this.trackLength - this.thumbLength) * (clamp - scrollBar.getMin()) / (scrollBar.getMax() - scrollBar.getMin())) : 0.0);
        if (!Properties.IS_TOUCH_SUPPORTED) {
            if (scrollBar.getOrientation() == Orientation.VERTICAL) {
                this.trackPos += this.decButton.prefHeight(-1.0);
            }
            else {
                this.trackPos += this.decButton.prefWidth(-1.0);
            }
        }
        this.thumb.setTranslateX(this.snapPositionX((scrollBar.getOrientation() == Orientation.VERTICAL) ? this.snappedLeftInset() : (this.trackPos + this.snappedLeftInset())));
        this.thumb.setTranslateY(this.snapPositionY((scrollBar.getOrientation() == Orientation.VERTICAL) ? (this.trackPos + this.snappedTopInset()) : this.snappedTopInset()));
    }
    
    private Node getThumb() {
        return this.thumb;
    }
    
    private Node getTrack() {
        return this.track;
    }
    
    private Node getIncrementButton() {
        return this.incButton;
    }
    
    private Node getDecrementButton() {
        return this.decButton;
    }
    
    private static class EndButton extends Region
    {
        private Region arrow;
        
        private EndButton(final String s, final String s2) {
            this.getStyleClass().setAll(s);
            this.arrow = new Region();
            this.arrow.getStyleClass().setAll(s2);
            this.getChildren().setAll(this.arrow);
            this.requestLayout();
        }
        
        @Override
        protected void layoutChildren() {
            final double snappedTopInset = this.snappedTopInset();
            final double snappedLeftInset = this.snappedLeftInset();
            final double snappedBottomInset = this.snappedBottomInset();
            final double snappedRightInset = this.snappedRightInset();
            final double snapSizeX = this.snapSizeX(this.arrow.prefWidth(-1.0));
            final double snapSizeY = this.snapSizeY(this.arrow.prefHeight(-1.0));
            this.arrow.resizeRelocate(this.snapPositionX((this.getWidth() - (snappedLeftInset + snappedRightInset + snapSizeX)) / 2.0) + snappedLeftInset, this.snapPositionY((this.getHeight() - (snappedTopInset + snappedBottomInset + snapSizeY)) / 2.0) + snappedTopInset, snapSizeX, snapSizeY);
        }
        
        @Override
        protected double computeMinHeight(final double n) {
            return this.prefHeight(-1.0);
        }
        
        @Override
        protected double computeMinWidth(final double n) {
            return this.prefWidth(-1.0);
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            return this.snappedLeftInset() + this.snapSizeX(this.arrow.prefWidth(-1.0)) + this.snappedRightInset();
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            return this.snappedTopInset() + this.snapSizeY(this.arrow.prefHeight(-1.0)) + this.snappedBottomInset();
        }
    }
}
