// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.Node;
import javafx.scene.control.TableColumnBase;
import java.util.Map;
import javafx.scene.control.TreeTableRow;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.TreeTableColumn;
import javafx.beans.property.ReadOnlyObjectProperty;
import com.sun.javafx.scene.control.behavior.TreeTableCellBehavior;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.TreeTableCell;
import javafx.scene.control.TreeItem;

public class TreeTableCellSkin<S, T> extends TableCellSkinBase<TreeItem<S>, T, TreeTableCell<S, T>>
{
    private final BehaviorBase<TreeTableCell<S, T>> behavior;
    
    public TreeTableCellSkin(final TreeTableCell<S, T> treeTableCell) {
        super(treeTableCell);
        this.behavior = (BehaviorBase<TreeTableCell<S, T>>)new TreeTableCellBehavior((TreeTableCell<Object, Object>)treeTableCell);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    public ReadOnlyObjectProperty<TreeTableColumn<S, T>> tableColumnProperty() {
        return this.getSkinnable().tableColumnProperty();
    }
    
    @Override
    double leftLabelPadding() {
        final double leftLabelPadding = super.leftLabelPadding();
        final double cellSize = this.getCellSize();
        final TreeTableCell treeTableCell = this.getSkinnable();
        final TreeTableColumn tableColumn = treeTableCell.getTableColumn();
        if (tableColumn == null) {
            return leftLabelPadding;
        }
        final TreeTableView treeTableView = treeTableCell.getTreeTableView();
        if (treeTableView == null) {
            return leftLabelPadding;
        }
        final int visibleLeafIndex = treeTableView.getVisibleLeafIndex(tableColumn);
        final TreeTableColumn treeColumn = treeTableView.getTreeColumn();
        if ((treeColumn == null && visibleLeafIndex != 0) || (treeColumn != null && !tableColumn.equals(treeColumn))) {
            return leftLabelPadding;
        }
        final TreeTableRow treeTableRow = treeTableCell.getTreeTableRow();
        if (treeTableRow == null) {
            return leftLabelPadding;
        }
        final TreeItem treeItem = treeTableRow.getTreeItem();
        if (treeItem == null) {
            return leftLabelPadding;
        }
        int treeItemLevel = treeTableView.getTreeItemLevel(treeItem);
        if (!treeTableView.isShowRoot()) {
            --treeItemLevel;
        }
        double indentationPerLevel = 10.0;
        if (treeTableRow.getSkin() instanceof TreeTableRowSkin) {
            indentationPerLevel = ((TreeTableRowSkin)treeTableRow.getSkin()).getIndentationPerLevel();
        }
        final double n = leftLabelPadding + treeItemLevel * indentationPerLevel;
        final Map<TableColumnBase<?, ?>, Double> maxDisclosureWidthMap = TableRowSkinBase.maxDisclosureWidthMap;
        final double n2 = n + (maxDisclosureWidthMap.containsKey(treeColumn) ? maxDisclosureWidthMap.get(treeColumn) : 0.0);
        final Node graphic = treeItem.getGraphic();
        return n2 + ((graphic == null) ? 0.0 : graphic.prefWidth(cellSize));
    }
}
