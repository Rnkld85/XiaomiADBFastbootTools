// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.beans.value.ObservableValue;
import javafx.scene.control.Label;

public class LabelSkin extends LabeledSkinBase<Label>
{
    public LabelSkin(final Label label) {
        super(label);
        this.consumeMouseEvents(false);
        this.registerChangeListener(label.labelForProperty(), p0 -> this.mnemonicTargetChanged());
    }
}
