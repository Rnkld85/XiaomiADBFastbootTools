// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.input.MouseEvent;
import javafx.util.Duration;
import javafx.animation.Transition;
import javafx.scene.Node;
import javafx.scene.AccessibleRole;
import javafx.scene.AccessibleAttribute;
import javafx.scene.layout.BackgroundFill;
import javafx.geometry.Side;
import javafx.geometry.Orientation;
import javafx.beans.value.ObservableValue;
import javafx.util.StringConverter;
import com.sun.javafx.scene.control.behavior.SliderBehavior;
import javafx.scene.layout.StackPane;
import javafx.geometry.Point2D;
import javafx.scene.chart.NumberAxis;
import javafx.scene.control.Slider;
import javafx.scene.control.SkinBase;

public class SliderSkin extends SkinBase<Slider>
{
    private NumberAxis tickLine;
    private double trackToTickGap;
    private boolean showTickMarks;
    private double thumbWidth;
    private double thumbHeight;
    private double trackStart;
    private double trackLength;
    private double thumbTop;
    private double thumbLeft;
    private double preDragThumbPos;
    private Point2D dragStart;
    private StackPane thumb;
    private StackPane track;
    private boolean trackClicked;
    private final SliderBehavior behavior;
    StringConverter<Number> stringConverterWrapper;
    
    public SliderSkin(final Slider slider) {
        super(slider);
        this.tickLine = null;
        this.trackToTickGap = 2.0;
        this.trackClicked = false;
        this.stringConverterWrapper = new StringConverter<Number>() {
            Slider slider = SliderSkin.this.getSkinnable();
            
            @Override
            public String toString(final Number n) {
                return (n != null) ? this.slider.getLabelFormatter().toString(n.doubleValue()) : "";
            }
            
            @Override
            public Number fromString(final String s) {
                return this.slider.getLabelFormatter().fromString(s);
            }
        };
        this.behavior = new SliderBehavior(slider);
        this.initialize();
        slider.requestLayout();
        this.registerChangeListener(slider.minProperty(), p1 -> {
            if (this.showTickMarks && this.tickLine != null) {
                this.tickLine.setLowerBound(slider.getMin());
            }
            this.getSkinnable().requestLayout();
            return;
        });
        this.registerChangeListener(slider.maxProperty(), p1 -> {
            if (this.showTickMarks && this.tickLine != null) {
                this.tickLine.setUpperBound(slider.getMax());
            }
            this.getSkinnable().requestLayout();
            return;
        });
        this.registerChangeListener(slider.valueProperty(), p0 -> this.positionThumb(this.trackClicked));
        this.registerChangeListener(slider.orientationProperty(), p1 -> {
            if (this.showTickMarks && this.tickLine != null) {
                this.tickLine.setSide((slider.getOrientation() == Orientation.VERTICAL) ? Side.RIGHT : ((slider.getOrientation() == null) ? Side.RIGHT : Side.BOTTOM));
            }
            this.getSkinnable().requestLayout();
            return;
        });
        this.registerChangeListener(slider.showTickMarksProperty(), p1 -> this.setShowTickMarks(slider.isShowTickMarks(), slider.isShowTickLabels()));
        this.registerChangeListener(slider.showTickLabelsProperty(), p1 -> this.setShowTickMarks(slider.isShowTickMarks(), slider.isShowTickLabels()));
        this.registerChangeListener(slider.majorTickUnitProperty(), p1 -> {
            if (this.tickLine != null) {
                this.tickLine.setTickUnit(slider.getMajorTickUnit());
                this.getSkinnable().requestLayout();
            }
            return;
        });
        this.registerChangeListener(slider.minorTickCountProperty(), p1 -> {
            if (this.tickLine != null) {
                this.tickLine.setMinorTickCount(Math.max(slider.getMinorTickCount(), 0) + 1);
                this.getSkinnable().requestLayout();
            }
            return;
        });
        this.registerChangeListener(slider.labelFormatterProperty(), p1 -> {
            if (this.tickLine != null) {
                if (slider.getLabelFormatter() == null) {
                    this.tickLine.setTickLabelFormatter(null);
                }
                else {
                    this.tickLine.setTickLabelFormatter(this.stringConverterWrapper);
                    this.tickLine.requestAxisLayout();
                }
            }
            return;
        });
        this.registerChangeListener(slider.snapToTicksProperty(), p1 -> slider.adjustValue(slider.getValue()));
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        this.thumbWidth = this.snapSizeX(this.thumb.prefWidth(-1.0));
        this.thumbHeight = this.snapSizeY(this.thumb.prefHeight(-1.0));
        this.thumb.resize(this.thumbWidth, this.thumbHeight);
        final double n5 = (this.track.getBackground() == null) ? 0.0 : ((this.track.getBackground().getFills().size() > 0) ? this.track.getBackground().getFills().get(0).getRadii().getTopLeftHorizontalRadius() : 0.0);
        if (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
            final double n6 = this.showTickMarks ? this.tickLine.prefHeight(-1.0) : 0.0;
            final double snapSizeY = this.snapSizeY(this.track.prefHeight(-1.0));
            final double max = Math.max(snapSizeY, this.thumbHeight);
            final double n7 = n2 + (n4 - (max + (this.showTickMarks ? (this.trackToTickGap + n6) : 0.0))) / 2.0;
            this.trackLength = this.snapSizeX(n3 - this.thumbWidth);
            this.trackStart = this.snapPositionX(n + this.thumbWidth / 2.0);
            final double n8 = (int)(n7 + (max - snapSizeY) / 2.0);
            this.thumbTop = (int)(n7 + (max - this.thumbHeight) / 2.0);
            this.positionThumb(false);
            this.track.resizeRelocate((int)(this.trackStart - n5), n8, (int)(this.trackLength + n5 + n5), snapSizeY);
            if (this.showTickMarks) {
                this.tickLine.setLayoutX(this.trackStart);
                this.tickLine.setLayoutY(n8 + snapSizeY + this.trackToTickGap);
                this.tickLine.resize(this.trackLength, n6);
                this.tickLine.requestAxisLayout();
            }
            else {
                if (this.tickLine != null) {
                    this.tickLine.resize(0.0, 0.0);
                    this.tickLine.requestAxisLayout();
                }
                this.tickLine = null;
            }
        }
        else {
            final double n9 = this.showTickMarks ? this.tickLine.prefWidth(-1.0) : 0.0;
            final double snapSizeX = this.snapSizeX(this.track.prefWidth(-1.0));
            final double max2 = Math.max(snapSizeX, this.thumbWidth);
            final double n10 = n + (n3 - (max2 + (this.showTickMarks ? (this.trackToTickGap + n9) : 0.0))) / 2.0;
            this.trackLength = this.snapSizeY(n4 - this.thumbHeight);
            this.trackStart = this.snapPositionY(n2 + this.thumbHeight / 2.0);
            final double n11 = (int)(n10 + (max2 - snapSizeX) / 2.0);
            this.thumbLeft = (int)(n10 + (max2 - this.thumbWidth) / 2.0);
            this.positionThumb(false);
            this.track.resizeRelocate(n11, (int)(this.trackStart - n5), snapSizeX, (int)(this.trackLength + n5 + n5));
            if (this.showTickMarks) {
                this.tickLine.setLayoutX(n11 + snapSizeX + this.trackToTickGap);
                this.tickLine.setLayoutY(this.trackStart);
                this.tickLine.resize(n9, this.trackLength);
                this.tickLine.requestAxisLayout();
            }
            else {
                if (this.tickLine != null) {
                    this.tickLine.resize(0.0, 0.0);
                    this.tickLine.requestAxisLayout();
                }
                this.tickLine = null;
            }
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
            return n5 + this.minTrackLength() + this.thumb.minWidth(-1.0) + n3;
        }
        return n5 + this.thumb.prefWidth(-1.0) + n3;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
            return n2 + this.thumb.prefHeight(-1.0) + (this.showTickMarks ? (this.tickLine.prefHeight(-1.0) + this.trackToTickGap) : 0.0) + n4;
        }
        return n2 + this.minTrackLength() + this.thumb.prefHeight(-1.0) + n4;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.getSkinnable().getOrientation() != Orientation.HORIZONTAL) {
            return n5 + Math.max(this.thumb.prefWidth(-1.0), this.track.prefWidth(-1.0)) + (this.showTickMarks ? (this.tickLine.prefWidth(-1.0) + this.trackToTickGap) : 0.0) + n3;
        }
        if (this.showTickMarks) {
            return Math.max(140.0, this.tickLine.prefWidth(-1.0));
        }
        return 140.0;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
            return n2 + Math.max(this.thumb.prefHeight(-1.0), this.track.prefHeight(-1.0)) + (this.showTickMarks ? (this.trackToTickGap + this.tickLine.prefHeight(-1.0)) : 0.0) + n4;
        }
        if (this.showTickMarks) {
            return Math.max(140.0, this.tickLine.prefHeight(-1.0));
        }
        return 140.0;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
            return Double.MAX_VALUE;
        }
        return this.getSkinnable().prefWidth(-1.0);
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
            return this.getSkinnable().prefHeight(n);
        }
        return Double.MAX_VALUE;
    }
    
    private void initialize() {
        this.thumb = new StackPane() {
            @Override
            public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
                switch (accessibleAttribute) {
                    case VALUE: {
                        return SliderSkin.this.getSkinnable().getValue();
                    }
                    default: {
                        return super.queryAccessibleAttribute(accessibleAttribute, array);
                    }
                }
            }
        };
        this.thumb.getStyleClass().setAll("thumb");
        this.thumb.setAccessibleRole(AccessibleRole.THUMB);
        this.track = new StackPane();
        this.track.getStyleClass().setAll("track");
        this.getChildren().clear();
        this.getChildren().addAll(this.track, this.thumb);
        this.setShowTickMarks(this.getSkinnable().isShowTickMarks(), this.getSkinnable().isShowTickLabels());
        this.track.setOnMousePressed(mouseEvent -> {
            if (!this.thumb.isPressed()) {
                this.trackClicked = true;
                if (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
                    this.behavior.trackPress(mouseEvent, mouseEvent.getX() / this.trackLength);
                }
                else {
                    this.behavior.trackPress(mouseEvent, mouseEvent.getY() / this.trackLength);
                }
                this.trackClicked = false;
            }
            return;
        });
        this.track.setOnMouseDragged(mouseEvent2 -> {
            if (!this.thumb.isPressed()) {
                if (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
                    this.behavior.trackPress(mouseEvent2, mouseEvent2.getX() / this.trackLength);
                }
                else {
                    this.behavior.trackPress(mouseEvent2, mouseEvent2.getY() / this.trackLength);
                }
            }
            return;
        });
        this.thumb.setOnMousePressed(mouseEvent3 -> {
            this.behavior.thumbPressed(mouseEvent3, 0.0);
            this.dragStart = this.thumb.localToParent(mouseEvent3.getX(), mouseEvent3.getY());
            this.preDragThumbPos = (this.getSkinnable().getValue() - this.getSkinnable().getMin()) / (this.getSkinnable().getMax() - this.getSkinnable().getMin());
            return;
        });
        this.thumb.setOnMouseReleased(mouseEvent4 -> this.behavior.thumbReleased(mouseEvent4));
        final Point2D point2D;
        this.thumb.setOnMouseDragged(mouseEvent5 -> {
            this.thumb.localToParent(mouseEvent5.getX(), mouseEvent5.getY());
            this.behavior.thumbDragged(mouseEvent5, this.preDragThumbPos + ((this.getSkinnable().getOrientation() == Orientation.HORIZONTAL) ? (point2D.getX() - this.dragStart.getX()) : (-(point2D.getY() - this.dragStart.getY()))) / this.trackLength);
        });
    }
    
    private void setShowTickMarks(final boolean b, final boolean b2) {
        this.showTickMarks = (b || b2);
        final Slider slider = this.getSkinnable();
        if (this.showTickMarks) {
            if (this.tickLine == null) {
                (this.tickLine = new NumberAxis()).setAutoRanging(false);
                this.tickLine.setSide((slider.getOrientation() == Orientation.VERTICAL) ? Side.RIGHT : ((slider.getOrientation() == null) ? Side.RIGHT : Side.BOTTOM));
                this.tickLine.setUpperBound(slider.getMax());
                this.tickLine.setLowerBound(slider.getMin());
                this.tickLine.setTickUnit(slider.getMajorTickUnit());
                this.tickLine.setTickMarkVisible(b);
                this.tickLine.setTickLabelsVisible(b2);
                this.tickLine.setMinorTickVisible(b);
                this.tickLine.setMinorTickCount(Math.max(slider.getMinorTickCount(), 0) + 1);
                if (slider.getLabelFormatter() != null) {
                    this.tickLine.setTickLabelFormatter(this.stringConverterWrapper);
                }
                this.getChildren().clear();
                this.getChildren().addAll(this.tickLine, this.track, this.thumb);
            }
            else {
                this.tickLine.setTickLabelsVisible(b2);
                this.tickLine.setTickMarkVisible(b);
                this.tickLine.setMinorTickVisible(b);
            }
        }
        else {
            this.getChildren().clear();
            this.getChildren().addAll(this.track, this.thumb);
        }
        this.getSkinnable().requestLayout();
    }
    
    void positionThumb(final boolean b) {
        final Slider slider = this.getSkinnable();
        if (slider.getValue() > slider.getMax()) {
            return;
        }
        final boolean b2 = slider.getOrientation() == Orientation.HORIZONTAL;
        final double layoutX = b2 ? (this.trackStart + (this.trackLength * ((slider.getValue() - slider.getMin()) / (slider.getMax() - slider.getMin())) - this.thumbWidth / 2.0)) : this.thumbLeft;
        final double layoutY = b2 ? this.thumbTop : (this.snappedTopInset() + this.trackLength - this.trackLength * ((slider.getValue() - slider.getMin()) / (slider.getMax() - slider.getMin())));
        if (b) {
            new Transition() {
                final /* synthetic */ double val$startX = SliderSkin.this.thumb.getLayoutX();
                final /* synthetic */ double val$startY = SliderSkin.this.thumb.getLayoutY();
                
                {
                    this.setCycleDuration(Duration.millis(200.0));
                }
                
                @Override
                protected void interpolate(final double n) {
                    if (!Double.isNaN(this.val$startX)) {
                        SliderSkin.this.thumb.setLayoutX(this.val$startX + n * (layoutX - this.val$startX));
                    }
                    if (!Double.isNaN(this.val$startY)) {
                        SliderSkin.this.thumb.setLayoutY(this.val$startY + n * (layoutY - this.val$startY));
                    }
                }
            }.play();
        }
        else {
            this.thumb.setLayoutX(layoutX);
            this.thumb.setLayoutY(layoutY);
        }
    }
    
    double minTrackLength() {
        return 2.0 * this.thumb.prefWidth(-1.0);
    }
}
