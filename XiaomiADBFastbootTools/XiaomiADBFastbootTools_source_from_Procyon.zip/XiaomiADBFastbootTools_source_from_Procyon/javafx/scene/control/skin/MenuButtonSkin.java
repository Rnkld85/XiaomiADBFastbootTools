// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.event.Event;
import javafx.stage.WindowEvent;
import javafx.event.ActionEvent;
import com.sun.javafx.scene.control.behavior.MenuButtonBehaviorBase;
import javafx.scene.AccessibleAttribute;
import javafx.scene.Node;
import com.sun.javafx.scene.control.ContextMenuContent;
import com.sun.javafx.scene.control.behavior.MenuButtonBehavior;
import javafx.scene.control.MenuButton;

public class MenuButtonSkin extends MenuButtonSkinBase<MenuButton>
{
    static final String AUTOHIDE = "autoHide";
    private final MenuButtonBehavior behavior;
    
    public MenuButtonSkin(final MenuButton labelFor) {
        super(labelFor);
        this.behavior = new MenuButtonBehavior(labelFor);
        final MenuButton menuButton;
        this.popup.setOnAutoHide(p0 -> {
            menuButton = this.getSkinnable();
            if (!menuButton.getProperties().containsKey("autoHide")) {
                menuButton.getProperties().put("autoHide", Boolean.TRUE);
            }
            return;
        });
        ContextMenuContent contextMenuContent;
        this.popup.setOnShown(p0 -> {
            if (this.requestFocusOnFirstMenuItem) {
                this.requestFocusOnFirstMenuItem();
                this.requestFocusOnFirstMenuItem = false;
            }
            else {
                contextMenuContent = (ContextMenuContent)this.popup.getSkin().getNode();
                if (contextMenuContent != null) {
                    contextMenuContent.requestFocus();
                }
            }
            return;
        });
        if (labelFor.getOnAction() == null) {
            labelFor.setOnAction(p1 -> labelFor.show());
        }
        this.label.setLabelFor(labelFor);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    MenuButtonBehavior getBehavior() {
        return this.behavior;
    }
    
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case MNEMONIC: {
                return this.label.queryAccessibleAttribute(AccessibleAttribute.MNEMONIC, new Object[0]);
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
}
