// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.control.Skin;
import java.util.Iterator;
import javafx.beans.value.ObservableValue;
import java.util.List;
import javafx.scene.Node;
import java.util.Collection;
import com.sun.javafx.scene.control.behavior.AccordionBehavior;
import java.util.HashMap;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.beans.value.ChangeListener;
import java.util.Map;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.TitledPane;
import javafx.scene.control.Accordion;
import javafx.scene.control.SkinBase;

public class AccordionSkin extends SkinBase<Accordion>
{
    private TitledPane firstTitledPane;
    private Rectangle clipRect;
    private boolean forceRelayout;
    private boolean relayout;
    private double previousHeight;
    private TitledPane expandedPane;
    private TitledPane previousPane;
    private Map<TitledPane, ChangeListener<Boolean>> listeners;
    private final BehaviorBase<Accordion> behavior;
    
    public AccordionSkin(final Accordion accordion) {
        super(accordion);
        this.forceRelayout = false;
        this.relayout = false;
        this.previousHeight = 0.0;
        this.expandedPane = null;
        this.previousPane = null;
        this.listeners = new HashMap<TitledPane, ChangeListener<Boolean>>();
        this.behavior = new AccordionBehavior(accordion);
        accordion.getPanes().addListener(change -> {
            if (this.firstTitledPane != null) {
                this.firstTitledPane.getStyleClass().remove("first-titled-pane");
            }
            if (!accordion.getPanes().isEmpty()) {
                this.firstTitledPane = accordion.getPanes().get(0);
                this.firstTitledPane.getStyleClass().add("first-titled-pane");
            }
            this.getChildren().setAll(accordion.getPanes());
            while (change.next()) {
                this.removeTitledPaneListeners(change.getRemoved());
                this.initTitledPaneListeners(change.getAddedSubList());
            }
            this.forceRelayout = true;
            return;
        });
        if (!accordion.getPanes().isEmpty()) {
            this.firstTitledPane = accordion.getPanes().get(0);
            this.firstTitledPane.getStyleClass().add("first-titled-pane");
        }
        this.clipRect = new Rectangle(accordion.getWidth(), accordion.getHeight());
        this.getSkinnable().setClip(this.clipRect);
        this.initTitledPaneListeners(accordion.getPanes());
        this.getChildren().setAll(accordion.getPanes());
        this.getSkinnable().requestLayout();
        this.registerChangeListener(this.getSkinnable().widthProperty(), p0 -> this.clipRect.setWidth(this.getSkinnable().getWidth()));
        this.registerChangeListener(this.getSkinnable().heightProperty(), p0 -> {
            this.clipRect.setHeight(this.getSkinnable().getHeight());
            this.relayout = true;
        });
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        if (this.expandedPane != null) {
            n6 += this.expandedPane.minHeight(n);
        }
        if (this.previousPane != null && !this.previousPane.equals(this.expandedPane)) {
            n6 += this.previousPane.minHeight(n);
        }
        for (final Node node : this.getChildren()) {
            final TitledPane titledPane = (TitledPane)node;
            if (!titledPane.equals(this.expandedPane) && !titledPane.equals(this.previousPane)) {
                final Skin<?> skin = ((TitledPane)node).getSkin();
                if (skin instanceof TitledPaneSkin) {
                    n6 += ((TitledPaneSkin)skin).getTitleRegionSize(n);
                }
                else {
                    n6 += titledPane.minHeight(n);
                }
            }
        }
        return n6 + n2 + n4;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        if (this.expandedPane != null) {
            n6 += this.expandedPane.prefHeight(n);
        }
        if (this.previousPane != null && !this.previousPane.equals(this.expandedPane)) {
            n6 += this.previousPane.prefHeight(n);
        }
        for (final Node node : this.getChildren()) {
            final TitledPane titledPane = (TitledPane)node;
            if (!titledPane.equals(this.expandedPane) && !titledPane.equals(this.previousPane)) {
                final Skin<?> skin = ((TitledPane)node).getSkin();
                if (skin instanceof TitledPaneSkin) {
                    n6 += ((TitledPaneSkin)skin).getTitleRegionSize(n);
                }
                else {
                    n6 += titledPane.prefHeight(n);
                }
            }
        }
        return n6 + n2 + n4;
    }
    
    @Override
    protected void layoutChildren(final double n, double n2, final double n3, final double previousHeight) {
        final boolean b = this.forceRelayout || (this.relayout && this.previousHeight != previousHeight);
        this.forceRelayout = false;
        this.previousHeight = previousHeight;
        double n4 = 0.0;
        for (final TitledPane titledPane : this.getSkinnable().getPanes()) {
            if (!titledPane.equals(this.expandedPane)) {
                n4 += this.snapSizeY(((TitledPaneSkin)titledPane.getSkin()).getTitleRegionSize(n3));
            }
        }
        final double maxTitledPaneHeightForAccordion = previousHeight - n4;
        for (final TitledPane titledPane2 : this.getSkinnable().getPanes()) {
            final Skin<?> skin = titledPane2.getSkin();
            double n5;
            if (skin instanceof TitledPaneSkin) {
                ((TitledPaneSkin)skin).setMaxTitledPaneHeightForAccordion(maxTitledPaneHeightForAccordion);
                n5 = this.snapSizeY(((TitledPaneSkin)skin).getTitledPaneHeightForAccordion());
            }
            else {
                n5 = titledPane2.prefHeight(n3);
            }
            titledPane2.resize(n3, n5);
            boolean b2 = true;
            if (!b && this.previousPane != null && this.expandedPane != null) {
                final ObservableList<TitledPane> panes = this.getSkinnable().getPanes();
                final int index = panes.indexOf(this.previousPane);
                final int index2 = panes.indexOf(this.expandedPane);
                final int index3 = panes.indexOf(titledPane2);
                if (index < index2) {
                    if (index3 <= index2) {
                        titledPane2.relocate(n, n2);
                        n2 += n5;
                        b2 = false;
                    }
                }
                else if (index > index2) {
                    if (index3 <= index) {
                        titledPane2.relocate(n, n2);
                        n2 += n5;
                        b2 = false;
                    }
                }
                else {
                    titledPane2.relocate(n, n2);
                    n2 += n5;
                    b2 = false;
                }
            }
            if (b2) {
                titledPane2.relocate(n, n2);
                n2 += n5;
            }
        }
    }
    
    private void initTitledPaneListeners(final List<? extends TitledPane> list) {
        for (final TitledPane expandedPane : list) {
            expandedPane.setExpanded(expandedPane == this.getSkinnable().getExpandedPane());
            if (expandedPane.isExpanded()) {
                this.expandedPane = expandedPane;
            }
            final ChangeListener<Boolean> expandedPropertyListener = this.expandedPropertyListener(expandedPane);
            expandedPane.expandedProperty().addListener(expandedPropertyListener);
            this.listeners.put(expandedPane, expandedPropertyListener);
        }
    }
    
    private void removeTitledPaneListeners(final List<? extends TitledPane> list) {
        for (final TitledPane titledPane : list) {
            if (this.listeners.containsKey(titledPane)) {
                titledPane.expandedProperty().removeListener(this.listeners.get(titledPane));
                this.listeners.remove(titledPane);
            }
        }
    }
    
    private ChangeListener<Boolean> expandedPropertyListener(final TitledPane expandedPane) {
        final Accordion accordion;
        return (p1, p2, b) -> {
            this.previousPane = this.expandedPane;
            accordion = this.getSkinnable();
            if (b) {
                if (this.expandedPane != null) {
                    this.expandedPane.setExpanded(false);
                }
                if (expandedPane != null) {
                    accordion.setExpandedPane(expandedPane);
                }
                this.expandedPane = accordion.getExpandedPane();
            }
            else {
                accordion.setExpandedPane(this.expandedPane = null);
            }
        };
    }
}
