// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.control.IndexRange;
import com.sun.javafx.scene.control.behavior.TextInputControlBehavior;
import javafx.scene.AccessibleAttribute;
import javafx.geometry.HPos;
import java.util.Collection;
import java.util.List;
import javafx.geometry.Bounds;
import javafx.geometry.Rectangle2D;
import com.sun.javafx.tk.FontMetrics;
import javafx.event.Event;
import javafx.scene.text.HitInfo;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import javafx.beans.binding.BooleanBinding;
import javafx.scene.shape.PathElement;
import javafx.beans.value.ObservableNumberValue;
import javafx.scene.paint.Paint;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.binding.StringBinding;
import javafx.scene.Node;
import javafx.beans.value.ObservableValue;
import javafx.beans.Observable;
import javafx.beans.binding.DoubleBinding;
import com.sun.javafx.scene.control.behavior.PasswordFieldBehavior;
import javafx.scene.control.PasswordField;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ObservableDoubleValue;
import javafx.beans.property.DoubleProperty;
import javafx.beans.value.ObservableBooleanValue;
import javafx.scene.shape.Path;
import javafx.scene.text.Text;
import javafx.scene.shape.Rectangle;
import javafx.scene.Group;
import javafx.scene.layout.Pane;
import com.sun.javafx.scene.control.behavior.TextFieldBehavior;
import javafx.scene.control.TextField;

public class TextFieldSkin extends TextInputControlSkin<TextField>
{
    private final TextFieldBehavior behavior;
    private Pane textGroup;
    private Group handleGroup;
    private Rectangle clip;
    private Text textNode;
    private Text promptNode;
    private Path selectionHighlightPath;
    private Path characterBoundingPath;
    private ObservableBooleanValue usePromptText;
    private DoubleProperty textTranslateX;
    private double caretWidth;
    private ObservableDoubleValue textRight;
    private double pressX;
    private double pressY;
    static final char BULLET = '\u25cf';
    
    public TextFieldSkin(final TextField textField) {
        super(textField);
        this.textGroup = new Pane();
        this.clip = new Rectangle();
        this.textNode = new Text();
        this.selectionHighlightPath = new Path();
        this.characterBoundingPath = new Path();
        this.textTranslateX = new SimpleDoubleProperty(this, "textTranslateX");
        (this.behavior = ((textField instanceof PasswordField) ? new PasswordFieldBehavior((PasswordField)textField) : new TextFieldBehavior(textField))).setTextFieldSkin(this);
        textField.caretPositionProperty().addListener((p1, p2, p3) -> {
            if (textField.getWidth() > 0.0) {
                this.updateTextNodeCaretPos(textField.getCaretPosition());
                if (!this.isForwardBias()) {
                    this.setForwardBias(true);
                }
                this.updateCaretOff();
            }
            return;
        });
        this.forwardBiasProperty().addListener(p1 -> {
            if (textField.getWidth() > 0.0) {
                this.updateTextNodeCaretPos(textField.getCaretPosition());
                this.updateCaretOff();
            }
            return;
        });
        this.textRight = new DoubleBinding() {
            {
                this.bind(TextFieldSkin.this.textGroup.widthProperty());
            }
            
            @Override
            protected double computeValue() {
                return TextFieldSkin.this.textGroup.getWidth();
            }
        };
        this.clip.setSmooth(false);
        this.clip.setX(0.0);
        this.clip.widthProperty().bind(this.textGroup.widthProperty());
        this.clip.heightProperty().bind(this.textGroup.heightProperty());
        this.textGroup.setClip(this.clip);
        this.textGroup.getChildren().addAll(this.selectionHighlightPath, this.textNode, new Group(new Node[] { this.caretPath }));
        this.getChildren().add(this.textGroup);
        if (TextFieldSkin.SHOW_HANDLES) {
            (this.handleGroup = new Group()).setManaged(false);
            this.handleGroup.getChildren().addAll(this.caretHandle, this.selectionHandle1, this.selectionHandle2);
            this.getChildren().add(this.handleGroup);
        }
        this.textNode.setManaged(false);
        this.textNode.getStyleClass().add("text");
        this.textNode.fontProperty().bind((ObservableValue<?>)textField.fontProperty());
        this.textNode.layoutXProperty().bind(this.textTranslateX);
        this.textNode.textProperty().bind(new StringBinding() {
            {
                this.bind(textField.textProperty());
            }
            
            @Override
            protected String computeValue() {
                return TextFieldSkin.this.maskText(textField.textProperty().getValueSafe());
            }
        });
        this.textNode.fillProperty().bind((ObservableValue<?>)this.textFillProperty());
        this.textNode.selectionFillProperty().bind((ObservableValue<?>)new ObjectBinding<Paint>() {
            {
                this.bind(TextFieldSkin.this.highlightTextFillProperty(), TextFieldSkin.this.textFillProperty(), textField.focusedProperty());
            }
            
            @Override
            protected Paint computeValue() {
                return textField.isFocused() ? TextFieldSkin.this.highlightTextFillProperty().get() : TextFieldSkin.this.textFillProperty().get();
            }
        });
        this.updateTextNodeCaretPos(textField.getCaretPosition());
        textField.selectionProperty().addListener(p0 -> this.updateSelection());
        this.selectionHighlightPath.setManaged(false);
        this.selectionHighlightPath.setStroke(null);
        this.selectionHighlightPath.layoutXProperty().bind(this.textTranslateX);
        this.selectionHighlightPath.visibleProperty().bind(textField.anchorProperty().isNotEqualTo(textField.caretPositionProperty()).and(textField.focusedProperty()));
        this.selectionHighlightPath.fillProperty().bind((ObservableValue<?>)this.highlightFillProperty());
        this.textNode.selectionShapeProperty().addListener(p0 -> this.updateSelection());
        this.caretPath.setManaged(false);
        this.caretPath.setStrokeWidth(1.0);
        this.caretPath.fillProperty().bind((ObservableValue<?>)this.textFillProperty());
        this.caretPath.strokeProperty().bind((ObservableValue<?>)this.textFillProperty());
        this.caretPath.opacityProperty().bind(new DoubleBinding() {
            {
                this.bind(TextFieldSkin.this.caretVisibleProperty());
            }
            
            @Override
            protected double computeValue() {
                return TextFieldSkin.this.caretVisibleProperty().get() ? 1.0 : 0.0;
            }
        });
        this.caretPath.layoutXProperty().bind(this.textTranslateX);
        this.textNode.caretShapeProperty().addListener(p1 -> {
            this.caretPath.getElements().setAll((PathElement[])this.textNode.caretShapeProperty().get());
            if (this.caretPath.getElements().size() == 0) {
                this.updateTextNodeCaretPos(textField.getCaretPosition());
            }
            else if (this.caretPath.getElements().size() != 4) {
                this.caretWidth = (double)Math.round(this.caretPath.getLayoutBounds().getWidth());
            }
            return;
        });
        textField.fontProperty().addListener(p1 -> {
            textField.requestLayout();
            this.getSkinnable().requestLayout();
            return;
        });
        this.registerChangeListener(textField.prefColumnCountProperty(), p0 -> this.getSkinnable().requestLayout());
        if (textField.isFocused()) {
            this.setCaretAnimating(true);
        }
        textField.alignmentProperty().addListener(p1 -> {
            if (textField.getWidth() > 0.0) {
                this.updateTextPos();
                this.updateCaretOff();
                textField.requestLayout();
            }
            return;
        });
        this.usePromptText = new BooleanBinding() {
            {
                this.bind(textField.textProperty(), textField.promptTextProperty(), TextFieldSkin.this.promptTextFillProperty());
            }
            
            @Override
            protected boolean computeValue() {
                final String text = textField.getText();
                final String promptText = textField.getPromptText();
                return (text == null || text.isEmpty()) && promptText != null && !promptText.isEmpty() && !TextFieldSkin.this.getPromptTextFill().equals(Color.TRANSPARENT);
            }
        };
        this.promptTextFillProperty().addListener(p0 -> this.updateTextPos());
        textField.textProperty().addListener(p0 -> {
            if (!this.behavior.isEditing()) {
                this.updateTextPos();
            }
            return;
        });
        if (this.usePromptText.get()) {
            this.createPromptNode();
        }
        this.usePromptText.addListener(p1 -> {
            this.createPromptNode();
            textField.requestLayout();
            return;
        });
        if (TextFieldSkin.SHOW_HANDLES) {
            this.selectionHandle1.setRotate(180.0);
            final EventHandler<? super MouseEvent> onMousePressed = mouseEvent -> {
                this.pressX = mouseEvent.getX();
                this.pressY = mouseEvent.getY();
                mouseEvent.consume();
                return;
            };
            this.caretHandle.setOnMousePressed(onMousePressed);
            this.selectionHandle1.setOnMousePressed(onMousePressed);
            this.selectionHandle2.setOnMousePressed(onMousePressed);
            this.caretHandle.setOnMouseDragged(mouseEvent2 -> {
                this.positionCaret(this.textNode.hitTest(new Point2D(this.caretHandle.getLayoutX() + mouseEvent2.getX() + this.pressX - this.textNode.getLayoutX(), this.caretHandle.getLayoutY() + mouseEvent2.getY() - this.pressY - 6.0)), false);
                mouseEvent2.consume();
                return;
            });
            this.selectionHandle1.setOnMouseDragged(new EventHandler<MouseEvent>() {
                @Override
                public void handle(final MouseEvent mouseEvent) {
                    final TextField textField = TextFieldSkin.this.getSkinnable();
                    final Point2D localToScene = TextFieldSkin.this.textNode.localToScene(0.0, 0.0);
                    final HitInfo hitTest = TextFieldSkin.this.textNode.hitTest(new Point2D(mouseEvent.getSceneX() - localToScene.getX() + 10.0 - TextFieldSkin.this.pressX + TextFieldSkin.this.selectionHandle1.getWidth() / 2.0, mouseEvent.getSceneY() - localToScene.getY() - TextFieldSkin.this.pressY - 6.0));
                    if (textField.getAnchor() < textField.getCaretPosition()) {
                        textField.selectRange(textField.getCaretPosition(), textField.getAnchor());
                    }
                    int n = hitTest.getInsertionIndex();
                    if (n >= 0) {
                        if (n >= textField.getAnchor() - 1) {
                            n = Math.max(0, textField.getAnchor() - 1);
                        }
                        TextFieldSkin.this.positionCaret(n, hitTest.isLeading(), true);
                    }
                    mouseEvent.consume();
                }
            });
            this.selectionHandle2.setOnMouseDragged(new EventHandler<MouseEvent>() {
                @Override
                public void handle(final MouseEvent mouseEvent) {
                    final TextField textField = TextFieldSkin.this.getSkinnable();
                    final Point2D localToScene = TextFieldSkin.this.textNode.localToScene(0.0, 0.0);
                    final HitInfo hitTest = TextFieldSkin.this.textNode.hitTest(new Point2D(mouseEvent.getSceneX() - localToScene.getX() + 10.0 - TextFieldSkin.this.pressX + TextFieldSkin.this.selectionHandle2.getWidth() / 2.0, mouseEvent.getSceneY() - localToScene.getY() - TextFieldSkin.this.pressY - 6.0));
                    if (textField.getAnchor() > textField.getCaretPosition()) {
                        textField.selectRange(textField.getCaretPosition(), textField.getAnchor());
                    }
                    int n = hitTest.getInsertionIndex();
                    if (n > 0) {
                        if (n <= textField.getAnchor()) {
                            n = Math.min(textField.getAnchor() + 1, textField.getLength());
                        }
                        TextFieldSkin.this.positionCaret(n, hitTest.isLeading(), true);
                    }
                    mouseEvent.consume();
                }
            });
        }
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().getPrefColumnCount() * (double)this.fontMetrics.get().getCharWidth('W') + n5 + n3;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computePrefHeight(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n2 + this.textNode.getLayoutBounds().getHeight() + n4;
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefHeight(n);
    }
    
    public double computeBaselineOffset(final double n, final double n2, final double n3, final double n4) {
        return n + this.textNode.getBaselineOffset();
    }
    
    public void replaceText(final int n, final int n2, final String s) {
        final double maxX = this.textNode.getBoundsInParent().getMaxX();
        final double n3 = this.caretPath.getLayoutBounds().getMaxX() + this.textTranslateX.get();
        this.getSkinnable().replaceText(n, n2, s);
        this.scrollAfterDelete(maxX, n3);
    }
    
    public void deleteChar(final boolean b) {
        final double maxX = this.textNode.getBoundsInParent().getMaxX();
        final double n = this.caretPath.getLayoutBounds().getMaxX() + this.textTranslateX.get();
        if (b) {
            if (!this.getSkinnable().deletePreviousChar()) {
                return;
            }
        }
        else if (!this.getSkinnable().deleteNextChar()) {
            return;
        }
        this.scrollAfterDelete(maxX, n);
    }
    
    public HitInfo getIndex(final double n, final double n2) {
        return this.textNode.hitTest(new Point2D(n - this.textTranslateX.get() - this.snappedLeftInset(), n2 - this.snappedTopInset()));
    }
    
    public void positionCaret(final HitInfo hitInfo, final boolean b) {
        this.positionCaret(hitInfo.getInsertionIndex(), hitInfo.isLeading(), b);
    }
    
    private void positionCaret(final int n, final boolean forwardBias, final boolean b) {
        final TextField textField = this.getSkinnable();
        if (b) {
            textField.selectPositionCaret(n);
        }
        else {
            textField.positionCaret(n);
        }
        this.setForwardBias(forwardBias);
    }
    
    @Override
    public Rectangle2D getCharacterBounds(final int n) {
        double n2;
        double minY;
        double n3;
        double maxY;
        if (n == this.textNode.getText().length()) {
            final Bounds boundsInLocal = this.textNode.getBoundsInLocal();
            n2 = boundsInLocal.getMaxX();
            minY = 0.0;
            n3 = 0.0;
            maxY = boundsInLocal.getMaxY();
        }
        else {
            this.characterBoundingPath.getElements().clear();
            this.characterBoundingPath.getElements().addAll(this.textNode.rangeShape(n, n + 1));
            this.characterBoundingPath.setLayoutX(this.textNode.getLayoutX());
            this.characterBoundingPath.setLayoutY(this.textNode.getLayoutY());
            final Bounds boundsInLocal2 = this.characterBoundingPath.getBoundsInLocal();
            n2 = boundsInLocal2.getMinX();
            minY = boundsInLocal2.getMinY();
            n3 = (boundsInLocal2.isEmpty() ? 0.0 : boundsInLocal2.getWidth());
            maxY = (boundsInLocal2.isEmpty() ? 0.0 : boundsInLocal2.getHeight());
        }
        final Bounds boundsInParent = this.textGroup.getBoundsInParent();
        return new Rectangle2D(n2 + boundsInParent.getMinX() + this.textTranslateX.get(), minY + boundsInParent.getMinY(), n3, maxY);
    }
    
    @Override
    protected PathElement[] getUnderlineShape(final int n, final int n2) {
        return this.textNode.underlineShape(n, n2);
    }
    
    @Override
    protected PathElement[] getRangeShape(final int n, final int n2) {
        return this.textNode.rangeShape(n, n2);
    }
    
    @Override
    protected void addHighlight(final List<? extends Node> list, final int n) {
        this.textGroup.getChildren().addAll((Collection<?>)list);
    }
    
    @Override
    protected void removeHighlight(final List<? extends Node> list) {
        this.textGroup.getChildren().removeAll(list);
    }
    
    @Override
    public void moveCaret(final TextUnit textUnit, final Direction direction, final boolean b) {
        switch (textUnit) {
            case CHARACTER: {
                switch (direction) {
                    case LEFT:
                    case RIGHT: {
                        this.nextCharacterVisually(direction == Direction.RIGHT);
                        return;
                    }
                    default: {
                        throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/skin/TextInputControlSkin$Direction;)Ljava/lang/String;, direction));
                    }
                }
                break;
            }
            default: {
                throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/skin/TextInputControlSkin$TextUnit;)Ljava/lang/String;, textUnit));
            }
        }
    }
    
    private void nextCharacterVisually(boolean b) {
        if (this.isRTL()) {
            b = !b;
        }
        Bounds bounds = this.caretPath.getLayoutBounds();
        if (this.caretPath.getElements().size() == 4) {
            bounds = new Path(new PathElement[] { this.caretPath.getElements().get(0), this.caretPath.getElements().get(1) }).getLayoutBounds();
        }
        final HitInfo hitTest = this.textNode.hitTest(new Point2D(b ? bounds.getMaxX() : bounds.getMinX(), (bounds.getMinY() + bounds.getMaxY()) / 2.0));
        boolean leading = hitTest.isLeading();
        final Path path = new Path(this.textNode.rangeShape(hitTest.getCharIndex(), hitTest.getCharIndex() + 1));
        if ((b && path.getLayoutBounds().getMaxX() > bounds.getMaxX()) || (!b && path.getLayoutBounds().getMinX() < bounds.getMinX())) {
            leading = !leading;
        }
        this.positionCaret(hitTest.getInsertionIndex(), leading, false);
    }
    
    @Override
    protected void layoutChildren(final double n, final double layoutY, final double n2, final double n3) {
        super.layoutChildren(n, layoutY, n2, n3);
        if (this.textNode != null) {
            final Bounds layoutBounds = this.textNode.getLayoutBounds();
            final double baselineOffset = this.textNode.getBaselineOffset();
            final double n4 = layoutBounds.getHeight() - baselineOffset;
            double n5 = 0.0;
            switch (this.getSkinnable().getAlignment().getVpos()) {
                case TOP: {
                    n5 = baselineOffset;
                    break;
                }
                case CENTER: {
                    n5 = (baselineOffset + this.textGroup.getHeight() - n4) / 2.0;
                    break;
                }
                default: {
                    n5 = this.textGroup.getHeight() - n4;
                    break;
                }
            }
            this.textNode.setY(n5);
            if (this.promptNode != null) {
                this.promptNode.setY(n5);
            }
            if (this.getSkinnable().getWidth() > 0.0) {
                this.updateTextPos();
                this.updateCaretOff();
            }
        }
        if (TextFieldSkin.SHOW_HANDLES) {
            this.handleGroup.setLayoutX(n + this.caretWidth / 2.0);
            this.handleGroup.setLayoutY(layoutY);
            this.selectionHandle1.resize(this.selectionHandle1.prefWidth(-1.0), this.selectionHandle1.prefHeight(-1.0));
            this.selectionHandle2.resize(this.selectionHandle2.prefWidth(-1.0), this.selectionHandle2.prefHeight(-1.0));
            this.caretHandle.resize(this.caretHandle.prefWidth(-1.0), this.caretHandle.prefHeight(-1.0));
            final Bounds boundsInParent = this.caretPath.getBoundsInParent();
            this.caretHandle.setLayoutY(boundsInParent.getMaxY() - 1.0);
            this.selectionHandle1.setLayoutY(boundsInParent.getMinY() - this.selectionHandle1.getHeight() + 1.0);
            this.selectionHandle2.setLayoutY(boundsInParent.getMaxY() - 1.0);
        }
    }
    
    private HPos getHAlignment() {
        return this.getSkinnable().getAlignment().getHpos();
    }
    
    @Override
    public Point2D getMenuPosition() {
        Point2D menuPosition = super.getMenuPosition();
        if (menuPosition != null) {
            menuPosition = new Point2D(Math.max(0.0, menuPosition.getX() - this.textNode.getLayoutX() - this.snappedLeftInset() + this.textTranslateX.get()), Math.max(0.0, menuPosition.getY() - this.textNode.getLayoutY() - this.snappedTopInset()));
        }
        return menuPosition;
    }
    
    @Override
    protected String maskText(final String s) {
        if (this.getSkinnable() instanceof PasswordField) {
            final int length = s.length();
            final StringBuilder sb = new StringBuilder(length);
            for (int i = 0; i < length; ++i) {
                sb.append('\u25cf');
            }
            return sb.toString();
        }
        return s;
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case BOUNDS_FOR_RANGE:
            case OFFSET_AT_POINT: {
                return this.textNode.queryAccessibleAttribute(accessibleAttribute, array);
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    TextInputControlBehavior getBehavior() {
        return this.behavior;
    }
    
    private void updateTextNodeCaretPos(final int caretPosition) {
        if (caretPosition == 0 || this.isForwardBias()) {
            this.textNode.setCaretPosition(caretPosition);
        }
        else {
            this.textNode.setCaretPosition(caretPosition - 1);
        }
        this.textNode.caretBiasProperty().set(this.isForwardBias());
    }
    
    private void createPromptNode() {
        if (this.promptNode != null || !this.usePromptText.get()) {
            return;
        }
        this.promptNode = new Text();
        this.textGroup.getChildren().add(0, this.promptNode);
        this.promptNode.setManaged(false);
        this.promptNode.getStyleClass().add("text");
        this.promptNode.visibleProperty().bind(this.usePromptText);
        this.promptNode.fontProperty().bind((ObservableValue<?>)this.getSkinnable().fontProperty());
        this.promptNode.textProperty().bind(this.getSkinnable().promptTextProperty());
        this.promptNode.fillProperty().bind((ObservableValue<?>)this.promptTextFillProperty());
        this.updateSelection();
    }
    
    private void updateSelection() {
        final TextField textField = this.getSkinnable();
        final IndexRange selection = textField.getSelection();
        if (selection == null || selection.getLength() == 0) {
            this.textNode.selectionStartProperty().set(-1);
            this.textNode.selectionEndProperty().set(-1);
        }
        else {
            this.textNode.selectionStartProperty().set(selection.getStart());
            this.textNode.selectionEndProperty().set(selection.getStart());
            this.textNode.selectionEndProperty().set(selection.getEnd());
        }
        final PathElement[] all = this.textNode.selectionShapeProperty().get();
        if (all == null) {
            this.selectionHighlightPath.getElements().clear();
        }
        else {
            this.selectionHighlightPath.getElements().setAll(all);
        }
        if (TextFieldSkin.SHOW_HANDLES && selection != null && selection.getLength() > 0) {
            final int caretPosition = textField.getCaretPosition();
            final int anchor = textField.getAnchor();
            this.updateTextNodeCaretPos(anchor);
            final Bounds boundsInParent = this.caretPath.getBoundsInParent();
            if (caretPosition < anchor) {
                this.selectionHandle2.setLayoutX(boundsInParent.getMinX() - this.selectionHandle2.getWidth() / 2.0);
            }
            else {
                this.selectionHandle1.setLayoutX(boundsInParent.getMinX() - this.selectionHandle1.getWidth() / 2.0);
            }
            this.updateTextNodeCaretPos(caretPosition);
            final Bounds boundsInParent2 = this.caretPath.getBoundsInParent();
            if (caretPosition < anchor) {
                this.selectionHandle1.setLayoutX(boundsInParent2.getMinX() - this.selectionHandle1.getWidth() / 2.0);
            }
            else {
                this.selectionHandle2.setLayoutX(boundsInParent2.getMinX() - this.selectionHandle2.getWidth() / 2.0);
            }
        }
    }
    
    private void updateTextPos() {
        final double value = this.textTranslateX.get();
        final double width = this.textNode.getLayoutBounds().getWidth();
        switch (this.getHAlignment()) {
            case CENTER: {
                final double n = this.textRight.get() / 2.0;
                double layoutX;
                if (this.usePromptText.get()) {
                    layoutX = n - this.promptNode.getLayoutBounds().getWidth() / 2.0;
                    this.promptNode.setLayoutX(layoutX);
                }
                else {
                    layoutX = n - width / 2.0;
                }
                if (layoutX + width <= this.textRight.get()) {
                    this.textTranslateX.set(layoutX);
                    break;
                }
                break;
            }
            case RIGHT: {
                final double n2 = this.textRight.get() - width - this.caretWidth / 2.0;
                if (n2 > value || n2 > 0.0) {
                    this.textTranslateX.set(n2);
                }
                if (this.usePromptText.get()) {
                    this.promptNode.setLayoutX(this.textRight.get() - this.promptNode.getLayoutBounds().getWidth() - this.caretWidth / 2.0);
                    break;
                }
                break;
            }
            default: {
                final double n3 = this.caretWidth / 2.0;
                if (n3 < value || n3 + width <= this.textRight.get()) {
                    this.textTranslateX.set(n3);
                }
                if (this.usePromptText.get()) {
                    this.promptNode.layoutXProperty().set(n3);
                    break;
                }
                break;
            }
        }
    }
    
    private void updateCaretOff() {
        double n = 0.0;
        final double n2 = this.caretPath.getLayoutBounds().getMinX() + this.textTranslateX.get();
        if (n2 < 0.0) {
            n = n2;
        }
        else if (n2 > this.textRight.get() - this.caretWidth) {
            n = n2 - (this.textRight.get() - this.caretWidth);
        }
        switch (this.getHAlignment()) {
            case CENTER: {
                this.textTranslateX.set(this.textTranslateX.get() - n);
                break;
            }
            case RIGHT: {
                this.textTranslateX.set(Math.max(this.textTranslateX.get() - n, this.textRight.get() - this.textNode.getLayoutBounds().getWidth() - this.caretWidth / 2.0));
                break;
            }
            default: {
                this.textTranslateX.set(Math.min(this.textTranslateX.get() - n, this.caretWidth / 2.0));
                break;
            }
        }
        if (TextFieldSkin.SHOW_HANDLES) {
            this.caretHandle.setLayoutX(n2 - this.caretHandle.getWidth() / 2.0);
        }
    }
    
    private void scrollAfterDelete(final double n, final double n2) {
        final Bounds localToParent = this.textNode.localToParent(this.textNode.getLayoutBounds());
        final Bounds boundsInParent = this.clip.getBoundsInParent();
        final Bounds layoutBounds = this.caretPath.getLayoutBounds();
        switch (this.getHAlignment()) {
            case RIGHT: {
                if (localToParent.getMaxX() > boundsInParent.getMaxX()) {
                    double n3 = n2 - layoutBounds.getMaxX() - this.textTranslateX.get();
                    if (localToParent.getMaxX() + n3 < boundsInParent.getMaxX()) {
                        if (n <= boundsInParent.getMaxX()) {
                            n3 = n - localToParent.getMaxX();
                        }
                        else {
                            n3 = boundsInParent.getMaxX() - localToParent.getMaxX();
                        }
                    }
                    this.textTranslateX.set(this.textTranslateX.get() + n3);
                    break;
                }
                this.updateTextPos();
                break;
            }
            default: {
                if (localToParent.getMinX() < boundsInParent.getMinX() + this.caretWidth / 2.0 && localToParent.getMaxX() <= boundsInParent.getMaxX()) {
                    double n4 = n2 - layoutBounds.getMaxX() - this.textTranslateX.get();
                    if (localToParent.getMaxX() + n4 < boundsInParent.getMaxX()) {
                        if (n <= boundsInParent.getMaxX()) {
                            n4 = n - localToParent.getMaxX();
                        }
                        else {
                            n4 = boundsInParent.getMaxX() - localToParent.getMaxX();
                        }
                    }
                    this.textTranslateX.set(this.textTranslateX.get() + n4);
                    break;
                }
                break;
            }
        }
        this.updateCaretOff();
    }
}
