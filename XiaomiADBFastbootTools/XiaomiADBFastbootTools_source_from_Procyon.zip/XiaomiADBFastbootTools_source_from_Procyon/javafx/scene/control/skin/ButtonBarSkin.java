// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.beans.Observable;
import javafx.collections.ListChangeListener;
import java.util.ArrayList;
import java.util.HashMap;
import javafx.scene.layout.Region;
import java.util.Map;
import javafx.scene.control.Button;
import javafx.collections.ObservableList;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Pane;
import javafx.collections.ObservableMap;
import java.util.Iterator;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import java.util.List;
import javafx.geometry.Pos;
import javafx.beans.InvalidationListener;
import javafx.scene.layout.HBox;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.SkinBase;

public class ButtonBarSkin extends SkinBase<ButtonBar>
{
    private static final double GAP_SIZE = 10.0;
    private static final String CATEGORIZED_TYPES = "LRHEYNXBIACO";
    private static final double DO_NOT_CHANGE_SIZE = Double.MAX_VALUE;
    private HBox layout;
    private InvalidationListener buttonDataListener;
    
    public ButtonBarSkin(final ButtonBar buttonBar) {
        super(buttonBar);
        this.buttonDataListener = (p0 -> this.layoutButtons());
        (this.layout = new HBox(10.0) {
            @Override
            protected void layoutChildren() {
                ButtonBarSkin.this.resizeButtons();
                super.layoutChildren();
            }
        }).setAlignment(Pos.CENTER);
        this.layout.getStyleClass().add("container");
        this.getChildren().add(this.layout);
        this.layoutButtons();
        this.updateButtonListeners(buttonBar.getButtons(), true);
        buttonBar.getButtons().addListener(change -> {
            while (change.next()) {
                this.updateButtonListeners(change.getRemoved(), false);
                this.updateButtonListeners(change.getAddedSubList(), true);
            }
            this.layoutButtons();
            return;
        });
        this.registerChangeListener(buttonBar.buttonOrderProperty(), p0 -> this.layoutButtons());
        this.registerChangeListener(buttonBar.buttonMinWidthProperty(), p0 -> this.resizeButtons());
    }
    
    private void updateButtonListeners(final List<? extends Node> list, final boolean b) {
        if (list != null) {
            final Iterator<? extends Node> iterator = list.iterator();
            while (iterator.hasNext()) {
                final ObservableMap<Object, Object> properties = ((Node)iterator.next()).getProperties();
                if (properties.containsKey("javafx.scene.control.ButtonBar.ButtonData")) {
                    final ObjectProperty objectProperty = properties.get("javafx.scene.control.ButtonBar.ButtonData");
                    if (objectProperty == null) {
                        continue;
                    }
                    if (b) {
                        objectProperty.addListener(this.buttonDataListener);
                    }
                    else {
                        objectProperty.removeListener(this.buttonDataListener);
                    }
                }
            }
        }
    }
    
    private void layoutButtons() {
        final ButtonBar buttonBar = this.getSkinnable();
        final ObservableList<Node> buttons = buttonBar.getButtons();
        final double buttonMinWidth = buttonBar.getButtonMinWidth();
        final String buttonOrder = this.getSkinnable().getButtonOrder();
        this.layout.getChildren().clear();
        if (buttonOrder == null) {
            throw new IllegalStateException("ButtonBar buttonOrder string can not be null");
        }
        if (buttonOrder.equals("")) {
            Spacer.DYNAMIC.add(this.layout, true);
            for (final Node node : buttons) {
                this.sizeButton(node, buttonMinWidth, Double.MAX_VALUE, Double.MAX_VALUE);
                this.layout.getChildren().add(node);
                HBox.setHgrow(node, Priority.NEVER);
            }
        }
        else {
            this.doButtonOrderLayout(buttonOrder);
        }
    }
    
    private void doButtonOrderLayout(final String s) {
        final ButtonBar buttonBar = this.getSkinnable();
        final ObservableList<Node> buttons = buttonBar.getButtons();
        final double buttonMinWidth = buttonBar.getButtonMinWidth();
        final Map<String, List<Node>> buildButtonMap = this.buildButtonMap(buttons);
        final char[] charArray = s.toCharArray();
        int n = 0;
        Spacer spacer = Spacer.NONE;
        for (int i = 0; i < charArray.length; ++i) {
            final char c = charArray[i];
            final boolean b = n <= 0 && n >= buttons.size() - 1;
            final boolean b2 = !this.layout.getChildren().isEmpty();
            if (c == '+') {
                spacer = spacer.replace(Spacer.DYNAMIC);
            }
            else if (c == '_' && b2) {
                spacer = spacer.replace(Spacer.FIXED);
            }
            else {
                final List<Node> list = buildButtonMap.get(String.valueOf(c).toUpperCase());
                if (list != null) {
                    spacer.add(this.layout, b);
                    for (final Node node : list) {
                        this.sizeButton(node, buttonMinWidth, Double.MAX_VALUE, Double.MAX_VALUE);
                        this.layout.getChildren().add(node);
                        HBox.setHgrow(node, Priority.NEVER);
                        ++n;
                    }
                    spacer = spacer.replace(Spacer.NONE);
                }
            }
        }
        boolean b3 = false;
        final int size = buttons.size();
        for (int j = 0; j < size; ++j) {
            final Node node2 = buttons.get(j);
            if (node2 instanceof Button && ((Button)node2).isDefaultButton()) {
                node2.requestFocus();
                b3 = true;
                break;
            }
        }
        if (!b3) {
            for (int k = 0; k < size; ++k) {
                final Node node3 = buttons.get(k);
                final ButtonBar.ButtonData buttonData = ButtonBar.getButtonData(node3);
                if (buttonData != null && buttonData.isDefaultButton()) {
                    node3.requestFocus();
                    break;
                }
            }
        }
    }
    
    private void resizeButtons() {
        final ButtonBar buttonBar = this.getSkinnable();
        final double buttonMinWidth = buttonBar.getButtonMinWidth();
        final ObservableList<Node> buttons = buttonBar.getButtons();
        double max = buttonMinWidth;
        for (final Node node : buttons) {
            if (ButtonBar.isButtonUniformSize(node)) {
                max = Math.max(node.prefWidth(-1.0), max);
            }
        }
        for (final Node node2 : buttons) {
            if (ButtonBar.isButtonUniformSize(node2)) {
                this.sizeButton(node2, Double.MAX_VALUE, max, Double.MAX_VALUE);
            }
        }
    }
    
    private void sizeButton(final Node node, final double minWidth, final double prefWidth, final double maxWidth) {
        if (node instanceof Region) {
            final Region region = (Region)node;
            if (minWidth != Double.MAX_VALUE) {
                region.setMinWidth(minWidth);
            }
            if (prefWidth != Double.MAX_VALUE) {
                region.setPrefWidth(prefWidth);
            }
            if (maxWidth != Double.MAX_VALUE) {
                region.setMaxWidth(maxWidth);
            }
        }
    }
    
    private String getButtonType(final Node node) {
        ButtonBar.ButtonData buttonData = ButtonBar.getButtonData(node);
        if (buttonData == null) {
            buttonData = ButtonBar.ButtonData.OTHER;
        }
        final String typeCode = buttonData.getTypeCode();
        final String s = (typeCode.length() > 0) ? typeCode.substring(0, 1) : "";
        return "LRHEYNXBIACO".contains(s.toUpperCase()) ? s : ButtonBar.ButtonData.OTHER.getTypeCode();
    }
    
    private Map<String, List<Node>> buildButtonMap(final List<? extends Node> list) {
        final HashMap<String, List<Node>> hashMap = (HashMap<String, List<Node>>)new HashMap<Object, List<Node>>();
        for (final Node node : list) {
            if (node == null) {
                continue;
            }
            final String buttonType = this.getButtonType(node);
            List<Node> list2 = hashMap.get(buttonType);
            if (list2 == null) {
                list2 = new ArrayList<Node>();
                hashMap.put(buttonType, list2);
            }
            list2.add(node);
        }
        return hashMap;
    }
    
    private enum Spacer
    {
        FIXED(0) {
            @Override
            protected Node create(final boolean b) {
                if (b) {
                    return null;
                }
                final Region region = new Region();
                ButtonBar.setButtonData(region, ButtonBar.ButtonData.SMALL_GAP);
                region.setMinWidth(10.0);
                HBox.setHgrow(region, Priority.NEVER);
                return region;
            }
        }, 
        DYNAMIC(1) {
            @Override
            protected Node create(final boolean b) {
                final Region region = new Region();
                ButtonBar.setButtonData(region, ButtonBar.ButtonData.BIG_GAP);
                region.setMinWidth(b ? 0.0 : 10.0);
                HBox.setHgrow(region, Priority.ALWAYS);
                return region;
            }
            
            @Override
            public Spacer replace(final Spacer spacer) {
                return (ButtonBarSkin$Spacer$2.FIXED == spacer) ? this : spacer;
            }
        }, 
        NONE;
        
        protected Node create(final boolean b) {
            return null;
        }
        
        public Spacer replace(final Spacer spacer) {
            return spacer;
        }
        
        public void add(final Pane pane, final boolean b) {
            final Node create = this.create(b);
            if (create != null) {
                pane.getChildren().add(create);
            }
        }
    }
}
