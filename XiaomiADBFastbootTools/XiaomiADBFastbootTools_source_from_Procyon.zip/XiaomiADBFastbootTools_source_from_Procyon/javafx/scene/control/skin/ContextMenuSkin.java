// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.control.Skinnable;
import javafx.geometry.Bounds;
import javafx.scene.control.PopupControl;
import com.sun.javafx.scene.control.skin.Utils;
import java.util.Collection;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.control.EmbeddedTextContextMenuContent;
import com.sun.javafx.scene.control.Properties;
import javafx.stage.WindowEvent;
import javafx.scene.Node;
import javafx.scene.AccessibleAttribute;
import com.sun.javafx.scene.control.ContextMenuContent;
import javafx.scene.control.Menu;
import javafx.event.Event;
import javafx.scene.input.KeyEvent;
import javafx.event.EventHandler;
import com.sun.javafx.scene.control.behavior.TwoLevelFocusPopupBehavior;
import javafx.scene.layout.Region;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Skin;

public class ContextMenuSkin implements Skin<ContextMenu>
{
    private ContextMenu popupMenu;
    private final Region root;
    private TwoLevelFocusPopupBehavior tlFocus;
    private double prefHeight;
    private double shiftY;
    private double prefWidth;
    private double shiftX;
    private final EventHandler<KeyEvent> keyListener;
    
    public ContextMenuSkin(final ContextMenu popupMenu) {
        this.keyListener = new EventHandler<KeyEvent>() {
            @Override
            public void handle(final KeyEvent keyEvent) {
                if (keyEvent.getEventType() != KeyEvent.KEY_PRESSED) {
                    return;
                }
                if (!ContextMenuSkin.this.root.isFocused()) {
                    return;
                }
                switch (keyEvent.getCode()) {
                    case ENTER:
                    case SPACE: {
                        ContextMenuSkin.this.popupMenu.hide();
                    }
                    default: {}
                }
            }
        };
        (this.popupMenu = popupMenu).addEventHandler(Menu.ON_SHOWING, new EventHandler<Event>() {
            @Override
            public void handle(final Event event) {
                ContextMenuSkin.this.prefHeight = ContextMenuSkin.this.root.prefHeight(-1.0);
                ContextMenuSkin.this.prefWidth = ContextMenuSkin.this.root.prefWidth(-1.0);
            }
        });
        this.popupMenu.addEventHandler(Menu.ON_SHOWN, new EventHandler<Event>() {
            @Override
            public void handle(final Event event) {
                final Node node = ContextMenuSkin.this.popupMenu.getSkin().getNode();
                if (node != null && node instanceof ContextMenuContent) {
                    ((ContextMenuContent)node).getItemsContainer().notifyAccessibleAttributeChanged(AccessibleAttribute.VISIBLE);
                }
                ContextMenuSkin.this.root.addEventHandler(KeyEvent.KEY_PRESSED, ContextMenuSkin.this.keyListener);
                ContextMenuSkin.this.performPopupShifts();
            }
        });
        this.popupMenu.addEventHandler(Menu.ON_HIDDEN, new EventHandler<Event>() {
            @Override
            public void handle(final Event event) {
                final Node node = ContextMenuSkin.this.popupMenu.getSkin().getNode();
                if (node != null) {
                    node.requestFocus();
                }
                ContextMenuSkin.this.root.removeEventHandler(KeyEvent.KEY_PRESSED, ContextMenuSkin.this.keyListener);
            }
        });
        this.popupMenu.addEventFilter(WindowEvent.WINDOW_HIDING, new EventHandler<Event>() {
            @Override
            public void handle(final Event event) {
                final Node node = ContextMenuSkin.this.popupMenu.getSkin().getNode();
                if (node instanceof ContextMenuContent) {
                    ((ContextMenuContent)node).getItemsContainer().notifyAccessibleAttributeChanged(AccessibleAttribute.VISIBLE);
                }
            }
        });
        if (Properties.IS_TOUCH_SUPPORTED && this.popupMenu.getStyleClass().contains("text-input-context-menu")) {
            this.root = new EmbeddedTextContextMenuContent(this.popupMenu);
        }
        else {
            this.root = new ContextMenuContent(this.popupMenu);
        }
        this.root.idProperty().bind(this.popupMenu.idProperty());
        this.root.styleProperty().bind(this.popupMenu.styleProperty());
        this.root.getStyleClass().addAll((Collection<?>)this.popupMenu.getStyleClass());
        if (Utils.isTwoLevelFocus()) {
            this.tlFocus = new TwoLevelFocusPopupBehavior(this.popupMenu);
        }
    }
    
    @Override
    public ContextMenu getSkinnable() {
        return this.popupMenu;
    }
    
    @Override
    public Node getNode() {
        return this.root;
    }
    
    @Override
    public void dispose() {
        this.root.idProperty().unbind();
        this.root.styleProperty().unbind();
        if (this.tlFocus != null) {
            this.tlFocus.dispose();
        }
    }
    
    private void performPopupShifts() {
        final ContextMenu skinnable = this.getSkinnable();
        final Node ownerNode = skinnable.getOwnerNode();
        if (ownerNode == null) {
            return;
        }
        final Bounds localToScreen = ownerNode.localToScreen(ownerNode.getLayoutBounds());
        if (localToScreen == null) {
            return;
        }
        final double prefHeight = this.root.prefHeight(-1.0);
        this.shiftY = this.prefHeight - prefHeight;
        if (this.shiftY > 0.0 && skinnable.getY() + prefHeight < localToScreen.getMinY()) {
            skinnable.setY(skinnable.getY() + this.shiftY);
        }
        final double prefWidth = this.root.prefWidth(-1.0);
        this.shiftX = this.prefWidth - prefWidth;
        if (this.shiftX > 0.0 && skinnable.getX() + prefWidth < localToScreen.getMinX()) {
            skinnable.setX(skinnable.getX() + this.shiftX);
        }
    }
}
