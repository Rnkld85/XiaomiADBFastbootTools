// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.util.AbstractList;
import javafx.scene.shape.Rectangle;
import javafx.event.EventDispatchChain;
import javafx.beans.value.ObservableValue;
import javafx.scene.input.TouchEvent;
import javafx.beans.Observable;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import java.util.Collection;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.scene.control.Logging;
import java.util.Iterator;
import javafx.scene.AccessibleRole;
import javafx.scene.control.Cell;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.BooleanPropertyBase;
import javafx.beans.InvalidationListener;
import javafx.event.EventDispatcher;
import com.sun.javafx.scene.ParentHelper;
import com.sun.javafx.scene.traversal.ParentTraversalEngine;
import com.sun.javafx.scene.traversal.Direction;
import com.sun.javafx.scene.traversal.TraversalContext;
import com.sun.javafx.scene.traversal.Algorithm;
import javafx.geometry.Orientation;
import javafx.scene.input.MouseEvent;
import com.sun.javafx.scene.control.Properties;
import javafx.event.EventHandler;
import javafx.event.Event;
import javafx.scene.input.ScrollEvent;
import java.util.ArrayList;
import com.sun.javafx.util.Utils;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.Parent;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import java.util.List;
import javafx.util.Callback;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.BooleanProperty;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import java.util.BitSet;
import javafx.scene.layout.StackPane;
import com.sun.javafx.scene.control.VirtualScrollBar;
import javafx.scene.Node;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.layout.Region;
import javafx.scene.control.IndexedCell;

public class VirtualFlow<T extends IndexedCell> extends Region
{
    private static final int MIN_SCROLLING_LINES_PER_PAGE = 8;
    private static final String NEW_CELL = "newcell";
    private static final double GOLDEN_RATIO_MULTIPLIER = 0.618033987;
    private boolean touchDetected;
    private boolean mouseDown;
    double lastWidth;
    double lastHeight;
    int lastCellCount;
    boolean lastVertical;
    double lastPosition;
    double lastCellBreadth;
    double lastCellLength;
    final ArrayLinkedList<T> cells;
    final ArrayLinkedList<T> pile;
    T accumCell;
    Group accumCellParent;
    final Group sheet;
    final ObservableList<Node> sheetChildren;
    private VirtualScrollBar hbar;
    private VirtualScrollBar vbar;
    ClippedContainer clipView;
    StackPane corner;
    private double lastX;
    private double lastY;
    private boolean isPanning;
    private boolean fixedCellSizeEnabled;
    private boolean needsReconfigureCells;
    private boolean needsRecreateCells;
    private boolean needsRebuildCells;
    private boolean needsCellsLayout;
    private boolean sizeChanged;
    private final BitSet dirtyCells;
    Timeline sbTouchTimeline;
    KeyFrame sbTouchKF1;
    KeyFrame sbTouchKF2;
    private boolean needBreadthBar;
    private boolean needLengthBar;
    private boolean tempVisibility;
    private BooleanProperty vertical;
    private BooleanProperty pannable;
    private IntegerProperty cellCount;
    private DoubleProperty position;
    private DoubleProperty fixedCellSize;
    private ObjectProperty<Callback<VirtualFlow<T>, T>> cellFactory;
    private double maxPrefBreadth;
    private double viewportBreadth;
    private double viewportLength;
    private final List<T> privateCells;
    
    public VirtualFlow() {
        this.touchDetected = false;
        this.mouseDown = false;
        this.lastWidth = -1.0;
        this.lastHeight = -1.0;
        this.lastCellCount = 0;
        this.lastCellBreadth = -1.0;
        this.lastCellLength = -1.0;
        this.cells = new ArrayLinkedList<T>();
        this.pile = new ArrayLinkedList<T>();
        this.hbar = new VirtualScrollBar(this);
        this.vbar = new VirtualScrollBar(this);
        this.isPanning = false;
        this.fixedCellSizeEnabled = false;
        this.needsReconfigureCells = false;
        this.needsRecreateCells = false;
        this.needsRebuildCells = false;
        this.needsCellsLayout = false;
        this.sizeChanged = false;
        this.dirtyCells = new BitSet();
        this.tempVisibility = false;
        this.pannable = new SimpleBooleanProperty(this, "pannable", true);
        this.cellCount = new SimpleIntegerProperty((Object)this, "cellCount", 0) {
            private int oldCount = 0;
            
            @Override
            protected void invalidated() {
                final int value = this.get();
                final boolean b = this.oldCount != value;
                this.oldCount = value;
                if (b) {
                    (VirtualFlow.this.isVertical() ? VirtualFlow.this.vbar : VirtualFlow.this.hbar).setMax(value);
                }
                if (b) {
                    VirtualFlow.this.layoutChildren();
                    VirtualFlow.this.sheetChildren.clear();
                    final Parent parent = VirtualFlow.this.getParent();
                    if (parent != null) {
                        parent.requestLayout();
                    }
                }
            }
        };
        this.position = new SimpleDoubleProperty((Object)this, "position") {
            @Override
            public void setValue(final Number n) {
                super.setValue(Utils.clamp(0.0, this.get(), 1.0));
            }
            
            @Override
            protected void invalidated() {
                super.invalidated();
                VirtualFlow.this.requestLayout();
            }
        };
        this.fixedCellSize = new SimpleDoubleProperty((Object)this, "fixedCellSize") {
            @Override
            protected void invalidated() {
                VirtualFlow.this.fixedCellSizeEnabled = (this.get() > 0.0);
                VirtualFlow.this.needsCellsLayout = true;
                VirtualFlow.this.layoutChildren();
            }
        };
        this.privateCells = new ArrayList<T>();
        this.getStyleClass().add("virtual-flow");
        this.setId("virtual-flow");
        this.sheet = new Group();
        this.sheet.getStyleClass().add("sheet");
        this.sheet.setAutoSizeChildren(false);
        this.sheetChildren = this.sheet.getChildren();
        (this.clipView = new ClippedContainer(this)).setNode(this.sheet);
        this.getChildren().add(this.clipView);
        (this.accumCellParent = new Group()).setVisible(false);
        this.getChildren().add(this.accumCellParent);
        final EventDispatcher eventDispatcher = (event, p1) -> event;
        final EventDispatcher eventDispatcher2;
        final EventDispatcher eventDispatcher3;
        this.hbar.setEventDispatcher((scrollEvent, eventDispatchChain) -> {
            this.hbar.getEventDispatcher();
            if (scrollEvent.getEventType() == ScrollEvent.SCROLL && !scrollEvent.isDirect()) {
                eventDispatchChain = eventDispatchChain.prepend(eventDispatcher2);
                eventDispatchChain = eventDispatchChain.prepend(eventDispatcher3);
                return eventDispatchChain.dispatchEvent(scrollEvent);
            }
            else {
                return eventDispatcher3.dispatchEvent(scrollEvent, eventDispatchChain);
            }
        });
        final EventDispatcher eventDispatcher4;
        final EventDispatcher eventDispatcher5;
        this.vbar.setEventDispatcher((scrollEvent2, eventDispatchChain2) -> {
            this.vbar.getEventDispatcher();
            if (scrollEvent2.getEventType() == ScrollEvent.SCROLL && !scrollEvent2.isDirect()) {
                eventDispatchChain2 = eventDispatchChain2.prepend(eventDispatcher4);
                eventDispatchChain2 = eventDispatchChain2.prepend(eventDispatcher5);
                return eventDispatchChain2.dispatchEvent(scrollEvent2);
            }
            else {
                return eventDispatcher5.dispatchEvent(scrollEvent2, eventDispatchChain2);
            }
        });
        this.setOnScroll(new EventHandler<ScrollEvent>() {
            @Override
            public void handle(final ScrollEvent scrollEvent) {
                if (Properties.IS_TOUCH_SUPPORTED && !VirtualFlow.this.touchDetected && !VirtualFlow.this.mouseDown) {
                    VirtualFlow.this.startSBReleasedAnimation();
                }
                double deltaY = 0.0;
                if (VirtualFlow.this.isVertical()) {
                    switch (scrollEvent.getTextDeltaYUnits()) {
                        case PAGES: {
                            deltaY = scrollEvent.getTextDeltaY() * VirtualFlow.this.lastHeight;
                            break;
                        }
                        case LINES: {
                            double fixedCellSize;
                            if (VirtualFlow.this.fixedCellSizeEnabled) {
                                fixedCellSize = VirtualFlow.this.getFixedCellSize();
                            }
                            else {
                                final IndexedCell indexedCell = VirtualFlow.this.cells.getLast();
                                fixedCellSize = (VirtualFlow.this.getCellPosition(indexedCell) + VirtualFlow.this.getCellLength(indexedCell) - VirtualFlow.this.getCellPosition(VirtualFlow.this.cells.getFirst())) / VirtualFlow.this.cells.size();
                            }
                            if (VirtualFlow.this.lastHeight / fixedCellSize < 8.0) {
                                fixedCellSize = VirtualFlow.this.lastHeight / 8.0;
                            }
                            deltaY = scrollEvent.getTextDeltaY() * fixedCellSize;
                            break;
                        }
                        case NONE: {
                            deltaY = scrollEvent.getDeltaY();
                            break;
                        }
                    }
                }
                else {
                    switch (scrollEvent.getTextDeltaXUnits()) {
                        case CHARACTERS:
                        case NONE: {
                            final double deltaX = scrollEvent.getDeltaX();
                            final double deltaY2 = scrollEvent.getDeltaY();
                            deltaY = ((Math.abs(deltaX) > Math.abs(deltaY2)) ? deltaX : deltaY2);
                            break;
                        }
                    }
                }
                if (deltaY != 0.0 && VirtualFlow.this.scrollPixels(-deltaY) != 0.0) {
                    scrollEvent.consume();
                }
                final VirtualScrollBar virtualScrollBar = VirtualFlow.this.isVertical() ? VirtualFlow.this.hbar : VirtualFlow.this.vbar;
                if (VirtualFlow.this.needBreadthBar) {
                    final double n = VirtualFlow.this.isVertical() ? scrollEvent.getDeltaX() : scrollEvent.getDeltaY();
                    if (n != 0.0) {
                        final double value = virtualScrollBar.getValue() - n;
                        if (value < virtualScrollBar.getMin()) {
                            virtualScrollBar.setValue(virtualScrollBar.getMin());
                        }
                        else if (value > virtualScrollBar.getMax()) {
                            virtualScrollBar.setValue(virtualScrollBar.getMax());
                        }
                        else {
                            virtualScrollBar.setValue(value);
                        }
                        scrollEvent.consume();
                    }
                }
            }
        });
        this.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(final MouseEvent mouseEvent) {
                VirtualFlow.this.mouseDown = true;
                if (Properties.IS_TOUCH_SUPPORTED) {
                    VirtualFlow.this.scrollBarOn();
                }
                if (VirtualFlow.this.isFocusTraversable()) {
                    boolean b = true;
                    final Node focusOwner = VirtualFlow.this.getScene().getFocusOwner();
                    if (focusOwner != null) {
                        for (Parent parent = focusOwner.getParent(); parent != null; parent = parent.getParent()) {
                            if (parent.equals(VirtualFlow.this)) {
                                b = false;
                                break;
                            }
                        }
                    }
                    if (b) {
                        VirtualFlow.this.requestFocus();
                    }
                }
                VirtualFlow.this.lastX = mouseEvent.getX();
                VirtualFlow.this.lastY = mouseEvent.getY();
                VirtualFlow.this.isPanning = (!VirtualFlow.this.vbar.getBoundsInParent().contains(mouseEvent.getX(), mouseEvent.getY()) && !VirtualFlow.this.hbar.getBoundsInParent().contains(mouseEvent.getX(), mouseEvent.getY()));
            }
        });
        this.addEventFilter(MouseEvent.MOUSE_RELEASED, p0 -> {
            this.mouseDown = false;
            if (Properties.IS_TOUCH_SUPPORTED) {
                this.startSBReleasedAnimation();
            }
            return;
        });
        double n3;
        double n4;
        double n5;
        VirtualScrollBar virtualScrollBar;
        double value;
        this.addEventFilter(MouseEvent.MOUSE_DRAGGED, mouseEvent3 -> {
            if (Properties.IS_TOUCH_SUPPORTED) {
                this.scrollBarOn();
            }
            if (!this.isPanning || !this.isPannable()) {
                return;
            }
            else {
                n3 = this.lastX - mouseEvent3.getX();
                n4 = this.lastY - mouseEvent3.getY();
                if (this.scrollPixels(this.isVertical() ? n4 : n3) != 0.0) {
                    if (this.isVertical()) {
                        this.lastY = mouseEvent3.getY();
                    }
                    else {
                        this.lastX = mouseEvent3.getX();
                    }
                }
                n5 = (this.isVertical() ? n3 : n4);
                virtualScrollBar = (this.isVertical() ? this.hbar : this.vbar);
                if (virtualScrollBar.isVisible()) {
                    value = virtualScrollBar.getValue() + n5;
                    if (value < virtualScrollBar.getMin()) {
                        virtualScrollBar.setValue(virtualScrollBar.getMin());
                    }
                    else if (value > virtualScrollBar.getMax()) {
                        virtualScrollBar.setValue(virtualScrollBar.getMax());
                    }
                    else {
                        virtualScrollBar.setValue(value);
                        if (this.isVertical()) {
                            this.lastX = mouseEvent3.getX();
                        }
                        else {
                            this.lastY = mouseEvent3.getY();
                        }
                    }
                }
                return;
            }
        });
        this.vbar.setOrientation(Orientation.VERTICAL);
        this.vbar.addEventHandler(MouseEvent.ANY, mouseEvent -> mouseEvent.consume());
        this.getChildren().add(this.vbar);
        this.hbar.setOrientation(Orientation.HORIZONTAL);
        this.hbar.addEventHandler(MouseEvent.ANY, mouseEvent2 -> mouseEvent2.consume());
        this.getChildren().add(this.hbar);
        this.corner = new StackPane();
        this.corner.getStyleClass().setAll("corner");
        this.getChildren().add(this.corner);
        final InvalidationListener invalidationListener = p0 -> this.updateHbar();
        this.verticalProperty().addListener(invalidationListener);
        this.hbar.valueProperty().addListener(invalidationListener);
        this.hbar.visibleProperty().addListener(invalidationListener);
        this.vbar.valueProperty().addListener((p0, p1, p2) -> this.clipView.setClipY(this.isVertical() ? 0.0 : this.vbar.getValue()));
        super.heightProperty().addListener((p0, n, n2) -> {
            if (n.doubleValue() == 0.0 && n2.doubleValue() > 0.0) {
                this.recreateCells();
            }
            return;
        });
        this.setOnTouchPressed(p0 -> {
            this.touchDetected = true;
            this.scrollBarOn();
            return;
        });
        this.setOnTouchReleased(p0 -> {
            this.touchDetected = false;
            this.startSBReleasedAnimation();
            return;
        });
        ParentHelper.setTraversalEngine(this, new ParentTraversalEngine(this, new Algorithm() {
            Node selectNextAfterIndex(int n, final TraversalContext traversalContext) {
                IndexedCell visibleCell;
                while ((visibleCell = VirtualFlow.this.getVisibleCell(++n)) != null) {
                    if (visibleCell.isFocusTraversable()) {
                        return visibleCell;
                    }
                    final Node selectFirstInParent = traversalContext.selectFirstInParent(visibleCell);
                    if (selectFirstInParent != null) {
                        return selectFirstInParent;
                    }
                }
                return null;
            }
            
            Node selectPreviousBeforeIndex(int n, final TraversalContext traversalContext) {
                IndexedCell visibleCell;
                while ((visibleCell = VirtualFlow.this.getVisibleCell(--n)) != null) {
                    final Node selectLastInParent = traversalContext.selectLastInParent(visibleCell);
                    if (selectLastInParent != null) {
                        return selectLastInParent;
                    }
                    if (visibleCell.isFocusTraversable()) {
                        return visibleCell;
                    }
                }
                return null;
            }
            
            @Override
            public Node select(final Node o, Direction next_IN_LINE, final TraversalContext traversalContext) {
                if (VirtualFlow.this.cells.isEmpty()) {
                    return null;
                }
                IndexedCell ownerCell;
                if (VirtualFlow.this.cells.contains(o)) {
                    ownerCell = (IndexedCell)o;
                }
                else {
                    ownerCell = this.findOwnerCell(o);
                    final Node selectInSubtree = traversalContext.selectInSubtree(ownerCell, o, next_IN_LINE);
                    if (selectInSubtree != null) {
                        return selectInSubtree;
                    }
                    if (next_IN_LINE == Direction.NEXT) {
                        next_IN_LINE = Direction.NEXT_IN_LINE;
                    }
                }
                final int index = ownerCell.getIndex();
                switch (next_IN_LINE) {
                    case PREVIOUS: {
                        return this.selectPreviousBeforeIndex(index, traversalContext);
                    }
                    case NEXT: {
                        final Node selectFirstInParent = traversalContext.selectFirstInParent(ownerCell);
                        if (selectFirstInParent != null) {
                            return selectFirstInParent;
                        }
                        return this.selectNextAfterIndex(index, traversalContext);
                    }
                    case NEXT_IN_LINE: {
                        return this.selectNextAfterIndex(index, traversalContext);
                    }
                    default: {
                        return null;
                    }
                }
            }
            
            private T findOwnerCell(final Node node) {
                Parent o;
                for (o = node.getParent(); !VirtualFlow.this.cells.contains(o); o = o.getParent()) {}
                return (T)o;
            }
            
            @Override
            public Node selectFirst(final TraversalContext traversalContext) {
                final IndexedCell indexedCell = VirtualFlow.this.cells.getFirst();
                if (indexedCell == null) {
                    return null;
                }
                if (indexedCell.isFocusTraversable()) {
                    return indexedCell;
                }
                final Node selectFirstInParent = traversalContext.selectFirstInParent(indexedCell);
                if (selectFirstInParent != null) {
                    return selectFirstInParent;
                }
                return this.selectNextAfterIndex(indexedCell.getIndex(), traversalContext);
            }
            
            @Override
            public Node selectLast(final TraversalContext traversalContext) {
                final IndexedCell indexedCell = VirtualFlow.this.cells.getLast();
                if (indexedCell == null) {
                    return null;
                }
                final Node selectLastInParent = traversalContext.selectLastInParent(indexedCell);
                if (selectLastInParent != null) {
                    return selectLastInParent;
                }
                if (indexedCell.isFocusTraversable()) {
                    return indexedCell;
                }
                return this.selectPreviousBeforeIndex(indexedCell.getIndex(), traversalContext);
            }
        }));
    }
    
    public final void setVertical(final boolean b) {
        this.verticalProperty().set(b);
    }
    
    public final boolean isVertical() {
        return this.vertical == null || this.vertical.get();
    }
    
    public final BooleanProperty verticalProperty() {
        if (this.vertical == null) {
            this.vertical = new BooleanPropertyBase(true) {
                @Override
                protected void invalidated() {
                    VirtualFlow.this.pile.clear();
                    VirtualFlow.this.sheetChildren.clear();
                    VirtualFlow.this.cells.clear();
                    final VirtualFlow this$0 = VirtualFlow.this;
                    final VirtualFlow this$2 = VirtualFlow.this;
                    final double n = -1.0;
                    this$2.lastHeight = n;
                    this$0.lastWidth = n;
                    VirtualFlow.this.setMaxPrefBreadth(-1.0);
                    VirtualFlow.this.setViewportBreadth(0.0);
                    VirtualFlow.this.setViewportLength(0.0);
                    VirtualFlow.this.lastPosition = 0.0;
                    VirtualFlow.this.hbar.setValue(0.0);
                    VirtualFlow.this.vbar.setValue(0.0);
                    VirtualFlow.this.setPosition(0.0);
                    Parent.this.setNeedsLayout(true);
                    VirtualFlow.this.requestLayout();
                }
                
                @Override
                public Object getBean() {
                    return VirtualFlow.this;
                }
                
                @Override
                public String getName() {
                    return "vertical";
                }
            };
        }
        return this.vertical;
    }
    
    public final boolean isPannable() {
        return this.pannable.get();
    }
    
    public final void setPannable(final boolean b) {
        this.pannable.set(b);
    }
    
    public final BooleanProperty pannableProperty() {
        return this.pannable;
    }
    
    public final int getCellCount() {
        return this.cellCount.get();
    }
    
    public final void setCellCount(final int n) {
        this.cellCount.set(n);
    }
    
    public final IntegerProperty cellCountProperty() {
        return this.cellCount;
    }
    
    public final double getPosition() {
        return this.position.get();
    }
    
    public final void setPosition(final double n) {
        this.position.set(n);
    }
    
    public final DoubleProperty positionProperty() {
        return this.position;
    }
    
    public final void setFixedCellSize(final double n) {
        this.fixedCellSize.set(n);
    }
    
    public final double getFixedCellSize() {
        return this.fixedCellSize.get();
    }
    
    public final DoubleProperty fixedCellSizeProperty() {
        return this.fixedCellSize;
    }
    
    public final void setCellFactory(final Callback<VirtualFlow<T>, T> callback) {
        this.cellFactoryProperty().set(callback);
    }
    
    public final Callback<VirtualFlow<T>, T> getCellFactory() {
        return (this.cellFactory == null) ? null : this.cellFactory.get();
    }
    
    public final ObjectProperty<Callback<VirtualFlow<T>, T>> cellFactoryProperty() {
        if (this.cellFactory == null) {
            this.cellFactory = new SimpleObjectProperty<Callback<VirtualFlow<T>, T>>(this, "cellFactory") {
                @Override
                protected void invalidated() {
                    if (this.get() != null) {
                        VirtualFlow.this.accumCell = null;
                        Parent.this.setNeedsLayout(true);
                        VirtualFlow.this.recreateCells();
                        if (VirtualFlow.this.getParent() != null) {
                            VirtualFlow.this.getParent().requestLayout();
                        }
                    }
                }
            };
        }
        return this.cellFactory;
    }
    
    @Override
    public void requestLayout() {
        super.requestLayout();
    }
    
    @Override
    protected void layoutChildren() {
        if (this.needsRecreateCells) {
            this.lastWidth = -1.0;
            this.lastHeight = -1.0;
            this.releaseCell(this.accumCell);
            this.sheet.getChildren().clear();
            for (int i = 0; i < this.cells.size(); ++i) {
                this.cells.get(i).updateIndex(-1);
            }
            this.cells.clear();
            this.pile.clear();
            this.releaseAllPrivateCells();
        }
        else if (this.needsRebuildCells) {
            this.lastWidth = -1.0;
            this.lastHeight = -1.0;
            this.releaseCell(this.accumCell);
            for (int j = 0; j < this.cells.size(); ++j) {
                this.cells.get(j).updateIndex(-1);
            }
            this.addAllToPile();
            this.releaseAllPrivateCells();
        }
        else if (this.needsReconfigureCells) {
            this.setMaxPrefBreadth(-1.0);
            this.lastWidth = -1.0;
            this.lastHeight = -1.0;
        }
        if (!this.dirtyCells.isEmpty()) {
            final int size = this.cells.size();
            int nextSetBit;
            while ((nextSetBit = this.dirtyCells.nextSetBit(0)) != -1 && nextSetBit < size) {
                final IndexedCell indexedCell = this.cells.get(nextSetBit);
                if (indexedCell != null) {
                    indexedCell.requestLayout();
                }
                this.dirtyCells.clear(nextSetBit);
            }
            this.setMaxPrefBreadth(-1.0);
            this.lastWidth = -1.0;
            this.lastHeight = -1.0;
        }
        final boolean sizeChanged = this.sizeChanged;
        final boolean b = this.needsRebuildCells || this.needsRecreateCells || this.sizeChanged;
        this.needsRecreateCells = false;
        this.needsReconfigureCells = false;
        this.needsRebuildCells = false;
        this.sizeChanged = false;
        if (this.needsCellsLayout) {
            for (int k = 0; k < this.cells.size(); ++k) {
                final IndexedCell indexedCell2 = this.cells.get(k);
                if (indexedCell2 != null) {
                    indexedCell2.requestLayout();
                }
            }
            this.needsCellsLayout = false;
            return;
        }
        final double width = this.getWidth();
        final double height = this.getHeight();
        final boolean vertical = this.isVertical();
        final double position = this.getPosition();
        if (width <= 0.0 || height <= 0.0) {
            this.addAllToPile();
            this.lastWidth = width;
            this.lastHeight = height;
            this.hbar.setVisible(false);
            this.vbar.setVisible(false);
            this.corner.setVisible(false);
            return;
        }
        boolean needsLayout = false;
        boolean b2 = false;
        if (Properties.IS_TOUCH_SUPPORTED && ((this.tempVisibility && (!this.hbar.isVisible() || !this.vbar.isVisible())) || (!this.tempVisibility && (this.hbar.isVisible() || this.vbar.isVisible())))) {
            b2 = true;
        }
        if (!needsLayout) {
            for (int l = 0; l < this.cells.size(); ++l) {
                needsLayout = this.cells.get(l).isNeedsLayout();
                if (needsLayout) {
                    break;
                }
            }
        }
        final int cellCount = this.getCellCount();
        final IndexedCell firstVisibleCell = this.getFirstVisibleCell();
        if (!needsLayout && !b2) {
            int n = 0;
            if (firstVisibleCell != null) {
                final double cellBreadth = this.getCellBreadth(firstVisibleCell);
                final double cellLength = this.getCellLength((T)firstVisibleCell);
                n = ((cellBreadth != this.lastCellBreadth || cellLength != this.lastCellLength) ? 1 : 0);
                this.lastCellBreadth = cellBreadth;
                this.lastCellLength = cellLength;
            }
            if (width == this.lastWidth && height == this.lastHeight && cellCount == this.lastCellCount && vertical == this.lastVertical && position == this.lastPosition && n == 0) {
                return;
            }
        }
        boolean b3 = false;
        int n2 = (needsLayout || vertical != this.lastVertical || this.cells.isEmpty() || this.getMaxPrefBreadth() == -1.0 || position != this.lastPosition || cellCount != this.lastCellCount || sizeChanged || (vertical && height < this.lastHeight) || (!vertical && width < this.lastWidth)) ? 1 : 0;
        if (n2 == 0) {
            final double maxPrefBreadth = this.getMaxPrefBreadth();
            boolean b4 = false;
            for (int n3 = 0; n3 < this.cells.size(); ++n3) {
                final double cellBreadth2 = this.getCellBreadth(this.cells.get(n3));
                if (maxPrefBreadth == cellBreadth2) {
                    b4 = true;
                }
                else if (cellBreadth2 > maxPrefBreadth) {
                    n2 = 1;
                    break;
                }
            }
            if (!b4) {
                n2 = 1;
            }
        }
        if (n2 == 0 && ((vertical && height > this.lastHeight) || (!vertical && width > this.lastWidth))) {
            b3 = true;
        }
        this.initViewport();
        int n4 = this.computeCurrentIndex();
        if (this.lastCellCount != cellCount) {
            if (position != 0.0) {
                if (position != 1.0) {
                    if (n4 >= cellCount) {
                        this.setPosition(1.0);
                    }
                    else if (firstVisibleCell != null) {
                        final double cellPosition = this.getCellPosition((T)firstVisibleCell);
                        final int cellIndex = this.getCellIndex((T)firstVisibleCell);
                        this.adjustPositionToIndex(cellIndex);
                        this.adjustByPixelAmount(-this.computeOffsetForCell(cellIndex) - cellPosition);
                    }
                }
            }
            n4 = this.computeCurrentIndex();
        }
        if (n2 != 0) {
            this.setMaxPrefBreadth(-1.0);
            this.addAllToPile();
            this.addLeadingCells(n4, -this.computeViewportOffset(this.getPosition()));
            this.addTrailingCells(true);
        }
        else if (b3) {
            this.addTrailingCells(true);
        }
        this.computeBarVisiblity();
        this.updateScrollBarsAndCells(b || n2 != 0);
        this.lastWidth = this.getWidth();
        this.lastHeight = this.getHeight();
        this.lastCellCount = this.getCellCount();
        this.lastVertical = this.isVertical();
        this.lastPosition = this.getPosition();
        this.cleanPile();
    }
    
    @Override
    protected void setWidth(final double width) {
        if (width != this.lastWidth) {
            super.setWidth(width);
            this.setNeedsLayout(this.sizeChanged = true);
            this.requestLayout();
        }
    }
    
    @Override
    protected void setHeight(final double height) {
        if (height != this.lastHeight) {
            super.setHeight(height);
            this.setNeedsLayout(this.sizeChanged = true);
            this.requestLayout();
        }
    }
    
    protected T getAvailableCell(final int n) {
        IndexedCell indexedCell = null;
        for (int i = 0; i < this.pile.size(); ++i) {
            final IndexedCell indexedCell2 = this.pile.get(i);
            assert indexedCell2 != null;
            if (this.getCellIndex((T)indexedCell2) == n) {
                indexedCell = indexedCell2;
                this.pile.remove(i);
                break;
            }
        }
        if (indexedCell == null && !this.pile.isEmpty()) {
            indexedCell = this.pile.removeLast();
        }
        if (indexedCell == null) {
            indexedCell = this.getCellFactory().call(this);
            indexedCell.getProperties().put("newcell", null);
        }
        if (indexedCell.getParent() == null) {
            this.sheetChildren.add(indexedCell);
        }
        return (T)indexedCell;
    }
    
    protected void addAllToPile() {
        for (int i = 0; i < this.cells.size(); ++i) {
            this.addToPile(this.cells.removeFirst());
        }
    }
    
    public T getVisibleCell(final int n) {
        if (this.cells.isEmpty()) {
            return null;
        }
        final IndexedCell indexedCell = this.cells.getLast();
        final int cellIndex = this.getCellIndex((T)indexedCell);
        if (n == cellIndex) {
            return (T)indexedCell;
        }
        final IndexedCell indexedCell2 = this.cells.getFirst();
        final int cellIndex2 = this.getCellIndex((T)indexedCell2);
        if (n == cellIndex2) {
            return (T)indexedCell2;
        }
        if (n > cellIndex2 && n < cellIndex) {
            final IndexedCell indexedCell3 = this.cells.get(n - cellIndex2);
            if (this.getCellIndex((T)indexedCell3) == n) {
                return (T)indexedCell3;
            }
        }
        return null;
    }
    
    public T getLastVisibleCell() {
        if (this.cells.isEmpty() || this.getViewportLength() <= 0.0) {
            return null;
        }
        for (int i = this.cells.size() - 1; i >= 0; --i) {
            final IndexedCell indexedCell = this.cells.get(i);
            if (!indexedCell.isEmpty()) {
                return (T)indexedCell;
            }
        }
        return null;
    }
    
    public T getFirstVisibleCell() {
        if (this.cells.isEmpty() || this.getViewportLength() <= 0.0) {
            return null;
        }
        final IndexedCell indexedCell = this.cells.getFirst();
        return (T)(indexedCell.isEmpty() ? null : indexedCell);
    }
    
    public void scrollToTop(final T t) {
        if (t != null) {
            this.scrollPixels(this.getCellPosition(t));
        }
    }
    
    public void scrollToBottom(final T t) {
        if (t != null) {
            this.scrollPixels(this.getCellPosition(t) + this.getCellLength(t) - this.getViewportLength());
        }
    }
    
    public void scrollTo(final T t) {
        if (t != null) {
            final double cellPosition = this.getCellPosition(t);
            final double n = cellPosition + this.getCellLength(t);
            final double viewportLength = this.getViewportLength();
            if (cellPosition < 0.0) {
                this.scrollPixels(cellPosition);
            }
            else if (n > viewportLength) {
                this.scrollPixels(n - viewportLength);
            }
        }
    }
    
    public void scrollTo(final int n) {
        final IndexedCell visibleCell = this.getVisibleCell(n);
        if (visibleCell != null) {
            this.scrollTo((T)visibleCell);
        }
        else {
            this.adjustPositionToIndex(n);
            this.addAllToPile();
            this.requestLayout();
        }
    }
    
    public void scrollToTop(final int n) {
        boolean b = false;
        if (n >= this.getCellCount() - 1) {
            this.setPosition(1.0);
            b = true;
        }
        else if (n < 0) {
            this.setPosition(0.0);
            b = true;
        }
        if (!b) {
            this.adjustPositionToIndex(n);
            this.adjustByPixelAmount(-this.computeOffsetForCell(n));
        }
        this.requestLayout();
    }
    
    public double scrollPixels(final double n) {
        if (n == 0.0) {
            return 0.0;
        }
        final boolean vertical = this.isVertical();
        if (vertical) {
            if (this.tempVisibility) {
                if (!this.needLengthBar) {
                    return 0.0;
                }
            }
            else if (!this.vbar.isVisible()) {
                return 0.0;
            }
        }
        if (!vertical) {
            if (this.tempVisibility) {
                if (!this.needLengthBar) {
                    return 0.0;
                }
            }
            else if (!this.hbar.isVisible()) {
                return 0.0;
            }
        }
        final double position = this.getPosition();
        if (position == 0.0 && n < 0.0) {
            return 0.0;
        }
        if (position == 1.0 && n > 0.0) {
            return 0.0;
        }
        this.adjustByPixelAmount(n);
        if (position == this.getPosition()) {
            return 0.0;
        }
        if (this.cells.size() > 0) {
            for (int i = 0; i < this.cells.size(); ++i) {
                final IndexedCell indexedCell = this.cells.get(i);
                assert indexedCell != null;
                this.positionCell((T)indexedCell, this.getCellPosition((T)indexedCell) - n);
            }
            final IndexedCell indexedCell2 = this.cells.getFirst();
            double n2 = (indexedCell2 == null) ? 0.0 : this.getCellPosition((T)indexedCell2);
            for (int j = 0; j < this.cells.size(); ++j) {
                final IndexedCell indexedCell3 = this.cells.get(j);
                assert indexedCell3 != null;
                if (Math.abs(this.getCellPosition((T)indexedCell3) - n2) > 0.001) {
                    this.positionCell((T)indexedCell3, n2);
                }
                n2 += this.getCellLength((T)indexedCell3);
            }
            this.cull();
            final IndexedCell indexedCell4 = this.cells.getFirst();
            if (indexedCell4 != null) {
                final int cellIndex = this.getCellIndex((T)indexedCell4);
                this.addLeadingCells(cellIndex - 1, this.getCellPosition((T)indexedCell4) - this.getCellLength(cellIndex - 1));
            }
            else {
                this.addLeadingCells(this.computeCurrentIndex(), -this.computeViewportOffset(this.getPosition()));
            }
            if (!this.addTrailingCells(false)) {
                final IndexedCell lastVisibleCell = this.getLastVisibleCell();
                final double n3 = this.getCellPosition((T)lastVisibleCell) + this.getCellLength((T)lastVisibleCell);
                final double viewportLength = this.getViewportLength();
                if (n3 < viewportLength) {
                    final double n4 = viewportLength - n3;
                    for (int k = 0; k < this.cells.size(); ++k) {
                        final IndexedCell indexedCell5 = this.cells.get(k);
                        this.positionCell((T)indexedCell5, this.getCellPosition((T)indexedCell5) + n4);
                    }
                    this.setPosition(1.0);
                    final IndexedCell indexedCell6 = this.cells.getFirst();
                    final int cellIndex2 = this.getCellIndex((T)indexedCell6);
                    this.addLeadingCells(cellIndex2 - 1, this.getCellPosition((T)indexedCell6) - this.getCellLength(cellIndex2 - 1));
                }
            }
        }
        this.cull();
        this.updateScrollBarsAndCells(false);
        this.lastPosition = this.getPosition();
        return n;
    }
    
    @Override
    protected double computePrefWidth(final double n) {
        return (this.isVertical() ? this.getPrefBreadth(n) : this.getPrefLength()) + this.vbar.prefWidth(-1.0);
    }
    
    @Override
    protected double computePrefHeight(final double n) {
        return (this.isVertical() ? this.getPrefLength() : this.getPrefBreadth(n)) + this.hbar.prefHeight(-1.0);
    }
    
    public T getCell(final int n) {
        if (!this.cells.isEmpty()) {
            final IndexedCell visibleCell = this.getVisibleCell(n);
            if (visibleCell != null) {
                return (T)visibleCell;
            }
        }
        for (int i = 0; i < this.pile.size(); ++i) {
            final IndexedCell indexedCell = this.pile.get(i);
            if (this.getCellIndex((T)indexedCell) == n) {
                return (T)indexedCell;
            }
        }
        if (this.pile.size() > 0) {
            return this.pile.get(0);
        }
        if (this.accumCell == null) {
            final Callback<VirtualFlow<T>, T> cellFactory = this.getCellFactory();
            if (cellFactory != null) {
                this.accumCell = cellFactory.call(this);
                this.accumCell.getProperties().put("newcell", null);
                this.accumCellParent.getChildren().setAll(this.accumCell);
                this.accumCell.setAccessibleRole(AccessibleRole.NODE);
                final Iterator<Node> iterator;
                this.accumCell.getChildrenUnmodifiable().addListener(p0 -> {
                    this.accumCell.getChildrenUnmodifiable().iterator();
                    while (iterator.hasNext()) {
                        iterator.next().setAccessibleRole(AccessibleRole.NODE);
                    }
                    return;
                });
            }
        }
        this.setCellIndex(this.accumCell, n);
        this.resizeCellSize(this.accumCell);
        return this.accumCell;
    }
    
    protected void setCellIndex(final T t, final int n) {
        assert t != null;
        t.updateIndex(n);
        if ((t.isNeedsLayout() && t.getScene() != null) || t.getProperties().containsKey("newcell")) {
            t.applyCss();
            t.getProperties().remove("newcell");
        }
    }
    
    protected int getCellIndex(final T t) {
        return t.getIndex();
    }
    
    final VirtualScrollBar getHbar() {
        return this.hbar;
    }
    
    final VirtualScrollBar getVbar() {
        return this.vbar;
    }
    
    private final void setMaxPrefBreadth(final double maxPrefBreadth) {
        this.maxPrefBreadth = maxPrefBreadth;
    }
    
    final double getMaxPrefBreadth() {
        return this.maxPrefBreadth;
    }
    
    private final void setViewportBreadth(final double viewportBreadth) {
        this.viewportBreadth = viewportBreadth;
    }
    
    private final double getViewportBreadth() {
        return this.viewportBreadth;
    }
    
    void setViewportLength(final double viewportLength) {
        this.viewportLength = viewportLength;
    }
    
    double getViewportLength() {
        return this.viewportLength;
    }
    
    double getCellLength(final int n) {
        if (this.fixedCellSizeEnabled) {
            return this.getFixedCellSize();
        }
        final IndexedCell cell = this.getCell(n);
        final double cellLength = this.getCellLength((T)cell);
        this.releaseCell((T)cell);
        return cellLength;
    }
    
    double getCellBreadth(final int n) {
        final IndexedCell cell = this.getCell(n);
        final double cellBreadth = this.getCellBreadth(cell);
        this.releaseCell((T)cell);
        return cellBreadth;
    }
    
    double getCellLength(final T t) {
        if (t == null) {
            return 0.0;
        }
        if (this.fixedCellSizeEnabled) {
            return this.getFixedCellSize();
        }
        return this.isVertical() ? t.getLayoutBounds().getHeight() : t.getLayoutBounds().getWidth();
    }
    
    double getCellBreadth(final Cell cell) {
        return this.isVertical() ? cell.prefWidth(-1.0) : cell.prefHeight(-1.0);
    }
    
    double getCellPosition(final T t) {
        if (t == null) {
            return 0.0;
        }
        return this.isVertical() ? t.getLayoutY() : t.getLayoutX();
    }
    
    private void positionCell(final T t, final double n) {
        if (this.isVertical()) {
            t.setLayoutX(0.0);
            t.setLayoutY(this.snapSizeY(n));
        }
        else {
            t.setLayoutX(this.snapSizeX(n));
            t.setLayoutY(0.0);
        }
    }
    
    private void resizeCellSize(final T t) {
        if (t == null) {
            return;
        }
        if (this.isVertical()) {
            final double max = Math.max(this.getMaxPrefBreadth(), this.getViewportBreadth());
            t.resize(max, this.fixedCellSizeEnabled ? this.getFixedCellSize() : com.sun.javafx.scene.control.skin.Utils.boundedSize(t.prefHeight(max), t.minHeight(max), t.maxHeight(max)));
        }
        else {
            final double max2 = Math.max(this.getMaxPrefBreadth(), this.getViewportBreadth());
            t.resize(this.fixedCellSizeEnabled ? this.getFixedCellSize() : com.sun.javafx.scene.control.skin.Utils.boundedSize(t.prefWidth(max2), t.minWidth(max2), t.maxWidth(max2)), max2);
        }
    }
    
    private List<T> getCells() {
        return this.cells;
    }
    
    T getLastVisibleCellWithinViewPort() {
        if (this.cells.isEmpty() || this.getViewportLength() <= 0.0) {
            return null;
        }
        final double viewportLength = this.getViewportLength();
        for (int i = this.cells.size() - 1; i >= 0; --i) {
            final IndexedCell indexedCell = this.cells.get(i);
            if (!indexedCell.isEmpty()) {
                if (this.getCellPosition((T)indexedCell) + this.getCellLength((T)indexedCell) <= viewportLength + 2.0) {
                    return (T)indexedCell;
                }
            }
        }
        return null;
    }
    
    T getFirstVisibleCellWithinViewPort() {
        if (this.cells.isEmpty() || this.getViewportLength() <= 0.0) {
            return null;
        }
        for (int i = 0; i < this.cells.size(); ++i) {
            final IndexedCell indexedCell = this.cells.get(i);
            if (!indexedCell.isEmpty()) {
                if (this.getCellPosition((T)indexedCell) >= 0.0) {
                    return (T)indexedCell;
                }
            }
        }
        return null;
    }
    
    void addLeadingCells(final int n, final double n2) {
        double n3 = n2;
        int n4 = n;
        int n5 = 1;
        if (n4 == this.getCellCount() && n3 == this.getViewportLength()) {
            --n4;
            n5 = 0;
        }
        while (n4 >= 0 && (n3 > 0.0 || n5 != 0)) {
            final IndexedCell availableCell = this.getAvailableCell(n4);
            this.setCellIndex((T)availableCell, n4);
            this.resizeCellSize((T)availableCell);
            this.cells.addFirst((T)availableCell);
            if (n5 != 0) {
                n5 = 0;
            }
            else {
                n3 -= this.getCellLength((T)availableCell);
            }
            this.positionCell((T)availableCell, n3);
            this.setMaxPrefBreadth(Math.max(this.getMaxPrefBreadth(), this.getCellBreadth(availableCell)));
            availableCell.setVisible(true);
            --n4;
        }
        if (this.cells.size() > 0) {
            final IndexedCell indexedCell = this.cells.getFirst();
            final int cellIndex = this.getCellIndex((T)indexedCell);
            final double cellPosition = this.getCellPosition((T)indexedCell);
            if (cellIndex == 0 && cellPosition > 0.0) {
                this.setPosition(0.0);
                double n6 = 0.0;
                for (int i = 0; i < this.cells.size(); ++i) {
                    final IndexedCell indexedCell2 = this.cells.get(i);
                    this.positionCell((T)indexedCell2, n6);
                    n6 += this.getCellLength((T)indexedCell2);
                }
            }
        }
        else {
            this.vbar.setValue(0.0);
            this.hbar.setValue(0.0);
        }
    }
    
    boolean addTrailingCells(final boolean b) {
        if (this.cells.isEmpty()) {
            return false;
        }
        final IndexedCell indexedCell = this.cells.getLast();
        double n = this.getCellPosition((T)indexedCell) + this.getCellLength((T)indexedCell);
        int n2 = this.getCellIndex((T)indexedCell) + 1;
        final int cellCount = this.getCellCount();
        boolean b2 = n2 <= cellCount;
        final double viewportLength = this.getViewportLength();
        if (n < 0.0 && !b) {
            return false;
        }
        final double n3 = viewportLength;
        while (n < viewportLength) {
            if (n2 >= cellCount) {
                if (n < viewportLength) {
                    b2 = false;
                }
                if (!b) {
                    return b2;
                }
                if (n2 > n3) {
                    final PlatformLogger controlsLogger = Logging.getControlsLogger();
                    if (controlsLogger.isLoggable(PlatformLogger.Level.INFO)) {
                        controlsLogger.info(invokedynamic(makeConcatWithConstants:(Ljava/lang/Class;)Ljava/lang/String;, indexedCell.getClass()));
                    }
                    return b2;
                }
            }
            final IndexedCell availableCell = this.getAvailableCell(n2);
            this.setCellIndex((T)availableCell, n2);
            this.resizeCellSize((T)availableCell);
            this.cells.addLast((T)availableCell);
            this.positionCell((T)availableCell, n);
            this.setMaxPrefBreadth(Math.max(this.getMaxPrefBreadth(), this.getCellBreadth(availableCell)));
            n += this.getCellLength((T)availableCell);
            availableCell.setVisible(true);
            ++n2;
        }
        final IndexedCell indexedCell2 = this.cells.getFirst();
        int cellIndex = this.getCellIndex((T)indexedCell2);
        final IndexedCell lastVisibleCell = this.getLastVisibleCell();
        double cellPosition = this.getCellPosition((T)indexedCell2);
        final double n4 = this.getCellPosition((T)lastVisibleCell) + this.getCellLength((T)lastVisibleCell);
        if ((cellIndex != 0 || (cellIndex == 0 && cellPosition < 0.0)) && b && lastVisibleCell != null && this.getCellIndex((T)lastVisibleCell) == cellCount - 1 && n4 < viewportLength) {
            double n5 = n4;
            final double n6 = viewportLength - n4;
            while (n5 < viewportLength && cellIndex != 0 && -cellPosition < n6) {
                --cellIndex;
                final IndexedCell availableCell2 = this.getAvailableCell(cellIndex);
                this.setCellIndex((T)availableCell2, cellIndex);
                this.resizeCellSize((T)availableCell2);
                this.cells.addFirst((T)availableCell2);
                final double cellLength = this.getCellLength((T)availableCell2);
                cellPosition -= cellLength;
                n5 += cellLength;
                this.positionCell((T)availableCell2, cellPosition);
                this.setMaxPrefBreadth(Math.max(this.getMaxPrefBreadth(), this.getCellBreadth(availableCell2)));
                availableCell2.setVisible(true);
            }
            final IndexedCell indexedCell3 = this.cells.getFirst();
            final double cellPosition2 = this.getCellPosition((T)indexedCell3);
            double n7 = viewportLength - n4;
            if (this.getCellIndex((T)indexedCell3) == 0 && n7 > -cellPosition2) {
                n7 = -cellPosition2;
            }
            for (int i = 0; i < this.cells.size(); ++i) {
                final IndexedCell indexedCell4 = this.cells.get(i);
                this.positionCell((T)indexedCell4, this.getCellPosition((T)indexedCell4) + n7);
            }
            final double cellPosition3 = this.getCellPosition((T)indexedCell3);
            if (this.getCellIndex((T)indexedCell3) == 0 && cellPosition3 == 0.0) {
                this.setPosition(0.0);
            }
            else if (this.getPosition() != 1.0) {
                this.setPosition(1.0);
            }
        }
        return b2;
    }
    
    void reconfigureCells() {
        this.needsReconfigureCells = true;
        this.requestLayout();
    }
    
    void recreateCells() {
        this.needsRecreateCells = true;
        this.requestLayout();
    }
    
    void rebuildCells() {
        this.needsRebuildCells = true;
        this.requestLayout();
    }
    
    void requestCellLayout() {
        this.needsCellsLayout = true;
        this.requestLayout();
    }
    
    void setCellDirty(final int bitIndex) {
        this.dirtyCells.set(bitIndex);
        this.requestLayout();
    }
    
    private void startSBReleasedAnimation() {
        if (this.sbTouchTimeline == null) {
            this.sbTouchTimeline = new Timeline();
            this.sbTouchKF1 = new KeyFrame(Duration.millis(0.0), p0 -> {
                this.tempVisibility = true;
                this.requestLayout();
                return;
            }, new KeyValue[0]);
            this.sbTouchKF2 = new KeyFrame(Duration.millis(1000.0), p0 -> {
                if (!this.touchDetected && !this.mouseDown) {
                    this.tempVisibility = false;
                    this.requestLayout();
                }
                return;
            }, new KeyValue[0]);
            this.sbTouchTimeline.getKeyFrames().addAll(this.sbTouchKF1, this.sbTouchKF2);
        }
        this.sbTouchTimeline.playFromStart();
    }
    
    private void scrollBarOn() {
        this.tempVisibility = true;
        this.requestLayout();
    }
    
    void updateHbar() {
        if (!this.isVisible() || this.getScene() == null) {
            return;
        }
        if (this.isVertical()) {
            if (this.hbar.isVisible()) {
                this.clipView.setClipX(this.hbar.getValue());
            }
            else {
                this.clipView.setClipX(0.0);
                this.hbar.setValue(0.0);
            }
        }
    }
    
    private boolean computeBarVisiblity() {
        if (this.cells.isEmpty()) {
            this.needLengthBar = false;
            this.needBreadthBar = false;
            return true;
        }
        final boolean vertical = this.isVertical();
        boolean b = false;
        final VirtualScrollBar virtualScrollBar = vertical ? this.hbar : this.vbar;
        final VirtualScrollBar virtualScrollBar2 = vertical ? this.vbar : this.hbar;
        final double viewportBreadth = this.getViewportBreadth();
        final int size = this.cells.size();
        final int cellCount = this.getCellCount();
        for (int i = 0; i < 2; ++i) {
            final boolean needLengthBar = this.getPosition() > 0.0 || cellCount > size || (cellCount == size && this.getCellPosition(this.cells.getLast()) + this.getCellLength(this.cells.getLast()) > this.getViewportLength()) || (cellCount == size - 1 && b && this.needBreadthBar);
            if (needLengthBar ^ this.needLengthBar) {
                this.needLengthBar = needLengthBar;
                b = true;
            }
            final boolean needBreadthBar = this.maxPrefBreadth > viewportBreadth;
            if (needBreadthBar ^ this.needBreadthBar) {
                this.needBreadthBar = needBreadthBar;
                b = true;
            }
        }
        if (!Properties.IS_TOUCH_SUPPORTED) {
            this.updateViewportDimensions();
            virtualScrollBar.setVisible(this.needBreadthBar);
            virtualScrollBar2.setVisible(this.needLengthBar);
        }
        else {
            virtualScrollBar.setVisible(this.needBreadthBar && this.tempVisibility);
            virtualScrollBar2.setVisible(this.needLengthBar && this.tempVisibility);
        }
        return b;
    }
    
    private void updateViewportDimensions() {
        final boolean vertical = this.isVertical();
        final double n = vertical ? this.snapSizeY(this.hbar.prefHeight(-1.0)) : this.snapSizeX(this.vbar.prefWidth(-1.0));
        final double n2 = vertical ? this.snapSizeX(this.vbar.prefWidth(-1.0)) : this.snapSizeY(this.hbar.prefHeight(-1.0));
        this.setViewportBreadth((vertical ? this.getWidth() : this.getHeight()) - (this.needLengthBar ? n2 : 0.0));
        this.setViewportLength((vertical ? this.getHeight() : this.getWidth()) - (this.needBreadthBar ? n : 0.0));
    }
    
    private void initViewport() {
        final boolean vertical = this.isVertical();
        this.updateViewportDimensions();
        final VirtualScrollBar virtualScrollBar = vertical ? this.hbar : this.vbar;
        final VirtualScrollBar virtualScrollBar2 = vertical ? this.vbar : this.hbar;
        virtualScrollBar.setVirtual(false);
        virtualScrollBar2.setVirtual(true);
    }
    
    private void updateScrollBarsAndCells(final boolean b) {
        final boolean vertical = this.isVertical();
        final VirtualScrollBar virtualScrollBar = vertical ? this.hbar : this.vbar;
        final VirtualScrollBar virtualScrollBar2 = vertical ? this.vbar : this.hbar;
        this.fitCells();
        if (!this.cells.isEmpty()) {
            final double n = -this.computeViewportOffset(this.getPosition());
            final int n2 = this.computeCurrentIndex() - this.cells.getFirst().getIndex();
            final int size = this.cells.size();
            double n3 = n;
            for (int n4 = n2 - 1; n4 >= 0 && n4 < size; --n4) {
                final IndexedCell indexedCell = this.cells.get(n4);
                n3 -= this.getCellLength((T)indexedCell);
                this.positionCell((T)indexedCell, n3);
            }
            double n5 = n;
            for (int n6 = n2; n6 >= 0 && n6 < size; ++n6) {
                final IndexedCell indexedCell2 = this.cells.get(n6);
                this.positionCell((T)indexedCell2, n5);
                n5 += this.getCellLength((T)indexedCell2);
            }
        }
        this.corner.setVisible(virtualScrollBar.isVisible() && virtualScrollBar2.isVisible());
        double n7 = 0.0;
        final double n8 = (vertical ? this.getHeight() : this.getWidth()) - (virtualScrollBar.isVisible() ? virtualScrollBar.prefHeight(-1.0) : 0.0);
        final double viewportBreadth = this.getViewportBreadth();
        final double viewportLength = this.getViewportLength();
        if (virtualScrollBar.isVisible()) {
            if (!Properties.IS_TOUCH_SUPPORTED) {
                if (vertical) {
                    this.hbar.resizeRelocate(0.0, viewportLength, viewportBreadth, this.hbar.prefHeight(viewportBreadth));
                }
                else {
                    this.vbar.resizeRelocate(viewportLength, 0.0, this.vbar.prefWidth(viewportBreadth), viewportBreadth);
                }
            }
            else if (vertical) {
                this.hbar.resizeRelocate(0.0, viewportLength - this.hbar.getHeight(), viewportBreadth, this.hbar.prefHeight(viewportBreadth));
            }
            else {
                this.vbar.resizeRelocate(viewportLength - this.vbar.getWidth(), 0.0, this.vbar.prefWidth(viewportBreadth), viewportBreadth);
            }
            if (this.getMaxPrefBreadth() != -1.0) {
                final double max = Math.max(1.0, this.getMaxPrefBreadth() - viewportBreadth);
                if (max != virtualScrollBar.getMax()) {
                    virtualScrollBar.setMax(max);
                    final double value = virtualScrollBar.getValue();
                    if ((value != 0.0 && max == value) || value > max) {
                        virtualScrollBar.setValue(max);
                    }
                    virtualScrollBar.setVisibleAmount(viewportBreadth / this.getMaxPrefBreadth() * max);
                }
            }
        }
        if (b && (virtualScrollBar2.isVisible() || Properties.IS_TOUCH_SUPPORTED)) {
            final int cellCount = this.getCellCount();
            int n9 = 0;
            for (int i = 0; i < this.cells.size(); ++i) {
                final IndexedCell indexedCell3 = this.cells.get(i);
                if (indexedCell3 != null && !indexedCell3.isEmpty()) {
                    n7 += (vertical ? indexedCell3.getHeight() : indexedCell3.getWidth());
                    if (n7 > n8) {
                        break;
                    }
                    ++n9;
                }
            }
            virtualScrollBar2.setMax(1.0);
            if (n9 == 0 && cellCount == 1) {
                virtualScrollBar2.setVisibleAmount(n8 / n7);
            }
            else {
                virtualScrollBar2.setVisibleAmount(n9 / (float)cellCount);
            }
        }
        if (virtualScrollBar2.isVisible()) {
            if (!Properties.IS_TOUCH_SUPPORTED) {
                if (vertical) {
                    this.vbar.resizeRelocate(viewportBreadth, 0.0, this.vbar.prefWidth(viewportLength), viewportLength);
                }
                else {
                    this.hbar.resizeRelocate(0.0, viewportBreadth, viewportLength, this.hbar.prefHeight(-1.0));
                }
            }
            else if (vertical) {
                this.vbar.resizeRelocate(viewportBreadth - this.vbar.getWidth(), 0.0, this.vbar.prefWidth(viewportLength), viewportLength);
            }
            else {
                this.hbar.resizeRelocate(0.0, viewportBreadth - this.hbar.getHeight(), viewportLength, this.hbar.prefHeight(-1.0));
            }
        }
        if (this.corner.isVisible()) {
            if (!Properties.IS_TOUCH_SUPPORTED) {
                this.corner.resize(this.vbar.getWidth(), this.hbar.getHeight());
                this.corner.relocate(this.hbar.getLayoutX() + this.hbar.getWidth(), this.vbar.getLayoutY() + this.vbar.getHeight());
            }
            else {
                this.corner.resize(this.vbar.getWidth(), this.hbar.getHeight());
                this.corner.relocate(this.hbar.getLayoutX() + (this.hbar.getWidth() - this.vbar.getWidth()), this.vbar.getLayoutY() + (this.vbar.getHeight() - this.hbar.getHeight()));
                this.hbar.resize(this.hbar.getWidth() - this.vbar.getWidth(), this.hbar.getHeight());
                this.vbar.resize(this.vbar.getWidth(), this.vbar.getHeight() - this.hbar.getHeight());
            }
        }
        this.clipView.resize(this.snapSizeX(vertical ? viewportBreadth : viewportLength), this.snapSizeY(vertical ? viewportLength : viewportBreadth));
        if (this.getPosition() != virtualScrollBar2.getValue()) {
            virtualScrollBar2.setValue(this.getPosition());
        }
    }
    
    private void fitCells() {
        final double max = Math.max(this.getMaxPrefBreadth(), this.getViewportBreadth());
        final boolean vertical = this.isVertical();
        for (int i = 0; i < this.cells.size(); ++i) {
            final IndexedCell indexedCell = this.cells.get(i);
            if (vertical) {
                indexedCell.resize(max, indexedCell.prefHeight(max));
            }
            else {
                indexedCell.resize(indexedCell.prefWidth(max), max);
            }
        }
    }
    
    private void cull() {
        final double viewportLength = this.getViewportLength();
        for (int i = this.cells.size() - 1; i >= 0; --i) {
            final IndexedCell indexedCell = this.cells.get(i);
            final double cellLength = this.getCellLength((T)indexedCell);
            final double cellPosition = this.getCellPosition((T)indexedCell);
            final double n = cellPosition + cellLength;
            if (cellPosition >= viewportLength || n < 0.0) {
                this.addToPile(this.cells.remove(i));
            }
        }
    }
    
    private void releaseCell(final T t) {
        if (this.accumCell != null && t == this.accumCell) {
            this.accumCell.updateIndex(-1);
        }
    }
    
    T getPrivateCell(final int n) {
        IndexedCell visibleCell = null;
        if (!this.cells.isEmpty()) {
            visibleCell = this.getVisibleCell(n);
            if (visibleCell != null) {
                visibleCell.layout();
                return (T)visibleCell;
            }
        }
        if (visibleCell == null) {
            for (int i = 0; i < this.sheetChildren.size(); ++i) {
                final IndexedCell indexedCell = this.sheetChildren.get(i);
                if (this.getCellIndex((T)indexedCell) == n) {
                    return (T)indexedCell;
                }
            }
        }
        final Callback<VirtualFlow<T>, T> cellFactory = this.getCellFactory();
        if (cellFactory != null) {
            visibleCell = cellFactory.call(this);
        }
        if (visibleCell != null) {
            this.setCellIndex((T)visibleCell, n);
            this.resizeCellSize((T)visibleCell);
            visibleCell.setVisible(false);
            this.sheetChildren.add(visibleCell);
            this.privateCells.add((T)visibleCell);
        }
        return (T)visibleCell;
    }
    
    private void releaseAllPrivateCells() {
        this.sheetChildren.removeAll(this.privateCells);
        this.privateCells.clear();
    }
    
    private void addToPile(final T t) {
        assert t != null;
        this.pile.addLast(t);
    }
    
    private void cleanPile() {
        boolean b = false;
        for (int i = 0; i < this.pile.size(); ++i) {
            final IndexedCell indexedCell = this.pile.get(i);
            b = (b || this.doesCellContainFocus(indexedCell));
            indexedCell.setVisible(false);
        }
        if (b) {
            this.requestFocus();
        }
    }
    
    private boolean doesCellContainFocus(final Cell<?> cell) {
        final Scene scene = cell.getScene();
        final Node obj = (scene == null) ? null : scene.getFocusOwner();
        if (obj != null) {
            if (cell.equals(obj)) {
                return true;
            }
            for (Parent obj2 = obj.getParent(); obj2 != null && !(obj2 instanceof VirtualFlow); obj2 = obj2.getParent()) {
                if (cell.equals(obj2)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private double getPrefBreadth(final double n) {
        double a = this.getMaxCellWidth(10);
        if (n > -1.0) {
            a = Math.max(a, this.getPrefLength() * 0.618033987);
        }
        return a;
    }
    
    private double getPrefLength() {
        double n = 0.0;
        for (int min = Math.min(10, this.getCellCount()), i = 0; i < min; ++i) {
            n += this.getCellLength(i);
        }
        return n;
    }
    
    double getMaxCellWidth(final int n) {
        double max = 0.0;
        for (int max2 = Math.max(1, (n == -1) ? this.getCellCount() : n), i = 0; i < max2; ++i) {
            max = Math.max(max, this.getCellBreadth(i));
        }
        return max;
    }
    
    private double computeViewportOffset(final double n) {
        final double clamp = Utils.clamp(0.0, n, 1.0);
        final double n2 = clamp * this.getCellCount();
        final int n3 = (int)n2;
        return this.getCellLength(n3) * (n2 - n3) - this.getViewportLength() * clamp;
    }
    
    private void adjustPositionToIndex(final int n) {
        final int cellCount = this.getCellCount();
        if (cellCount <= 0) {
            this.setPosition(0.0);
        }
        else {
            this.setPosition(n / (double)cellCount);
        }
    }
    
    private void adjustByPixelAmount(final double n) {
        if (n == 0.0) {
            return;
        }
        final boolean b = n > 0.0;
        final int cellCount = this.getCellCount();
        final double n2 = this.getPosition() * cellCount;
        int n3 = (int)n2;
        if (b && n3 == cellCount) {
            return;
        }
        final double cellLength = this.getCellLength(n3);
        final double n4 = cellLength * (n2 - n3);
        final double n5 = 1.0 / cellCount;
        double n6 = this.computeOffsetForCell(n3);
        double n7 = cellLength + this.computeOffsetForCell(n3 + 1);
        double n8 = n7 - n6;
        double n9 = b ? (n + n4 - this.getViewportLength() * this.getPosition() - n6) : (-n + n7 - (n4 - this.getViewportLength() * this.getPosition()));
        double n10 = n5 * n3;
        while (n9 > n8 && ((b && n3 < cellCount - 1) || (!b && n3 > 0))) {
            if (b) {
                ++n3;
            }
            else {
                --n3;
            }
            n9 -= n8;
            final double cellLength2 = this.getCellLength(n3);
            n6 = this.computeOffsetForCell(n3);
            n7 = cellLength2 + this.computeOffsetForCell(n3 + 1);
            n8 = n7 - n6;
            n10 = n5 * n3;
        }
        if (n9 > n8) {
            this.setPosition(b ? 1.0 : 0.0);
        }
        else if (b) {
            this.setPosition(n10 + n5 / Math.abs(n7 - n6) * n9);
        }
        else {
            this.setPosition(n10 + n5 - n5 / Math.abs(n7 - n6) * n9);
        }
    }
    
    private int computeCurrentIndex() {
        return (int)(this.getPosition() * this.getCellCount());
    }
    
    private double computeOffsetForCell(final int n) {
        final double n2 = this.getCellCount();
        return -(this.getViewportLength() * (Utils.clamp(0.0, n, n2) / n2));
    }
    
    static class ClippedContainer extends Region
    {
        private Node node;
        private final Rectangle clipRect;
        
        public Node getNode() {
            return this.node;
        }
        
        public void setNode(final Node node) {
            this.node = node;
            this.getChildren().clear();
            this.getChildren().add(this.node);
        }
        
        public void setClipX(final double layoutX) {
            this.setLayoutX(-layoutX);
            this.clipRect.setLayoutX(layoutX);
        }
        
        public void setClipY(final double layoutY) {
            this.setLayoutY(-layoutY);
            this.clipRect.setLayoutY(layoutY);
        }
        
        public ClippedContainer(final VirtualFlow<?> virtualFlow) {
            if (virtualFlow == null) {
                throw new IllegalArgumentException("VirtualFlow can not be null");
            }
            this.getStyleClass().add("clipped-container");
            (this.clipRect = new Rectangle()).setSmooth(false);
            this.setClip(this.clipRect);
            super.widthProperty().addListener(p0 -> this.clipRect.setWidth(this.getWidth()));
            super.heightProperty().addListener(p0 -> this.clipRect.setHeight(this.getHeight()));
        }
    }
    
    static class ArrayLinkedList<T> extends AbstractList<T>
    {
        private final ArrayList<T> array;
        private int firstIndex;
        private int lastIndex;
        
        public ArrayLinkedList() {
            this.firstIndex = -1;
            this.lastIndex = -1;
            this.array = new ArrayList<T>(50);
            for (int i = 0; i < 50; ++i) {
                this.array.add(null);
            }
        }
        
        public T getFirst() {
            return (this.firstIndex == -1) ? null : this.array.get(this.firstIndex);
        }
        
        public T getLast() {
            return (this.lastIndex == -1) ? null : this.array.get(this.lastIndex);
        }
        
        public void addFirst(final T element) {
            if (this.firstIndex == -1) {
                final int n = this.array.size() / 2;
                this.lastIndex = n;
                this.firstIndex = n;
                this.array.set(this.firstIndex, element);
            }
            else if (this.firstIndex == 0) {
                this.array.add(0, element);
                ++this.lastIndex;
            }
            else {
                this.array.set(--this.firstIndex, element);
            }
        }
        
        public void addLast(final T element) {
            if (this.firstIndex == -1) {
                final int n = this.array.size() / 2;
                this.lastIndex = n;
                this.firstIndex = n;
                this.array.set(this.lastIndex, element);
            }
            else if (this.lastIndex == this.array.size() - 1) {
                this.array.add(++this.lastIndex, element);
            }
            else {
                this.array.set(++this.lastIndex, element);
            }
        }
        
        @Override
        public int size() {
            return (this.firstIndex == -1) ? 0 : (this.lastIndex - this.firstIndex + 1);
        }
        
        @Override
        public boolean isEmpty() {
            return this.firstIndex == -1;
        }
        
        @Override
        public T get(final int n) {
            if (n > this.lastIndex - this.firstIndex || n < 0) {
                return null;
            }
            return this.array.get(this.firstIndex + n);
        }
        
        @Override
        public void clear() {
            for (int i = 0; i < this.array.size(); ++i) {
                this.array.set(i, null);
            }
            final int n = -1;
            this.lastIndex = n;
            this.firstIndex = n;
        }
        
        public T removeFirst() {
            if (this.isEmpty()) {
                return null;
            }
            return this.remove(0);
        }
        
        public T removeLast() {
            if (this.isEmpty()) {
                return null;
            }
            return this.remove(this.lastIndex - this.firstIndex);
        }
        
        @Override
        public T remove(final int n) {
            if (n > this.lastIndex - this.firstIndex || n < 0) {
                throw new ArrayIndexOutOfBoundsException();
            }
            if (n == 0) {
                final T value = this.array.get(this.firstIndex);
                this.array.set(this.firstIndex, null);
                if (this.firstIndex == this.lastIndex) {
                    final int n2 = -1;
                    this.lastIndex = n2;
                    this.firstIndex = n2;
                }
                else {
                    ++this.firstIndex;
                }
                return value;
            }
            if (n == this.lastIndex - this.firstIndex) {
                final T value2 = this.array.get(this.lastIndex);
                this.array.set(this.lastIndex--, null);
                return value2;
            }
            final T value3 = this.array.get(this.firstIndex + n);
            this.array.set(this.firstIndex + n, null);
            for (int i = this.firstIndex + n + 1; i <= this.lastIndex; ++i) {
                this.array.set(i - 1, this.array.get(i));
            }
            this.array.set(this.lastIndex--, null);
            return value3;
        }
    }
}
