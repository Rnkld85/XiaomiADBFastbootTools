// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import java.util.WeakHashMap;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.Node;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.beans.Observable;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.control.behavior.TreeCellBehavior;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import java.util.Map;
import javafx.scene.control.TreeCell;

public class TreeCellSkin<T> extends CellSkinBase<TreeCell<T>>
{
    private static final Map<TreeView<?>, Double> maxDisclosureWidthMap;
    private boolean disclosureNodeDirty;
    private TreeItem<?> treeItem;
    private final BehaviorBase<TreeCell<T>> behavior;
    private double fixedCellSize;
    private boolean fixedCellSizeEnabled;
    private DoubleProperty indent;
    
    public TreeCellSkin(final TreeCell<T> treeCell) {
        super(treeCell);
        this.disclosureNodeDirty = true;
        this.indent = null;
        this.behavior = (BehaviorBase<TreeCell<T>>)new TreeCellBehavior((TreeCell<Object>)treeCell);
        this.updateTreeItem();
        this.registerChangeListener(treeCell.treeItemProperty(), p0 -> {
            this.updateTreeItem();
            this.disclosureNodeDirty = true;
            this.getSkinnable().requestLayout();
            return;
        });
        this.registerChangeListener(treeCell.textProperty(), p0 -> this.getSkinnable().requestLayout());
        this.setupTreeViewListeners();
    }
    
    private void setupTreeViewListeners() {
        final TreeView treeView = this.getSkinnable().getTreeView();
        if (treeView == null) {
            this.getSkinnable().treeViewProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(final Observable observable) {
                    TreeCellSkin.this.getSkinnable().treeViewProperty().removeListener(this);
                    TreeCellSkin.this.setupTreeViewListeners();
                }
            });
        }
        else {
            this.fixedCellSize = treeView.getFixedCellSize();
            this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0);
            this.registerChangeListener(treeView.fixedCellSizeProperty(), p0 -> {
                this.fixedCellSize = this.getSkinnable().getTreeView().getFixedCellSize();
                this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0);
            });
        }
    }
    
    public final void setIndent(final double n) {
        this.indentProperty().set(n);
    }
    
    public final double getIndent() {
        return (this.indent == null) ? 10.0 : this.indent.get();
    }
    
    public final DoubleProperty indentProperty() {
        if (this.indent == null) {
            this.indent = new StyleableDoubleProperty(10.0) {
                @Override
                public Object getBean() {
                    return TreeCellSkin.this;
                }
                
                @Override
                public String getName() {
                    return "indent";
                }
                
                @Override
                public CssMetaData<TreeCell<?>, Number> getCssMetaData() {
                    return StyleableProperties.INDENT;
                }
            };
        }
        return this.indent;
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void updateChildren() {
        super.updateChildren();
        this.updateDisclosureNode();
    }
    
    @Override
    protected void layoutChildren(double n, final double n2, double n3, final double n4) {
        final TreeView<?> treeView = this.getSkinnable().getTreeView();
        if (treeView == null) {
            return;
        }
        if (this.disclosureNodeDirty) {
            this.updateDisclosureNode();
            this.disclosureNodeDirty = false;
        }
        final Node disclosureNode = this.getSkinnable().getDisclosureNode();
        int treeItemLevel = treeView.getTreeItemLevel(this.treeItem);
        if (!treeView.isShowRoot()) {
            --treeItemLevel;
        }
        final double n5 = this.getIndent() * treeItemLevel;
        n += n5;
        final boolean b = disclosureNode != null && this.treeItem != null && !this.treeItem.isLeaf();
        double prefWidth;
        final double n6 = prefWidth = (TreeCellSkin.maxDisclosureWidthMap.containsKey(treeView) ? TreeCellSkin.maxDisclosureWidthMap.get(treeView) : 18.0);
        if (b) {
            if (disclosureNode == null || disclosureNode.getScene() == null) {
                this.updateChildren();
            }
            if (disclosureNode != null) {
                prefWidth = disclosureNode.prefWidth(n4);
                if (prefWidth > n6) {
                    TreeCellSkin.maxDisclosureWidthMap.put(treeView, prefWidth);
                }
                final double prefHeight = disclosureNode.prefHeight(prefWidth);
                disclosureNode.resize(prefWidth, prefHeight);
                this.positionInArea(disclosureNode, n, n2, prefWidth, prefHeight, 0.0, HPos.CENTER, VPos.CENTER);
            }
        }
        final int n7 = (this.treeItem != null && this.treeItem.getGraphic() == null) ? 0 : 3;
        n += prefWidth + n7;
        n3 -= n5 + prefWidth + n7;
        final Node graphic = this.getSkinnable().getGraphic();
        if (graphic != null && !this.getChildren().contains(graphic)) {
            this.getChildren().add(graphic);
        }
        this.layoutLabelInArea(n, n2, n3, n4);
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.fixedCellSizeEnabled) {
            return this.fixedCellSize;
        }
        final double computeMinHeight = super.computeMinHeight(n, n2, n3, n4, n5);
        final Node disclosureNode = this.getSkinnable().getDisclosureNode();
        return (disclosureNode == null) ? computeMinHeight : Math.max(disclosureNode.minHeight(-1.0), computeMinHeight);
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.fixedCellSizeEnabled) {
            return this.fixedCellSize;
        }
        final TreeCell treeCell = this.getSkinnable();
        final double computePrefHeight = super.computePrefHeight(n, n2, n3, n4, n5);
        final Node disclosureNode = treeCell.getDisclosureNode();
        return this.snapSizeY(Math.max(treeCell.getMinHeight(), (disclosureNode == null) ? computePrefHeight : Math.max(disclosureNode.prefHeight(-1.0), computePrefHeight)));
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.fixedCellSizeEnabled) {
            return this.fixedCellSize;
        }
        return super.computeMaxHeight(n, n2, n3, n4, n5);
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final double computePrefWidth = super.computePrefWidth(n, n2, n3, n4, n5);
        final double n6 = this.snappedLeftInset() + this.snappedRightInset();
        final TreeView treeView = this.getSkinnable().getTreeView();
        if (treeView == null) {
            return n6;
        }
        if (this.treeItem == null) {
            return n6;
        }
        final double n7 = computePrefWidth;
        int treeItemLevel = treeView.getTreeItemLevel(this.treeItem);
        if (!treeView.isShowRoot()) {
            --treeItemLevel;
        }
        final double n8 = n7 + this.getIndent() * treeItemLevel;
        final Node disclosureNode = this.getSkinnable().getDisclosureNode();
        return n8 + Math.max(TreeCellSkin.maxDisclosureWidthMap.containsKey(treeView) ? ((double)TreeCellSkin.maxDisclosureWidthMap.get(treeView)) : 0.0, (disclosureNode == null) ? 0.0 : disclosureNode.prefWidth(-1.0));
    }
    
    private void updateTreeItem() {
        this.treeItem = this.getSkinnable().getTreeItem();
    }
    
    private void updateDisclosureNode() {
        if (this.getSkinnable().isEmpty()) {
            return;
        }
        final Node disclosureNode = this.getSkinnable().getDisclosureNode();
        if (disclosureNode == null) {
            return;
        }
        final boolean visible = this.treeItem != null && !this.treeItem.isLeaf();
        disclosureNode.setVisible(visible);
        if (!visible) {
            this.getChildren().remove(disclosureNode);
        }
        else if (disclosureNode.getParent() == null) {
            this.getChildren().add(disclosureNode);
            disclosureNode.toFront();
        }
        else {
            disclosureNode.toBack();
        }
        if (disclosureNode.getScene() != null) {
            disclosureNode.applyCss();
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    static {
        maxDisclosureWidthMap = new WeakHashMap<TreeView<?>, Double>();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TreeCell<?>, Number> INDENT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            INDENT = new CssMetaData<TreeCell<?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)10.0) {
                @Override
                public boolean isSettable(final TreeCell<?> treeCell) {
                    final DoubleProperty indentProperty = ((TreeCellSkin)treeCell.getSkin()).indentProperty();
                    return indentProperty == null || !indentProperty.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TreeCell<?> treeCell) {
                    return (StyleableProperty<Number>)((TreeCellSkin)treeCell.getSkin()).indentProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(CellSkinBase.getClassCssMetaData());
            list.add(StyleableProperties.INDENT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
