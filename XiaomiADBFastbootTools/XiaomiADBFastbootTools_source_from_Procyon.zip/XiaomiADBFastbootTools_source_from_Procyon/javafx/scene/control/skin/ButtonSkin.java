// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.Node;
import javafx.scene.control.SkinBase;
import javafx.scene.Scene;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;
import javafx.scene.control.ContextMenu;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.control.behavior.ButtonBehavior;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.control.Button;

public class ButtonSkin extends LabeledSkinBase<Button>
{
    private KeyCodeCombination defaultAcceleratorKeyCodeCombination;
    private KeyCodeCombination cancelAcceleratorKeyCodeCombination;
    private final BehaviorBase<Button> behavior;
    Runnable defaultButtonRunnable;
    Runnable cancelButtonRunnable;
    
    public ButtonSkin(final Button button) {
        super(button);
        this.defaultButtonRunnable = (() -> {
            if (this.getSkinnable().getScene() != null && NodeHelper.isTreeVisible(((SkinBase<Node>)this).getSkinnable()) && !this.getSkinnable().isDisabled()) {
                this.getSkinnable().fire();
            }
            return;
        });
        this.cancelButtonRunnable = (() -> {
            if (this.getSkinnable().getScene() != null && NodeHelper.isTreeVisible(((SkinBase<Node>)this).getSkinnable()) && !this.getSkinnable().isDisabled()) {
                this.getSkinnable().fire();
            }
            return;
        });
        this.behavior = new ButtonBehavior<Button>(button);
        this.registerChangeListener(button.defaultButtonProperty(), p0 -> this.setDefaultButton(this.getSkinnable().isDefaultButton()));
        this.registerChangeListener(button.cancelButtonProperty(), p0 -> this.setCancelButton(this.getSkinnable().isCancelButton()));
        final ContextMenu contextMenu;
        this.registerChangeListener(button.focusedProperty(), p0 -> {
            if (!this.getSkinnable().isFocused()) {
                this.getSkinnable().getContextMenu();
                if (contextMenu != null && contextMenu.isShowing()) {
                    contextMenu.hide();
                    Utils.removeMnemonics(contextMenu, this.getSkinnable().getScene());
                }
            }
            return;
        });
        this.registerChangeListener(button.parentProperty(), p0 -> {
            if (this.getSkinnable().getParent() == null && this.getSkinnable().getScene() != null) {
                if (this.getSkinnable().isDefaultButton()) {
                    this.getSkinnable().getScene().getAccelerators().remove(this.defaultAcceleratorKeyCodeCombination);
                }
                if (this.getSkinnable().isCancelButton()) {
                    this.getSkinnable().getScene().getAccelerators().remove(this.cancelAcceleratorKeyCodeCombination);
                }
            }
            return;
        });
        if (this.getSkinnable().isDefaultButton()) {
            this.setDefaultButton(true);
        }
        if (this.getSkinnable().isCancelButton()) {
            this.setCancelButton(true);
        }
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    private void setDefaultButton(final boolean b) {
        final Scene scene = this.getSkinnable().getScene();
        if (scene != null) {
            this.defaultAcceleratorKeyCodeCombination = new KeyCodeCombination(KeyCode.ENTER, new KeyCombination.Modifier[0]);
            final Runnable runnable = scene.getAccelerators().get(this.defaultAcceleratorKeyCodeCombination);
            if (!b) {
                if (this.defaultButtonRunnable.equals(runnable)) {
                    scene.getAccelerators().remove(this.defaultAcceleratorKeyCodeCombination);
                }
            }
            else if (!this.defaultButtonRunnable.equals(runnable)) {
                scene.getAccelerators().remove(this.defaultAcceleratorKeyCodeCombination);
                scene.getAccelerators().put(this.defaultAcceleratorKeyCodeCombination, this.defaultButtonRunnable);
            }
        }
    }
    
    private void setCancelButton(final boolean b) {
        final Scene scene = this.getSkinnable().getScene();
        if (scene != null) {
            this.cancelAcceleratorKeyCodeCombination = new KeyCodeCombination(KeyCode.ESCAPE, new KeyCombination.Modifier[0]);
            final Runnable runnable = scene.getAccelerators().get(this.cancelAcceleratorKeyCodeCombination);
            if (!b) {
                if (this.cancelButtonRunnable.equals(runnable)) {
                    scene.getAccelerators().remove(this.cancelAcceleratorKeyCodeCombination);
                }
            }
            else if (!this.cancelButtonRunnable.equals(runnable)) {
                scene.getAccelerators().remove(this.cancelAcceleratorKeyCodeCombination);
                scene.getAccelerators().put(this.cancelAcceleratorKeyCodeCombination, this.cancelButtonRunnable);
            }
        }
    }
}
