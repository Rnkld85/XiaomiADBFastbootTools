// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.control.TreeItem;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.TablePositionBase;
import javafx.scene.control.TableFocusModel;
import javafx.scene.control.TableSelectionModel;
import javafx.collections.FXCollections;
import javafx.scene.control.IndexedCell;
import javafx.scene.control.Control;
import javafx.beans.property.BooleanProperty;
import javafx.scene.control.ResizeFeaturesBase;
import javafx.beans.property.ObjectProperty;
import javafx.scene.control.TreeTableRow;
import javafx.scene.control.TreeTableCell;
import com.sun.javafx.scene.control.TreeTableViewBackingList;
import javafx.scene.Node;
import javafx.util.Callback;
import javafx.collections.ObservableList;
import com.sun.javafx.scene.control.TableColumnBaseHelper;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.scene.layout.Region;
import javafx.scene.control.TableCell;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumnBase;

class TableSkinUtils
{
    private TableSkinUtils() {
    }
    
    public static boolean resizeColumn(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase, final TableColumnBase<?, ?> tableColumnBase, final double n) {
        if (!tableColumnBase.isResizable()) {
            return false;
        }
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return skinnable.resizeColumn((TableColumn)tableColumnBase, n);
        }
        return skinnable instanceof TreeTableView && ((TreeTableView)skinnable).resizeColumn((TreeTableColumn)tableColumnBase, n);
    }
    
    public static void resizeColumnToFitContent(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase, final TableColumnBase<?, ?> tableColumnBase, final int n) {
        if (!tableColumnBase.isResizable()) {
            return;
        }
        final TableView<Object> skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            resizeColumnToFitContent(skinnable, (TableColumn<Object, Object>)tableColumnBase, tableViewSkinBase, n);
        }
        else if (skinnable instanceof TreeTableView) {
            resizeColumnToFitContent((TreeTableView<Object>)skinnable, (TreeTableColumn<Object, Object>)tableColumnBase, tableViewSkinBase, n);
        }
    }
    
    private static <T, S> void resizeColumnToFitContent(final TableView<T> tableView, final TableColumn<T, S> tableColumn, final TableViewSkinBase tableViewSkinBase, final int b) {
        final ObservableList<T> items = tableView.getItems();
        if (items == null || items.isEmpty()) {
            return;
        }
        final Callback<TableColumn<T, S>, TableCell<T, S>> cellFactory = tableColumn.getCellFactory();
        if (cellFactory == null) {
            return;
        }
        final TableCell<T, S> tableCell = cellFactory.call(tableColumn);
        if (tableCell == null) {
            return;
        }
        tableCell.getProperties().put("deferToParentPrefWidth", Boolean.TRUE);
        double n = 10.0;
        final Node node = (tableCell.getSkin() == null) ? null : tableCell.getSkin().getNode();
        if (node instanceof Region) {
            final Region region = (Region)node;
            n = region.snappedLeftInset() + region.snappedRightInset();
        }
        final int n2 = (b == -1) ? items.size() : Math.min(items.size(), b);
        double max = 0.0;
        for (int i = 0; i < n2; ++i) {
            tableCell.updateTableColumn(tableColumn);
            tableCell.updateTableView(tableView);
            tableCell.updateIndex(i);
            if ((tableCell.getText() != null && !tableCell.getText().isEmpty()) || tableCell.getGraphic() != null) {
                tableViewSkinBase.getChildren().add(tableCell);
                tableCell.applyCss();
                max = Math.max(max, tableCell.prefWidth(-1.0));
                tableViewSkinBase.getChildren().remove(tableCell);
            }
        }
        tableCell.updateIndex(-1);
        final TableColumnHeader columnHeader = tableViewSkinBase.getTableHeaderRow().getColumnHeaderFor(tableColumn);
        final double computeTextWidth = Utils.computeTextWidth(columnHeader.label.getFont(), tableColumn.getText(), -1.0);
        final Node graphic = columnHeader.label.getGraphic();
        double maxWidth = Math.max(max, computeTextWidth + ((graphic == null) ? 0.0 : (graphic.prefWidth(-1.0) + columnHeader.label.getGraphicTextGap())) + 10.0 + columnHeader.snappedLeftInset() + columnHeader.snappedRightInset()) + n;
        if (tableView.getColumnResizePolicy() == TableView.CONSTRAINED_RESIZE_POLICY && tableView.getWidth() > 0.0) {
            if (maxWidth > tableColumn.getMaxWidth()) {
                maxWidth = tableColumn.getMaxWidth();
            }
            final int size = tableColumn.getColumns().size();
            if (size > 0) {
                resizeColumnToFitContent(tableViewSkinBase, (TableColumnBase<?, ?>)tableColumn.getColumns().get(size - 1), b);
                return;
            }
            resizeColumn(tableViewSkinBase, tableColumn, (double)Math.round(maxWidth - tableColumn.getWidth()));
        }
        else {
            TableColumnBaseHelper.setWidth(tableColumn, maxWidth);
        }
    }
    
    private static <T, S> void resizeColumnToFitContent(final TreeTableView<T> treeTableView, final TreeTableColumn<T, S> treeTableColumn, final TableViewSkinBase tableViewSkinBase, final int b) {
        final TreeTableViewBackingList list = new TreeTableViewBackingList(treeTableView);
        if (list == null || list.isEmpty()) {
            return;
        }
        final Callback<TreeTableColumn<T, S>, TreeTableCell<T, S>> cellFactory = treeTableColumn.getCellFactory();
        if (cellFactory == null) {
            return;
        }
        final TreeTableCell<T, S> treeTableCell = cellFactory.call(treeTableColumn);
        if (treeTableCell == null) {
            return;
        }
        treeTableCell.getProperties().put("deferToParentPrefWidth", Boolean.TRUE);
        double n = 10.0;
        final Node node = (treeTableCell.getSkin() == null) ? null : treeTableCell.getSkin().getNode();
        if (node instanceof Region) {
            final Region region = (Region)node;
            n = region.snappedLeftInset() + region.snappedRightInset();
        }
        final TreeTableRow<T> treeTableRow = new TreeTableRow<T>();
        treeTableRow.updateTreeTableView(treeTableView);
        final int n2 = (b == -1) ? list.size() : Math.min(list.size(), b);
        double max = 0.0;
        for (int i = 0; i < n2; ++i) {
            treeTableRow.updateIndex(i);
            treeTableRow.updateTreeItem(treeTableView.getTreeItem(i));
            treeTableCell.updateTreeTableColumn(treeTableColumn);
            treeTableCell.updateTreeTableView(treeTableView);
            treeTableCell.updateTreeTableRow(treeTableRow);
            treeTableCell.updateIndex(i);
            if ((treeTableCell.getText() != null && !treeTableCell.getText().isEmpty()) || treeTableCell.getGraphic() != null) {
                tableViewSkinBase.getChildren().add(treeTableCell);
                treeTableCell.applyCss();
                max = Math.max(max, treeTableCell.prefWidth(-1.0));
                tableViewSkinBase.getChildren().remove(treeTableCell);
            }
        }
        treeTableCell.updateIndex(-1);
        final TableColumnHeader columnHeader = tableViewSkinBase.getTableHeaderRow().getColumnHeaderFor(treeTableColumn);
        final double computeTextWidth = Utils.computeTextWidth(columnHeader.label.getFont(), treeTableColumn.getText(), -1.0);
        final Node graphic = columnHeader.label.getGraphic();
        double maxWidth = Math.max(max, computeTextWidth + ((graphic == null) ? 0.0 : (graphic.prefWidth(-1.0) + columnHeader.label.getGraphicTextGap())) + 10.0 + columnHeader.snappedLeftInset() + columnHeader.snappedRightInset()) + n;
        if (treeTableView.getColumnResizePolicy() == TreeTableView.CONSTRAINED_RESIZE_POLICY && treeTableView.getWidth() > 0.0) {
            if (maxWidth > treeTableColumn.getMaxWidth()) {
                maxWidth = treeTableColumn.getMaxWidth();
            }
            final int size = treeTableColumn.getColumns().size();
            if (size > 0) {
                resizeColumnToFitContent(tableViewSkinBase, (TableColumnBase<?, ?>)treeTableColumn.getColumns().get(size - 1), b);
                return;
            }
            resizeColumn(tableViewSkinBase, treeTableColumn, (double)Math.round(maxWidth - treeTableColumn.getWidth()));
        }
        else {
            TableColumnBaseHelper.setWidth(treeTableColumn, maxWidth);
        }
    }
    
    public static ObjectProperty<Callback<ResizeFeaturesBase, Boolean>> columnResizePolicyProperty(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (ObjectProperty<Callback<ResizeFeaturesBase, Boolean>>)skinnable.columnResizePolicyProperty();
        }
        if (skinnable instanceof TreeTableView) {
            return (ObjectProperty<Callback<ResizeFeaturesBase, Boolean>>)((TreeTableView)skinnable).columnResizePolicyProperty();
        }
        return null;
    }
    
    public static BooleanProperty tableMenuButtonVisibleProperty(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return skinnable.tableMenuButtonVisibleProperty();
        }
        if (skinnable instanceof TreeTableView) {
            return ((TreeTableView)skinnable).tableMenuButtonVisibleProperty();
        }
        return null;
    }
    
    public static ObjectProperty<Node> placeholderProperty(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (ObjectProperty<Node>)skinnable.placeholderProperty();
        }
        if (skinnable instanceof TreeTableView) {
            return (ObjectProperty<Node>)((TreeTableView)skinnable).placeholderProperty();
        }
        return null;
    }
    
    public static <C extends Control, I extends IndexedCell<?>> ObjectProperty<Callback<C, I>> rowFactoryProperty(final TableViewSkinBase<?, ?, C, I, ?> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (ObjectProperty<Callback<C, I>>)skinnable.rowFactoryProperty();
        }
        if (skinnable instanceof TreeTableView) {
            return (ObjectProperty<Callback<C, I>>)((TreeTableView)skinnable).rowFactoryProperty();
        }
        return null;
    }
    
    public static ObservableList<TableColumnBase<?, ?>> getSortOrder(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (ObservableList<TableColumnBase<?, ?>>)skinnable.getSortOrder();
        }
        if (skinnable instanceof TreeTableView) {
            return (ObservableList<TableColumnBase<?, ?>>)((TreeTableView)skinnable).getSortOrder();
        }
        return FXCollections.emptyObservableList();
    }
    
    public static ObservableList<TableColumnBase<?, ?>> getColumns(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (ObservableList<TableColumnBase<?, ?>>)skinnable.getColumns();
        }
        if (skinnable instanceof TreeTableView) {
            return (ObservableList<TableColumnBase<?, ?>>)((TreeTableView)skinnable).getColumns();
        }
        return FXCollections.emptyObservableList();
    }
    
    public static <T> TableSelectionModel<T> getSelectionModel(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (TableSelectionModel<T>)skinnable.getSelectionModel();
        }
        if (skinnable instanceof TreeTableView) {
            return (TableSelectionModel<T>)((TreeTableView)skinnable).getSelectionModel();
        }
        return null;
    }
    
    public static <T> TableFocusModel<T, ?> getFocusModel(final TableViewSkinBase<T, ?, ?, ?, ?> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (TableFocusModel<T, ?>)skinnable.getFocusModel();
        }
        if (skinnable instanceof TreeTableView) {
            return (TableFocusModel<T, ?>)((TreeTableView)skinnable).getFocusModel();
        }
        return null;
    }
    
    public static <T, TC extends TableColumnBase<T, ?>> TablePositionBase<? extends TC> getFocusedCell(final TableViewSkinBase<?, T, ?, ?, TC> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (TablePositionBase<? extends TC>)skinnable.getFocusModel().getFocusedCell();
        }
        if (skinnable instanceof TreeTableView) {
            return (TablePositionBase<? extends TC>)((TreeTableView)skinnable).getFocusModel().getFocusedCell();
        }
        return null;
    }
    
    public static <TC extends TableColumnBase<?, ?>> ObservableList<TC> getVisibleLeafColumns(final TableViewSkinBase<?, ?, ?, ?, TC> tableViewSkinBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (ObservableList<TC>)skinnable.getVisibleLeafColumns();
        }
        if (skinnable instanceof TreeTableView) {
            return (ObservableList<TC>)((TreeTableView)skinnable).getVisibleLeafColumns();
        }
        return FXCollections.emptyObservableList();
    }
    
    public static int getVisibleLeafIndex(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase, final TableColumnBase tableColumnBase) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return skinnable.getVisibleLeafIndex((TableColumn)tableColumnBase);
        }
        if (skinnable instanceof TreeTableView) {
            return ((TreeTableView)skinnable).getVisibleLeafIndex((TreeTableColumn)tableColumnBase);
        }
        return -1;
    }
    
    public static <T, TC extends TableColumnBase<T, ?>> TC getVisibleLeafColumn(final TableViewSkinBase<?, T, ?, ?, TC> tableViewSkinBase, final int n) {
        final TableView skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return (TC)skinnable.getVisibleLeafColumn(n);
        }
        if (skinnable instanceof TreeTableView) {
            return (TC)((TreeTableView)skinnable).getVisibleLeafColumn(n);
        }
        return null;
    }
    
    public static <T> ObjectProperty<ObservableList<T>> itemsProperty(final TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase) {
        final TableView<T> skinnable = tableViewSkinBase.getSkinnable();
        if (skinnable instanceof TableView) {
            return skinnable.itemsProperty();
        }
        if (skinnable instanceof TreeTableView && tableViewSkinBase instanceof TreeTableViewSkin) {
            final TreeTableViewSkin treeTableViewSkin = (TreeTableViewSkin)tableViewSkinBase;
            if (treeTableViewSkin.tableBackingListProperty == null) {
                treeTableViewSkin.tableBackingList = (TreeTableViewBackingList<T>)new TreeTableViewBackingList<Object>((TreeTableView<T>)skinnable);
                treeTableViewSkin.tableBackingListProperty = new SimpleObjectProperty<ObservableList<TreeItem<T>>>(treeTableViewSkin.tableBackingList);
            }
            return (ObjectProperty<ObservableList<T>>)treeTableViewSkin.tableBackingListProperty;
        }
        return null;
    }
}
