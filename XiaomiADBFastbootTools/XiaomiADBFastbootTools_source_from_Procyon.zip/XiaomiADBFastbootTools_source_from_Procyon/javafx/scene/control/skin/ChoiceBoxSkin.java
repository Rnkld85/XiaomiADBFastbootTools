// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.event.ActionEvent;
import javafx.beans.Observable;
import javafx.scene.control.Toggle;
import javafx.util.StringConverter;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Separator;
import javafx.scene.text.Text;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.Node;
import javafx.geometry.Side;
import com.sun.javafx.scene.control.ContextMenuContent;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.MenuItem;
import javafx.beans.value.ObservableValue;
import javafx.beans.WeakInvalidationListener;
import com.sun.javafx.scene.control.behavior.ChoiceBoxBehavior;
import java.util.Iterator;
import javafx.beans.InvalidationListener;
import javafx.collections.WeakListChangeListener;
import javafx.collections.ListChangeListener;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionModel;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.StackPane;
import javafx.scene.control.ContextMenu;
import javafx.collections.ObservableList;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.SkinBase;

public class ChoiceBoxSkin<T> extends SkinBase<ChoiceBox<T>>
{
    private ObservableList<T> choiceBoxItems;
    private ContextMenu popup;
    private StackPane openButton;
    private final ToggleGroup toggleGroup;
    private SelectionModel<T> selectionModel;
    private Label label;
    private final BehaviorBase<ChoiceBox<T>> behavior;
    private final ListChangeListener<T> choiceBoxItemsListener;
    private final WeakListChangeListener<T> weakChoiceBoxItemsListener;
    private final InvalidationListener itemsObserver;
    private InvalidationListener selectionChangeListener;
    
    public ChoiceBoxSkin(final ChoiceBox<T> choiceBox) {
        super(choiceBox);
        this.toggleGroup = new ToggleGroup();
        this.choiceBoxItemsListener = new ListChangeListener<T>() {
            @Override
            public void onChanged(final Change<? extends T> change) {
                while (change.next()) {
                    if (change.getRemovedSize() > 0 || change.wasPermutated()) {
                        ChoiceBoxSkin.this.toggleGroup.getToggles().clear();
                        ChoiceBoxSkin.this.popup.getItems().clear();
                        int n = 0;
                        final Iterator<Object> iterator = change.getList().iterator();
                        while (iterator.hasNext()) {
                            ChoiceBoxSkin.this.addPopupItem(iterator.next(), n);
                            ++n;
                        }
                    }
                    else {
                        for (int i = change.getFrom(); i < change.getTo(); ++i) {
                            ChoiceBoxSkin.this.addPopupItem(change.getList().get(i), i);
                        }
                    }
                }
                ChoiceBoxSkin.this.updateSelection();
                ChoiceBoxSkin.this.getSkinnable().requestLayout();
            }
        };
        this.weakChoiceBoxItemsListener = new WeakListChangeListener<T>(this.choiceBoxItemsListener);
        this.selectionChangeListener = (p0 -> this.updateSelection());
        this.behavior = (BehaviorBase<ChoiceBox<T>>)new ChoiceBoxBehavior((ChoiceBox<Object>)choiceBox);
        this.initialize();
        this.itemsObserver = (p0 -> this.updateChoiceBoxItems());
        choiceBox.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver));
        choiceBox.requestLayout();
        this.registerChangeListener(choiceBox.selectionModelProperty(), p0 -> this.updateSelectionModel());
        final SingleSelectionModel singleSelectionModel;
        long n;
        final int n2;
        MenuItem menuItem;
        MenuItem menuItem2;
        ContextMenuContent contextMenuContent;
        double n3 = 0.0;
        this.registerChangeListener(choiceBox.showingProperty(), p0 -> {
            if (this.getSkinnable().isShowing()) {
                this.getSkinnable().getSelectionModel();
                if (singleSelectionModel != null) {
                    n = singleSelectionModel.getSelectedIndex();
                    this.choiceBoxItems.size();
                    if (n >= 0L && n < n2) {
                        menuItem = this.popup.getItems().get((int)n);
                        if (menuItem != null && menuItem instanceof RadioMenuItem) {
                            ((RadioMenuItem)menuItem).setSelected(true);
                        }
                    }
                    else if (n2 > 0) {
                        menuItem2 = this.popup.getItems().get(0);
                    }
                    this.getSkinnable().autosize();
                    if (this.popup.getSkin() != null) {
                        contextMenuContent = (ContextMenuContent)this.popup.getSkin().getNode();
                        if (contextMenuContent != null && n != -1L) {
                            n3 = -contextMenuContent.getMenuYOffset((int)n);
                        }
                    }
                    this.popup.show(this.getSkinnable(), Side.BOTTOM, 2.0, n3);
                }
            }
            else {
                this.popup.hide();
            }
            return;
        });
        this.registerChangeListener(choiceBox.itemsProperty(), p0 -> {
            this.updateChoiceBoxItems();
            this.updatePopupItems();
            this.updateSelectionModel();
            this.updateSelection();
            if (this.selectionModel != null && this.selectionModel.getSelectedIndex() == -1) {
                this.label.setText("");
            }
            return;
        });
        final int n4;
        MenuItem menuItem3;
        this.registerChangeListener(choiceBox.getSelectionModel().selectedItemProperty(), p0 -> {
            if (this.getSkinnable().getSelectionModel() != null) {
                this.getSkinnable().getSelectionModel().getSelectedIndex();
                if (n4 != -1) {
                    menuItem3 = this.popup.getItems().get(n4);
                    if (menuItem3 instanceof RadioMenuItem) {
                        ((RadioMenuItem)menuItem3).setSelected(true);
                    }
                }
            }
            return;
        });
        this.registerChangeListener(choiceBox.converterProperty(), p0 -> {
            this.updateChoiceBoxItems();
            this.updatePopupItems();
        });
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        final double prefWidth = this.openButton.prefWidth(-1.0);
        this.label.resizeRelocate(n, n2, n3, n4);
        this.openButton.resize(prefWidth, this.openButton.prefHeight(-1.0));
        this.positionInArea(this.openButton, n + n3 - prefWidth, n2, prefWidth, n4, 0.0, HPos.CENTER, VPos.CENTER);
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n5 + Math.max(this.label.minWidth(-1.0) + this.openButton.minWidth(-1.0), this.popup.minWidth(-1.0)) + n3;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n2 + Math.max(this.label.minHeight(-1.0), this.openButton.minHeight(-1.0)) + n4;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final double a = this.label.prefWidth(-1.0) + this.openButton.prefWidth(-1.0);
        double b = this.popup.prefWidth(-1.0);
        if (b <= 0.0 && this.popup.getItems().size() > 0) {
            b = new Text(this.popup.getItems().get(0).getText()).prefWidth(-1.0);
        }
        return (this.popup.getItems().size() == 0) ? 50.0 : (n5 + Math.max(a, b) + n3);
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n2 + Math.max(this.label.prefHeight(-1.0), this.openButton.prefHeight(-1.0)) + n4;
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefHeight(n);
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefWidth(n);
    }
    
    private void initialize() {
        this.updateChoiceBoxItems();
        (this.label = new Label()).setMnemonicParsing(false);
        this.openButton = new StackPane();
        this.openButton.getStyleClass().setAll("open-button");
        final StackPane stackPane = new StackPane();
        stackPane.getStyleClass().setAll("arrow");
        this.openButton.getChildren().clear();
        this.openButton.getChildren().addAll(stackPane);
        this.popup = new ContextMenu();
        this.popup.showingProperty().addListener((p0, p1, b) -> {
            if (!b) {
                this.getSkinnable().hide();
            }
            return;
        });
        this.popup.setId("choice-box-popup-menu");
        this.getChildren().setAll(this.label, this.openButton);
        this.updatePopupItems();
        this.updateSelectionModel();
        this.updateSelection();
        if (this.selectionModel != null && this.selectionModel.getSelectedIndex() == -1) {
            this.label.setText("");
        }
    }
    
    private void updateChoiceBoxItems() {
        if (this.choiceBoxItems != null) {
            this.choiceBoxItems.removeListener(this.weakChoiceBoxItemsListener);
        }
        this.choiceBoxItems = this.getSkinnable().getItems();
        if (this.choiceBoxItems != null) {
            this.choiceBoxItems.addListener(this.weakChoiceBoxItemsListener);
        }
    }
    
    String getChoiceBoxSelectedText() {
        return this.label.getText();
    }
    
    private void addPopupItem(final T t, final int n) {
        SeparatorMenuItem separatorMenuItem;
        if (t instanceof Separator) {
            separatorMenuItem = new SeparatorMenuItem();
        }
        else if (t instanceof SeparatorMenuItem) {
            separatorMenuItem = (SeparatorMenuItem)t;
        }
        else {
            final StringConverter<T> converter = this.getSkinnable().getConverter();
            final RadioMenuItem radioMenuItem = new RadioMenuItem((converter == null) ? ((t == null) ? "" : t.toString()) : converter.toString(t));
            radioMenuItem.setId("choice-box-menu-item");
            radioMenuItem.setToggleGroup(this.toggleGroup);
            final RadioMenuItem radioMenuItem2;
            radioMenuItem.setOnAction(p2 -> {
                if (this.selectionModel == null) {
                    return;
                }
                else {
                    this.selectionModel.select(this.getSkinnable().getItems().indexOf(t));
                    radioMenuItem2.setSelected(true);
                    return;
                }
            });
            separatorMenuItem = (SeparatorMenuItem)radioMenuItem;
        }
        separatorMenuItem.setMnemonicParsing(false);
        this.popup.getItems().add(n, separatorMenuItem);
    }
    
    private void updatePopupItems() {
        this.toggleGroup.getToggles().clear();
        this.popup.getItems().clear();
        this.toggleGroup.selectToggle(null);
        for (int i = 0; i < this.choiceBoxItems.size(); ++i) {
            this.addPopupItem((T)this.choiceBoxItems.get(i), i);
        }
    }
    
    private void updateSelectionModel() {
        if (this.selectionModel != null) {
            this.selectionModel.selectedIndexProperty().removeListener(this.selectionChangeListener);
        }
        this.selectionModel = (SelectionModel<T>)this.getSkinnable().getSelectionModel();
        if (this.selectionModel != null) {
            this.selectionModel.selectedIndexProperty().addListener(this.selectionChangeListener);
        }
    }
    
    private void updateSelection() {
        if (this.selectionModel == null || this.selectionModel.isEmpty()) {
            this.toggleGroup.selectToggle(null);
            this.label.setText("");
        }
        else {
            final int selectedIndex = this.selectionModel.getSelectedIndex();
            if (selectedIndex == -1 || selectedIndex > this.popup.getItems().size()) {
                this.label.setText("");
                return;
            }
            if (selectedIndex < this.popup.getItems().size()) {
                final MenuItem menuItem = this.popup.getItems().get(selectedIndex);
                if (menuItem instanceof RadioMenuItem) {
                    ((RadioMenuItem)menuItem).setSelected(true);
                    this.toggleGroup.selectToggle(null);
                }
                this.label.setText(((MenuItem)this.popup.getItems().get(selectedIndex)).getText());
            }
        }
    }
}
