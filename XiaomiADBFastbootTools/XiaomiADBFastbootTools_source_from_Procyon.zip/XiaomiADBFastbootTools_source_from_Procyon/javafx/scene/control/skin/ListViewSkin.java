// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import com.sun.javafx.scene.control.skin.resources.ControlResources;
import java.security.AccessController;
import javafx.beans.Observable;
import javafx.scene.control.FocusModel;
import javafx.scene.control.Label;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.AccessibleAction;
import java.util.Iterator;
import java.util.Collection;
import javafx.collections.FXCollections;
import java.util.ArrayList;
import javafx.scene.AccessibleAttribute;
import javafx.collections.ObservableMap;
import javafx.event.EventHandler;
import javafx.beans.value.ObservableValue;
import javafx.beans.WeakInvalidationListener;
import javafx.scene.input.MouseEvent;
import javafx.geometry.Orientation;
import javafx.collections.WeakListChangeListener;
import javafx.collections.ListChangeListener;
import javafx.collections.MapChangeListener;
import com.sun.javafx.scene.control.behavior.ListViewBehavior;
import javafx.beans.InvalidationListener;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;

public class ListViewSkin<T> extends VirtualContainerBase<ListView<T>, ListCell<T>>
{
    private static final boolean IS_PANNABLE;
    private static final String EMPTY_LIST_TEXT;
    private final VirtualFlow<ListCell<T>> flow;
    private StackPane placeholderRegion;
    private Node placeholderNode;
    private ObservableList<T> listViewItems;
    private final InvalidationListener itemsChangeListener;
    private boolean needCellsRebuilt;
    private boolean needCellsReconfigured;
    private int itemCount;
    private ListViewBehavior<T> behavior;
    private MapChangeListener<Object, Object> propertiesMapListener;
    private final ListChangeListener<T> listViewItemsListener;
    private final WeakListChangeListener<T> weakListViewItemsListener;
    
    public ListViewSkin(final ListView<T> listView) {
        super(listView);
        this.itemsChangeListener = (p0 -> this.updateListViewItems());
        this.needCellsRebuilt = true;
        this.needCellsReconfigured = false;
        this.itemCount = -1;
        this.propertiesMapListener = (change -> {
            if (!change.wasAdded()) {
                return;
            }
            else {
                if ("recreateKey".equals(change.getKey())) {
                    this.needCellsRebuilt = true;
                    this.getSkinnable().requestLayout();
                    this.getSkinnable().getProperties().remove("recreateKey");
                }
                return;
            }
        });
        this.listViewItemsListener = new ListChangeListener<T>() {
            @Override
            public void onChanged(final Change<? extends T> change) {
                while (change.next()) {
                    if (change.wasReplaced()) {
                        for (int i = change.getFrom(); i < change.getTo(); ++i) {
                            ListViewSkin.this.flow.setCellDirty(i);
                        }
                        break;
                    }
                    if (change.getRemovedSize() == ListViewSkin.this.itemCount) {
                        ListViewSkin.this.itemCount = 0;
                        break;
                    }
                }
                ListViewSkin.this.getSkinnable().edit(-1);
                ListViewSkin.this.markItemCountDirty();
                ListViewSkin.this.getSkinnable().requestLayout();
            }
        };
        this.weakListViewItemsListener = new WeakListChangeListener<T>(this.listViewItemsListener);
        (this.behavior = new ListViewBehavior<T>(listView)).setOnFocusPreviousRow(() -> this.onFocusPreviousCell());
        this.behavior.setOnFocusNextRow(() -> this.onFocusNextCell());
        this.behavior.setOnMoveToFirstCell(() -> this.onMoveToFirstCell());
        this.behavior.setOnMoveToLastCell(() -> this.onMoveToLastCell());
        this.behavior.setOnSelectPreviousRow(() -> this.onSelectPreviousCell());
        this.behavior.setOnSelectNextRow(() -> this.onSelectNextCell());
        this.behavior.setOnScrollPageDown(this::onScrollPageDown);
        this.behavior.setOnScrollPageUp(this::onScrollPageUp);
        this.updateListViewItems();
        (this.flow = this.getVirtualFlow()).setId("virtual-flow");
        this.flow.setPannable(ListViewSkin.IS_PANNABLE);
        this.flow.setVertical(listView.getOrientation() == Orientation.VERTICAL);
        this.flow.setCellFactory(p0 -> this.createCell());
        this.flow.setFixedCellSize(listView.getFixedCellSize());
        this.getChildren().add(this.flow);
        final EventHandler<? super MouseEvent> eventHandler = p1 -> {
            if (listView.getEditingIndex() > -1) {
                listView.edit(-1);
            }
            if (listView.isFocusTraversable()) {
                listView.requestFocus();
            }
            return;
        };
        this.flow.getVbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        this.flow.getHbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        this.updateItemCount();
        listView.itemsProperty().addListener(new WeakInvalidationListener(this.itemsChangeListener));
        final ObservableMap<Object, Object> properties = listView.getProperties();
        properties.remove("recreateKey");
        properties.addListener(this.propertiesMapListener);
        this.registerChangeListener(listView.itemsProperty(), p0 -> this.updateListViewItems());
        this.registerChangeListener(listView.orientationProperty(), p1 -> this.flow.setVertical(listView.getOrientation() == Orientation.VERTICAL));
        this.registerChangeListener(listView.cellFactoryProperty(), p0 -> this.flow.recreateCells());
        this.registerChangeListener(listView.parentProperty(), p1 -> {
            if (listView.getParent() != null && listView.isVisible()) {
                listView.requestLayout();
            }
            return;
        });
        this.registerChangeListener(listView.placeholderProperty(), p0 -> this.updatePlaceholderRegionVisibility());
        this.registerChangeListener(listView.fixedCellSizeProperty(), p1 -> this.flow.setFixedCellSize(listView.getFixedCellSize()));
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        super.layoutChildren(n, n2, n3, n4);
        if (this.needCellsRebuilt) {
            this.flow.rebuildCells();
        }
        else if (this.needCellsReconfigured) {
            this.flow.reconfigureCells();
        }
        this.needCellsRebuilt = false;
        this.needCellsReconfigured = false;
        if (this.getItemCount() == 0) {
            if (this.placeholderRegion != null) {
                this.placeholderRegion.setVisible(n3 > 0.0 && n4 > 0.0);
                this.placeholderRegion.resizeRelocate(n, n2, n3, n4);
            }
        }
        else {
            this.flow.resizeRelocate(n, n2, n3, n4);
        }
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        this.checkState();
        if (this.getItemCount() == 0) {
            if (this.placeholderRegion == null) {
                this.updatePlaceholderRegionVisibility();
            }
            if (this.placeholderRegion != null) {
                return this.placeholderRegion.prefWidth(n) + n5 + n3;
            }
        }
        return this.computePrefHeight(-1.0, n2, n3, n4, n5) * 0.618033987;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return 400.0;
    }
    
    @Override
    protected int getItemCount() {
        return this.itemCount;
    }
    
    @Override
    protected void updateItemCount() {
        if (this.flow == null) {
            return;
        }
        final int itemCount = this.itemCount;
        final int n = (this.listViewItems == null) ? 0 : this.listViewItems.size();
        this.itemCount = n;
        this.flow.setCellCount(n);
        this.updatePlaceholderRegionVisibility();
        if (n != itemCount) {
            this.requestRebuildCells();
        }
        else {
            this.needCellsReconfigured = true;
        }
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case FOCUS_ITEM: {
                int focusedIndex = this.getSkinnable().getFocusModel().getFocusedIndex();
                if (focusedIndex == -1) {
                    if (this.placeholderRegion != null && this.placeholderRegion.isVisible()) {
                        return this.placeholderRegion.getChildren().get(0);
                    }
                    if (this.getItemCount() <= 0) {
                        return null;
                    }
                    focusedIndex = 0;
                }
                return this.flow.getPrivateCell(focusedIndex);
            }
            case ITEM_COUNT: {
                return this.getItemCount();
            }
            case ITEM_AT_INDEX: {
                final Integer n = (Integer)array[0];
                if (n == null) {
                    return null;
                }
                if (0 <= n && n < this.getItemCount()) {
                    return this.flow.getPrivateCell(n);
                }
                return null;
            }
            case SELECTED_ITEMS: {
                final ObservableList selectedIndices = this.getSkinnable().getSelectionModel().getSelectedIndices();
                final ArrayList list = new ArrayList<ListCell<T>>(selectedIndices.size());
                final Iterator<Integer> iterator = selectedIndices.iterator();
                while (iterator.hasNext()) {
                    final ListCell<T> listCell = this.flow.getPrivateCell(iterator.next());
                    if (listCell != null) {
                        list.add(listCell);
                    }
                }
                return FXCollections.observableArrayList((Collection<?>)list);
            }
            case VERTICAL_SCROLLBAR: {
                return this.flow.getVbar();
            }
            case HORIZONTAL_SCROLLBAR: {
                return this.flow.getHbar();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    protected void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case SHOW_ITEM: {
                final Node node = (Node)array[0];
                if (node instanceof ListCell) {
                    this.flow.scrollTo(((ListCell)node).getIndex());
                    break;
                }
                break;
            }
            case SET_SELECTED_ITEMS: {
                final ObservableList list = (ObservableList)array[0];
                if (list != null) {
                    final MultipleSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
                    if (selectionModel != null) {
                        selectionModel.clearSelection();
                        for (final Node node2 : list) {
                            if (node2 instanceof ListCell) {
                                selectionModel.select(((ListCell)node2).getIndex());
                            }
                        }
                    }
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    private ListCell<T> createCell() {
        ListCell<?> defaultCellImpl;
        if (this.getSkinnable().getCellFactory() != null) {
            defaultCellImpl = this.getSkinnable().getCellFactory().call(this.getSkinnable());
        }
        else {
            defaultCellImpl = createDefaultCellImpl();
        }
        defaultCellImpl.updateListView(this.getSkinnable());
        return (ListCell<T>)defaultCellImpl;
    }
    
    private void updateListViewItems() {
        if (this.listViewItems != null) {
            this.listViewItems.removeListener(this.weakListViewItemsListener);
        }
        this.listViewItems = this.getSkinnable().getItems();
        if (this.listViewItems != null) {
            this.listViewItems.addListener(this.weakListViewItemsListener);
        }
        this.markItemCountDirty();
        this.getSkinnable().requestLayout();
    }
    
    private final void updatePlaceholderRegionVisibility() {
        final boolean visible = this.getItemCount() == 0;
        if (visible) {
            this.placeholderNode = this.getSkinnable().getPlaceholder();
            if (this.placeholderNode == null && ListViewSkin.EMPTY_LIST_TEXT != null && !ListViewSkin.EMPTY_LIST_TEXT.isEmpty()) {
                this.placeholderNode = new Label();
                ((Label)this.placeholderNode).setText(ListViewSkin.EMPTY_LIST_TEXT);
            }
            if (this.placeholderNode != null) {
                if (this.placeholderRegion == null) {
                    this.placeholderRegion = new StackPane();
                    this.placeholderRegion.getStyleClass().setAll("placeholder");
                    this.getChildren().add(this.placeholderRegion);
                }
                this.placeholderRegion.getChildren().setAll(this.placeholderNode);
            }
        }
        this.flow.setVisible(!visible);
        if (this.placeholderRegion != null) {
            this.placeholderRegion.setVisible(visible);
        }
    }
    
    private static <T> ListCell<T> createDefaultCellImpl() {
        return new ListCell<T>() {
            public void updateItem(final T t, final boolean b) {
                super.updateItem(t, b);
                if (b) {
                    this.setText(null);
                    this.setGraphic(null);
                }
                else if (t instanceof Node) {
                    this.setText(null);
                    final Node graphic = this.getGraphic();
                    final Node node = (Node)t;
                    if (graphic == null || !graphic.equals(node)) {
                        this.setGraphic(node);
                    }
                }
                else {
                    this.setText((t == null) ? "null" : t.toString());
                    this.setGraphic(null);
                }
            }
        };
    }
    
    private void onFocusPreviousCell() {
        final FocusModel focusModel = this.getSkinnable().getFocusModel();
        if (focusModel == null) {
            return;
        }
        this.flow.scrollTo(focusModel.getFocusedIndex());
    }
    
    private void onFocusNextCell() {
        final FocusModel focusModel = this.getSkinnable().getFocusModel();
        if (focusModel == null) {
            return;
        }
        this.flow.scrollTo(focusModel.getFocusedIndex());
    }
    
    private void onSelectPreviousCell() {
        final MultipleSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
        if (selectionModel == null) {
            return;
        }
        final int selectedIndex = selectionModel.getSelectedIndex();
        this.flow.scrollTo(selectedIndex);
        final ListCell<T> firstVisibleCell = this.flow.getFirstVisibleCell();
        if (firstVisibleCell == null || selectedIndex < firstVisibleCell.getIndex()) {
            this.flow.setPosition(selectedIndex / (double)this.getItemCount());
        }
    }
    
    private void onSelectNextCell() {
        final MultipleSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
        if (selectionModel == null) {
            return;
        }
        final int selectedIndex = selectionModel.getSelectedIndex();
        this.flow.scrollTo(selectedIndex);
        final ListCell<T> listCell = this.flow.getLastVisibleCell();
        if (listCell == null || listCell.getIndex() < selectedIndex) {
            this.flow.setPosition(selectedIndex / (double)this.getItemCount());
        }
    }
    
    private void onMoveToFirstCell() {
        this.flow.scrollTo(0);
        this.flow.setPosition(0.0);
    }
    
    private void onMoveToLastCell() {
        this.flow.scrollTo(this.getItemCount() - 1);
        this.flow.setPosition(1.0);
    }
    
    private int onScrollPageDown(final boolean b) {
        ListCell<T> listCell = this.flow.getLastVisibleCellWithinViewPort();
        if (listCell == null) {
            return -1;
        }
        final MultipleSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
        final FocusModel focusModel = this.getSkinnable().getFocusModel();
        if (selectionModel == null || focusModel == null) {
            return -1;
        }
        final int index = listCell.getIndex();
        boolean b2;
        if (b) {
            b2 = (listCell.isFocused() || focusModel.isFocused(index));
        }
        else {
            b2 = (listCell.isSelected() || selectionModel.isSelected(index));
        }
        if (b2 && ((b && focusModel.getFocusedIndex() == index) || (!b && selectionModel.getSelectedIndex() == index))) {
            this.flow.scrollToTop(listCell);
            final ListCell<T> listCell2 = this.flow.getLastVisibleCellWithinViewPort();
            listCell = ((listCell2 == null) ? listCell : listCell2);
        }
        final int index2 = listCell.getIndex();
        this.flow.scrollTo(listCell);
        return index2;
    }
    
    private int onScrollPageUp(final boolean b) {
        ListCell<T> listCell = this.flow.getFirstVisibleCellWithinViewPort();
        if (listCell == null) {
            return -1;
        }
        final MultipleSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
        final FocusModel focusModel = this.getSkinnable().getFocusModel();
        if (selectionModel == null || focusModel == null) {
            return -1;
        }
        final int index = listCell.getIndex();
        boolean b2;
        if (b) {
            b2 = (listCell.isFocused() || focusModel.isFocused(index));
        }
        else {
            b2 = (listCell.isSelected() || selectionModel.isSelected(index));
        }
        if (b2 && ((b && focusModel.getFocusedIndex() == index) || (!b && selectionModel.getSelectedIndex() == index))) {
            this.flow.scrollToBottom(listCell);
            final ListCell<T> listCell2 = this.flow.getFirstVisibleCellWithinViewPort();
            listCell = ((listCell2 == null) ? listCell : listCell2);
        }
        final int index2 = listCell.getIndex();
        this.flow.scrollTo(listCell);
        return index2;
    }
    
    static {
        IS_PANNABLE = AccessController.doPrivileged(() -> Boolean.getBoolean("javafx.scene.control.skin.ListViewSkin.pannable"));
        EMPTY_LIST_TEXT = ControlResources.getString("ListView.noContent");
    }
}
