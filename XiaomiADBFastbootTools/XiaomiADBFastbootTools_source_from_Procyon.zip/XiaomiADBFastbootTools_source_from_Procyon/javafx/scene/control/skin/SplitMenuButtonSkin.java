// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import com.sun.javafx.scene.control.behavior.MenuButtonBehaviorBase;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import com.sun.javafx.scene.control.behavior.SplitMenuButtonBehavior;
import javafx.scene.control.SplitMenuButton;

public class SplitMenuButtonSkin extends MenuButtonSkinBase<SplitMenuButton>
{
    private final SplitMenuButtonBehavior behavior;
    
    public SplitMenuButtonSkin(final SplitMenuButton labelFor) {
        super(labelFor);
        this.behavior = new SplitMenuButtonBehavior(labelFor);
        this.behaveLikeButton = true;
        this.arrowButton.addEventHandler(MouseEvent.ANY, mouseEvent -> mouseEvent.consume());
        this.arrowButton.setOnMousePressed(mouseEvent2 -> {
            this.getBehavior().mousePressed(mouseEvent2, false);
            mouseEvent2.consume();
            return;
        });
        this.arrowButton.setOnMouseReleased(mouseEvent3 -> {
            this.getBehavior().mouseReleased(mouseEvent3, false);
            mouseEvent3.consume();
            return;
        });
        this.label.setLabelFor(labelFor);
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    SplitMenuButtonBehavior getBehavior() {
        return this.behavior;
    }
}
