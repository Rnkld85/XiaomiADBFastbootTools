// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import java.util.Collections;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.scene.control.ContextMenu;
import java.util.Iterator;
import javafx.scene.control.TableColumn;
import java.util.ArrayList;
import javafx.geometry.Pos;
import java.util.Locale;
import javafx.scene.layout.Priority;
import com.sun.javafx.scene.control.TableColumnSortTypeWrapper;
import javafx.geometry.Insets;
import javafx.scene.layout.GridPane;
import com.sun.javafx.scene.control.Properties;
import javafx.collections.ObservableList;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import java.util.List;
import com.sun.javafx.scene.control.TableColumnBaseHelper;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.scene.AccessibleRole;
import javafx.beans.value.ObservableValue;
import java.util.Collection;
import javafx.css.PseudoClass;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.DoubleProperty;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.collections.WeakListChangeListener;
import javafx.scene.control.TableColumnBase;
import javafx.collections.ListChangeListener;
import com.sun.javafx.scene.control.LambdaMultiplePropertyChangeListenerHandler;
import javafx.scene.Node;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;

public class TableColumnHeader extends Region
{
    static final String DEFAULT_STYLE_CLASS = "column-header";
    static final double DEFAULT_COLUMN_WIDTH = 80.0;
    private boolean autoSizeComplete;
    private double dragOffset;
    private NestedTableColumnHeader nestedColumnHeader;
    private TableHeaderRow tableHeaderRow;
    private NestedTableColumnHeader parentHeader;
    Label label;
    int sortPos;
    private Region arrow;
    private Label sortOrderLabel;
    private HBox sortOrderDots;
    private Node sortArrow;
    private boolean isSortColumn;
    private boolean isSizeDirty;
    boolean isLastVisibleColumn;
    int columnIndex;
    private int newColumnPos;
    Region columnReorderLine;
    final LambdaMultiplePropertyChangeListenerHandler changeListenerHandler;
    private ListChangeListener<TableColumnBase<?, ?>> sortOrderListener;
    private ListChangeListener<TableColumnBase<?, ?>> visibleLeafColumnsListener;
    private ListChangeListener<String> styleClassListener;
    private WeakListChangeListener<TableColumnBase<?, ?>> weakSortOrderListener;
    private final WeakListChangeListener<TableColumnBase<?, ?>> weakVisibleLeafColumnsListener;
    private final WeakListChangeListener<String> weakStyleClassListener;
    private static final EventHandler<MouseEvent> mousePressedHandler;
    private static final EventHandler<MouseEvent> mouseDraggedHandler;
    private static final EventHandler<MouseEvent> mouseReleasedHandler;
    private static final EventHandler<ContextMenuEvent> contextMenuRequestedHandler;
    private DoubleProperty size;
    private ReadOnlyObjectWrapper<TableColumnBase<?, ?>> tableColumn;
    private static final PseudoClass PSEUDO_CLASS_LAST_VISIBLE;
    
    public TableColumnHeader(final TableColumnBase tableColumn) {
        this.autoSizeComplete = false;
        this.sortPos = -1;
        this.isSizeDirty = false;
        this.isLastVisibleColumn = false;
        this.columnIndex = -1;
        this.sortOrderListener = (p0 -> this.updateSortPosition());
        this.visibleLeafColumnsListener = (p0 -> {
            this.updateColumnIndex();
            this.updateSortPosition();
            return;
        });
        this.styleClassListener = (change -> {
            while (change.next()) {
                if (change.wasRemoved()) {
                    this.getStyleClass().removeAll(change.getRemoved());
                }
                if (change.wasAdded()) {
                    this.getStyleClass().addAll((Collection<?>)change.getAddedSubList());
                }
            }
            return;
        });
        this.weakSortOrderListener = new WeakListChangeListener<TableColumnBase<?, ?>>(this.sortOrderListener);
        this.weakVisibleLeafColumnsListener = new WeakListChangeListener<TableColumnBase<?, ?>>(this.visibleLeafColumnsListener);
        this.weakStyleClassListener = new WeakListChangeListener<String>(this.styleClassListener);
        this.tableColumn = new ReadOnlyObjectWrapper<TableColumnBase<?, ?>>(this, "tableColumn");
        this.setTableColumn(tableColumn);
        this.setFocusTraversable(false);
        this.initStyleClasses();
        this.initUI();
        (this.changeListenerHandler = new LambdaMultiplePropertyChangeListenerHandler()).registerChangeListener(this.sceneProperty(), p0 -> this.updateScene());
        if (this.getTableColumn() != null) {
            this.changeListenerHandler.registerChangeListener(tableColumn.idProperty(), p1 -> this.setId(tableColumn.getId()));
            this.changeListenerHandler.registerChangeListener(tableColumn.styleProperty(), p1 -> this.setStyle(tableColumn.getStyle()));
            this.changeListenerHandler.registerChangeListener(tableColumn.widthProperty(), p0 -> {
                this.isSizeDirty = true;
                this.requestLayout();
                return;
            });
            this.changeListenerHandler.registerChangeListener(tableColumn.visibleProperty(), p0 -> this.setVisible(this.getTableColumn().isVisible()));
            this.changeListenerHandler.registerChangeListener(tableColumn.sortNodeProperty(), p0 -> this.updateSortGrid());
            this.changeListenerHandler.registerChangeListener(tableColumn.sortableProperty(), p0 -> {
                if (TableSkinUtils.getSortOrder(this.getTableSkin()).contains(this.getTableColumn())) {
                    this.updateAllHeaders(this.getTableHeaderRow().getRootHeader());
                }
                return;
            });
            this.changeListenerHandler.registerChangeListener(tableColumn.textProperty(), p1 -> this.label.setText(tableColumn.getText()));
            this.changeListenerHandler.registerChangeListener(tableColumn.graphicProperty(), p1 -> this.label.setGraphic(tableColumn.getGraphic()));
            this.setId(tableColumn.getId());
            this.setStyle(tableColumn.getStyle());
            this.setAccessibleRole(AccessibleRole.TABLE_COLUMN);
        }
    }
    
    private final double getSize() {
        return (this.size == null) ? 20.0 : this.size.doubleValue();
    }
    
    private final DoubleProperty sizeProperty() {
        if (this.size == null) {
            this.size = new StyleableDoubleProperty(20.0) {
                @Override
                protected void invalidated() {
                    if (this.get() <= 0.0) {
                        if (this.isBound()) {
                            this.unbind();
                        }
                        this.set(20.0);
                        throw new IllegalArgumentException("Size cannot be 0 or negative");
                    }
                }
                
                @Override
                public Object getBean() {
                    return TableColumnHeader.this;
                }
                
                @Override
                public String getName() {
                    return "size";
                }
                
                @Override
                public CssMetaData<TableColumnHeader, Number> getCssMetaData() {
                    return StyleableProperties.SIZE;
                }
            };
        }
        return this.size;
    }
    
    private final void setTableColumn(final TableColumnBase<?, ?> tableColumnBase) {
        this.tableColumn.set(tableColumnBase);
    }
    
    public final TableColumnBase<?, ?> getTableColumn() {
        return this.tableColumn.get();
    }
    
    public final ReadOnlyObjectProperty<TableColumnBase<?, ?>> tableColumnProperty() {
        return this.tableColumn.getReadOnlyProperty();
    }
    
    @Override
    protected void layoutChildren() {
        if (this.isSizeDirty) {
            this.resize(this.getTableColumn().getWidth(), this.getHeight());
            this.isSizeDirty = false;
        }
        double prefWidth = 0.0;
        final double n = this.snapSizeX(this.getWidth()) - (this.snappedLeftInset() + this.snappedRightInset());
        final double n2 = this.getHeight() - (this.snappedTopInset() + this.snappedBottomInset());
        final double n3 = n;
        if (this.arrow != null) {
            this.arrow.setMaxSize(this.arrow.prefWidth(-1.0), this.arrow.prefHeight(-1.0));
        }
        if (this.sortArrow != null && this.sortArrow.isVisible()) {
            prefWidth = this.sortArrow.prefWidth(-1.0);
            final double n4 = n3 - prefWidth;
            this.sortArrow.resize(prefWidth, this.sortArrow.prefHeight(-1.0));
            this.positionInArea(this.sortArrow, n4, this.snappedTopInset(), prefWidth, n2, 0.0, HPos.CENTER, VPos.CENTER);
        }
        if (this.label != null) {
            this.label.resizeRelocate(this.snappedLeftInset(), 0.0, n - prefWidth, this.getHeight());
        }
    }
    
    @Override
    protected double computePrefWidth(final double n) {
        if (this.getNestedColumnHeader() != null) {
            final double prefWidth = this.getNestedColumnHeader().prefWidth(n);
            if (this.getTableColumn() != null) {
                TableColumnBaseHelper.setWidth(this.getTableColumn(), prefWidth);
            }
            return prefWidth;
        }
        if (this.getTableColumn() != null && this.getTableColumn().isVisible()) {
            return this.snapSizeX(this.getTableColumn().getWidth());
        }
        return 0.0;
    }
    
    @Override
    protected double computeMinHeight(final double n) {
        return (this.label == null) ? 0.0 : this.label.minHeight(n);
    }
    
    @Override
    protected double computePrefHeight(final double n) {
        if (this.getTableColumn() == null) {
            return 0.0;
        }
        return Math.max(this.getSize(), this.label.prefHeight(-1.0));
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case INDEX: {
                return this.getIndex(this.getTableColumn());
            }
            case TEXT: {
                return (this.getTableColumn() != null) ? this.getTableColumn().getText() : null;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    void initStyleClasses() {
        this.getStyleClass().setAll("column-header");
        this.installTableColumnStyleClassListener();
    }
    
    void installTableColumnStyleClassListener() {
        final TableColumnBase<?, ?> tableColumn = this.getTableColumn();
        if (tableColumn != null) {
            this.getStyleClass().addAll((Collection<?>)tableColumn.getStyleClass());
            tableColumn.getStyleClass().addListener(this.weakStyleClassListener);
        }
    }
    
    NestedTableColumnHeader getNestedColumnHeader() {
        return this.nestedColumnHeader;
    }
    
    void setNestedColumnHeader(final NestedTableColumnHeader nestedColumnHeader) {
        this.nestedColumnHeader = nestedColumnHeader;
    }
    
    TableHeaderRow getTableHeaderRow() {
        return this.tableHeaderRow;
    }
    
    void setTableHeaderRow(final TableHeaderRow tableHeaderRow) {
        this.tableHeaderRow = tableHeaderRow;
        this.updateTableSkin();
    }
    
    private void updateTableSkin() {
        final TableViewSkinBase<?, ?, ?, ?, ?> tableSkin = this.getTableSkin();
        if (tableSkin == null) {
            return;
        }
        this.updateColumnIndex();
        this.columnReorderLine = tableSkin.getColumnReorderLine();
        if (this.getTableColumn() != null) {
            this.updateSortPosition();
            TableSkinUtils.getSortOrder(tableSkin).addListener(this.weakSortOrderListener);
            TableSkinUtils.getVisibleLeafColumns(tableSkin).addListener((ListChangeListener<? super TableColumnBase>)this.weakVisibleLeafColumnsListener);
        }
    }
    
    TableViewSkinBase<?, ?, ?, ?, ?> getTableSkin() {
        return (this.tableHeaderRow == null) ? null : this.tableHeaderRow.tableSkin;
    }
    
    NestedTableColumnHeader getParentHeader() {
        return this.parentHeader;
    }
    
    void setParentHeader(final NestedTableColumnHeader parentHeader) {
        this.parentHeader = parentHeader;
    }
    
    private void updateAllHeaders(final TableColumnHeader tableColumnHeader) {
        if (tableColumnHeader instanceof NestedTableColumnHeader) {
            final ObservableList<TableColumnHeader> columnHeaders = ((NestedTableColumnHeader)tableColumnHeader).getColumnHeaders();
            for (int i = 0; i < columnHeaders.size(); ++i) {
                this.updateAllHeaders((TableColumnHeader)columnHeaders.get(i));
            }
        }
        else {
            tableColumnHeader.updateSortPosition();
        }
    }
    
    private void updateScene() {
        if (!this.autoSizeComplete) {
            if (this.getTableColumn() == null || this.getTableColumn().getWidth() != 80.0 || this.getScene() == null) {
                return;
            }
            this.doColumnAutoSize(this.getTableColumn(), 30);
            this.autoSizeComplete = true;
        }
    }
    
    void dispose() {
        final TableViewSkinBase<?, ?, ?, ?, ?> tableSkin = this.getTableSkin();
        if (tableSkin != null) {
            TableSkinUtils.getVisibleLeafColumns(tableSkin).removeListener((ListChangeListener<? super TableColumnBase>)this.weakVisibleLeafColumnsListener);
            TableSkinUtils.getSortOrder(tableSkin).removeListener(this.weakSortOrderListener);
        }
        this.changeListenerHandler.dispose();
    }
    
    private boolean isSortingEnabled() {
        return true;
    }
    
    private boolean isColumnReorderingEnabled() {
        return !Properties.IS_TOUCH_SUPPORTED && TableSkinUtils.getVisibleLeafColumns(this.getTableSkin()).size() > 1;
    }
    
    private void initUI() {
        if (this.getTableColumn() == null) {
            return;
        }
        this.setOnMousePressed(TableColumnHeader.mousePressedHandler);
        this.setOnMouseDragged(TableColumnHeader.mouseDraggedHandler);
        this.setOnDragDetected(mouseEvent -> mouseEvent.consume());
        this.setOnContextMenuRequested(TableColumnHeader.contextMenuRequestedHandler);
        this.setOnMouseReleased(TableColumnHeader.mouseReleasedHandler);
        (this.label = new Label()).setText(this.getTableColumn().getText());
        this.label.setGraphic(this.getTableColumn().getGraphic());
        this.label.setVisible(this.getTableColumn().isVisible());
        if (this.isSortingEnabled()) {
            this.updateSortGrid();
        }
    }
    
    private void doColumnAutoSize(final TableColumnBase<?, ?> tableColumnBase, final int n) {
        if (tableColumnBase.getPrefWidth() == 80.0) {
            TableSkinUtils.resizeColumnToFitContent(this.getTableSkin(), tableColumnBase, n);
        }
    }
    
    private void updateSortPosition() {
        this.sortPos = (this.getTableColumn().isSortable() ? this.getSortPosition() : -1);
        this.updateSortGrid();
    }
    
    private void updateSortGrid() {
        if (this instanceof NestedTableColumnHeader) {
            return;
        }
        this.getChildren().clear();
        this.getChildren().add(this.label);
        if (!this.isSortingEnabled()) {
            return;
        }
        if (!(this.isSortColumn = (this.sortPos != -1))) {
            if (this.sortArrow != null) {
                this.sortArrow.setVisible(false);
            }
            return;
        }
        if (TableSkinUtils.getVisibleLeafIndex(this.getTableSkin(), this.getTableColumn()) == -1) {
            return;
        }
        final int visibleSortOrderColumnCount = this.getVisibleSortOrderColumnCount();
        final boolean b = this.sortPos <= 3 && visibleSortOrderColumnCount > 1;
        Node sortNode;
        if (this.getTableColumn().getSortNode() != null) {
            sortNode = this.getTableColumn().getSortNode();
            this.getChildren().add(sortNode);
        }
        else {
            final GridPane gridPane = (GridPane)(sortNode = new GridPane());
            gridPane.setPadding(new Insets(0.0, 3.0, 0.0, 0.0));
            this.getChildren().add(gridPane);
            if (this.arrow == null) {
                this.arrow = new Region();
                this.arrow.getStyleClass().setAll("arrow");
                this.arrow.setVisible(true);
                this.arrow.setRotate(TableColumnSortTypeWrapper.isAscending(this.getTableColumn()) ? 180.0 : 0.0);
                this.changeListenerHandler.registerChangeListener(TableColumnSortTypeWrapper.getSortTypeProperty(this.getTableColumn()), p0 -> {
                    this.updateSortGrid();
                    if (this.arrow != null) {
                        this.arrow.setRotate(TableColumnSortTypeWrapper.isAscending(this.getTableColumn()) ? 180.0 : 0.0);
                    }
                    return;
                });
            }
            this.arrow.setVisible(this.isSortColumn);
            if (this.sortPos > 2) {
                if (this.sortOrderLabel == null) {
                    this.sortOrderLabel = new Label();
                    this.sortOrderLabel.getStyleClass().add("sort-order");
                }
                this.sortOrderLabel.setText(invokedynamic(makeConcatWithConstants:(I)Ljava/lang/String;, this.sortPos + 1));
                this.sortOrderLabel.setVisible(visibleSortOrderColumnCount > 1);
                gridPane.add(this.arrow, 1, 1);
                GridPane.setHgrow(this.arrow, Priority.NEVER);
                GridPane.setVgrow(this.arrow, Priority.NEVER);
                gridPane.add(this.sortOrderLabel, 2, 1);
            }
            else if (b) {
                if (this.sortOrderDots == null) {
                    this.sortOrderDots = new HBox(0.0);
                    this.sortOrderDots.getStyleClass().add("sort-order-dots-container");
                }
                final boolean ascending = TableColumnSortTypeWrapper.isAscending(this.getTableColumn());
                final int n = ascending ? 1 : 2;
                final int n2 = ascending ? 2 : 1;
                gridPane.add(this.arrow, 1, n);
                GridPane.setHalignment(this.arrow, HPos.CENTER);
                gridPane.add(this.sortOrderDots, 1, n2);
                this.updateSortOrderDots(this.sortPos);
            }
            else {
                gridPane.add(this.arrow, 1, 1);
                GridPane.setHgrow(this.arrow, Priority.NEVER);
                GridPane.setVgrow(this.arrow, Priority.ALWAYS);
            }
        }
        this.sortArrow = sortNode;
        if (this.sortArrow != null) {
            this.sortArrow.setVisible(this.isSortColumn);
        }
        this.requestLayout();
    }
    
    private void updateSortOrderDots(final int n) {
        final double prefWidth = this.arrow.prefWidth(-1.0);
        this.sortOrderDots.getChildren().clear();
        for (int i = 0; i <= n; ++i) {
            final Region region = new Region();
            region.getStyleClass().add("sort-order-dot");
            final String sortTypeName = TableColumnSortTypeWrapper.getSortTypeName(this.getTableColumn());
            if (sortTypeName != null && !sortTypeName.isEmpty()) {
                region.getStyleClass().add(sortTypeName.toLowerCase(Locale.ROOT));
            }
            this.sortOrderDots.getChildren().add(region);
            if (i < n) {
                final Region region2 = new Region();
                region2.setPadding(new Insets(0.0, 1.0, 0.0, (n == 1) ? 1.0 : 0.0));
                this.sortOrderDots.getChildren().add(region2);
            }
        }
        this.sortOrderDots.setAlignment(Pos.TOP_CENTER);
        this.sortOrderDots.setMaxWidth(prefWidth);
    }
    
    void moveColumn(final TableColumnBase tableColumnBase, final int n) {
        if (tableColumnBase == null || n < 0) {
            return;
        }
        final ObservableList<TableColumnBase<?, ?>> columns = this.getColumns(tableColumnBase);
        final int size = columns.size();
        final int index = columns.indexOf(tableColumnBase);
        final int n3;
        int n2 = n3 = n;
        for (int n4 = 0, n5 = 0; n5 < size && n4 != n3 + 1; ++n5) {
            if (columns.get(n5).isVisible()) {
                ++n4;
            }
            else {
                ++n2;
            }
        }
        if (n2 >= size) {
            n2 = size - 1;
        }
        else if (n2 < 0) {
            n2 = 0;
        }
        if (n2 == index) {
            return;
        }
        final ArrayList all = new ArrayList<TableColumnBase<?, ?>>(columns);
        all.remove(tableColumnBase);
        all.add(n2, (TableColumnBase<?, ?>)tableColumnBase);
        columns.setAll((Collection<? extends TableColumnBase<?, ?>>)all);
    }
    
    private ObservableList<TableColumnBase<?, ?>> getColumns(final TableColumnBase tableColumnBase) {
        return (tableColumnBase.getParentColumn() == null) ? TableSkinUtils.getColumns(this.getTableSkin()) : tableColumnBase.getParentColumn().getColumns();
    }
    
    private int getIndex(final TableColumnBase<?, ?> tableColumnBase) {
        if (tableColumnBase == null) {
            return -1;
        }
        final ObservableList<TableColumnBase<?, ?>> columns = this.getColumns(tableColumnBase);
        int n = -1;
        for (int i = 0; i < columns.size(); ++i) {
            final TableColumnBase obj = columns.get(i);
            if (obj.isVisible()) {
                ++n;
                if (tableColumnBase.equals(obj)) {
                    break;
                }
            }
        }
        return n;
    }
    
    private void updateColumnIndex() {
        final TableColumnBase<?, ?> tableColumn = this.getTableColumn();
        final TableViewSkinBase<?, ?, ?, ?, ?> tableSkin = this.getTableSkin();
        this.columnIndex = ((tableSkin == null || tableColumn == null) ? -1 : TableSkinUtils.getVisibleLeafIndex(tableSkin, tableColumn));
        this.isLastVisibleColumn = (this.getTableColumn() != null && this.columnIndex != -1 && this.columnIndex == TableSkinUtils.getVisibleLeafColumns(tableSkin).size() - 1);
        this.pseudoClassStateChanged(TableColumnHeader.PSEUDO_CLASS_LAST_VISIBLE, this.isLastVisibleColumn);
    }
    
    private void sortColumn(final boolean b) {
        if (!this.isSortingEnabled()) {
            return;
        }
        if (this.getTableColumn() == null || this.getTableColumn().getColumns().size() != 0 || this.getTableColumn().getComparator() == null || !this.getTableColumn().isSortable()) {
            return;
        }
        final ObservableList<TableColumnBase<?, ?>> sortOrder = TableSkinUtils.getSortOrder(this.getTableSkin());
        if (b) {
            if (!this.isSortColumn) {
                TableColumnSortTypeWrapper.setSortType(this.getTableColumn(), TableColumn.SortType.ASCENDING);
                sortOrder.add(this.getTableColumn());
            }
            else if (TableColumnSortTypeWrapper.isAscending(this.getTableColumn())) {
                TableColumnSortTypeWrapper.setSortType(this.getTableColumn(), TableColumn.SortType.DESCENDING);
            }
            else {
                final int index = sortOrder.indexOf(this.getTableColumn());
                if (index != -1) {
                    sortOrder.remove(index);
                }
            }
        }
        else if (this.isSortColumn && sortOrder.size() == 1) {
            if (TableColumnSortTypeWrapper.isAscending(this.getTableColumn())) {
                TableColumnSortTypeWrapper.setSortType(this.getTableColumn(), TableColumn.SortType.DESCENDING);
            }
            else {
                sortOrder.remove(this.getTableColumn());
            }
        }
        else if (this.isSortColumn) {
            if (TableColumnSortTypeWrapper.isAscending(this.getTableColumn())) {
                TableColumnSortTypeWrapper.setSortType(this.getTableColumn(), TableColumn.SortType.DESCENDING);
            }
            else if (TableColumnSortTypeWrapper.isDescending(this.getTableColumn())) {
                TableColumnSortTypeWrapper.setSortType(this.getTableColumn(), TableColumn.SortType.ASCENDING);
            }
            final ArrayList list = new ArrayList<TableColumnBase<?, ?>>(sortOrder);
            list.remove(this.getTableColumn());
            list.add(0, this.getTableColumn());
            sortOrder.setAll(this.getTableColumn());
        }
        else {
            TableColumnSortTypeWrapper.setSortType(this.getTableColumn(), TableColumn.SortType.ASCENDING);
            sortOrder.setAll(this.getTableColumn());
        }
    }
    
    private int getSortPosition() {
        if (this.getTableColumn() == null) {
            return -1;
        }
        final List<TableColumnBase> visibleSortOrderColumns = this.getVisibleSortOrderColumns();
        int n = 0;
        for (int i = 0; i < visibleSortOrderColumns.size(); ++i) {
            if (this.getTableColumn().equals(visibleSortOrderColumns.get(i))) {
                return n;
            }
            ++n;
        }
        return -1;
    }
    
    private List<TableColumnBase> getVisibleSortOrderColumns() {
        final ObservableList<TableColumnBase<?, ?>> sortOrder = TableSkinUtils.getSortOrder(this.getTableSkin());
        final ArrayList<TableColumnBase> list = new ArrayList<TableColumnBase>();
        for (int i = 0; i < sortOrder.size(); ++i) {
            final TableColumnBase tableColumnBase = sortOrder.get(i);
            if (tableColumnBase != null && tableColumnBase.isSortable()) {
                if (tableColumnBase.isVisible()) {
                    list.add(tableColumnBase);
                }
            }
        }
        return (List<TableColumnBase>)list;
    }
    
    private int getVisibleSortOrderColumnCount() {
        return this.getVisibleSortOrderColumns().size();
    }
    
    void columnReorderingStarted(final double dragOffset) {
        if (!this.getTableColumn().isReorderable()) {
            return;
        }
        this.dragOffset = dragOffset;
        this.getTableHeaderRow().setReorderingColumn(this.getTableColumn());
        this.getTableHeaderRow().setReorderingRegion(this);
    }
    
    void columnReordering(final double n, final double n2) {
        if (!this.getTableColumn().isReorderable()) {
            return;
        }
        this.getTableHeaderRow().setReordering(true);
        Region region = null;
        final double x = this.getParentHeader().sceneToLocal(n, n2).getX();
        this.getTableHeaderRow().setDragHeaderX(this.getTableSkin().getSkinnable().sceneToLocal(n, n2).getX() - this.dragOffset);
        double minX = 0.0;
        double n3 = 0.0;
        double n4 = 0.0;
        this.newColumnPos = 0;
        for (final TableColumnHeader tableColumnHeader : this.getParentHeader().getColumnHeaders()) {
            if (!tableColumnHeader.isVisible()) {
                continue;
            }
            final double prefWidth = tableColumnHeader.prefWidth(-1.0);
            n4 += prefWidth;
            minX = tableColumnHeader.getBoundsInParent().getMinX();
            n3 = minX + prefWidth;
            if (x >= minX && x < n3) {
                region = tableColumnHeader;
                break;
            }
            ++this.newColumnPos;
        }
        if (region == null) {
            this.newColumnPos = ((x > n4) ? (this.getParentHeader().getColumns().size() - 1) : 0);
            return;
        }
        final boolean b = x <= minX + (n3 - minX) / 2.0;
        final int index = this.getIndex(this.getTableColumn());
        this.newColumnPos += ((this.newColumnPos > index && b) ? -1 : (this.newColumnPos < index && !b));
        final double translateX = this.getTableHeaderRow().sceneToLocal(region.localToScene(region.getBoundsInLocal())).getMinX() + (b ? 0.0 : region.getWidth());
        if (translateX >= -0.5 && translateX <= this.getTableSkin().getSkinnable().getWidth()) {
            this.columnReorderLine.setTranslateX(translateX);
            this.columnReorderLine.setVisible(true);
        }
        this.getTableHeaderRow().setReordering(true);
    }
    
    void columnReorderingComplete() {
        if (!this.getTableColumn().isReorderable()) {
            return;
        }
        this.moveColumn(this.getTableColumn(), this.newColumnPos);
        this.columnReorderLine.setTranslateX(0.0);
        this.columnReorderLine.setLayoutX(0.0);
        this.newColumnPos = 0;
        this.getTableHeaderRow().setReordering(false);
        this.columnReorderLine.setVisible(false);
        this.getTableHeaderRow().setReorderingColumn(null);
        this.getTableHeaderRow().setReorderingRegion(null);
        this.dragOffset = 0.0;
    }
    
    double getDragRectHeight() {
        return this.getHeight();
    }
    
    boolean represents(final TableColumnBase<?, ?> tableColumnBase) {
        return tableColumnBase.getColumns().isEmpty() && tableColumnBase == this.getTableColumn();
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    static {
        final TableColumnHeader tableColumnHeader;
        final ContextMenu contextMenu;
        mousePressedHandler = (mouseEvent -> {
            tableColumnHeader = (TableColumnHeader)mouseEvent.getSource();
            tableColumnHeader.getTableColumn().getContextMenu();
            if (contextMenu != null && contextMenu.isShowing()) {
                contextMenu.hide();
            }
            if (mouseEvent.isConsumed()) {
                return;
            }
            else {
                mouseEvent.consume();
                tableColumnHeader.getTableHeaderRow().columnDragLock = true;
                tableColumnHeader.getTableSkin().getSkinnable().requestFocus();
                if (mouseEvent.isPrimaryButtonDown() && tableColumnHeader.isColumnReorderingEnabled()) {
                    tableColumnHeader.columnReorderingStarted(mouseEvent.getX());
                }
                return;
            }
        });
        TableColumnHeader tableColumnHeader2;
        mouseDraggedHandler = (mouseEvent2 -> {
            if (mouseEvent2.isConsumed()) {
                return;
            }
            else {
                mouseEvent2.consume();
                tableColumnHeader2 = (TableColumnHeader)mouseEvent2.getSource();
                if (mouseEvent2.isPrimaryButtonDown() && tableColumnHeader2.isColumnReorderingEnabled()) {
                    tableColumnHeader2.columnReordering(mouseEvent2.getSceneX(), mouseEvent2.getSceneY());
                }
                return;
            }
        });
        TableColumnHeader tableColumnHeader3;
        mouseReleasedHandler = (mouseEvent3 -> {
            if (mouseEvent3.isPopupTrigger()) {
                return;
            }
            else if (mouseEvent3.isConsumed()) {
                return;
            }
            else {
                mouseEvent3.consume();
                tableColumnHeader3 = (TableColumnHeader)mouseEvent3.getSource();
                tableColumnHeader3.getTableHeaderRow().columnDragLock = false;
                if (tableColumnHeader3.getTableHeaderRow().isReordering() && tableColumnHeader3.isColumnReorderingEnabled()) {
                    tableColumnHeader3.columnReorderingComplete();
                }
                else if (mouseEvent3.isStillSincePress()) {
                    tableColumnHeader3.sortColumn(mouseEvent3.isShiftDown());
                }
                return;
            }
        });
        final TableColumnHeader tableColumnHeader4;
        final ContextMenu contextMenu2;
        contextMenuRequestedHandler = (contextMenuEvent -> {
            tableColumnHeader4 = (TableColumnHeader)contextMenuEvent.getSource();
            tableColumnHeader4.getTableColumn().getContextMenu();
            if (contextMenu2 != null) {
                contextMenu2.show(tableColumnHeader4, contextMenuEvent.getScreenX(), contextMenuEvent.getScreenY());
                contextMenuEvent.consume();
            }
            return;
        });
        PSEUDO_CLASS_LAST_VISIBLE = PseudoClass.getPseudoClass("last-visible");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TableColumnHeader, Number> SIZE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            SIZE = new CssMetaData<TableColumnHeader, Number>((StyleConverter)SizeConverter.getInstance(), (Number)20.0) {
                @Override
                public boolean isSettable(final TableColumnHeader tableColumnHeader) {
                    return tableColumnHeader.size == null || !tableColumnHeader.size.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TableColumnHeader tableColumnHeader) {
                    return (StyleableProperty<Number>)tableColumnHeader.sizeProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Region.getClassCssMetaData());
            list.add(StyleableProperties.SIZE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
