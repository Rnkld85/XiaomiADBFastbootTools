// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.control.SkinBase;
import com.sun.javafx.scene.control.behavior.ComboBoxBaseBehavior;
import javafx.util.StringConverter;
import com.sun.javafx.scene.control.DatePickerHijrahContent;
import java.time.chrono.HijrahChronology;
import javafx.scene.Node;
import javafx.event.Event;
import javafx.event.ActionEvent;
import java.time.temporal.TemporalAccessor;
import java.time.YearMonth;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.beans.Observable;
import javafx.beans.InvalidationListener;
import javafx.scene.control.ComboBoxBase;
import com.sun.javafx.scene.control.behavior.DatePickerBehavior;
import com.sun.javafx.scene.control.DatePickerContent;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import java.time.LocalDate;

public class DatePickerSkin extends ComboBoxPopupControl<LocalDate>
{
    private final DatePicker datePicker;
    private TextField displayNode;
    private DatePickerContent datePickerContent;
    private final DatePickerBehavior behavior;
    
    public DatePickerSkin(final DatePicker datePicker) {
        super(datePicker);
        this.datePicker = datePicker;
        this.behavior = new DatePickerBehavior(datePicker);
        this.arrow.paddingProperty().addListener(new InvalidationListener() {
            private boolean rounding = false;
            
            @Override
            public void invalidated(final Observable observable) {
                if (!this.rounding) {
                    final Insets padding = DatePickerSkin.this.arrow.getPadding();
                    final Insets padding2 = new Insets((double)Math.round(padding.getTop()), (double)Math.round(padding.getRight()), (double)Math.round(padding.getBottom()), (double)Math.round(padding.getLeft()));
                    if (!padding2.equals(padding)) {
                        this.rounding = true;
                        DatePickerSkin.this.arrow.setPadding(padding2);
                        this.rounding = false;
                    }
                }
            }
        });
        this.registerChangeListener(datePicker.chronologyProperty(), p0 -> {
            this.updateDisplayNode();
            this.datePickerContent = null;
            this.popup = null;
            return;
        });
        this.registerChangeListener(datePicker.converterProperty(), p0 -> this.updateDisplayNode());
        this.registerChangeListener(datePicker.dayCellFactoryProperty(), p0 -> {
            this.updateDisplayNode();
            this.datePickerContent = null;
            this.popup = null;
            return;
        });
        this.registerChangeListener(datePicker.showWeekNumbersProperty(), p0 -> {
            if (this.datePickerContent != null) {
                this.datePickerContent.updateGrid();
                this.datePickerContent.updateWeeknumberDateCells();
            }
            return;
        });
        LocalDate temporal;
        this.registerChangeListener(datePicker.valueProperty(), p1 -> {
            this.updateDisplayNode();
            if (this.datePickerContent != null) {
                temporal = datePicker.getValue();
                this.datePickerContent.displayedYearMonthProperty().set((temporal != null) ? YearMonth.from(temporal) : YearMonth.now());
                this.datePickerContent.updateValues();
            }
            datePicker.fireEvent(new ActionEvent());
            return;
        });
        LocalDate temporal2;
        this.registerChangeListener(datePicker.showingProperty(), p1 -> {
            if (datePicker.isShowing()) {
                if (this.datePickerContent != null) {
                    temporal2 = datePicker.getValue();
                    this.datePickerContent.displayedYearMonthProperty().set((temporal2 != null) ? YearMonth.from(temporal2) : YearMonth.now());
                    this.datePickerContent.updateValues();
                }
                this.show();
            }
            else {
                this.hide();
            }
            return;
        });
        if (datePicker.isShowing()) {
            this.show();
        }
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    public Node getPopupContent() {
        if (this.datePickerContent == null) {
            if (this.datePicker.getChronology() instanceof HijrahChronology) {
                this.datePickerContent = new DatePickerHijrahContent(this.datePicker);
            }
            else {
                this.datePickerContent = new DatePickerContent(this.datePicker);
            }
        }
        return this.datePickerContent;
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return 50.0;
    }
    
    @Override
    public void show() {
        super.show();
        this.datePickerContent.clearFocus();
    }
    
    @Override
    protected TextField getEditor() {
        return ((SkinBase<DatePicker>)this).getSkinnable().getEditor();
    }
    
    @Override
    protected StringConverter<LocalDate> getConverter() {
        return ((SkinBase<DatePicker>)this).getSkinnable().getConverter();
    }
    
    @Override
    public Node getDisplayNode() {
        if (this.displayNode == null) {
            this.displayNode = this.getEditableInputNode();
            this.displayNode.getStyleClass().add("date-picker-display-node");
            this.updateDisplayNode();
        }
        this.displayNode.setEditable(this.datePicker.isEditable());
        return this.displayNode;
    }
    
    @Override
    void focusLost() {
    }
    
    @Override
    ComboBoxBaseBehavior getBehavior() {
        return this.behavior;
    }
}
