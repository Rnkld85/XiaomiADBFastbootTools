// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.util.Duration;
import java.lang.ref.WeakReference;
import javafx.animation.Transition;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.scene.control.SkinBase;
import javafx.css.converter.BooleanConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.beans.Observable;
import javafx.css.Styleable;
import java.util.List;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ObservableNumberValue;
import javafx.beans.value.ObservableBooleanValue;
import javafx.beans.binding.When;
import javafx.scene.layout.Background;
import javafx.scene.paint.Paint;
import javafx.scene.paint.Color;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.Node;
import com.sun.javafx.scene.NodeHelper;
import javafx.css.StyleableBooleanProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableDoubleProperty;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.ProgressBar;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;

public class ProgressBarSkin extends ProgressIndicatorSkin
{
    private StackPane bar;
    private StackPane track;
    private Region clipRegion;
    private double barWidth;
    private DoubleProperty indeterminateBarLength;
    private BooleanProperty indeterminateBarEscape;
    private BooleanProperty indeterminateBarFlip;
    private DoubleProperty indeterminateBarAnimationTime;
    boolean wasIndeterminate;
    
    public ProgressBarSkin(final ProgressBar progressBar) {
        super(progressBar);
        this.indeterminateBarLength = null;
        this.indeterminateBarEscape = null;
        this.indeterminateBarFlip = null;
        this.indeterminateBarAnimationTime = null;
        this.wasIndeterminate = false;
        this.barWidth = (int)(progressBar.getWidth() - this.snappedLeftInset() - this.snappedRightInset()) * 2 * Math.min(1.0, Math.max(0.0, progressBar.getProgress())) / 2.0;
        progressBar.widthProperty().addListener(p0 -> this.updateProgress());
        this.initialize();
        this.getSkinnable().requestLayout();
    }
    
    private DoubleProperty indeterminateBarLengthProperty() {
        if (this.indeterminateBarLength == null) {
            this.indeterminateBarLength = new StyleableDoubleProperty(60.0) {
                @Override
                public Object getBean() {
                    return ProgressBarSkin.this;
                }
                
                @Override
                public String getName() {
                    return "indeterminateBarLength";
                }
                
                @Override
                public CssMetaData<ProgressBar, Number> getCssMetaData() {
                    return StyleableProperties.INDETERMINATE_BAR_LENGTH;
                }
            };
        }
        return this.indeterminateBarLength;
    }
    
    private Double getIndeterminateBarLength() {
        return (this.indeterminateBarLength == null) ? 60.0 : this.indeterminateBarLength.get();
    }
    
    private BooleanProperty indeterminateBarEscapeProperty() {
        if (this.indeterminateBarEscape == null) {
            this.indeterminateBarEscape = new StyleableBooleanProperty(true) {
                @Override
                public Object getBean() {
                    return ProgressBarSkin.this;
                }
                
                @Override
                public String getName() {
                    return "indeterminateBarEscape";
                }
                
                @Override
                public CssMetaData<ProgressBar, Boolean> getCssMetaData() {
                    return StyleableProperties.INDETERMINATE_BAR_ESCAPE;
                }
            };
        }
        return this.indeterminateBarEscape;
    }
    
    private Boolean getIndeterminateBarEscape() {
        return this.indeterminateBarEscape == null || this.indeterminateBarEscape.get();
    }
    
    private BooleanProperty indeterminateBarFlipProperty() {
        if (this.indeterminateBarFlip == null) {
            this.indeterminateBarFlip = new StyleableBooleanProperty(true) {
                @Override
                public Object getBean() {
                    return ProgressBarSkin.this;
                }
                
                @Override
                public String getName() {
                    return "indeterminateBarFlip";
                }
                
                @Override
                public CssMetaData<ProgressBar, Boolean> getCssMetaData() {
                    return StyleableProperties.INDETERMINATE_BAR_FLIP;
                }
            };
        }
        return this.indeterminateBarFlip;
    }
    
    private Boolean getIndeterminateBarFlip() {
        return this.indeterminateBarFlip == null || this.indeterminateBarFlip.get();
    }
    
    private DoubleProperty indeterminateBarAnimationTimeProperty() {
        if (this.indeterminateBarAnimationTime == null) {
            this.indeterminateBarAnimationTime = new StyleableDoubleProperty(2.0) {
                @Override
                public Object getBean() {
                    return ProgressBarSkin.this;
                }
                
                @Override
                public String getName() {
                    return "indeterminateBarAnimationTime";
                }
                
                @Override
                public CssMetaData<ProgressBar, Number> getCssMetaData() {
                    return StyleableProperties.INDETERMINATE_BAR_ANIMATION_TIME;
                }
            };
        }
        return this.indeterminateBarAnimationTime;
    }
    
    private double getIndeterminateBarAnimationTime() {
        return (this.indeterminateBarAnimationTime == null) ? 2.0 : this.indeterminateBarAnimationTime.get();
    }
    
    public double computeBaselineOffset(final double n, final double n2, final double n3, final double n4) {
        return Double.NEGATIVE_INFINITY;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Math.max(100.0, n5 + this.bar.prefWidth(this.getSkinnable().getWidth()) + n3);
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return n2 + this.bar.prefHeight(n) + n4;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefWidth(n);
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefHeight(n);
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        final boolean indeterminate = this.getSkinnable().isIndeterminate();
        this.clipRegion.resizeRelocate(0.0, 0.0, n3, n4);
        this.track.resizeRelocate(n, n2, n3, n4);
        this.bar.resizeRelocate(n, n2, indeterminate ? ((double)this.getIndeterminateBarLength()) : this.barWidth, n4);
        this.track.setVisible(true);
        if (indeterminate) {
            this.createIndeterminateTimeline();
            if (NodeHelper.isTreeShowing(((SkinBase<Node>)this).getSkinnable())) {
                this.indeterminateTransition.play();
            }
            this.bar.setClip(this.clipRegion);
        }
        else if (this.indeterminateTransition != null) {
            this.indeterminateTransition.stop();
            this.indeterminateTransition = null;
            this.bar.setClip(null);
            this.bar.setScaleX(1.0);
            this.bar.setTranslateX(0.0);
            this.clipRegion.translateXProperty().unbind();
        }
    }
    
    @Override
    void initialize() {
        this.track = new StackPane();
        this.track.getStyleClass().setAll("track");
        this.bar = new StackPane();
        this.bar.getStyleClass().setAll("bar");
        this.getChildren().setAll(this.track, this.bar);
        this.clipRegion = new Region();
        BackgroundFill[] array;
        int i = 0;
        BackgroundFill backgroundFill;
        this.bar.backgroundProperty().addListener((p0, p1, background) -> {
            if (background != null && !background.getFills().isEmpty()) {
                array = new BackgroundFill[background.getFills().size()];
                while (i < background.getFills().size()) {
                    backgroundFill = background.getFills().get(i);
                    array[i] = new BackgroundFill(Color.BLACK, backgroundFill.getRadii(), backgroundFill.getInsets());
                    ++i;
                }
                this.clipRegion.setBackground(new Background(array));
            }
        });
    }
    
    @Override
    void createIndeterminateTimeline() {
        if (this.indeterminateTransition != null) {
            this.indeterminateTransition.stop();
        }
        final double n = this.getSkinnable().getWidth() - (this.snappedLeftInset() + this.snappedRightInset());
        (this.indeterminateTransition = new IndeterminateTransition(this.getIndeterminateBarEscape() ? (-this.getIndeterminateBarLength()) : 0.0, this.getIndeterminateBarEscape() ? n : (n - this.getIndeterminateBarLength()), this)).setCycleCount(-1);
        this.clipRegion.translateXProperty().bind(new When(this.bar.scaleXProperty().isEqualTo(-1.0, 1.0E-100)).then((ObservableNumberValue)this.bar.translateXProperty().subtract(n).add(this.indeterminateBarLengthProperty())).otherwise(this.bar.translateXProperty().negate()));
    }
    
    @Override
    void updateProgress() {
        final ProgressIndicator progressIndicator = this.getSkinnable();
        final boolean indeterminate = progressIndicator.isIndeterminate();
        if (!indeterminate || !this.wasIndeterminate) {
            this.barWidth = (int)(progressIndicator.getWidth() - this.snappedLeftInset() - this.snappedRightInset()) * 2 * Math.min(1.0, Math.max(0.0, progressIndicator.getProgress())) / 2.0;
            this.getSkinnable().requestLayout();
        }
        this.wasIndeterminate = indeterminate;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<ProgressBar, Number> INDETERMINATE_BAR_LENGTH;
        private static final CssMetaData<ProgressBar, Boolean> INDETERMINATE_BAR_ESCAPE;
        private static final CssMetaData<ProgressBar, Boolean> INDETERMINATE_BAR_FLIP;
        private static final CssMetaData<ProgressBar, Number> INDETERMINATE_BAR_ANIMATION_TIME;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            INDETERMINATE_BAR_LENGTH = new CssMetaData<ProgressBar, Number>((StyleConverter)SizeConverter.getInstance(), (Number)60.0) {
                @Override
                public boolean isSettable(final ProgressBar progressBar) {
                    final ProgressBarSkin progressBarSkin = (ProgressBarSkin)progressBar.getSkin();
                    return progressBarSkin.indeterminateBarLength == null || !progressBarSkin.indeterminateBarLength.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ProgressBar progressBar) {
                    return (StyleableProperty<Number>)((ProgressBarSkin)progressBar.getSkin()).indeterminateBarLengthProperty();
                }
            };
            INDETERMINATE_BAR_ESCAPE = new CssMetaData<ProgressBar, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final ProgressBar progressBar) {
                    final ProgressBarSkin progressBarSkin = (ProgressBarSkin)progressBar.getSkin();
                    return progressBarSkin.indeterminateBarEscape == null || !progressBarSkin.indeterminateBarEscape.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final ProgressBar progressBar) {
                    return (StyleableProperty<Boolean>)((ProgressBarSkin)progressBar.getSkin()).indeterminateBarEscapeProperty();
                }
            };
            INDETERMINATE_BAR_FLIP = new CssMetaData<ProgressBar, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.TRUE) {
                @Override
                public boolean isSettable(final ProgressBar progressBar) {
                    final ProgressBarSkin progressBarSkin = (ProgressBarSkin)progressBar.getSkin();
                    return progressBarSkin.indeterminateBarFlip == null || !progressBarSkin.indeterminateBarFlip.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final ProgressBar progressBar) {
                    return (StyleableProperty<Boolean>)((ProgressBarSkin)progressBar.getSkin()).indeterminateBarFlipProperty();
                }
            };
            INDETERMINATE_BAR_ANIMATION_TIME = new CssMetaData<ProgressBar, Number>((StyleConverter)SizeConverter.getInstance(), (Number)2.0) {
                @Override
                public boolean isSettable(final ProgressBar progressBar) {
                    final ProgressBarSkin progressBarSkin = (ProgressBarSkin)progressBar.getSkin();
                    return progressBarSkin.indeterminateBarAnimationTime == null || !progressBarSkin.indeterminateBarAnimationTime.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ProgressBar progressBar) {
                    return (StyleableProperty<Number>)((ProgressBarSkin)progressBar.getSkin()).indeterminateBarAnimationTimeProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(SkinBase.getClassCssMetaData());
            list.add(StyleableProperties.INDETERMINATE_BAR_LENGTH);
            list.add(StyleableProperties.INDETERMINATE_BAR_ESCAPE);
            list.add(StyleableProperties.INDETERMINATE_BAR_FLIP);
            list.add(StyleableProperties.INDETERMINATE_BAR_ANIMATION_TIME);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    private static class IndeterminateTransition extends Transition
    {
        private final WeakReference<ProgressBarSkin> skin;
        private final double startX;
        private final double endX;
        private final boolean flip;
        
        public IndeterminateTransition(final double startX, final double endX, final ProgressBarSkin referent) {
            this.startX = startX;
            this.endX = endX;
            this.skin = new WeakReference<ProgressBarSkin>(referent);
            this.flip = referent.getIndeterminateBarFlip();
            referent.getIndeterminateBarEscape();
            this.setCycleDuration(Duration.seconds(referent.getIndeterminateBarAnimationTime() * (this.flip ? 2 : 1)));
        }
        
        @Override
        protected void interpolate(final double n) {
            final ProgressBarSkin progressBarSkin = this.skin.get();
            if (progressBarSkin == null) {
                this.stop();
            }
            else if (n <= 0.5 || !this.flip) {
                progressBarSkin.bar.setScaleX(-1.0);
                progressBarSkin.bar.setTranslateX(this.startX + (this.flip ? 2 : 1) * n * (this.endX - this.startX));
            }
            else {
                progressBarSkin.bar.setScaleX(1.0);
                progressBarSkin.bar.setTranslateX(this.startX + 2.0 * (1.0 - n) * (this.endX - this.startX));
            }
        }
    }
}
