// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.control.TableColumnBase;
import javafx.collections.ObservableList;
import javafx.scene.control.TableCell;
import javafx.scene.Node;
import javafx.scene.AccessibleAction;
import java.util.Iterator;
import java.util.Collection;
import javafx.collections.FXCollections;
import javafx.scene.control.TablePosition;
import java.util.ArrayList;
import javafx.scene.AccessibleAttribute;
import javafx.event.EventHandler;
import javafx.beans.value.ObservableValue;
import javafx.scene.input.MouseEvent;
import com.sun.javafx.scene.control.behavior.TableViewBehavior;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;

public class TableViewSkin<T> extends TableViewSkinBase<T, T, TableView<T>, TableRow<T>, TableColumn<T, ?>>
{
    private final TableViewBehavior<T> behavior;
    
    public TableViewSkin(final TableView<T> tableView) {
        super(tableView);
        this.behavior = new TableViewBehavior<T>(tableView);
        this.flow.setFixedCellSize(tableView.getFixedCellSize());
        this.flow.setCellFactory(p0 -> this.createCell());
        final EventHandler<? super MouseEvent> eventHandler = p1 -> {
            if (tableView.getEditingCell() != null) {
                tableView.edit(-1, null);
            }
            if (tableView.isFocusTraversable()) {
                tableView.requestFocus();
            }
            return;
        };
        this.flow.getVbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        this.flow.getHbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
        this.behavior.setOnFocusPreviousRow(() -> this.onFocusPreviousCell());
        this.behavior.setOnFocusNextRow(() -> this.onFocusNextCell());
        this.behavior.setOnMoveToFirstCell(() -> this.onMoveToFirstCell());
        this.behavior.setOnMoveToLastCell(() -> this.onMoveToLastCell());
        this.behavior.setOnScrollPageDown(b -> this.onScrollPageDown(b));
        this.behavior.setOnScrollPageUp(b2 -> this.onScrollPageUp(b2));
        this.behavior.setOnSelectPreviousRow(() -> this.onSelectPreviousCell());
        this.behavior.setOnSelectNextRow(() -> this.onSelectNextCell());
        this.behavior.setOnSelectLeftCell(() -> this.onSelectLeftCell());
        this.behavior.setOnSelectRightCell(() -> this.onSelectRightCell());
        this.registerChangeListener(tableView.fixedCellSizeProperty(), p0 -> this.flow.setFixedCellSize(this.getSkinnable().getFixedCellSize()));
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case SELECTED_ITEMS: {
                final ArrayList<TableRow> list = new ArrayList<TableRow>();
                final Iterator iterator = this.getSkinnable().getSelectionModel().getSelectedCells().iterator();
                while (iterator.hasNext()) {
                    final TableRow tableRow = (TableRow)this.flow.getPrivateCell(iterator.next().getRow());
                    if (tableRow != null) {
                        list.add(tableRow);
                    }
                }
                return FXCollections.observableArrayList((Collection<?>)list);
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    protected void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case SHOW_ITEM: {
                final Node node = (Node)array[0];
                if (node instanceof TableCell) {
                    this.flow.scrollTo(((TableCell)node).getIndex());
                    break;
                }
                break;
            }
            case SET_SELECTED_ITEMS: {
                final ObservableList list = (ObservableList)array[0];
                if (list != null) {
                    final TableView.TableViewSelectionModel selectionModel = this.getSkinnable().getSelectionModel();
                    if (selectionModel != null) {
                        selectionModel.clearSelection();
                        for (final Node node2 : list) {
                            if (node2 instanceof TableCell) {
                                final TableCell tableCell = (TableCell)node2;
                                selectionModel.select(tableCell.getIndex(), tableCell.getTableColumn());
                            }
                        }
                    }
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    private TableRow<T> createCell() {
        final TableView<T> tableView = this.getSkinnable();
        TableRow<T> tableRow;
        if (tableView.getRowFactory() != null) {
            tableRow = tableView.getRowFactory().call(tableView);
        }
        else {
            tableRow = new TableRow<T>();
        }
        tableRow.updateTableView(tableView);
        return tableRow;
    }
    
    @Override
    protected int getItemCount() {
        final TableView tableView = this.getSkinnable();
        return (tableView.getItems() == null) ? 0 : tableView.getItems().size();
    }
    
    @Override
    void horizontalScroll() {
        super.horizontalScroll();
        if (this.getSkinnable().getFixedCellSize() > 0.0) {
            this.flow.requestCellLayout();
        }
    }
}
