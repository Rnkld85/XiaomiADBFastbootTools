// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.collections.ObservableList;
import javafx.scene.control.TableColumnBase;
import javafx.scene.control.TableColumn;
import java.util.Iterator;
import java.util.Collection;
import javafx.collections.FXCollections;
import java.lang.ref.Reference;
import javafx.scene.control.TablePosition;
import java.util.ArrayList;
import javafx.scene.AccessibleAttribute;
import javafx.beans.property.DoubleProperty;
import javafx.scene.control.TableView;
import javafx.beans.Observable;
import javafx.beans.InvalidationListener;
import javafx.scene.control.IndexedCell;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.control.behavior.TableRowBehavior;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableRow;

public class TableRowSkin<T> extends TableRowSkinBase<T, TableRow<T>, TableCell<T, ?>>
{
    private TableViewSkin<T> tableViewSkin;
    private final BehaviorBase<TableRow<T>> behavior;
    
    public TableRowSkin(final TableRow<T> tableRow) {
        super(tableRow);
        this.behavior = (BehaviorBase<TableRow<T>>)new TableRowBehavior((TableRow<Object>)tableRow);
        this.updateTableViewSkin();
        int i = 0;
        final int n;
        IndexedCell indexedCell;
        this.registerChangeListener(tableRow.tableViewProperty(), p0 -> {
            this.updateTableViewSkin();
            this.cells.size();
            while (i < n) {
                indexedCell = this.cells.get(i);
                if (indexedCell instanceof TableCell) {
                    ((TableCell)indexedCell).updateTableView(this.getSkinnable().getTableView());
                }
                ++i;
            }
            return;
        });
        this.setupTreeTableViewListeners();
    }
    
    private void setupTreeTableViewListeners() {
        final TableView tableView = this.getSkinnable().getTableView();
        if (tableView == null) {
            this.getSkinnable().tableViewProperty().addListener(new InvalidationListener() {
                @Override
                public void invalidated(final Observable observable) {
                    TableRowSkin.this.getSkinnable().tableViewProperty().removeListener(this);
                    TableRowSkin.this.setupTreeTableViewListeners();
                }
            });
        }
        else {
            final DoubleProperty fixedCellSizeProperty = tableView.fixedCellSizeProperty();
            if (fixedCellSizeProperty != null) {
                this.registerChangeListener(fixedCellSizeProperty, p1 -> {
                    this.fixedCellSize = fixedCellSizeProperty.get();
                    this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0);
                    return;
                });
                this.fixedCellSize = fixedCellSizeProperty.get();
                this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0);
                this.registerChangeListener(this.getVirtualFlow().widthProperty(), p1 -> tableView.requestLayout());
            }
        }
    }
    
    @Override
    public void dispose() {
        super.dispose();
        if (this.behavior != null) {
            this.behavior.dispose();
        }
    }
    
    @Override
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case SELECTED_ITEMS: {
                final ArrayList<TableCell> list = new ArrayList<TableCell>();
                final int index = this.getSkinnable().getIndex();
                final Iterator<TablePosition<T, ?>> iterator = (Iterator<TablePosition<T, ?>>)this.getTableView().getSelectionModel().getSelectedCells().iterator();
                if (iterator.hasNext()) {
                    final TablePosition<T, ?> tablePosition = iterator.next();
                    if (tablePosition.getRow() == index) {
                        TableColumn<T, ?> key = tablePosition.getTableColumn();
                        if (key == null) {
                            key = this.getTableView().getVisibleLeafColumn(0);
                        }
                        final TableCell tableCell = (TableCell)this.cellsMap.get(key).get();
                        if (tableCell != null) {
                            list.add(tableCell);
                        }
                    }
                    return FXCollections.observableArrayList((Collection<?>)list);
                }
            }
            case CELL_AT_ROW_COLUMN: {
                final TableColumn<T, ?> visibleLeafColumn = this.getTableView().getVisibleLeafColumn((int)array[1]);
                if (this.cellsMap.containsKey(visibleLeafColumn)) {
                    return this.cellsMap.get(visibleLeafColumn).get();
                }
                return null;
            }
            case FOCUS_ITEM: {
                TableColumn<T, ?> tableColumn = this.getTableView().getFocusModel().getFocusedCell().getTableColumn();
                if (tableColumn == null) {
                    tableColumn = this.getTableView().getVisibleLeafColumn(0);
                }
                if (this.cellsMap.containsKey(tableColumn)) {
                    return this.cellsMap.get(tableColumn).get();
                }
                return null;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    protected TableCell<T, ?> createCell(final TableColumnBase tableColumnBase) {
        final TableColumn<T, ?> tableColumn = (TableColumn<T, ?>)tableColumnBase;
        final TableCell<T, ?> tableCell = tableColumn.getCellFactory().call(tableColumn);
        tableCell.updateTableColumn(tableColumn);
        tableCell.updateTableView(tableColumn.getTableView());
        tableCell.updateTableRow(this.getSkinnable());
        return tableCell;
    }
    
    @Override
    protected ObservableList<TableColumn<T, ?>> getVisibleLeafColumns() {
        return (this.getTableView() == null) ? FXCollections.emptyObservableList() : this.getTableView().getVisibleLeafColumns();
    }
    
    @Override
    protected void updateCell(final TableCell<T, ?> tableCell, final TableRow<T> tableRow) {
        tableCell.updateTableRow(tableRow);
    }
    
    @Override
    protected TableColumn<T, ?> getTableColumn(final TableCell<T, ?> tableCell) {
        return tableCell.getTableColumn();
    }
    
    private TableView<T> getTableView() {
        return this.getSkinnable().getTableView();
    }
    
    private void updateTableViewSkin() {
        final TableView tableView = this.getSkinnable().getTableView();
        if (tableView != null && tableView.getSkin() instanceof TableViewSkin) {
            this.tableViewSkin = (TableViewSkin<T>)tableView.getSkin();
        }
    }
}
