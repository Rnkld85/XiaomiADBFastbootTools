// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.scene.shape.Rectangle;
import javafx.scene.Cursor;
import javafx.scene.layout.StackPane;
import javafx.collections.ListChangeListener;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.geometry.NodeOrientation;
import javafx.scene.input.MouseEvent;
import java.util.ListIterator;
import javafx.beans.value.ChangeListener;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.collections.FXCollections;
import javafx.geometry.Orientation;
import javafx.collections.ObservableList;
import javafx.scene.control.SplitPane;
import javafx.scene.control.SkinBase;

public class SplitPaneSkin extends SkinBase<SplitPane>
{
    private ObservableList<Content> contentRegions;
    private ObservableList<ContentDivider> contentDividers;
    private boolean horizontal;
    private double previousSize;
    private int lastDividerUpdate;
    private boolean resize;
    private boolean checkDividerPos;
    
    public SplitPaneSkin(final SplitPane splitPane) {
        super(splitPane);
        this.previousSize = -1.0;
        this.lastDividerUpdate = 0;
        this.resize = false;
        this.checkDividerPos = true;
        this.horizontal = (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL);
        this.contentRegions = FXCollections.observableArrayList();
        this.contentDividers = FXCollections.observableArrayList();
        int n = 0;
        final Iterator<Node> iterator = this.getSkinnable().getItems().iterator();
        while (iterator.hasNext()) {
            this.addContent(n++, iterator.next());
        }
        this.initializeContentListener();
        final Iterator<SplitPane.Divider> iterator2 = this.getSkinnable().getDividers().iterator();
        while (iterator2.hasNext()) {
            this.addDivider(iterator2.next());
        }
        final Iterator<ContentDivider> iterator3;
        this.registerChangeListener(splitPane.orientationProperty(), p0 -> {
            this.horizontal = (this.getSkinnable().getOrientation() == Orientation.HORIZONTAL);
            this.previousSize = -1.0;
            this.contentDividers.iterator();
            while (iterator3.hasNext()) {
                iterator3.next().setGrabberStyle(this.horizontal);
            }
            this.getSkinnable().requestLayout();
            return;
        });
        this.registerChangeListener(splitPane.widthProperty(), p0 -> this.getSkinnable().requestLayout());
        this.registerChangeListener(splitPane.heightProperty(), p0 -> this.getSkinnable().requestLayout());
    }
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        final SplitPane splitPane = this.getSkinnable();
        final double width = splitPane.getWidth();
        final double height = splitPane.getHeight();
        if (this.horizontal) {
            if (width == 0.0) {
                return;
            }
        }
        else if (height == 0.0) {
            return;
        }
        if (!this.contentRegions.isEmpty()) {
            final double n5 = this.contentDividers.isEmpty() ? 0.0 : this.contentDividers.get(0).prefWidth(-1.0);
            if (this.contentDividers.size() > 0 && this.previousSize != -1.0 && this.previousSize != (this.horizontal ? width : height)) {
                final ArrayList<Content> list = new ArrayList<Content>();
                for (final Content content : this.contentRegions) {
                    if (content.isResizableWithParent()) {
                        list.add(content);
                    }
                }
                final double a = (this.horizontal ? splitPane.getWidth() : splitPane.getHeight()) - this.previousSize;
                final boolean b = a > 0.0;
                final double abs = Math.abs(a);
                if (abs != 0.0 && !list.isEmpty()) {
                    int n6 = (int)abs / list.size();
                    int n7 = (int)abs % list.size();
                    int n8;
                    if (n6 == 0) {
                        n6 = n7;
                        n8 = n7;
                        n7 = 0;
                    }
                    else {
                        n8 = n6 * list.size();
                    }
                    while (n8 > 0 && !list.isEmpty()) {
                        if (b) {
                            ++this.lastDividerUpdate;
                        }
                        else {
                            --this.lastDividerUpdate;
                            if (this.lastDividerUpdate < 0) {
                                this.lastDividerUpdate = this.contentRegions.size() - 1;
                            }
                        }
                        final Content content2 = this.contentRegions.get(this.lastDividerUpdate % this.contentRegions.size());
                        if (content2.isResizableWithParent() && list.contains(content2)) {
                            final double area = content2.getArea();
                            double area2;
                            if (b) {
                                if (area + n6 > (this.horizontal ? content2.maxWidth(-1.0) : content2.maxHeight(-1.0))) {
                                    list.remove(content2);
                                    continue;
                                }
                                area2 = area + n6;
                            }
                            else {
                                if (area - n6 < (this.horizontal ? content2.minWidth(-1.0) : content2.minHeight(-1.0))) {
                                    list.remove(content2);
                                    continue;
                                }
                                area2 = area - n6;
                            }
                            content2.setArea(area2);
                            n8 -= n6;
                            if (n8 == 0 && n7 != 0) {
                                n6 = n7;
                                n8 = n7;
                                n7 = 0;
                            }
                            else {
                                if (n8 == 0) {
                                    break;
                                }
                                continue;
                            }
                        }
                    }
                    for (final Content content3 : this.contentRegions) {
                        content3.setResizableWithParentArea(content3.getArea());
                        content3.setAvailable(0.0);
                    }
                    this.resize = true;
                }
                this.previousSize = (this.horizontal ? width : height);
            }
            else {
                this.previousSize = (this.horizontal ? width : height);
            }
            final double totalMinSize = this.totalMinSize();
            if (totalMinSize > (this.horizontal ? n3 : n4)) {
                for (int i = 0; i < this.contentRegions.size(); ++i) {
                    final Content content4 = this.contentRegions.get(i);
                    final double n9 = (this.horizontal ? content4.minWidth(-1.0) : content4.minHeight(-1.0)) / totalMinSize;
                    if (this.horizontal) {
                        content4.setArea(this.snapSpaceX(n9 * n3));
                    }
                    else {
                        content4.setArea(this.snapSpaceY(n9 * n4));
                    }
                    content4.setAvailable(0.0);
                }
                this.setupContentAndDividerForLayout();
                this.layoutDividersAndContent(n3, n4);
                this.resize = false;
                return;
            }
            for (int j = 0; j < 10; ++j) {
                ContentDivider contentDivider = null;
                ContentDivider contentDivider2 = null;
                for (int k = 0; k < this.contentRegions.size(); ++k) {
                    double absoluteDividerPos = 0.0;
                    if (k < this.contentDividers.size()) {
                        contentDivider2 = (ContentDivider)this.contentDividers.get(k);
                        if (contentDivider2.posExplicit) {
                            this.checkDividerPosition(contentDivider2, this.posToDividerPos(contentDivider2, contentDivider2.d.getPosition()), contentDivider2.getDividerPos());
                        }
                        if (k == 0) {
                            absoluteDividerPos = this.getAbsoluteDividerPos(contentDivider2);
                        }
                        else {
                            final double n10 = this.getAbsoluteDividerPos(contentDivider) + n5;
                            if (this.getAbsoluteDividerPos(contentDivider2) <= this.getAbsoluteDividerPos(contentDivider)) {
                                this.setAndCheckAbsoluteDividerPos(contentDivider2, n10);
                            }
                            absoluteDividerPos = this.getAbsoluteDividerPos(contentDivider2) - n10;
                        }
                    }
                    else if (k == this.contentDividers.size()) {
                        absoluteDividerPos = (this.horizontal ? n3 : n4) - ((contentDivider != null) ? (this.getAbsoluteDividerPos(contentDivider) + n5) : 0.0);
                    }
                    if (!this.resize || contentDivider2.posExplicit) {
                        this.contentRegions.get(k).setArea(absoluteDividerPos);
                    }
                    contentDivider = contentDivider2;
                }
                double a2 = 0.0;
                double distributeTo = 0.0;
                for (final Content content5 : this.contentRegions) {
                    if (content5 == null) {
                        continue;
                    }
                    final double area3 = this.horizontal ? content5.maxWidth(-1.0) : content5.maxHeight(-1.0);
                    final double n11 = this.horizontal ? content5.minWidth(-1.0) : content5.minHeight(-1.0);
                    if (content5.getArea() >= area3) {
                        distributeTo += content5.getArea() - area3;
                        content5.setArea(area3);
                    }
                    content5.setAvailable(content5.getArea() - n11);
                    if (content5.getAvailable() >= 0.0) {
                        continue;
                    }
                    a2 += content5.getAvailable();
                }
                double n12 = Math.abs(a2);
                final ArrayList<Content> list2 = new ArrayList<Content>();
                final ArrayList<Content> list3 = new ArrayList<Content>();
                final ArrayList<Content> list4 = new ArrayList<Content>();
                double n13 = 0.0;
                for (final Content content6 : this.contentRegions) {
                    if (content6.getAvailable() >= 0.0) {
                        n13 += content6.getAvailable();
                        list2.add(content6);
                    }
                    if (this.resize && !content6.isResizableWithParent()) {
                        if (content6.getArea() >= content6.getResizableWithParentArea()) {
                            distributeTo += content6.getArea() - content6.getResizableWithParentArea();
                        }
                        else {
                            n12 += content6.getResizableWithParentArea() - content6.getArea();
                        }
                        content6.setAvailable(0.0);
                    }
                    if (this.resize) {
                        if (content6.isResizableWithParent()) {
                            list3.add(content6);
                        }
                    }
                    else {
                        list3.add(content6);
                    }
                    if (content6.getAvailable() < 0.0) {
                        list4.add(content6);
                    }
                }
                if (distributeTo > 0.0) {
                    distributeTo = this.distributeTo(list3, distributeTo);
                    double a3 = 0.0;
                    list4.clear();
                    n13 = 0.0;
                    list2.clear();
                    for (final Content content7 : this.contentRegions) {
                        if (content7.getAvailable() < 0.0) {
                            a3 += content7.getAvailable();
                            list4.add(content7);
                        }
                        else {
                            n13 += content7.getAvailable();
                            list2.add(content7);
                        }
                    }
                    n12 = Math.abs(a3);
                }
                if (n13 >= n12) {
                    for (final Content content8 : list4) {
                        content8.setArea(this.horizontal ? content8.minWidth(-1.0) : content8.minHeight(-1.0));
                        content8.setAvailable(0.0);
                    }
                    if (n12 > 0.0 && !list4.isEmpty()) {
                        this.distributeFrom(n12, list2);
                    }
                    if (this.resize) {
                        double n14 = 0.0;
                        for (final Content content9 : this.contentRegions) {
                            if (content9.isResizableWithParent()) {
                                n14 += content9.getArea();
                            }
                            else {
                                n14 += content9.getResizableWithParentArea();
                            }
                        }
                        final double n15 = n14 + n5 * this.contentDividers.size();
                        if (n15 < (this.horizontal ? n3 : n4)) {
                            this.distributeTo(list3, distributeTo + ((this.horizontal ? n3 : n4) - n15));
                        }
                        else {
                            this.distributeFrom(n12 + (n15 - (this.horizontal ? n3 : n4)), list3);
                        }
                    }
                }
                this.setupContentAndDividerForLayout();
                boolean b2 = true;
                for (final Content content10 : this.contentRegions) {
                    final double n16 = this.horizontal ? content10.maxWidth(-1.0) : content10.maxHeight(-1.0);
                    if (content10.getArea() < (this.horizontal ? content10.minWidth(-1.0) : content10.minHeight(-1.0)) || content10.getArea() > n16) {
                        b2 = false;
                        break;
                    }
                }
                if (b2) {
                    break;
                }
            }
            this.layoutDividersAndContent(n3, n4);
            this.resize = false;
        }
    }
    
    @Override
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        double max = 0.0;
        for (final Content content : this.contentRegions) {
            n6 += content.minWidth(-1.0);
            max = Math.max(max, content.minWidth(-1.0));
        }
        final Iterator<ContentDivider> iterator2 = this.contentDividers.iterator();
        while (iterator2.hasNext()) {
            n6 += iterator2.next().prefWidth(-1.0);
        }
        if (this.horizontal) {
            return n6 + n5 + n3;
        }
        return max + n5 + n3;
    }
    
    @Override
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        double max = 0.0;
        for (final Content content : this.contentRegions) {
            n6 += content.minHeight(-1.0);
            max = Math.max(max, content.minHeight(-1.0));
        }
        final Iterator<ContentDivider> iterator2 = this.contentDividers.iterator();
        while (iterator2.hasNext()) {
            n6 += iterator2.next().prefWidth(-1.0);
        }
        if (this.horizontal) {
            return max + n2 + n4;
        }
        return n6 + n2 + n4;
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        double max = 0.0;
        for (final Content content : this.contentRegions) {
            n6 += content.prefWidth(-1.0);
            max = Math.max(max, content.prefWidth(-1.0));
        }
        final Iterator<ContentDivider> iterator2 = this.contentDividers.iterator();
        while (iterator2.hasNext()) {
            n6 += iterator2.next().prefWidth(-1.0);
        }
        if (this.horizontal) {
            return n6 + n5 + n3;
        }
        return max + n5 + n3;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double n6 = 0.0;
        double max = 0.0;
        for (final Content content : this.contentRegions) {
            n6 += content.prefHeight(-1.0);
            max = Math.max(max, content.prefHeight(-1.0));
        }
        final Iterator<ContentDivider> iterator2 = this.contentDividers.iterator();
        while (iterator2.hasNext()) {
            n6 += iterator2.next().prefWidth(-1.0);
        }
        if (this.horizontal) {
            return max + n2 + n4;
        }
        return n6 + n2 + n4;
    }
    
    private void addContent(final int n, final Node node) {
        final Content content = new Content(node);
        this.contentRegions.add(n, content);
        this.getChildren().add(n, content);
    }
    
    private void removeContent(final Node obj) {
        for (final Content content : this.contentRegions) {
            if (content.getContent().equals(obj)) {
                content.dispose();
                this.getChildren().remove(content);
                this.contentRegions.remove(content);
                break;
            }
        }
    }
    
    private void initializeContentListener() {
        final Iterator<Node> iterator;
        Node node;
        int n = 0;
        final int n2;
        final Iterator<Node> iterator2;
        final Iterator<Node> iterator3;
        Node node2;
        int n3 = 0;
        final int n4;
        final Iterator<SplitPane.Divider> iterator4;
        this.getSkinnable().getItems().addListener(change -> {
            while (change.next()) {
                if (change.wasPermutated() || change.wasUpdated()) {
                    this.getChildren().clear();
                    this.contentRegions.clear();
                    change.getList().iterator();
                    while (iterator.hasNext()) {
                        node = iterator.next();
                        n++;
                        this.addContent(n2, node);
                    }
                }
                else {
                    change.getRemoved().iterator();
                    while (iterator2.hasNext()) {
                        this.removeContent(iterator2.next());
                    }
                    change.getFrom();
                    change.getAddedSubList().iterator();
                    while (iterator3.hasNext()) {
                        node2 = iterator3.next();
                        n3++;
                        this.addContent(n4, node2);
                    }
                }
            }
            this.removeAllDividers();
            this.getSkinnable().getDividers().iterator();
            while (iterator4.hasNext()) {
                this.addDivider(iterator4.next());
            }
        });
    }
    
    private void checkDividerPosition(final ContentDivider contentDivider, final double n, final double n2) {
        final double prefWidth = contentDivider.prefWidth(-1.0);
        final Content left = this.getLeft(contentDivider);
        final Content right = this.getRight(contentDivider);
        final double n3 = (left == null) ? 0.0 : (this.horizontal ? left.minWidth(-1.0) : left.minHeight(-1.0));
        final double n4 = (right == null) ? 0.0 : (this.horizontal ? right.minWidth(-1.0) : right.minHeight(-1.0));
        final double n5 = (left == null) ? 0.0 : ((left.getContent() != null) ? (this.horizontal ? left.getContent().maxWidth(-1.0) : left.getContent().maxHeight(-1.0)) : 0.0);
        final double n6 = (right == null) ? 0.0 : ((right.getContent() != null) ? (this.horizontal ? right.getContent().maxWidth(-1.0) : right.getContent().maxHeight(-1.0)) : 0.0);
        double n7 = 0.0;
        double n8 = this.getSize();
        final int index = this.contentDividers.indexOf(contentDivider);
        if (index - 1 >= 0) {
            n7 = ((ContentDivider)this.contentDividers.get(index - 1)).getDividerPos();
            if (n7 == -1.0) {
                n7 = this.getAbsoluteDividerPos((ContentDivider)this.contentDividers.get(index - 1));
            }
        }
        if (index + 1 < this.contentDividers.size()) {
            n8 = ((ContentDivider)this.contentDividers.get(index + 1)).getDividerPos();
            if (n8 == -1.0) {
                n8 = this.getAbsoluteDividerPos((ContentDivider)this.contentDividers.get(index + 1));
            }
        }
        this.checkDividerPos = false;
        if (n > n2) {
            final double min = Math.min((n7 == 0.0) ? n5 : (n7 + prefWidth + n5), n8 - n4 - prefWidth);
            if (n >= min) {
                this.setAbsoluteDividerPos(contentDivider, min);
            }
            else {
                final double n9 = n8 - n6 - prefWidth;
                if (n <= n9) {
                    this.setAbsoluteDividerPos(contentDivider, n9);
                }
                else {
                    this.setAbsoluteDividerPos(contentDivider, n);
                }
            }
        }
        else {
            final double max = Math.max(n8 - n6 - prefWidth, (n7 == 0.0) ? n3 : (n7 + n3 + prefWidth));
            if (n <= max) {
                this.setAbsoluteDividerPos(contentDivider, max);
            }
            else {
                final double n10 = n7 + n5 + prefWidth;
                if (n >= n10) {
                    this.setAbsoluteDividerPos(contentDivider, n10);
                }
                else {
                    this.setAbsoluteDividerPos(contentDivider, n);
                }
            }
        }
        this.checkDividerPos = true;
    }
    
    private void addDivider(final SplitPane.Divider divider) {
        final ContentDivider contentDivider = new ContentDivider(divider);
        contentDivider.setInitialPos(divider.getPosition());
        contentDivider.setDividerPos(-1.0);
        final PosPropertyListener posPropertyListener = new PosPropertyListener(contentDivider);
        contentDivider.setPosPropertyListener(posPropertyListener);
        divider.positionProperty().addListener(posPropertyListener);
        this.initializeDivderEventHandlers(contentDivider);
        this.contentDividers.add(contentDivider);
        this.getChildren().add(contentDivider);
    }
    
    private void removeAllDividers() {
        final ListIterator<ContentDivider> listIterator = (ListIterator<ContentDivider>)this.contentDividers.listIterator();
        while (listIterator.hasNext()) {
            final ContentDivider contentDivider = listIterator.next();
            this.getChildren().remove(contentDivider);
            contentDivider.getDivider().positionProperty().removeListener(contentDivider.getPosPropertyListener());
            listIterator.remove();
        }
        this.lastDividerUpdate = 0;
    }
    
    private void initializeDivderEventHandlers(final ContentDivider contentDivider) {
        contentDivider.addEventHandler(MouseEvent.ANY, mouseEvent -> mouseEvent.consume());
        contentDivider.setOnMousePressed(mouseEvent2 -> {
            if (this.horizontal) {
                contentDivider.setInitialPos(contentDivider.getDividerPos());
                contentDivider.setPressPos(mouseEvent2.getSceneX());
                contentDivider.setPressPos((this.getSkinnable().getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) ? (this.getSkinnable().getWidth() - mouseEvent2.getSceneX()) : mouseEvent2.getSceneX());
            }
            else {
                contentDivider.setInitialPos(contentDivider.getDividerPos());
                contentDivider.setPressPos(mouseEvent2.getSceneY());
            }
            mouseEvent2.consume();
            return;
        });
        double sceneY;
        contentDivider.setOnMouseDragged(mouseEvent3 -> {
            if (this.horizontal) {
                sceneY = ((this.getSkinnable().getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) ? (this.getSkinnable().getWidth() - mouseEvent3.getSceneX()) : mouseEvent3.getSceneX());
            }
            else {
                sceneY = mouseEvent3.getSceneY();
            }
            this.setAndCheckAbsoluteDividerPos(contentDivider, Math.ceil(contentDivider.getInitialPos() + (sceneY - contentDivider.getPressPos())));
            mouseEvent3.consume();
        });
    }
    
    private Content getLeft(final ContentDivider contentDivider) {
        final int index = this.contentDividers.indexOf(contentDivider);
        if (index != -1) {
            return (Content)this.contentRegions.get(index);
        }
        return null;
    }
    
    private Content getRight(final ContentDivider contentDivider) {
        final int index = this.contentDividers.indexOf(contentDivider);
        if (index != -1) {
            return (Content)this.contentRegions.get(index + 1);
        }
        return null;
    }
    
    private void setAbsoluteDividerPos(final ContentDivider contentDivider, final double dividerPos) {
        if (this.getSkinnable().getWidth() > 0.0 && this.getSkinnable().getHeight() > 0.0 && contentDivider != null) {
            final SplitPane.Divider divider = contentDivider.getDivider();
            contentDivider.setDividerPos(dividerPos);
            final double size = this.getSize();
            if (size != 0.0) {
                divider.setPosition((dividerPos + contentDivider.prefWidth(-1.0) / 2.0) / size);
            }
            else {
                divider.setPosition(0.0);
            }
        }
    }
    
    private double getAbsoluteDividerPos(final ContentDivider contentDivider) {
        if (this.getSkinnable().getWidth() > 0.0 && this.getSkinnable().getHeight() > 0.0 && contentDivider != null) {
            final double posToDividerPos = this.posToDividerPos(contentDivider, contentDivider.getDivider().getPosition());
            contentDivider.setDividerPos(posToDividerPos);
            return posToDividerPos;
        }
        return 0.0;
    }
    
    private double posToDividerPos(final ContentDivider contentDivider, final double n) {
        final double n2 = this.getSize() * n;
        double a;
        if (n == 1.0) {
            a = n2 - contentDivider.prefWidth(-1.0);
        }
        else {
            a = n2 - contentDivider.prefWidth(-1.0) / 2.0;
        }
        return (double)Math.round(a);
    }
    
    private double totalMinSize() {
        final double n = this.contentDividers.isEmpty() ? 0.0 : (this.contentDividers.size() * this.contentDividers.get(0).prefWidth(-1.0));
        double n2 = 0.0;
        for (final Content content : this.contentRegions) {
            if (this.horizontal) {
                n2 += content.minWidth(-1.0);
            }
            else {
                n2 += content.minHeight(-1.0);
            }
        }
        return n2 + n;
    }
    
    private double getSize() {
        final SplitPane splitPane = this.getSkinnable();
        double totalMinSize = this.totalMinSize();
        if (this.horizontal) {
            if (splitPane.getWidth() > totalMinSize) {
                totalMinSize = splitPane.getWidth() - this.snappedLeftInset() - this.snappedRightInset();
            }
        }
        else if (splitPane.getHeight() > totalMinSize) {
            totalMinSize = splitPane.getHeight() - this.snappedTopInset() - this.snappedBottomInset();
        }
        return totalMinSize;
    }
    
    private double distributeTo(final List<Content> list, double n) {
        if (list.isEmpty()) {
            return n;
        }
        n = (this.horizontal ? this.snapSizeX(n) : this.snapSizeY(n));
        int n2 = (int)n / list.size();
        while (n > 0.0 && !list.isEmpty()) {
            final Iterator<Content> iterator = list.iterator();
            while (iterator.hasNext()) {
                final Content content = iterator.next();
                final double min = Math.min(this.horizontal ? content.maxWidth(-1.0) : content.maxHeight(-1.0), Double.MAX_VALUE);
                final double n3 = this.horizontal ? content.minWidth(-1.0) : content.minHeight(-1.0);
                if (content.getArea() >= min) {
                    content.setAvailable(content.getArea() - n3);
                    iterator.remove();
                }
                else {
                    if (n2 >= min - content.getArea()) {
                        n -= min - content.getArea();
                        content.setArea(min);
                        content.setAvailable(min - n3);
                        iterator.remove();
                    }
                    else {
                        content.setArea(content.getArea() + n2);
                        content.setAvailable(content.getArea() - n3);
                        n -= n2;
                    }
                    if ((int)n == 0) {
                        return n;
                    }
                    continue;
                }
            }
            if (list.isEmpty()) {
                return n;
            }
            n2 = (int)n / list.size();
            final int n4 = (int)n % list.size();
            if (n2 != 0 || n4 == 0) {
                continue;
            }
            n2 = n4;
        }
        return n;
    }
    
    private double distributeFrom(double n, final List<Content> list) {
        if (list.isEmpty()) {
            return n;
        }
        n = (this.horizontal ? this.snapSizeX(n) : this.snapSizeY(n));
        int n2 = (int)n / list.size();
        while (n > 0.0 && !list.isEmpty()) {
            final Iterator<Content> iterator = list.iterator();
            while (iterator.hasNext()) {
                final Content content = iterator.next();
                if (n2 >= content.getAvailable()) {
                    content.setArea(content.getArea() - content.getAvailable());
                    n -= content.getAvailable();
                    content.setAvailable(0.0);
                    iterator.remove();
                }
                else {
                    content.setArea(content.getArea() - n2);
                    content.setAvailable(content.getAvailable() - n2);
                    n -= n2;
                }
                if ((int)n == 0) {
                    return n;
                }
            }
            if (list.isEmpty()) {
                return n;
            }
            n2 = (int)n / list.size();
            final int n3 = (int)n % list.size();
            if (n2 != 0 || n3 == 0) {
                continue;
            }
            n2 = n3;
        }
        return n;
    }
    
    private void setupContentAndDividerForLayout() {
        final double n = this.contentDividers.isEmpty() ? 0.0 : this.contentDividers.get(0).prefWidth(-1.0);
        double x = 0.0;
        double y = 0.0;
        for (final Content content : this.contentRegions) {
            if (this.resize && !content.isResizableWithParent()) {
                content.setArea(content.getResizableWithParentArea());
            }
            content.setX(x);
            content.setY(y);
            if (this.horizontal) {
                x += content.getArea() + n;
            }
            else {
                y += content.getArea() + n;
            }
        }
        double x2 = 0.0;
        double y2 = 0.0;
        this.checkDividerPos = false;
        for (int i = 0; i < this.contentDividers.size(); ++i) {
            final ContentDivider contentDivider = this.contentDividers.get(i);
            if (this.horizontal) {
                x2 += this.getLeft(contentDivider).getArea() + ((i == 0) ? 0.0 : n);
            }
            else {
                y2 += this.getLeft(contentDivider).getArea() + ((i == 0) ? 0.0 : n);
            }
            contentDivider.setX(x2);
            contentDivider.setY(y2);
            this.setAbsoluteDividerPos(contentDivider, this.horizontal ? contentDivider.getX() : contentDivider.getY());
            contentDivider.posExplicit = false;
        }
        this.checkDividerPos = true;
    }
    
    private void layoutDividersAndContent(final double n, final double n2) {
        final double snappedLeftInset = this.snappedLeftInset();
        final double snappedTopInset = this.snappedTopInset();
        final double n3 = this.contentDividers.isEmpty() ? 0.0 : this.contentDividers.get(0).prefWidth(-1.0);
        for (final Content content : this.contentRegions) {
            if (this.horizontal) {
                content.setClipSize(content.getArea(), n2);
                this.layoutInArea(content, content.getX() + snappedLeftInset, content.getY() + snappedTopInset, content.getArea(), n2, 0.0, HPos.CENTER, VPos.CENTER);
            }
            else {
                content.setClipSize(n, content.getArea());
                this.layoutInArea(content, content.getX() + snappedLeftInset, content.getY() + snappedTopInset, n, content.getArea(), 0.0, HPos.CENTER, VPos.CENTER);
            }
        }
        for (final ContentDivider contentDivider : this.contentDividers) {
            if (this.horizontal) {
                contentDivider.resize(n3, n2);
                this.positionInArea(contentDivider, contentDivider.getX() + snappedLeftInset, contentDivider.getY() + snappedTopInset, n3, n2, 0.0, HPos.CENTER, VPos.CENTER);
            }
            else {
                contentDivider.resize(n, n3);
                this.positionInArea(contentDivider, contentDivider.getX() + snappedLeftInset, contentDivider.getY() + snappedTopInset, n, n3, 0.0, HPos.CENTER, VPos.CENTER);
            }
        }
    }
    
    private void setAndCheckAbsoluteDividerPos(final ContentDivider contentDivider, final double n) {
        final double dividerPos = contentDivider.getDividerPos();
        this.setAbsoluteDividerPos(contentDivider, n);
        this.checkDividerPosition(contentDivider, n, dividerPos);
    }
    
    class PosPropertyListener implements ChangeListener<Number>
    {
        ContentDivider divider;
        
        public PosPropertyListener(final ContentDivider divider) {
            this.divider = divider;
        }
        
        @Override
        public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
            if (SplitPaneSkin.this.checkDividerPos) {
                this.divider.posExplicit = true;
            }
            SplitPaneSkin.this.getSkinnable().requestLayout();
        }
    }
    
    class ContentDivider extends StackPane
    {
        private double initialPos;
        private double dividerPos;
        private double pressPos;
        private SplitPane.Divider d;
        private StackPane grabber;
        private double x;
        private double y;
        private boolean posExplicit;
        private ChangeListener<Number> listener;
        
        public ContentDivider(final SplitPane.Divider d) {
            this.getStyleClass().setAll("split-pane-divider");
            this.d = d;
            this.initialPos = 0.0;
            this.dividerPos = 0.0;
            this.pressPos = 0.0;
            this.grabber = new StackPane() {
                @Override
                protected double computeMinWidth(final double n) {
                    return 0.0;
                }
                
                @Override
                protected double computeMinHeight(final double n) {
                    return 0.0;
                }
                
                @Override
                protected double computePrefWidth(final double n) {
                    return this.snappedLeftInset() + this.snappedRightInset();
                }
                
                @Override
                protected double computePrefHeight(final double n) {
                    return this.snappedTopInset() + this.snappedBottomInset();
                }
                
                @Override
                protected double computeMaxWidth(final double n) {
                    return this.computePrefWidth(-1.0);
                }
                
                @Override
                protected double computeMaxHeight(final double n) {
                    return this.computePrefHeight(-1.0);
                }
            };
            this.setGrabberStyle(SplitPaneSkin.this.horizontal);
            this.getChildren().add(this.grabber);
        }
        
        public SplitPane.Divider getDivider() {
            return this.d;
        }
        
        public final void setGrabberStyle(final boolean b) {
            this.grabber.getStyleClass().clear();
            this.grabber.getStyleClass().setAll("vertical-grabber");
            this.setCursor(Cursor.V_RESIZE);
            if (b) {
                this.grabber.getStyleClass().setAll("horizontal-grabber");
                this.setCursor(Cursor.H_RESIZE);
            }
        }
        
        public double getInitialPos() {
            return this.initialPos;
        }
        
        public void setInitialPos(final double initialPos) {
            this.initialPos = initialPos;
        }
        
        public double getDividerPos() {
            return this.dividerPos;
        }
        
        public void setDividerPos(final double dividerPos) {
            this.dividerPos = dividerPos;
        }
        
        public double getPressPos() {
            return this.pressPos;
        }
        
        public void setPressPos(final double pressPos) {
            this.pressPos = pressPos;
        }
        
        public double getX() {
            return this.x;
        }
        
        public void setX(final double x) {
            this.x = x;
        }
        
        public double getY() {
            return this.y;
        }
        
        public void setY(final double y) {
            this.y = y;
        }
        
        public ChangeListener<Number> getPosPropertyListener() {
            return this.listener;
        }
        
        public void setPosPropertyListener(final ChangeListener<Number> listener) {
            this.listener = listener;
        }
        
        @Override
        protected double computeMinWidth(final double n) {
            return this.computePrefWidth(n);
        }
        
        @Override
        protected double computeMinHeight(final double n) {
            return this.computePrefHeight(n);
        }
        
        @Override
        protected double computePrefWidth(final double n) {
            return this.snappedLeftInset() + this.snappedRightInset();
        }
        
        @Override
        protected double computePrefHeight(final double n) {
            return this.snappedTopInset() + this.snappedBottomInset();
        }
        
        @Override
        protected double computeMaxWidth(final double n) {
            return this.computePrefWidth(n);
        }
        
        @Override
        protected double computeMaxHeight(final double n) {
            return this.computePrefHeight(n);
        }
        
        @Override
        protected void layoutChildren() {
            final double prefWidth = this.grabber.prefWidth(-1.0);
            final double prefHeight = this.grabber.prefHeight(-1.0);
            final double n = (this.getWidth() - prefWidth) / 2.0;
            final double n2 = (this.getHeight() - prefHeight) / 2.0;
            this.grabber.resize(prefWidth, prefHeight);
            this.positionInArea(this.grabber, n, n2, prefWidth, prefHeight, 0.0, HPos.CENTER, VPos.CENTER);
        }
    }
    
    static class Content extends StackPane
    {
        private Node content;
        private Rectangle clipRect;
        private double x;
        private double y;
        private double area;
        private double resizableWithParentArea;
        private double available;
        
        public Content(final Node content) {
            this.setClip(this.clipRect = new Rectangle());
            this.content = content;
            if (content != null) {
                this.getChildren().add(content);
            }
            this.x = 0.0;
            this.y = 0.0;
        }
        
        public Node getContent() {
            return this.content;
        }
        
        public double getX() {
            return this.x;
        }
        
        public void setX(final double x) {
            this.x = x;
        }
        
        public double getY() {
            return this.y;
        }
        
        public void setY(final double y) {
            this.y = y;
        }
        
        public double getArea() {
            return this.area;
        }
        
        public void setArea(final double area) {
            this.area = area;
        }
        
        public double getAvailable() {
            return this.available;
        }
        
        public void setAvailable(final double available) {
            this.available = available;
        }
        
        public boolean isResizableWithParent() {
            return SplitPane.isResizableWithParent(this.content);
        }
        
        public double getResizableWithParentArea() {
            return this.resizableWithParentArea;
        }
        
        public void setResizableWithParentArea(final double resizableWithParentArea) {
            if (!this.isResizableWithParent()) {
                this.resizableWithParentArea = resizableWithParentArea;
            }
            else {
                this.resizableWithParentArea = 0.0;
            }
        }
        
        protected void setClipSize(final double width, final double height) {
            this.clipRect.setWidth(width);
            this.clipRect.setHeight(height);
        }
        
        private void dispose() {
            this.getChildren().remove(this.content);
        }
        
        @Override
        protected double computeMaxWidth(final double n) {
            return this.snapSizeX(this.content.maxWidth(n));
        }
        
        @Override
        protected double computeMaxHeight(final double n) {
            return this.snapSizeY(this.content.maxHeight(n));
        }
    }
}
