// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control.skin;

import javafx.collections.ObservableList;
import com.sun.javafx.scene.control.behavior.ComboBoxBaseBehavior;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.beans.value.ObservableValue;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.Node;
import javafx.scene.control.ComboBoxBase;
import javafx.scene.control.SkinBase;

public abstract class ComboBoxBaseSkin<T> extends SkinBase<ComboBoxBase<T>>
{
    private Node displayNode;
    StackPane arrowButton;
    Region arrow;
    private ComboBoxMode mode;
    private final EventHandler<MouseEvent> mouseEnteredEventHandler;
    private final EventHandler<MouseEvent> mousePressedEventHandler;
    private final EventHandler<MouseEvent> mouseReleasedEventHandler;
    private final EventHandler<MouseEvent> mouseExitedEventHandler;
    
    final ComboBoxMode getMode() {
        return this.mode;
    }
    
    final void setMode(final ComboBoxMode mode) {
        this.mode = mode;
    }
    
    public ComboBoxBaseSkin(final ComboBoxBase<T> comboBoxBase) {
        super(comboBoxBase);
        this.mode = ComboBoxMode.COMBOBOX;
        this.mouseEnteredEventHandler = (mouseEvent -> this.getBehavior().mouseEntered(mouseEvent));
        this.mousePressedEventHandler = (mouseEvent2 -> {
            this.getBehavior().mousePressed(mouseEvent2);
            mouseEvent2.consume();
            return;
        });
        this.mouseReleasedEventHandler = (mouseEvent3 -> {
            this.getBehavior().mouseReleased(mouseEvent3);
            mouseEvent3.consume();
            return;
        });
        this.mouseExitedEventHandler = (mouseEvent4 -> this.getBehavior().mouseExited(mouseEvent4));
        this.getChildren().clear();
        (this.arrow = new Region()).setFocusTraversable(false);
        this.arrow.getStyleClass().setAll("arrow");
        this.arrow.setId("arrow");
        this.arrow.setMaxWidth(Double.NEGATIVE_INFINITY);
        this.arrow.setMaxHeight(Double.NEGATIVE_INFINITY);
        this.arrow.setMouseTransparent(true);
        (this.arrowButton = new StackPane()).setFocusTraversable(false);
        this.arrowButton.setId("arrow-button");
        this.arrowButton.getStyleClass().setAll("arrow-button");
        this.arrowButton.getChildren().add(this.arrow);
        this.getChildren().add(this.arrowButton);
        this.getSkinnable().focusedProperty().addListener((p0, p1, b) -> {
            if (!b) {
                this.focusLost();
            }
            return;
        });
        this.updateArrowButtonListeners();
        this.registerChangeListener(comboBoxBase.editableProperty(), p0 -> {
            this.updateArrowButtonListeners();
            this.updateDisplayArea();
            return;
        });
        this.registerChangeListener(comboBoxBase.showingProperty(), p0 -> {
            if (this.getSkinnable().isShowing()) {
                this.show();
            }
            else {
                this.hide();
            }
            return;
        });
        this.registerChangeListener(comboBoxBase.valueProperty(), p0 -> this.updateDisplayArea());
    }
    
    public abstract Node getDisplayNode();
    
    public abstract void show();
    
    public abstract void hide();
    
    @Override
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        if (this.displayNode == null) {
            this.updateDisplayArea();
        }
        final double snapSizeX = this.snapSizeX(this.arrow.prefWidth(-1.0));
        final double n5 = this.isButton() ? 0.0 : (this.arrowButton.snappedLeftInset() + snapSizeX + this.arrowButton.snappedRightInset());
        if (this.displayNode != null) {
            this.displayNode.resizeRelocate(n, n2, n3 - n5, n4);
        }
        this.arrowButton.setVisible(!this.isButton());
        if (!this.isButton()) {
            this.arrowButton.resize(n5, n4);
            this.positionInArea(this.arrowButton, n + n3 - n5, n2, n5, n4, 0.0, HPos.CENTER, VPos.CENTER);
        }
    }
    
    @Override
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.displayNode == null) {
            this.updateDisplayArea();
        }
        final double snapSizeX = this.snapSizeX(this.arrow.prefWidth(-1.0));
        return n5 + (((this.displayNode == null) ? 0.0 : this.displayNode.prefWidth(n)) + (this.isButton() ? 0.0 : (this.arrowButton.snappedLeftInset() + snapSizeX + this.arrowButton.snappedRightInset()))) + n3;
    }
    
    @Override
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        if (this.displayNode == null) {
            this.updateDisplayArea();
        }
        double n6;
        if (this.displayNode == null) {
            n6 = Math.max(21.0, this.isButton() ? 0.0 : (this.arrowButton.snappedTopInset() + this.arrow.prefHeight(-1.0) + this.arrowButton.snappedBottomInset()));
        }
        else {
            n6 = this.displayNode.prefHeight(n);
        }
        return n2 + n6 + n4;
    }
    
    @Override
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefWidth(n);
    }
    
    @Override
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.getSkinnable().prefHeight(n);
    }
    
    @Override
    protected double computeBaselineOffset(final double n, final double n2, final double n3, final double n4) {
        if (this.displayNode == null) {
            this.updateDisplayArea();
        }
        if (this.displayNode != null) {
            return this.displayNode.getLayoutBounds().getMinY() + this.displayNode.getLayoutY() + this.displayNode.getBaselineOffset();
        }
        return super.computeBaselineOffset(n, n2, n3, n4);
    }
    
    ComboBoxBaseBehavior getBehavior() {
        return null;
    }
    
    void focusLost() {
        this.getSkinnable().hide();
    }
    
    private boolean isButton() {
        return this.getMode() == ComboBoxMode.BUTTON;
    }
    
    private void updateArrowButtonListeners() {
        if (this.getSkinnable().isEditable()) {
            this.arrowButton.addEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
            this.arrowButton.addEventHandler(MouseEvent.MOUSE_PRESSED, this.mousePressedEventHandler);
            this.arrowButton.addEventHandler(MouseEvent.MOUSE_RELEASED, this.mouseReleasedEventHandler);
            this.arrowButton.addEventHandler(MouseEvent.MOUSE_EXITED, this.mouseExitedEventHandler);
        }
        else {
            this.arrowButton.removeEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
            this.arrowButton.removeEventHandler(MouseEvent.MOUSE_PRESSED, this.mousePressedEventHandler);
            this.arrowButton.removeEventHandler(MouseEvent.MOUSE_RELEASED, this.mouseReleasedEventHandler);
            this.arrowButton.removeEventHandler(MouseEvent.MOUSE_EXITED, this.mouseExitedEventHandler);
        }
    }
    
    void updateDisplayArea() {
        final ObservableList<Node> children = this.getChildren();
        final Node displayNode = this.displayNode;
        this.displayNode = this.getDisplayNode();
        if (displayNode != null && displayNode != this.displayNode) {
            children.remove(displayNode);
        }
        if (this.displayNode != null && !children.contains(this.displayNode)) {
            children.add(this.displayNode);
            this.displayNode.applyCss();
        }
    }
}
