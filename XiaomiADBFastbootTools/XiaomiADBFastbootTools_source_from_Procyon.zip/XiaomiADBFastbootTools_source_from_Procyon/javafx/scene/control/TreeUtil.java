// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.collections.ObservableList;

class TreeUtil
{
    static <T> int getExpandedDescendantCount(final TreeItem<T> treeItem, final boolean b) {
        if (treeItem == null) {
            return 0;
        }
        if (treeItem.isLeaf()) {
            return 1;
        }
        return treeItem.getExpandedDescendentCount(b);
    }
    
    static int updateExpandedItemCount(final TreeItem treeItem, final boolean b, final boolean b2) {
        if (treeItem == null) {
            return 0;
        }
        if (!treeItem.isExpanded()) {
            return 1;
        }
        int expandedDescendantCount = getExpandedDescendantCount((TreeItem<Object>)treeItem, b);
        if (!b2) {
            --expandedDescendantCount;
        }
        return expandedDescendantCount;
    }
    
    static <T> TreeItem<T> getItem(final TreeItem<T> treeItem, final int n, final boolean b) {
        if (treeItem == null) {
            return null;
        }
        if (n == 0) {
            return treeItem;
        }
        if (n >= getExpandedDescendantCount(treeItem, b)) {
            return null;
        }
        final ObservableList<TreeItem<T>> children = treeItem.getChildren();
        if (children == null) {
            return null;
        }
        int n2 = n - 1;
        for (int i = 0; i < children.size(); ++i) {
            final TreeItem<Object> treeItem2 = children.get(i);
            if (n2 == 0) {
                return (TreeItem<T>)treeItem2;
            }
            if (treeItem2.isLeaf() || !treeItem2.isExpanded()) {
                --n2;
            }
            else {
                final int expandedDescendantCount = getExpandedDescendantCount((TreeItem<T>)treeItem2, b);
                if (n2 >= expandedDescendantCount) {
                    n2 -= expandedDescendantCount;
                }
                else {
                    final TreeItem<Object> item = getItem(treeItem2, n2, b);
                    if (item != null) {
                        return (TreeItem<T>)item;
                    }
                    --n2;
                }
            }
        }
        return null;
    }
    
    static <T> int getRow(final TreeItem<T> treeItem, final TreeItem<T> treeItem2, final boolean b, final boolean b2) {
        if (treeItem == null) {
            return -1;
        }
        if (b2 && treeItem.equals(treeItem2)) {
            return 0;
        }
        int n = 0;
        TreeItem<T> treeItem3 = treeItem;
        TreeItem<T> treeItem4 = treeItem.getParent();
        boolean b3 = false;
        while (!treeItem3.equals(treeItem2) && treeItem4 != null) {
            if (!treeItem4.isExpanded()) {
                b3 = true;
                break;
            }
            final ObservableList<TreeItem<T>> children = treeItem4.children;
            for (int i = children.indexOf(treeItem3) - 1; i > -1; --i) {
                final TreeItem<Object> treeItem5 = children.get(i);
                if (treeItem5 != null) {
                    n += getExpandedDescendantCount(treeItem5, b);
                    if (treeItem5.equals(treeItem2)) {
                        if (!b2) {
                            return -1;
                        }
                        return n;
                    }
                }
            }
            treeItem3 = treeItem4;
            treeItem4 = treeItem4.getParent();
            if (treeItem4 == null && !treeItem3.equals(treeItem2)) {
                return -1;
            }
            ++n;
        }
        return ((treeItem4 == null && n == 0) || b3) ? -1 : (b2 ? n : (n - 1));
    }
}
