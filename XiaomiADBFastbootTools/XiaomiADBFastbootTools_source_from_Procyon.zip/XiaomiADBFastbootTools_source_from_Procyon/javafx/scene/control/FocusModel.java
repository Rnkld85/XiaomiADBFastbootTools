// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.Observable;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyIntegerWrapper;

public abstract class FocusModel<T>
{
    private ReadOnlyIntegerWrapper focusedIndex;
    private ReadOnlyObjectWrapper<T> focusedItem;
    
    public FocusModel() {
        this.focusedIndex = new ReadOnlyIntegerWrapper(this, "focusedIndex", -1);
        this.focusedItem = new ReadOnlyObjectWrapper<T>(this, "focusedItem");
        this.focusedIndexProperty().addListener(p0 -> this.setFocusedItem(this.getModelItem(this.getFocusedIndex())));
    }
    
    public final ReadOnlyIntegerProperty focusedIndexProperty() {
        return this.focusedIndex.getReadOnlyProperty();
    }
    
    public final int getFocusedIndex() {
        return this.focusedIndex.get();
    }
    
    final void setFocusedIndex(final int n) {
        this.focusedIndex.set(n);
    }
    
    public final ReadOnlyObjectProperty<T> focusedItemProperty() {
        return this.focusedItem.getReadOnlyProperty();
    }
    
    public final T getFocusedItem() {
        return this.focusedItemProperty().get();
    }
    
    final void setFocusedItem(final T t) {
        this.focusedItem.set(t);
    }
    
    protected abstract int getItemCount();
    
    protected abstract T getModelItem(final int p0);
    
    public boolean isFocused(final int n) {
        return n >= 0 && n < this.getItemCount() && this.getFocusedIndex() == n;
    }
    
    public void focus(final int focusedIndex) {
        if (focusedIndex < 0 || focusedIndex >= this.getItemCount()) {
            this.setFocusedIndex(-1);
        }
        else {
            final int focusedIndex2 = this.getFocusedIndex();
            this.setFocusedIndex(focusedIndex);
            if (focusedIndex2 == focusedIndex) {
                this.setFocusedItem(this.getModelItem(focusedIndex));
            }
        }
    }
    
    public void focusPrevious() {
        if (this.getFocusedIndex() == -1) {
            this.focus(0);
        }
        else if (this.getFocusedIndex() > 0) {
            this.focus(this.getFocusedIndex() - 1);
        }
    }
    
    public void focusNext() {
        if (this.getFocusedIndex() == -1) {
            this.focus(0);
        }
        else if (this.getFocusedIndex() != this.getItemCount() - 1) {
            this.focus(this.getFocusedIndex() + 1);
        }
    }
}
