// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.collections.ObservableList;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.ObjectProperty;

public abstract class MultipleSelectionModel<T> extends SelectionModel<T>
{
    private ObjectProperty<SelectionMode> selectionMode;
    
    public final void setSelectionMode(final SelectionMode selectionMode) {
        this.selectionModeProperty().set(selectionMode);
    }
    
    public final SelectionMode getSelectionMode() {
        return (this.selectionMode == null) ? SelectionMode.SINGLE : this.selectionMode.get();
    }
    
    public final ObjectProperty<SelectionMode> selectionModeProperty() {
        if (this.selectionMode == null) {
            this.selectionMode = new ObjectPropertyBase<SelectionMode>(SelectionMode.SINGLE) {
                @Override
                protected void invalidated() {
                    if (MultipleSelectionModel.this.getSelectionMode() == SelectionMode.SINGLE && !MultipleSelectionModel.this.isEmpty()) {
                        final int selectedIndex = MultipleSelectionModel.this.getSelectedIndex();
                        MultipleSelectionModel.this.clearSelection();
                        MultipleSelectionModel.this.select(selectedIndex);
                    }
                }
                
                @Override
                public Object getBean() {
                    return MultipleSelectionModel.this;
                }
                
                @Override
                public String getName() {
                    return "selectionMode";
                }
            };
        }
        return this.selectionMode;
    }
    
    public abstract ObservableList<Integer> getSelectedIndices();
    
    public abstract ObservableList<T> getSelectedItems();
    
    public abstract void selectIndices(final int p0, final int... p1);
    
    public void selectRange(final int n, final int n2) {
        if (n == n2) {
            return;
        }
        final boolean b = n < n2;
        final int n3 = b ? n : n2;
        final int n4 = b ? n2 : n;
        final int n5 = n4 - n3 - 1;
        final int[] array = new int[n5];
        int n6 = b ? n3 : n4;
        final int n7 = b ? n6++ : n6--;
        for (int i = 0; i < n5; ++i) {
            array[i] = (b ? n6++ : n6--);
        }
        this.selectIndices(n7, array);
    }
    
    public abstract void selectAll();
    
    @Override
    public abstract void selectFirst();
    
    @Override
    public abstract void selectLast();
}
