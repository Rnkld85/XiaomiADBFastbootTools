// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.BooleanConverter;
import javafx.beans.Observable;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.DatePickerSkin;
import com.sun.javafx.scene.control.FakeFocusTextField;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableBooleanProperty;
import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.scene.AccessibleRole;
import javafx.beans.property.SimpleObjectProperty;
import java.time.chrono.IsoChronology;
import java.time.DateTimeException;
import java.time.temporal.TemporalAccessor;
import java.util.Locale;
import javafx.util.converter.LocalDateStringConverter;
import java.time.format.FormatStyle;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.util.StringConverter;
import javafx.beans.property.BooleanProperty;
import javafx.util.Callback;
import javafx.beans.property.ObjectProperty;
import java.time.chrono.Chronology;
import java.time.LocalDate;

public class DatePicker extends ComboBoxBase<LocalDate>
{
    private LocalDate lastValidDate;
    private Chronology lastValidChronology;
    private ObjectProperty<Callback<DatePicker, DateCell>> dayCellFactory;
    private ObjectProperty<Chronology> chronology;
    private BooleanProperty showWeekNumbers;
    private ObjectProperty<StringConverter<LocalDate>> converter;
    private StringConverter<LocalDate> defaultConverter;
    private ReadOnlyObjectWrapper<TextField> editor;
    private static final String DEFAULT_STYLE_CLASS = "date-picker";
    
    public DatePicker() {
        this(null);
        final LocalDate lastValidDate;
        this.valueProperty().addListener(p0 -> {
            lastValidDate = this.getValue();
            if (this.validateDate(this.getChronology(), lastValidDate)) {
                this.lastValidDate = lastValidDate;
            }
            else {
                System.err.println(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, (this.lastValidDate == null) ? "null" : this.getConverter().toString(this.lastValidDate)));
                this.setValue(this.lastValidDate);
            }
            return;
        });
        final LocalDate localDate;
        final Chronology lastValidChronology;
        this.chronologyProperty().addListener(p0 -> {
            localDate = this.getValue();
            this.getChronology();
            if (this.validateDate(lastValidChronology, localDate)) {
                this.lastValidChronology = lastValidChronology;
                this.defaultConverter = new LocalDateStringConverter(FormatStyle.SHORT, null, lastValidChronology);
            }
            else {
                System.err.println(invokedynamic(makeConcatWithConstants:(Ljava/time/chrono/Chronology;)Ljava/lang/String;, this.lastValidChronology));
                this.setChronology(this.lastValidChronology);
            }
        });
    }
    
    private boolean validateDate(final Chronology chronology, final LocalDate localDate) {
        try {
            if (localDate != null) {
                chronology.date(localDate);
            }
            return true;
        }
        catch (DateTimeException x) {
            System.err.println(x);
            return false;
        }
    }
    
    public DatePicker(final LocalDate value) {
        this.lastValidDate = null;
        this.lastValidChronology = IsoChronology.INSTANCE;
        this.chronology = new SimpleObjectProperty<Chronology>(this, "chronology", null);
        this.converter = new SimpleObjectProperty<StringConverter<LocalDate>>(this, "converter", null);
        this.defaultConverter = new LocalDateStringConverter(FormatStyle.SHORT, null, this.getChronology());
        this.setValue(value);
        this.getStyleClass().add("date-picker");
        this.setAccessibleRole(AccessibleRole.DATE_PICKER);
        this.setEditable(true);
    }
    
    public final void setDayCellFactory(final Callback<DatePicker, DateCell> callback) {
        this.dayCellFactoryProperty().set(callback);
    }
    
    public final Callback<DatePicker, DateCell> getDayCellFactory() {
        return (this.dayCellFactory != null) ? this.dayCellFactory.get() : null;
    }
    
    public final ObjectProperty<Callback<DatePicker, DateCell>> dayCellFactoryProperty() {
        if (this.dayCellFactory == null) {
            this.dayCellFactory = new SimpleObjectProperty<Callback<DatePicker, DateCell>>(this, "dayCellFactory");
        }
        return this.dayCellFactory;
    }
    
    public final ObjectProperty<Chronology> chronologyProperty() {
        return this.chronology;
    }
    
    public final Chronology getChronology() {
        Chronology chronology = this.chronology.get();
        if (chronology == null) {
            try {
                chronology = Chronology.ofLocale(Locale.getDefault(Locale.Category.FORMAT));
            }
            catch (Exception x) {
                System.err.println(x);
            }
            if (chronology == null) {
                chronology = IsoChronology.INSTANCE;
            }
        }
        return chronology;
    }
    
    public final void setChronology(final Chronology value) {
        this.chronology.setValue(value);
    }
    
    public final BooleanProperty showWeekNumbersProperty() {
        if (this.showWeekNumbers == null) {
            final String country = Locale.getDefault(Locale.Category.FORMAT).getCountry();
            this.showWeekNumbers = new StyleableBooleanProperty(!country.isEmpty() && ControlResources.getNonTranslatableString("DatePicker.showWeekNumbers").contains(country)) {
                @Override
                public CssMetaData<DatePicker, Boolean> getCssMetaData() {
                    return StyleableProperties.SHOW_WEEK_NUMBERS;
                }
                
                @Override
                public Object getBean() {
                    return DatePicker.this;
                }
                
                @Override
                public String getName() {
                    return "showWeekNumbers";
                }
            };
        }
        return this.showWeekNumbers;
    }
    
    public final void setShowWeekNumbers(final boolean b) {
        this.showWeekNumbersProperty().setValue(b);
    }
    
    public final boolean isShowWeekNumbers() {
        return this.showWeekNumbersProperty().getValue();
    }
    
    public final ObjectProperty<StringConverter<LocalDate>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<LocalDate> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<LocalDate> getConverter() {
        final StringConverter<LocalDate> stringConverter = this.converterProperty().get();
        if (stringConverter != null) {
            return stringConverter;
        }
        return this.defaultConverter;
    }
    
    public final TextField getEditor() {
        return this.editorProperty().get();
    }
    
    public final ReadOnlyObjectProperty<TextField> editorProperty() {
        if (this.editor == null) {
            (this.editor = new ReadOnlyObjectWrapper<TextField>(this, "editor")).set(new FakeFocusTextField());
        }
        return this.editor.getReadOnlyProperty();
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new DatePickerSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case DATE: {
                return ((ComboBoxBase<Object>)this).getValue();
            }
            case TEXT: {
                final String accessibleText = this.getAccessibleText();
                if (accessibleText != null && !accessibleText.isEmpty()) {
                    return accessibleText;
                }
                final LocalDate localDate = this.getValue();
                final StringConverter<LocalDate> converter = this.getConverter();
                if (localDate != null && converter != null) {
                    return converter.toString(localDate);
                }
                return "";
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    private static class StyleableProperties
    {
        private static final String country;
        private static final CssMetaData<DatePicker, Boolean> SHOW_WEEK_NUMBERS;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            country = Locale.getDefault(Locale.Category.FORMAT).getCountry();
            SHOW_WEEK_NUMBERS = new CssMetaData<DatePicker, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.valueOf(!StyleableProperties.country.isEmpty() && ControlResources.getNonTranslatableString("DatePicker.showWeekNumbers").contains(StyleableProperties.country))) {
                @Override
                public boolean isSettable(final DatePicker datePicker) {
                    return datePicker.showWeekNumbers == null || !datePicker.showWeekNumbers.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final DatePicker datePicker) {
                    return (StyleableProperty<Boolean>)datePicker.showWeekNumbersProperty();
                }
            };
            final ArrayList<Object> list = new ArrayList<Object>(Control.getClassCssMetaData());
            Collections.addAll(list, StyleableProperties.SHOW_WEEK_NUMBERS);
            STYLEABLES = Collections.unmodifiableList((List<? extends CssMetaData<? extends Styleable, ?>>)list);
        }
    }
}
