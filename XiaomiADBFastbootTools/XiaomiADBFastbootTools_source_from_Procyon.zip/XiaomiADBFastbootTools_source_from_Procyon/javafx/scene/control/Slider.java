// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.EnumConverter;
import javafx.css.converter.BooleanConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.scene.AccessibleAction;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.SliderSkin;
import com.sun.javafx.util.Utils;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.StyleableIntegerProperty;
import javafx.css.StyleableDoubleProperty;
import javafx.css.StyleableBooleanProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.AccessibleAttribute;
import javafx.beans.property.DoublePropertyBase;
import javafx.scene.AccessibleRole;
import javafx.css.PseudoClass;
import javafx.util.StringConverter;
import javafx.beans.property.IntegerProperty;
import javafx.geometry.Orientation;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;

public class Slider extends Control
{
    private DoubleProperty max;
    private DoubleProperty min;
    private DoubleProperty value;
    private BooleanProperty valueChanging;
    private ObjectProperty<Orientation> orientation;
    private BooleanProperty showTickLabels;
    private BooleanProperty showTickMarks;
    private DoubleProperty majorTickUnit;
    private IntegerProperty minorTickCount;
    private BooleanProperty snapToTicks;
    private ObjectProperty<StringConverter<Double>> labelFormatter;
    private DoubleProperty blockIncrement;
    private static final String DEFAULT_STYLE_CLASS = "slider";
    private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE;
    private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE;
    
    public Slider() {
        this.initialize();
    }
    
    public Slider(final double min, final double max, final double value) {
        this.setMax(max);
        this.setMin(min);
        this.setValue(value);
        this.adjustValues();
        this.initialize();
    }
    
    private void initialize() {
        this.getStyleClass().setAll("slider");
        this.setAccessibleRole(AccessibleRole.SLIDER);
    }
    
    public final void setMax(final double n) {
        this.maxProperty().set(n);
    }
    
    public final double getMax() {
        return (this.max == null) ? 100.0 : this.max.get();
    }
    
    public final DoubleProperty maxProperty() {
        if (this.max == null) {
            this.max = new DoublePropertyBase(100.0) {
                @Override
                protected void invalidated() {
                    if (this.get() < Slider.this.getMin()) {
                        Slider.this.setMin(this.get());
                    }
                    Slider.this.adjustValues();
                    Slider.this.notifyAccessibleAttributeChanged(AccessibleAttribute.MAX_VALUE);
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "max";
                }
            };
        }
        return this.max;
    }
    
    public final void setMin(final double n) {
        this.minProperty().set(n);
    }
    
    public final double getMin() {
        return (this.min == null) ? 0.0 : this.min.get();
    }
    
    public final DoubleProperty minProperty() {
        if (this.min == null) {
            this.min = new DoublePropertyBase(0.0) {
                @Override
                protected void invalidated() {
                    if (this.get() > Slider.this.getMax()) {
                        Slider.this.setMax(this.get());
                    }
                    Slider.this.adjustValues();
                    Slider.this.notifyAccessibleAttributeChanged(AccessibleAttribute.MIN_VALUE);
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "min";
                }
            };
        }
        return this.min;
    }
    
    public final void setValue(final double n) {
        if (!this.valueProperty().isBound()) {
            this.valueProperty().set(n);
        }
    }
    
    public final double getValue() {
        return (this.value == null) ? 0.0 : this.value.get();
    }
    
    public final DoubleProperty valueProperty() {
        if (this.value == null) {
            this.value = new DoublePropertyBase(0.0) {
                @Override
                protected void invalidated() {
                    Slider.this.adjustValues();
                    Slider.this.notifyAccessibleAttributeChanged(AccessibleAttribute.VALUE);
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "value";
                }
            };
        }
        return this.value;
    }
    
    public final void setValueChanging(final boolean b) {
        this.valueChangingProperty().set(b);
    }
    
    public final boolean isValueChanging() {
        return this.valueChanging != null && this.valueChanging.get();
    }
    
    public final BooleanProperty valueChangingProperty() {
        if (this.valueChanging == null) {
            this.valueChanging = new SimpleBooleanProperty(this, "valueChanging", false);
        }
        return this.valueChanging;
    }
    
    public final void setOrientation(final Orientation orientation) {
        this.orientationProperty().set(orientation);
    }
    
    public final Orientation getOrientation() {
        return (this.orientation == null) ? Orientation.HORIZONTAL : this.orientation.get();
    }
    
    public final ObjectProperty<Orientation> orientationProperty() {
        if (this.orientation == null) {
            this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL) {
                @Override
                protected void invalidated() {
                    final boolean b = this.get() == Orientation.VERTICAL;
                    Slider.this.pseudoClassStateChanged(Slider.VERTICAL_PSEUDOCLASS_STATE, b);
                    Slider.this.pseudoClassStateChanged(Slider.HORIZONTAL_PSEUDOCLASS_STATE, !b);
                }
                
                @Override
                public CssMetaData<Slider, Orientation> getCssMetaData() {
                    return StyleableProperties.ORIENTATION;
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "orientation";
                }
            };
        }
        return this.orientation;
    }
    
    public final void setShowTickLabels(final boolean b) {
        this.showTickLabelsProperty().set(b);
    }
    
    public final boolean isShowTickLabels() {
        return this.showTickLabels != null && this.showTickLabels.get();
    }
    
    public final BooleanProperty showTickLabelsProperty() {
        if (this.showTickLabels == null) {
            this.showTickLabels = new StyleableBooleanProperty(false) {
                @Override
                public CssMetaData<Slider, Boolean> getCssMetaData() {
                    return StyleableProperties.SHOW_TICK_LABELS;
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "showTickLabels";
                }
            };
        }
        return this.showTickLabels;
    }
    
    public final void setShowTickMarks(final boolean b) {
        this.showTickMarksProperty().set(b);
    }
    
    public final boolean isShowTickMarks() {
        return this.showTickMarks != null && this.showTickMarks.get();
    }
    
    public final BooleanProperty showTickMarksProperty() {
        if (this.showTickMarks == null) {
            this.showTickMarks = new StyleableBooleanProperty(false) {
                @Override
                public CssMetaData<Slider, Boolean> getCssMetaData() {
                    return StyleableProperties.SHOW_TICK_MARKS;
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "showTickMarks";
                }
            };
        }
        return this.showTickMarks;
    }
    
    public final void setMajorTickUnit(final double n) {
        if (n <= 0.0) {
            throw new IllegalArgumentException("MajorTickUnit cannot be less than or equal to 0.");
        }
        this.majorTickUnitProperty().set(n);
    }
    
    public final double getMajorTickUnit() {
        return (this.majorTickUnit == null) ? 25.0 : this.majorTickUnit.get();
    }
    
    public final DoubleProperty majorTickUnitProperty() {
        if (this.majorTickUnit == null) {
            this.majorTickUnit = new StyleableDoubleProperty(25.0) {
                public void invalidated() {
                    if (this.get() <= 0.0) {
                        throw new IllegalArgumentException("MajorTickUnit cannot be less than or equal to 0.");
                    }
                }
                
                @Override
                public CssMetaData<Slider, Number> getCssMetaData() {
                    return StyleableProperties.MAJOR_TICK_UNIT;
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "majorTickUnit";
                }
            };
        }
        return this.majorTickUnit;
    }
    
    public final void setMinorTickCount(final int n) {
        this.minorTickCountProperty().set(n);
    }
    
    public final int getMinorTickCount() {
        return (this.minorTickCount == null) ? 3 : this.minorTickCount.get();
    }
    
    public final IntegerProperty minorTickCountProperty() {
        if (this.minorTickCount == null) {
            this.minorTickCount = new StyleableIntegerProperty(3) {
                @Override
                public CssMetaData<Slider, Number> getCssMetaData() {
                    return StyleableProperties.MINOR_TICK_COUNT;
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "minorTickCount";
                }
            };
        }
        return this.minorTickCount;
    }
    
    public final void setSnapToTicks(final boolean b) {
        this.snapToTicksProperty().set(b);
    }
    
    public final boolean isSnapToTicks() {
        return this.snapToTicks != null && this.snapToTicks.get();
    }
    
    public final BooleanProperty snapToTicksProperty() {
        if (this.snapToTicks == null) {
            this.snapToTicks = new StyleableBooleanProperty(false) {
                @Override
                public CssMetaData<Slider, Boolean> getCssMetaData() {
                    return StyleableProperties.SNAP_TO_TICKS;
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "snapToTicks";
                }
            };
        }
        return this.snapToTicks;
    }
    
    public final void setLabelFormatter(final StringConverter<Double> stringConverter) {
        this.labelFormatterProperty().set(stringConverter);
    }
    
    public final StringConverter<Double> getLabelFormatter() {
        return (this.labelFormatter == null) ? null : this.labelFormatter.get();
    }
    
    public final ObjectProperty<StringConverter<Double>> labelFormatterProperty() {
        if (this.labelFormatter == null) {
            this.labelFormatter = new SimpleObjectProperty<StringConverter<Double>>(this, "labelFormatter");
        }
        return this.labelFormatter;
    }
    
    public final void setBlockIncrement(final double n) {
        this.blockIncrementProperty().set(n);
    }
    
    public final double getBlockIncrement() {
        return (this.blockIncrement == null) ? 10.0 : this.blockIncrement.get();
    }
    
    public final DoubleProperty blockIncrementProperty() {
        if (this.blockIncrement == null) {
            this.blockIncrement = new StyleableDoubleProperty(10.0) {
                @Override
                public CssMetaData<Slider, Number> getCssMetaData() {
                    return StyleableProperties.BLOCK_INCREMENT;
                }
                
                @Override
                public Object getBean() {
                    return Slider.this;
                }
                
                @Override
                public String getName() {
                    return "blockIncrement";
                }
            };
        }
        return this.blockIncrement;
    }
    
    public void adjustValue(double n) {
        final double min = this.getMin();
        final double max = this.getMax();
        if (max <= min) {
            return;
        }
        n = ((n < min) ? min : n);
        n = ((n > max) ? max : n);
        this.setValue(this.snapValueToTicks(n));
    }
    
    public void increment() {
        this.adjustValue(this.getValue() + this.getBlockIncrement());
    }
    
    public void decrement() {
        this.adjustValue(this.getValue() - this.getBlockIncrement());
    }
    
    private void adjustValues() {
        if (this.getValue() < this.getMin() || this.getValue() > this.getMax()) {
            this.setValue(Utils.clamp(this.getMin(), this.getValue(), this.getMax()));
        }
    }
    
    private double snapValueToTicks(final double n) {
        double nearest = n;
        if (this.isSnapToTicks()) {
            double majorTickUnit;
            if (this.getMinorTickCount() != 0) {
                majorTickUnit = this.getMajorTickUnit() / (Math.max(this.getMinorTickCount(), 0) + 1);
            }
            else {
                majorTickUnit = this.getMajorTickUnit();
            }
            final int n2 = (int)((nearest - this.getMin()) / majorTickUnit);
            nearest = Utils.nearest(n2 * majorTickUnit + this.getMin(), nearest, (n2 + 1) * majorTickUnit + this.getMin());
        }
        return Utils.clamp(this.getMin(), nearest, this.getMax());
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new SliderSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    protected List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case VALUE: {
                return this.getValue();
            }
            case MAX_VALUE: {
                return this.getMax();
            }
            case MIN_VALUE: {
                return this.getMin();
            }
            case ORIENTATION: {
                return this.getOrientation();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case INCREMENT: {
                this.increment();
                break;
            }
            case DECREMENT: {
                this.decrement();
                break;
            }
            case SET_VALUE: {
                final Double n = (Double)array[0];
                if (n != null) {
                    this.setValue(n);
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    static {
        VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
        HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Slider, Number> BLOCK_INCREMENT;
        private static final CssMetaData<Slider, Boolean> SHOW_TICK_LABELS;
        private static final CssMetaData<Slider, Boolean> SHOW_TICK_MARKS;
        private static final CssMetaData<Slider, Boolean> SNAP_TO_TICKS;
        private static final CssMetaData<Slider, Number> MAJOR_TICK_UNIT;
        private static final CssMetaData<Slider, Number> MINOR_TICK_COUNT;
        private static final CssMetaData<Slider, Orientation> ORIENTATION;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            BLOCK_INCREMENT = new CssMetaData<Slider, Number>((StyleConverter)SizeConverter.getInstance(), (Number)10.0) {
                @Override
                public boolean isSettable(final Slider slider) {
                    return slider.blockIncrement == null || !slider.blockIncrement.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Slider slider) {
                    return (StyleableProperty<Number>)slider.blockIncrementProperty();
                }
            };
            SHOW_TICK_LABELS = new CssMetaData<Slider, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
                @Override
                public boolean isSettable(final Slider slider) {
                    return slider.showTickLabels == null || !slider.showTickLabels.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Slider slider) {
                    return (StyleableProperty<Boolean>)slider.showTickLabelsProperty();
                }
            };
            SHOW_TICK_MARKS = new CssMetaData<Slider, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
                @Override
                public boolean isSettable(final Slider slider) {
                    return slider.showTickMarks == null || !slider.showTickMarks.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Slider slider) {
                    return (StyleableProperty<Boolean>)slider.showTickMarksProperty();
                }
            };
            SNAP_TO_TICKS = new CssMetaData<Slider, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
                @Override
                public boolean isSettable(final Slider slider) {
                    return slider.snapToTicks == null || !slider.snapToTicks.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Slider slider) {
                    return (StyleableProperty<Boolean>)slider.snapToTicksProperty();
                }
            };
            MAJOR_TICK_UNIT = new CssMetaData<Slider, Number>((StyleConverter)SizeConverter.getInstance(), (Number)25.0) {
                @Override
                public boolean isSettable(final Slider slider) {
                    return slider.majorTickUnit == null || !slider.majorTickUnit.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Slider slider) {
                    return (StyleableProperty<Number>)slider.majorTickUnitProperty();
                }
            };
            MINOR_TICK_COUNT = new CssMetaData<Slider, Number>((StyleConverter)SizeConverter.getInstance(), (Number)3.0) {
                @Override
                public boolean isSettable(final Slider slider) {
                    return slider.minorTickCount == null || !slider.minorTickCount.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Slider slider) {
                    return (StyleableProperty<Number>)slider.minorTickCountProperty();
                }
            };
            ORIENTATION = new CssMetaData<Slider, Orientation>((StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL) {
                @Override
                public Orientation getInitialValue(final Slider slider) {
                    return slider.getOrientation();
                }
                
                @Override
                public boolean isSettable(final Slider slider) {
                    return slider.orientation == null || !slider.orientation.isBound();
                }
                
                @Override
                public StyleableProperty<Orientation> getStyleableProperty(final Slider slider) {
                    return (StyleableProperty<Orientation>)(StyleableProperty)slider.orientationProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.BLOCK_INCREMENT);
            list.add(StyleableProperties.SHOW_TICK_LABELS);
            list.add(StyleableProperties.SHOW_TICK_MARKS);
            list.add(StyleableProperties.SNAP_TO_TICKS);
            list.add(StyleableProperties.MAJOR_TICK_UNIT);
            list.add(StyleableProperties.MINOR_TICK_COUNT);
            list.add(StyleableProperties.ORIENTATION);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
