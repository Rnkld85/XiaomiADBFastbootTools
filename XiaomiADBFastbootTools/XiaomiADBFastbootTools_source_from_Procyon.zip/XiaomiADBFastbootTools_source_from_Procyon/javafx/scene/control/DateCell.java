// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.AccessibleAttribute;
import javafx.scene.control.skin.DateCellSkin;
import javafx.scene.AccessibleRole;
import java.time.LocalDate;

public class DateCell extends Cell<LocalDate>
{
    private static final String DEFAULT_STYLE_CLASS = "date-cell";
    
    public DateCell() {
        this.getStyleClass().add("date-cell");
        this.setAccessibleRole(AccessibleRole.TEXT);
    }
    
    public void updateItem(final LocalDate localDate, final boolean b) {
        super.updateItem(localDate, b);
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new DateCellSkin(this);
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case TEXT: {
                if (this.isFocused()) {
                    return this.getText();
                }
                return "";
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
}
