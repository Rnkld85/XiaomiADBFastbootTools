// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import javafx.css.PseudoClass;
import javafx.css.Styleable;
import javafx.css.CssMetaData;
import java.util.List;
import javafx.scene.layout.Region;
import javafx.geometry.Insets;
import java.util.function.Consumer;
import javafx.beans.value.ObservableValue;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import com.sun.javafx.scene.control.LambdaMultiplePropertyChangeListenerHandler;
import javafx.scene.Node;
import javafx.collections.ObservableList;

public abstract class SkinBase<C extends Control> implements Skin<C>
{
    private C control;
    private ObservableList<Node> children;
    private LambdaMultiplePropertyChangeListenerHandler lambdaChangeListenerHandler;
    private static final EventHandler<MouseEvent> mouseEventConsumer;
    
    protected SkinBase(final C control) {
        if (control == null) {
            throw new IllegalArgumentException("Cannot pass null for control");
        }
        this.control = control;
        this.children = control.getControlChildren();
        this.consumeMouseEvents(true);
    }
    
    @Override
    public final C getSkinnable() {
        return this.control;
    }
    
    @Override
    public final Node getNode() {
        return this.control;
    }
    
    @Override
    public void dispose() {
        if (this.lambdaChangeListenerHandler != null) {
            this.lambdaChangeListenerHandler.dispose();
        }
        this.control = null;
    }
    
    public final ObservableList<Node> getChildren() {
        return this.children;
    }
    
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            if (node.isManaged()) {
                this.layoutInArea(node, n, n2, n3, n4, -1.0, HPos.CENTER, VPos.CENTER);
            }
        }
    }
    
    protected final void consumeMouseEvents(final boolean b) {
        if (b) {
            this.control.addEventHandler(MouseEvent.ANY, SkinBase.mouseEventConsumer);
        }
        else {
            this.control.removeEventHandler(MouseEvent.ANY, SkinBase.mouseEventConsumer);
        }
    }
    
    protected final void registerChangeListener(final ObservableValue<?> observableValue, final Consumer<ObservableValue<?>> consumer) {
        if (this.lambdaChangeListenerHandler == null) {
            this.lambdaChangeListenerHandler = new LambdaMultiplePropertyChangeListenerHandler();
        }
        this.lambdaChangeListenerHandler.registerChangeListener(observableValue, consumer);
    }
    
    protected final Consumer<ObservableValue<?>> unregisterChangeListeners(final ObservableValue<?> observableValue) {
        if (this.lambdaChangeListenerHandler == null) {
            return null;
        }
        return this.lambdaChangeListenerHandler.unregisterChangeListeners(observableValue);
    }
    
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        double min = 0.0;
        double max = 0.0;
        int n6 = 1;
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            if (node.isManaged()) {
                final double b = node.getLayoutBounds().getMinX() + node.getLayoutX();
                if (n6 == 0) {
                    min = Math.min(min, b);
                    max = Math.max(max, b + node.minWidth(-1.0));
                }
                else {
                    min = b;
                    max = b + node.minWidth(-1.0);
                    n6 = 0;
                }
            }
        }
        return n5 + (max - min) + n3;
    }
    
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double min = 0.0;
        double max = 0.0;
        int n6 = 1;
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            if (node.isManaged()) {
                final double b = node.getLayoutBounds().getMinY() + node.getLayoutY();
                if (n6 == 0) {
                    min = Math.min(min, b);
                    max = Math.max(max, b + node.minHeight(-1.0));
                }
                else {
                    min = b;
                    max = b + node.minHeight(-1.0);
                    n6 = 0;
                }
            }
        }
        return n2 + (max - min) + n4;
    }
    
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Double.MAX_VALUE;
    }
    
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return Double.MAX_VALUE;
    }
    
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        double min = 0.0;
        double max = 0.0;
        int n6 = 1;
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            if (node.isManaged()) {
                final double b = node.getLayoutBounds().getMinX() + node.getLayoutX();
                if (n6 == 0) {
                    min = Math.min(min, b);
                    max = Math.max(max, b + node.prefWidth(-1.0));
                }
                else {
                    min = b;
                    max = b + node.prefWidth(-1.0);
                    n6 = 0;
                }
            }
        }
        return max - min;
    }
    
    protected double computePrefHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        double min = 0.0;
        double max = 0.0;
        int n6 = 1;
        for (int i = 0; i < this.children.size(); ++i) {
            final Node node = this.children.get(i);
            if (node.isManaged()) {
                final double b = node.getLayoutBounds().getMinY() + node.getLayoutY();
                if (n6 == 0) {
                    min = Math.min(min, b);
                    max = Math.max(max, b + node.prefHeight(-1.0));
                }
                else {
                    min = b;
                    max = b + node.prefHeight(-1.0);
                    n6 = 0;
                }
            }
        }
        return max - min;
    }
    
    protected double computeBaselineOffset(final double n, final double n2, final double n3, final double n4) {
        for (int size = this.children.size(), i = 0; i < size; ++i) {
            final Node node = this.children.get(i);
            if (node.isManaged()) {
                final double baselineOffset = node.getBaselineOffset();
                if (baselineOffset != Double.NEGATIVE_INFINITY) {
                    return node.getLayoutBounds().getMinY() + node.getLayoutY() + baselineOffset;
                }
            }
        }
        return Double.NEGATIVE_INFINITY;
    }
    
    protected double snappedTopInset() {
        return this.control.snappedTopInset();
    }
    
    protected double snappedBottomInset() {
        return this.control.snappedBottomInset();
    }
    
    protected double snappedLeftInset() {
        return this.control.snappedLeftInset();
    }
    
    protected double snappedRightInset() {
        return this.control.snappedRightInset();
    }
    
    @Deprecated(since = "9")
    protected double snapSpace(final double n) {
        return this.control.snapSpaceX(n);
    }
    
    protected double snapSpaceX(final double n) {
        return this.control.snapSpaceX(n);
    }
    
    protected double snapSpaceY(final double n) {
        return this.control.snapSpaceY(n);
    }
    
    @Deprecated(since = "9")
    protected double snapSize(final double n) {
        return this.control.snapSizeX(n);
    }
    
    protected double snapSizeX(final double n) {
        return this.control.snapSizeX(n);
    }
    
    protected double snapSizeY(final double n) {
        return this.control.snapSizeY(n);
    }
    
    @Deprecated(since = "9")
    protected double snapPosition(final double n) {
        return this.control.snapPositionX(n);
    }
    
    protected double snapPositionX(final double n) {
        return this.control.snapPositionX(n);
    }
    
    protected double snapPositionY(final double n) {
        return this.control.snapPositionY(n);
    }
    
    protected void positionInArea(final Node node, final double n, final double n2, final double n3, final double n4, final double n5, final HPos hPos, final VPos vPos) {
        this.positionInArea(node, n, n2, n3, n4, n5, Insets.EMPTY, hPos, vPos);
    }
    
    protected void positionInArea(final Node node, final double n, final double n2, final double n3, final double n4, final double n5, final Insets insets, final HPos hPos, final VPos vPos) {
        Region.positionInArea(node, n, n2, n3, n4, n5, insets, hPos, vPos, this.control.isSnapToPixel());
    }
    
    protected void layoutInArea(final Node node, final double n, final double n2, final double n3, final double n4, final double n5, final HPos hPos, final VPos vPos) {
        this.layoutInArea(node, n, n2, n3, n4, n5, Insets.EMPTY, true, true, hPos, vPos);
    }
    
    protected void layoutInArea(final Node node, final double n, final double n2, final double n3, final double n4, final double n5, final Insets insets, final HPos hPos, final VPos vPos) {
        this.layoutInArea(node, n, n2, n3, n4, n5, insets, true, true, hPos, vPos);
    }
    
    protected void layoutInArea(final Node node, final double n, final double n2, final double n3, final double n4, final double n5, final Insets insets, final boolean b, final boolean b2, final HPos hPos, final VPos vPos) {
        Region.layoutInArea(node, n, n2, n3, n4, n5, insets, b, b2, hPos, vPos, this.control.isSnapToPixel());
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    public final void pseudoClassStateChanged(final PseudoClass pseudoClass, final boolean b) {
        final Control skinnable = this.getSkinnable();
        if (skinnable != null) {
            skinnable.pseudoClassStateChanged(pseudoClass, b);
        }
    }
    
    protected Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        return null;
    }
    
    protected void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
    }
    
    static {
        mouseEventConsumer = (mouseEvent -> mouseEvent.consume());
    }
    
    private static class StyleableProperties
    {
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            STYLEABLES = Collections.unmodifiableList((List<? extends CssMetaData<? extends Styleable, ?>>)Control.getClassCssMetaData());
        }
    }
}
