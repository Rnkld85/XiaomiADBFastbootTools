// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.control.skin.ColorPickerSkin;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.paint.Color;

public class ColorPicker extends ComboBoxBase<Color>
{
    public static final String STYLE_CLASS_BUTTON = "button";
    public static final String STYLE_CLASS_SPLIT_BUTTON = "split-button";
    private ObservableList<Color> customColors;
    private static final String DEFAULT_STYLE_CLASS = "color-picker";
    
    public final ObservableList<Color> getCustomColors() {
        return this.customColors;
    }
    
    public ColorPicker() {
        this(Color.WHITE);
    }
    
    public ColorPicker(final Color value) {
        this.customColors = FXCollections.observableArrayList();
        this.setValue(value);
        this.getStyleClass().add("color-picker");
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ColorPickerSkin(this);
    }
}
