// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ObjectPropertyBase;
import javafx.event.Event;
import javafx.beans.Observable;
import javafx.scene.control.skin.TableColumnHeader;
import javafx.scene.layout.Pane;
import javafx.scene.control.skin.NestedTableColumnHeader;
import javafx.scene.control.skin.TableHeaderRow;
import javafx.scene.control.skin.TreeTableViewSkin;
import javafx.scene.Node;
import java.util.Collections;
import javafx.css.CssMetaData;
import java.util.List;
import javafx.css.Styleable;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.collections.ObservableMap;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import java.util.Iterator;
import javafx.beans.value.WritableValue;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.ObservableList;
import javafx.collections.WeakListChangeListener;
import javafx.collections.ListChangeListener;
import javafx.event.EventHandler;
import javafx.util.Callback;
import javafx.event.EventType;
import javafx.event.EventTarget;

public class TreeTableColumn<S, T> extends TableColumnBase<TreeItem<S>, T> implements EventTarget
{
    private static final EventType<?> EDIT_ANY_EVENT;
    private static final EventType<?> EDIT_START_EVENT;
    private static final EventType<?> EDIT_CANCEL_EVENT;
    private static final EventType<?> EDIT_COMMIT_EVENT;
    public static final Callback<TreeTableColumn<?, ?>, TreeTableCell<?, ?>> DEFAULT_CELL_FACTORY;
    private EventHandler<CellEditEvent<S, T>> DEFAULT_EDIT_COMMIT_HANDLER;
    private ListChangeListener<TreeTableColumn<S, ?>> columnsListener;
    private WeakListChangeListener<TreeTableColumn<S, ?>> weakColumnsListener;
    private final ObservableList<TreeTableColumn<S, ?>> columns;
    private ReadOnlyObjectWrapper<TreeTableView<S>> treeTableView;
    private ObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>> cellValueFactory;
    private final ObjectProperty<Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>> cellFactory;
    private ObjectProperty<SortType> sortType;
    private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditStart;
    private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCommit;
    private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCancel;
    private static final String DEFAULT_STYLE_CLASS = "table-column";
    
    public static <S, T> EventType<CellEditEvent<S, T>> editAnyEvent() {
        return (EventType<CellEditEvent<S, T>>)TreeTableColumn.EDIT_ANY_EVENT;
    }
    
    public static <S, T> EventType<CellEditEvent<S, T>> editStartEvent() {
        return (EventType<CellEditEvent<S, T>>)TreeTableColumn.EDIT_START_EVENT;
    }
    
    public static <S, T> EventType<CellEditEvent<S, T>> editCancelEvent() {
        return (EventType<CellEditEvent<S, T>>)TreeTableColumn.EDIT_CANCEL_EVENT;
    }
    
    public static <S, T> EventType<CellEditEvent<S, T>> editCommitEvent() {
        return (EventType<CellEditEvent<S, T>>)TreeTableColumn.EDIT_COMMIT_EVENT;
    }
    
    public TreeTableColumn() {
        final WritableValue<T> writableValue;
        this.DEFAULT_EDIT_COMMIT_HANDLER = (cellEditEvent -> {
            this.getCellObservableValue(cellEditEvent.getRowValue());
            if (writableValue instanceof WritableValue) {
                writableValue.setValue(cellEditEvent.getNewValue());
            }
            return;
        });
        this.columnsListener = new ListChangeListener<TreeTableColumn<S, ?>>() {
            @Override
            public void onChanged(final Change<? extends TreeTableColumn<S, ?>> change) {
                while (change.next()) {
                    for (final TreeTableColumn<Object, Object> treeTableColumn : change.getRemoved()) {
                        if (TreeTableColumn.this.getColumns().contains(treeTableColumn)) {
                            continue;
                        }
                        treeTableColumn.setTreeTableView((TreeTableView<TreeItem<Object>>)null);
                        treeTableColumn.setParentColumn((TableColumnBase<TreeItem<Object>, ?>)null);
                    }
                    final Iterator<? extends TreeTableColumn<S, ?>> iterator2 = change.getAddedSubList().iterator();
                    while (iterator2.hasNext()) {
                        ((TreeTableColumn)iterator2.next()).setTreeTableView(TreeTableColumn.this.getTreeTableView());
                    }
                    TreeTableColumn.this.updateColumnWidths();
                }
            }
        };
        this.weakColumnsListener = new WeakListChangeListener<TreeTableColumn<S, ?>>(this.columnsListener);
        this.columns = FXCollections.observableArrayList();
        this.treeTableView = new ReadOnlyObjectWrapper<TreeTableView<S>>(this, "treeTableView");
        this.cellFactory = new SimpleObjectProperty<Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>>((Object)this, "cellFactory", (Callback)TreeTableColumn.DEFAULT_CELL_FACTORY) {
            @Override
            protected void invalidated() {
                final TreeTableView<S> treeTableView = TreeTableColumn.this.getTreeTableView();
                if (treeTableView == null) {
                    return;
                }
                final ObservableMap<Object, Object> properties = treeTableView.getProperties();
                if (properties.containsKey("recreateKey")) {
                    properties.remove("recreateKey");
                }
                properties.put("recreateKey", Boolean.TRUE);
            }
        };
        this.getStyleClass().add("table-column");
        this.setOnEditCommit(this.DEFAULT_EDIT_COMMIT_HANDLER);
        this.getColumns().addListener(this.weakColumnsListener);
        final Iterator<TreeTableColumn> iterator;
        this.treeTableViewProperty().addListener(p0 -> {
            this.getColumns().iterator();
            while (iterator.hasNext()) {
                iterator.next().setTreeTableView(this.getTreeTableView());
            }
        });
    }
    
    public TreeTableColumn(final String text) {
        this();
        this.setText(text);
    }
    
    public final ReadOnlyObjectProperty<TreeTableView<S>> treeTableViewProperty() {
        return this.treeTableView.getReadOnlyProperty();
    }
    
    final void setTreeTableView(final TreeTableView<S> treeTableView) {
        this.treeTableView.set(treeTableView);
    }
    
    public final TreeTableView<S> getTreeTableView() {
        return this.treeTableView.get();
    }
    
    public final void setCellValueFactory(final Callback<CellDataFeatures<S, T>, ObservableValue<T>> callback) {
        this.cellValueFactoryProperty().set(callback);
    }
    
    public final Callback<CellDataFeatures<S, T>, ObservableValue<T>> getCellValueFactory() {
        return (this.cellValueFactory == null) ? null : this.cellValueFactory.get();
    }
    
    public final ObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>> cellValueFactoryProperty() {
        if (this.cellValueFactory == null) {
            this.cellValueFactory = new SimpleObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>>(this, "cellValueFactory");
        }
        return this.cellValueFactory;
    }
    
    public final void setCellFactory(final Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> callback) {
        this.cellFactory.set(callback);
    }
    
    public final Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> getCellFactory() {
        return this.cellFactory.get();
    }
    
    public final ObjectProperty<Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>> cellFactoryProperty() {
        return this.cellFactory;
    }
    
    public final ObjectProperty<SortType> sortTypeProperty() {
        if (this.sortType == null) {
            this.sortType = new SimpleObjectProperty<SortType>(this, "sortType", SortType.ASCENDING);
        }
        return this.sortType;
    }
    
    public final void setSortType(final SortType sortType) {
        this.sortTypeProperty().set(sortType);
    }
    
    public final SortType getSortType() {
        return (this.sortType == null) ? SortType.ASCENDING : this.sortType.get();
    }
    
    public final void setOnEditStart(final EventHandler<CellEditEvent<S, T>> eventHandler) {
        this.onEditStartProperty().set(eventHandler);
    }
    
    public final EventHandler<CellEditEvent<S, T>> getOnEditStart() {
        return (this.onEditStart == null) ? null : this.onEditStart.get();
    }
    
    public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditStartProperty() {
        if (this.onEditStart == null) {
            this.onEditStart = new SimpleObjectProperty<EventHandler<CellEditEvent<S, T>>>(this, "onEditStart") {
                @Override
                protected void invalidated() {
                    TreeTableColumn.this.eventHandlerManager.setEventHandler(TreeTableColumn.editStartEvent(), ((ObjectPropertyBase<EventHandler<? super CellEditEvent<Object, Object>>>)this).get());
                }
            };
        }
        return this.onEditStart;
    }
    
    public final void setOnEditCommit(final EventHandler<CellEditEvent<S, T>> eventHandler) {
        this.onEditCommitProperty().set(eventHandler);
    }
    
    public final EventHandler<CellEditEvent<S, T>> getOnEditCommit() {
        return (this.onEditCommit == null) ? null : this.onEditCommit.get();
    }
    
    public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCommitProperty() {
        if (this.onEditCommit == null) {
            this.onEditCommit = new SimpleObjectProperty<EventHandler<CellEditEvent<S, T>>>(this, "onEditCommit") {
                @Override
                protected void invalidated() {
                    TreeTableColumn.this.eventHandlerManager.setEventHandler(TreeTableColumn.editCommitEvent(), ((ObjectPropertyBase<EventHandler<? super CellEditEvent<Object, Object>>>)this).get());
                }
            };
        }
        return this.onEditCommit;
    }
    
    public final void setOnEditCancel(final EventHandler<CellEditEvent<S, T>> eventHandler) {
        this.onEditCancelProperty().set(eventHandler);
    }
    
    public final EventHandler<CellEditEvent<S, T>> getOnEditCancel() {
        return (this.onEditCancel == null) ? null : this.onEditCancel.get();
    }
    
    public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCancelProperty() {
        if (this.onEditCancel == null) {
            this.onEditCancel = new SimpleObjectProperty<EventHandler<CellEditEvent<S, T>>>(this, "onEditCancel") {
                @Override
                protected void invalidated() {
                    TreeTableColumn.this.eventHandlerManager.setEventHandler(TreeTableColumn.editCancelEvent(), ((ObjectPropertyBase<EventHandler<? super CellEditEvent<Object, Object>>>)this).get());
                }
            };
        }
        return this.onEditCancel;
    }
    
    @Override
    public final ObservableList<TreeTableColumn<S, ?>> getColumns() {
        return this.columns;
    }
    
    @Override
    public final ObservableValue<T> getCellObservableValue(final int n) {
        if (n < 0) {
            return null;
        }
        final TreeTableView<S> treeTableView = this.getTreeTableView();
        if (treeTableView == null || n >= treeTableView.getExpandedItemCount()) {
            return null;
        }
        return this.getCellObservableValue(treeTableView.getTreeItem(n));
    }
    
    @Override
    public final ObservableValue<T> getCellObservableValue(final TreeItem<S> treeItem) {
        final Callback<CellDataFeatures<S, T>, ObservableValue<T>> cellValueFactory = this.getCellValueFactory();
        if (cellValueFactory == null) {
            return null;
        }
        final TreeTableView<S> treeTableView = (TreeTableView<S>)this.getTreeTableView();
        if (treeTableView == null) {
            return null;
        }
        return cellValueFactory.call(new CellDataFeatures<S, T>((TreeTableView<Object>)treeTableView, (TreeTableColumn<Object, Object>)this, (TreeItem<Object>)treeItem));
    }
    
    @Override
    public String getTypeSelector() {
        return "TreeTableColumn";
    }
    
    @Override
    public Styleable getStyleableParent() {
        return this.getTreeTableView();
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return Collections.emptyList();
    }
    
    @Override
    public Node getStyleableNode() {
        if (!(this.getTreeTableView().getSkin() instanceof TreeTableViewSkin)) {
            return null;
        }
        final TreeTableViewSkin treeTableViewSkin = (TreeTableViewSkin)this.getTreeTableView().getSkin();
        Pane pane = null;
        for (final Node node : treeTableViewSkin.getChildren()) {
            if (node instanceof TableHeaderRow) {
                pane = (TableHeaderRow)node;
            }
        }
        TableColumnHeader tableColumnHeader = null;
        for (final Node node2 : pane.getChildren()) {
            if (node2 instanceof NestedTableColumnHeader) {
                tableColumnHeader = (NestedTableColumnHeader)node2;
            }
        }
        return this.scan(tableColumnHeader);
    }
    
    private TableColumnHeader scan(final TableColumnHeader tableColumnHeader) {
        if (this.equals(tableColumnHeader.getTableColumn())) {
            return tableColumnHeader;
        }
        if (tableColumnHeader instanceof NestedTableColumnHeader) {
            final NestedTableColumnHeader nestedTableColumnHeader = (NestedTableColumnHeader)tableColumnHeader;
            for (int i = 0; i < nestedTableColumnHeader.getColumnHeaders().size(); ++i) {
                final TableColumnHeader scan = this.scan(nestedTableColumnHeader.getColumnHeaders().get(i));
                if (scan != null) {
                    return scan;
                }
            }
        }
        return null;
    }
    
    static {
        EDIT_ANY_EVENT = new EventType<Object>(Event.ANY, "TREE_TABLE_COLUMN_EDIT");
        EDIT_START_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_START");
        EDIT_CANCEL_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_CANCEL");
        EDIT_COMMIT_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_COMMIT");
        DEFAULT_CELL_FACTORY = new Callback<TreeTableColumn<?, ?>, TreeTableCell<?, ?>>() {
            @Override
            public TreeTableCell<?, ?> call(final TreeTableColumn<?, ?> treeTableColumn) {
                return (TreeTableCell<?, ?>)new TreeTableCell() {
                    @Override
                    protected void updateItem(final Object o, final boolean b) {
                        if (o == this.getItem()) {
                            return;
                        }
                        super.updateItem(o, b);
                        if (o == null) {
                            super.setText(null);
                            super.setGraphic(null);
                        }
                        else if (o instanceof Node) {
                            super.setText(null);
                            super.setGraphic((Node)o);
                        }
                        else {
                            super.setText(o.toString());
                            super.setGraphic(null);
                        }
                    }
                };
            }
        };
    }
    
    public static class CellDataFeatures<S, T>
    {
        private final TreeTableView<S> treeTableView;
        private final TreeTableColumn<S, T> tableColumn;
        private final TreeItem<S> value;
        
        public CellDataFeatures(final TreeTableView<S> treeTableView, final TreeTableColumn<S, T> tableColumn, final TreeItem<S> value) {
            this.treeTableView = treeTableView;
            this.tableColumn = tableColumn;
            this.value = value;
        }
        
        public TreeItem<S> getValue() {
            return this.value;
        }
        
        public TreeTableColumn<S, T> getTreeTableColumn() {
            return this.tableColumn;
        }
        
        public TreeTableView<S> getTreeTableView() {
            return this.treeTableView;
        }
    }
    
    public static class CellEditEvent<S, T> extends Event
    {
        private static final long serialVersionUID = -609964441682677579L;
        public static final EventType<?> ANY;
        private final T newValue;
        private final transient TreeTablePosition<S, T> pos;
        
        public CellEditEvent(final TreeTableView<S> treeTableView, final TreeTablePosition<S, T> pos, final EventType<CellEditEvent<S, T>> eventType, final T newValue) {
            super(treeTableView, Event.NULL_SOURCE_TARGET, eventType);
            if (treeTableView == null) {
                throw new NullPointerException("TableView can not be null");
            }
            this.pos = pos;
            this.newValue = newValue;
        }
        
        public TreeTableView<S> getTreeTableView() {
            return this.pos.getTreeTableView();
        }
        
        public TreeTableColumn<S, T> getTableColumn() {
            return this.pos.getTableColumn();
        }
        
        public TreeTablePosition<S, T> getTreeTablePosition() {
            return this.pos;
        }
        
        public T getNewValue() {
            return this.newValue;
        }
        
        public T getOldValue() {
            final TreeItem<S> rowValue = this.getRowValue();
            if (rowValue == null || this.pos.getTableColumn() == null) {
                return null;
            }
            return (T)this.pos.getTableColumn().getCellData(rowValue);
        }
        
        public TreeItem<S> getRowValue() {
            final TreeTableView<S> treeTableView = this.getTreeTableView();
            final int row = this.pos.getRow();
            if (row < 0 || row >= treeTableView.getExpandedItemCount()) {
                return null;
            }
            return treeTableView.getTreeItem(row);
        }
        
        static {
            ANY = TreeTableColumn.EDIT_ANY_EVENT;
        }
    }
    
    public enum SortType
    {
        ASCENDING, 
        DESCENDING;
    }
}
