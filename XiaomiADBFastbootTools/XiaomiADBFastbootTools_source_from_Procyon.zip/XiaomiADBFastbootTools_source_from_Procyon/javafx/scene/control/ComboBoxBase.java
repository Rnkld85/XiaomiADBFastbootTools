// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.collections.MapChangeListener;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import javafx.event.EventTarget;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.beans.property.StringProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.event.Event;
import javafx.event.EventType;

public abstract class ComboBoxBase<T> extends Control
{
    public static final EventType<Event> ON_SHOWING;
    public static final EventType<Event> ON_SHOWN;
    public static final EventType<Event> ON_HIDING;
    public static final EventType<Event> ON_HIDDEN;
    private ObjectProperty<T> value;
    private BooleanProperty editable;
    private ReadOnlyBooleanWrapper showing;
    private StringProperty promptText;
    private BooleanProperty armed;
    private ObjectProperty<EventHandler<ActionEvent>> onAction;
    private ObjectProperty<EventHandler<Event>> onShowing;
    private ObjectProperty<EventHandler<Event>> onShown;
    private ObjectProperty<EventHandler<Event>> onHiding;
    private ObjectProperty<EventHandler<Event>> onHidden;
    private static final String DEFAULT_STYLE_CLASS = "combo-box-base";
    private static final PseudoClass PSEUDO_CLASS_EDITABLE;
    private static final PseudoClass PSEUDO_CLASS_SHOWING;
    private static final PseudoClass PSEUDO_CLASS_ARMED;
    
    public ComboBoxBase() {
        this.value = new SimpleObjectProperty<T>(this, "value");
        this.editable = new SimpleBooleanProperty((Object)this, "editable", false) {
            @Override
            protected void invalidated() {
                ComboBoxBase.this.pseudoClassStateChanged(ComboBoxBase.PSEUDO_CLASS_EDITABLE, this.get());
            }
        };
        this.promptText = new SimpleStringProperty((Object)this, "promptText", (String)null) {
            @Override
            protected void invalidated() {
                final String value = this.get();
                if (value != null && value.contains("\n")) {
                    this.set(value.replace("\n", ""));
                }
            }
        };
        this.armed = new SimpleBooleanProperty((Object)this, "armed", false) {
            @Override
            protected void invalidated() {
                ComboBoxBase.this.pseudoClassStateChanged(ComboBoxBase.PSEUDO_CLASS_ARMED, this.get());
            }
        };
        this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ActionEvent.ACTION, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ComboBoxBase.this;
            }
            
            @Override
            public String getName() {
                return "onAction";
            }
        };
        this.onShowing = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ComboBoxBase.ON_SHOWING, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ComboBoxBase.this;
            }
            
            @Override
            public String getName() {
                return "onShowing";
            }
        };
        this.onShown = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ComboBoxBase.ON_SHOWN, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ComboBoxBase.this;
            }
            
            @Override
            public String getName() {
                return "onShown";
            }
        };
        this.onHiding = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ComboBoxBase.ON_HIDING, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ComboBoxBase.this;
            }
            
            @Override
            public String getName() {
                return "onHiding";
            }
        };
        this.onHidden = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ComboBoxBase.ON_HIDDEN, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ComboBoxBase.this;
            }
            
            @Override
            public String getName() {
                return "onHidden";
            }
        };
        this.getStyleClass().add("combo-box-base");
        this.getProperties().addListener(change -> {
            if (change.wasAdded() && change.getKey() == "FOCUSED") {
                this.setFocused(change.getValueAdded());
                this.getProperties().remove("FOCUSED");
            }
        });
    }
    
    public ObjectProperty<T> valueProperty() {
        return this.value;
    }
    
    public final void setValue(final T t) {
        this.valueProperty().set(t);
    }
    
    public final T getValue() {
        return this.valueProperty().get();
    }
    
    public BooleanProperty editableProperty() {
        return this.editable;
    }
    
    public final void setEditable(final boolean b) {
        this.editableProperty().set(b);
    }
    
    public final boolean isEditable() {
        return this.editableProperty().get();
    }
    
    public ReadOnlyBooleanProperty showingProperty() {
        return this.showingPropertyImpl().getReadOnlyProperty();
    }
    
    public final boolean isShowing() {
        return this.showingPropertyImpl().get();
    }
    
    private void setShowing(final boolean b) {
        Event.fireEvent(this, b ? new Event(ComboBoxBase.ON_SHOWING) : new Event(ComboBoxBase.ON_HIDING));
        this.showingPropertyImpl().set(b);
        Event.fireEvent(this, b ? new Event(ComboBoxBase.ON_SHOWN) : new Event(ComboBoxBase.ON_HIDDEN));
    }
    
    private ReadOnlyBooleanWrapper showingPropertyImpl() {
        if (this.showing == null) {
            this.showing = new ReadOnlyBooleanWrapper(false) {
                @Override
                protected void invalidated() {
                    ComboBoxBase.this.pseudoClassStateChanged(ComboBoxBase.PSEUDO_CLASS_SHOWING, this.get());
                    ComboBoxBase.this.notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED);
                }
                
                @Override
                public Object getBean() {
                    return ComboBoxBase.this;
                }
                
                @Override
                public String getName() {
                    return "showing";
                }
            };
        }
        return this.showing;
    }
    
    public final StringProperty promptTextProperty() {
        return this.promptText;
    }
    
    public final String getPromptText() {
        return this.promptText.get();
    }
    
    public final void setPromptText(final String s) {
        this.promptText.set(s);
    }
    
    public BooleanProperty armedProperty() {
        return this.armed;
    }
    
    private final void setArmed(final boolean b) {
        this.armedProperty().set(b);
    }
    
    public final boolean isArmed() {
        return this.armedProperty().get();
    }
    
    public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() {
        return this.onAction;
    }
    
    public final void setOnAction(final EventHandler<ActionEvent> eventHandler) {
        this.onActionProperty().set(eventHandler);
    }
    
    public final EventHandler<ActionEvent> getOnAction() {
        return this.onActionProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onShowingProperty() {
        return this.onShowing;
    }
    
    public final void setOnShowing(final EventHandler<Event> eventHandler) {
        this.onShowingProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnShowing() {
        return this.onShowingProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onShownProperty() {
        return this.onShown;
    }
    
    public final void setOnShown(final EventHandler<Event> eventHandler) {
        this.onShownProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnShown() {
        return this.onShownProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onHidingProperty() {
        return this.onHiding;
    }
    
    public final void setOnHiding(final EventHandler<Event> eventHandler) {
        this.onHidingProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnHiding() {
        return this.onHidingProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onHiddenProperty() {
        return this.onHidden;
    }
    
    public final void setOnHidden(final EventHandler<Event> eventHandler) {
        this.onHiddenProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnHidden() {
        return this.onHiddenProperty().get();
    }
    
    public void show() {
        if (!this.isDisabled()) {
            this.setShowing(true);
        }
    }
    
    public void hide() {
        if (this.isShowing()) {
            this.setShowing(false);
        }
    }
    
    public void arm() {
        if (!this.armedProperty().isBound()) {
            this.setArmed(true);
        }
    }
    
    public void disarm() {
        if (!this.armedProperty().isBound()) {
            this.setArmed(false);
        }
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case EXPANDED: {
                return this.isShowing();
            }
            case EDITABLE: {
                return this.isEditable();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case EXPAND: {
                this.show();
                break;
            }
            case COLLAPSE: {
                this.hide();
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, new Object[0]);
                break;
            }
        }
    }
    
    static {
        ON_SHOWING = new EventType<Event>(Event.ANY, "COMBO_BOX_BASE_ON_SHOWING");
        ON_SHOWN = new EventType<Event>(Event.ANY, "COMBO_BOX_BASE_ON_SHOWN");
        ON_HIDING = new EventType<Event>(Event.ANY, "COMBO_BOX_BASE_ON_HIDING");
        ON_HIDDEN = new EventType<Event>(Event.ANY, "COMBO_BOX_BASE_ON_HIDDEN");
        PSEUDO_CLASS_EDITABLE = PseudoClass.getPseudoClass("editable");
        PSEUDO_CLASS_SHOWING = PseudoClass.getPseudoClass("showing");
        PSEUDO_CLASS_ARMED = PseudoClass.getPseudoClass("armed");
    }
}
