// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.PaginationSkin;
import javafx.css.CssMetaData;
import javafx.css.StyleableIntegerProperty;
import javafx.scene.AccessibleRole;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.Node;
import javafx.util.Callback;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.DefaultProperty;

@DefaultProperty("pages")
public class Pagination extends Control
{
    private static final int DEFAULT_MAX_PAGE_INDICATOR_COUNT = 10;
    public static final String STYLE_CLASS_BULLET = "bullet";
    public static final int INDETERMINATE = Integer.MAX_VALUE;
    private int oldMaxPageIndicatorCount;
    private IntegerProperty maxPageIndicatorCount;
    private int oldPageCount;
    private IntegerProperty pageCount;
    private final IntegerProperty currentPageIndex;
    private ObjectProperty<Callback<Integer, Node>> pageFactory;
    private static final String DEFAULT_STYLE_CLASS = "pagination";
    
    public Pagination(final int pageCount, final int currentPageIndex) {
        this.oldMaxPageIndicatorCount = 10;
        this.oldPageCount = Integer.MAX_VALUE;
        this.pageCount = new SimpleIntegerProperty((Object)this, "pageCount", Integer.MAX_VALUE) {
            @Override
            protected void invalidated() {
                if (!Pagination.this.pageCount.isBound()) {
                    if (Pagination.this.getPageCount() < 1) {
                        Pagination.this.setPageCount(Pagination.this.oldPageCount);
                    }
                    Pagination.this.oldPageCount = Pagination.this.getPageCount();
                }
            }
        };
        this.currentPageIndex = new SimpleIntegerProperty((Object)this, "currentPageIndex", 0) {
            @Override
            protected void invalidated() {
                if (!Pagination.this.currentPageIndex.isBound()) {
                    if (Pagination.this.getCurrentPageIndex() < 0) {
                        Pagination.this.setCurrentPageIndex(0);
                    }
                    else if (Pagination.this.getCurrentPageIndex() > Pagination.this.getPageCount() - 1) {
                        Pagination.this.setCurrentPageIndex(Pagination.this.getPageCount() - 1);
                    }
                }
            }
            
            @Override
            public void bind(final ObservableValue<? extends Number> observableValue) {
                throw new UnsupportedOperationException("currentPageIndex supports only bidirectional binding");
            }
        };
        this.pageFactory = new SimpleObjectProperty<Callback<Integer, Node>>(this, "pageFactory");
        this.getStyleClass().setAll("pagination");
        this.setAccessibleRole(AccessibleRole.PAGINATION);
        this.setPageCount(pageCount);
        this.setCurrentPageIndex(currentPageIndex);
    }
    
    public Pagination(final int n) {
        this(n, 0);
    }
    
    public Pagination() {
        this(Integer.MAX_VALUE, 0);
    }
    
    public final void setMaxPageIndicatorCount(final int n) {
        this.maxPageIndicatorCountProperty().set(n);
    }
    
    public final int getMaxPageIndicatorCount() {
        return (this.maxPageIndicatorCount == null) ? 10 : this.maxPageIndicatorCount.get();
    }
    
    public final IntegerProperty maxPageIndicatorCountProperty() {
        if (this.maxPageIndicatorCount == null) {
            this.maxPageIndicatorCount = new StyleableIntegerProperty(10) {
                @Override
                protected void invalidated() {
                    if (!Pagination.this.maxPageIndicatorCount.isBound()) {
                        if (Pagination.this.getMaxPageIndicatorCount() < 1 || Pagination.this.getMaxPageIndicatorCount() > Pagination.this.getPageCount()) {
                            Pagination.this.setMaxPageIndicatorCount(Pagination.this.oldMaxPageIndicatorCount);
                        }
                        Pagination.this.oldMaxPageIndicatorCount = Pagination.this.getMaxPageIndicatorCount();
                    }
                }
                
                @Override
                public CssMetaData<Pagination, Number> getCssMetaData() {
                    return StyleableProperties.MAX_PAGE_INDICATOR_COUNT;
                }
                
                @Override
                public Object getBean() {
                    return Pagination.this;
                }
                
                @Override
                public String getName() {
                    return "maxPageIndicatorCount";
                }
            };
        }
        return this.maxPageIndicatorCount;
    }
    
    public final void setPageCount(final int n) {
        this.pageCount.set(n);
    }
    
    public final int getPageCount() {
        return this.pageCount.get();
    }
    
    public final IntegerProperty pageCountProperty() {
        return this.pageCount;
    }
    
    public final void setCurrentPageIndex(final int n) {
        this.currentPageIndex.set(n);
    }
    
    public final int getCurrentPageIndex() {
        return this.currentPageIndex.get();
    }
    
    public final IntegerProperty currentPageIndexProperty() {
        return this.currentPageIndex;
    }
    
    public final void setPageFactory(final Callback<Integer, Node> callback) {
        this.pageFactory.set(callback);
    }
    
    public final Callback<Integer, Node> getPageFactory() {
        return this.pageFactory.get();
    }
    
    public final ObjectProperty<Callback<Integer, Node>> pageFactoryProperty() {
        return this.pageFactory;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new PaginationSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Pagination, Number> MAX_PAGE_INDICATOR_COUNT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            MAX_PAGE_INDICATOR_COUNT = new CssMetaData<Pagination, Number>((StyleConverter)SizeConverter.getInstance(), (Number)10) {
                @Override
                public boolean isSettable(final Pagination pagination) {
                    return pagination.maxPageIndicatorCount == null || !pagination.maxPageIndicatorCount.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Pagination pagination) {
                    return (StyleableProperty<Number>)pagination.maxPageIndicatorCountProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.MAX_PAGE_INDICATOR_COUNT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
