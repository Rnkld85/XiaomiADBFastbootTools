// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;
import javafx.event.Event;

public class ScrollToEvent<T> extends Event
{
    public static final EventType<ScrollToEvent> ANY;
    private static final EventType<ScrollToEvent<Integer>> SCROLL_TO_TOP_INDEX;
    private static final EventType<?> SCROLL_TO_COLUMN;
    private static final long serialVersionUID = -8557345736849482516L;
    private final T scrollTarget;
    
    public static EventType<ScrollToEvent<Integer>> scrollToTopIndex() {
        return ScrollToEvent.SCROLL_TO_TOP_INDEX;
    }
    
    public static <T extends TableColumnBase<?, ?>> EventType<ScrollToEvent<T>> scrollToColumn() {
        return (EventType<ScrollToEvent<T>>)ScrollToEvent.SCROLL_TO_COLUMN;
    }
    
    public ScrollToEvent(@NamedArg("source") final Object o, @NamedArg("target") final EventTarget eventTarget, @NamedArg("type") final EventType<ScrollToEvent<T>> eventType, @NamedArg("scrollTarget") final T scrollTarget) {
        super(o, eventTarget, eventType);
        assert scrollTarget != null;
        this.scrollTarget = scrollTarget;
    }
    
    public T getScrollTarget() {
        return this.scrollTarget;
    }
    
    static {
        ANY = new EventType<ScrollToEvent>(Event.ANY, "SCROLL_TO");
        SCROLL_TO_TOP_INDEX = new EventType<ScrollToEvent<Integer>>(ScrollToEvent.ANY, "SCROLL_TO_TOP_INDEX");
        SCROLL_TO_COLUMN = new EventType<Object>(ScrollToEvent.ANY, "SCROLL_TO_COLUMN");
    }
}
