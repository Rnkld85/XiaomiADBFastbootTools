// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.DoubleProperty;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.SplitPaneSkin;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.collections.ListChangeListener;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.collections.FXCollections;
import javafx.css.PseudoClass;
import java.util.WeakHashMap;
import javafx.scene.Node;
import javafx.collections.ObservableList;
import javafx.geometry.Orientation;
import javafx.beans.property.ObjectProperty;
import javafx.beans.DefaultProperty;

@DefaultProperty("items")
public class SplitPane extends Control
{
    private static final String RESIZABLE_WITH_PARENT = "resizable-with-parent";
    private ObjectProperty<Orientation> orientation;
    private final ObservableList<Node> items;
    private final ObservableList<Divider> dividers;
    private final ObservableList<Divider> unmodifiableDividers;
    private final WeakHashMap<Integer, Double> dividerCache;
    private static final String DEFAULT_STYLE_CLASS = "split-pane";
    private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE;
    private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE;
    
    public static void setResizableWithParent(final Node node, final Boolean b) {
        if (b == null) {
            node.getProperties().remove("resizable-with-parent");
        }
        else {
            node.getProperties().put("resizable-with-parent", b);
        }
    }
    
    public static Boolean isResizableWithParent(final Node node) {
        if (node.hasProperties()) {
            final Boolean value = node.getProperties().get("resizable-with-parent");
            if (value != null) {
                return value;
            }
        }
        return true;
    }
    
    public SplitPane() {
        this((Node[])null);
    }
    
    public SplitPane(final Node... array) {
        this.items = FXCollections.observableArrayList();
        this.dividers = FXCollections.observableArrayList();
        this.unmodifiableDividers = FXCollections.unmodifiableObservableList(this.dividers);
        this.dividerCache = new WeakHashMap<Integer, Double>();
        this.getStyleClass().setAll("split-pane");
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
        this.getItems().addListener(new ListChangeListener<Node>() {
            @Override
            public void onChanged(final Change<? extends Node> change) {
                while (change.next()) {
                    int from = change.getFrom();
                    for (int i = 0; i < change.getRemovedSize(); ++i) {
                        if (from < SplitPane.this.dividers.size()) {
                            SplitPane.this.dividerCache.put(from, Double.MAX_VALUE);
                        }
                        else if (from == SplitPane.this.dividers.size() && !SplitPane.this.dividers.isEmpty()) {
                            if (change.wasReplaced()) {
                                SplitPane.this.dividerCache.put(from - 1, ((Divider)SplitPane.this.dividers.get(from - 1)).getPosition());
                            }
                            else {
                                SplitPane.this.dividerCache.put(from - 1, Double.MAX_VALUE);
                            }
                        }
                        ++from;
                    }
                    for (int j = 0; j < SplitPane.this.dividers.size(); ++j) {
                        if (SplitPane.this.dividerCache.get(j) == null) {
                            SplitPane.this.dividerCache.put(j, ((Divider)SplitPane.this.dividers.get(j)).getPosition());
                        }
                    }
                }
                SplitPane.this.dividers.clear();
                for (int k = 0; k < SplitPane.this.getItems().size() - 1; ++k) {
                    if (SplitPane.this.dividerCache.containsKey(k) && (double)SplitPane.this.dividerCache.get(k) != Double.MAX_VALUE) {
                        final Divider divider = new Divider();
                        divider.setPosition(SplitPane.this.dividerCache.get(k));
                        SplitPane.this.dividers.add(divider);
                    }
                    else {
                        SplitPane.this.dividers.add(new Divider());
                    }
                    SplitPane.this.dividerCache.remove(k);
                }
            }
        });
        if (array != null) {
            this.getItems().addAll(array);
        }
        this.pseudoClassStateChanged(SplitPane.HORIZONTAL_PSEUDOCLASS_STATE, true);
    }
    
    public final void setOrientation(final Orientation orientation) {
        this.orientationProperty().set(orientation);
    }
    
    public final Orientation getOrientation() {
        return (this.orientation == null) ? Orientation.HORIZONTAL : this.orientation.get();
    }
    
    public final ObjectProperty<Orientation> orientationProperty() {
        if (this.orientation == null) {
            this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL) {
                public void invalidated() {
                    final boolean b = this.get() == Orientation.VERTICAL;
                    SplitPane.this.pseudoClassStateChanged(SplitPane.VERTICAL_PSEUDOCLASS_STATE, b);
                    SplitPane.this.pseudoClassStateChanged(SplitPane.HORIZONTAL_PSEUDOCLASS_STATE, !b);
                }
                
                @Override
                public CssMetaData<SplitPane, Orientation> getCssMetaData() {
                    return StyleableProperties.ORIENTATION;
                }
                
                @Override
                public Object getBean() {
                    return SplitPane.this;
                }
                
                @Override
                public String getName() {
                    return "orientation";
                }
            };
        }
        return this.orientation;
    }
    
    public ObservableList<Node> getItems() {
        return this.items;
    }
    
    public ObservableList<Divider> getDividers() {
        return this.unmodifiableDividers;
    }
    
    public void setDividerPosition(final int i, final double n) {
        if (this.getDividers().size() <= i) {
            this.dividerCache.put(i, n);
            return;
        }
        if (i >= 0) {
            this.getDividers().get(i).setPosition(n);
        }
    }
    
    public void setDividerPositions(final double... array) {
        if (this.dividers.isEmpty()) {
            for (int i = 0; i < array.length; ++i) {
                this.dividerCache.put(i, array[i]);
            }
            return;
        }
        for (int n = 0; n < array.length && n < this.dividers.size(); ++n) {
            ((Divider)this.dividers.get(n)).setPosition(array[n]);
        }
    }
    
    public double[] getDividerPositions() {
        final double[] array = new double[this.dividers.size()];
        for (int i = 0; i < this.dividers.size(); ++i) {
            array[i] = ((Divider)this.dividers.get(i)).getPosition();
        }
        return array;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new SplitPaneSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    static {
        VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
        HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<SplitPane, Orientation> ORIENTATION;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            ORIENTATION = new CssMetaData<SplitPane, Orientation>((StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL) {
                @Override
                public Orientation getInitialValue(final SplitPane splitPane) {
                    return splitPane.getOrientation();
                }
                
                @Override
                public boolean isSettable(final SplitPane splitPane) {
                    return splitPane.orientation == null || !splitPane.orientation.isBound();
                }
                
                @Override
                public StyleableProperty<Orientation> getStyleableProperty(final SplitPane splitPane) {
                    return (StyleableProperty<Orientation>)(StyleableProperty)splitPane.orientationProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.ORIENTATION);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    public static class Divider
    {
        private DoubleProperty position;
        
        public final void setPosition(final double n) {
            this.positionProperty().set(n);
        }
        
        public final double getPosition() {
            return (this.position == null) ? 0.5 : this.position.get();
        }
        
        public final DoubleProperty positionProperty() {
            if (this.position == null) {
                this.position = new SimpleDoubleProperty(this, "position", 0.5);
            }
            return this.position;
        }
    }
}
