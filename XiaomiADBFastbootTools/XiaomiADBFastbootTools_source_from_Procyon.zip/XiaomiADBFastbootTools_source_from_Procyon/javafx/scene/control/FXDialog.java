// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.stage.StageStyle;
import javafx.scene.Node;
import javafx.beans.property.StringProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.stage.Modality;
import javafx.stage.Window;
import java.util.Iterator;
import javafx.collections.ObservableList;

abstract class FXDialog
{
    protected Object owner;
    
    protected FXDialog() {
    }
    
    public boolean requestPermissionToClose(final Dialog<?> dialog) {
        boolean b = true;
        final DialogPane dialogPane = dialog.getDialogPane();
        if (dialogPane != null) {
            final ObservableList<ButtonType> buttonTypes = dialogPane.getButtonTypes();
            if (buttonTypes.size() == 1) {
                b = false;
            }
            else {
                for (final ButtonType buttonType : buttonTypes) {
                    if (buttonType == null) {
                        continue;
                    }
                    final ButtonBar.ButtonData buttonData = buttonType.getButtonData();
                    if (buttonData == null) {
                        continue;
                    }
                    if (buttonData == ButtonBar.ButtonData.CANCEL_CLOSE || buttonData.isCancelButton()) {
                        b = false;
                        break;
                    }
                }
            }
        }
        return !b;
    }
    
    public abstract void show();
    
    public abstract void showAndWait();
    
    public abstract void close();
    
    public abstract void initOwner(final Window p0);
    
    public abstract Window getOwner();
    
    public abstract void initModality(final Modality p0);
    
    public abstract Modality getModality();
    
    public abstract ReadOnlyBooleanProperty showingProperty();
    
    public abstract Window getWindow();
    
    public abstract void sizeToScene();
    
    public abstract double getX();
    
    public abstract void setX(final double p0);
    
    public abstract ReadOnlyDoubleProperty xProperty();
    
    public abstract double getY();
    
    public abstract void setY(final double p0);
    
    public abstract ReadOnlyDoubleProperty yProperty();
    
    abstract BooleanProperty resizableProperty();
    
    abstract ReadOnlyBooleanProperty focusedProperty();
    
    abstract StringProperty titleProperty();
    
    public abstract void setDialogPane(final DialogPane p0);
    
    public abstract Node getRoot();
    
    abstract ReadOnlyDoubleProperty widthProperty();
    
    abstract void setWidth(final double p0);
    
    abstract ReadOnlyDoubleProperty heightProperty();
    
    abstract void setHeight(final double p0);
    
    abstract void initStyle(final StageStyle p0);
    
    abstract StageStyle getStyle();
    
    abstract double getSceneHeight();
}
