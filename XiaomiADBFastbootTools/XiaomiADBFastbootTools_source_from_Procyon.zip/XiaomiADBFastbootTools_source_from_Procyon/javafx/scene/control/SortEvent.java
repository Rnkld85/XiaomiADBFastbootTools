// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.event.EventTarget;
import javafx.beans.NamedArg;
import javafx.event.EventType;
import javafx.event.Event;

public class SortEvent<C> extends Event
{
    public static final EventType<SortEvent> ANY;
    private static final EventType<?> SORT_EVENT;
    
    public static <C> EventType<SortEvent<C>> sortEvent() {
        return (EventType<SortEvent<C>>)SortEvent.SORT_EVENT;
    }
    
    public SortEvent(@NamedArg("source") final C c, @NamedArg("target") final EventTarget eventTarget) {
        super(c, eventTarget, sortEvent());
    }
    
    @Override
    public C getSource() {
        return (C)super.getSource();
    }
    
    static {
        ANY = new EventType<SortEvent>(Event.ANY, "SORT");
        SORT_EVENT = new EventType<Object>(SortEvent.ANY, "SORT_EVENT");
    }
}
