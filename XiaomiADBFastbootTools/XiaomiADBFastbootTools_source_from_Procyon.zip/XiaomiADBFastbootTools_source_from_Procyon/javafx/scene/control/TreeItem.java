// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.List;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;
import javafx.event.EventDispatcher;
import javafx.event.EventDispatchChain;
import javafx.collections.FXCollections;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.BooleanPropertyBase;
import javafx.beans.property.ObjectPropertyBase;
import javafx.event.Event;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.BooleanProperty;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ListChangeListener;
import java.util.Comparator;
import com.sun.javafx.event.EventHandlerManager;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.event.EventTarget;

public class TreeItem<T> implements EventTarget
{
    private static final EventType<?> TREE_NOTIFICATION_EVENT;
    private static final EventType<?> EXPANDED_ITEM_COUNT_CHANGE_EVENT;
    private static final EventType<?> BRANCH_EXPANDED_EVENT;
    private static final EventType<?> BRANCH_COLLAPSED_EVENT;
    private static final EventType<?> CHILDREN_MODIFICATION_EVENT;
    private static final EventType<?> VALUE_CHANGED_EVENT;
    private static final EventType<?> GRAPHIC_CHANGED_EVENT;
    private final EventHandler<TreeModificationEvent<Object>> itemListener;
    private boolean ignoreSortUpdate;
    private boolean expandedDescendentCountDirty;
    ObservableList<TreeItem<T>> children;
    private final EventHandlerManager eventHandlerManager;
    private int expandedDescendentCount;
    int previousExpandedDescendentCount;
    Comparator<TreeItem<T>> lastComparator;
    TreeSortMode lastSortMode;
    private int parentLinkCount;
    private ListChangeListener<TreeItem<T>> childrenListener;
    private ObjectProperty<T> value;
    private ObjectProperty<Node> graphic;
    private BooleanProperty expanded;
    private ReadOnlyBooleanWrapper leaf;
    private ReadOnlyObjectWrapper<TreeItem<T>> parent;
    
    public static <T> EventType<TreeModificationEvent<T>> treeNotificationEvent() {
        return (EventType<TreeModificationEvent<T>>)TreeItem.TREE_NOTIFICATION_EVENT;
    }
    
    public static <T> EventType<TreeModificationEvent<T>> expandedItemCountChangeEvent() {
        return (EventType<TreeModificationEvent<T>>)TreeItem.EXPANDED_ITEM_COUNT_CHANGE_EVENT;
    }
    
    public static <T> EventType<TreeModificationEvent<T>> branchExpandedEvent() {
        return (EventType<TreeModificationEvent<T>>)TreeItem.BRANCH_EXPANDED_EVENT;
    }
    
    public static <T> EventType<TreeModificationEvent<T>> branchCollapsedEvent() {
        return (EventType<TreeModificationEvent<T>>)TreeItem.BRANCH_COLLAPSED_EVENT;
    }
    
    public static <T> EventType<TreeModificationEvent<T>> childrenModificationEvent() {
        return (EventType<TreeModificationEvent<T>>)TreeItem.CHILDREN_MODIFICATION_EVENT;
    }
    
    public static <T> EventType<TreeModificationEvent<T>> valueChangedEvent() {
        return (EventType<TreeModificationEvent<T>>)TreeItem.VALUE_CHANGED_EVENT;
    }
    
    public static <T> EventType<TreeModificationEvent<T>> graphicChangedEvent() {
        return (EventType<TreeModificationEvent<T>>)TreeItem.GRAPHIC_CHANGED_EVENT;
    }
    
    public TreeItem() {
        this(null);
    }
    
    public TreeItem(final T t) {
        this(t, null);
    }
    
    public TreeItem(final T value, final Node graphic) {
        this.itemListener = new EventHandler<TreeModificationEvent<Object>>() {
            @Override
            public void handle(final TreeModificationEvent<Object> treeModificationEvent) {
                TreeItem.this.expandedDescendentCountDirty = true;
            }
        };
        this.ignoreSortUpdate = false;
        this.expandedDescendentCountDirty = true;
        this.eventHandlerManager = new EventHandlerManager(this);
        this.expandedDescendentCount = 1;
        this.previousExpandedDescendentCount = 1;
        this.lastComparator = null;
        this.lastSortMode = null;
        this.parentLinkCount = 0;
        this.childrenListener = (change -> {
            this.expandedDescendentCountDirty = true;
            this.updateChildren(change);
            return;
        });
        this.parent = new ReadOnlyObjectWrapper<TreeItem<T>>(this, "parent");
        this.setValue(value);
        this.setGraphic(graphic);
        this.addEventHandler(expandedItemCountChangeEvent(), this.itemListener);
    }
    
    public final void setValue(final T value) {
        this.valueProperty().setValue(value);
    }
    
    public final T getValue() {
        return (this.value == null) ? null : this.value.getValue();
    }
    
    public final ObjectProperty<T> valueProperty() {
        if (this.value == null) {
            this.value = new ObjectPropertyBase<T>() {
                @Override
                protected void invalidated() {
                    TreeItem.this.fireEvent(new TreeModificationEvent(TreeItem.VALUE_CHANGED_EVENT, TreeItem.this, (T)this.get()));
                }
                
                @Override
                public Object getBean() {
                    return TreeItem.this;
                }
                
                @Override
                public String getName() {
                    return "value";
                }
            };
        }
        return this.value;
    }
    
    public final void setGraphic(final Node value) {
        this.graphicProperty().setValue(value);
    }
    
    public final Node getGraphic() {
        return (this.graphic == null) ? null : this.graphic.getValue();
    }
    
    public final ObjectProperty<Node> graphicProperty() {
        if (this.graphic == null) {
            this.graphic = new ObjectPropertyBase<Node>() {
                @Override
                protected void invalidated() {
                    TreeItem.this.fireEvent(new TreeModificationEvent(TreeItem.GRAPHIC_CHANGED_EVENT, TreeItem.this));
                }
                
                @Override
                public Object getBean() {
                    return TreeItem.this;
                }
                
                @Override
                public String getName() {
                    return "graphic";
                }
            };
        }
        return this.graphic;
    }
    
    public final void setExpanded(final boolean b) {
        if (!b && this.expanded == null) {
            return;
        }
        this.expandedProperty().setValue(b);
    }
    
    public final boolean isExpanded() {
        return this.expanded != null && this.expanded.getValue();
    }
    
    public final BooleanProperty expandedProperty() {
        if (this.expanded == null) {
            this.expanded = new BooleanPropertyBase() {
                @Override
                protected void invalidated() {
                    if (TreeItem.this.isLeaf()) {
                        return;
                    }
                    TreeItem.this.fireEvent(new TreeModificationEvent(TreeItem.this.isExpanded() ? TreeItem.BRANCH_EXPANDED_EVENT : TreeItem.BRANCH_COLLAPSED_EVENT, TreeItem.this, TreeItem.this.isExpanded()));
                }
                
                @Override
                public Object getBean() {
                    return TreeItem.this;
                }
                
                @Override
                public String getName() {
                    return "expanded";
                }
            };
        }
        return this.expanded;
    }
    
    private void setLeaf(final boolean b) {
        if (b && this.leaf == null) {
            return;
        }
        if (this.leaf == null) {
            this.leaf = new ReadOnlyBooleanWrapper(this, "leaf", true);
        }
        this.leaf.setValue(b);
    }
    
    public boolean isLeaf() {
        return this.leaf == null || this.leaf.getValue();
    }
    
    public final ReadOnlyBooleanProperty leafProperty() {
        if (this.leaf == null) {
            this.leaf = new ReadOnlyBooleanWrapper(this, "leaf", true);
        }
        return this.leaf.getReadOnlyProperty();
    }
    
    private void setParent(final TreeItem<T> value) {
        this.parent.setValue(value);
    }
    
    public final TreeItem<T> getParent() {
        return (this.parent == null) ? null : this.parent.getValue();
    }
    
    public final ReadOnlyObjectProperty<TreeItem<T>> parentProperty() {
        return this.parent.getReadOnlyProperty();
    }
    
    public ObservableList<TreeItem<T>> getChildren() {
        if (this.children == null) {
            (this.children = FXCollections.observableArrayList()).addListener(this.childrenListener);
        }
        if (this.children.isEmpty()) {
            return this.children;
        }
        if (!this.ignoreSortUpdate) {
            this.checkSortState();
        }
        return this.children;
    }
    
    public TreeItem<T> previousSibling() {
        return this.previousSibling(this);
    }
    
    public TreeItem<T> previousSibling(final TreeItem<T> treeItem) {
        if (this.getParent() == null || treeItem == null) {
            return null;
        }
        final ObservableList<TreeItem<T>> children = this.getParent().getChildren();
        for (int size = children.size(), i = 0; i < size; ++i) {
            if (treeItem.equals(children.get(i))) {
                final int n = i - 1;
                return (n < 0) ? null : ((TreeItem<T>)children.get(n));
            }
        }
        return null;
    }
    
    public TreeItem<T> nextSibling() {
        return this.nextSibling(this);
    }
    
    public TreeItem<T> nextSibling(final TreeItem<T> treeItem) {
        if (this.getParent() == null || treeItem == null) {
            return null;
        }
        final ObservableList<TreeItem<T>> children = this.getParent().getChildren();
        for (int size = children.size(), i = 0; i < size; ++i) {
            if (treeItem.equals(children.get(i))) {
                final int n = i + 1;
                return (n >= size) ? null : ((TreeItem<T>)children.get(n));
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;)Ljava/lang/String;, this.getValue());
    }
    
    private void fireEvent(final TreeModificationEvent<T> treeModificationEvent) {
        Event.fireEvent(this, treeModificationEvent);
    }
    
    @Override
    public EventDispatchChain buildEventDispatchChain(final EventDispatchChain eventDispatchChain) {
        if (this.getParent() != null) {
            this.getParent().buildEventDispatchChain(eventDispatchChain);
        }
        return eventDispatchChain.append(this.eventHandlerManager);
    }
    
    public <E extends Event> void addEventHandler(final EventType<E> eventType, final EventHandler<E> eventHandler) {
        this.eventHandlerManager.addEventHandler(eventType, eventHandler);
    }
    
    public <E extends Event> void removeEventHandler(final EventType<E> eventType, final EventHandler<E> eventHandler) {
        this.eventHandlerManager.removeEventHandler(eventType, eventHandler);
    }
    
    void sort() {
        this.sort(this.children, this.lastComparator, this.lastSortMode);
    }
    
    private void sort(final ObservableList<TreeItem<T>> list, final Comparator<TreeItem<T>> comparator, final TreeSortMode treeSortMode) {
        if (comparator == null) {
            return;
        }
        this.runSort(list, comparator, treeSortMode);
        if (this.getParent() == null) {
            final TreeModificationEvent<T> treeModificationEvent = new TreeModificationEvent<T>(childrenModificationEvent(), this);
            ((TreeModificationEvent<Object>)treeModificationEvent).wasPermutated = true;
            this.fireEvent(treeModificationEvent);
        }
    }
    
    private void checkSortState() {
        final TreeItem<T> root = this.getRoot();
        final TreeSortMode lastSortMode = root.lastSortMode;
        final Comparator<TreeItem<T>> lastComparator = root.lastComparator;
        if (lastComparator != null && lastComparator != this.lastComparator) {
            this.lastComparator = lastComparator;
            this.runSort(this.children, lastComparator, lastSortMode);
        }
    }
    
    private void runSort(final ObservableList<TreeItem<T>> list, final Comparator<TreeItem<T>> comparator, final TreeSortMode treeSortMode) {
        if (treeSortMode == TreeSortMode.ALL_DESCENDANTS) {
            this.doSort(list, comparator);
        }
        else if (treeSortMode == TreeSortMode.ONLY_FIRST_LEVEL && this.getParent() == null) {
            this.doSort(list, comparator);
        }
    }
    
    private TreeItem<T> getRoot() {
        TreeItem<T> parent = this.getParent();
        if (parent == null) {
            return this;
        }
        while (true) {
            final TreeItem parent2 = parent.getParent();
            if (parent2 == null) {
                break;
            }
            parent = (TreeItem<T>)parent2;
        }
        return parent;
    }
    
    private void doSort(final ObservableList<TreeItem<T>> list, final Comparator<TreeItem<T>> comparator) {
        if (!this.isLeaf() && this.isExpanded()) {
            FXCollections.sort((ObservableList<Object>)list, (Comparator<? super Object>)comparator);
        }
    }
    
    int getExpandedDescendentCount(final boolean b) {
        if (b || this.expandedDescendentCountDirty) {
            this.updateExpandedDescendentCount(b);
            this.expandedDescendentCountDirty = false;
        }
        return this.expandedDescendentCount;
    }
    
    private void updateExpandedDescendentCount(final boolean b) {
        this.previousExpandedDescendentCount = this.expandedDescendentCount;
        this.expandedDescendentCount = 1;
        this.ignoreSortUpdate = true;
        if (!this.isLeaf() && this.isExpanded()) {
            for (final TreeItem treeItem : this.getChildren()) {
                if (treeItem == null) {
                    continue;
                }
                this.expandedDescendentCount += (treeItem.isExpanded() ? treeItem.getExpandedDescendentCount(b) : 1);
            }
        }
        this.ignoreSortUpdate = false;
    }
    
    private void updateChildren(final ListChangeListener.Change<? extends TreeItem<T>> change) {
        this.setLeaf(this.children.isEmpty());
        final ArrayList<Object> list = new ArrayList<Object>();
        final ArrayList<Object> list2 = new ArrayList<Object>();
        while (change.next()) {
            list.addAll(change.getAddedSubList());
            list2.addAll(change.getRemoved());
        }
        updateChildrenParent((List<? extends TreeItem<Object>>)list2, (TreeItem<Object>)null);
        updateChildrenParent((List<? extends TreeItem<Object>>)list, (TreeItem<Object>)this);
        change.reset();
        this.fireEvent(new TreeModificationEvent<T>((EventType)TreeItem.CHILDREN_MODIFICATION_EVENT, this, (List)list, (List)list2, (ListChangeListener.Change)change));
    }
    
    private static <T> void updateChildrenParent(final List<? extends TreeItem<T>> list, final TreeItem<T> treeItem) {
        if (list == null) {
            return;
        }
        for (final TreeItem<T> treeItem2 : list) {
            if (treeItem2 == null) {
                continue;
            }
            final TreeItem<T> parent = treeItem2.getParent();
            if (treeItem2.parentLinkCount == 0) {
                treeItem2.setParent(treeItem);
            }
            if (parent == null || !parent.equals(treeItem)) {
                continue;
            }
            if (treeItem == null) {
                final TreeItem<T> treeItem3 = treeItem2;
                --treeItem3.parentLinkCount;
            }
            else {
                final TreeItem<T> treeItem4 = treeItem2;
                ++treeItem4.parentLinkCount;
            }
        }
    }
    
    static {
        TREE_NOTIFICATION_EVENT = new EventType<Object>(Event.ANY, "TreeNotificationEvent");
        EXPANDED_ITEM_COUNT_CHANGE_EVENT = new EventType<Object>(treeNotificationEvent(), "ExpandedItemCountChangeEvent");
        BRANCH_EXPANDED_EVENT = new EventType<Object>(expandedItemCountChangeEvent(), "BranchExpandedEvent");
        BRANCH_COLLAPSED_EVENT = new EventType<Object>(expandedItemCountChangeEvent(), "BranchCollapsedEvent");
        CHILDREN_MODIFICATION_EVENT = new EventType<Object>(expandedItemCountChangeEvent(), "ChildrenModificationEvent");
        VALUE_CHANGED_EVENT = new EventType<Object>(treeNotificationEvent(), "ValueChangedEvent");
        GRAPHIC_CHANGED_EVENT = new EventType<Object>(treeNotificationEvent(), "GraphicChangedEvent");
    }
    
    public static class TreeModificationEvent<T> extends Event
    {
        private static final long serialVersionUID = 4741889985221719579L;
        public static final EventType<?> ANY;
        private final transient TreeItem<T> treeItem;
        private final T newValue;
        private final List<? extends TreeItem<T>> added;
        private final List<? extends TreeItem<T>> removed;
        private final ListChangeListener.Change<? extends TreeItem<T>> change;
        private final boolean wasExpanded;
        private final boolean wasCollapsed;
        private boolean wasPermutated;
        
        public TreeModificationEvent(final EventType<? extends Event> eventType, final TreeItem<T> treeItem) {
            this(eventType, (TreeItem<Object>)treeItem, (Object)null);
        }
        
        public TreeModificationEvent(final EventType<? extends Event> eventType, final TreeItem<T> treeItem, final T newValue) {
            super(eventType);
            this.treeItem = treeItem;
            this.newValue = newValue;
            this.added = null;
            this.removed = null;
            this.change = null;
            this.wasExpanded = false;
            this.wasCollapsed = false;
        }
        
        public TreeModificationEvent(final EventType<? extends Event> eventType, final TreeItem<T> treeItem, final boolean wasExpanded) {
            super(eventType);
            this.treeItem = treeItem;
            this.newValue = null;
            this.added = null;
            this.removed = null;
            this.change = null;
            this.wasExpanded = wasExpanded;
            this.wasCollapsed = !wasExpanded;
        }
        
        public TreeModificationEvent(final EventType<? extends Event> eventType, final TreeItem<T> treeItem, final List<? extends TreeItem<T>> list, final List<? extends TreeItem<T>> list2) {
            this(eventType, treeItem, list, list2, null);
        }
        
        private TreeModificationEvent(final EventType<? extends Event> eventType, final TreeItem<T> treeItem, final List<? extends TreeItem<T>> added, final List<? extends TreeItem<T>> removed, final ListChangeListener.Change<? extends TreeItem<T>> change) {
            super(eventType);
            this.treeItem = treeItem;
            this.newValue = null;
            this.added = added;
            this.removed = removed;
            this.change = change;
            this.wasExpanded = false;
            this.wasCollapsed = false;
            this.wasPermutated = (added != null && removed != null && added.size() == removed.size() && added.containsAll(removed));
        }
        
        @Override
        public TreeItem<T> getSource() {
            return this.treeItem;
        }
        
        public TreeItem<T> getTreeItem() {
            return this.treeItem;
        }
        
        public T getNewValue() {
            return this.newValue;
        }
        
        public List<? extends TreeItem<T>> getAddedChildren() {
            return (this.added == null) ? Collections.emptyList() : this.added;
        }
        
        public List<? extends TreeItem<T>> getRemovedChildren() {
            return (this.removed == null) ? Collections.emptyList() : this.removed;
        }
        
        public int getRemovedSize() {
            return this.getRemovedChildren().size();
        }
        
        public int getAddedSize() {
            return this.getAddedChildren().size();
        }
        
        public boolean wasExpanded() {
            return this.wasExpanded;
        }
        
        public boolean wasCollapsed() {
            return this.wasCollapsed;
        }
        
        public boolean wasAdded() {
            return this.getAddedSize() > 0;
        }
        
        public boolean wasRemoved() {
            return this.getRemovedSize() > 0;
        }
        
        public boolean wasPermutated() {
            return this.wasPermutated;
        }
        
        int getFrom() {
            return (this.change == null) ? -1 : this.change.getFrom();
        }
        
        int getTo() {
            return (this.change == null) ? -1 : this.change.getTo();
        }
        
        ListChangeListener.Change<? extends TreeItem<T>> getChange() {
            return this.change;
        }
        
        static {
            ANY = TreeItem.TREE_NOTIFICATION_EVENT;
        }
    }
}
