// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.collections.ObservableList;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.BooleanProperty;

public abstract class TableSelectionModel<T> extends MultipleSelectionModelBase<T>
{
    private BooleanProperty cellSelectionEnabled;
    
    public TableSelectionModel() {
        this.cellSelectionEnabled = new SimpleBooleanProperty(this, "cellSelectionEnabled");
    }
    
    public abstract boolean isSelected(final int p0, final TableColumnBase<T, ?> p1);
    
    public abstract void select(final int p0, final TableColumnBase<T, ?> p1);
    
    public abstract void clearAndSelect(final int p0, final TableColumnBase<T, ?> p1);
    
    public abstract void clearSelection(final int p0, final TableColumnBase<T, ?> p1);
    
    public abstract void selectLeftCell();
    
    public abstract void selectRightCell();
    
    public abstract void selectAboveCell();
    
    public abstract void selectBelowCell();
    
    public abstract void selectRange(final int p0, final TableColumnBase<T, ?> p1, final int p2, final TableColumnBase<T, ?> p3);
    
    public final BooleanProperty cellSelectionEnabledProperty() {
        return this.cellSelectionEnabled;
    }
    
    public final void setCellSelectionEnabled(final boolean b) {
        this.cellSelectionEnabledProperty().set(b);
    }
    
    public final boolean isCellSelectionEnabled() {
        return this.cellSelectionEnabled != null && this.cellSelectionEnabled.get();
    }
}
