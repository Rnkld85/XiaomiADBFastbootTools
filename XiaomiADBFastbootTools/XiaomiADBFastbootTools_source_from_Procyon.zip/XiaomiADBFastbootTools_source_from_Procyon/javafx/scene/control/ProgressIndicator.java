// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.AccessibleAttribute;
import javafx.scene.control.skin.ProgressIndicatorSkin;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.scene.AccessibleRole;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.css.PseudoClass;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;

public class ProgressIndicator extends Control
{
    public static final double INDETERMINATE_PROGRESS = -1.0;
    private ReadOnlyBooleanWrapper indeterminate;
    private DoubleProperty progress;
    private static final String DEFAULT_STYLE_CLASS = "progress-indicator";
    private static final PseudoClass PSEUDO_CLASS_DETERMINATE;
    private static final PseudoClass PSEUDO_CLASS_INDETERMINATE;
    
    public ProgressIndicator() {
        this(-1.0);
    }
    
    public ProgressIndicator(final double n) {
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
        this.setProgress(n);
        this.getStyleClass().setAll("progress-indicator");
        this.setAccessibleRole(AccessibleRole.PROGRESS_INDICATOR);
        final int compare = Double.compare(-1.0, n);
        this.pseudoClassStateChanged(ProgressIndicator.PSEUDO_CLASS_INDETERMINATE, compare == 0);
        this.pseudoClassStateChanged(ProgressIndicator.PSEUDO_CLASS_DETERMINATE, compare != 0);
    }
    
    private void setIndeterminate(final boolean b) {
        this.indeterminatePropertyImpl().set(b);
    }
    
    public final boolean isIndeterminate() {
        return this.indeterminate == null || this.indeterminate.get();
    }
    
    public final ReadOnlyBooleanProperty indeterminateProperty() {
        return this.indeterminatePropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper indeterminatePropertyImpl() {
        if (this.indeterminate == null) {
            this.indeterminate = new ReadOnlyBooleanWrapper(true) {
                @Override
                protected void invalidated() {
                    final boolean value = this.get();
                    ProgressIndicator.this.pseudoClassStateChanged(ProgressIndicator.PSEUDO_CLASS_INDETERMINATE, value);
                    ProgressIndicator.this.pseudoClassStateChanged(ProgressIndicator.PSEUDO_CLASS_DETERMINATE, !value);
                }
                
                @Override
                public Object getBean() {
                    return ProgressIndicator.this;
                }
                
                @Override
                public String getName() {
                    return "indeterminate";
                }
            };
        }
        return this.indeterminate;
    }
    
    public final void setProgress(final double n) {
        this.progressProperty().set(n);
    }
    
    public final double getProgress() {
        return (this.progress == null) ? -1.0 : this.progress.get();
    }
    
    public final DoubleProperty progressProperty() {
        if (this.progress == null) {
            this.progress = new DoublePropertyBase(-1.0) {
                @Override
                protected void invalidated() {
                    ProgressIndicator.this.setIndeterminate(ProgressIndicator.this.getProgress() < 0.0);
                }
                
                @Override
                public Object getBean() {
                    return ProgressIndicator.this;
                }
                
                @Override
                public String getName() {
                    return "progress";
                }
            };
        }
        return this.progress;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ProgressIndicatorSkin(this);
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case VALUE: {
                return this.getProgress();
            }
            case MAX_VALUE: {
                return 1.0;
            }
            case MIN_VALUE: {
                return 0.0;
            }
            case INDETERMINATE: {
                return this.isIndeterminate();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        PSEUDO_CLASS_DETERMINATE = PseudoClass.getPseudoClass("determinate");
        PSEUDO_CLASS_INDETERMINATE = PseudoClass.getPseudoClass("indeterminate");
    }
}
