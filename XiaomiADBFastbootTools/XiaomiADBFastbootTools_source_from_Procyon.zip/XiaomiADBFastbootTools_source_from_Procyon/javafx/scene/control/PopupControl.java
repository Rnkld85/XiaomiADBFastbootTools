// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import com.sun.javafx.scene.layout.PaneHelper;
import javafx.css.CssParser;
import com.sun.javafx.css.StyleManager;
import com.sun.javafx.scene.ParentHelper;
import javafx.scene.Parent;
import javafx.scene.layout.Pane;
import java.util.Collection;
import java.util.Collections;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.StringConverter;
import com.sun.javafx.application.PlatformImpl;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableSet;
import javafx.scene.Scene;
import javafx.stage.Window;
import javafx.css.PseudoClass;
import javafx.beans.property.DoublePropertyBase;
import javafx.css.StyleableStringProperty;
import javafx.collections.ObservableList;
import com.sun.javafx.stage.PopupWindowHelper;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.scene.control.Logging;
import com.sun.javafx.scene.NodeHelper;
import javafx.scene.Node;
import javafx.beans.property.ObjectPropertyBase;
import java.util.List;
import javafx.css.CssMetaData;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.ObjectProperty;
import javafx.css.Styleable;
import javafx.stage.PopupWindow;

public class PopupControl extends PopupWindow implements Skinnable, Styleable
{
    public static final double USE_PREF_SIZE = Double.NEGATIVE_INFINITY;
    public static final double USE_COMPUTED_SIZE = -1.0;
    protected CSSBridge bridge;
    private final ObjectProperty<Skin<?>> skin;
    private String currentSkinClassName;
    private StringProperty skinClassName;
    private DoubleProperty minWidth;
    private DoubleProperty minHeight;
    private DoubleProperty prefWidth;
    private DoubleProperty prefHeight;
    private DoubleProperty maxWidth;
    private DoubleProperty maxHeight;
    private double prefWidthCache;
    private double prefHeightCache;
    private double minWidthCache;
    private double minHeightCache;
    private double maxWidthCache;
    private double maxHeightCache;
    private boolean skinSizeComputed;
    private static final CssMetaData<CSSBridge, String> SKIN;
    private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
    
    public PopupControl() {
        this.skin = new ObjectPropertyBase<Skin<?>>() {
            private Skin<?> oldValue;
            
            @Override
            public void set(final Skin<?> skin) {
                Label_0039: {
                    if (skin == null) {
                        if (this.oldValue != null) {
                            break Label_0039;
                        }
                    }
                    else if (this.oldValue == null || !skin.getClass().equals(this.oldValue.getClass())) {
                        break Label_0039;
                    }
                    return;
                }
                super.set(skin);
            }
            
            @Override
            protected void invalidated() {
                final Skin skin = ((ObjectPropertyBase<Skin>)this).get();
                PopupControl.this.currentSkinClassName = ((skin == null) ? null : skin.getClass().getName());
                PopupControl.this.skinClassNameProperty().set(PopupControl.this.currentSkinClassName);
                if (this.oldValue != null) {
                    this.oldValue.dispose();
                }
                this.oldValue = this.getValue();
                PopupControl.this.prefWidthCache = -1.0;
                PopupControl.this.prefHeightCache = -1.0;
                PopupControl.this.minWidthCache = -1.0;
                PopupControl.this.minHeightCache = -1.0;
                PopupControl.this.maxWidthCache = -1.0;
                PopupControl.this.maxHeightCache = -1.0;
                PopupControl.this.skinSizeComputed = false;
                final Node access$900 = PopupControl.this.getSkinNode();
                if (access$900 != null) {
                    PopupControl.this.bridge.getChildren().setAll(access$900);
                }
                else {
                    PopupControl.this.bridge.getChildren().clear();
                }
                NodeHelper.reapplyCSS(PopupControl.this.bridge);
                final PlatformLogger controlsLogger = Logging.getControlsLogger();
                if (controlsLogger.isLoggable(PlatformLogger.Level.FINEST)) {
                    controlsLogger.finest(invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;Ljavafx/scene/control/PopupControl$1;)Ljava/lang/String;, this.getValue(), this));
                }
            }
            
            @Override
            public Object getBean() {
                return PopupControl.this;
            }
            
            @Override
            public String getName() {
                return "skin";
            }
        };
        this.currentSkinClassName = null;
        this.skinClassName = null;
        this.prefWidthCache = -1.0;
        this.prefHeightCache = -1.0;
        this.minWidthCache = -1.0;
        this.minHeightCache = -1.0;
        this.maxWidthCache = -1.0;
        this.maxHeightCache = -1.0;
        this.skinSizeComputed = false;
        this.bridge = new CSSBridge();
        this.setAnchorLocation(AnchorLocation.CONTENT_TOP_LEFT);
        PopupWindowHelper.getContent(this).add(this.bridge);
    }
    
    public final StringProperty idProperty() {
        return this.bridge.idProperty();
    }
    
    public final void setId(final String s) {
        this.idProperty().set(s);
    }
    
    @Override
    public final String getId() {
        return this.idProperty().get();
    }
    
    @Override
    public final ObservableList<String> getStyleClass() {
        return this.bridge.getStyleClass();
    }
    
    public final void setStyle(final String s) {
        this.styleProperty().set(s);
    }
    
    @Override
    public final String getStyle() {
        return this.styleProperty().get();
    }
    
    public final StringProperty styleProperty() {
        return this.bridge.styleProperty();
    }
    
    @Override
    public final ObjectProperty<Skin<?>> skinProperty() {
        return this.skin;
    }
    
    @Override
    public final void setSkin(final Skin<?> value) {
        this.skinProperty().setValue(value);
    }
    
    @Override
    public final Skin<?> getSkin() {
        return this.skinProperty().getValue();
    }
    
    private StringProperty skinClassNameProperty() {
        if (this.skinClassName == null) {
            this.skinClassName = new StyleableStringProperty() {
                @Override
                public void set(final String s) {
                    if (s == null || s.isEmpty() || s.equals(this.get())) {
                        return;
                    }
                    super.set(s);
                }
                
                public void invalidated() {
                    if (this.get() != null && !this.get().equals(PopupControl.this.currentSkinClassName)) {
                        Control.loadSkinClass(PopupControl.this, this.get());
                    }
                }
                
                @Override
                public Object getBean() {
                    return PopupControl.this;
                }
                
                @Override
                public String getName() {
                    return "skinClassName";
                }
                
                @Override
                public CssMetaData<CSSBridge, String> getCssMetaData() {
                    return PopupControl.SKIN;
                }
            };
        }
        return this.skinClassName;
    }
    
    private Node getSkinNode() {
        return (this.getSkin() == null) ? null : this.getSkin().getNode();
    }
    
    public final void setMinWidth(final double n) {
        this.minWidthProperty().set(n);
    }
    
    public final double getMinWidth() {
        return (this.minWidth == null) ? -1.0 : this.minWidth.get();
    }
    
    public final DoubleProperty minWidthProperty() {
        if (this.minWidth == null) {
            this.minWidth = new DoublePropertyBase(-1.0) {
                public void invalidated() {
                    if (PopupControl.this.isShowing()) {
                        PopupControl.this.bridge.requestLayout();
                    }
                }
                
                @Override
                public Object getBean() {
                    return PopupControl.this;
                }
                
                @Override
                public String getName() {
                    return "minWidth";
                }
            };
        }
        return this.minWidth;
    }
    
    public final void setMinHeight(final double n) {
        this.minHeightProperty().set(n);
    }
    
    public final double getMinHeight() {
        return (this.minHeight == null) ? -1.0 : this.minHeight.get();
    }
    
    public final DoubleProperty minHeightProperty() {
        if (this.minHeight == null) {
            this.minHeight = new DoublePropertyBase(-1.0) {
                public void invalidated() {
                    if (PopupControl.this.isShowing()) {
                        PopupControl.this.bridge.requestLayout();
                    }
                }
                
                @Override
                public Object getBean() {
                    return PopupControl.this;
                }
                
                @Override
                public String getName() {
                    return "minHeight";
                }
            };
        }
        return this.minHeight;
    }
    
    public void setMinSize(final double minWidth, final double minHeight) {
        this.setMinWidth(minWidth);
        this.setMinHeight(minHeight);
    }
    
    public final void setPrefWidth(final double n) {
        this.prefWidthProperty().set(n);
    }
    
    public final double getPrefWidth() {
        return (this.prefWidth == null) ? -1.0 : this.prefWidth.get();
    }
    
    public final DoubleProperty prefWidthProperty() {
        if (this.prefWidth == null) {
            this.prefWidth = new DoublePropertyBase(-1.0) {
                public void invalidated() {
                    if (PopupControl.this.isShowing()) {
                        PopupControl.this.bridge.requestLayout();
                    }
                }
                
                @Override
                public Object getBean() {
                    return PopupControl.this;
                }
                
                @Override
                public String getName() {
                    return "prefWidth";
                }
            };
        }
        return this.prefWidth;
    }
    
    public final void setPrefHeight(final double n) {
        this.prefHeightProperty().set(n);
    }
    
    public final double getPrefHeight() {
        return (this.prefHeight == null) ? -1.0 : this.prefHeight.get();
    }
    
    public final DoubleProperty prefHeightProperty() {
        if (this.prefHeight == null) {
            this.prefHeight = new DoublePropertyBase(-1.0) {
                public void invalidated() {
                    if (PopupControl.this.isShowing()) {
                        PopupControl.this.bridge.requestLayout();
                    }
                }
                
                @Override
                public Object getBean() {
                    return PopupControl.this;
                }
                
                @Override
                public String getName() {
                    return "prefHeight";
                }
            };
        }
        return this.prefHeight;
    }
    
    public void setPrefSize(final double prefWidth, final double prefHeight) {
        this.setPrefWidth(prefWidth);
        this.setPrefHeight(prefHeight);
    }
    
    public final void setMaxWidth(final double n) {
        this.maxWidthProperty().set(n);
    }
    
    public final double getMaxWidth() {
        return (this.maxWidth == null) ? -1.0 : this.maxWidth.get();
    }
    
    public final DoubleProperty maxWidthProperty() {
        if (this.maxWidth == null) {
            this.maxWidth = new DoublePropertyBase(-1.0) {
                public void invalidated() {
                    if (PopupControl.this.isShowing()) {
                        PopupControl.this.bridge.requestLayout();
                    }
                }
                
                @Override
                public Object getBean() {
                    return PopupControl.this;
                }
                
                @Override
                public String getName() {
                    return "maxWidth";
                }
            };
        }
        return this.maxWidth;
    }
    
    public final void setMaxHeight(final double n) {
        this.maxHeightProperty().set(n);
    }
    
    public final double getMaxHeight() {
        return (this.maxHeight == null) ? -1.0 : this.maxHeight.get();
    }
    
    public final DoubleProperty maxHeightProperty() {
        if (this.maxHeight == null) {
            this.maxHeight = new DoublePropertyBase(-1.0) {
                public void invalidated() {
                    if (PopupControl.this.isShowing()) {
                        PopupControl.this.bridge.requestLayout();
                    }
                }
                
                @Override
                public Object getBean() {
                    return PopupControl.this;
                }
                
                @Override
                public String getName() {
                    return "maxHeight";
                }
            };
        }
        return this.maxHeight;
    }
    
    public void setMaxSize(final double maxWidth, final double maxHeight) {
        this.setMaxWidth(maxWidth);
        this.setMaxHeight(maxHeight);
    }
    
    public final double minWidth(final double n) {
        final double minWidth = this.getMinWidth();
        if (minWidth == -1.0) {
            if (this.minWidthCache == -1.0) {
                this.minWidthCache = this.recalculateMinWidth(n);
            }
            return this.minWidthCache;
        }
        if (minWidth == Double.NEGATIVE_INFINITY) {
            return this.prefWidth(n);
        }
        return minWidth;
    }
    
    public final double minHeight(final double n) {
        final double minHeight = this.getMinHeight();
        if (minHeight == -1.0) {
            if (this.minHeightCache == -1.0) {
                this.minHeightCache = this.recalculateMinHeight(n);
            }
            return this.minHeightCache;
        }
        if (minHeight == Double.NEGATIVE_INFINITY) {
            return this.prefHeight(n);
        }
        return minHeight;
    }
    
    public final double prefWidth(final double n) {
        final double prefWidth = this.getPrefWidth();
        if (prefWidth == -1.0) {
            if (this.prefWidthCache == -1.0) {
                this.prefWidthCache = this.recalculatePrefWidth(n);
            }
            return this.prefWidthCache;
        }
        if (prefWidth == Double.NEGATIVE_INFINITY) {
            return this.prefWidth(n);
        }
        return prefWidth;
    }
    
    public final double prefHeight(final double n) {
        final double prefHeight = this.getPrefHeight();
        if (prefHeight == -1.0) {
            if (this.prefHeightCache == -1.0) {
                this.prefHeightCache = this.recalculatePrefHeight(n);
            }
            return this.prefHeightCache;
        }
        if (prefHeight == Double.NEGATIVE_INFINITY) {
            return this.prefHeight(n);
        }
        return prefHeight;
    }
    
    public final double maxWidth(final double n) {
        final double maxWidth = this.getMaxWidth();
        if (maxWidth == -1.0) {
            if (this.maxWidthCache == -1.0) {
                this.maxWidthCache = this.recalculateMaxWidth(n);
            }
            return this.maxWidthCache;
        }
        if (maxWidth == Double.NEGATIVE_INFINITY) {
            return this.prefWidth(n);
        }
        return maxWidth;
    }
    
    public final double maxHeight(final double n) {
        final double maxHeight = this.getMaxHeight();
        if (maxHeight == -1.0) {
            if (this.maxHeightCache == -1.0) {
                this.maxHeightCache = this.recalculateMaxHeight(n);
            }
            return this.maxHeightCache;
        }
        if (maxHeight == Double.NEGATIVE_INFINITY) {
            return this.prefHeight(n);
        }
        return maxHeight;
    }
    
    private double recalculateMinWidth(final double n) {
        this.recomputeSkinSize();
        return (this.getSkinNode() == null) ? 0.0 : this.getSkinNode().minWidth(n);
    }
    
    private double recalculateMinHeight(final double n) {
        this.recomputeSkinSize();
        return (this.getSkinNode() == null) ? 0.0 : this.getSkinNode().minHeight(n);
    }
    
    private double recalculateMaxWidth(final double n) {
        this.recomputeSkinSize();
        return (this.getSkinNode() == null) ? 0.0 : this.getSkinNode().maxWidth(n);
    }
    
    private double recalculateMaxHeight(final double n) {
        this.recomputeSkinSize();
        return (this.getSkinNode() == null) ? 0.0 : this.getSkinNode().maxHeight(n);
    }
    
    private double recalculatePrefWidth(final double n) {
        this.recomputeSkinSize();
        return (this.getSkinNode() == null) ? 0.0 : this.getSkinNode().prefWidth(n);
    }
    
    private double recalculatePrefHeight(final double n) {
        this.recomputeSkinSize();
        return (this.getSkinNode() == null) ? 0.0 : this.getSkinNode().prefHeight(n);
    }
    
    private void recomputeSkinSize() {
        if (!this.skinSizeComputed) {
            this.bridge.applyCss();
            this.skinSizeComputed = true;
        }
    }
    
    protected Skin<?> createDefaultSkin() {
        return null;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return PopupControl.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    public final void pseudoClassStateChanged(final PseudoClass pseudoClass, final boolean b) {
        this.bridge.pseudoClassStateChanged(pseudoClass, b);
    }
    
    @Override
    public String getTypeSelector() {
        return "PopupControl";
    }
    
    @Override
    public Styleable getStyleableParent() {
        final Node ownerNode = this.getOwnerNode();
        if (ownerNode != null) {
            return ownerNode;
        }
        final Window ownerWindow = this.getOwnerWindow();
        if (ownerWindow != null) {
            final Scene scene = ownerWindow.getScene();
            if (scene != null) {
                return scene.getRoot();
            }
        }
        return this.bridge.getParent();
    }
    
    @Override
    public final ObservableSet<PseudoClass> getPseudoClassStates() {
        return FXCollections.emptyObservableSet();
    }
    
    @Override
    public Node getStyleableNode() {
        return this.bridge;
    }
    
    static {
        if (Application.getUserAgentStylesheet() == null) {
            PlatformImpl.setDefaultPlatformUserAgentStylesheet();
        }
        SKIN = new CssMetaData<CSSBridge, String>((StyleConverter)StringConverter.getInstance()) {
            @Override
            public boolean isSettable(final CSSBridge cssBridge) {
                return !cssBridge.popupControl.skinProperty().isBound();
            }
            
            @Override
            public StyleableProperty<String> getStyleableProperty(final CSSBridge cssBridge) {
                return (StyleableProperty<String>)cssBridge.popupControl.skinClassNameProperty();
            }
        };
        final ArrayList<Object> list = new ArrayList<Object>();
        Collections.addAll(list, PopupControl.SKIN);
        STYLEABLES = Collections.unmodifiableList((List<? extends CssMetaData<? extends Styleable, ?>>)list);
    }
    
    protected class CSSBridge extends Pane
    {
        private final PopupControl popupControl;
        
        protected CSSBridge() {
            this.popupControl = PopupControl.this;
            CSSBridgeHelper.initHelper(this);
        }
        
        @Override
        public void requestLayout() {
            PopupControl.this.prefWidthCache = -1.0;
            PopupControl.this.prefHeightCache = -1.0;
            PopupControl.this.minWidthCache = -1.0;
            PopupControl.this.minHeightCache = -1.0;
            PopupControl.this.maxWidthCache = -1.0;
            PopupControl.this.maxHeightCache = -1.0;
            super.requestLayout();
        }
        
        @Override
        public Styleable getStyleableParent() {
            return PopupControl.this.getStyleableParent();
        }
        
        @Override
        public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
            return PopupControl.this.getCssMetaData();
        }
        
        private List<String> doGetAllParentStylesheets() {
            final Styleable styleableParent = this.getStyleableParent();
            if (styleableParent instanceof Parent) {
                return ParentHelper.getAllParentStylesheets((Parent)styleableParent);
            }
            return null;
        }
        
        private void doProcessCSS() {
            CSSBridgeHelper.superProcessCSS(this);
            if (PopupControl.this.getSkin() == null) {
                final Skin<?> defaultSkin = PopupControl.this.createDefaultSkin();
                if (defaultSkin != null) {
                    PopupControl.this.skinProperty().set(defaultSkin);
                    CSSBridgeHelper.superProcessCSS(this);
                }
                else {
                    final String s = invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/PopupControl$CSSBridge;)Ljava/lang/String;, this);
                    final ObservableList<CssParser.ParseError> errors = StyleManager.getErrors();
                    if (errors != null) {
                        errors.add(new CssParser.ParseError(s));
                    }
                    Logging.getControlsLogger().severe(s);
                }
            }
        }
    }
    
    static final class CSSBridgeHelper extends PaneHelper
    {
        private static final CSSBridgeHelper theInstance;
        
        private static CSSBridgeHelper getInstance() {
            return CSSBridgeHelper.theInstance;
        }
        
        public static void initHelper(final CSSBridge cssBridge) {
            NodeHelper.setHelper(cssBridge, getInstance());
        }
        
        public static void superProcessCSS(final Node node) {
            ((CSSBridgeHelper)NodeHelper.getHelper(node)).superProcessCSSImpl(node);
        }
        
        @Override
        void superProcessCSSImpl(final Node node) {
            super.processCSSImpl(node);
        }
        
        @Override
        protected void processCSSImpl(final Node node) {
            ((CSSBridge)node).doProcessCSS();
        }
        
        @Override
        protected List<String> getAllParentStylesheetsImpl(final Parent parent) {
            return ((CSSBridge)parent).doGetAllParentStylesheets();
        }
        
        static {
            theInstance = new CSSBridgeHelper();
        }
    }
}
