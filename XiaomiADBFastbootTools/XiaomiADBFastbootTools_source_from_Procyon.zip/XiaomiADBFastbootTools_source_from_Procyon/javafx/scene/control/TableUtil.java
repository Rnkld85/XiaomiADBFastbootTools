// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.collections.ObservableList;
import javafx.collections.ListChangeListener;
import java.util.Iterator;
import javafx.beans.InvalidationListener;
import java.util.List;

class TableUtil
{
    private TableUtil() {
    }
    
    static void removeTableColumnListener(final List<? extends TableColumnBase> list, final InvalidationListener invalidationListener, final InvalidationListener invalidationListener2, final InvalidationListener invalidationListener3, final InvalidationListener invalidationListener4) {
        if (list == null) {
            return;
        }
        for (final TableColumnBase tableColumnBase : list) {
            tableColumnBase.visibleProperty().removeListener(invalidationListener);
            tableColumnBase.sortableProperty().removeListener(invalidationListener2);
            tableColumnBase.comparatorProperty().removeListener(invalidationListener4);
            if (tableColumnBase instanceof TableColumn) {
                ((TableColumn)tableColumnBase).sortTypeProperty().removeListener(invalidationListener3);
            }
            else if (tableColumnBase instanceof TreeTableColumn) {
                ((TreeTableColumn)tableColumnBase).sortTypeProperty().removeListener(invalidationListener3);
            }
            removeTableColumnListener(tableColumnBase.getColumns(), invalidationListener, invalidationListener2, invalidationListener3, invalidationListener4);
        }
    }
    
    static void addTableColumnListener(final List<? extends TableColumnBase> list, final InvalidationListener invalidationListener, final InvalidationListener invalidationListener2, final InvalidationListener invalidationListener3, final InvalidationListener invalidationListener4) {
        if (list == null) {
            return;
        }
        for (final TableColumnBase tableColumnBase : list) {
            tableColumnBase.visibleProperty().addListener(invalidationListener);
            tableColumnBase.sortableProperty().addListener(invalidationListener2);
            tableColumnBase.comparatorProperty().addListener(invalidationListener4);
            if (tableColumnBase instanceof TableColumn) {
                ((TableColumn)tableColumnBase).sortTypeProperty().addListener(invalidationListener3);
            }
            else if (tableColumnBase instanceof TreeTableColumn) {
                ((TreeTableColumn)tableColumnBase).sortTypeProperty().addListener(invalidationListener3);
            }
            addTableColumnListener(tableColumnBase.getColumns(), invalidationListener, invalidationListener2, invalidationListener3, invalidationListener4);
        }
    }
    
    static void removeColumnsListener(final List<? extends TableColumnBase> list, final ListChangeListener listChangeListener) {
        if (list == null) {
            return;
        }
        for (final TableColumnBase tableColumnBase : list) {
            tableColumnBase.getColumns().removeListener(listChangeListener);
            removeColumnsListener(tableColumnBase.getColumns(), listChangeListener);
        }
    }
    
    static void addColumnsListener(final List<? extends TableColumnBase> list, final ListChangeListener listChangeListener) {
        if (list == null) {
            return;
        }
        for (final TableColumnBase tableColumnBase : list) {
            tableColumnBase.getColumns().addListener(listChangeListener);
            addColumnsListener(tableColumnBase.getColumns(), listChangeListener);
        }
    }
    
    static void handleSortFailure(final ObservableList<? extends TableColumnBase> list, final SortEventType sortEventType, final Object... array) {
        if (sortEventType == SortEventType.COLUMN_SORT_TYPE_CHANGE) {
            revertSortType((TableColumnBase)array[0]);
        }
        else if (sortEventType == SortEventType.SORT_ORDER_CHANGE) {
            final ListChangeListener.Change change = (ListChangeListener.Change)array[0];
            final ArrayList<Object> list2 = new ArrayList<Object>();
            final ArrayList<Object> list3 = new ArrayList<Object>();
            while (change.next()) {
                if (change.wasAdded()) {
                    list2.addAll(change.getAddedSubList());
                }
                if (change.wasRemoved()) {
                    list3.addAll(change.getRemoved());
                }
            }
            list.removeAll(list2);
            list.addAll((Collection<?>)list3);
        }
        else if (sortEventType != SortEventType.COLUMN_SORTABLE_CHANGE) {
            if (sortEventType == SortEventType.COLUMN_COMPARATOR_CHANGE) {}
        }
    }
    
    private static void revertSortType(final TableColumnBase tableColumnBase) {
        if (tableColumnBase instanceof TableColumn) {
            final TableColumn tableColumn = (TableColumn)tableColumnBase;
            final TableColumn.SortType sortType = tableColumn.getSortType();
            if (sortType == TableColumn.SortType.ASCENDING) {
                tableColumn.setSortType(null);
            }
            else if (sortType == TableColumn.SortType.DESCENDING) {
                tableColumn.setSortType(TableColumn.SortType.ASCENDING);
            }
            else if (sortType == null) {
                tableColumn.setSortType(TableColumn.SortType.DESCENDING);
            }
        }
        else if (tableColumnBase instanceof TreeTableColumn) {
            final TreeTableColumn treeTableColumn = (TreeTableColumn)tableColumnBase;
            final TreeTableColumn.SortType sortType2 = treeTableColumn.getSortType();
            if (sortType2 == TreeTableColumn.SortType.ASCENDING) {
                treeTableColumn.setSortType(null);
            }
            else if (sortType2 == TreeTableColumn.SortType.DESCENDING) {
                treeTableColumn.setSortType(TreeTableColumn.SortType.ASCENDING);
            }
            else if (sortType2 == null) {
                treeTableColumn.setSortType(TreeTableColumn.SortType.DESCENDING);
            }
        }
    }
    
    static boolean constrainedResize(final ResizeFeaturesBase resizeFeaturesBase, final boolean b, final double n, final List<? extends TableColumnBase<?, ?>> list) {
        final TableColumnBase column = resizeFeaturesBase.getColumn();
        final double doubleValue = resizeFeaturesBase.getDelta();
        double n2 = 0.0;
        double n3 = 0.0;
        if (n == 0.0) {
            return false;
        }
        double n4 = 0.0;
        final Iterator<? extends TableColumnBase<?, ?>> iterator = list.iterator();
        while (iterator.hasNext()) {
            n4 += ((TableColumnBase)iterator.next()).getWidth();
        }
        if (Math.abs(n4 - n) > 1.0) {
            final boolean b2 = n4 > n;
            double n5 = n;
            if (b) {
                for (final TableColumnBase tableColumnBase : list) {
                    n2 += tableColumnBase.getMinWidth();
                    n3 += tableColumnBase.getMaxWidth();
                }
                double n6 = (n3 == Double.POSITIVE_INFINITY) ? Double.MAX_VALUE : ((n3 == Double.NEGATIVE_INFINITY) ? Double.MIN_VALUE : n3);
                for (final TableColumnBase tableColumnBase2 : list) {
                    final double minWidth = tableColumnBase2.getMinWidth();
                    final double maxWidth = tableColumnBase2.getMaxWidth();
                    double n7;
                    if (Math.abs(n2 - n6) < 1.0E-7) {
                        n7 = minWidth;
                    }
                    else {
                        n7 = (double)Math.round(minWidth + (n5 - n2) / (n6 - n2) * (maxWidth - minWidth));
                    }
                    n5 -= n7 + resize(tableColumnBase2, n7 - tableColumnBase2.getWidth());
                    n2 -= minWidth;
                    n6 -= maxWidth;
                }
            }
            else {
                resizeColumns(list, n - n4);
            }
        }
        if (column == null) {
            return false;
        }
        final boolean b3 = doubleValue < 0.0;
        TableColumnBase tableColumnBase3;
        for (tableColumnBase3 = column; tableColumnBase3.getColumns().size() > 0; tableColumnBase3 = (TableColumnBase)tableColumnBase3.getColumns().get(tableColumnBase3.getColumns().size() - 1)) {}
        final int index = list.indexOf(tableColumnBase3);
        int n8 = list.size() - 1;
        double a = doubleValue;
        while (n8 > index && a != 0.0) {
            final TableColumnBase tableColumnBase4 = (TableColumnBase)list.get(n8);
            --n8;
            if (!tableColumnBase4.isResizable()) {
                continue;
            }
            final TableColumnBase tableColumnBase5 = b3 ? tableColumnBase3 : tableColumnBase4;
            TableColumnBase tableColumnBase6 = b3 ? tableColumnBase4 : tableColumnBase3;
            if (tableColumnBase6.getWidth() > tableColumnBase6.getPrefWidth()) {
                final List<? extends TableColumnBase<?, ?>> subList = list.subList(index + 1, n8 + 1);
                for (int i = subList.size() - 1; i >= 0; --i) {
                    final TableColumnBase tableColumnBase7 = (TableColumnBase)subList.get(i);
                    if (tableColumnBase7.getWidth() < tableColumnBase7.getPrefWidth()) {
                        tableColumnBase6 = tableColumnBase7;
                        break;
                    }
                }
            }
            final double min = Math.min(Math.abs(a), tableColumnBase5.getWidth() - tableColumnBase5.getMinWidth());
            resize(tableColumnBase5, -min);
            resize(tableColumnBase6, min);
            a += (b3 ? min : (-min));
        }
        return a == 0.0;
    }
    
    static double resize(final TableColumnBase tableColumnBase, final double n) {
        if (n == 0.0) {
            return 0.0;
        }
        if (!tableColumnBase.isResizable()) {
            return n;
        }
        final List<TableColumnBase<?, ?>> resizableChildren = getResizableChildren(tableColumnBase, n < 0.0);
        if (resizableChildren.size() > 0) {
            return resizeColumns(resizableChildren, n);
        }
        final double n2 = tableColumnBase.getWidth() + n;
        if (n2 > tableColumnBase.getMaxWidth()) {
            tableColumnBase.doSetWidth(tableColumnBase.getMaxWidth());
            return n2 - tableColumnBase.getMaxWidth();
        }
        if (n2 < tableColumnBase.getMinWidth()) {
            tableColumnBase.doSetWidth(tableColumnBase.getMinWidth());
            return n2 - tableColumnBase.getMinWidth();
        }
        tableColumnBase.doSetWidth(n2);
        return 0.0;
    }
    
    private static List<TableColumnBase<?, ?>> getResizableChildren(final TableColumnBase<?, ?> tableColumnBase, final boolean b) {
        if (tableColumnBase == null || tableColumnBase.getColumns().isEmpty()) {
            return Collections.emptyList();
        }
        final ArrayList<TableColumnBase> list = (ArrayList<TableColumnBase>)new ArrayList<TableColumnBase<?, ?>>();
        for (final TableColumnBase<?, ?> tableColumnBase2 : tableColumnBase.getColumns()) {
            if (!tableColumnBase2.isVisible()) {
                continue;
            }
            if (!tableColumnBase2.isResizable()) {
                continue;
            }
            if (b && tableColumnBase2.getWidth() > tableColumnBase2.getMinWidth()) {
                list.add(tableColumnBase2);
            }
            else {
                if (b || tableColumnBase2.getWidth() >= tableColumnBase2.getMaxWidth()) {
                    continue;
                }
                list.add(tableColumnBase2);
            }
        }
        return (List<TableColumnBase<?, ?>>)list;
    }
    
    private static double resizeColumns(final List<? extends TableColumnBase<?, ?>> list, final double n) {
        final int size = list.size();
        double n2 = n / size;
        double n3 = n;
        int n4 = 0;
        boolean b = true;
        for (final TableColumnBase tableColumnBase : list) {
            ++n4;
            final double resize = resize(tableColumnBase, n2);
            n3 = n3 - n2 + resize;
            if (resize != 0.0) {
                b = false;
                n2 = n3 / (size - n4);
            }
        }
        return b ? 0.0 : n3;
    }
    
    enum SortEventType
    {
        SORT_ORDER_CHANGE, 
        COLUMN_SORT_TYPE_CHANGE, 
        COLUMN_SORTABLE_CHANGE, 
        COLUMN_COMPARATOR_CHANGE;
    }
}
