// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

public enum SelectionMode
{
    SINGLE, 
    MULTIPLE;
}
