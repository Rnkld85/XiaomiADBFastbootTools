// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.AccessibleAction;
import javafx.scene.control.skin.TreeCellSkin;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.AccessibleRole;
import java.lang.ref.WeakReference;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.AccessibleAttribute;
import javafx.beans.property.BooleanProperty;
import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import javafx.css.PseudoClass;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.value.WeakChangeListener;
import javafx.collections.WeakListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import javafx.collections.ListChangeListener;

public class TreeCell<T> extends IndexedCell<T>
{
    private final ListChangeListener<Integer> selectedListener;
    private final ChangeListener<MultipleSelectionModel<TreeItem<T>>> selectionModelPropertyListener;
    private final InvalidationListener focusedListener;
    private final ChangeListener<FocusModel<TreeItem<T>>> focusModelPropertyListener;
    private final InvalidationListener editingListener;
    private final InvalidationListener leafListener;
    private boolean oldIsExpanded;
    private final InvalidationListener treeItemExpandedInvalidationListener;
    private final InvalidationListener rootPropertyListener;
    private final WeakListChangeListener<Integer> weakSelectedListener;
    private final WeakChangeListener<MultipleSelectionModel<TreeItem<T>>> weakSelectionModelPropertyListener;
    private final WeakInvalidationListener weakFocusedListener;
    private final WeakChangeListener<FocusModel<TreeItem<T>>> weakFocusModelPropertyListener;
    private final WeakInvalidationListener weakEditingListener;
    private final WeakInvalidationListener weakLeafListener;
    private final WeakInvalidationListener weakTreeItemExpandedInvalidationListener;
    private final WeakInvalidationListener weakRootPropertyListener;
    private ReadOnlyObjectWrapper<TreeItem<T>> treeItem;
    private ObjectProperty<Node> disclosureNode;
    private ReadOnlyObjectWrapper<TreeView<T>> treeView;
    private boolean isFirstRun;
    private boolean updateEditingIndex;
    private static final String DEFAULT_STYLE_CLASS = "tree-cell";
    private static final PseudoClass EXPANDED_PSEUDOCLASS_STATE;
    private static final PseudoClass COLLAPSED_PSEUDOCLASS_STATE;
    
    public TreeCell() {
        this.selectedListener = (p0 -> this.updateSelection());
        this.selectionModelPropertyListener = new ChangeListener<MultipleSelectionModel<TreeItem<T>>>() {
            @Override
            public void changed(final ObservableValue<? extends MultipleSelectionModel<TreeItem<T>>> observableValue, final MultipleSelectionModel<TreeItem<T>> multipleSelectionModel, final MultipleSelectionModel<TreeItem<T>> multipleSelectionModel2) {
                if (multipleSelectionModel != null) {
                    multipleSelectionModel.getSelectedIndices().removeListener(TreeCell.this.weakSelectedListener);
                }
                if (multipleSelectionModel2 != null) {
                    multipleSelectionModel2.getSelectedIndices().addListener(TreeCell.this.weakSelectedListener);
                }
                TreeCell.this.updateSelection();
            }
        };
        this.focusedListener = (p0 -> this.updateFocus());
        this.focusModelPropertyListener = new ChangeListener<FocusModel<TreeItem<T>>>() {
            @Override
            public void changed(final ObservableValue<? extends FocusModel<TreeItem<T>>> observableValue, final FocusModel<TreeItem<T>> focusModel, final FocusModel<TreeItem<T>> focusModel2) {
                if (focusModel != null) {
                    focusModel.focusedIndexProperty().removeListener(TreeCell.this.weakFocusedListener);
                }
                if (focusModel2 != null) {
                    focusModel2.focusedIndexProperty().addListener(TreeCell.this.weakFocusedListener);
                }
                TreeCell.this.updateFocus();
            }
        };
        this.editingListener = (p0 -> this.updateEditing());
        this.leafListener = new InvalidationListener() {
            @Override
            public void invalidated(final Observable observable) {
                if (TreeCell.this.getTreeItem() != null) {
                    TreeCell.this.requestLayout();
                }
            }
        };
        this.treeItemExpandedInvalidationListener = new InvalidationListener() {
            @Override
            public void invalidated(final Observable observable) {
                final boolean value = ((BooleanProperty)observable).get();
                TreeCell.this.pseudoClassStateChanged(TreeCell.EXPANDED_PSEUDOCLASS_STATE, value);
                TreeCell.this.pseudoClassStateChanged(TreeCell.COLLAPSED_PSEUDOCLASS_STATE, !value);
                if (value != TreeCell.this.oldIsExpanded) {
                    TreeCell.this.notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED);
                }
                TreeCell.this.oldIsExpanded = value;
            }
        };
        this.rootPropertyListener = (p0 -> this.updateItem(-1));
        this.weakSelectedListener = new WeakListChangeListener<Integer>(this.selectedListener);
        this.weakSelectionModelPropertyListener = new WeakChangeListener<MultipleSelectionModel<TreeItem<T>>>(this.selectionModelPropertyListener);
        this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
        this.weakFocusModelPropertyListener = new WeakChangeListener<FocusModel<TreeItem<T>>>(this.focusModelPropertyListener);
        this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
        this.weakLeafListener = new WeakInvalidationListener(this.leafListener);
        this.weakTreeItemExpandedInvalidationListener = new WeakInvalidationListener(this.treeItemExpandedInvalidationListener);
        this.weakRootPropertyListener = new WeakInvalidationListener(this.rootPropertyListener);
        this.treeItem = new ReadOnlyObjectWrapper<TreeItem<T>>((Object)this, "treeItem") {
            TreeItem<T> oldValue = null;
            
            @Override
            protected void invalidated() {
                if (this.oldValue != null) {
                    this.oldValue.expandedProperty().removeListener(TreeCell.this.weakTreeItemExpandedInvalidationListener);
                }
                this.oldValue = this.get();
                if (this.oldValue != null) {
                    TreeCell.this.oldIsExpanded = this.oldValue.isExpanded();
                    this.oldValue.expandedProperty().addListener(TreeCell.this.weakTreeItemExpandedInvalidationListener);
                    TreeCell.this.weakTreeItemExpandedInvalidationListener.invalidated(this.oldValue.expandedProperty());
                }
            }
        };
        this.disclosureNode = new SimpleObjectProperty<Node>(this, "disclosureNode");
        this.treeView = new ReadOnlyObjectWrapper<TreeView<T>>() {
            private WeakReference<TreeView<T>> weakTreeViewRef;
            
            @Override
            protected void invalidated() {
                if (this.weakTreeViewRef != null) {
                    final TreeView treeView = this.weakTreeViewRef.get();
                    if (treeView != null) {
                        final MultipleSelectionModel selectionModel = treeView.getSelectionModel();
                        if (selectionModel != null) {
                            selectionModel.getSelectedIndices().removeListener(TreeCell.this.weakSelectedListener);
                        }
                        final FocusModel focusModel = treeView.getFocusModel();
                        if (focusModel != null) {
                            focusModel.focusedIndexProperty().removeListener(TreeCell.this.weakFocusedListener);
                        }
                        treeView.editingItemProperty().removeListener(TreeCell.this.weakEditingListener);
                        treeView.focusModelProperty().removeListener(TreeCell.this.weakFocusModelPropertyListener);
                        treeView.selectionModelProperty().removeListener(TreeCell.this.weakSelectionModelPropertyListener);
                        treeView.rootProperty().removeListener(TreeCell.this.weakRootPropertyListener);
                    }
                    this.weakTreeViewRef = null;
                }
                final TreeView<T> referent = this.get();
                if (referent != null) {
                    final MultipleSelectionModel<TreeItem<T>> selectionModel2 = referent.getSelectionModel();
                    if (selectionModel2 != null) {
                        selectionModel2.getSelectedIndices().addListener(TreeCell.this.weakSelectedListener);
                    }
                    final FocusModel<TreeItem<T>> focusModel2 = referent.getFocusModel();
                    if (focusModel2 != null) {
                        focusModel2.focusedIndexProperty().addListener(TreeCell.this.weakFocusedListener);
                    }
                    referent.editingItemProperty().addListener(TreeCell.this.weakEditingListener);
                    referent.focusModelProperty().addListener(TreeCell.this.weakFocusModelPropertyListener);
                    referent.selectionModelProperty().addListener(TreeCell.this.weakSelectionModelPropertyListener);
                    referent.rootProperty().addListener(TreeCell.this.weakRootPropertyListener);
                    this.weakTreeViewRef = new WeakReference<TreeView<T>>(referent);
                }
                TreeCell.this.updateItem(-1);
                TreeCell.this.requestLayout();
            }
            
            @Override
            public Object getBean() {
                return TreeCell.this;
            }
            
            @Override
            public String getName() {
                return "treeView";
            }
        };
        this.isFirstRun = true;
        this.updateEditingIndex = true;
        this.getStyleClass().addAll("tree-cell");
        this.setAccessibleRole(AccessibleRole.TREE_ITEM);
    }
    
    private void setTreeItem(final TreeItem<T> treeItem) {
        this.treeItem.set(treeItem);
    }
    
    public final TreeItem<T> getTreeItem() {
        return this.treeItem.get();
    }
    
    public final ReadOnlyObjectProperty<TreeItem<T>> treeItemProperty() {
        return this.treeItem.getReadOnlyProperty();
    }
    
    public final void setDisclosureNode(final Node node) {
        this.disclosureNodeProperty().set(node);
    }
    
    public final Node getDisclosureNode() {
        return this.disclosureNode.get();
    }
    
    public final ObjectProperty<Node> disclosureNodeProperty() {
        return this.disclosureNode;
    }
    
    private void setTreeView(final TreeView<T> treeView) {
        this.treeView.set(treeView);
    }
    
    public final TreeView<T> getTreeView() {
        return this.treeView.get();
    }
    
    public final ReadOnlyObjectProperty<TreeView<T>> treeViewProperty() {
        return this.treeView.getReadOnlyProperty();
    }
    
    @Override
    public void startEdit() {
        if (this.isEditing()) {
            return;
        }
        final TreeView<?> treeView = this.getTreeView();
        if (!this.isEditable() || (treeView != null && !treeView.isEditable())) {
            return;
        }
        this.updateItem(-1);
        super.startEdit();
        if (treeView != null) {
            treeView.fireEvent(new TreeView.EditEvent<Object>((TreeView<Object>)treeView, TreeView.editStartEvent(), this.getTreeItem(), this.getItem(), null));
            treeView.requestFocus();
        }
    }
    
    @Override
    public void commitEdit(final T value) {
        if (!this.isEditing()) {
            return;
        }
        final TreeItem<T> treeItem = (TreeItem<T>)this.getTreeItem();
        final TreeView<Object> treeView = this.getTreeView();
        if (treeView != null) {
            treeView.fireEvent(new TreeView.EditEvent<Object>(treeView, TreeView.editCommitEvent(), (TreeItem<Object>)treeItem, this.getItem(), value));
        }
        super.commitEdit(value);
        if (treeItem != null) {
            treeItem.setValue((Object)value);
            this.updateTreeItem(treeItem);
            this.updateItem(value, false);
        }
        if (treeView != null) {
            treeView.edit((TreeItem<?>)null);
            ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(treeView);
        }
    }
    
    @Override
    public void cancelEdit() {
        if (!this.isEditing()) {
            return;
        }
        final TreeView<Object> treeView = this.getTreeView();
        super.cancelEdit();
        if (treeView != null) {
            if (this.updateEditingIndex) {
                treeView.edit(null);
            }
            ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(treeView);
            treeView.fireEvent(new TreeView.EditEvent<Object>(treeView, TreeView.editCancelEvent(), this.getTreeItem(), this.getItem(), null));
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TreeCellSkin<Object>(this);
    }
    
    @Override
    void indexChanged(final int n, final int n2) {
        super.indexChanged(n, n2);
        if (!this.isEditing() || n2 != n) {
            this.updateItem(n);
            this.updateSelection();
            this.updateFocus();
        }
    }
    
    private void updateItem(final int n) {
        final TreeView<T> treeView = this.getTreeView();
        if (treeView == null) {
            return;
        }
        final int index = this.getIndex();
        final boolean b = index >= 0 && index < treeView.getExpandedItemCount();
        final boolean empty = this.isEmpty();
        final TreeItem<T> treeItem = this.getTreeItem();
        if (b) {
            final TreeItem<T> treeItem2 = treeView.getTreeItem(index);
            final T t = (treeItem2 == null) ? null : treeItem2.getValue();
            final T t2 = (treeItem == null) ? null : treeItem.getValue();
            if (n != index || this.isItemChanged(t2, t)) {
                this.updateTreeItem(treeItem2);
                this.updateItem(t, false);
            }
        }
        else if ((!empty && treeItem != null) || this.isFirstRun) {
            this.updateTreeItem(null);
            this.updateItem(null, true);
            this.isFirstRun = false;
        }
    }
    
    private void updateSelection() {
        if (this.isEmpty()) {
            return;
        }
        if (this.getIndex() == -1 || this.getTreeView() == null) {
            return;
        }
        final MultipleSelectionModel<TreeItem<T>> selectionModel = this.getTreeView().getSelectionModel();
        if (selectionModel == null) {
            this.updateSelected(false);
            return;
        }
        final boolean selected = selectionModel.isSelected(this.getIndex());
        if (this.isSelected() == selected) {
            return;
        }
        this.updateSelected(selected);
    }
    
    private void updateFocus() {
        if (this.getIndex() == -1 || this.getTreeView() == null) {
            return;
        }
        final FocusModel<TreeItem<T>> focusModel = this.getTreeView().getFocusModel();
        if (focusModel == null) {
            this.setFocused(false);
            return;
        }
        this.setFocused(focusModel.isFocused(this.getIndex()));
    }
    
    private void updateEditing() {
        final int index = this.getIndex();
        final TreeView<T> treeView = this.getTreeView();
        final TreeItem<T> treeItem = this.getTreeItem();
        final TreeItem<T> obj = (treeView == null) ? null : treeView.getEditingItem();
        final boolean editing = this.isEditing();
        if (index == -1 || treeView == null || treeItem == null) {
            return;
        }
        final boolean equals = treeItem.equals(obj);
        if (equals && !editing) {
            this.startEdit();
        }
        else if (!equals && editing) {
            this.updateEditingIndex = false;
            this.cancelEdit();
            this.updateEditingIndex = true;
        }
    }
    
    public final void updateTreeView(final TreeView<T> treeView) {
        this.setTreeView(treeView);
    }
    
    public final void updateTreeItem(final TreeItem<T> treeItem) {
        final TreeItem<T> treeItem2 = this.getTreeItem();
        if (treeItem2 != null) {
            treeItem2.leafProperty().removeListener(this.weakLeafListener);
        }
        this.setTreeItem(treeItem);
        if (treeItem != null) {
            treeItem.leafProperty().addListener(this.weakLeafListener);
        }
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        final TreeItem<T> treeItem = this.getTreeItem();
        final TreeView<T> treeView = this.getTreeView();
        switch (accessibleAttribute) {
            case TREE_ITEM_PARENT: {
                if (treeView == null) {
                    return null;
                }
                if (treeItem == null) {
                    return null;
                }
                final TreeItem<T> parent = treeItem.getParent();
                if (parent == null) {
                    return null;
                }
                return treeView.queryAccessibleAttribute(AccessibleAttribute.ROW_AT_INDEX, treeView.getRow(parent));
            }
            case TREE_ITEM_COUNT: {
                if (treeItem == null) {
                    return 0;
                }
                if (!treeItem.isExpanded()) {
                    return 0;
                }
                return treeItem.getChildren().size();
            }
            case TREE_ITEM_AT_INDEX: {
                if (treeItem == null) {
                    return null;
                }
                if (!treeItem.isExpanded()) {
                    return null;
                }
                final int intValue = (int)array[0];
                if (intValue >= treeItem.getChildren().size()) {
                    return null;
                }
                final TreeItem<T> treeItem2 = treeItem.getChildren().get(intValue);
                if (treeItem2 == null) {
                    return null;
                }
                return treeView.queryAccessibleAttribute(AccessibleAttribute.ROW_AT_INDEX, treeView.getRow(treeItem2));
            }
            case LEAF: {
                return treeItem == null || treeItem.isLeaf();
            }
            case EXPANDED: {
                return treeItem != null && treeItem.isExpanded();
            }
            case INDEX: {
                return this.getIndex();
            }
            case SELECTED: {
                return this.isSelected();
            }
            case DISCLOSURE_LEVEL: {
                return (treeView == null) ? 0 : treeView.getTreeItemLevel(treeItem);
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case EXPAND: {
                final TreeItem<T> treeItem = this.getTreeItem();
                if (treeItem != null) {
                    treeItem.setExpanded(true);
                    break;
                }
                break;
            }
            case COLLAPSE: {
                final TreeItem<T> treeItem2 = this.getTreeItem();
                if (treeItem2 != null) {
                    treeItem2.setExpanded(false);
                    break;
                }
                break;
            }
            case REQUEST_FOCUS: {
                final TreeView<T> treeView = this.getTreeView();
                if (treeView != null) {
                    final FocusModel<TreeItem<T>> focusModel = treeView.getFocusModel();
                    if (focusModel != null) {
                        focusModel.focus(this.getIndex());
                    }
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, new Object[0]);
                break;
            }
        }
    }
    
    static {
        EXPANDED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("expanded");
        COLLAPSED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("collapsed");
    }
}
