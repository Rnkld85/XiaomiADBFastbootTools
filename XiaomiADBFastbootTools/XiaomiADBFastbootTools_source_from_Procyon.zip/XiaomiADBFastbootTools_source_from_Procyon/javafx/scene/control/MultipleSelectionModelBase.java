// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.function.Consumer;
import com.sun.javafx.scene.control.ReadOnlyUnbackedObservableList;
import javafx.beans.Observable;
import java.util.stream.IntStream;
import com.sun.javafx.collections.NonIterableChange;
import java.util.Iterator;
import com.sun.javafx.scene.control.MultipleAdditionAndRemovedChange;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.BitSet;
import java.util.Collections;
import java.util.List;
import java.util.Arrays;
import javafx.util.Pair;
import javafx.util.Callback;
import java.util.function.Supplier;
import javafx.collections.ObservableList;
import com.sun.javafx.scene.control.SelectedItemsReadOnlyObservableList;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableListBase;

abstract class MultipleSelectionModelBase<T> extends MultipleSelectionModel<T>
{
    final SelectedIndicesList selectedIndices;
    private final ObservableListBase<T> selectedItems;
    ListChangeListener.Change selectedItemChange;
    
    public MultipleSelectionModelBase() {
        this.selectedIndexProperty().addListener(p0 -> this.setSelectedItem(this.getModelItem(this.getSelectedIndex())));
        this.selectedIndices = new SelectedIndicesList();
        this.selectedItems = new SelectedItemsReadOnlyObservableList<T>(this.selectedIndices, () -> this.getItemCount()) {
            @Override
            protected T getModelItem(final int n) {
                return MultipleSelectionModelBase.this.getModelItem(n);
            }
        };
    }
    
    @Override
    public ObservableList<Integer> getSelectedIndices() {
        return this.selectedIndices;
    }
    
    @Override
    public ObservableList<T> getSelectedItems() {
        return this.selectedItems;
    }
    
    protected abstract int getItemCount();
    
    protected abstract T getModelItem(final int p0);
    
    protected abstract void focus(final int p0);
    
    protected abstract int getFocusedIndex();
    
    void shiftSelection(final int i, final int j, final Callback<ShiftParams, Void> callback) {
        this.shiftSelection(Arrays.asList(new Pair((K)i, (V)j)), callback);
    }
    
    void shiftSelection(final List<Pair<Integer, Integer>> list, final Callback<ShiftParams, Void> callback) {
        if (this.selectedIndices.size() == 0) {
            return;
        }
        final int[] array = new int[this.selectedIndices.bitsetSize()];
        Arrays.fill(array, -1);
        Collections.sort((List<Object>)list, (pair, pair3) -> Integer.compare(pair3.getKey(), pair.getKey()));
        final int intValue = list.get(list.size() - 1).getKey();
        final BitSet set = (BitSet)this.selectedIndices.bitset.clone();
        this.startAtomic();
        final Iterator<Pair<Integer, Integer>> iterator = list.iterator();
        while (iterator.hasNext()) {
            this.doShift(iterator.next(), callback, array);
        }
        this.stopAtomic();
        final boolean b = Arrays.stream(array).filter(n -> n > -1).toArray().length > 0;
        final int selectedIndex = this.getSelectedIndex();
        if (selectedIndex >= intValue && selectedIndex > -1) {
            final int max = Math.max(0, selectedIndex + list.stream().filter(pair4 -> pair4.getKey() <= selectedIndex).mapToInt(pair2 -> pair2.getValue()).sum());
            this.setSelectedIndex(max);
            if (b) {
                this.selectedIndices.set(max, true);
            }
            else {
                this.select(max);
            }
        }
        if (b) {
            final BitSet set2 = (BitSet)set.clone();
            set2.andNot(this.selectedIndices.bitset);
            final BitSet set3 = (BitSet)this.selectedIndices.bitset.clone();
            set3.andNot(set);
            this.selectedIndices.reset();
            this.selectedIndices.callObservers(new MultipleAdditionAndRemovedChange<Integer>((List<Object>)set3.stream().boxed().collect((Collector<? super Integer, ?, List<? super Integer>>)Collectors.toList()), (List<Object>)set2.stream().boxed().collect((Collector<? super Integer, ?, List<? super Integer>>)Collectors.toList()), (ObservableList<Object>)this.selectedIndices));
        }
    }
    
    private void doShift(final Pair<Integer, Integer> pair, final Callback<ShiftParams, Void> callback, final int[] array) {
        final int intValue = pair.getKey();
        final int intValue2 = pair.getValue();
        if (intValue < 0) {
            return;
        }
        if (intValue2 == 0) {
            return;
        }
        int n2 = (int)Arrays.stream(array).filter(n -> n > -1).count();
        final int n3 = this.selectedIndices.bitsetSize() - n2;
        if (intValue2 > 0) {
            for (int n4 = n3 - 1; n4 >= intValue && n4 >= 0; --n4) {
                final boolean selected = this.selectedIndices.isSelected(n4);
                if (callback == null) {
                    this.selectedIndices.clear(n4);
                    this.selectedIndices.set(n4 + intValue2, selected);
                }
                else {
                    callback.call(new ShiftParams(n4, n4 + intValue2, selected));
                }
                if (selected) {
                    array[n2++] = n4 + 1;
                }
            }
            this.selectedIndices.clear(intValue);
        }
        else if (intValue2 < 0) {
            for (int i = intValue; i < n3; ++i) {
                if (i + intValue2 >= 0) {
                    if (i + 1 + intValue2 >= intValue) {
                        final boolean selected2 = this.selectedIndices.isSelected(i + 1);
                        if (callback == null) {
                            this.selectedIndices.clear(i + 1);
                            this.selectedIndices.set(i + 1 + intValue2, selected2);
                        }
                        else {
                            callback.call(new ShiftParams(i + 1, i + 1 + intValue2, selected2));
                        }
                        if (selected2) {
                            array[n2++] = i;
                        }
                    }
                }
            }
        }
    }
    
    void startAtomic() {
        this.selectedIndices.startAtomic();
    }
    
    void stopAtomic() {
        this.selectedIndices.stopAtomic();
    }
    
    boolean isAtomic() {
        return this.selectedIndices.isAtomic();
    }
    
    @Override
    public void clearAndSelect(final int n) {
        if (n < 0 || n >= this.getItemCount()) {
            this.clearSelection();
            return;
        }
        final boolean selected = this.isSelected(n);
        if (selected && this.getSelectedIndices().size() == 1 && this.getSelectedItem() == this.getModelItem(n)) {
            return;
        }
        final BitSet set = new BitSet();
        set.or(this.selectedIndices.bitset);
        set.clear(n);
        final SelectedIndicesList list = new SelectedIndicesList(set);
        this.startAtomic();
        this.clearSelection();
        this.select(n);
        this.stopAtomic();
        ListChangeListener.Change<Integer> buildClearAndSelectChange;
        if (selected) {
            buildClearAndSelectChange = ControlUtils.buildClearAndSelectChange(this.selectedIndices, (List<Integer>)list, n);
        }
        else {
            final int max = Math.max(0, this.selectedIndices.indexOf(n));
            buildClearAndSelectChange = new NonIterableChange.GenericAddRemoveChange<Integer>(max, max + 1, (List<Object>)list, (ObservableList<Object>)this.selectedIndices);
        }
        this.selectedIndices.callObservers(buildClearAndSelectChange);
    }
    
    @Override
    public void select(final int selectedIndex) {
        if (selectedIndex == -1) {
            this.clearSelection();
            return;
        }
        if (selectedIndex < 0 || selectedIndex >= this.getItemCount()) {
            return;
        }
        final boolean b = selectedIndex == this.getSelectedIndex();
        final Object selectedItem = this.getSelectedItem();
        final T modelItem = this.getModelItem(selectedIndex);
        final boolean b2 = modelItem != null && modelItem.equals(selectedItem);
        final boolean b3 = b && !b2;
        this.focus(selectedIndex);
        if (!this.selectedIndices.isSelected(selectedIndex)) {
            if (this.getSelectionMode() == SelectionMode.SINGLE) {
                this.startAtomic();
                this.quietClearSelection();
                this.stopAtomic();
            }
            this.selectedIndices.set(selectedIndex);
        }
        this.setSelectedIndex(selectedIndex);
        if (b3) {
            this.setSelectedItem(modelItem);
        }
    }
    
    @Override
    public void select(final T t) {
        if (t == null && this.getSelectionMode() == SelectionMode.SINGLE) {
            this.clearSelection();
            return;
        }
        for (int i = 0; i < this.getItemCount(); ++i) {
            final T modelItem = this.getModelItem(i);
            if (modelItem != null) {
                if (modelItem.equals(t)) {
                    if (this.isSelected(i)) {
                        return;
                    }
                    if (this.getSelectionMode() == SelectionMode.SINGLE) {
                        this.quietClearSelection();
                    }
                    this.select(i);
                    return;
                }
            }
        }
        this.setSelectedIndex(-1);
        this.setSelectedItem(t);
    }
    
    @Override
    public void selectIndices(final int t, final int... values) {
        if (values == null || values.length == 0) {
            this.select(t);
            return;
        }
        final int itemCount = this.getItemCount();
        if (this.getSelectionMode() == SelectionMode.SINGLE) {
            this.quietClearSelection();
            for (int i = values.length - 1; i >= 0; --i) {
                final int n3 = values[i];
                if (n3 >= 0 && n3 < itemCount) {
                    this.selectedIndices.set(n3);
                    this.select(n3);
                    break;
                }
            }
            if (this.selectedIndices.isEmpty() && t > 0 && t < itemCount) {
                this.selectedIndices.set(t);
                this.select(t);
            }
        }
        else {
            this.selectedIndices.set(t, values);
            final int n4;
            IntStream.concat(IntStream.of(t), IntStream.of(values)).filter(n -> n >= 0 && n < n4).reduce((p0, n2) -> n2).ifPresent(selectedIndex -> {
                this.setSelectedIndex(selectedIndex);
                this.focus(selectedIndex);
                this.setSelectedItem(this.getModelItem(selectedIndex));
            });
        }
    }
    
    @Override
    public void selectAll() {
        if (this.getSelectionMode() == SelectionMode.SINGLE) {
            return;
        }
        if (this.getItemCount() <= 0) {
            return;
        }
        final int itemCount = this.getItemCount();
        final int focusedIndex = this.getFocusedIndex();
        this.clearSelection();
        this.selectedIndices.set(0, itemCount, true);
        if (focusedIndex == -1) {
            this.setSelectedIndex(itemCount - 1);
            this.focus(itemCount - 1);
        }
        else {
            this.setSelectedIndex(focusedIndex);
            this.focus(focusedIndex);
        }
    }
    
    @Override
    public void selectFirst() {
        if (this.getSelectionMode() == SelectionMode.SINGLE) {
            this.quietClearSelection();
        }
        if (this.getItemCount() > 0) {
            this.select(0);
        }
    }
    
    @Override
    public void selectLast() {
        if (this.getSelectionMode() == SelectionMode.SINGLE) {
            this.quietClearSelection();
        }
        final int itemCount = this.getItemCount();
        if (itemCount > 0 && this.getSelectedIndex() < itemCount - 1) {
            this.select(itemCount - 1);
        }
    }
    
    @Override
    public void clearSelection(final int n) {
        if (n < 0) {
            return;
        }
        final boolean empty = this.selectedIndices.isEmpty();
        this.selectedIndices.clear(n);
        if (!empty && this.selectedIndices.isEmpty()) {
            this.clearSelection();
        }
    }
    
    @Override
    public void clearSelection() {
        this.quietClearSelection();
        if (!this.isAtomic()) {
            this.setSelectedIndex(-1);
            this.focus(-1);
        }
    }
    
    private void quietClearSelection() {
        this.selectedIndices.clear();
    }
    
    @Override
    public boolean isSelected(final int n) {
        return n >= 0 && n < this.selectedIndices.bitsetSize() && this.selectedIndices.isSelected(n);
    }
    
    @Override
    public boolean isEmpty() {
        return this.selectedIndices.isEmpty();
    }
    
    @Override
    public void selectPrevious() {
        final int focusedIndex = this.getFocusedIndex();
        if (this.getSelectionMode() == SelectionMode.SINGLE) {
            this.quietClearSelection();
        }
        if (focusedIndex == -1) {
            this.select(this.getItemCount() - 1);
        }
        else if (focusedIndex > 0) {
            this.select(focusedIndex - 1);
        }
    }
    
    @Override
    public void selectNext() {
        final int focusedIndex = this.getFocusedIndex();
        if (this.getSelectionMode() == SelectionMode.SINGLE) {
            this.quietClearSelection();
        }
        if (focusedIndex == -1) {
            this.select(0);
        }
        else if (focusedIndex != this.getItemCount() - 1) {
            this.select(focusedIndex + 1);
        }
    }
    
    static class ShiftParams
    {
        private final int clearIndex;
        private final int setIndex;
        private final boolean selected;
        
        ShiftParams(final int clearIndex, final int setIndex, final boolean selected) {
            this.clearIndex = clearIndex;
            this.setIndex = setIndex;
            this.selected = selected;
        }
        
        public final int getClearIndex() {
            return this.clearIndex;
        }
        
        public final int getSetIndex() {
            return this.setIndex;
        }
        
        public final boolean isSelected() {
            return this.selected;
        }
    }
    
    class SelectedIndicesList extends ReadOnlyUnbackedObservableList<Integer>
    {
        private final BitSet bitset;
        private int lastGetIndex;
        private int lastGetValue;
        private int atomicityCount;
        
        public SelectedIndicesList(final MultipleSelectionModelBase multipleSelectionModelBase) {
            this(multipleSelectionModelBase, new BitSet());
        }
        
        public SelectedIndicesList(final BitSet bitset) {
            this.lastGetIndex = -1;
            this.lastGetValue = -1;
            this.atomicityCount = 0;
            this.bitset = bitset;
        }
        
        boolean isAtomic() {
            return this.atomicityCount > 0;
        }
        
        void startAtomic() {
            ++this.atomicityCount;
        }
        
        void stopAtomic() {
            this.atomicityCount = Math.max(0, this.atomicityCount - 1);
        }
        
        @Override
        public Integer get(final int n) {
            final int size = this.size();
            if (n < 0 || n >= size) {
                throw new IndexOutOfBoundsException(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, n, size));
            }
            if (n == this.lastGetIndex + 1 && this.lastGetValue < size) {
                ++this.lastGetIndex;
                this.lastGetValue = this.bitset.nextSetBit(this.lastGetValue + 1);
                return this.lastGetValue;
            }
            if (n == this.lastGetIndex - 1 && this.lastGetValue > 0) {
                --this.lastGetIndex;
                this.lastGetValue = this.bitset.previousSetBit(this.lastGetValue - 1);
                return this.lastGetValue;
            }
            this.lastGetIndex = 0;
            this.lastGetValue = this.bitset.nextSetBit(0);
            while (this.lastGetValue >= 0 || this.lastGetIndex == n) {
                if (this.lastGetIndex == n) {
                    return this.lastGetValue;
                }
                ++this.lastGetIndex;
                this.lastGetValue = this.bitset.nextSetBit(this.lastGetValue + 1);
            }
            return -1;
        }
        
        public void set(final int n) {
            if (!this.isValidIndex(n) || this.isSelected(n)) {
                return;
            }
            this._beginChange();
            this.bitset.set(n);
            final int index = this.indexOf(n);
            this._nextAdd(index, index + 1);
            this._endChange();
        }
        
        private boolean isValidIndex(final int n) {
            return n >= 0 && n < MultipleSelectionModelBase.this.getItemCount();
        }
        
        public void set(final int n, final boolean b) {
            if (b) {
                this.set(n);
            }
            else {
                this.clear(n);
            }
        }
        
        public void set(final int fromIndex, final int n, final boolean b) {
            this._beginChange();
            if (b) {
                this.bitset.set(fromIndex, n, b);
                final int index = this.indexOf(fromIndex);
                this._nextAdd(index, index + (n - fromIndex));
            }
            else {
                this.bitset.set(fromIndex, n, b);
            }
            this._endChange();
        }
        
        public void set(final int t, final int... values) {
            if (values == null || values.length == 0) {
                this.set(t);
            }
            else {
                this.startAtomic();
                final List<? super Integer> list = IntStream.concat(IntStream.of(t), IntStream.of(values)).distinct().filter(this::isValidIndex).filter(this::isNotSelected).sorted().boxed().peek(this::set).collect((Collector<? super Integer, ?, List<? super Integer>>)Collectors.toList());
                this.stopAtomic();
                final int size = list.size();
                if (size != 0) {
                    if (size == 1) {
                        this._beginChange();
                        final int index = this.indexOf(list.get(0));
                        this._nextAdd(index, index + 1);
                        this._endChange();
                    }
                    else {
                        this._beginChange();
                        int i = 0;
                        final int intValue = list.get(i++);
                        int index2 = this.indexOf(intValue);
                        int n = index2 + 1;
                        int intValue2 = intValue;
                        while (i < size) {
                            final int n2 = intValue2;
                            intValue2 = list.get(i++);
                            ++n;
                            if (n2 != intValue2 - 1) {
                                this._nextAdd(index2, n);
                                index2 = n;
                            }
                            else {
                                if (i != size) {
                                    continue;
                                }
                                this._nextAdd(index2, index2 + i);
                            }
                        }
                        this._endChange();
                    }
                }
            }
        }
        
        @Override
        public void clear() {
            this._beginChange();
            final List<? super Integer> list = this.bitset.stream().boxed().collect((Collector<? super Integer, ?, List<? super Integer>>)Collectors.toList());
            this.bitset.clear();
            this._nextRemove(0, (List<? extends Integer>)list);
            this._endChange();
        }
        
        public void clear(final int i) {
            if (!this.bitset.get(i)) {
                return;
            }
            this._beginChange();
            this.bitset.clear(i);
            this._nextRemove(i, i);
            this._endChange();
        }
        
        public boolean isSelected(final int bitIndex) {
            return this.bitset.get(bitIndex);
        }
        
        public boolean isNotSelected(final int n) {
            return !this.isSelected(n);
        }
        
        @Override
        public int size() {
            return this.bitset.cardinality();
        }
        
        public int bitsetSize() {
            return this.bitset.size();
        }
        
        @Override
        public int indexOf(final Object o) {
            this.reset();
            return super.indexOf(o);
        }
        
        @Override
        public boolean contains(final Object o) {
            if (o instanceof Number) {
                final int intValue = ((Number)o).intValue();
                return intValue >= 0 && intValue < this.bitset.length() && this.bitset.get(intValue);
            }
            return false;
        }
        
        public void reset() {
            this.lastGetIndex = -1;
            this.lastGetValue = -1;
        }
        
        @Override
        public void _beginChange() {
            if (!this.isAtomic()) {
                super._beginChange();
            }
        }
        
        @Override
        public void _endChange() {
            if (!this.isAtomic()) {
                super._endChange();
            }
        }
        
        @Override
        public final void _nextUpdate(final int n) {
            if (!this.isAtomic()) {
                this.nextUpdate(n);
            }
        }
        
        @Override
        public final void _nextSet(final int n, final Integer n2) {
            if (!this.isAtomic()) {
                this.nextSet(n, n2);
            }
        }
        
        @Override
        public final void _nextReplace(final int n, final int n2, final List<? extends Integer> list) {
            if (!this.isAtomic()) {
                this.nextReplace(n, n2, list);
            }
        }
        
        @Override
        public final void _nextRemove(final int n, final List<? extends Integer> list) {
            if (!this.isAtomic()) {
                this.nextRemove(n, list);
            }
        }
        
        @Override
        public final void _nextRemove(final int n, final Integer n2) {
            if (!this.isAtomic()) {
                this.nextRemove(n, n2);
            }
        }
        
        @Override
        public final void _nextPermutation(final int n, final int n2, final int[] array) {
            if (!this.isAtomic()) {
                this.nextPermutation(n, n2, array);
            }
        }
        
        @Override
        public final void _nextAdd(final int n, final int n2) {
            if (!this.isAtomic()) {
                this.nextAdd(n, n2);
            }
        }
    }
}
