// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.skin.SplitMenuButtonSkin;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.scene.AccessibleRole;

public class SplitMenuButton extends MenuButton
{
    private static final String DEFAULT_STYLE_CLASS = "split-menu-button";
    
    public SplitMenuButton() {
        this((MenuItem[])null);
    }
    
    public SplitMenuButton(final MenuItem... array) {
        if (array != null) {
            this.getItems().addAll(array);
        }
        this.getStyleClass().setAll("split-menu-button");
        this.setAccessibleRole(AccessibleRole.SPLIT_MENU_BUTTON);
        this.setMnemonicParsing(true);
    }
    
    @Override
    public void fire() {
        if (!this.isDisabled()) {
            this.fireEvent(new ActionEvent());
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new SplitMenuButtonSkin(this);
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case EXPANDED: {
                return this.isShowing();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case FIRE: {
                this.fire();
                break;
            }
            case EXPAND: {
                this.show();
                break;
            }
            case COLLAPSE: {
                this.hide();
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, new Object[0]);
                break;
            }
        }
    }
}
