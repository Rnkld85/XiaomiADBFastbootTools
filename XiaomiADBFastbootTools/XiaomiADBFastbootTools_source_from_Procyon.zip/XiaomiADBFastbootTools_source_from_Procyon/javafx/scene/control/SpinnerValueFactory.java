// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.time.temporal.TemporalAmount;
import java.time.Duration;
import java.time.format.FormatStyle;
import java.time.format.DateTimeFormatter;
import java.time.LocalTime;
import javafx.beans.property.SimpleLongProperty;
import java.time.chrono.ChronoLocalDate;
import java.time.temporal.ChronoUnit;
import javafx.beans.property.LongProperty;
import java.time.temporal.TemporalUnit;
import java.time.LocalDate;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.DecimalFormat;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.DoubleProperty;
import javafx.util.converter.IntegerStringConverter;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.value.ObservableValue;
import java.lang.ref.WeakReference;
import javafx.beans.NamedArg;
import javafx.collections.ObservableList;
import javafx.collections.WeakListChangeListener;
import javafx.collections.ListChangeListener;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.BooleanProperty;
import javafx.util.StringConverter;
import javafx.beans.property.ObjectProperty;

public abstract class SpinnerValueFactory<T>
{
    private ObjectProperty<T> value;
    private ObjectProperty<StringConverter<T>> converter;
    private BooleanProperty wrapAround;
    
    public SpinnerValueFactory() {
        this.value = new SimpleObjectProperty<T>(this, "value");
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter");
    }
    
    public abstract void decrement(final int p0);
    
    public abstract void increment(final int p0);
    
    public final T getValue() {
        return this.value.get();
    }
    
    public final void setValue(final T t) {
        this.value.set(t);
    }
    
    public final ObjectProperty<T> valueProperty() {
        return this.value;
    }
    
    public final StringConverter<T> getConverter() {
        return this.converter.get();
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converter.set(stringConverter);
    }
    
    public final ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setWrapAround(final boolean b) {
        this.wrapAroundProperty().set(b);
    }
    
    public final boolean isWrapAround() {
        return this.wrapAround != null && this.wrapAround.get();
    }
    
    public final BooleanProperty wrapAroundProperty() {
        if (this.wrapAround == null) {
            this.wrapAround = new SimpleBooleanProperty(this, "wrapAround", false);
        }
        return this.wrapAround;
    }
    
    public static class ListSpinnerValueFactory<T> extends SpinnerValueFactory<T>
    {
        private int currentIndex;
        private final ListChangeListener<T> itemsContentObserver;
        private WeakListChangeListener<T> weakItemsContentObserver;
        private ObjectProperty<ObservableList<T>> items;
        
        public ListSpinnerValueFactory(@NamedArg("items") final ObservableList<T> items) {
            this.currentIndex = 0;
            this.itemsContentObserver = (p0 -> this.updateCurrentIndex());
            this.weakItemsContentObserver = new WeakListChangeListener<T>(this.itemsContentObserver);
            this.setItems(items);
            this.setConverter(new StringConverter<T>() {
                @Override
                public String toString(final T t) {
                    if (t == null) {
                        return "";
                    }
                    return t.toString();
                }
                
                @Override
                public T fromString(final String s) {
                    return (T)s;
                }
            });
            int currentIndex;
            this.valueProperty().addListener((p1, p2, t) -> {
                if (items.contains(t)) {
                    currentIndex = items.indexOf(t);
                }
                else {
                    items.add(t);
                    currentIndex = items.indexOf(t);
                }
                this.currentIndex = currentIndex;
                return;
            });
            this.setValue(this._getValue(this.currentIndex));
        }
        
        public final void setItems(final ObservableList<T> list) {
            this.itemsProperty().set(list);
        }
        
        public final ObservableList<T> getItems() {
            return (this.items == null) ? null : this.items.get();
        }
        
        public final ObjectProperty<ObservableList<T>> itemsProperty() {
            if (this.items == null) {
                this.items = new SimpleObjectProperty<ObservableList<T>>(this, "items") {
                    WeakReference<ObservableList<T>> oldItemsRef;
                    
                    @Override
                    protected void invalidated() {
                        final ObservableList list = (this.oldItemsRef == null) ? null : this.oldItemsRef.get();
                        final ObservableList<T> items = ListSpinnerValueFactory.this.getItems();
                        if (list != null) {
                            list.removeListener(ListSpinnerValueFactory.this.weakItemsContentObserver);
                        }
                        if (items != null) {
                            items.addListener(ListSpinnerValueFactory.this.weakItemsContentObserver);
                        }
                        ListSpinnerValueFactory.this.updateCurrentIndex();
                        this.oldItemsRef = new WeakReference<ObservableList<T>>(ListSpinnerValueFactory.this.getItems());
                    }
                };
            }
            return this.items;
        }
        
        @Override
        public void decrement(final int n) {
            final int n2 = this.getItemsSize() - 1;
            final int n3 = this.currentIndex - n;
            this.currentIndex = ((n3 >= 0) ? n3 : (this.isWrapAround() ? Spinner.wrapValue(n3, 0, n2 + 1) : 0));
            this.setValue(this._getValue(this.currentIndex));
        }
        
        @Override
        public void increment(final int n) {
            final int n2 = this.getItemsSize() - 1;
            final int n3 = this.currentIndex + n;
            this.currentIndex = ((n3 <= n2) ? n3 : (this.isWrapAround() ? Spinner.wrapValue(n3, 0, n2 + 1) : n2));
            this.setValue(this._getValue(this.currentIndex));
        }
        
        private int getItemsSize() {
            final ObservableList<T> items = this.getItems();
            return (items == null) ? 0 : items.size();
        }
        
        private void updateCurrentIndex() {
            final int itemsSize = this.getItemsSize();
            if (this.currentIndex < 0 || this.currentIndex >= itemsSize) {
                this.currentIndex = 0;
            }
            this.setValue(this._getValue(this.currentIndex));
        }
        
        private T _getValue(final int n) {
            final ObservableList<T> items = this.getItems();
            return (T)((items == null) ? null : ((n >= 0 && n < items.size()) ? items.get(n) : null));
        }
    }
    
    public static class IntegerSpinnerValueFactory extends SpinnerValueFactory<Integer>
    {
        private IntegerProperty min;
        private IntegerProperty max;
        private IntegerProperty amountToStepBy;
        
        public IntegerSpinnerValueFactory(@NamedArg("min") final int n, @NamedArg("max") final int n2) {
            this(n, n2, n);
        }
        
        public IntegerSpinnerValueFactory(@NamedArg("min") final int n, @NamedArg("max") final int n2, @NamedArg("initialValue") final int n3) {
            this(n, n2, n3, 1);
        }
        
        public IntegerSpinnerValueFactory(@NamedArg("min") final int min, @NamedArg("max") final int max, @NamedArg("initialValue") final int n2, @NamedArg("amountToStepBy") final int amountToStepBy) {
            this.min = new SimpleIntegerProperty((Object)this, "min") {
                @Override
                protected void invalidated() {
                    final Integer n = IntegerSpinnerValueFactory.this.getValue();
                    if (n == null) {
                        return;
                    }
                    final int value = this.get();
                    if (value > IntegerSpinnerValueFactory.this.getMax()) {
                        IntegerSpinnerValueFactory.this.setMin(IntegerSpinnerValueFactory.this.getMax());
                        return;
                    }
                    if (n < value) {
                        IntegerSpinnerValueFactory.this.setValue(value);
                    }
                }
            };
            this.max = new SimpleIntegerProperty((Object)this, "max") {
                @Override
                protected void invalidated() {
                    final Integer n = IntegerSpinnerValueFactory.this.getValue();
                    if (n == null) {
                        return;
                    }
                    final int value = this.get();
                    if (value < IntegerSpinnerValueFactory.this.getMin()) {
                        IntegerSpinnerValueFactory.this.setMax(IntegerSpinnerValueFactory.this.getMin());
                        return;
                    }
                    if (n > value) {
                        IntegerSpinnerValueFactory.this.setValue(value);
                    }
                }
            };
            this.amountToStepBy = new SimpleIntegerProperty(this, "amountToStepBy");
            this.setMin(min);
            this.setMax(max);
            this.setAmountToStepBy(amountToStepBy);
            this.setConverter(new IntegerStringConverter());
            this.valueProperty().addListener((p0, p1, n) -> {
                if (n < this.getMin()) {
                    this.setValue(this.getMin());
                }
                else if (n > this.getMax()) {
                    this.setValue(this.getMax());
                }
                return;
            });
            this.setValue((n2 >= min && n2 <= max) ? n2 : min);
        }
        
        public final void setMin(final int n) {
            this.min.set(n);
        }
        
        public final int getMin() {
            return this.min.get();
        }
        
        public final IntegerProperty minProperty() {
            return this.min;
        }
        
        public final void setMax(final int n) {
            this.max.set(n);
        }
        
        public final int getMax() {
            return this.max.get();
        }
        
        public final IntegerProperty maxProperty() {
            return this.max;
        }
        
        public final void setAmountToStepBy(final int n) {
            this.amountToStepBy.set(n);
        }
        
        public final int getAmountToStepBy() {
            return this.amountToStepBy.get();
        }
        
        public final IntegerProperty amountToStepByProperty() {
            return this.amountToStepBy;
        }
        
        @Override
        public void decrement(final int n) {
            final int min = this.getMin();
            final int max = this.getMax();
            final int n2 = this.getValue() - n * this.getAmountToStepBy();
            this.setValue((n2 >= min) ? n2 : (this.isWrapAround() ? (Spinner.wrapValue(n2, min, max) + 1) : min));
        }
        
        @Override
        public void increment(final int n) {
            final int min = this.getMin();
            final int max = this.getMax();
            final int n2 = this.getValue() + n * this.getAmountToStepBy();
            this.setValue((n2 <= max) ? n2 : (this.isWrapAround() ? (Spinner.wrapValue(n2, min, max) - 1) : max));
        }
    }
    
    public static class DoubleSpinnerValueFactory extends SpinnerValueFactory<Double>
    {
        private DoubleProperty min;
        private DoubleProperty max;
        private DoubleProperty amountToStepBy;
        
        public DoubleSpinnerValueFactory(@NamedArg("min") final double n, @NamedArg("max") final double n2) {
            this(n, n2, n);
        }
        
        public DoubleSpinnerValueFactory(@NamedArg("min") final double n, @NamedArg("max") final double n2, @NamedArg("initialValue") final double n3) {
            this(n, n2, n3, 1.0);
        }
        
        public DoubleSpinnerValueFactory(@NamedArg("min") final double min, @NamedArg("max") final double max, @NamedArg("initialValue") final double n2, @NamedArg("amountToStepBy") final double amountToStepBy) {
            this.min = new SimpleDoubleProperty((Object)this, "min") {
                @Override
                protected void invalidated() {
                    final Double n = DoubleSpinnerValueFactory.this.getValue();
                    if (n == null) {
                        return;
                    }
                    final double value = this.get();
                    if (value > DoubleSpinnerValueFactory.this.getMax()) {
                        DoubleSpinnerValueFactory.this.setMin(DoubleSpinnerValueFactory.this.getMax());
                        return;
                    }
                    if (n < value) {
                        DoubleSpinnerValueFactory.this.setValue(value);
                    }
                }
            };
            this.max = new SimpleDoubleProperty((Object)this, "max") {
                @Override
                protected void invalidated() {
                    final Double n = DoubleSpinnerValueFactory.this.getValue();
                    if (n == null) {
                        return;
                    }
                    final double value = this.get();
                    if (value < DoubleSpinnerValueFactory.this.getMin()) {
                        DoubleSpinnerValueFactory.this.setMax(DoubleSpinnerValueFactory.this.getMin());
                        return;
                    }
                    if (n > value) {
                        DoubleSpinnerValueFactory.this.setValue(value);
                    }
                }
            };
            this.amountToStepBy = new SimpleDoubleProperty(this, "amountToStepBy");
            this.setMin(min);
            this.setMax(max);
            this.setAmountToStepBy(amountToStepBy);
            this.setConverter(new StringConverter<Double>() {
                private final DecimalFormat df = new DecimalFormat("#.##");
                
                @Override
                public String toString(final Double obj) {
                    if (obj == null) {
                        return "";
                    }
                    return this.df.format(obj);
                }
                
                @Override
                public Double fromString(String trim) {
                    try {
                        if (trim == null) {
                            return null;
                        }
                        trim = trim.trim();
                        if (trim.length() < 1) {
                            return null;
                        }
                        return this.df.parse(trim).doubleValue();
                    }
                    catch (ParseException cause) {
                        throw new RuntimeException(cause);
                    }
                }
            });
            this.valueProperty().addListener((p0, p1, n) -> {
                if (n == null) {
                    return;
                }
                else {
                    if (n < this.getMin()) {
                        this.setValue(this.getMin());
                    }
                    else if (n > this.getMax()) {
                        this.setValue(this.getMax());
                    }
                    return;
                }
            });
            this.setValue((n2 >= min && n2 <= max) ? n2 : min);
        }
        
        public final void setMin(final double n) {
            this.min.set(n);
        }
        
        public final double getMin() {
            return this.min.get();
        }
        
        public final DoubleProperty minProperty() {
            return this.min;
        }
        
        public final void setMax(final double n) {
            this.max.set(n);
        }
        
        public final double getMax() {
            return this.max.get();
        }
        
        public final DoubleProperty maxProperty() {
            return this.max;
        }
        
        public final void setAmountToStepBy(final double n) {
            this.amountToStepBy.set(n);
        }
        
        public final double getAmountToStepBy() {
            return this.amountToStepBy.get();
        }
        
        public final DoubleProperty amountToStepByProperty() {
            return this.amountToStepBy;
        }
        
        @Override
        public void decrement(final int n) {
            final BigDecimal value = BigDecimal.valueOf(this.getValue());
            final BigDecimal value2 = BigDecimal.valueOf(this.getMin());
            final BigDecimal value3 = BigDecimal.valueOf(this.getMax());
            final BigDecimal subtract = value.subtract(BigDecimal.valueOf(this.getAmountToStepBy()).multiply(BigDecimal.valueOf(n)));
            this.setValue((subtract.compareTo(value2) >= 0) ? subtract.doubleValue() : (this.isWrapAround() ? Spinner.wrapValue(subtract, value2, value3).doubleValue() : this.getMin()));
        }
        
        @Override
        public void increment(final int n) {
            final BigDecimal value = BigDecimal.valueOf(this.getValue());
            final BigDecimal value2 = BigDecimal.valueOf(this.getMin());
            final BigDecimal value3 = BigDecimal.valueOf(this.getMax());
            final BigDecimal add = value.add(BigDecimal.valueOf(this.getAmountToStepBy()).multiply(BigDecimal.valueOf(n)));
            this.setValue((add.compareTo(value3) <= 0) ? add.doubleValue() : (this.isWrapAround() ? Spinner.wrapValue(add, value2, value3).doubleValue() : this.getMax()));
        }
    }
    
    static class LocalDateSpinnerValueFactory extends SpinnerValueFactory<LocalDate>
    {
        private ObjectProperty<LocalDate> min;
        private ObjectProperty<LocalDate> max;
        private ObjectProperty<TemporalUnit> temporalUnit;
        private LongProperty amountToStepBy;
        
        public LocalDateSpinnerValueFactory() {
            this(LocalDate.now());
        }
        
        public LocalDateSpinnerValueFactory(@NamedArg("initialValue") final LocalDate localDate) {
            this(LocalDate.MIN, LocalDate.MAX, localDate);
        }
        
        public LocalDateSpinnerValueFactory(@NamedArg("min") final LocalDate localDate, @NamedArg("min") final LocalDate localDate2, @NamedArg("initialValue") final LocalDate localDate3) {
            this(localDate, localDate2, localDate3, 1L, ChronoUnit.DAYS);
        }
        
        public LocalDateSpinnerValueFactory(@NamedArg("min") final LocalDate min, @NamedArg("min") final LocalDate max, @NamedArg("initialValue") final LocalDate localDate2, @NamedArg("amountToStepBy") final long amountToStepBy, @NamedArg("temporalUnit") final TemporalUnit temporalUnit) {
            this.min = new SimpleObjectProperty<LocalDate>((Object)this, "min") {
                @Override
                protected void invalidated() {
                    final LocalDate localDate = LocalDateSpinnerValueFactory.this.getValue();
                    if (localDate == null) {
                        return;
                    }
                    final LocalDate localDate2 = this.get();
                    if (localDate2.isAfter(LocalDateSpinnerValueFactory.this.getMax())) {
                        LocalDateSpinnerValueFactory.this.setMin(LocalDateSpinnerValueFactory.this.getMax());
                        return;
                    }
                    if (localDate.isBefore(localDate2)) {
                        LocalDateSpinnerValueFactory.this.setValue(localDate2);
                    }
                }
            };
            this.max = new SimpleObjectProperty<LocalDate>((Object)this, "max") {
                @Override
                protected void invalidated() {
                    final LocalDate localDate = LocalDateSpinnerValueFactory.this.getValue();
                    if (localDate == null) {
                        return;
                    }
                    final LocalDate localDate2 = this.get();
                    if (localDate2.isBefore(LocalDateSpinnerValueFactory.this.getMin())) {
                        LocalDateSpinnerValueFactory.this.setMax(LocalDateSpinnerValueFactory.this.getMin());
                        return;
                    }
                    if (localDate.isAfter(localDate2)) {
                        LocalDateSpinnerValueFactory.this.setValue(localDate2);
                    }
                }
            };
            this.temporalUnit = new SimpleObjectProperty<TemporalUnit>(this, "temporalUnit");
            this.amountToStepBy = new SimpleLongProperty(this, "amountToStepBy");
            this.setMin(min);
            this.setMax(max);
            this.setAmountToStepBy(amountToStepBy);
            this.setTemporalUnit(temporalUnit);
            this.setConverter(new StringConverter<LocalDate>() {
                @Override
                public String toString(final LocalDate localDate) {
                    if (localDate == null) {
                        return "";
                    }
                    return localDate.toString();
                }
                
                @Override
                public LocalDate fromString(final String text) {
                    return LocalDate.parse(text);
                }
            });
            this.valueProperty().addListener((p0, p1, localDate) -> {
                if (this.getMin() != null && localDate.isBefore(this.getMin())) {
                    this.setValue(this.getMin());
                }
                else if (this.getMax() != null && localDate.isAfter(this.getMax())) {
                    this.setValue(this.getMax());
                }
                return;
            });
            this.setValue((localDate2 != null) ? localDate2 : LocalDate.now());
        }
        
        public final void setMin(final LocalDate localDate) {
            this.min.set(localDate);
        }
        
        public final LocalDate getMin() {
            return this.min.get();
        }
        
        public final ObjectProperty<LocalDate> minProperty() {
            return this.min;
        }
        
        public final void setMax(final LocalDate localDate) {
            this.max.set(localDate);
        }
        
        public final LocalDate getMax() {
            return this.max.get();
        }
        
        public final ObjectProperty<LocalDate> maxProperty() {
            return this.max;
        }
        
        public final void setTemporalUnit(final TemporalUnit temporalUnit) {
            this.temporalUnit.set(temporalUnit);
        }
        
        public final TemporalUnit getTemporalUnit() {
            return this.temporalUnit.get();
        }
        
        public final ObjectProperty<TemporalUnit> temporalUnitProperty() {
            return this.temporalUnit;
        }
        
        public final void setAmountToStepBy(final long n) {
            this.amountToStepBy.set(n);
        }
        
        public final long getAmountToStepBy() {
            return this.amountToStepBy.get();
        }
        
        public final LongProperty amountToStepByProperty() {
            return this.amountToStepBy;
        }
        
        @Override
        public void decrement(final int n) {
            final LocalDate localDate = this.getValue();
            final LocalDate min = this.getMin();
            LocalDate value = localDate.minus(this.getAmountToStepBy() * n, this.getTemporalUnit());
            if (min != null && this.isWrapAround() && value.isBefore(min)) {
                value = this.getMax();
            }
            this.setValue(value);
        }
        
        @Override
        public void increment(final int n) {
            final LocalDate localDate = this.getValue();
            final LocalDate max = this.getMax();
            LocalDate value = localDate.plus(this.getAmountToStepBy() * n, this.getTemporalUnit());
            if (max != null && this.isWrapAround() && value.isAfter(max)) {
                value = this.getMin();
            }
            this.setValue(value);
        }
    }
    
    static class LocalTimeSpinnerValueFactory extends SpinnerValueFactory<LocalTime>
    {
        private ObjectProperty<LocalTime> min;
        private ObjectProperty<LocalTime> max;
        private ObjectProperty<TemporalUnit> temporalUnit;
        private LongProperty amountToStepBy;
        
        public LocalTimeSpinnerValueFactory() {
            this(LocalTime.now());
        }
        
        public LocalTimeSpinnerValueFactory(@NamedArg("initialValue") final LocalTime localTime) {
            this(LocalTime.MIN, LocalTime.MAX, localTime);
        }
        
        public LocalTimeSpinnerValueFactory(@NamedArg("min") final LocalTime localTime, @NamedArg("min") final LocalTime localTime2, @NamedArg("initialValue") final LocalTime localTime3) {
            this(localTime, localTime2, localTime3, 1L, ChronoUnit.HOURS);
        }
        
        public LocalTimeSpinnerValueFactory(@NamedArg("min") final LocalTime min, @NamedArg("min") final LocalTime max, @NamedArg("initialValue") final LocalTime localTime2, @NamedArg("amountToStepBy") final long amountToStepBy, @NamedArg("temporalUnit") final TemporalUnit temporalUnit) {
            this.min = new SimpleObjectProperty<LocalTime>((Object)this, "min") {
                @Override
                protected void invalidated() {
                    final LocalTime localTime = LocalTimeSpinnerValueFactory.this.getValue();
                    if (localTime == null) {
                        return;
                    }
                    final LocalTime localTime2 = this.get();
                    if (localTime2.isAfter(LocalTimeSpinnerValueFactory.this.getMax())) {
                        LocalTimeSpinnerValueFactory.this.setMin(LocalTimeSpinnerValueFactory.this.getMax());
                        return;
                    }
                    if (localTime.isBefore(localTime2)) {
                        LocalTimeSpinnerValueFactory.this.setValue(localTime2);
                    }
                }
            };
            this.max = new SimpleObjectProperty<LocalTime>((Object)this, "max") {
                @Override
                protected void invalidated() {
                    final LocalTime localTime = LocalTimeSpinnerValueFactory.this.getValue();
                    if (localTime == null) {
                        return;
                    }
                    final LocalTime localTime2 = this.get();
                    if (localTime2.isBefore(LocalTimeSpinnerValueFactory.this.getMin())) {
                        LocalTimeSpinnerValueFactory.this.setMax(LocalTimeSpinnerValueFactory.this.getMin());
                        return;
                    }
                    if (localTime.isAfter(localTime2)) {
                        LocalTimeSpinnerValueFactory.this.setValue(localTime2);
                    }
                }
            };
            this.temporalUnit = new SimpleObjectProperty<TemporalUnit>(this, "temporalUnit");
            this.amountToStepBy = new SimpleLongProperty(this, "amountToStepBy");
            this.setMin(min);
            this.setMax(max);
            this.setAmountToStepBy(amountToStepBy);
            this.setTemporalUnit(temporalUnit);
            this.setConverter(new StringConverter<LocalTime>() {
                private DateTimeFormatter dtf = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT);
                
                @Override
                public String toString(final LocalTime localTime) {
                    if (localTime == null) {
                        return "";
                    }
                    return localTime.format(this.dtf);
                }
                
                @Override
                public LocalTime fromString(final String text) {
                    return LocalTime.parse(text);
                }
            });
            this.valueProperty().addListener((p0, p1, localTime) -> {
                if (this.getMin() != null && localTime.isBefore(this.getMin())) {
                    this.setValue(this.getMin());
                }
                else if (this.getMax() != null && localTime.isAfter(this.getMax())) {
                    this.setValue(this.getMax());
                }
                return;
            });
            this.setValue((localTime2 != null) ? localTime2 : LocalTime.now());
        }
        
        public final void setMin(final LocalTime localTime) {
            this.min.set(localTime);
        }
        
        public final LocalTime getMin() {
            return this.min.get();
        }
        
        public final ObjectProperty<LocalTime> minProperty() {
            return this.min;
        }
        
        public final void setMax(final LocalTime localTime) {
            this.max.set(localTime);
        }
        
        public final LocalTime getMax() {
            return this.max.get();
        }
        
        public final ObjectProperty<LocalTime> maxProperty() {
            return this.max;
        }
        
        public final void setTemporalUnit(final TemporalUnit temporalUnit) {
            this.temporalUnit.set(temporalUnit);
        }
        
        public final TemporalUnit getTemporalUnit() {
            return this.temporalUnit.get();
        }
        
        public final ObjectProperty<TemporalUnit> temporalUnitProperty() {
            return this.temporalUnit;
        }
        
        public final void setAmountToStepBy(final long n) {
            this.amountToStepBy.set(n);
        }
        
        public final long getAmountToStepBy() {
            return this.amountToStepBy.get();
        }
        
        public final LongProperty amountToStepByProperty() {
            return this.amountToStepBy;
        }
        
        @Override
        public void decrement(final int n) {
            final LocalTime localTime = this.getValue();
            final LocalTime min = this.getMin();
            final Duration of = Duration.of(this.getAmountToStepBy() * n, this.getTemporalUnit());
            final long n2 = of.toMinutes() * 60L;
            final long n3 = localTime.toSecondOfDay();
            if (!this.isWrapAround() && n2 > n3) {
                this.setValue((min == null) ? LocalTime.MIN : min);
            }
            else {
                this.setValue(localTime.minus((TemporalAmount)of));
            }
        }
        
        @Override
        public void increment(final int n) {
            final LocalTime localTime = this.getValue();
            final LocalTime max = this.getMax();
            final Duration of = Duration.of(this.getAmountToStepBy() * n, this.getTemporalUnit());
            final long n2 = of.toMinutes() * 60L;
            final long n3 = localTime.toSecondOfDay();
            if (!this.isWrapAround() && n2 > LocalTime.MAX.toSecondOfDay() - n3) {
                this.setValue((max == null) ? LocalTime.MAX : max);
            }
            else {
                this.setValue(localTime.plus((TemporalAmount)of));
            }
        }
    }
}
