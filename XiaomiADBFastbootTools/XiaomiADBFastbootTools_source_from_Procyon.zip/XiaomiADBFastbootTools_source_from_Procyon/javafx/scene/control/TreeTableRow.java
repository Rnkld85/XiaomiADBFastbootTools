// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ObjectPropertyBase;
import javafx.scene.AccessibleAction;
import javafx.scene.control.skin.TreeTableRowSkin;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.AccessibleRole;
import java.lang.ref.WeakReference;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.AccessibleAttribute;
import javafx.beans.property.BooleanProperty;
import javafx.beans.Observable;
import javafx.css.PseudoClass;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.WeakInvalidationListener;
import javafx.collections.WeakListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;

public class TreeTableRow<T> extends IndexedCell<T>
{
    private final ListChangeListener<Integer> selectedListener;
    private final InvalidationListener focusedListener;
    private final InvalidationListener editingListener;
    private final InvalidationListener leafListener;
    private boolean oldExpanded;
    private final InvalidationListener treeItemExpandedInvalidationListener;
    private final WeakListChangeListener<Integer> weakSelectedListener;
    private final WeakInvalidationListener weakFocusedListener;
    private final WeakInvalidationListener weakEditingListener;
    private final WeakInvalidationListener weakLeafListener;
    private final WeakInvalidationListener weakTreeItemExpandedInvalidationListener;
    private ReadOnlyObjectWrapper<TreeItem<T>> treeItem;
    private ObjectProperty<Node> disclosureNode;
    private ReadOnlyObjectWrapper<TreeTableView<T>> treeTableView;
    private int index;
    private boolean isFirstRun;
    private static final String DEFAULT_STYLE_CLASS = "tree-table-row-cell";
    private static final PseudoClass EXPANDED_PSEUDOCLASS_STATE;
    private static final PseudoClass COLLAPSED_PSEUDOCLASS_STATE;
    
    public TreeTableRow() {
        this.selectedListener = (p0 -> this.updateSelection());
        this.focusedListener = (p0 -> this.updateFocus());
        this.editingListener = (p0 -> this.updateEditing());
        this.leafListener = new InvalidationListener() {
            @Override
            public void invalidated(final Observable observable) {
                if (TreeTableRow.this.getTreeItem() != null) {
                    TreeTableRow.this.requestLayout();
                }
            }
        };
        final boolean oldExpanded;
        this.treeItemExpandedInvalidationListener = (booleanProperty -> {
            booleanProperty.get();
            this.pseudoClassStateChanged(TreeTableRow.EXPANDED_PSEUDOCLASS_STATE, oldExpanded);
            this.pseudoClassStateChanged(TreeTableRow.COLLAPSED_PSEUDOCLASS_STATE, !oldExpanded);
            if (oldExpanded != this.oldExpanded) {
                this.notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED);
            }
            this.oldExpanded = oldExpanded;
            return;
        });
        this.weakSelectedListener = new WeakListChangeListener<Integer>(this.selectedListener);
        this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
        this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
        this.weakLeafListener = new WeakInvalidationListener(this.leafListener);
        this.weakTreeItemExpandedInvalidationListener = new WeakInvalidationListener(this.treeItemExpandedInvalidationListener);
        this.treeItem = new ReadOnlyObjectWrapper<TreeItem<T>>((Object)this, "treeItem") {
            TreeItem<T> oldValue = null;
            
            @Override
            protected void invalidated() {
                if (this.oldValue != null) {
                    this.oldValue.expandedProperty().removeListener(TreeTableRow.this.weakTreeItemExpandedInvalidationListener);
                }
                this.oldValue = this.get();
                if (this.oldValue != null) {
                    TreeTableRow.this.oldExpanded = this.oldValue.isExpanded();
                    this.oldValue.expandedProperty().addListener(TreeTableRow.this.weakTreeItemExpandedInvalidationListener);
                    TreeTableRow.this.weakTreeItemExpandedInvalidationListener.invalidated(this.oldValue.expandedProperty());
                }
            }
        };
        this.disclosureNode = new SimpleObjectProperty<Node>(this, "disclosureNode");
        this.treeTableView = new ReadOnlyObjectWrapper<TreeTableView<T>>((Object)this, "treeTableView") {
            private WeakReference<TreeTableView<T>> weakTreeTableViewRef;
            
            @Override
            protected void invalidated() {
                if (this.weakTreeTableViewRef != null) {
                    final TreeTableView treeTableView = this.weakTreeTableViewRef.get();
                    if (treeTableView != null) {
                        final TreeTableView.TreeTableViewSelectionModel selectionModel = treeTableView.getSelectionModel();
                        if (selectionModel != null) {
                            selectionModel.getSelectedIndices().removeListener(TreeTableRow.this.weakSelectedListener);
                        }
                        final TreeTableView.TreeTableViewFocusModel focusModel = treeTableView.getFocusModel();
                        if (focusModel != null) {
                            focusModel.focusedIndexProperty().removeListener(TreeTableRow.this.weakFocusedListener);
                        }
                        treeTableView.editingCellProperty().removeListener(TreeTableRow.this.weakEditingListener);
                    }
                    this.weakTreeTableViewRef = null;
                }
                if (this.get() != null) {
                    final TreeTableView.TreeTableViewSelectionModel selectionModel2 = ((ObjectPropertyBase<TreeTableView>)this).get().getSelectionModel();
                    if (selectionModel2 != null) {
                        selectionModel2.getSelectedIndices().addListener(TreeTableRow.this.weakSelectedListener);
                    }
                    final TreeTableView.TreeTableViewFocusModel focusModel2 = ((ObjectPropertyBase<TreeTableView>)this).get().getFocusModel();
                    if (focusModel2 != null) {
                        focusModel2.focusedIndexProperty().addListener(TreeTableRow.this.weakFocusedListener);
                    }
                    ((ObjectPropertyBase<TreeTableView>)this).get().editingCellProperty().addListener(TreeTableRow.this.weakEditingListener);
                    this.weakTreeTableViewRef = new WeakReference<TreeTableView<T>>((TreeTableView<T>)((ObjectPropertyBase<TreeTableView<?>>)this).get());
                }
                TreeTableRow.this.updateItem();
                TreeTableRow.this.requestLayout();
            }
        };
        this.index = -1;
        this.isFirstRun = true;
        this.getStyleClass().addAll("tree-table-row-cell");
        this.setAccessibleRole(AccessibleRole.TREE_TABLE_ROW);
    }
    
    private void setTreeItem(final TreeItem<T> treeItem) {
        this.treeItem.set(treeItem);
    }
    
    public final TreeItem<T> getTreeItem() {
        return this.treeItem.get();
    }
    
    public final ReadOnlyObjectProperty<TreeItem<T>> treeItemProperty() {
        return this.treeItem.getReadOnlyProperty();
    }
    
    public final void setDisclosureNode(final Node node) {
        this.disclosureNodeProperty().set(node);
    }
    
    public final Node getDisclosureNode() {
        return this.disclosureNode.get();
    }
    
    public final ObjectProperty<Node> disclosureNodeProperty() {
        return this.disclosureNode;
    }
    
    private void setTreeTableView(final TreeTableView<T> treeTableView) {
        this.treeTableView.set(treeTableView);
    }
    
    public final TreeTableView<T> getTreeTableView() {
        return this.treeTableView.get();
    }
    
    public final ReadOnlyObjectProperty<TreeTableView<T>> treeTableViewProperty() {
        return this.treeTableView.getReadOnlyProperty();
    }
    
    @Override
    void indexChanged(final int n, final int n2) {
        this.index = this.getIndex();
        this.updateItem();
        this.updateSelection();
        this.updateFocus();
    }
    
    @Override
    public void startEdit() {
        final TreeTableView<?> treeTableView = this.getTreeTableView();
        if (!this.isEditable() || (treeTableView != null && !treeTableView.isEditable())) {
            return;
        }
        super.startEdit();
        if (treeTableView != null) {
            treeTableView.fireEvent(new TreeTableView.EditEvent<Object>((TreeTableView<Object>)treeTableView, TreeTableView.editStartEvent(), this.getTreeItem(), this.getItem(), null));
            treeTableView.requestFocus();
        }
    }
    
    @Override
    public void commitEdit(final T value) {
        if (!this.isEditing()) {
            return;
        }
        final TreeItem<T> treeItem = (TreeItem<T>)this.getTreeItem();
        final TreeTableView<Object> treeTableView = this.getTreeTableView();
        if (treeTableView != null) {
            treeTableView.fireEvent(new TreeTableView.EditEvent<Object>(treeTableView, TreeTableView.editCommitEvent(), (TreeItem<Object>)treeItem, this.getItem(), value));
        }
        if (treeItem != null) {
            treeItem.setValue((Object)value);
            this.updateTreeItem(treeItem);
            this.updateItem(value, false);
        }
        super.commitEdit(value);
        if (treeTableView != null) {
            treeTableView.edit(-1, (TreeTableColumn<?, ?>)null);
            treeTableView.requestFocus();
        }
    }
    
    @Override
    public void cancelEdit() {
        if (!this.isEditing()) {
            return;
        }
        final TreeTableView<?> treeTableView = this.getTreeTableView();
        if (treeTableView != null) {
            treeTableView.fireEvent(new TreeTableView.EditEvent<Object>((TreeTableView<Object>)treeTableView, TreeTableView.editCancelEvent(), this.getTreeItem(), this.getItem(), null));
        }
        super.cancelEdit();
        if (treeTableView != null) {
            treeTableView.edit(-1, null);
            treeTableView.requestFocus();
        }
    }
    
    private void updateItem() {
        final TreeTableView<T> treeTableView = this.getTreeTableView();
        if (treeTableView == null) {
            return;
        }
        final boolean b = this.index >= 0 && this.index < treeTableView.getExpandedItemCount();
        final TreeItem<T> treeItem = this.getTreeItem();
        final boolean empty = this.isEmpty();
        if (b) {
            final TreeItem<T> treeItem2 = treeTableView.getTreeItem(this.index);
            final T t = (treeItem2 == null) ? null : treeItem2.getValue();
            this.updateTreeItem(treeItem2);
            this.updateItem(t, false);
        }
        else if ((!empty && treeItem != null) || this.isFirstRun) {
            this.updateTreeItem(null);
            this.updateItem(null, true);
            this.isFirstRun = false;
        }
    }
    
    private void updateSelection() {
        if (this.isEmpty()) {
            return;
        }
        if (this.index == -1 || this.getTreeTableView() == null) {
            return;
        }
        if (this.getTreeTableView().getSelectionModel() == null) {
            return;
        }
        final boolean selected = this.getTreeTableView().getSelectionModel().isSelected(this.index);
        if (this.isSelected() == selected) {
            return;
        }
        this.updateSelected(selected);
    }
    
    private void updateFocus() {
        if (this.getIndex() == -1 || this.getTreeTableView() == null) {
            return;
        }
        if (this.getTreeTableView().getFocusModel() == null) {
            return;
        }
        this.setFocused(this.getTreeTableView().getFocusModel().isFocused(this.getIndex()));
    }
    
    private void updateEditing() {
        if (this.getIndex() == -1 || this.getTreeTableView() == null || this.getTreeItem() == null) {
            return;
        }
        final TreeTablePosition<T, ?> editingCell = this.getTreeTableView().getEditingCell();
        if (editingCell != null && editingCell.getTableColumn() != null) {
            return;
        }
        final TreeItem<T> treeItem = (editingCell == null) ? null : editingCell.getTreeItem();
        if (!this.isEditing() && this.getTreeItem().equals(treeItem)) {
            this.startEdit();
        }
        else if (this.isEditing() && !this.getTreeItem().equals(treeItem)) {
            this.cancelEdit();
        }
    }
    
    public final void updateTreeTableView(final TreeTableView<T> treeTableView) {
        this.setTreeTableView(treeTableView);
    }
    
    public final void updateTreeItem(final TreeItem<T> treeItem) {
        final TreeItem<T> treeItem2 = this.getTreeItem();
        if (treeItem2 != null) {
            treeItem2.leafProperty().removeListener(this.weakLeafListener);
        }
        this.setTreeItem(treeItem);
        if (treeItem != null) {
            treeItem.leafProperty().addListener(this.weakLeafListener);
        }
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TreeTableRowSkin<Object>(this);
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        final TreeItem<T> treeItem = this.getTreeItem();
        final TreeTableView<T> treeTableView = this.getTreeTableView();
        switch (accessibleAttribute) {
            case TREE_ITEM_PARENT: {
                if (treeItem == null) {
                    return null;
                }
                final TreeItem<T> parent = treeItem.getParent();
                if (parent == null) {
                    return null;
                }
                return treeTableView.queryAccessibleAttribute(AccessibleAttribute.ROW_AT_INDEX, treeTableView.getRow(parent));
            }
            case TREE_ITEM_COUNT: {
                if (treeItem == null) {
                    return 0;
                }
                if (!treeItem.isExpanded()) {
                    return 0;
                }
                return treeItem.getChildren().size();
            }
            case TREE_ITEM_AT_INDEX: {
                if (treeItem == null) {
                    return null;
                }
                if (!treeItem.isExpanded()) {
                    return null;
                }
                final int intValue = (int)array[0];
                if (intValue >= treeItem.getChildren().size()) {
                    return null;
                }
                final TreeItem<T> treeItem2 = treeItem.getChildren().get(intValue);
                if (treeItem2 == null) {
                    return null;
                }
                return treeTableView.queryAccessibleAttribute(AccessibleAttribute.ROW_AT_INDEX, treeTableView.getRow(treeItem2));
            }
            case LEAF: {
                return treeItem == null || treeItem.isLeaf();
            }
            case EXPANDED: {
                return treeItem != null && treeItem.isExpanded();
            }
            case INDEX: {
                return this.getIndex();
            }
            case DISCLOSURE_LEVEL: {
                return (treeTableView == null) ? 0 : treeTableView.getTreeItemLevel(treeItem);
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case EXPAND: {
                final TreeItem<T> treeItem = this.getTreeItem();
                if (treeItem != null) {
                    treeItem.setExpanded(true);
                    break;
                }
                break;
            }
            case COLLAPSE: {
                final TreeItem<T> treeItem2 = this.getTreeItem();
                if (treeItem2 != null) {
                    treeItem2.setExpanded(false);
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, new Object[0]);
                break;
            }
        }
    }
    
    static {
        EXPANDED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("expanded");
        COLLAPSED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("collapsed");
    }
}
