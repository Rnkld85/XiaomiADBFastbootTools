// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.Observable;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.scene.control.skin.TableCellSkin;
import javafx.event.EventTarget;
import javafx.event.Event;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.scene.AccessibleRole;
import java.util.Collection;
import javafx.css.PseudoClass;
import java.lang.ref.WeakReference;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.WeakInvalidationListener;
import javafx.collections.WeakListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;

public class TableCell<S, T> extends IndexedCell<T>
{
    boolean lockItemOnEdit;
    private boolean itemDirty;
    private ListChangeListener<TablePosition> selectedListener;
    private final InvalidationListener focusedListener;
    private final InvalidationListener tableRowUpdateObserver;
    private final InvalidationListener editingListener;
    private ListChangeListener<TableColumn<S, ?>> visibleLeafColumnsListener;
    private ListChangeListener<String> columnStyleClassListener;
    private final InvalidationListener columnStyleListener;
    private final InvalidationListener columnIdListener;
    private final WeakListChangeListener<TablePosition> weakSelectedListener;
    private final WeakInvalidationListener weakFocusedListener;
    private final WeakInvalidationListener weaktableRowUpdateObserver;
    private final WeakInvalidationListener weakEditingListener;
    private final WeakInvalidationListener weakColumnStyleListener;
    private final WeakInvalidationListener weakColumnIdListener;
    private final WeakListChangeListener<TableColumn<S, ?>> weakVisibleLeafColumnsListener;
    private final WeakListChangeListener<String> weakColumnStyleClassListener;
    private ReadOnlyObjectWrapper<TableColumn<S, T>> tableColumn;
    private ReadOnlyObjectWrapper<TableView<S>> tableView;
    private ReadOnlyObjectWrapper<TableRow<S>> tableRow;
    private boolean isLastVisibleColumn;
    private int columnIndex;
    private boolean updateEditingIndex;
    private ObservableValue<T> currentObservableValue;
    private boolean isFirstRun;
    private WeakReference<S> oldRowItemRef;
    private static final String DEFAULT_STYLE_CLASS = "table-cell";
    private static final PseudoClass PSEUDO_CLASS_LAST_VISIBLE;
    
    public TableCell() {
        this.lockItemOnEdit = false;
        this.itemDirty = false;
        this.selectedListener = (change -> {
            while (change.next()) {
                if (change.wasAdded() || change.wasRemoved()) {
                    this.updateSelection();
                }
            }
            return;
        });
        this.focusedListener = (p0 -> this.updateFocus());
        this.tableRowUpdateObserver = (p0 -> {
            this.itemDirty = true;
            this.requestLayout();
            return;
        });
        this.editingListener = (p0 -> this.updateEditing());
        this.visibleLeafColumnsListener = (p0 -> this.updateColumnIndex());
        this.columnStyleClassListener = (change2 -> {
            while (change2.next()) {
                if (change2.wasRemoved()) {
                    this.getStyleClass().removeAll(change2.getRemoved());
                }
                if (change2.wasAdded()) {
                    this.getStyleClass().addAll((Collection<?>)change2.getAddedSubList());
                }
            }
            return;
        });
        this.columnStyleListener = (p0 -> {
            if (this.getTableColumn() != null) {
                this.possiblySetStyle(this.getTableColumn().getStyle());
            }
            return;
        });
        this.columnIdListener = (p0 -> {
            if (this.getTableColumn() != null) {
                this.possiblySetId(this.getTableColumn().getId());
            }
            return;
        });
        this.weakSelectedListener = new WeakListChangeListener<TablePosition>(this.selectedListener);
        this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
        this.weaktableRowUpdateObserver = new WeakInvalidationListener(this.tableRowUpdateObserver);
        this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
        this.weakColumnStyleListener = new WeakInvalidationListener(this.columnStyleListener);
        this.weakColumnIdListener = new WeakInvalidationListener(this.columnIdListener);
        this.weakVisibleLeafColumnsListener = new WeakListChangeListener<TableColumn<S, ?>>(this.visibleLeafColumnsListener);
        this.weakColumnStyleClassListener = new WeakListChangeListener<String>(this.columnStyleClassListener);
        this.tableColumn = new ReadOnlyObjectWrapper<TableColumn<S, T>>() {
            @Override
            protected void invalidated() {
                TableCell.this.updateColumnIndex();
            }
            
            @Override
            public Object getBean() {
                return TableCell.this;
            }
            
            @Override
            public String getName() {
                return "tableColumn";
            }
        };
        this.tableRow = new ReadOnlyObjectWrapper<TableRow<S>>(this, "tableRow");
        this.isLastVisibleColumn = false;
        this.columnIndex = -1;
        this.updateEditingIndex = true;
        this.currentObservableValue = null;
        this.isFirstRun = true;
        this.getStyleClass().addAll("table-cell");
        this.setAccessibleRole(AccessibleRole.TABLE_CELL);
        this.updateColumnIndex();
    }
    
    public final ReadOnlyObjectProperty<TableColumn<S, T>> tableColumnProperty() {
        return this.tableColumn.getReadOnlyProperty();
    }
    
    private void setTableColumn(final TableColumn<S, T> tableColumn) {
        this.tableColumn.set(tableColumn);
    }
    
    public final TableColumn<S, T> getTableColumn() {
        return this.tableColumn.get();
    }
    
    private void setTableView(final TableView<S> tableView) {
        this.tableViewPropertyImpl().set(tableView);
    }
    
    public final TableView<S> getTableView() {
        return (this.tableView == null) ? null : this.tableView.get();
    }
    
    public final ReadOnlyObjectProperty<TableView<S>> tableViewProperty() {
        return this.tableViewPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<TableView<S>> tableViewPropertyImpl() {
        if (this.tableView == null) {
            this.tableView = new ReadOnlyObjectWrapper<TableView<S>>() {
                private WeakReference<TableView<S>> weakTableViewRef;
                
                @Override
                protected void invalidated() {
                    if (this.weakTableViewRef != null) {
                        TableCell.this.cleanUpTableViewListeners(this.weakTableViewRef.get());
                    }
                    if (this.get() != null) {
                        final TableView.TableViewSelectionModel selectionModel = ((ObjectPropertyBase<TableView>)this).get().getSelectionModel();
                        if (selectionModel != null) {
                            selectionModel.getSelectedCells().addListener(TableCell.this.weakSelectedListener);
                        }
                        final TableView.TableViewFocusModel focusModel = ((ObjectPropertyBase<TableView>)this).get().getFocusModel();
                        if (focusModel != null) {
                            focusModel.focusedCellProperty().addListener(TableCell.this.weakFocusedListener);
                        }
                        ((ObjectPropertyBase<TableView>)this).get().editingCellProperty().addListener(TableCell.this.weakEditingListener);
                        ((ObjectPropertyBase<TableView>)this).get().getVisibleLeafColumns().addListener(TableCell.this.weakVisibleLeafColumnsListener);
                        this.weakTableViewRef = new WeakReference<TableView<S>>((TableView<S>)((ObjectPropertyBase<TableView<?>>)this).get());
                    }
                    TableCell.this.updateColumnIndex();
                }
                
                @Override
                public Object getBean() {
                    return TableCell.this;
                }
                
                @Override
                public String getName() {
                    return "tableView";
                }
            };
        }
        return this.tableView;
    }
    
    private void setTableRow(final TableRow<S> tableRow) {
        this.tableRow.set(tableRow);
    }
    
    public final TableRow<S> getTableRow() {
        return this.tableRow.get();
    }
    
    public final ReadOnlyObjectProperty<TableRow<S>> tableRowProperty() {
        return this.tableRow;
    }
    
    @Override
    public void startEdit() {
        final TableView<?> tableView = this.getTableView();
        final TableColumn<S, T> tableColumn = this.getTableColumn();
        if (!this.isEditable() || (tableView != null && !tableView.isEditable()) || (tableColumn != null && !this.getTableColumn().isEditable())) {
            return;
        }
        if (!this.lockItemOnEdit) {
            this.updateItem(-1);
        }
        super.startEdit();
        if (tableColumn != null) {
            Event.fireEvent(tableColumn, new TableColumn.CellEditEvent<Object, Object>(tableView, tableView.getEditingCell(), TableColumn.editStartEvent(), null));
        }
    }
    
    @Override
    public void commitEdit(final T t) {
        if (!this.isEditing()) {
            return;
        }
        final TableView<?> tableView = this.getTableView();
        if (tableView != null) {
            Event.fireEvent(this.getTableColumn(), new TableColumn.CellEditEvent<Object, Object>((TableView<Object>)tableView, (TablePosition<Object, Object>)tableView.getEditingCell(), TableColumn.editCommitEvent(), t));
        }
        super.commitEdit(t);
        this.updateItem(t, false);
        if (tableView != null) {
            tableView.edit(-1, null);
            ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(tableView);
        }
    }
    
    @Override
    public void cancelEdit() {
        if (!this.isEditing()) {
            return;
        }
        final TableView<Object> tableView = this.getTableView();
        super.cancelEdit();
        if (tableView != null) {
            final TablePosition<Object, ?> editingCell = tableView.getEditingCell();
            if (this.updateEditingIndex) {
                tableView.edit(-1, null);
            }
            ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(tableView);
            Event.fireEvent(this.getTableColumn(), new TableColumn.CellEditEvent<Object, Object>(tableView, (TablePosition<Object, Object>)editingCell, TableColumn.editCancelEvent(), null));
        }
    }
    
    @Override
    public void updateSelected(final boolean selected) {
        if (this.getTableRow() == null || this.getTableRow().isEmpty()) {
            return;
        }
        this.setSelected(selected);
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TableCellSkin<Object, Object>(this);
    }
    
    private void cleanUpTableViewListeners(final TableView<S> tableView) {
        if (tableView != null) {
            final TableView.TableViewSelectionModel<S> selectionModel = tableView.getSelectionModel();
            if (selectionModel != null) {
                selectionModel.getSelectedCells().removeListener(this.weakSelectedListener);
            }
            final TableView.TableViewFocusModel<S> focusModel = tableView.getFocusModel();
            if (focusModel != null) {
                focusModel.focusedCellProperty().removeListener(this.weakFocusedListener);
            }
            tableView.editingCellProperty().removeListener(this.weakEditingListener);
            tableView.getVisibleLeafColumns().removeListener(this.weakVisibleLeafColumnsListener);
        }
    }
    
    @Override
    void indexChanged(final int n, final int n2) {
        super.indexChanged(n, n2);
        this.updateItem(n);
        this.updateSelection();
        this.updateFocus();
        this.updateEditing();
    }
    
    private void updateColumnIndex() {
        final TableView<S> tableView = this.getTableView();
        final TableColumn<S, ?> tableColumn = this.getTableColumn();
        this.columnIndex = ((tableView == null || tableColumn == null) ? -1 : tableView.getVisibleLeafIndex(tableColumn));
        this.isLastVisibleColumn = (this.getTableColumn() != null && this.columnIndex != -1 && this.columnIndex == this.getTableView().getVisibleLeafColumns().size() - 1);
        this.pseudoClassStateChanged(TableCell.PSEUDO_CLASS_LAST_VISIBLE, this.isLastVisibleColumn);
    }
    
    private void updateSelection() {
        if (this.isEmpty()) {
            return;
        }
        final boolean selected = this.isSelected();
        if (!this.isInCellSelectionMode()) {
            if (selected) {
                this.updateSelected(false);
            }
            return;
        }
        final TableView<S> tableView = this.getTableView();
        if (this.getIndex() == -1 || tableView == null) {
            return;
        }
        final TableView.TableViewSelectionModel<S> selectionModel = tableView.getSelectionModel();
        if (selectionModel == null) {
            this.updateSelected(false);
            return;
        }
        final boolean selected2 = selectionModel.isSelected(this.getIndex(), this.getTableColumn());
        if (selected == selected2) {
            return;
        }
        this.updateSelected(selected2);
    }
    
    private void updateFocus() {
        final boolean focused = this.isFocused();
        if (!this.isInCellSelectionMode()) {
            if (focused) {
                this.setFocused(false);
            }
            return;
        }
        final TableView<S> tableView = this.getTableView();
        final TableRow<S> tableRow = this.getTableRow();
        final int index = this.getIndex();
        if (index == -1 || tableView == null || tableRow == null) {
            return;
        }
        final TableView.TableViewFocusModel<S> focusModel = tableView.getFocusModel();
        if (focusModel == null) {
            this.setFocused(false);
            return;
        }
        this.setFocused(focusModel.isFocused(index, this.getTableColumn()));
    }
    
    private void updateEditing() {
        if (this.getIndex() == -1 || this.getTableView() == null) {
            return;
        }
        final boolean match = this.match(this.getTableView().getEditingCell());
        if (match && !this.isEditing()) {
            this.startEdit();
        }
        else if (!match && this.isEditing()) {
            this.updateEditingIndex = false;
            this.cancelEdit();
            this.updateEditingIndex = true;
        }
    }
    
    private boolean match(final TablePosition<S, ?> tablePosition) {
        return tablePosition != null && tablePosition.getRow() == this.getIndex() && tablePosition.getTableColumn() == this.getTableColumn();
    }
    
    private boolean isInCellSelectionMode() {
        final TableView<S> tableView = this.getTableView();
        if (tableView == null) {
            return false;
        }
        final TableView.TableViewSelectionModel<S> selectionModel = tableView.getSelectionModel();
        return selectionModel != null && selectionModel.isCellSelectionEnabled();
    }
    
    private void updateItem(final int n) {
        if (this.currentObservableValue != null) {
            this.currentObservableValue.removeListener(this.weaktableRowUpdateObserver);
        }
        final TableView<S> tableView = this.getTableView();
        final ObservableList<S> list = (tableView == null) ? FXCollections.emptyObservableList() : tableView.getItems();
        final TableColumn<S, T> tableColumn = this.getTableColumn();
        final int n2 = (list == null) ? -1 : list.size();
        final int index = this.getIndex();
        final boolean empty = this.isEmpty();
        final T item = this.getItem();
        final TableRow<S> tableRow = this.getTableRow();
        final S n3 = (tableRow == null) ? null : tableRow.getItem();
        final boolean b = index >= n2;
        if (b || index < 0 || this.columnIndex < 0 || !this.isVisible() || tableColumn == null || !tableColumn.isVisible()) {
            if ((!empty && item != null) || this.isFirstRun || b) {
                this.updateItem(null, true);
                this.isFirstRun = false;
            }
            return;
        }
        this.currentObservableValue = tableColumn.getCellObservableValue(index);
        final T t = (this.currentObservableValue == null) ? null : this.currentObservableValue.getValue();
        Label_0282: {
            if (n == index && !this.isItemChanged(item, t)) {
                final Object o = (this.oldRowItemRef != null) ? this.oldRowItemRef.get() : null;
                if (o != null && o.equals(n3)) {
                    break Label_0282;
                }
            }
            this.updateItem(t, false);
        }
        this.oldRowItemRef = new WeakReference<S>(n3);
        if (this.currentObservableValue == null) {
            return;
        }
        this.currentObservableValue.addListener(this.weaktableRowUpdateObserver);
    }
    
    @Override
    protected void layoutChildren() {
        if (this.itemDirty) {
            this.updateItem(-1);
            this.itemDirty = false;
        }
        super.layoutChildren();
    }
    
    public final void updateTableView(final TableView tableView) {
        this.setTableView(tableView);
    }
    
    public final void updateTableRow(final TableRow tableRow) {
        this.setTableRow(tableRow);
    }
    
    public final void updateTableColumn(final TableColumn tableColumn) {
        final TableColumn<S, T> tableColumn2 = this.getTableColumn();
        if (tableColumn2 != null) {
            tableColumn2.getStyleClass().removeListener(this.weakColumnStyleClassListener);
            this.getStyleClass().removeAll(tableColumn2.getStyleClass());
            tableColumn2.idProperty().removeListener(this.weakColumnIdListener);
            tableColumn2.styleProperty().removeListener(this.weakColumnStyleListener);
            final String id = this.getId();
            final String style = this.getStyle();
            if (id != null && id.equals(tableColumn2.getId())) {
                this.setId(null);
            }
            if (style != null && style.equals(tableColumn2.getStyle())) {
                this.setStyle("");
            }
        }
        this.setTableColumn(tableColumn);
        if (tableColumn != null) {
            this.getStyleClass().addAll((Collection<?>)tableColumn.getStyleClass());
            tableColumn.getStyleClass().addListener(this.weakColumnStyleClassListener);
            tableColumn.idProperty().addListener(this.weakColumnIdListener);
            tableColumn.styleProperty().addListener(this.weakColumnStyleListener);
            this.possiblySetId(tableColumn.getId());
            this.possiblySetStyle(tableColumn.getStyle());
        }
    }
    
    private void possiblySetId(final String id) {
        if (this.getId() == null || this.getId().isEmpty()) {
            this.setId(id);
        }
    }
    
    private void possiblySetStyle(final String style) {
        if (this.getStyle() == null || this.getStyle().isEmpty()) {
            this.setStyle(style);
        }
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case ROW_INDEX: {
                return this.getIndex();
            }
            case COLUMN_INDEX: {
                return this.columnIndex;
            }
            case SELECTED: {
                return this.isInCellSelectionMode() ? this.isSelected() : this.getTableRow().isSelected();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case REQUEST_FOCUS: {
                final TableView<S> tableView = this.getTableView();
                if (tableView != null) {
                    final TableView.TableViewFocusModel<S> focusModel = tableView.getFocusModel();
                    if (focusModel != null) {
                        focusModel.focus(this.getIndex(), this.getTableColumn());
                    }
                    break;
                }
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, array);
                break;
            }
        }
    }
    
    static {
        PSEUDO_CLASS_LAST_VISIBLE = PseudoClass.getPseudoClass("last-visible");
    }
}
