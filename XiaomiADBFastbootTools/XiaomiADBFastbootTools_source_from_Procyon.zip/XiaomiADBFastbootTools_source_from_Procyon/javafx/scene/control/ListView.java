// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import com.sun.javafx.scene.control.behavior.CellBehaviorBase;
import java.util.HashMap;
import javafx.util.Pair;
import javafx.beans.WeakInvalidationListener;
import javafx.beans.Observable;
import java.lang.ref.WeakReference;
import com.sun.javafx.scene.control.SelectedItemsReadOnlyObservableList;
import javafx.collections.WeakListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.SizeConverter;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.event.Event;
import javafx.collections.MapChangeListener;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.ListViewSkin;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.css.StyleableDoubleProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.scene.AccessibleRole;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.css.PseudoClass;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.util.Callback;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.beans.DefaultProperty;

@DefaultProperty("items")
public class ListView<T> extends Control
{
    private static final EventType<?> EDIT_ANY_EVENT;
    private static final EventType<?> EDIT_START_EVENT;
    private static final EventType<?> EDIT_CANCEL_EVENT;
    private static final EventType<?> EDIT_COMMIT_EVENT;
    private boolean selectFirstRowByDefault;
    private EventHandler<EditEvent<T>> DEFAULT_EDIT_COMMIT_HANDLER;
    private ObjectProperty<ObservableList<T>> items;
    private ObjectProperty<Node> placeholder;
    private ObjectProperty<MultipleSelectionModel<T>> selectionModel;
    private ObjectProperty<FocusModel<T>> focusModel;
    private ObjectProperty<Orientation> orientation;
    private ObjectProperty<Callback<ListView<T>, ListCell<T>>> cellFactory;
    private DoubleProperty fixedCellSize;
    private BooleanProperty editable;
    private ReadOnlyIntegerWrapper editingIndex;
    private ObjectProperty<EventHandler<EditEvent<T>>> onEditStart;
    private ObjectProperty<EventHandler<EditEvent<T>>> onEditCommit;
    private ObjectProperty<EventHandler<EditEvent<T>>> onEditCancel;
    private ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollTo;
    private static final String DEFAULT_STYLE_CLASS = "list-view";
    private static final PseudoClass PSEUDO_CLASS_VERTICAL;
    private static final PseudoClass PSEUDO_CLASS_HORIZONTAL;
    
    public static <T> EventType<EditEvent<T>> editAnyEvent() {
        return (EventType<EditEvent<T>>)ListView.EDIT_ANY_EVENT;
    }
    
    public static <T> EventType<EditEvent<T>> editStartEvent() {
        return (EventType<EditEvent<T>>)ListView.EDIT_START_EVENT;
    }
    
    public static <T> EventType<EditEvent<T>> editCancelEvent() {
        return (EventType<EditEvent<T>>)ListView.EDIT_CANCEL_EVENT;
    }
    
    public static <T> EventType<EditEvent<T>> editCommitEvent() {
        return (EventType<EditEvent<T>>)ListView.EDIT_COMMIT_EVENT;
    }
    
    public ListView() {
        this(FXCollections.observableArrayList());
    }
    
    public ListView(final ObservableList<T> items) {
        this.selectFirstRowByDefault = true;
        final int n;
        final ObservableList<Object> list;
        this.DEFAULT_EDIT_COMMIT_HANDLER = (editEvent -> {
            editEvent.getIndex();
            this.getItems();
            if (n < 0 || n >= list.size()) {
                return;
            }
            else {
                list.set(n, editEvent.getNewValue());
                return;
            }
        });
        this.selectionModel = new SimpleObjectProperty<MultipleSelectionModel<T>>(this, "selectionModel");
        this.getStyleClass().setAll("list-view");
        this.setAccessibleRole(AccessibleRole.LIST_VIEW);
        this.setItems(items);
        this.setSelectionModel(new ListViewBitSetSelectionModel<T>(this));
        this.setFocusModel(new ListViewFocusModel<T>(this));
        this.setOnEditCommit(this.DEFAULT_EDIT_COMMIT_HANDLER);
        Boolean b;
        this.getProperties().addListener(change -> {
            if (change.wasAdded() && "selectFirstRowByDefault".equals(change.getKey())) {
                b = (Boolean)change.getValueAdded();
                if (b != null) {
                    this.selectFirstRowByDefault = b;
                }
            }
        });
    }
    
    public final void setItems(final ObservableList<T> list) {
        this.itemsProperty().set(list);
    }
    
    public final ObservableList<T> getItems() {
        return (this.items == null) ? null : this.items.get();
    }
    
    public final ObjectProperty<ObservableList<T>> itemsProperty() {
        if (this.items == null) {
            this.items = new SimpleObjectProperty<ObservableList<T>>(this, "items");
        }
        return this.items;
    }
    
    public final ObjectProperty<Node> placeholderProperty() {
        if (this.placeholder == null) {
            this.placeholder = new SimpleObjectProperty<Node>(this, "placeholder");
        }
        return this.placeholder;
    }
    
    public final void setPlaceholder(final Node node) {
        this.placeholderProperty().set(node);
    }
    
    public final Node getPlaceholder() {
        return (this.placeholder == null) ? null : this.placeholder.get();
    }
    
    public final void setSelectionModel(final MultipleSelectionModel<T> multipleSelectionModel) {
        this.selectionModelProperty().set(multipleSelectionModel);
    }
    
    public final MultipleSelectionModel<T> getSelectionModel() {
        return (this.selectionModel == null) ? null : this.selectionModel.get();
    }
    
    public final ObjectProperty<MultipleSelectionModel<T>> selectionModelProperty() {
        return this.selectionModel;
    }
    
    public final void setFocusModel(final FocusModel<T> focusModel) {
        this.focusModelProperty().set(focusModel);
    }
    
    public final FocusModel<T> getFocusModel() {
        return (this.focusModel == null) ? null : this.focusModel.get();
    }
    
    public final ObjectProperty<FocusModel<T>> focusModelProperty() {
        if (this.focusModel == null) {
            this.focusModel = new SimpleObjectProperty<FocusModel<T>>(this, "focusModel");
        }
        return this.focusModel;
    }
    
    public final void setOrientation(final Orientation orientation) {
        this.orientationProperty().set(orientation);
    }
    
    public final Orientation getOrientation() {
        return (this.orientation == null) ? Orientation.VERTICAL : this.orientation.get();
    }
    
    public final ObjectProperty<Orientation> orientationProperty() {
        if (this.orientation == null) {
            this.orientation = new StyleableObjectProperty<Orientation>(Orientation.VERTICAL) {
                public void invalidated() {
                    final boolean b = this.get() == Orientation.VERTICAL;
                    ListView.this.pseudoClassStateChanged(ListView.PSEUDO_CLASS_VERTICAL, b);
                    ListView.this.pseudoClassStateChanged(ListView.PSEUDO_CLASS_HORIZONTAL, !b);
                }
                
                @Override
                public CssMetaData<ListView<?>, Orientation> getCssMetaData() {
                    return StyleableProperties.ORIENTATION;
                }
                
                @Override
                public Object getBean() {
                    return ListView.this;
                }
                
                @Override
                public String getName() {
                    return "orientation";
                }
            };
        }
        return this.orientation;
    }
    
    public final void setCellFactory(final Callback<ListView<T>, ListCell<T>> callback) {
        this.cellFactoryProperty().set(callback);
    }
    
    public final Callback<ListView<T>, ListCell<T>> getCellFactory() {
        return (this.cellFactory == null) ? null : this.cellFactory.get();
    }
    
    public final ObjectProperty<Callback<ListView<T>, ListCell<T>>> cellFactoryProperty() {
        if (this.cellFactory == null) {
            this.cellFactory = new SimpleObjectProperty<Callback<ListView<T>, ListCell<T>>>(this, "cellFactory");
        }
        return this.cellFactory;
    }
    
    public final void setFixedCellSize(final double n) {
        this.fixedCellSizeProperty().set(n);
    }
    
    public final double getFixedCellSize() {
        return (this.fixedCellSize == null) ? -1.0 : this.fixedCellSize.get();
    }
    
    public final DoubleProperty fixedCellSizeProperty() {
        if (this.fixedCellSize == null) {
            this.fixedCellSize = new StyleableDoubleProperty(-1.0) {
                @Override
                public CssMetaData<ListView<?>, Number> getCssMetaData() {
                    return StyleableProperties.FIXED_CELL_SIZE;
                }
                
                @Override
                public Object getBean() {
                    return ListView.this;
                }
                
                @Override
                public String getName() {
                    return "fixedCellSize";
                }
            };
        }
        return this.fixedCellSize;
    }
    
    public final void setEditable(final boolean b) {
        this.editableProperty().set(b);
    }
    
    public final boolean isEditable() {
        return this.editable != null && this.editable.get();
    }
    
    public final BooleanProperty editableProperty() {
        if (this.editable == null) {
            this.editable = new SimpleBooleanProperty(this, "editable", false);
        }
        return this.editable;
    }
    
    private void setEditingIndex(final int n) {
        this.editingIndexPropertyImpl().set(n);
    }
    
    public final int getEditingIndex() {
        return (this.editingIndex == null) ? -1 : this.editingIndex.get();
    }
    
    public final ReadOnlyIntegerProperty editingIndexProperty() {
        return this.editingIndexPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyIntegerWrapper editingIndexPropertyImpl() {
        if (this.editingIndex == null) {
            this.editingIndex = new ReadOnlyIntegerWrapper(this, "editingIndex", -1);
        }
        return this.editingIndex;
    }
    
    public final void setOnEditStart(final EventHandler<EditEvent<T>> eventHandler) {
        this.onEditStartProperty().set(eventHandler);
    }
    
    public final EventHandler<EditEvent<T>> getOnEditStart() {
        return (this.onEditStart == null) ? null : this.onEditStart.get();
    }
    
    public final ObjectProperty<EventHandler<EditEvent<T>>> onEditStartProperty() {
        if (this.onEditStart == null) {
            this.onEditStart = new ObjectPropertyBase<EventHandler<EditEvent<T>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(ListView.editStartEvent(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return ListView.this;
                }
                
                @Override
                public String getName() {
                    return "onEditStart";
                }
            };
        }
        return this.onEditStart;
    }
    
    public final void setOnEditCommit(final EventHandler<EditEvent<T>> eventHandler) {
        this.onEditCommitProperty().set(eventHandler);
    }
    
    public final EventHandler<EditEvent<T>> getOnEditCommit() {
        return (this.onEditCommit == null) ? null : this.onEditCommit.get();
    }
    
    public final ObjectProperty<EventHandler<EditEvent<T>>> onEditCommitProperty() {
        if (this.onEditCommit == null) {
            this.onEditCommit = new ObjectPropertyBase<EventHandler<EditEvent<T>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(ListView.editCommitEvent(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return ListView.this;
                }
                
                @Override
                public String getName() {
                    return "onEditCommit";
                }
            };
        }
        return this.onEditCommit;
    }
    
    public final void setOnEditCancel(final EventHandler<EditEvent<T>> eventHandler) {
        this.onEditCancelProperty().set(eventHandler);
    }
    
    public final EventHandler<EditEvent<T>> getOnEditCancel() {
        return (this.onEditCancel == null) ? null : this.onEditCancel.get();
    }
    
    public final ObjectProperty<EventHandler<EditEvent<T>>> onEditCancelProperty() {
        if (this.onEditCancel == null) {
            this.onEditCancel = new ObjectPropertyBase<EventHandler<EditEvent<T>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(ListView.editCancelEvent(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return ListView.this;
                }
                
                @Override
                public String getName() {
                    return "onEditCancel";
                }
            };
        }
        return this.onEditCancel;
    }
    
    public void edit(final int editingIndex) {
        if (!this.isEditable()) {
            return;
        }
        this.setEditingIndex(editingIndex);
    }
    
    public void scrollTo(final int n) {
        ControlUtils.scrollToIndex(this, n);
    }
    
    public void scrollTo(final T t) {
        if (this.getItems() != null) {
            final int index = this.getItems().indexOf(t);
            if (index >= 0) {
                ControlUtils.scrollToIndex(this, index);
            }
        }
    }
    
    public void setOnScrollTo(final EventHandler<ScrollToEvent<Integer>> eventHandler) {
        this.onScrollToProperty().set(eventHandler);
    }
    
    public EventHandler<ScrollToEvent<Integer>> getOnScrollTo() {
        if (this.onScrollTo != null) {
            return this.onScrollTo.get();
        }
        return null;
    }
    
    public ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollToProperty() {
        if (this.onScrollTo == null) {
            this.onScrollTo = new ObjectPropertyBase<EventHandler<ScrollToEvent<Integer>>>() {
                @Override
                protected void invalidated() {
                    Node.this.setEventHandler(ScrollToEvent.scrollToTopIndex(), ((ObjectPropertyBase<EventHandler>)this).get());
                }
                
                @Override
                public Object getBean() {
                    return ListView.this;
                }
                
                @Override
                public String getName() {
                    return "onScrollTo";
                }
            };
        }
        return this.onScrollTo;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ListViewSkin<Object>(this);
    }
    
    public void refresh() {
        this.getProperties().put("recreateKey", Boolean.TRUE);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case MULTIPLE_SELECTION: {
                final MultipleSelectionModel<T> selectionModel = this.getSelectionModel();
                return selectionModel != null && selectionModel.getSelectionMode() == SelectionMode.MULTIPLE;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        EDIT_ANY_EVENT = new EventType<Object>(Event.ANY, "LIST_VIEW_EDIT");
        EDIT_START_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_START");
        EDIT_CANCEL_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_CANCEL");
        EDIT_COMMIT_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_COMMIT");
        PSEUDO_CLASS_VERTICAL = PseudoClass.getPseudoClass("vertical");
        PSEUDO_CLASS_HORIZONTAL = PseudoClass.getPseudoClass("horizontal");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<ListView<?>, Orientation> ORIENTATION;
        private static final CssMetaData<ListView<?>, Number> FIXED_CELL_SIZE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            ORIENTATION = new CssMetaData<ListView<?>, Orientation>((StyleConverter)new EnumConverter(Orientation.class), Orientation.VERTICAL) {
                @Override
                public Orientation getInitialValue(final ListView<?> listView) {
                    return listView.getOrientation();
                }
                
                @Override
                public boolean isSettable(final ListView<?> listView) {
                    return ((ListView<Object>)listView).orientation == null || !((ListView<Object>)listView).orientation.isBound();
                }
                
                @Override
                public StyleableProperty<Orientation> getStyleableProperty(final ListView<?> listView) {
                    return (StyleableProperty<Orientation>)(StyleableProperty)listView.orientationProperty();
                }
            };
            FIXED_CELL_SIZE = new CssMetaData<ListView<?>, Number>((StyleConverter)SizeConverter.getInstance(), (Number)(-1.0)) {
                @Override
                public Double getInitialValue(final ListView<?> listView) {
                    return listView.getFixedCellSize();
                }
                
                @Override
                public boolean isSettable(final ListView<?> listView) {
                    return ((ListView<Object>)listView).fixedCellSize == null || !((ListView<Object>)listView).fixedCellSize.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final ListView<?> listView) {
                    return (StyleableProperty<Number>)listView.fixedCellSizeProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.ORIENTATION);
            list.add(StyleableProperties.FIXED_CELL_SIZE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    public static class EditEvent<T> extends Event
    {
        private final T newValue;
        private final int editIndex;
        private final ListView<T> source;
        private static final long serialVersionUID = 20130724L;
        public static final EventType<?> ANY;
        
        public EditEvent(final ListView<T> source, final EventType<? extends EditEvent<T>> eventType, final T newValue, final int editIndex) {
            super(source, Event.NULL_SOURCE_TARGET, eventType);
            this.source = source;
            this.editIndex = editIndex;
            this.newValue = newValue;
        }
        
        @Override
        public ListView<T> getSource() {
            return this.source;
        }
        
        public int getIndex() {
            return this.editIndex;
        }
        
        public T getNewValue() {
            return this.newValue;
        }
        
        @Override
        public String toString() {
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;Ljavafx/scene/control/ListView;)Ljava/lang/String;, this.getNewValue(), this.getSource());
        }
        
        static {
            ANY = ListView.EDIT_ANY_EVENT;
        }
    }
    
    static class ListViewBitSetSelectionModel<T> extends MultipleSelectionModelBase<T>
    {
        private final ListChangeListener<T> itemsContentObserver;
        private final InvalidationListener itemsObserver;
        private WeakListChangeListener<T> weakItemsContentObserver;
        private final ListView<T> listView;
        private int itemCount;
        private int previousModelSize;
        
        public ListViewBitSetSelectionModel(final ListView<T> listView) {
            this.itemsContentObserver = new ListChangeListener<T>() {
                @Override
                public void onChanged(final Change<? extends T> selectedItemChange) {
                    ListViewBitSetSelectionModel.this.updateItemCount();
                    boolean b = true;
                    while (selectedItemChange.next()) {
                        final Object selectedItem = ListViewBitSetSelectionModel.this.getSelectedItem();
                        final int selectedIndex = ListViewBitSetSelectionModel.this.getSelectedIndex();
                        if (ListViewBitSetSelectionModel.this.listView.getItems() == null || ListViewBitSetSelectionModel.this.listView.getItems().isEmpty()) {
                            ListViewBitSetSelectionModel.this.selectedItemChange = selectedItemChange;
                            ListViewBitSetSelectionModel.this.clearSelection();
                            ListViewBitSetSelectionModel.this.selectedItemChange = null;
                        }
                        else if (selectedIndex == -1 && selectedItem != null) {
                            final int index = ListViewBitSetSelectionModel.this.listView.getItems().indexOf(selectedItem);
                            if (index == -1) {
                                continue;
                            }
                            ListViewBitSetSelectionModel.this.setSelectedIndex(index);
                            b = false;
                        }
                        else {
                            if (!selectedItemChange.wasRemoved() || selectedItemChange.getRemovedSize() != 1 || selectedItemChange.wasAdded() || selectedItem == null || !selectedItem.equals(selectedItemChange.getRemoved().get(0)) || ListViewBitSetSelectionModel.this.getSelectedIndex() >= ListViewBitSetSelectionModel.this.getItemCount()) {
                                continue;
                            }
                            final T modelItem = ListViewBitSetSelectionModel.this.getModelItem((selectedIndex == 0) ? 0 : (selectedIndex - 1));
                            if (selectedItem.equals(modelItem)) {
                                continue;
                            }
                            ListViewBitSetSelectionModel.this.startAtomic();
                            ListViewBitSetSelectionModel.this.clearSelection(selectedIndex);
                            ListViewBitSetSelectionModel.this.stopAtomic();
                            ListViewBitSetSelectionModel.this.select(modelItem);
                        }
                    }
                    if (b) {
                        ListViewBitSetSelectionModel.this.updateSelection(selectedItemChange);
                    }
                }
            };
            this.weakItemsContentObserver = new WeakListChangeListener<T>(this.itemsContentObserver);
            this.itemCount = 0;
            this.previousModelSize = 0;
            if (listView == null) {
                throw new IllegalArgumentException("ListView can not be null");
            }
            this.listView = listView;
            ((SelectedItemsReadOnlyObservableList)this.getSelectedItems()).setItemsList(listView.getItems());
            this.itemsObserver = new InvalidationListener() {
                private WeakReference<ObservableList<T>> weakItemsRef = new WeakReference<ObservableList<T>>(listView.getItems());
                
                @Override
                public void invalidated(final Observable observable) {
                    final ObservableList list = this.weakItemsRef.get();
                    this.weakItemsRef = new WeakReference<ObservableList<T>>(listView.getItems());
                    ((SelectedItemsReadOnlyObservableList)ListViewBitSetSelectionModel.this.getSelectedItems()).setItemsList(listView.getItems());
                    ListViewBitSetSelectionModel.this.updateItemsObserver(list, listView.getItems());
                }
            };
            this.listView.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver));
            if (listView.getItems() != null) {
                this.listView.getItems().addListener(this.weakItemsContentObserver);
            }
            this.updateItemCount();
            this.updateDefaultSelection();
        }
        
        private void updateSelection(final ListChangeListener.Change<? extends T> change) {
            change.reset();
            final ArrayList<Pair<Integer, Integer>> list = new ArrayList<Pair<Integer, Integer>>();
            while (change.next()) {
                if (change.wasReplaced()) {
                    if (change.getList().isEmpty()) {
                        this.clearSelection();
                    }
                    else {
                        final int selectedIndex = this.getSelectedIndex();
                        if (this.previousModelSize == change.getRemovedSize()) {
                            this.clearSelection();
                        }
                        else if (selectedIndex < this.getItemCount() && selectedIndex >= 0) {
                            this.startAtomic();
                            this.clearSelection(selectedIndex);
                            this.stopAtomic();
                            this.select(selectedIndex);
                        }
                        else {
                            this.clearSelection();
                        }
                    }
                }
                else if (change.wasAdded() || change.wasRemoved()) {
                    list.add(new Pair<Integer, Integer>(change.getFrom(), change.wasAdded() ? change.getAddedSize() : (-change.getRemovedSize())));
                }
                else {
                    if (!change.wasPermutated()) {
                        continue;
                    }
                    final HashMap<Integer, Integer> hashMap = new HashMap<Integer, Integer>(change.getTo() - change.getFrom());
                    for (int i = change.getFrom(); i < change.getTo(); ++i) {
                        hashMap.put(i, change.getPermutation(i));
                    }
                    final ArrayList<Integer> list2 = new ArrayList<Integer>(this.getSelectedIndices());
                    this.clearSelection();
                    final ArrayList<Integer> list3 = new ArrayList<Integer>(this.getSelectedIndices().size());
                    for (int j = 0; j < list2.size(); ++j) {
                        final int intValue = list2.get(j);
                        if (hashMap.containsKey(intValue)) {
                            list3.add(hashMap.get(intValue));
                        }
                    }
                    if (list3.isEmpty()) {
                        continue;
                    }
                    if (list3.size() == 1) {
                        this.select((int)list3.get(0));
                    }
                    else {
                        final int[] array = new int[list3.size() - 1];
                        for (int k = 0; k < list3.size() - 1; ++k) {
                            array[k] = (int)list3.get(k + 1);
                        }
                        this.selectIndices(list3.get(0), array);
                    }
                }
            }
            if (!list.isEmpty()) {
                this.shiftSelection(list, null);
            }
            this.previousModelSize = this.getItemCount();
        }
        
        @Override
        public void selectAll() {
            final int intValue = CellBehaviorBase.getAnchor(this.listView, -1);
            super.selectAll();
            CellBehaviorBase.setAnchor(this.listView, intValue, false);
        }
        
        @Override
        public void clearAndSelect(final int i) {
            CellBehaviorBase.setAnchor(this.listView, i, false);
            super.clearAndSelect(i);
        }
        
        @Override
        protected void focus(final int n) {
            if (this.listView.getFocusModel() == null) {
                return;
            }
            this.listView.getFocusModel().focus(n);
            this.listView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
        }
        
        @Override
        protected int getFocusedIndex() {
            if (this.listView.getFocusModel() == null) {
                return -1;
            }
            return this.listView.getFocusModel().getFocusedIndex();
        }
        
        @Override
        protected int getItemCount() {
            return this.itemCount;
        }
        
        @Override
        protected T getModelItem(final int n) {
            final ObservableList<T> items = this.listView.getItems();
            if (items == null) {
                return null;
            }
            if (n < 0 || n >= this.itemCount) {
                return null;
            }
            return (T)items.get(n);
        }
        
        private void updateItemCount() {
            if (this.listView == null) {
                this.itemCount = -1;
            }
            else {
                final ObservableList<T> items = this.listView.getItems();
                this.itemCount = ((items == null) ? -1 : items.size());
            }
        }
        
        private void updateItemsObserver(final ObservableList<T> list, final ObservableList<T> list2) {
            if (list != null) {
                list.removeListener(this.weakItemsContentObserver);
            }
            if (list2 != null) {
                list2.addListener(this.weakItemsContentObserver);
            }
            this.updateItemCount();
            this.updateDefaultSelection();
        }
        
        private void updateDefaultSelection() {
            int n = -1;
            int index = -1;
            if (this.listView.getItems() != null) {
                final Object selectedItem = this.getSelectedItem();
                if (selectedItem != null) {
                    n = (index = this.listView.getItems().indexOf(selectedItem));
                }
                if (((ListView<Object>)this.listView).selectFirstRowByDefault && index == -1) {
                    final int n2 = (this.listView.getItems().size() > 0) ? 0 : -1;
                }
            }
            this.clearSelection();
            this.select(n);
        }
    }
    
    static class ListViewFocusModel<T> extends FocusModel<T>
    {
        private final ListView<T> listView;
        private int itemCount;
        private final InvalidationListener itemsObserver;
        private final ListChangeListener<T> itemsContentListener;
        private WeakListChangeListener<T> weakItemsContentListener;
        
        public ListViewFocusModel(final ListView<T> listView) {
            this.itemCount = 0;
            final int n;
            boolean b = false;
            boolean b2 = false;
            int n2 = 0;
            int n3 = 0;
            this.itemsContentListener = (change -> {
                this.updateItemCount();
                while (change.next()) {
                    change.getFrom();
                    if (change.wasReplaced() || change.getAddedSize() == this.getItemCount()) {
                        this.updateDefaultFocus();
                    }
                    else if (this.getFocusedIndex() != -1 && n <= this.getFocusedIndex()) {
                        change.reset();
                        while (change.next()) {
                            b |= change.wasAdded();
                            b2 |= change.wasRemoved();
                            n2 += change.getAddedSize();
                            n3 += change.getRemovedSize();
                        }
                        if (b && !b2) {
                            this.focus(Math.min(this.getItemCount() - 1, this.getFocusedIndex() + n2));
                        }
                        else if (!b && b2) {
                            this.focus(Math.max(0, this.getFocusedIndex() - n3));
                        }
                        else {
                            continue;
                        }
                    }
                }
                return;
            });
            this.weakItemsContentListener = new WeakListChangeListener<T>(this.itemsContentListener);
            if (listView == null) {
                throw new IllegalArgumentException("ListView can not be null");
            }
            this.listView = listView;
            this.itemsObserver = new InvalidationListener() {
                private WeakReference<ObservableList<T>> weakItemsRef = new WeakReference<ObservableList<T>>(listView.getItems());
                
                @Override
                public void invalidated(final Observable observable) {
                    final ObservableList list = this.weakItemsRef.get();
                    this.weakItemsRef = new WeakReference<ObservableList<T>>(listView.getItems());
                    ListViewFocusModel.this.updateItemsObserver(list, listView.getItems());
                }
            };
            this.listView.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver));
            if (listView.getItems() != null) {
                this.listView.getItems().addListener(this.weakItemsContentListener);
            }
            this.updateItemCount();
            this.updateDefaultFocus();
            this.focusedIndexProperty().addListener(p1 -> listView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM));
        }
        
        private void updateItemsObserver(final ObservableList<T> list, final ObservableList<T> list2) {
            if (list != null) {
                list.removeListener(this.weakItemsContentListener);
            }
            if (list2 != null) {
                list2.addListener(this.weakItemsContentListener);
            }
            this.updateItemCount();
            this.updateDefaultFocus();
        }
        
        @Override
        protected int getItemCount() {
            return this.itemCount;
        }
        
        @Override
        protected T getModelItem(final int n) {
            if (this.isEmpty()) {
                return null;
            }
            if (n < 0 || n >= this.itemCount) {
                return null;
            }
            return this.listView.getItems().get(n);
        }
        
        private boolean isEmpty() {
            return this.itemCount == -1;
        }
        
        private void updateItemCount() {
            if (this.listView == null) {
                this.itemCount = -1;
            }
            else {
                final ObservableList<T> items = this.listView.getItems();
                this.itemCount = ((items == null) ? -1 : items.size());
            }
        }
        
        private void updateDefaultFocus() {
            int index = -1;
            if (this.listView.getItems() != null) {
                final Object focusedItem = this.getFocusedItem();
                if (focusedItem != null) {
                    index = this.listView.getItems().indexOf(focusedItem);
                }
                if (index == -1) {
                    index = ((this.listView.getItems().size() > 0) ? 0 : -1);
                }
            }
            this.focus(index);
        }
    }
}
