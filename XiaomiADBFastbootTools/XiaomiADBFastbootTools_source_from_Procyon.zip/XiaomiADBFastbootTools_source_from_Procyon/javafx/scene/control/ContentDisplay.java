// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

public enum ContentDisplay
{
    TOP, 
    RIGHT, 
    BOTTOM, 
    LEFT, 
    CENTER, 
    GRAPHIC_ONLY, 
    TEXT_ONLY;
}
