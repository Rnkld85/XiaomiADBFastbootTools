// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ObjectPropertyBase;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.DurationConverter;
import javafx.event.ActionEvent;
import javafx.collections.MapChangeListener;
import javafx.beans.Observable;
import javafx.scene.AccessibleAction;
import java.math.BigDecimal;
import javafx.scene.AccessibleAttribute;
import javafx.beans.property.StringProperty;
import com.sun.javafx.scene.control.FakeFocusTextField;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.util.StringConverter;
import javafx.scene.control.skin.SpinnerSkin;
import javafx.collections.ObservableList;
import java.time.LocalTime;
import java.time.temporal.TemporalUnit;
import java.time.LocalDate;
import javafx.beans.NamedArg;
import javafx.scene.AccessibleRole;
import javafx.css.SimpleStyleableObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.Styleable;
import java.util.List;
import javafx.css.CssMetaData;
import javafx.util.Duration;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;

public class Spinner<T> extends Control
{
    private static final String DEFAULT_STYLE_CLASS = "spinner";
    public static final String STYLE_CLASS_ARROWS_ON_RIGHT_HORIZONTAL = "arrows-on-right-horizontal";
    public static final String STYLE_CLASS_ARROWS_ON_LEFT_VERTICAL = "arrows-on-left-vertical";
    public static final String STYLE_CLASS_ARROWS_ON_LEFT_HORIZONTAL = "arrows-on-left-horizontal";
    public static final String STYLE_CLASS_SPLIT_ARROWS_VERTICAL = "split-arrows-vertical";
    public static final String STYLE_CLASS_SPLIT_ARROWS_HORIZONTAL = "split-arrows-horizontal";
    private ReadOnlyObjectWrapper<T> value;
    private ObjectProperty<SpinnerValueFactory<T>> valueFactory;
    private BooleanProperty editable;
    private TextField textField;
    private ReadOnlyObjectWrapper<TextField> editor;
    private final ObjectProperty<Duration> initialDelay;
    private final ObjectProperty<Duration> repeatDelay;
    private static final CssMetaData<Spinner<?>, Duration> INITIAL_DELAY;
    private static final CssMetaData<Spinner<?>, Duration> REPEAT_DELAY;
    private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
    
    public Spinner() {
        this.value = new ReadOnlyObjectWrapper<T>(this, "value");
        this.valueFactory = new SimpleObjectProperty<SpinnerValueFactory<T>>((Object)this, "valueFactory") {
            @Override
            protected void invalidated() {
                Spinner.this.value.unbind();
                final SpinnerValueFactory spinnerValueFactory = ((ObjectPropertyBase<SpinnerValueFactory>)this).get();
                if (spinnerValueFactory != null) {
                    Spinner.this.value.bind(spinnerValueFactory.valueProperty());
                }
            }
        };
        this.initialDelay = new SimpleStyleableObjectProperty<Duration>(Spinner.INITIAL_DELAY, this, "initialDelay", new Duration(300.0));
        this.repeatDelay = new SimpleStyleableObjectProperty<Duration>(Spinner.REPEAT_DELAY, this, "repeatDelay", new Duration(60.0));
        this.getStyleClass().add("spinner");
        this.setAccessibleRole(AccessibleRole.SPINNER);
        this.getEditor().setOnAction(p0 -> this.commitValue());
        this.getEditor().editableProperty().bind(this.editableProperty());
        this.value.addListener((p0, p1, text) -> this.setText(text));
        this.getProperties().addListener(change -> {
            if (change.wasAdded() && change.getKey() == "FOCUSED") {
                this.setFocused(change.getValueAdded());
                this.getProperties().remove("FOCUSED");
            }
            return;
        });
        this.focusedProperty().addListener(p0 -> {
            if (!this.isFocused()) {
                this.commitValue();
            }
        });
    }
    
    public Spinner(@NamedArg("min") final int n, @NamedArg("max") final int n2, @NamedArg("initialValue") final int n3) {
        this((SpinnerValueFactory)new SpinnerValueFactory.IntegerSpinnerValueFactory(n, n2, n3));
    }
    
    public Spinner(@NamedArg("min") final int n, @NamedArg("max") final int n2, @NamedArg("initialValue") final int n3, @NamedArg("amountToStepBy") final int n4) {
        this((SpinnerValueFactory)new SpinnerValueFactory.IntegerSpinnerValueFactory(n, n2, n3, n4));
    }
    
    public Spinner(@NamedArg("min") final double n, @NamedArg("max") final double n2, @NamedArg("initialValue") final double n3) {
        this((SpinnerValueFactory)new SpinnerValueFactory.DoubleSpinnerValueFactory(n, n2, n3));
    }
    
    public Spinner(@NamedArg("min") final double n, @NamedArg("max") final double n2, @NamedArg("initialValue") final double n3, @NamedArg("amountToStepBy") final double n4) {
        this((SpinnerValueFactory)new SpinnerValueFactory.DoubleSpinnerValueFactory(n, n2, n3, n4));
    }
    
    Spinner(@NamedArg("min") final LocalDate localDate, @NamedArg("max") final LocalDate localDate2, @NamedArg("initialValue") final LocalDate localDate3) {
        this((SpinnerValueFactory)new SpinnerValueFactory.LocalDateSpinnerValueFactory(localDate, localDate2, localDate3));
    }
    
    Spinner(@NamedArg("min") final LocalDate localDate, @NamedArg("max") final LocalDate localDate2, @NamedArg("initialValue") final LocalDate localDate3, @NamedArg("amountToStepBy") final long n, @NamedArg("temporalUnit") final TemporalUnit temporalUnit) {
        this((SpinnerValueFactory)new SpinnerValueFactory.LocalDateSpinnerValueFactory(localDate, localDate2, localDate3, n, temporalUnit));
    }
    
    Spinner(@NamedArg("min") final LocalTime localTime, @NamedArg("max") final LocalTime localTime2, @NamedArg("initialValue") final LocalTime localTime3) {
        this((SpinnerValueFactory)new SpinnerValueFactory.LocalTimeSpinnerValueFactory(localTime, localTime2, localTime3));
    }
    
    Spinner(@NamedArg("min") final LocalTime localTime, @NamedArg("max") final LocalTime localTime2, @NamedArg("initialValue") final LocalTime localTime3, @NamedArg("amountToStepBy") final long n, @NamedArg("temporalUnit") final TemporalUnit temporalUnit) {
        this((SpinnerValueFactory)new SpinnerValueFactory.LocalTimeSpinnerValueFactory(localTime, localTime2, localTime3, n, temporalUnit));
    }
    
    public Spinner(@NamedArg("items") final ObservableList<T> list) {
        this((SpinnerValueFactory)new SpinnerValueFactory.ListSpinnerValueFactory(list));
    }
    
    public Spinner(@NamedArg("valueFactory") final SpinnerValueFactory<T> valueFactory) {
        this();
        this.setValueFactory(valueFactory);
    }
    
    public void increment() {
        this.increment(1);
    }
    
    public void increment(final int n) {
        final SpinnerValueFactory<T> valueFactory = this.getValueFactory();
        if (valueFactory == null) {
            throw new IllegalStateException("Can't increment Spinner with a null SpinnerValueFactory");
        }
        this.commitValue();
        valueFactory.increment(n);
    }
    
    public void decrement() {
        this.decrement(1);
    }
    
    public void decrement(final int n) {
        final SpinnerValueFactory<T> valueFactory = this.getValueFactory();
        if (valueFactory == null) {
            throw new IllegalStateException("Can't decrement Spinner with a null SpinnerValueFactory");
        }
        this.commitValue();
        valueFactory.decrement(n);
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new SpinnerSkin<Object>(this);
    }
    
    public final void commitValue() {
        if (!this.isEditable()) {
            return;
        }
        final String text = this.getEditor().getText();
        final SpinnerValueFactory<Object> valueFactory = this.getValueFactory();
        if (valueFactory != null) {
            final StringConverter<Object> converter = valueFactory.getConverter();
            if (converter != null) {
                valueFactory.setValue(converter.fromString(text));
            }
        }
    }
    
    public final void cancelEdit() {
        if (!this.isEditable()) {
            return;
        }
        final Object value = this.getValue();
        final SpinnerValueFactory<Object> valueFactory = this.getValueFactory();
        if (valueFactory != null) {
            final StringConverter<Object> converter = valueFactory.getConverter();
            if (converter != null) {
                this.getEditor().setText(converter.toString(value));
            }
        }
    }
    
    public final T getValue() {
        return this.value.get();
    }
    
    public final ReadOnlyObjectProperty<T> valueProperty() {
        return this.value;
    }
    
    public final void setValueFactory(final SpinnerValueFactory<T> value) {
        this.valueFactory.setValue(value);
    }
    
    public final SpinnerValueFactory<T> getValueFactory() {
        return this.valueFactory.get();
    }
    
    public final ObjectProperty<SpinnerValueFactory<T>> valueFactoryProperty() {
        return this.valueFactory;
    }
    
    public final void setEditable(final boolean b) {
        this.editableProperty().set(b);
    }
    
    public final boolean isEditable() {
        return this.editable == null || this.editable.get();
    }
    
    public final BooleanProperty editableProperty() {
        if (this.editable == null) {
            this.editable = new SimpleBooleanProperty(this, "editable", false);
        }
        return this.editable;
    }
    
    public final ReadOnlyObjectProperty<TextField> editorProperty() {
        if (this.editor == null) {
            this.editor = new ReadOnlyObjectWrapper<TextField>(this, "editor");
            this.textField = new FakeFocusTextField();
            this.textField.tooltipProperty().bind((ObservableValue<?>)this.tooltipProperty());
            this.editor.set(this.textField);
        }
        return this.editor.getReadOnlyProperty();
    }
    
    public final TextField getEditor() {
        return this.editorProperty().get();
    }
    
    public final StringProperty promptTextProperty() {
        return this.getEditor().promptTextProperty();
    }
    
    public final String getPromptText() {
        return this.getEditor().getPromptText();
    }
    
    public final void setPromptText(final String promptText) {
        this.getEditor().setPromptText(promptText);
    }
    
    public final ObjectProperty<Duration> initialDelayProperty() {
        return this.initialDelay;
    }
    
    public final void setInitialDelay(final Duration duration) {
        if (duration != null) {
            this.initialDelay.set(duration);
        }
    }
    
    public final Duration getInitialDelay() {
        return this.initialDelay.get();
    }
    
    public final ObjectProperty<Duration> repeatDelayProperty() {
        return this.repeatDelay;
    }
    
    public final void setRepeatDelay(final Duration duration) {
        if (duration != null) {
            this.repeatDelay.set(duration);
        }
    }
    
    public final Duration getRepeatDelay() {
        return this.repeatDelay.get();
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return Spinner.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    private void setText(final T t) {
        String text = null;
        final SpinnerValueFactory<T> valueFactory = this.getValueFactory();
        if (valueFactory != null) {
            final StringConverter<T> converter = valueFactory.getConverter();
            if (converter != null) {
                text = converter.toString(t);
            }
        }
        this.notifyAccessibleAttributeChanged(AccessibleAttribute.TEXT);
        if (text == null) {
            if (t == null) {
                this.getEditor().clear();
                return;
            }
            text = t.toString();
        }
        this.getEditor().setText(text);
    }
    
    static int wrapValue(final int n, final int n2, final int n3) {
        if (n3 == 0) {
            throw new RuntimeException();
        }
        int n4 = n % n3;
        if (n4 > n2 && n3 < n2) {
            n4 = n4 + n3 - n2;
        }
        else if (n4 < n2 && n3 > n2) {
            n4 = n4 + n3 - n2;
        }
        return n4;
    }
    
    static BigDecimal wrapValue(final BigDecimal bigDecimal, final BigDecimal val, final BigDecimal val2) {
        if (val2.doubleValue() == 0.0) {
            throw new RuntimeException();
        }
        if (bigDecimal.compareTo(val) < 0) {
            return val2;
        }
        if (bigDecimal.compareTo(val2) > 0) {
            return val;
        }
        return bigDecimal;
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case TEXT: {
                final Object value = this.getValue();
                final SpinnerValueFactory<Object> valueFactory = this.getValueFactory();
                if (valueFactory != null) {
                    final StringConverter<Object> converter = valueFactory.getConverter();
                    if (converter != null) {
                        return converter.toString(value);
                    }
                }
                return (value != null) ? value.toString() : "";
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case INCREMENT: {
                this.increment();
                break;
            }
            case DECREMENT: {
                this.decrement();
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, new Object[0]);
                break;
            }
        }
    }
    
    static {
        INITIAL_DELAY = new CssMetaData<Spinner<?>, Duration>((StyleConverter)DurationConverter.getInstance(), new Duration(300.0)) {
            @Override
            public boolean isSettable(final Spinner<?> spinner) {
                return !spinner.initialDelayProperty().isBound();
            }
            
            @Override
            public StyleableProperty<Duration> getStyleableProperty(final Spinner<?> spinner) {
                return (StyleableProperty<Duration>)(StyleableProperty)spinner.initialDelayProperty();
            }
        };
        REPEAT_DELAY = new CssMetaData<Spinner<?>, Duration>((StyleConverter)DurationConverter.getInstance(), new Duration(60.0)) {
            @Override
            public boolean isSettable(final Spinner<?> spinner) {
                return !spinner.repeatDelayProperty().isBound();
            }
            
            @Override
            public StyleableProperty<Duration> getStyleableProperty(final Spinner<?> spinner) {
                return (StyleableProperty<Duration>)(StyleableProperty)spinner.repeatDelayProperty();
            }
        };
        final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
        list.add(Spinner.INITIAL_DELAY);
        list.add(Spinner.REPEAT_DELAY);
        STYLEABLES = Collections.unmodifiableList((List<?>)list);
    }
}
