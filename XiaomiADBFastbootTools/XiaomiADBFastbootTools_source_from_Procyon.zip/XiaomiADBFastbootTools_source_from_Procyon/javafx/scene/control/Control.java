// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import javafx.css.StyleConverter;
import javafx.css.converter.StringConverter;
import com.sun.javafx.application.PlatformImpl;
import javafx.application.Application;
import javafx.scene.AccessibleAction;
import javafx.scene.AccessibleAttribute;
import java.util.ArrayList;
import java.util.HashMap;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import javafx.css.CssParser;
import com.sun.javafx.css.StyleManager;
import javafx.css.StyleableStringProperty;
import javafx.collections.ObservableList;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import com.sun.javafx.scene.control.ControlHelper;
import com.sun.javafx.scene.control.ControlAcceleratorSupport;
import java.lang.ref.WeakReference;
import javafx.beans.property.SimpleObjectProperty;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.scene.control.Logging;
import com.sun.javafx.scene.NodeHelper;
import javafx.css.StyleableObjectProperty;
import javafx.scene.Node;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.StringProperty;
import javafx.beans.property.ObjectProperty;
import javafx.scene.input.ContextMenuEvent;
import javafx.event.EventHandler;
import javafx.css.Styleable;
import javafx.css.CssMetaData;
import java.util.List;
import javafx.scene.layout.Region;

public abstract class Control extends Region implements Skinnable
{
    private List<CssMetaData<? extends Styleable, ?>> styleableProperties;
    private SkinBase<?> skinBase;
    private static final EventHandler<ContextMenuEvent> contextMenuHandler;
    private ObjectProperty<Skin<?>> skin;
    private ObjectProperty<Tooltip> tooltip;
    private ObjectProperty<ContextMenu> contextMenu;
    private String currentSkinClassName;
    private StringProperty skinClassName;
    private boolean skinCreationLocked;
    
    private static Class<?> loadClass(final String name, final Object o) throws ClassNotFoundException {
        try {
            return Class.forName(name, false, Control.class.getClassLoader());
        }
        catch (ClassNotFoundException ex) {
            if (Thread.currentThread().getContextClassLoader() != null) {
                try {
                    return Class.forName(name, false, Thread.currentThread().getContextClassLoader());
                }
                catch (ClassNotFoundException ex2) {}
            }
            if (o != null) {
                Class<?> clazz = o.getClass();
                while (clazz != null) {
                    try {
                        return Class.forName(name, false, clazz.getClassLoader());
                    }
                    catch (ClassNotFoundException ex3) {
                        clazz = clazz.getSuperclass();
                        continue;
                    }
                    break;
                }
            }
            throw ex;
        }
    }
    
    @Override
    public final ObjectProperty<Skin<?>> skinProperty() {
        return this.skin;
    }
    
    @Override
    public final void setSkin(final Skin<?> skin) {
        this.skinProperty().set(skin);
    }
    
    @Override
    public final Skin<?> getSkin() {
        return this.skinProperty().getValue();
    }
    
    public final ObjectProperty<Tooltip> tooltipProperty() {
        if (this.tooltip == null) {
            this.tooltip = new ObjectPropertyBase<Tooltip>() {
                private Tooltip old = null;
                
                @Override
                protected void invalidated() {
                    final Tooltip old = this.get();
                    if (old != this.old) {
                        if (this.old != null) {
                            Tooltip.uninstall(Control.this, this.old);
                        }
                        if (old != null) {
                            Tooltip.install(Control.this, old);
                        }
                        this.old = old;
                    }
                }
                
                @Override
                public Object getBean() {
                    return Control.this;
                }
                
                @Override
                public String getName() {
                    return "tooltip";
                }
            };
        }
        return this.tooltip;
    }
    
    public final void setTooltip(final Tooltip value) {
        this.tooltipProperty().setValue(value);
    }
    
    public final Tooltip getTooltip() {
        return (this.tooltip == null) ? null : this.tooltip.getValue();
    }
    
    public final ObjectProperty<ContextMenu> contextMenuProperty() {
        return this.contextMenu;
    }
    
    public final void setContextMenu(final ContextMenu value) {
        this.contextMenu.setValue(value);
    }
    
    public final ContextMenu getContextMenu() {
        return (this.contextMenu == null) ? null : this.contextMenu.getValue();
    }
    
    protected Control() {
        this.skin = new StyleableObjectProperty<Skin<?>>() {
            private Skin<?> oldValue;
            
            @Override
            public void set(final Skin<?> skin) {
                Label_0039: {
                    if (skin == null) {
                        if (this.oldValue != null) {
                            break Label_0039;
                        }
                    }
                    else if (this.oldValue == null || !skin.getClass().equals(this.oldValue.getClass())) {
                        break Label_0039;
                    }
                    return;
                }
                super.set(skin);
            }
            
            @Override
            protected void invalidated() {
                final Skin<?> oldValue = this.get();
                Control.this.currentSkinClassName = ((oldValue == null) ? null : oldValue.getClass().getName());
                Control.this.skinClassNameProperty().set(Control.this.currentSkinClassName);
                if (this.oldValue != null) {
                    this.oldValue.dispose();
                }
                this.oldValue = oldValue;
                Control.this.skinBase = null;
                if (oldValue instanceof SkinBase) {
                    Control.this.skinBase = (SkinBase<?>)(SkinBase)oldValue;
                }
                else {
                    final Node access$300 = Control.this.getSkinNode();
                    if (access$300 != null) {
                        Parent.this.getChildren().setAll(access$300);
                    }
                    else {
                        Parent.this.getChildren().clear();
                    }
                }
                Control.this.styleableProperties = null;
                NodeHelper.reapplyCSS(Control.this);
                final PlatformLogger controlsLogger = Logging.getControlsLogger();
                if (controlsLogger.isLoggable(PlatformLogger.Level.FINEST)) {
                    controlsLogger.finest(invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;Ljavafx/scene/control/Control$2;)Ljava/lang/String;, this.getValue(), this));
                }
            }
            
            @Override
            public CssMetaData getCssMetaData() {
                return StyleableProperties.SKIN;
            }
            
            @Override
            public Object getBean() {
                return Control.this;
            }
            
            @Override
            public String getName() {
                return "skin";
            }
        };
        this.contextMenu = new SimpleObjectProperty<ContextMenu>((Object)this, "contextMenu") {
            private WeakReference<ContextMenu> contextMenuRef;
            
            @Override
            protected void invalidated() {
                final ContextMenu contextMenu = (this.contextMenuRef == null) ? null : this.contextMenuRef.get();
                if (contextMenu != null) {
                    ControlAcceleratorSupport.removeAcceleratorsFromScene(contextMenu.getItems(), Control.this);
                }
                final ContextMenu referent = this.get();
                this.contextMenuRef = new WeakReference<ContextMenu>(referent);
                if (referent != null) {
                    referent.setShowRelativeToWindow(true);
                    ControlAcceleratorSupport.addAcceleratorsIntoScene(referent.getItems(), Control.this);
                }
            }
        };
        ControlHelper.initHelper(this);
        this.currentSkinClassName = null;
        this.skinCreationLocked = false;
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.TRUE);
        this.addEventHandler(ContextMenuEvent.CONTEXT_MENU_REQUESTED, Control.contextMenuHandler);
    }
    
    @Override
    public boolean isResizable() {
        return true;
    }
    
    @Override
    protected double computeMinWidth(final double n) {
        if (this.skinBase != null) {
            return this.skinBase.computeMinWidth(n, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset());
        }
        final Node skinNode = this.getSkinNode();
        return (skinNode == null) ? 0.0 : skinNode.minWidth(n);
    }
    
    @Override
    protected double computeMinHeight(final double n) {
        if (this.skinBase != null) {
            return this.skinBase.computeMinHeight(n, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset());
        }
        final Node skinNode = this.getSkinNode();
        return (skinNode == null) ? 0.0 : skinNode.minHeight(n);
    }
    
    @Override
    protected double computeMaxWidth(final double n) {
        if (this.skinBase != null) {
            return this.skinBase.computeMaxWidth(n, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset());
        }
        final Node skinNode = this.getSkinNode();
        return (skinNode == null) ? 0.0 : skinNode.maxWidth(n);
    }
    
    @Override
    protected double computeMaxHeight(final double n) {
        if (this.skinBase != null) {
            return this.skinBase.computeMaxHeight(n, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset());
        }
        final Node skinNode = this.getSkinNode();
        return (skinNode == null) ? 0.0 : skinNode.maxHeight(n);
    }
    
    @Override
    protected double computePrefWidth(final double n) {
        if (this.skinBase != null) {
            return this.skinBase.computePrefWidth(n, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset());
        }
        final Node skinNode = this.getSkinNode();
        return (skinNode == null) ? 0.0 : skinNode.prefWidth(n);
    }
    
    @Override
    protected double computePrefHeight(final double n) {
        if (this.skinBase != null) {
            return this.skinBase.computePrefHeight(n, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset());
        }
        final Node skinNode = this.getSkinNode();
        return (skinNode == null) ? 0.0 : skinNode.prefHeight(n);
    }
    
    @Override
    public double getBaselineOffset() {
        if (this.skinBase != null) {
            return this.skinBase.computeBaselineOffset(this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset());
        }
        final Node skinNode = this.getSkinNode();
        return (skinNode == null) ? 0.0 : skinNode.getBaselineOffset();
    }
    
    @Override
    protected void layoutChildren() {
        if (this.skinBase != null) {
            final double snappedLeftInset = this.snappedLeftInset();
            final double snappedTopInset = this.snappedTopInset();
            this.skinBase.layoutChildren(snappedLeftInset, snappedTopInset, this.snapSizeX(this.getWidth()) - snappedLeftInset - this.snappedRightInset(), this.snapSizeY(this.getHeight()) - snappedTopInset - this.snappedBottomInset());
        }
        else {
            final Node skinNode = this.getSkinNode();
            if (skinNode != null) {
                skinNode.resizeRelocate(0.0, 0.0, this.getWidth(), this.getHeight());
            }
        }
    }
    
    protected Skin<?> createDefaultSkin() {
        return null;
    }
    
    ObservableList<Node> getControlChildren() {
        return this.getChildren();
    }
    
    private Node getSkinNode() {
        assert this.skinBase == null;
        final Skin<?> skin = this.getSkin();
        return (skin == null) ? null : skin.getNode();
    }
    
    StringProperty skinClassNameProperty() {
        if (this.skinClassName == null) {
            this.skinClassName = new StyleableStringProperty() {
                @Override
                public void set(final String s) {
                    if (s == null || s.isEmpty() || s.equals(this.get())) {
                        return;
                    }
                    super.set(s);
                }
                
                public void invalidated() {
                    if (this.get() != null && !this.get().equals(Control.this.currentSkinClassName)) {
                        Control.loadSkinClass(Control.this, Control.this.skinClassName.get());
                    }
                }
                
                @Override
                public Object getBean() {
                    return Control.this;
                }
                
                @Override
                public String getName() {
                    return "skinClassName";
                }
                
                @Override
                public CssMetaData<Control, String> getCssMetaData() {
                    return StyleableProperties.SKIN;
                }
            };
        }
        return this.skinClassName;
    }
    
    static void loadSkinClass(final Skinnable skinnable, final String s) {
        if (s == null || s.isEmpty()) {
            final String s2 = invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/Skinnable;)Ljava/lang/String;, skinnable);
            final ObservableList<CssParser.ParseError> errors = StyleManager.getErrors();
            if (errors != null) {
                errors.add(new CssParser.ParseError(s2));
            }
            Logging.getControlsLogger().severe(s2);
            return;
        }
        try {
            final Class<?> loadClass = loadClass(s, skinnable);
            if (!Skin.class.isAssignableFrom(loadClass)) {
                final String s3 = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/control/Skinnable;)Ljava/lang/String;, s, skinnable);
                final ObservableList<CssParser.ParseError> errors2 = StyleManager.getErrors();
                if (errors2 != null) {
                    errors2.add(new CssParser.ParseError(s3));
                }
                Logging.getControlsLogger().severe(s3);
                return;
            }
            final Constructor[] constructors = loadClass.getConstructors();
            Constructor<Skin<?>> constructor = null;
            for (final Constructor constructor2 : constructors) {
                final Class[] parameterTypes = constructor2.getParameterTypes();
                if (parameterTypes.length == 1 && Skinnable.class.isAssignableFrom(parameterTypes[0])) {
                    constructor = (Constructor<Skin<?>>)constructor2;
                    break;
                }
            }
            if (constructor == null) {
                final String s4 = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/control/Skinnable;Ljava/lang/String;)Ljava/lang/String;, s, skinnable, s);
                final ObservableList<CssParser.ParseError> errors3 = StyleManager.getErrors();
                if (errors3 != null) {
                    errors3.add(new CssParser.ParseError(s4));
                }
                Logging.getControlsLogger().severe(s4);
            }
            else {
                skinnable.skinProperty().set(constructor.newInstance(skinnable));
            }
        }
        catch (InvocationTargetException ex) {
            final String s5 = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/control/Skinnable;)Ljava/lang/String;, s, skinnable);
            final ObservableList<CssParser.ParseError> errors4 = StyleManager.getErrors();
            if (errors4 != null) {
                errors4.add(new CssParser.ParseError(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s5, ex.getLocalizedMessage())));
            }
            Logging.getControlsLogger().severe(s5, ex.getCause());
        }
        catch (Exception ex2) {
            final String s6 = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/control/Skinnable;)Ljava/lang/String;, s, skinnable);
            final ObservableList<CssParser.ParseError> errors5 = StyleManager.getErrors();
            if (errors5 != null) {
                errors5.add(new CssParser.ParseError(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s6, ex2.getLocalizedMessage())));
            }
            Logging.getControlsLogger().severe(s6, ex2);
        }
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public final List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        if (this.styleableProperties == null) {
            final HashMap<String, CssMetaData<? extends Styleable, ?>> hashMap = new HashMap<String, CssMetaData<? extends Styleable, ?>>();
            final List<CssMetaData<? extends Styleable, ?>> controlCssMetaData = this.getControlCssMetaData();
            for (int i = 0; i < ((controlCssMetaData != null) ? controlCssMetaData.size() : 0); ++i) {
                final CssMetaData<? extends Styleable, ?> cssMetaData = controlCssMetaData.get(i);
                if (cssMetaData != null) {
                    hashMap.put(cssMetaData.getProperty(), cssMetaData);
                }
            }
            final List<CssMetaData<? extends Styleable, ?>> list = (this.skinBase != null) ? this.skinBase.getCssMetaData() : null;
            for (int j = 0; j < ((list != null) ? list.size() : 0); ++j) {
                final CssMetaData<? extends Styleable, ?> cssMetaData2 = list.get(j);
                if (cssMetaData2 != null) {
                    hashMap.put(cssMetaData2.getProperty(), cssMetaData2);
                }
            }
            (this.styleableProperties = new ArrayList<CssMetaData<? extends Styleable, ?>>()).addAll(hashMap.values());
        }
        return this.styleableProperties;
    }
    
    protected List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    private void doProcessCSS() {
        ControlHelper.superProcessCSS(this);
        if (this.getSkin() == null) {
            if (this.skinCreationLocked) {
                return;
            }
            try {
                this.skinCreationLocked = true;
                final Skin<?> defaultSkin = this.createDefaultSkin();
                if (defaultSkin != null) {
                    this.skinProperty().set(defaultSkin);
                    ControlHelper.superProcessCSS(this);
                }
                else {
                    final String s = invokedynamic(makeConcatWithConstants:(Ljavafx/scene/control/Control;)Ljava/lang/String;, this);
                    final ObservableList<CssParser.ParseError> errors = StyleManager.getErrors();
                    if (errors != null) {
                        errors.add(new CssParser.ParseError(s));
                    }
                    Logging.getControlsLogger().severe(s);
                }
            }
            finally {
                this.skinCreationLocked = false;
            }
        }
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.TRUE;
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case HELP: {
                final String accessibleHelp = this.getAccessibleHelp();
                if (accessibleHelp != null && !accessibleHelp.isEmpty()) {
                    return accessibleHelp;
                }
                final Tooltip tooltip = this.getTooltip();
                return (tooltip == null) ? "" : tooltip.getText();
            }
            default: {
                if (this.skinBase != null) {
                    final Object queryAccessibleAttribute = this.skinBase.queryAccessibleAttribute(accessibleAttribute, array);
                    if (queryAccessibleAttribute != null) {
                        return queryAccessibleAttribute;
                    }
                }
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        if (this.skinBase != null) {
            this.skinBase.executeAccessibleAction(accessibleAction, array);
        }
        super.executeAccessibleAction(accessibleAction, array);
    }
    
    static {
        ControlHelper.setControlAccessor(new ControlHelper.ControlAccessor() {
            @Override
            public void doProcessCSS(final Node node) {
                ((Control)node).doProcessCSS();
            }
            
            @Override
            public StringProperty skinClassNameProperty(final Control control) {
                return control.skinClassNameProperty();
            }
        });
        if (Application.getUserAgentStylesheet() == null) {
            PlatformImpl.setDefaultPlatformUserAgentStylesheet();
        }
        final Control control;
        Control control2;
        contextMenuHandler = (contextMenuEvent -> {
            if (!contextMenuEvent.isConsumed()) {
                contextMenuEvent.getSource();
                if (control instanceof Control) {
                    control2 = control;
                    if (control2.getContextMenu() != null) {
                        control2.getContextMenu().show(control2, contextMenuEvent.getScreenX(), contextMenuEvent.getScreenY());
                        contextMenuEvent.consume();
                    }
                }
            }
        });
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Control, String> SKIN;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            SKIN = new CssMetaData<Control, String>((StyleConverter)StringConverter.getInstance()) {
                @Override
                public boolean isSettable(final Control control) {
                    return control.skin == null || !control.skin.isBound();
                }
                
                @Override
                public StyleableProperty<String> getStyleableProperty(final Control control) {
                    return (StyleableProperty<String>)control.skinClassNameProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Region.getClassCssMetaData());
            list.add(StyleableProperties.SKIN);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
