// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import com.sun.javafx.scene.control.skin.resources.ControlResources;
import javafx.beans.NamedArg;

public final class ButtonType
{
    public static final ButtonType APPLY;
    public static final ButtonType OK;
    public static final ButtonType CANCEL;
    public static final ButtonType CLOSE;
    public static final ButtonType YES;
    public static final ButtonType NO;
    public static final ButtonType FINISH;
    public static final ButtonType NEXT;
    public static final ButtonType PREVIOUS;
    private final String key;
    private final String text;
    private final ButtonBar.ButtonData buttonData;
    
    public ButtonType(@NamedArg("text") final String s) {
        this(s, ButtonBar.ButtonData.OTHER);
    }
    
    public ButtonType(@NamedArg("text") final String s, @NamedArg("buttonData") final ButtonBar.ButtonData buttonData) {
        this(null, s, buttonData);
    }
    
    private ButtonType(final String key, final String text, final ButtonBar.ButtonData buttonData) {
        this.key = key;
        this.text = text;
        this.buttonData = buttonData;
    }
    
    public final ButtonBar.ButtonData getButtonData() {
        return this.buttonData;
    }
    
    public final String getText() {
        if (this.text == null && this.key != null) {
            return ControlResources.getString(this.key);
        }
        return this.text;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/control/ButtonBar$ButtonData;)Ljava/lang/String;, this.getText(), this.getButtonData());
    }
    
    static {
        APPLY = new ButtonType("Dialog.apply.button", null, ButtonBar.ButtonData.APPLY);
        OK = new ButtonType("Dialog.ok.button", null, ButtonBar.ButtonData.OK_DONE);
        CANCEL = new ButtonType("Dialog.cancel.button", null, ButtonBar.ButtonData.CANCEL_CLOSE);
        CLOSE = new ButtonType("Dialog.close.button", null, ButtonBar.ButtonData.CANCEL_CLOSE);
        YES = new ButtonType("Dialog.yes.button", null, ButtonBar.ButtonData.YES);
        NO = new ButtonType("Dialog.no.button", null, ButtonBar.ButtonData.NO);
        FINISH = new ButtonType("Dialog.finish.button", null, ButtonBar.ButtonData.FINISH);
        NEXT = new ButtonType("Dialog.next.button", null, ButtonBar.ButtonData.NEXT_FORWARD);
        PREVIOUS = new ButtonType("Dialog.previous.button", null, ButtonBar.ButtonData.BACK_PREVIOUS);
    }
}
