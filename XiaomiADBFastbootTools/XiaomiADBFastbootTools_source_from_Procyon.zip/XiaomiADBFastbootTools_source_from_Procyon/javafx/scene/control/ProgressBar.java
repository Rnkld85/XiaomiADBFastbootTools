// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.geometry.Orientation;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.skin.ProgressBarSkin;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;

public class ProgressBar extends ProgressIndicator
{
    private static final String DEFAULT_STYLE_CLASS = "progress-bar";
    
    public ProgressBar() {
        this(-1.0);
    }
    
    public ProgressBar(final double progress) {
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
        this.setProgress(progress);
        this.getStyleClass().setAll("progress-bar");
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ProgressBarSkin(this);
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case ORIENTATION: {
                return Orientation.HORIZONTAL;
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
}
