// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.property.ObjectPropertyBase;
import javafx.event.Event;
import javafx.beans.Observable;
import javafx.scene.control.skin.TableColumnHeader;
import javafx.scene.layout.Pane;
import javafx.scene.control.skin.NestedTableColumnHeader;
import javafx.scene.control.skin.TableHeaderRow;
import javafx.scene.control.skin.TableViewSkin;
import javafx.scene.Node;
import java.util.Collections;
import javafx.css.CssMetaData;
import javafx.css.Styleable;
import javafx.beans.property.ReadOnlyObjectProperty;
import java.util.Iterator;
import java.util.List;
import javafx.collections.ObservableMap;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.beans.value.WritableValue;
import javafx.beans.value.ObservableValue;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.ObservableList;
import javafx.collections.WeakListChangeListener;
import javafx.collections.ListChangeListener;
import javafx.event.EventHandler;
import javafx.util.Callback;
import javafx.event.EventType;
import javafx.event.EventTarget;

public class TableColumn<S, T> extends TableColumnBase<S, T> implements EventTarget
{
    private static final EventType<?> EDIT_ANY_EVENT;
    private static final EventType<?> EDIT_START_EVENT;
    private static final EventType<?> EDIT_CANCEL_EVENT;
    private static final EventType<?> EDIT_COMMIT_EVENT;
    public static final Callback<TableColumn<?, ?>, TableCell<?, ?>> DEFAULT_CELL_FACTORY;
    private EventHandler<CellEditEvent<S, T>> DEFAULT_EDIT_COMMIT_HANDLER;
    private ListChangeListener<TableColumn<S, ?>> columnsListener;
    private WeakListChangeListener<TableColumn<S, ?>> weakColumnsListener;
    private final ObservableList<TableColumn<S, ?>> columns;
    private ReadOnlyObjectWrapper<TableView<S>> tableView;
    private ObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>> cellValueFactory;
    private final ObjectProperty<Callback<TableColumn<S, T>, TableCell<S, T>>> cellFactory;
    private ObjectProperty<SortType> sortType;
    private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditStart;
    private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCommit;
    private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCancel;
    private static final String DEFAULT_STYLE_CLASS = "table-column";
    
    public static <S, T> EventType<CellEditEvent<S, T>> editAnyEvent() {
        return (EventType<CellEditEvent<S, T>>)TableColumn.EDIT_ANY_EVENT;
    }
    
    public static <S, T> EventType<CellEditEvent<S, T>> editStartEvent() {
        return (EventType<CellEditEvent<S, T>>)TableColumn.EDIT_START_EVENT;
    }
    
    public static <S, T> EventType<CellEditEvent<S, T>> editCancelEvent() {
        return (EventType<CellEditEvent<S, T>>)TableColumn.EDIT_CANCEL_EVENT;
    }
    
    public static <S, T> EventType<CellEditEvent<S, T>> editCommitEvent() {
        return (EventType<CellEditEvent<S, T>>)TableColumn.EDIT_COMMIT_EVENT;
    }
    
    public TableColumn() {
        final List<S> list;
        final int n;
        final WritableValue<T> writableValue;
        this.DEFAULT_EDIT_COMMIT_HANDLER = (cellEditEvent -> {
            cellEditEvent.getTablePosition().getRow();
            cellEditEvent.getTableView().getItems();
            if (list == null || n < 0 || n >= list.size()) {
                return;
            }
            else {
                this.getCellObservableValue(list.get(n));
                if (writableValue instanceof WritableValue) {
                    writableValue.setValue(cellEditEvent.getNewValue());
                }
                return;
            }
        });
        final Iterator<TableColumn> iterator;
        TableColumn tableColumn;
        final Iterator<TableColumn> iterator2;
        this.columnsListener = (change -> {
            while (change.next()) {
                change.getRemoved().iterator();
                while (iterator.hasNext()) {
                    tableColumn = iterator.next();
                    if (this.getColumns().contains(tableColumn)) {
                        continue;
                    }
                    else {
                        tableColumn.setTableView(null);
                        tableColumn.setParentColumn(null);
                    }
                }
                change.getAddedSubList().iterator();
                while (iterator2.hasNext()) {
                    iterator2.next().setTableView(this.getTableView());
                }
                this.updateColumnWidths();
            }
            return;
        });
        this.weakColumnsListener = new WeakListChangeListener<TableColumn<S, ?>>(this.columnsListener);
        this.columns = FXCollections.observableArrayList();
        this.tableView = new ReadOnlyObjectWrapper<TableView<S>>(this, "tableView");
        this.cellFactory = new SimpleObjectProperty<Callback<TableColumn<S, T>, TableCell<S, T>>>((Object)this, "cellFactory", (Callback)TableColumn.DEFAULT_CELL_FACTORY) {
            @Override
            protected void invalidated() {
                final TableView<S> tableView = TableColumn.this.getTableView();
                if (tableView == null) {
                    return;
                }
                final ObservableMap<Object, Object> properties = tableView.getProperties();
                if (properties.containsKey("recreateKey")) {
                    properties.remove("recreateKey");
                }
                properties.put("recreateKey", Boolean.TRUE);
            }
        };
        this.getStyleClass().add("table-column");
        this.setOnEditCommit(this.DEFAULT_EDIT_COMMIT_HANDLER);
        this.getColumns().addListener(this.weakColumnsListener);
        final Iterator<TableColumn> iterator3;
        this.tableViewProperty().addListener(p0 -> {
            this.getColumns().iterator();
            while (iterator3.hasNext()) {
                iterator3.next().setTableView(this.getTableView());
            }
        });
    }
    
    public TableColumn(final String text) {
        this();
        this.setText(text);
    }
    
    public final ReadOnlyObjectProperty<TableView<S>> tableViewProperty() {
        return this.tableView.getReadOnlyProperty();
    }
    
    final void setTableView(final TableView<S> tableView) {
        this.tableView.set(tableView);
    }
    
    public final TableView<S> getTableView() {
        return this.tableView.get();
    }
    
    public final void setCellValueFactory(final Callback<CellDataFeatures<S, T>, ObservableValue<T>> callback) {
        this.cellValueFactoryProperty().set(callback);
    }
    
    public final Callback<CellDataFeatures<S, T>, ObservableValue<T>> getCellValueFactory() {
        return (this.cellValueFactory == null) ? null : this.cellValueFactory.get();
    }
    
    public final ObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>> cellValueFactoryProperty() {
        if (this.cellValueFactory == null) {
            this.cellValueFactory = new SimpleObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>>(this, "cellValueFactory");
        }
        return this.cellValueFactory;
    }
    
    public final void setCellFactory(final Callback<TableColumn<S, T>, TableCell<S, T>> callback) {
        this.cellFactory.set(callback);
    }
    
    public final Callback<TableColumn<S, T>, TableCell<S, T>> getCellFactory() {
        return this.cellFactory.get();
    }
    
    public final ObjectProperty<Callback<TableColumn<S, T>, TableCell<S, T>>> cellFactoryProperty() {
        return this.cellFactory;
    }
    
    public final ObjectProperty<SortType> sortTypeProperty() {
        if (this.sortType == null) {
            this.sortType = new SimpleObjectProperty<SortType>(this, "sortType", SortType.ASCENDING);
        }
        return this.sortType;
    }
    
    public final void setSortType(final SortType sortType) {
        this.sortTypeProperty().set(sortType);
    }
    
    public final SortType getSortType() {
        return (this.sortType == null) ? SortType.ASCENDING : this.sortType.get();
    }
    
    public final void setOnEditStart(final EventHandler<CellEditEvent<S, T>> eventHandler) {
        this.onEditStartProperty().set(eventHandler);
    }
    
    public final EventHandler<CellEditEvent<S, T>> getOnEditStart() {
        return (this.onEditStart == null) ? null : this.onEditStart.get();
    }
    
    public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditStartProperty() {
        if (this.onEditStart == null) {
            this.onEditStart = new SimpleObjectProperty<EventHandler<CellEditEvent<S, T>>>(this, "onEditStart") {
                @Override
                protected void invalidated() {
                    TableColumn.this.eventHandlerManager.setEventHandler(TableColumn.editStartEvent(), ((ObjectPropertyBase<EventHandler<? super CellEditEvent<Object, Object>>>)this).get());
                }
            };
        }
        return this.onEditStart;
    }
    
    public final void setOnEditCommit(final EventHandler<CellEditEvent<S, T>> eventHandler) {
        this.onEditCommitProperty().set(eventHandler);
    }
    
    public final EventHandler<CellEditEvent<S, T>> getOnEditCommit() {
        return (this.onEditCommit == null) ? null : this.onEditCommit.get();
    }
    
    public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCommitProperty() {
        if (this.onEditCommit == null) {
            this.onEditCommit = new SimpleObjectProperty<EventHandler<CellEditEvent<S, T>>>(this, "onEditCommit") {
                @Override
                protected void invalidated() {
                    TableColumn.this.eventHandlerManager.setEventHandler(TableColumn.editCommitEvent(), ((ObjectPropertyBase<EventHandler<? super CellEditEvent<Object, Object>>>)this).get());
                }
            };
        }
        return this.onEditCommit;
    }
    
    public final void setOnEditCancel(final EventHandler<CellEditEvent<S, T>> eventHandler) {
        this.onEditCancelProperty().set(eventHandler);
    }
    
    public final EventHandler<CellEditEvent<S, T>> getOnEditCancel() {
        return (this.onEditCancel == null) ? null : this.onEditCancel.get();
    }
    
    public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCancelProperty() {
        if (this.onEditCancel == null) {
            this.onEditCancel = new SimpleObjectProperty<EventHandler<CellEditEvent<S, T>>>(this, "onEditCancel") {
                @Override
                protected void invalidated() {
                    TableColumn.this.eventHandlerManager.setEventHandler(TableColumn.editCancelEvent(), ((ObjectPropertyBase<EventHandler<? super CellEditEvent<Object, Object>>>)this).get());
                }
            };
        }
        return this.onEditCancel;
    }
    
    @Override
    public final ObservableList<TableColumn<S, ?>> getColumns() {
        return this.columns;
    }
    
    @Override
    public final ObservableValue<T> getCellObservableValue(final int n) {
        if (n < 0) {
            return null;
        }
        final TableView<Object> tableView = (TableView<Object>)this.getTableView();
        if (tableView == null || tableView.getItems() == null) {
            return null;
        }
        final ObservableList<Object> items = (ObservableList<Object>)tableView.getItems();
        if (n >= items.size()) {
            return null;
        }
        return this.getCellObservableValue((S)items.get(n));
    }
    
    @Override
    public final ObservableValue<T> getCellObservableValue(final S n) {
        final Callback<CellDataFeatures<S, T>, ObservableValue<T>> cellValueFactory = this.getCellValueFactory();
        if (cellValueFactory == null) {
            return null;
        }
        final TableView<S> tableView = (TableView<S>)this.getTableView();
        if (tableView == null) {
            return null;
        }
        return cellValueFactory.call(new CellDataFeatures<S, T>((TableView<Object>)tableView, (TableColumn<Object, Object>)this, n));
    }
    
    @Override
    public String getTypeSelector() {
        return "TableColumn";
    }
    
    @Override
    public Styleable getStyleableParent() {
        return this.getTableView();
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return Collections.emptyList();
    }
    
    @Override
    public Node getStyleableNode() {
        if (!(this.getTableView().getSkin() instanceof TableViewSkin)) {
            return null;
        }
        final TableViewSkin tableViewSkin = (TableViewSkin)this.getTableView().getSkin();
        Pane pane = null;
        for (final Node node : tableViewSkin.getChildren()) {
            if (node instanceof TableHeaderRow) {
                pane = (TableHeaderRow)node;
            }
        }
        TableColumnHeader tableColumnHeader = null;
        for (final Node node2 : pane.getChildren()) {
            if (node2 instanceof NestedTableColumnHeader) {
                tableColumnHeader = (NestedTableColumnHeader)node2;
            }
        }
        return this.scan(tableColumnHeader);
    }
    
    private TableColumnHeader scan(final TableColumnHeader tableColumnHeader) {
        if (this.equals(tableColumnHeader.getTableColumn())) {
            return tableColumnHeader;
        }
        if (tableColumnHeader instanceof NestedTableColumnHeader) {
            final NestedTableColumnHeader nestedTableColumnHeader = (NestedTableColumnHeader)tableColumnHeader;
            for (int i = 0; i < nestedTableColumnHeader.getColumnHeaders().size(); ++i) {
                final TableColumnHeader scan = this.scan(nestedTableColumnHeader.getColumnHeaders().get(i));
                if (scan != null) {
                    return scan;
                }
            }
        }
        return null;
    }
    
    static {
        EDIT_ANY_EVENT = new EventType<Object>(Event.ANY, "TABLE_COLUMN_EDIT");
        EDIT_START_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_START");
        EDIT_CANCEL_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_CANCEL");
        EDIT_COMMIT_EVENT = new EventType<Object>(editAnyEvent(), "EDIT_COMMIT");
        DEFAULT_CELL_FACTORY = new Callback<TableColumn<?, ?>, TableCell<?, ?>>() {
            @Override
            public TableCell<?, ?> call(final TableColumn<?, ?> tableColumn) {
                return new TableCell<Object, Object>() {
                    @Override
                    protected void updateItem(final Object o, final boolean b) {
                        if (o == ((Cell<Object>)this).getItem()) {
                            return;
                        }
                        super.updateItem((T)o, b);
                        if (o == null) {
                            super.setText(null);
                            super.setGraphic(null);
                        }
                        else if (o instanceof Node) {
                            super.setText(null);
                            super.setGraphic((Node)o);
                        }
                        else {
                            super.setText(o.toString());
                            super.setGraphic(null);
                        }
                    }
                };
            }
        };
    }
    
    public static class CellDataFeatures<S, T>
    {
        private final TableView<S> tableView;
        private final TableColumn<S, T> tableColumn;
        private final S value;
        
        public CellDataFeatures(final TableView<S> tableView, final TableColumn<S, T> tableColumn, final S value) {
            this.tableView = tableView;
            this.tableColumn = tableColumn;
            this.value = value;
        }
        
        public S getValue() {
            return this.value;
        }
        
        public TableColumn<S, T> getTableColumn() {
            return this.tableColumn;
        }
        
        public TableView<S> getTableView() {
            return this.tableView;
        }
    }
    
    public static class CellEditEvent<S, T> extends Event
    {
        private static final long serialVersionUID = -609964441682677579L;
        public static final EventType<?> ANY;
        private final T newValue;
        private final transient TablePosition<S, T> pos;
        
        public CellEditEvent(final TableView<S> tableView, final TablePosition<S, T> pos, final EventType<CellEditEvent<S, T>> eventType, final T newValue) {
            super(tableView, Event.NULL_SOURCE_TARGET, eventType);
            if (tableView == null) {
                throw new NullPointerException("TableView can not be null");
            }
            this.pos = pos;
            this.newValue = newValue;
        }
        
        public TableView<S> getTableView() {
            return this.pos.getTableView();
        }
        
        public TableColumn<S, T> getTableColumn() {
            return this.pos.getTableColumn();
        }
        
        public TablePosition<S, T> getTablePosition() {
            return this.pos;
        }
        
        public T getNewValue() {
            return this.newValue;
        }
        
        public T getOldValue() {
            final S rowValue = this.getRowValue();
            if (rowValue == null || this.pos.getTableColumn() == null) {
                return null;
            }
            return (T)this.pos.getTableColumn().getCellData(rowValue);
        }
        
        public S getRowValue() {
            final ObservableList<S> items = this.getTableView().getItems();
            if (items == null) {
                return null;
            }
            final int row = this.pos.getRow();
            if (row < 0 || row >= items.size()) {
                return null;
            }
            return (S)items.get(row);
        }
        
        static {
            ANY = TableColumn.EDIT_ANY_EVENT;
        }
    }
    
    public enum SortType
    {
        ASCENDING, 
        DESCENDING;
    }
}
