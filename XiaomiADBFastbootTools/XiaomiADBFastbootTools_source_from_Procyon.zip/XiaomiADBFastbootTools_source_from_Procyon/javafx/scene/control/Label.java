// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.value.ObservableValue;
import javafx.scene.control.skin.LabelSkin;
import javafx.beans.property.ObjectPropertyBase;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.scene.AccessibleRole;
import com.sun.javafx.scene.NodeHelper;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ChangeListener;

public class Label extends Labeled
{
    private ChangeListener<Boolean> mnemonicStateListener;
    private ObjectProperty<Node> labelFor;
    
    public Label() {
        this.mnemonicStateListener = ((p0, p1, value) -> NodeHelper.showMnemonicsProperty(this).setValue(value));
        this.initialize();
    }
    
    public Label(final String s) {
        super(s);
        this.mnemonicStateListener = ((p0, p1, value) -> NodeHelper.showMnemonicsProperty(this).setValue(value));
        this.initialize();
    }
    
    public Label(final String s, final Node node) {
        super(s, node);
        this.mnemonicStateListener = ((p0, p1, value) -> NodeHelper.showMnemonicsProperty(this).setValue(value));
        this.initialize();
    }
    
    private void initialize() {
        this.getStyleClass().setAll("label");
        this.setAccessibleRole(AccessibleRole.TEXT);
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
    }
    
    public ObjectProperty<Node> labelForProperty() {
        if (this.labelFor == null) {
            this.labelFor = new ObjectPropertyBase<Node>() {
                Node oldValue = null;
                
                @Override
                protected void invalidated() {
                    if (this.oldValue != null) {
                        NodeHelper.getNodeAccessor().setLabeledBy(this.oldValue, null);
                        NodeHelper.showMnemonicsProperty(this.oldValue).removeListener(Label.this.mnemonicStateListener);
                    }
                    final Node oldValue = this.get();
                    if (oldValue != null) {
                        NodeHelper.getNodeAccessor().setLabeledBy(oldValue, Label.this);
                        NodeHelper.showMnemonicsProperty(oldValue).addListener(Label.this.mnemonicStateListener);
                        NodeHelper.setShowMnemonics(Label.this, NodeHelper.isShowMnemonics(oldValue));
                    }
                    else {
                        NodeHelper.setShowMnemonics(Label.this, false);
                    }
                    this.oldValue = oldValue;
                }
                
                @Override
                public Object getBean() {
                    return Label.this;
                }
                
                @Override
                public String getName() {
                    return "labelFor";
                }
            };
        }
        return this.labelFor;
    }
    
    public final void setLabelFor(final Node value) {
        this.labelForProperty().setValue(value);
    }
    
    public final Node getLabelFor() {
        return (this.labelFor == null) ? null : this.labelFor.getValue();
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new LabelSkin(this);
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
}
