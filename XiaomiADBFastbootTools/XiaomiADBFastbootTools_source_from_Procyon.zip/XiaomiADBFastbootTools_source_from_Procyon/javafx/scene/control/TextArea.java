// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.css.StyleableProperty;
import javafx.css.StyleConverter;
import javafx.css.converter.SizeConverter;
import com.sun.javafx.collections.NonIterableChange;
import java.util.AbstractList;
import javafx.collections.ListChangeListener;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;
import java.util.Collection;
import java.util.Collections;
import com.sun.javafx.collections.ListListenerHelper;
import java.util.ArrayList;
import com.sun.javafx.binding.ExpressionHelper;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.TextAreaSkin;
import javafx.collections.ObservableList;
import javafx.scene.AccessibleRole;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.css.StyleableIntegerProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableBooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.BooleanProperty;

public class TextArea extends TextInputControl
{
    public static final int DEFAULT_PREF_COLUMN_COUNT = 40;
    public static final int DEFAULT_PREF_ROW_COUNT = 10;
    private static final int DEFAULT_PARAGRAPH_CAPACITY = 32;
    private BooleanProperty wrapText;
    private IntegerProperty prefColumnCount;
    private IntegerProperty prefRowCount;
    private DoubleProperty scrollTop;
    private DoubleProperty scrollLeft;
    
    public TextArea() {
        this("");
    }
    
    public TextArea(final String text) {
        super(new TextAreaContent());
        this.wrapText = new StyleableBooleanProperty(false) {
            @Override
            public Object getBean() {
                return TextArea.this;
            }
            
            @Override
            public String getName() {
                return "wrapText";
            }
            
            @Override
            public CssMetaData<TextArea, Boolean> getCssMetaData() {
                return StyleableProperties.WRAP_TEXT;
            }
        };
        this.prefColumnCount = new StyleableIntegerProperty(40) {
            private int oldValue = this.get();
            
            @Override
            protected void invalidated() {
                final int value = this.get();
                if (value < 0) {
                    if (this.isBound()) {
                        this.unbind();
                    }
                    this.set(this.oldValue);
                    throw new IllegalArgumentException("value cannot be negative.");
                }
                this.oldValue = value;
            }
            
            @Override
            public CssMetaData<TextArea, Number> getCssMetaData() {
                return StyleableProperties.PREF_COLUMN_COUNT;
            }
            
            @Override
            public Object getBean() {
                return TextArea.this;
            }
            
            @Override
            public String getName() {
                return "prefColumnCount";
            }
        };
        this.prefRowCount = new StyleableIntegerProperty(10) {
            private int oldValue = this.get();
            
            @Override
            protected void invalidated() {
                final int value = this.get();
                if (value < 0) {
                    if (this.isBound()) {
                        this.unbind();
                    }
                    this.set(this.oldValue);
                    throw new IllegalArgumentException("value cannot be negative.");
                }
                this.oldValue = value;
            }
            
            @Override
            public CssMetaData<TextArea, Number> getCssMetaData() {
                return StyleableProperties.PREF_ROW_COUNT;
            }
            
            @Override
            public Object getBean() {
                return TextArea.this;
            }
            
            @Override
            public String getName() {
                return "prefRowCount";
            }
        };
        this.scrollTop = new SimpleDoubleProperty(this, "scrollTop", 0.0);
        this.scrollLeft = new SimpleDoubleProperty(this, "scrollLeft", 0.0);
        this.getStyleClass().add("text-area");
        this.setAccessibleRole(AccessibleRole.TEXT_AREA);
        this.setText(text);
    }
    
    @Override
    final void textUpdated() {
        this.setScrollTop(0.0);
        this.setScrollLeft(0.0);
    }
    
    public ObservableList<CharSequence> getParagraphs() {
        return ((TextAreaContent)this.getContent()).paragraphList;
    }
    
    public final BooleanProperty wrapTextProperty() {
        return this.wrapText;
    }
    
    public final boolean isWrapText() {
        return this.wrapText.getValue();
    }
    
    public final void setWrapText(final boolean b) {
        this.wrapText.setValue(b);
    }
    
    public final IntegerProperty prefColumnCountProperty() {
        return this.prefColumnCount;
    }
    
    public final int getPrefColumnCount() {
        return this.prefColumnCount.getValue();
    }
    
    public final void setPrefColumnCount(final int i) {
        this.prefColumnCount.setValue(i);
    }
    
    public final IntegerProperty prefRowCountProperty() {
        return this.prefRowCount;
    }
    
    public final int getPrefRowCount() {
        return this.prefRowCount.getValue();
    }
    
    public final void setPrefRowCount(final int i) {
        this.prefRowCount.setValue(i);
    }
    
    public final DoubleProperty scrollTopProperty() {
        return this.scrollTop;
    }
    
    public final double getScrollTop() {
        return this.scrollTop.getValue();
    }
    
    public final void setScrollTop(final double d) {
        this.scrollTop.setValue(d);
    }
    
    public final DoubleProperty scrollLeftProperty() {
        return this.scrollLeft;
    }
    
    public final double getScrollLeft() {
        return this.scrollLeft.getValue();
    }
    
    public final void setScrollLeft(final double d) {
        this.scrollLeft.setValue(d);
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new TextAreaSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    private static final class TextAreaContent implements Content
    {
        private ExpressionHelper<String> helper;
        private ArrayList<StringBuilder> paragraphs;
        private int contentLength;
        private ParagraphList paragraphList;
        private ListListenerHelper<CharSequence> listenerHelper;
        
        private TextAreaContent() {
            this.helper = null;
            this.paragraphs = new ArrayList<StringBuilder>();
            this.contentLength = 0;
            this.paragraphList = new ParagraphList();
            this.paragraphs.add(new StringBuilder(32));
            this.paragraphList.content = this;
        }
        
        @Override
        public String get(final int n, final int n2) {
            final int capacity = n2 - n;
            final StringBuilder sb = new StringBuilder(capacity);
            final int size = this.paragraphs.size();
            int i = 0;
            int n3 = n;
            while (i < size) {
                final int n4 = this.paragraphs.get(i).length() + 1;
                if (n3 < n4) {
                    break;
                }
                n3 -= n4;
                ++i;
            }
            StringBuilder sb2 = this.paragraphs.get(i);
            for (int j = 0; j < capacity; ++j) {
                if (n3 == sb2.length() && j < this.contentLength) {
                    sb.append('\n');
                    sb2 = this.paragraphs.get(++i);
                    n3 = 0;
                }
                else {
                    sb.append(sb2.charAt(n3++));
                }
            }
            return sb.toString();
        }
        
        @Override
        public void insert(final int i, String filterInput, final boolean b) {
            if (i < 0 || i > this.contentLength) {
                throw new IndexOutOfBoundsException();
            }
            if (filterInput == null) {
                throw new IllegalArgumentException();
            }
            filterInput = TextInputControl.filterInput(filterInput, false, false);
            final int length = filterInput.length();
            if (length > 0) {
                final ArrayList<StringBuilder> list = new ArrayList<StringBuilder>();
                StringBuilder s = new StringBuilder(32);
                for (int j = 0; j < length; ++j) {
                    final char char1 = filterInput.charAt(j);
                    if (char1 == '\n') {
                        list.add(s);
                        s = new StringBuilder(32);
                    }
                    else {
                        s.append(char1);
                    }
                }
                list.add(s);
                int size = this.paragraphs.size();
                int n = this.contentLength + 1;
                StringBuilder sb;
                do {
                    sb = this.paragraphs.get(--size);
                    n -= sb.length() + 1;
                } while (i < n);
                final int dstOffset = i - n;
                final int size2 = list.size();
                if (size2 == 1) {
                    sb.insert(dstOffset, s);
                    this.fireParagraphListChangeEvent(size, size + 1, (List<CharSequence>)Collections.singletonList(sb));
                }
                else {
                    final int length2 = sb.length();
                    final CharSequence subSequence = sb.subSequence(dstOffset, length2);
                    sb.delete(dstOffset, length2);
                    sb.insert(dstOffset, list.get(0));
                    s.append(subSequence);
                    this.fireParagraphListChangeEvent(size, size + 1, (List<CharSequence>)Collections.singletonList(sb));
                    this.paragraphs.addAll(size + 1, list.subList(1, size2));
                    this.fireParagraphListChangeEvent(size + 1, size + size2, Collections.EMPTY_LIST);
                }
                this.contentLength += length;
                if (b) {
                    ExpressionHelper.fireValueChangedEvent(this.helper);
                }
            }
        }
        
        @Override
        public void delete(final int i, final int j, final boolean b) {
            if (i > j) {
                throw new IllegalArgumentException();
            }
            if (i < 0 || j > this.contentLength) {
                throw new IndexOutOfBoundsException();
            }
            final int n = j - i;
            if (n > 0) {
                int size = this.paragraphs.size();
                int n2 = this.contentLength + 1;
                StringBuilder sb;
                do {
                    sb = this.paragraphs.get(--size);
                    n2 -= sb.length() + 1;
                } while (j < n2);
                final int n3 = size;
                final int n4 = n2;
                final StringBuilder o = sb;
                ++size;
                int n5 = n2 + (sb.length() + 1);
                StringBuilder sb2;
                do {
                    sb2 = this.paragraphs.get(--size);
                    n5 -= sb2.length() + 1;
                } while (i < n5);
                final int n6 = size;
                final int n7 = n5;
                final StringBuilder sb3 = sb2;
                if (n6 == n3) {
                    sb3.delete(i - n7, j - n7);
                    this.fireParagraphListChangeEvent(n6, n6 + 1, (List<CharSequence>)Collections.singletonList(sb3));
                }
                else {
                    final CharSequence subSequence = sb3.subSequence(0, i - n7);
                    o.delete(0, i + n - n4);
                    this.fireParagraphListChangeEvent(n3, n3 + 1, (List<CharSequence>)Collections.singletonList(o));
                    if (n3 - n6 > 0) {
                        final ArrayList list = new ArrayList<CharSequence>(this.paragraphs.subList(n6, n3));
                        this.paragraphs.subList(n6, n3).clear();
                        this.fireParagraphListChangeEvent(n6, n6, (List<CharSequence>)list);
                    }
                    o.insert(0, subSequence);
                    this.fireParagraphListChangeEvent(n6, n6 + 1, (List<CharSequence>)Collections.singletonList(sb3));
                }
                this.contentLength -= n;
                if (b) {
                    ExpressionHelper.fireValueChangedEvent(this.helper);
                }
            }
        }
        
        @Override
        public int length() {
            return this.contentLength;
        }
        
        @Override
        public String get() {
            return this.get(0, this.length());
        }
        
        @Override
        public void addListener(final ChangeListener<? super String> changeListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, changeListener);
        }
        
        @Override
        public void removeListener(final ChangeListener<? super String> changeListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, changeListener);
        }
        
        @Override
        public String getValue() {
            return this.get();
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, invalidationListener);
        }
        
        private void fireParagraphListChangeEvent(final int n, final int n2, final List<CharSequence> list) {
            ListListenerHelper.fireValueChangedEvent(this.listenerHelper, new ParagraphListChange(this.paragraphList, n, n2, list));
        }
    }
    
    private static final class ParagraphList extends AbstractList<CharSequence> implements ObservableList<CharSequence>
    {
        private TextAreaContent content;
        
        @Override
        public CharSequence get(final int index) {
            return this.content.paragraphs.get(index);
        }
        
        @Override
        public boolean addAll(final Collection<? extends CharSequence> collection) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean addAll(final CharSequence... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean setAll(final Collection<? extends CharSequence> collection) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean setAll(final CharSequence... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public int size() {
            return this.content.paragraphs.size();
        }
        
        @Override
        public void addListener(final ListChangeListener<? super CharSequence> listChangeListener) {
            this.content.listenerHelper = (ListListenerHelper<CharSequence>)ListListenerHelper.addListener((ListListenerHelper<Object>)this.content.listenerHelper, (ListChangeListener<? super Object>)listChangeListener);
        }
        
        @Override
        public void removeListener(final ListChangeListener<? super CharSequence> listChangeListener) {
            this.content.listenerHelper = (ListListenerHelper<CharSequence>)ListListenerHelper.removeListener((ListListenerHelper<Object>)this.content.listenerHelper, (ListChangeListener<? super Object>)listChangeListener);
        }
        
        @Override
        public boolean removeAll(final CharSequence... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean retainAll(final CharSequence... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public void remove(final int n, final int n2) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.content.listenerHelper = (ListListenerHelper<CharSequence>)ListListenerHelper.addListener((ListListenerHelper<Object>)this.content.listenerHelper, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.content.listenerHelper = (ListListenerHelper<CharSequence>)ListListenerHelper.removeListener((ListListenerHelper<Object>)this.content.listenerHelper, invalidationListener);
        }
    }
    
    private static final class ParagraphListChange extends NonIterableChange<CharSequence>
    {
        private List<CharSequence> removed;
        
        protected ParagraphListChange(final ObservableList<CharSequence> list, final int n, final int n2, final List<CharSequence> removed) {
            super(n, n2, list);
            this.removed = removed;
        }
        
        @Override
        public List<CharSequence> getRemoved() {
            return this.removed;
        }
        
        @Override
        protected int[] getPermutation() {
            return new int[0];
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<TextArea, Number> PREF_COLUMN_COUNT;
        private static final CssMetaData<TextArea, Number> PREF_ROW_COUNT;
        private static final CssMetaData<TextArea, Boolean> WRAP_TEXT;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            PREF_COLUMN_COUNT = new CssMetaData<TextArea, Number>((StyleConverter)SizeConverter.getInstance(), (Number)40) {
                @Override
                public boolean isSettable(final TextArea textArea) {
                    return !textArea.prefColumnCount.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TextArea textArea) {
                    return (StyleableProperty<Number>)textArea.prefColumnCountProperty();
                }
            };
            PREF_ROW_COUNT = new CssMetaData<TextArea, Number>((StyleConverter)SizeConverter.getInstance(), (Number)10) {
                @Override
                public boolean isSettable(final TextArea textArea) {
                    return !textArea.prefRowCount.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final TextArea textArea) {
                    return (StyleableProperty<Number>)textArea.prefRowCountProperty();
                }
            };
            WRAP_TEXT = new CssMetaData<TextArea, Boolean>((StyleConverter)StyleConverter.getBooleanConverter(), Boolean.valueOf(false)) {
                @Override
                public boolean isSettable(final TextArea textArea) {
                    return !textArea.wrapText.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final TextArea textArea) {
                    return (StyleableProperty<Boolean>)textArea.wrapTextProperty();
                }
            };
            final ArrayList<CssMetaData<TextArea, Number>> list = new ArrayList<CssMetaData<TextArea, Number>>((Collection<? extends CssMetaData<TextArea, Number>>)TextInputControl.getClassCssMetaData());
            list.add(StyleableProperties.PREF_COLUMN_COUNT);
            list.add(StyleableProperties.PREF_ROW_COUNT);
            list.add((CssMetaData<TextArea, Number>)StyleableProperties.WRAP_TEXT);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
