// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.stage.WindowEvent;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import java.util.List;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.scene.Node;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.stage.Modality;
import javafx.stage.Window;
import javafx.stage.StageStyle;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Region;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

class HeavyweightDialog extends FXDialog
{
    final Stage stage;
    private Scene scene;
    private final Parent DUMMY_ROOT;
    private final Dialog<?> dialog;
    private DialogPane dialogPane;
    private double prefX;
    private double prefY;
    
    HeavyweightDialog(final Dialog<?> dialog) {
        this.stage = new Stage() {
            @Override
            public void centerOnScreen() {
                if (HeavyweightDialog.this.getOwner() != null) {
                    HeavyweightDialog.this.positionStage();
                }
                else if (this.getWidth() > 0.0 && this.getHeight() > 0.0) {
                    super.centerOnScreen();
                }
            }
        };
        this.DUMMY_ROOT = new Region();
        this.prefX = Double.NaN;
        this.prefY = Double.NaN;
        this.dialog = dialog;
        this.stage.setResizable(false);
        this.stage.setOnCloseRequest(windowEvent -> {
            if (this.requestPermissionToClose(dialog)) {
                dialog.close();
            }
            else {
                windowEvent.consume();
            }
            return;
        });
        this.stage.addEventHandler(KeyEvent.KEY_PRESSED, keyEvent -> {
            if (keyEvent.getCode() == KeyCode.ESCAPE && !keyEvent.isConsumed() && this.requestPermissionToClose(dialog)) {
                dialog.close();
                keyEvent.consume();
            }
        });
    }
    
    @Override
    void initStyle(final StageStyle stageStyle) {
        this.stage.initStyle(stageStyle);
    }
    
    @Override
    StageStyle getStyle() {
        return this.stage.getStyle();
    }
    
    @Override
    public void initOwner(final Window window) {
        this.updateStageBindings(this.stage.getOwner(), window);
        this.stage.initOwner(window);
    }
    
    @Override
    public Window getOwner() {
        return this.stage.getOwner();
    }
    
    @Override
    public void initModality(final Modality modality) {
        this.stage.initModality((modality == null) ? Modality.APPLICATION_MODAL : modality);
    }
    
    @Override
    public Modality getModality() {
        return this.stage.getModality();
    }
    
    @Override
    public void setDialogPane(final DialogPane dialogPane) {
        this.dialogPane = dialogPane;
        if (this.scene == null) {
            this.scene = new Scene(dialogPane);
            this.stage.setScene(this.scene);
        }
        else {
            this.scene.setRoot(dialogPane);
        }
        dialogPane.autosize();
        this.stage.sizeToScene();
    }
    
    @Override
    public void show() {
        this.scene.setRoot(this.dialogPane);
        this.stage.centerOnScreen();
        this.stage.show();
    }
    
    @Override
    public void showAndWait() {
        this.scene.setRoot(this.dialogPane);
        this.stage.centerOnScreen();
        this.stage.showAndWait();
    }
    
    @Override
    public void close() {
        if (this.stage.isShowing()) {
            this.stage.hide();
        }
        if (this.scene != null) {
            this.scene.setRoot(this.DUMMY_ROOT);
        }
    }
    
    @Override
    public ReadOnlyBooleanProperty showingProperty() {
        return this.stage.showingProperty();
    }
    
    @Override
    public Window getWindow() {
        return this.stage;
    }
    
    @Override
    public Node getRoot() {
        return this.stage.getScene().getRoot();
    }
    
    @Override
    public double getX() {
        return this.stage.getX();
    }
    
    @Override
    public void setX(final double x) {
        this.stage.setX(x);
    }
    
    @Override
    public ReadOnlyDoubleProperty xProperty() {
        return this.stage.xProperty();
    }
    
    @Override
    public double getY() {
        return this.stage.getY();
    }
    
    @Override
    public void setY(final double y) {
        this.stage.setY(y);
    }
    
    @Override
    public ReadOnlyDoubleProperty yProperty() {
        return this.stage.yProperty();
    }
    
    @Override
    ReadOnlyDoubleProperty heightProperty() {
        return this.stage.heightProperty();
    }
    
    @Override
    void setHeight(final double height) {
        this.stage.setHeight(height);
    }
    
    @Override
    double getSceneHeight() {
        return (this.scene == null) ? 0.0 : this.scene.getHeight();
    }
    
    @Override
    ReadOnlyDoubleProperty widthProperty() {
        return this.stage.widthProperty();
    }
    
    @Override
    void setWidth(final double width) {
        this.stage.setWidth(width);
    }
    
    @Override
    BooleanProperty resizableProperty() {
        return this.stage.resizableProperty();
    }
    
    @Override
    StringProperty titleProperty() {
        return this.stage.titleProperty();
    }
    
    @Override
    ReadOnlyBooleanProperty focusedProperty() {
        return this.stage.focusedProperty();
    }
    
    @Override
    public void sizeToScene() {
        this.stage.sizeToScene();
    }
    
    private void positionStage() {
        final double x = this.getX();
        final double y = this.getY();
        if (!Double.isNaN(x) && !Double.isNaN(y) && Double.compare(x, this.prefX) != 0 && Double.compare(y, this.prefY) != 0) {
            this.setX(x);
            this.setY(y);
            return;
        }
        this.dialogPane.applyCss();
        this.dialogPane.layout();
        final Window owner = this.getOwner();
        final Scene scene = owner.getScene();
        final double y2 = scene.getY();
        final double prefWidth = this.dialogPane.prefWidth(-1.0);
        final double prefHeight = this.dialogPane.prefHeight(prefWidth);
        final double n = owner.getX() + scene.getWidth() / 2.0 - prefWidth / 2.0;
        final double n2 = owner.getY() + y2 / 2.0 + scene.getHeight() / 2.0 - prefHeight / 2.0;
        this.prefX = n;
        this.prefY = n2;
        this.setX(n);
        this.setY(n2);
    }
    
    private void updateStageBindings(final Window window, final Window window2) {
        final Scene scene = this.stage.getScene();
        if (window != null && window instanceof Stage) {
            final Stage stage = (Stage)window;
            Bindings.unbindContent(this.stage.getIcons(), stage.getIcons());
            final Scene scene2 = stage.getScene();
            if (this.scene != null && scene != null) {
                Bindings.unbindContent(scene.getStylesheets(), scene2.getStylesheets());
            }
        }
        if (window2 instanceof Stage) {
            final Stage stage2 = (Stage)window2;
            Bindings.bindContent(this.stage.getIcons(), stage2.getIcons());
            final Scene scene3 = stage2.getScene();
            if (this.scene != null && scene != null) {
                Bindings.bindContent(scene.getStylesheets(), scene3.getStylesheets());
            }
        }
    }
}
