// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.converter.BooleanConverter;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.scene.AccessibleAttribute;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.ScrollPaneSkin;
import javafx.geometry.BoundingBox;
import javafx.css.StyleableBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.scene.AccessibleRole;
import javafx.css.PseudoClass;
import javafx.geometry.Bounds;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.DefaultProperty;

@DefaultProperty("content")
public class ScrollPane extends Control
{
    private ObjectProperty<ScrollBarPolicy> hbarPolicy;
    private ObjectProperty<ScrollBarPolicy> vbarPolicy;
    private ObjectProperty<Node> content;
    private DoubleProperty hvalue;
    private DoubleProperty vvalue;
    private DoubleProperty hmin;
    private DoubleProperty vmin;
    private DoubleProperty hmax;
    private DoubleProperty vmax;
    private BooleanProperty fitToWidth;
    private BooleanProperty fitToHeight;
    private BooleanProperty pannable;
    private DoubleProperty prefViewportWidth;
    private DoubleProperty prefViewportHeight;
    private DoubleProperty minViewportWidth;
    private DoubleProperty minViewportHeight;
    private ObjectProperty<Bounds> viewportBounds;
    private static final String DEFAULT_STYLE_CLASS = "scroll-pane";
    private static final PseudoClass PANNABLE_PSEUDOCLASS_STATE;
    private static final PseudoClass FIT_TO_WIDTH_PSEUDOCLASS_STATE;
    private static final PseudoClass FIT_TO_HEIGHT_PSEUDOCLASS_STATE;
    
    public ScrollPane() {
        this.getStyleClass().setAll("scroll-pane");
        this.setAccessibleRole(AccessibleRole.SCROLL_PANE);
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
    }
    
    public ScrollPane(final Node content) {
        this();
        this.setContent(content);
    }
    
    public final void setHbarPolicy(final ScrollBarPolicy scrollBarPolicy) {
        this.hbarPolicyProperty().set(scrollBarPolicy);
    }
    
    public final ScrollBarPolicy getHbarPolicy() {
        return (this.hbarPolicy == null) ? ScrollBarPolicy.AS_NEEDED : this.hbarPolicy.get();
    }
    
    public final ObjectProperty<ScrollBarPolicy> hbarPolicyProperty() {
        if (this.hbarPolicy == null) {
            this.hbarPolicy = new StyleableObjectProperty<ScrollBarPolicy>(ScrollBarPolicy.AS_NEEDED) {
                @Override
                public CssMetaData<ScrollPane, ScrollBarPolicy> getCssMetaData() {
                    return StyleableProperties.HBAR_POLICY;
                }
                
                @Override
                public Object getBean() {
                    return ScrollPane.this;
                }
                
                @Override
                public String getName() {
                    return "hbarPolicy";
                }
            };
        }
        return this.hbarPolicy;
    }
    
    public final void setVbarPolicy(final ScrollBarPolicy scrollBarPolicy) {
        this.vbarPolicyProperty().set(scrollBarPolicy);
    }
    
    public final ScrollBarPolicy getVbarPolicy() {
        return (this.vbarPolicy == null) ? ScrollBarPolicy.AS_NEEDED : this.vbarPolicy.get();
    }
    
    public final ObjectProperty<ScrollBarPolicy> vbarPolicyProperty() {
        if (this.vbarPolicy == null) {
            this.vbarPolicy = new StyleableObjectProperty<ScrollBarPolicy>(ScrollBarPolicy.AS_NEEDED) {
                @Override
                public CssMetaData<ScrollPane, ScrollBarPolicy> getCssMetaData() {
                    return StyleableProperties.VBAR_POLICY;
                }
                
                @Override
                public Object getBean() {
                    return ScrollPane.this;
                }
                
                @Override
                public String getName() {
                    return "vbarPolicy";
                }
            };
        }
        return this.vbarPolicy;
    }
    
    public final void setContent(final Node node) {
        this.contentProperty().set(node);
    }
    
    public final Node getContent() {
        return (this.content == null) ? null : this.content.get();
    }
    
    public final ObjectProperty<Node> contentProperty() {
        if (this.content == null) {
            this.content = new SimpleObjectProperty<Node>(this, "content");
        }
        return this.content;
    }
    
    public final void setHvalue(final double n) {
        this.hvalueProperty().set(n);
    }
    
    public final double getHvalue() {
        return (this.hvalue == null) ? 0.0 : this.hvalue.get();
    }
    
    public final DoubleProperty hvalueProperty() {
        if (this.hvalue == null) {
            this.hvalue = new SimpleDoubleProperty(this, "hvalue");
        }
        return this.hvalue;
    }
    
    public final void setVvalue(final double n) {
        this.vvalueProperty().set(n);
    }
    
    public final double getVvalue() {
        return (this.vvalue == null) ? 0.0 : this.vvalue.get();
    }
    
    public final DoubleProperty vvalueProperty() {
        if (this.vvalue == null) {
            this.vvalue = new SimpleDoubleProperty(this, "vvalue");
        }
        return this.vvalue;
    }
    
    public final void setHmin(final double n) {
        this.hminProperty().set(n);
    }
    
    public final double getHmin() {
        return (this.hmin == null) ? 0.0 : this.hmin.get();
    }
    
    public final DoubleProperty hminProperty() {
        if (this.hmin == null) {
            this.hmin = new SimpleDoubleProperty(this, "hmin", 0.0);
        }
        return this.hmin;
    }
    
    public final void setVmin(final double n) {
        this.vminProperty().set(n);
    }
    
    public final double getVmin() {
        return (this.vmin == null) ? 0.0 : this.vmin.get();
    }
    
    public final DoubleProperty vminProperty() {
        if (this.vmin == null) {
            this.vmin = new SimpleDoubleProperty(this, "vmin", 0.0);
        }
        return this.vmin;
    }
    
    public final void setHmax(final double n) {
        this.hmaxProperty().set(n);
    }
    
    public final double getHmax() {
        return (this.hmax == null) ? 1.0 : this.hmax.get();
    }
    
    public final DoubleProperty hmaxProperty() {
        if (this.hmax == null) {
            this.hmax = new SimpleDoubleProperty(this, "hmax", 1.0);
        }
        return this.hmax;
    }
    
    public final void setVmax(final double n) {
        this.vmaxProperty().set(n);
    }
    
    public final double getVmax() {
        return (this.vmax == null) ? 1.0 : this.vmax.get();
    }
    
    public final DoubleProperty vmaxProperty() {
        if (this.vmax == null) {
            this.vmax = new SimpleDoubleProperty(this, "vmax", 1.0);
        }
        return this.vmax;
    }
    
    public final void setFitToWidth(final boolean b) {
        this.fitToWidthProperty().set(b);
    }
    
    public final boolean isFitToWidth() {
        return this.fitToWidth != null && this.fitToWidth.get();
    }
    
    public final BooleanProperty fitToWidthProperty() {
        if (this.fitToWidth == null) {
            this.fitToWidth = new StyleableBooleanProperty(false) {
                public void invalidated() {
                    ScrollPane.this.pseudoClassStateChanged(ScrollPane.FIT_TO_WIDTH_PSEUDOCLASS_STATE, this.get());
                }
                
                @Override
                public CssMetaData<ScrollPane, Boolean> getCssMetaData() {
                    return StyleableProperties.FIT_TO_WIDTH;
                }
                
                @Override
                public Object getBean() {
                    return ScrollPane.this;
                }
                
                @Override
                public String getName() {
                    return "fitToWidth";
                }
            };
        }
        return this.fitToWidth;
    }
    
    public final void setFitToHeight(final boolean b) {
        this.fitToHeightProperty().set(b);
    }
    
    public final boolean isFitToHeight() {
        return this.fitToHeight != null && this.fitToHeight.get();
    }
    
    public final BooleanProperty fitToHeightProperty() {
        if (this.fitToHeight == null) {
            this.fitToHeight = new StyleableBooleanProperty(false) {
                public void invalidated() {
                    ScrollPane.this.pseudoClassStateChanged(ScrollPane.FIT_TO_HEIGHT_PSEUDOCLASS_STATE, this.get());
                }
                
                @Override
                public CssMetaData<ScrollPane, Boolean> getCssMetaData() {
                    return StyleableProperties.FIT_TO_HEIGHT;
                }
                
                @Override
                public Object getBean() {
                    return ScrollPane.this;
                }
                
                @Override
                public String getName() {
                    return "fitToHeight";
                }
            };
        }
        return this.fitToHeight;
    }
    
    public final void setPannable(final boolean b) {
        this.pannableProperty().set(b);
    }
    
    public final boolean isPannable() {
        return this.pannable != null && this.pannable.get();
    }
    
    public final BooleanProperty pannableProperty() {
        if (this.pannable == null) {
            this.pannable = new StyleableBooleanProperty(false) {
                public void invalidated() {
                    ScrollPane.this.pseudoClassStateChanged(ScrollPane.PANNABLE_PSEUDOCLASS_STATE, this.get());
                }
                
                @Override
                public CssMetaData<ScrollPane, Boolean> getCssMetaData() {
                    return StyleableProperties.PANNABLE;
                }
                
                @Override
                public Object getBean() {
                    return ScrollPane.this;
                }
                
                @Override
                public String getName() {
                    return "pannable";
                }
            };
        }
        return this.pannable;
    }
    
    public final void setPrefViewportWidth(final double n) {
        this.prefViewportWidthProperty().set(n);
    }
    
    public final double getPrefViewportWidth() {
        return (this.prefViewportWidth == null) ? 0.0 : this.prefViewportWidth.get();
    }
    
    public final DoubleProperty prefViewportWidthProperty() {
        if (this.prefViewportWidth == null) {
            this.prefViewportWidth = new SimpleDoubleProperty(this, "prefViewportWidth");
        }
        return this.prefViewportWidth;
    }
    
    public final void setPrefViewportHeight(final double n) {
        this.prefViewportHeightProperty().set(n);
    }
    
    public final double getPrefViewportHeight() {
        return (this.prefViewportHeight == null) ? 0.0 : this.prefViewportHeight.get();
    }
    
    public final DoubleProperty prefViewportHeightProperty() {
        if (this.prefViewportHeight == null) {
            this.prefViewportHeight = new SimpleDoubleProperty(this, "prefViewportHeight");
        }
        return this.prefViewportHeight;
    }
    
    public final void setMinViewportWidth(final double n) {
        this.minViewportWidthProperty().set(n);
    }
    
    public final double getMinViewportWidth() {
        return (this.minViewportWidth == null) ? 0.0 : this.minViewportWidth.get();
    }
    
    public final DoubleProperty minViewportWidthProperty() {
        if (this.minViewportWidth == null) {
            this.minViewportWidth = new SimpleDoubleProperty(this, "minViewportWidth");
        }
        return this.minViewportWidth;
    }
    
    public final void setMinViewportHeight(final double n) {
        this.minViewportHeightProperty().set(n);
    }
    
    public final double getMinViewportHeight() {
        return (this.minViewportHeight == null) ? 0.0 : this.minViewportHeight.get();
    }
    
    public final DoubleProperty minViewportHeightProperty() {
        if (this.minViewportHeight == null) {
            this.minViewportHeight = new SimpleDoubleProperty(this, "minViewportHeight");
        }
        return this.minViewportHeight;
    }
    
    public final void setViewportBounds(final Bounds bounds) {
        this.viewportBoundsProperty().set(bounds);
    }
    
    public final Bounds getViewportBounds() {
        return (this.viewportBounds == null) ? new BoundingBox(0.0, 0.0, 0.0, 0.0) : this.viewportBounds.get();
    }
    
    public final ObjectProperty<Bounds> viewportBoundsProperty() {
        if (this.viewportBounds == null) {
            this.viewportBounds = new SimpleObjectProperty<Bounds>(this, "viewportBounds", new BoundingBox(0.0, 0.0, 0.0, 0.0));
        }
        return this.viewportBounds;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ScrollPaneSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case CONTENTS: {
                return this.getContent();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    static {
        PANNABLE_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("pannable");
        FIT_TO_WIDTH_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("fitToWidth");
        FIT_TO_HEIGHT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("fitToHeight");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<ScrollPane, ScrollBarPolicy> HBAR_POLICY;
        private static final CssMetaData<ScrollPane, ScrollBarPolicy> VBAR_POLICY;
        private static final CssMetaData<ScrollPane, Boolean> FIT_TO_WIDTH;
        private static final CssMetaData<ScrollPane, Boolean> FIT_TO_HEIGHT;
        private static final CssMetaData<ScrollPane, Boolean> PANNABLE;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            HBAR_POLICY = new CssMetaData<ScrollPane, ScrollBarPolicy>((StyleConverter)new EnumConverter(ScrollBarPolicy.class), ScrollBarPolicy.AS_NEEDED) {
                @Override
                public boolean isSettable(final ScrollPane scrollPane) {
                    return scrollPane.hbarPolicy == null || !scrollPane.hbarPolicy.isBound();
                }
                
                @Override
                public StyleableProperty<ScrollBarPolicy> getStyleableProperty(final ScrollPane scrollPane) {
                    return (StyleableProperty<ScrollBarPolicy>)(StyleableProperty)scrollPane.hbarPolicyProperty();
                }
            };
            VBAR_POLICY = new CssMetaData<ScrollPane, ScrollBarPolicy>((StyleConverter)new EnumConverter(ScrollBarPolicy.class), ScrollBarPolicy.AS_NEEDED) {
                @Override
                public boolean isSettable(final ScrollPane scrollPane) {
                    return scrollPane.vbarPolicy == null || !scrollPane.vbarPolicy.isBound();
                }
                
                @Override
                public StyleableProperty<ScrollBarPolicy> getStyleableProperty(final ScrollPane scrollPane) {
                    return (StyleableProperty<ScrollBarPolicy>)(StyleableProperty)scrollPane.vbarPolicyProperty();
                }
            };
            FIT_TO_WIDTH = new CssMetaData<ScrollPane, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
                @Override
                public boolean isSettable(final ScrollPane scrollPane) {
                    return scrollPane.fitToWidth == null || !scrollPane.fitToWidth.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final ScrollPane scrollPane) {
                    return (StyleableProperty<Boolean>)scrollPane.fitToWidthProperty();
                }
            };
            FIT_TO_HEIGHT = new CssMetaData<ScrollPane, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
                @Override
                public boolean isSettable(final ScrollPane scrollPane) {
                    return scrollPane.fitToHeight == null || !scrollPane.fitToHeight.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final ScrollPane scrollPane) {
                    return (StyleableProperty<Boolean>)scrollPane.fitToHeightProperty();
                }
            };
            PANNABLE = new CssMetaData<ScrollPane, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
                @Override
                public boolean isSettable(final ScrollPane scrollPane) {
                    return scrollPane.pannable == null || !scrollPane.pannable.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final ScrollPane scrollPane) {
                    return (StyleableProperty<Boolean>)scrollPane.pannableProperty();
                }
            };
            final ArrayList<CssMetaData<ScrollPane, ScrollBarPolicy>> list = new ArrayList<CssMetaData<ScrollPane, ScrollBarPolicy>>((Collection<? extends CssMetaData<ScrollPane, ScrollBarPolicy>>)Control.getClassCssMetaData());
            list.add(StyleableProperties.HBAR_POLICY);
            list.add(StyleableProperties.VBAR_POLICY);
            list.add((CssMetaData<ScrollPane, ScrollBarPolicy>)StyleableProperties.FIT_TO_WIDTH);
            list.add((CssMetaData<ScrollPane, ScrollBarPolicy>)StyleableProperties.FIT_TO_HEIGHT);
            list.add((CssMetaData<ScrollPane, ScrollBarPolicy>)StyleableProperties.PANNABLE);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    public enum ScrollBarPolicy
    {
        NEVER, 
        ALWAYS, 
        AS_NEEDED;
    }
}
