// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.stream.Stream;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.function.Consumer;
import java.util.Objects;
import java.util.function.Function;
import javafx.collections.ListChangeListener;
import java.util.List;
import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.scene.control.skin.Utils;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.event.EventTarget;

class ControlUtils
{
    private ControlUtils() {
    }
    
    public static void scrollToIndex(final Control control, final int i) {
        Utils.executeOnceWhenPropertyIsNonNull(control.skinProperty(), p2 -> Event.fireEvent(control, new ScrollToEvent<Object>(control, control, (EventType<ScrollToEvent<?>>)ScrollToEvent.scrollToTopIndex(), (Object)i)));
    }
    
    public static void scrollToColumn(final Control control, final TableColumnBase<?, ?> tableColumnBase) {
        Utils.executeOnceWhenPropertyIsNonNull(control.skinProperty(), p2 -> control.fireEvent(new ScrollToEvent<Object>(control, control, ScrollToEvent.scrollToColumn(), tableColumnBase)));
    }
    
    static void requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(final Control control) {
        final Scene scene = control.getScene();
        final Node obj = (scene == null) ? null : scene.getFocusOwner();
        if (obj == null) {
            control.requestFocus();
        }
        else if (!control.equals(obj)) {
            for (Parent obj2 = obj.getParent(); obj2 != null; obj2 = obj2.getParent()) {
                if (control.equals(obj2)) {
                    control.requestFocus();
                    break;
                }
            }
        }
    }
    
    static <T> ListChangeListener.Change<T> buildClearAndSelectChange(final ObservableList<T> list, final List<T> list2, final int n) {
        return new ListChangeListener.Change<T>(list) {
            private final int[] EMPTY_PERM = new int[0];
            private final int removedSize = list2.size();
            private final List<T> firstRemovedRange;
            private final List<T> secondRemovedRange;
            private boolean invalid = true;
            private boolean atFirstRange = true;
            private int from = -1;
            
            {
                final int n = (n >= this.removedSize) ? this.removedSize : ((n < 0) ? 0 : n);
                this.firstRemovedRange = (List<T>)list2.subList(0, n);
                this.secondRemovedRange = (List<T>)list2.subList(n, this.removedSize);
            }
            
            @Override
            public int getFrom() {
                this.checkState();
                return this.from;
            }
            
            @Override
            public int getTo() {
                return this.getFrom();
            }
            
            @Override
            public List<T> getRemoved() {
                this.checkState();
                return this.atFirstRange ? this.firstRemovedRange : this.secondRemovedRange;
            }
            
            @Override
            public int getRemovedSize() {
                return this.atFirstRange ? this.firstRemovedRange.size() : this.secondRemovedRange.size();
            }
            
            @Override
            protected int[] getPermutation() {
                this.checkState();
                return this.EMPTY_PERM;
            }
            
            @Override
            public boolean next() {
                if (this.invalid && this.atFirstRange) {
                    this.invalid = false;
                    this.from = 0;
                    return true;
                }
                if (this.atFirstRange && !this.secondRemovedRange.isEmpty()) {
                    this.atFirstRange = false;
                    this.from = 1;
                    return true;
                }
                return false;
            }
            
            @Override
            public void reset() {
                this.invalid = true;
                this.atFirstRange = true;
            }
            
            private void checkState() {
                if (this.invalid) {
                    throw new IllegalStateException("Invalid Change state: next() must be called before inspecting the Change.");
                }
            }
        };
    }
    
    public static <S> void updateSelectedIndices(final MultipleSelectionModelBase<S> multipleSelectionModelBase, final ListChangeListener.Change<? extends TablePositionBase<?>> change) {
        multipleSelectionModelBase.selectedIndices._beginChange();
        while (change.next()) {
            multipleSelectionModelBase.startAtomic();
            final Stream<Object> distinct = change.getRemoved().stream().map((Function<? super Object, ?>)TablePositionBase::getRow).distinct();
            final MultipleSelectionModelBase.SelectedIndicesList selectedIndices = multipleSelectionModelBase.selectedIndices;
            Objects.requireNonNull(selectedIndices);
            final List<Object> list = distinct.peek((Consumer<? super Object>)selectedIndices::clear).collect((Collector<? super Object, ?, List<Object>>)Collectors.toList());
            final Stream<Object> distinct2 = change.getAddedSubList().stream().map((Function<? super Object, ?>)TablePositionBase::getRow).distinct();
            final MultipleSelectionModelBase.SelectedIndicesList selectedIndices2 = multipleSelectionModelBase.selectedIndices;
            Objects.requireNonNull(selectedIndices2);
            final int n = (int)distinct2.peek((Consumer<? super Object>)selectedIndices2::set).count();
            multipleSelectionModelBase.stopAtomic();
            final int n2 = change.getFrom() + n;
            if (change.wasReplaced()) {
                multipleSelectionModelBase.selectedIndices._nextReplace(change.getFrom(), n2, (List<? extends Integer>)list);
            }
            else if (change.wasRemoved()) {
                multipleSelectionModelBase.selectedIndices._nextRemove(change.getFrom(), (List<? extends Integer>)list);
            }
            else {
                if (!change.wasAdded()) {
                    continue;
                }
                multipleSelectionModelBase.selectedIndices._nextAdd(change.getFrom(), n2);
            }
        }
        change.reset();
        multipleSelectionModelBase.selectedIndices.reset();
        if (multipleSelectionModelBase.isAtomic()) {
            return;
        }
        if (multipleSelectionModelBase.getSelectedItems().isEmpty() && multipleSelectionModelBase.getSelectedItem() != null) {
            multipleSelectionModelBase.setSelectedItem(null);
        }
        multipleSelectionModelBase.selectedIndices._endChange();
    }
    
    static void reducingChange(final MultipleSelectionModelBase.SelectedIndicesList list, final List<Integer> list2) {
        if (list2.isEmpty()) {
            return;
        }
        int n = 0;
        int i = 1;
        boolean b = false;
        while (i < list2.size()) {
            if (list2.get(n) == list2.get(i) - 1) {
                ++i;
            }
            else {
                list._nextRemove(list.indexOf(list2.get(n)), list2.subList(n, i));
                n = i;
                i = n + 1;
                b = true;
            }
        }
        if (!b) {
            list._nextRemove(list.indexOf(list2.get(0)), list2);
        }
    }
}
