// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.stage.Window;
import javafx.scene.Scene;
import javafx.scene.control.skin.ContextMenuSkin;
import javafx.event.EventTarget;
import javafx.event.Event;
import javafx.geometry.Point2D;
import com.sun.javafx.util.Utils;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.geometry.Side;
import javafx.scene.Node;
import java.util.Iterator;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import javafx.event.EventType;
import javafx.beans.property.ObjectPropertyBase;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.beans.property.ObjectProperty;
import com.sun.javafx.beans.IDProperty;

@IDProperty("id")
public class ContextMenu extends PopupControl
{
    private boolean showRelativeToWindow;
    private ObjectProperty<EventHandler<ActionEvent>> onAction;
    private final ObservableList<MenuItem> items;
    private static final String DEFAULT_STYLE_CLASS = "context-menu";
    
    public ContextMenu() {
        this.showRelativeToWindow = false;
        this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
            @Override
            protected void invalidated() {
                Window.this.setEventHandler((EventType<Event>)ActionEvent.ACTION, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ContextMenu.this;
            }
            
            @Override
            public String getName() {
                return "onAction";
            }
        };
        this.items = new TrackableObservableList<MenuItem>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<MenuItem> change) {
                while (change.next()) {
                    final Iterator<MenuItem> iterator = change.getRemoved().iterator();
                    while (iterator.hasNext()) {
                        iterator.next().setParentPopup(null);
                    }
                    for (final MenuItem menuItem : change.getAddedSubList()) {
                        if (menuItem.getParentPopup() != null) {
                            menuItem.getParentPopup().getItems().remove(menuItem);
                        }
                        menuItem.setParentPopup(ContextMenu.this);
                    }
                }
            }
        };
        this.getStyleClass().setAll("context-menu");
        this.setAutoHide(true);
        this.setConsumeAutoHidingEvents(false);
    }
    
    public ContextMenu(final MenuItem... array) {
        this();
        this.items.addAll(array);
    }
    
    public final void setOnAction(final EventHandler<ActionEvent> eventHandler) {
        this.onActionProperty().set(eventHandler);
    }
    
    public final EventHandler<ActionEvent> getOnAction() {
        return this.onActionProperty().get();
    }
    
    public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() {
        return this.onAction;
    }
    
    public final ObservableList<MenuItem> getItems() {
        return this.items;
    }
    
    public void show(final Node node, final Side side, final double n, final double n2) {
        if (node == null) {
            return;
        }
        if (this.getItems().size() == 0) {
            return;
        }
        this.getScene().setNodeOrientation(node.getEffectiveNodeOrientation());
        final Point2D pointRelativeTo = Utils.pointRelativeTo(node, this.prefWidth(-1.0), this.prefHeight(-1.0), (side == Side.LEFT) ? HPos.LEFT : ((side == Side.RIGHT) ? HPos.RIGHT : HPos.CENTER), (side == Side.TOP) ? VPos.TOP : ((side == Side.BOTTOM) ? VPos.BOTTOM : VPos.CENTER), n, n2, true);
        this.doShow(node, pointRelativeTo.getX(), pointRelativeTo.getY());
    }
    
    @Override
    public void show(final Node node, final double n, final double n2) {
        if (node == null) {
            return;
        }
        if (this.getItems().size() == 0) {
            return;
        }
        this.getScene().setNodeOrientation(node.getEffectiveNodeOrientation());
        this.doShow(node, n, n2);
    }
    
    @Override
    public void hide() {
        if (!this.isShowing()) {
            return;
        }
        Event.fireEvent(this, new Event(Menu.ON_HIDING));
        super.hide();
        Event.fireEvent(this, new Event(Menu.ON_HIDDEN));
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ContextMenuSkin(this);
    }
    
    final boolean isShowRelativeToWindow() {
        return this.showRelativeToWindow;
    }
    
    final void setShowRelativeToWindow(final boolean showRelativeToWindow) {
        this.showRelativeToWindow = showRelativeToWindow;
    }
    
    private void doShow(final Node node, final double n, final double n2) {
        Event.fireEvent(this, new Event(Menu.ON_SHOWING));
        if (this.isShowRelativeToWindow()) {
            final Scene scene = (node == null) ? null : node.getScene();
            final Window window = (scene == null) ? null : scene.getWindow();
            if (window == null) {
                return;
            }
            super.show(window, n, n2);
        }
        else {
            super.show(node, n, n2);
        }
        Event.fireEvent(this, new Event(Menu.ON_SHOWN));
    }
}
