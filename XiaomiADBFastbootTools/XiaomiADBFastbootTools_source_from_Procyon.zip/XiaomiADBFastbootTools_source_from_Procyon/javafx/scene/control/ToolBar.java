// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import javafx.css.StyleConverter;
import javafx.css.converter.EnumConverter;
import javafx.css.Styleable;
import java.util.List;
import javafx.scene.control.skin.ToolBarSkin;
import javafx.css.CssMetaData;
import javafx.css.StyleableObjectProperty;
import javafx.css.StyleOrigin;
import javafx.css.StyleableProperty;
import javafx.scene.AccessibleRole;
import javafx.collections.FXCollections;
import javafx.css.PseudoClass;
import javafx.geometry.Orientation;
import javafx.beans.property.ObjectProperty;
import javafx.scene.Node;
import javafx.collections.ObservableList;
import javafx.beans.DefaultProperty;

@DefaultProperty("items")
public class ToolBar extends Control
{
    private final ObservableList<Node> items;
    private ObjectProperty<Orientation> orientation;
    private static final String DEFAULT_STYLE_CLASS = "tool-bar";
    private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE;
    private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE;
    
    public ToolBar() {
        this.items = FXCollections.observableArrayList();
        this.initialize();
    }
    
    public ToolBar(final Node... array) {
        this.items = FXCollections.observableArrayList();
        this.initialize();
        this.items.addAll(array);
    }
    
    private void initialize() {
        this.getStyleClass().setAll("tool-bar");
        this.setAccessibleRole(AccessibleRole.TOOL_BAR);
        ((StyleableProperty)this.focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
        this.pseudoClassStateChanged(ToolBar.HORIZONTAL_PSEUDOCLASS_STATE, true);
    }
    
    public final ObservableList<Node> getItems() {
        return this.items;
    }
    
    public final void setOrientation(final Orientation orientation) {
        this.orientationProperty().set(orientation);
    }
    
    public final Orientation getOrientation() {
        return (this.orientation == null) ? Orientation.HORIZONTAL : this.orientation.get();
    }
    
    public final ObjectProperty<Orientation> orientationProperty() {
        if (this.orientation == null) {
            this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL) {
                public void invalidated() {
                    final boolean b = this.get() == Orientation.VERTICAL;
                    ToolBar.this.pseudoClassStateChanged(ToolBar.VERTICAL_PSEUDOCLASS_STATE, b);
                    ToolBar.this.pseudoClassStateChanged(ToolBar.HORIZONTAL_PSEUDOCLASS_STATE, !b);
                }
                
                @Override
                public Object getBean() {
                    return ToolBar.this;
                }
                
                @Override
                public String getName() {
                    return "orientation";
                }
                
                @Override
                public CssMetaData<ToolBar, Orientation> getCssMetaData() {
                    return StyleableProperties.ORIENTATION;
                }
            };
        }
        return this.orientation;
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ToolBarSkin(this);
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
        return getClassCssMetaData();
    }
    
    @Override
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    static {
        VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
        HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<ToolBar, Orientation> ORIENTATION;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            ORIENTATION = new CssMetaData<ToolBar, Orientation>((StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL) {
                @Override
                public Orientation getInitialValue(final ToolBar toolBar) {
                    return toolBar.getOrientation();
                }
                
                @Override
                public boolean isSettable(final ToolBar toolBar) {
                    return toolBar.orientation == null || !toolBar.orientation.isBound();
                }
                
                @Override
                public StyleableProperty<Orientation> getStyleableProperty(final ToolBar toolBar) {
                    return (StyleableProperty<Orientation>)(StyleableProperty)toolBar.orientationProperty();
                }
            };
            final ArrayList<CssMetaData<? extends Styleable, ?>> list = new ArrayList<CssMetaData<? extends Styleable, ?>>(Control.getClassCssMetaData());
            list.add(StyleableProperties.ORIENTATION);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
}
