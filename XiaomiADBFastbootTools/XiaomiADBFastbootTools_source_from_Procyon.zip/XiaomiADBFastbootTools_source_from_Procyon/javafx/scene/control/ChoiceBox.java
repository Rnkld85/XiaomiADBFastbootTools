// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.control;

import javafx.beans.value.ObservableValue;
import javafx.scene.AccessibleAction;
import javafx.scene.control.skin.ChoiceBoxSkin;
import javafx.event.EventTarget;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.scene.AccessibleRole;
import javafx.beans.property.ObjectPropertyBase;
import javafx.scene.AccessibleAttribute;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.StringConverter;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.property.ObjectProperty;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.beans.DefaultProperty;

@DefaultProperty("items")
public class ChoiceBox<T> extends Control
{
    public static final EventType<Event> ON_SHOWING;
    public static final EventType<Event> ON_SHOWN;
    public static final EventType<Event> ON_HIDING;
    public static final EventType<Event> ON_HIDDEN;
    private ObjectProperty<SingleSelectionModel<T>> selectionModel;
    private ChangeListener<T> selectedItemListener;
    private ReadOnlyBooleanWrapper showing;
    private ObjectProperty<ObservableList<T>> items;
    private final ListChangeListener<T> itemsListener;
    private ObjectProperty<StringConverter<T>> converter;
    private ObjectProperty<T> value;
    private ObjectProperty<EventHandler<ActionEvent>> onAction;
    private ObjectProperty<EventHandler<Event>> onShowing;
    private ObjectProperty<EventHandler<Event>> onShown;
    private ObjectProperty<EventHandler<Event>> onHiding;
    private ObjectProperty<EventHandler<Event>> onHidden;
    private static final PseudoClass SHOWING_PSEUDOCLASS_STATE;
    
    public ChoiceBox() {
        this(FXCollections.observableArrayList());
    }
    
    public ChoiceBox(final ObservableList<T> items) {
        this.selectionModel = new SimpleObjectProperty<SingleSelectionModel<T>>((Object)this, "selectionModel") {
            private SelectionModel<T> oldSM = null;
            
            @Override
            protected void invalidated() {
                if (this.oldSM != null) {
                    this.oldSM.selectedItemProperty().removeListener(ChoiceBox.this.selectedItemListener);
                }
                final SelectionModel<T> oldSM = ((ObjectPropertyBase<SelectionModel<T>>)this).get();
                if ((this.oldSM = oldSM) != null) {
                    oldSM.selectedItemProperty().addListener(ChoiceBox.this.selectedItemListener);
                    if (oldSM.getSelectedItem() != null && !ChoiceBox.this.valueProperty().isBound()) {
                        ChoiceBox.this.setValue(oldSM.getSelectedItem());
                    }
                }
            }
        };
        this.selectedItemListener = ((p0, p1, value) -> {
            if (!this.valueProperty().isBound()) {
                this.setValue(value);
            }
            return;
        });
        this.showing = new ReadOnlyBooleanWrapper() {
            @Override
            protected void invalidated() {
                ChoiceBox.this.pseudoClassStateChanged(ChoiceBox.SHOWING_PSEUDOCLASS_STATE, this.get());
                ChoiceBox.this.notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED);
            }
            
            @Override
            public Object getBean() {
                return ChoiceBox.this;
            }
            
            @Override
            public String getName() {
                return "showing";
            }
        };
        this.items = new ObjectPropertyBase<ObservableList<T>>() {
            ObservableList<T> old;
            
            @Override
            protected void invalidated() {
                final ObservableList<T> old = this.get();
                if (this.old != old) {
                    if (this.old != null) {
                        this.old.removeListener(ChoiceBox.this.itemsListener);
                    }
                    if (old != null) {
                        old.addListener(ChoiceBox.this.itemsListener);
                    }
                    final SingleSelectionModel<Object> selectionModel = (SingleSelectionModel<Object>)ChoiceBox.this.getSelectionModel();
                    if (selectionModel != null) {
                        if (old != null && old.isEmpty()) {
                            selectionModel.clearSelection();
                        }
                        else if (selectionModel.getSelectedIndex() == -1 && selectionModel.getSelectedItem() != null) {
                            final int index = ChoiceBox.this.getItems().indexOf(selectionModel.getSelectedItem());
                            if (index != -1) {
                                selectionModel.setSelectedIndex(index);
                            }
                        }
                        else {
                            selectionModel.clearSelection();
                        }
                    }
                    this.old = old;
                }
            }
            
            @Override
            public Object getBean() {
                return ChoiceBox.this;
            }
            
            @Override
            public String getName() {
                return "items";
            }
        };
        final SingleSelectionModel<Object> singleSelectionModel;
        final Object o2;
        this.itemsListener = (change -> {
            this.getSelectionModel();
            if (singleSelectionModel != null) {
                if (this.getItems() == null || this.getItems().isEmpty()) {
                    singleSelectionModel.clearSelection();
                }
                else {
                    singleSelectionModel.setSelectedIndex(this.getItems().indexOf(singleSelectionModel.getSelectedItem()));
                }
            }
            if (singleSelectionModel != null) {
                singleSelectionModel.getSelectedItem();
                while (change.next()) {
                    if (o2 != null && change.getRemoved().contains(o2)) {
                        singleSelectionModel.clearSelection();
                        break;
                    }
                }
            }
            return;
        });
        this.converter = new SimpleObjectProperty<StringConverter<T>>(this, "converter", null);
        this.value = new SimpleObjectProperty<T>((Object)this, "value") {
            @Override
            protected void invalidated() {
                super.invalidated();
                ChoiceBox.this.fireEvent(new ActionEvent());
                final SingleSelectionModel<Object> selectionModel = ChoiceBox.this.getSelectionModel();
                if (selectionModel != null) {
                    selectionModel.select(super.getValue());
                }
                ChoiceBox.this.notifyAccessibleAttributeChanged(AccessibleAttribute.TEXT);
            }
        };
        this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ActionEvent.ACTION, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ChoiceBox.this;
            }
            
            @Override
            public String getName() {
                return "onAction";
            }
        };
        this.onShowing = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ChoiceBox.ON_SHOWING, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ChoiceBox.this;
            }
            
            @Override
            public String getName() {
                return "onShowing";
            }
        };
        this.onShown = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ChoiceBox.ON_SHOWN, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ChoiceBox.this;
            }
            
            @Override
            public String getName() {
                return "onShown";
            }
        };
        this.onHiding = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ChoiceBox.ON_HIDING, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ChoiceBox.this;
            }
            
            @Override
            public String getName() {
                return "onHiding";
            }
        };
        this.onHidden = new ObjectPropertyBase<EventHandler<Event>>() {
            @Override
            protected void invalidated() {
                Node.this.setEventHandler(ChoiceBox.ON_HIDDEN, ((ObjectPropertyBase<EventHandler>)this).get());
            }
            
            @Override
            public Object getBean() {
                return ChoiceBox.this;
            }
            
            @Override
            public String getName() {
                return "onHidden";
            }
        };
        this.getStyleClass().setAll("choice-box");
        this.setAccessibleRole(AccessibleRole.COMBO_BOX);
        this.setItems(items);
        this.setSelectionModel(new ChoiceBoxSelectionModel<T>(this));
        final int n;
        this.valueProperty().addListener((p0, p1, o) -> {
            if (this.getItems() != null) {
                this.getItems().indexOf(o);
                if (n > -1) {
                    this.getSelectionModel().select(n);
                }
            }
        });
    }
    
    public final void setSelectionModel(final SingleSelectionModel<T> singleSelectionModel) {
        this.selectionModel.set(singleSelectionModel);
    }
    
    public final SingleSelectionModel<T> getSelectionModel() {
        return this.selectionModel.get();
    }
    
    public final ObjectProperty<SingleSelectionModel<T>> selectionModelProperty() {
        return this.selectionModel;
    }
    
    public final boolean isShowing() {
        return this.showing.get();
    }
    
    public final ReadOnlyBooleanProperty showingProperty() {
        return this.showing.getReadOnlyProperty();
    }
    
    private void setShowing(final boolean b) {
        Event.fireEvent(this, b ? new Event(ChoiceBox.ON_SHOWING) : new Event(ChoiceBox.ON_HIDING));
        this.showing.set(b);
        Event.fireEvent(this, b ? new Event(ChoiceBox.ON_SHOWN) : new Event(ChoiceBox.ON_HIDDEN));
    }
    
    public final void setItems(final ObservableList<T> list) {
        this.items.set(list);
    }
    
    public final ObservableList<T> getItems() {
        return this.items.get();
    }
    
    public final ObjectProperty<ObservableList<T>> itemsProperty() {
        return this.items;
    }
    
    public ObjectProperty<StringConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final StringConverter<T> stringConverter) {
        this.converterProperty().set(stringConverter);
    }
    
    public final StringConverter<T> getConverter() {
        return this.converterProperty().get();
    }
    
    public ObjectProperty<T> valueProperty() {
        return this.value;
    }
    
    public final void setValue(final T t) {
        this.valueProperty().set(t);
    }
    
    public final T getValue() {
        return this.valueProperty().get();
    }
    
    public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() {
        return this.onAction;
    }
    
    public final void setOnAction(final EventHandler<ActionEvent> eventHandler) {
        this.onActionProperty().set(eventHandler);
    }
    
    public final EventHandler<ActionEvent> getOnAction() {
        return this.onActionProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onShowingProperty() {
        return this.onShowing;
    }
    
    public final void setOnShowing(final EventHandler<Event> eventHandler) {
        this.onShowingProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnShowing() {
        return this.onShowingProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onShownProperty() {
        return this.onShown;
    }
    
    public final void setOnShown(final EventHandler<Event> eventHandler) {
        this.onShownProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnShown() {
        return this.onShownProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onHidingProperty() {
        return this.onHiding;
    }
    
    public final void setOnHiding(final EventHandler<Event> eventHandler) {
        this.onHidingProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnHiding() {
        return this.onHidingProperty().get();
    }
    
    public final ObjectProperty<EventHandler<Event>> onHiddenProperty() {
        return this.onHidden;
    }
    
    public final void setOnHidden(final EventHandler<Event> eventHandler) {
        this.onHiddenProperty().set(eventHandler);
    }
    
    public final EventHandler<Event> getOnHidden() {
        return this.onHiddenProperty().get();
    }
    
    public void show() {
        if (!this.isDisabled()) {
            this.setShowing(true);
        }
    }
    
    public void hide() {
        this.setShowing(false);
    }
    
    @Override
    protected Skin<?> createDefaultSkin() {
        return new ChoiceBoxSkin<Object>(this);
    }
    
    @Override
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case TEXT: {
                final String accessibleText = this.getAccessibleText();
                if (accessibleText != null && !accessibleText.isEmpty()) {
                    return accessibleText;
                }
                final Object queryAccessibleAttribute = super.queryAccessibleAttribute(accessibleAttribute, array);
                if (queryAccessibleAttribute != null) {
                    return queryAccessibleAttribute;
                }
                final StringConverter<Object> converter = this.getConverter();
                if (converter == null) {
                    return (this.getValue() != null) ? this.getValue().toString() : "";
                }
                return converter.toString(this.getValue());
            }
            case EXPANDED: {
                return this.isShowing();
            }
            default: {
                return super.queryAccessibleAttribute(accessibleAttribute, array);
            }
        }
    }
    
    @Override
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case COLLAPSE: {
                this.hide();
                break;
            }
            case EXPAND: {
                this.show();
                break;
            }
            default: {
                super.executeAccessibleAction(accessibleAction, new Object[0]);
                break;
            }
        }
    }
    
    static {
        ON_SHOWING = new EventType<Event>(Event.ANY, "CHOICE_BOX_ON_SHOWING");
        ON_SHOWN = new EventType<Event>(Event.ANY, "CHOICE_BOX_ON_SHOWN");
        ON_HIDING = new EventType<Event>(Event.ANY, "CHOICE_BOX_ON_HIDING");
        ON_HIDDEN = new EventType<Event>(Event.ANY, "CHOICE_BOX_ON_HIDDEN");
        SHOWING_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("showing");
    }
    
    static class ChoiceBoxSelectionModel<T> extends SingleSelectionModel<T>
    {
        private final ChoiceBox<T> choiceBox;
        
        public ChoiceBoxSelectionModel(final ChoiceBox<T> choiceBox) {
            if (choiceBox == null) {
                throw new NullPointerException("ChoiceBox can not be null");
            }
            this.choiceBox = choiceBox;
            final int selectedIndex;
            final ListChangeListener<? super T> listChangeListener = p0 -> {
                if (this.choiceBox.getItems() == null || this.choiceBox.getItems().isEmpty()) {
                    this.setSelectedIndex(-1);
                }
                else if (this.getSelectedIndex() == -1 && this.getSelectedItem() != null) {
                    this.choiceBox.getItems().indexOf(this.getSelectedItem());
                    if (selectedIndex != -1) {
                        this.setSelectedIndex(selectedIndex);
                    }
                }
                return;
            };
            if (this.choiceBox.getItems() != null) {
                this.choiceBox.getItems().addListener(listChangeListener);
            }
            final ListChangeListener listChangeListener2;
            final int selectedIndex2;
            this.choiceBox.itemsProperty().addListener((p1, list, list2) -> {
                if (list != null) {
                    list.removeListener(listChangeListener2);
                }
                if (list2 != null) {
                    list2.addListener(listChangeListener2);
                }
                this.setSelectedIndex(-1);
                if (this.getSelectedItem() != null) {
                    this.choiceBox.getItems().indexOf(this.getSelectedItem());
                    if (selectedIndex2 != -1) {
                        this.setSelectedIndex(selectedIndex2);
                    }
                }
            });
        }
        
        @Override
        protected T getModelItem(final int n) {
            final ObservableList<T> items = this.choiceBox.getItems();
            if (items == null) {
                return null;
            }
            if (n < 0 || n >= items.size()) {
                return null;
            }
            return (T)items.get(n);
        }
        
        @Override
        protected int getItemCount() {
            final ObservableList<T> items = this.choiceBox.getItems();
            return (items == null) ? 0 : items.size();
        }
        
        @Override
        public void select(final int n) {
            super.select(n);
            if (this.choiceBox.isShowing()) {
                this.choiceBox.hide();
            }
        }
        
        @Override
        public void selectPrevious() {
            for (int i = this.getSelectedIndex() - 1; i >= 0; --i) {
                if (!(this.getModelItem(i) instanceof Separator)) {
                    this.select(i);
                    break;
                }
            }
        }
        
        @Override
        public void selectNext() {
            for (int i = this.getSelectedIndex() + 1; i < this.getItemCount(); ++i) {
                if (!(this.getModelItem(i) instanceof Separator)) {
                    this.select(i);
                    break;
                }
            }
        }
    }
}
