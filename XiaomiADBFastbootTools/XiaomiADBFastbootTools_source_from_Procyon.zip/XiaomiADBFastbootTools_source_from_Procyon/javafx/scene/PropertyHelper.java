// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import java.security.AccessController;

class PropertyHelper
{
    static boolean getBooleanProperty(final String key) {
        try {
            return AccessController.doPrivileged(() -> "true".equals(System.getProperty(key).toLowerCase()));
        }
        catch (Exception ex) {
            return false;
        }
    }
}
