// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import javafx.beans.Observable;
import com.sun.javafx.geom.BoxBounds;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.geom.PickRay;
import javafx.geometry.Point2D;
import javafx.geometry.Point3D;
import com.sun.javafx.scene.transform.TransformHelper;
import com.sun.javafx.sg.prism.NGCamera;
import javafx.beans.property.SimpleDoubleProperty;
import com.sun.javafx.geom.transform.NoninvertibleTransformException;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.geom.transform.BaseTransform;
import javafx.scene.transform.Transform;
import javafx.beans.InvalidationListener;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import com.sun.javafx.scene.CameraHelper;
import javafx.beans.property.DoubleProperty;
import com.sun.javafx.geom.Vec3d;
import com.sun.javafx.geom.transform.GeneralTransform3D;
import com.sun.javafx.geom.transform.Affine3D;

public abstract class Camera extends Node
{
    private Affine3D localToSceneTx;
    private double farClipInScene;
    private double nearClipInScene;
    private Scene ownerScene;
    private SubScene ownerSubScene;
    private GeneralTransform3D projViewTx;
    private GeneralTransform3D projTx;
    private Affine3D viewTx;
    private double viewWidth;
    private double viewHeight;
    private Vec3d position;
    private boolean clipInSceneValid;
    private boolean projViewTxValid;
    private boolean localToSceneValid;
    private boolean sceneToLocalValid;
    private Affine3D sceneToLocalTx;
    private DoubleProperty nearClip;
    private DoubleProperty farClip;
    
    protected Camera() {
        this.localToSceneTx = new Affine3D();
        CameraHelper.initHelper(this);
        this.ownerScene = null;
        this.ownerSubScene = null;
        this.projViewTx = new GeneralTransform3D();
        this.projTx = new GeneralTransform3D();
        this.viewTx = new Affine3D();
        this.viewWidth = 1.0;
        this.viewHeight = 1.0;
        this.position = new Vec3d();
        this.clipInSceneValid = false;
        this.projViewTxValid = false;
        this.localToSceneValid = false;
        this.sceneToLocalValid = false;
        this.sceneToLocalTx = new Affine3D();
        final InvalidationListener invalidationListener = p0 -> NodeHelper.markDirty(this, DirtyBits.NODE_CAMERA_TRANSFORM);
        this.localToSceneTransformProperty().addListener(invalidationListener);
        this.sceneProperty().addListener(invalidationListener);
    }
    
    double getFarClipInScene() {
        this.updateClipPlane();
        return this.farClipInScene;
    }
    
    double getNearClipInScene() {
        this.updateClipPlane();
        return this.nearClipInScene;
    }
    
    private void updateClipPlane() {
        if (!this.clipInSceneValid) {
            final Transform localToSceneTransform = this.getLocalToSceneTransform();
            this.nearClipInScene = localToSceneTransform.transform(0.0, 0.0, this.getNearClip()).getZ();
            this.farClipInScene = localToSceneTransform.transform(0.0, 0.0, this.getFarClip()).getZ();
            this.clipInSceneValid = true;
        }
    }
    
    Affine3D getSceneToLocalTransform() {
        if (!this.sceneToLocalValid) {
            this.sceneToLocalTx.setTransform(this.getCameraTransform());
            try {
                this.sceneToLocalTx.invert();
            }
            catch (NoninvertibleTransformException ex) {
                PlatformLogger.getLogger(Camera.class.getName()).severe("getSceneToLocalTransform", ex);
                this.sceneToLocalTx.setToIdentity();
            }
            this.sceneToLocalValid = true;
        }
        return this.sceneToLocalTx;
    }
    
    public final void setNearClip(final double n) {
        this.nearClipProperty().set(n);
    }
    
    public final double getNearClip() {
        return (this.nearClip == null) ? 0.1 : this.nearClip.get();
    }
    
    public final DoubleProperty nearClipProperty() {
        if (this.nearClip == null) {
            this.nearClip = new SimpleDoubleProperty(this, "nearClip", 0.1) {
                @Override
                protected void invalidated() {
                    Camera.this.clipInSceneValid = false;
                    NodeHelper.markDirty(Camera.this, DirtyBits.NODE_CAMERA);
                }
            };
        }
        return this.nearClip;
    }
    
    public final void setFarClip(final double n) {
        this.farClipProperty().set(n);
    }
    
    public final double getFarClip() {
        return (this.farClip == null) ? 100.0 : this.farClip.get();
    }
    
    public final DoubleProperty farClipProperty() {
        if (this.farClip == null) {
            this.farClip = new SimpleDoubleProperty(this, "farClip", 100.0) {
                @Override
                protected void invalidated() {
                    Camera.this.clipInSceneValid = false;
                    NodeHelper.markDirty(Camera.this, DirtyBits.NODE_CAMERA);
                }
            };
        }
        return this.farClip;
    }
    
    Camera copy() {
        return this;
    }
    
    private void doUpdatePeer() {
        final NGCamera ngCamera = this.getPeer();
        if (!NodeHelper.isDirtyEmpty(this)) {
            if (this.isDirty(DirtyBits.NODE_CAMERA)) {
                ngCamera.setNearClip((float)this.getNearClip());
                ngCamera.setFarClip((float)this.getFarClip());
                ngCamera.setViewWidth(this.getViewWidth());
                ngCamera.setViewHeight(this.getViewHeight());
            }
            if (this.isDirty(DirtyBits.NODE_CAMERA_TRANSFORM)) {
                ngCamera.setWorldTransform(this.getCameraTransform());
            }
            ngCamera.setProjViewTransform(this.getProjViewTransform());
            this.position = this.computePosition(this.position);
            this.getCameraTransform().transform(this.position, this.position);
            ngCamera.setPosition(this.position);
        }
    }
    
    void setViewWidth(final double viewWidth) {
        this.viewWidth = viewWidth;
        NodeHelper.markDirty(this, DirtyBits.NODE_CAMERA);
    }
    
    double getViewWidth() {
        return this.viewWidth;
    }
    
    void setViewHeight(final double viewHeight) {
        this.viewHeight = viewHeight;
        NodeHelper.markDirty(this, DirtyBits.NODE_CAMERA);
    }
    
    double getViewHeight() {
        return this.viewHeight;
    }
    
    void setOwnerScene(final Scene ownerScene) {
        if (ownerScene == null) {
            this.ownerScene = null;
        }
        else if (ownerScene != this.ownerScene) {
            if (this.ownerScene != null || this.ownerSubScene != null) {
                throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Camera;)Ljava/lang/String;, this));
            }
            this.ownerScene = ownerScene;
            this.markOwnerDirty();
        }
    }
    
    void setOwnerSubScene(final SubScene ownerSubScene) {
        if (ownerSubScene == null) {
            this.ownerSubScene = null;
        }
        else if (ownerSubScene != this.ownerSubScene) {
            if (this.ownerScene != null || this.ownerSubScene != null) {
                throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Camera;)Ljava/lang/String;, this));
            }
            this.ownerSubScene = ownerSubScene;
            this.markOwnerDirty();
        }
    }
    
    private void doMarkDirty(final DirtyBits dirtyBits) {
        if (dirtyBits == DirtyBits.NODE_CAMERA_TRANSFORM) {
            this.localToSceneValid = false;
            this.sceneToLocalValid = false;
            this.clipInSceneValid = false;
            this.projViewTxValid = false;
        }
        else if (dirtyBits == DirtyBits.NODE_CAMERA) {
            this.projViewTxValid = false;
        }
        this.markOwnerDirty();
    }
    
    private void markOwnerDirty() {
        if (this.ownerScene != null) {
            this.ownerScene.markCameraDirty();
        }
        if (this.ownerSubScene != null) {
            this.ownerSubScene.markContentDirty();
        }
    }
    
    Affine3D getCameraTransform() {
        if (!this.localToSceneValid) {
            this.localToSceneTx.setToIdentity();
            TransformHelper.apply(this.getLocalToSceneTransform(), this.localToSceneTx);
            this.localToSceneValid = true;
        }
        return this.localToSceneTx;
    }
    
    abstract void computeProjectionTransform(final GeneralTransform3D p0);
    
    abstract void computeViewTransform(final Affine3D p0);
    
    GeneralTransform3D getProjViewTransform() {
        if (!this.projViewTxValid) {
            this.computeProjectionTransform(this.projTx);
            this.computeViewTransform(this.viewTx);
            this.projViewTx.set(this.projTx);
            this.projViewTx.mul(this.viewTx);
            this.projViewTx.mul(this.getSceneToLocalTransform());
            this.projViewTxValid = true;
        }
        return this.projViewTx;
    }
    
    private Point2D project(final Point3D point3D) {
        final Vec3d transform = this.getProjViewTransform().transform(new Vec3d(point3D.getX(), point3D.getY(), point3D.getZ()));
        return new Point2D(this.getViewWidth() / 2.0 * (1.0 + transform.x), this.getViewHeight() / 2.0 * (1.0 - transform.y));
    }
    
    private Point2D pickNodeXYPlane(final Node node, final double n, final double n2) {
        final PickRay computePickRay = this.computePickRay(n, n2, null);
        final Affine3D affine3D = new Affine3D();
        TransformHelper.apply(node.getLocalToSceneTransform(), affine3D);
        final Vec3d originNoClone = computePickRay.getOriginNoClone();
        final Vec3d directionNoClone = computePickRay.getDirectionNoClone();
        try {
            affine3D.inverseTransform(originNoClone, originNoClone);
            affine3D.inverseDeltaTransform(directionNoClone, directionNoClone);
        }
        catch (NoninvertibleTransformException ex) {
            return null;
        }
        if (Node.almostZero(directionNoClone.z)) {
            return null;
        }
        final double n3 = -originNoClone.z / directionNoClone.z;
        return new Point2D(originNoClone.x + directionNoClone.x * n3, originNoClone.y + directionNoClone.y * n3);
    }
    
    Point3D pickProjectPlane(final double n, final double n2) {
        final PickRay computePickRay = this.computePickRay(n, n2, null);
        final Vec3d vec3d = new Vec3d();
        vec3d.add(computePickRay.getOriginNoClone(), computePickRay.getDirectionNoClone());
        return new Point3D(vec3d.x, vec3d.y, vec3d.z);
    }
    
    abstract PickRay computePickRay(final double p0, final double p1, final PickRay p2);
    
    abstract Vec3d computePosition(final Vec3d p0);
    
    private BaseBounds doComputeGeomBounds(final BaseBounds baseBounds, final BaseTransform baseTransform) {
        return new BoxBounds(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
    }
    
    private boolean doComputeContains(final double n, final double n2) {
        return false;
    }
    
    static {
        CameraHelper.setCameraAccessor(new CameraHelper.CameraAccessor() {
            @Override
            public void doMarkDirty(final Node node, final DirtyBits dirtyBits) {
                ((Camera)node).doMarkDirty(dirtyBits);
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((Camera)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((Camera)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public boolean doComputeContains(final Node node, final double n, final double n2) {
                return ((Camera)node).doComputeContains(n, n2);
            }
            
            @Override
            public Point2D project(final Camera camera, final Point3D point3D) {
                return camera.project(point3D);
            }
            
            @Override
            public Point2D pickNodeXYPlane(final Camera camera, final Node node, final double n, final double n2) {
                return camera.pickNodeXYPlane(node, n, n2);
            }
            
            @Override
            public Point3D pickProjectPlane(final Camera camera, final double n, final double n2) {
                return camera.pickProjectPlane(n, n2);
            }
        });
    }
}
