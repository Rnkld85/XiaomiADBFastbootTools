// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import java.util.ArrayList;
import javafx.scene.text.Font;
import javafx.css.ParsedValue;
import javafx.css.converter.EnumConverter;
import javafx.css.converter.SizeConverter;
import javafx.css.converter.BooleanConverter;
import javafx.css.converter.EffectConverter;
import javafx.css.StyleConverter;
import javafx.css.converter.CursorConverter;
import com.sun.javafx.binding.ExpressionHelper;
import javafx.beans.property.ReadOnlyBooleanPropertyBase;
import com.sun.javafx.effect.EffectDirtyBits;
import javafx.beans.property.IntegerProperty;
import com.sun.javafx.beans.event.AbstractNotifyListener;
import javafx.beans.property.ReadOnlyObjectPropertyBase;
import javafx.beans.property.ObjectPropertyBase;
import com.sun.javafx.scene.transform.TransformUtils;
import javafx.scene.transform.Rotate;
import com.sun.javafx.perf.PerformanceTracker;
import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import java.security.AccessControlContext;
import com.sun.glass.ui.Application;
import javafx.scene.input.PickResult;
import javafx.css.StyleableProperty;
import javafx.css.Style;
import javafx.scene.input.InputEvent;
import javafx.event.EventDispatchChain;
import javafx.beans.property.SimpleObjectProperty;
import javafx.event.Event;
import javafx.beans.binding.BooleanExpression;
import com.sun.javafx.scene.LayoutFlags;
import javafx.event.EventType;
import com.sun.javafx.scene.traversal.Direction;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.TouchEvent;
import javafx.scene.input.SwipeEvent;
import javafx.scene.input.ZoomEvent;
import javafx.scene.input.RotateEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ContextMenuEvent;
import com.sun.javafx.scene.input.PickResultChooser;
import com.sun.javafx.geom.PickRay;
import java.util.Iterator;
import com.sun.javafx.scene.CameraHelper;
import com.sun.javafx.scene.SceneHelper;
import com.sun.javafx.geometry.BoundsUtils;
import com.sun.javafx.scene.SceneUtils;
import javafx.geometry.Point2D;
import com.sun.javafx.geom.transform.NoninvertibleTransformException;
import javafx.scene.shape.Shape3D;
import javafx.geometry.BoundingBox;
import com.sun.javafx.geom.transform.GeneralTransform3D;
import com.sun.javafx.geom.Vec3d;
import javafx.scene.transform.Transform;
import com.sun.javafx.geom.BoxBounds;
import javafx.geometry.Orientation;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.util.Logging;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.BooleanPropertyBase;
import com.sun.javafx.css.PseudoClassState;
import javafx.geometry.Bounds;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import com.sun.javafx.geom.RectBounds;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.input.DragEvent;
import javafx.event.EventHandler;
import javafx.util.Callback;
import com.sun.javafx.tk.Toolkit;
import javafx.geometry.Rectangle2D;
import com.sun.javafx.util.TempState;
import com.sun.javafx.scene.transform.TransformHelper;
import com.sun.javafx.geom.transform.Affine3D;
import javafx.scene.image.WritableImage;
import java.util.LinkedList;
import com.sun.javafx.collections.UnmodifiableListSet;
import java.util.List;
import java.util.Collections;
import java.util.Set;
import javafx.css.Selector;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.css.StyleableObjectProperty;
import javafx.css.StyleableDoubleProperty;
import javafx.css.CssMetaData;
import javafx.css.StyleableBooleanProperty;
import javafx.beans.property.StringPropertyBase;
import javafx.beans.property.ReadOnlyObjectProperty;
import java.util.Map;
import javafx.collections.FXCollections;
import java.util.HashMap;
import com.sun.scenario.effect.EffectHelper;
import com.sun.javafx.util.Utils;
import com.sun.prism.impl.PrismSettings;
import com.sun.javafx.scene.DirtyBits;
import com.sun.glass.ui.Accessible;
import com.sun.javafx.scene.BoundsAccessor;
import javafx.css.PseudoClass;
import javafx.collections.ObservableSet;
import com.sun.javafx.scene.CssFlags;
import com.sun.javafx.scene.NodeEventDispatcher;
import javafx.event.EventDispatcher;
import javafx.scene.input.InputMethodRequests;
import javafx.scene.effect.Effect;
import javafx.geometry.NodeOrientation;
import com.sun.javafx.scene.EventHandlerProperties;
import javafx.geometry.Point3D;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.sg.prism.NGNode;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.scene.effect.BlendMode;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.BooleanProperty;
import javafx.collections.ObservableList;
import javafx.beans.property.StringProperty;
import javafx.stage.Window;
import javafx.beans.value.ChangeListener;
import javafx.beans.InvalidationListener;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.ObservableMap;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.beans.IDProperty;
import javafx.css.Styleable;
import javafx.event.EventTarget;

@IDProperty("id")
public abstract class Node implements EventTarget, Styleable
{
    private NodeHelper nodeHelper;
    private int dirtyBits;
    private BaseBounds _geomBounds;
    private BaseBounds _txBounds;
    private boolean pendingUpdateBounds;
    private static final Object USER_DATA_KEY;
    private ObservableMap<Object, Object> properties;
    private ReadOnlyObjectWrapper<Parent> parent;
    private final InvalidationListener parentDisabledChangedListener;
    private final InvalidationListener parentTreeVisibleChangedListener;
    private final ChangeListener<Boolean> windowShowingChangedListener;
    private final ChangeListener<Window> sceneWindowChangedListener;
    private SubScene subScene;
    private ReadOnlyObjectWrapperManualFire<Scene> scene;
    private StringProperty id;
    private ObservableList<String> styleClass;
    private StringProperty style;
    private BooleanProperty visible;
    private DoubleProperty opacity;
    private ObjectProperty<BlendMode> blendMode;
    private boolean derivedDepthTest;
    private BooleanProperty pickOnBounds;
    private ReadOnlyBooleanWrapper disabled;
    private Node clipParent;
    private NGNode peer;
    private BooleanProperty managed;
    private DoubleProperty layoutX;
    private DoubleProperty layoutY;
    public static final double BASELINE_OFFSET_SAME_AS_HEIGHT = Double.NEGATIVE_INFINITY;
    private LazyBoundsProperty layoutBounds;
    private BaseTransform localToParentTx;
    private boolean transformDirty;
    private BaseBounds txBounds;
    private BaseBounds geomBounds;
    private BaseBounds localBounds;
    boolean boundsChanged;
    private boolean geomBoundsInvalid;
    private boolean localBoundsInvalid;
    private boolean txBoundsInvalid;
    private static final double EPSILON_ABSOLUTE = 1.0E-5;
    private NodeTransformation nodeTransformation;
    private static final double DEFAULT_TRANSLATE_X = 0.0;
    private static final double DEFAULT_TRANSLATE_Y = 0.0;
    private static final double DEFAULT_TRANSLATE_Z = 0.0;
    private static final double DEFAULT_SCALE_X = 1.0;
    private static final double DEFAULT_SCALE_Y = 1.0;
    private static final double DEFAULT_SCALE_Z = 1.0;
    private static final double DEFAULT_ROTATE = 0.0;
    private static final Point3D DEFAULT_ROTATION_AXIS;
    private EventHandlerProperties eventHandlerProperties;
    private ObjectProperty<NodeOrientation> nodeOrientation;
    private EffectiveOrientationProperty effectiveNodeOrientationProperty;
    private static final byte EFFECTIVE_ORIENTATION_LTR = 0;
    private static final byte EFFECTIVE_ORIENTATION_RTL = 1;
    private static final byte EFFECTIVE_ORIENTATION_MASK = 1;
    private static final byte AUTOMATIC_ORIENTATION_LTR = 0;
    private static final byte AUTOMATIC_ORIENTATION_RTL = 2;
    private static final byte AUTOMATIC_ORIENTATION_MASK = 2;
    private byte resolvedNodeOrientation;
    private MiscProperties miscProperties;
    private static final double DEFAULT_VIEW_ORDER = 0.0;
    private static final boolean DEFAULT_CACHE = false;
    private static final CacheHint DEFAULT_CACHE_HINT;
    private static final Node DEFAULT_CLIP;
    private static final Cursor DEFAULT_CURSOR;
    private static final DepthTest DEFAULT_DEPTH_TEST;
    private static final boolean DEFAULT_DISABLE = false;
    private static final Effect DEFAULT_EFFECT;
    private static final InputMethodRequests DEFAULT_INPUT_METHOD_REQUESTS;
    private static final boolean DEFAULT_MOUSE_TRANSPARENT = false;
    private ReadOnlyBooleanWrapper hover;
    private ReadOnlyBooleanWrapper pressed;
    private FocusedProperty focused;
    private BooleanProperty focusTraversable;
    private boolean treeShowing;
    private TreeShowingPropertyReadOnly treeShowingRO;
    private boolean treeVisible;
    private TreeVisiblePropertyReadOnly treeVisibleRO;
    private boolean canReceiveFocus;
    private BooleanProperty showMnemonics;
    private Node labeledBy;
    private ObjectProperty<EventDispatcher> eventDispatcher;
    private NodeEventDispatcher internalEventDispatcher;
    private EventDispatcher preprocessMouseEventDispatcher;
    CssFlags cssFlag;
    final ObservableSet<PseudoClass> pseudoClassStates;
    CssStyleHelper styleHelper;
    private static final PseudoClass HOVER_PSEUDOCLASS_STATE;
    private static final PseudoClass PRESSED_PSEUDOCLASS_STATE;
    private static final PseudoClass DISABLED_PSEUDOCLASS_STATE;
    private static final PseudoClass FOCUSED_PSEUDOCLASS_STATE;
    private static final PseudoClass SHOW_MNEMONICS_PSEUDOCLASS_STATE;
    private static final BoundsAccessor boundsAccessor;
    private ObjectProperty<AccessibleRole> accessibleRole;
    AccessibilityProperties accessibilityProperties;
    Accessible accessible;
    
    private void doMarkDirty(final DirtyBits dirtyBits) {
        if (this.isDirtyEmpty()) {
            this.addToSceneDirtyList();
        }
        this.dirtyBits = (int)((long)this.dirtyBits | dirtyBits.getMask());
    }
    
    private void addToSceneDirtyList() {
        final Scene scene = this.getScene();
        if (scene != null) {
            scene.addToDirtyList(this);
            if (this.getSubScene() != null) {
                this.getSubScene().setDirty(this);
            }
        }
    }
    
    final boolean isDirty(final DirtyBits dirtyBits) {
        return ((long)this.dirtyBits & dirtyBits.getMask()) != 0x0L;
    }
    
    final void clearDirty(final DirtyBits dirtyBits) {
        this.dirtyBits = (int)((long)this.dirtyBits & ~dirtyBits.getMask());
    }
    
    private void setDirty() {
        this.dirtyBits = -1;
    }
    
    private void clearDirty() {
        this.dirtyBits = 0;
    }
    
    final boolean isDirtyEmpty() {
        return this.dirtyBits == 0;
    }
    
    final void syncPeer() {
        if (!this.isDirtyEmpty() && (this.treeVisible || this.isDirty(DirtyBits.NODE_VISIBLE) || this.isDirty(DirtyBits.NODE_FORCE_SYNC))) {
            NodeHelper.updatePeer(this);
            this.clearDirty();
        }
    }
    
    void updateBounds() {
        final Node clip = this.getClip();
        if (clip != null) {
            clip.updateBounds();
        }
        if (!this.treeVisible && !this.isDirty(DirtyBits.NODE_VISIBLE)) {
            if (this.isDirty(DirtyBits.NODE_TRANSFORM) || this.isDirty(DirtyBits.NODE_TRANSFORMED_BOUNDS) || this.isDirty(DirtyBits.NODE_BOUNDS)) {
                this.pendingUpdateBounds = true;
            }
            return;
        }
        if (this.pendingUpdateBounds) {
            NodeHelper.markDirty(this, DirtyBits.NODE_TRANSFORM);
            NodeHelper.markDirty(this, DirtyBits.NODE_TRANSFORMED_BOUNDS);
            NodeHelper.markDirty(this, DirtyBits.NODE_BOUNDS);
            this.pendingUpdateBounds = false;
        }
        if (this.isDirty(DirtyBits.NODE_TRANSFORM) || this.isDirty(DirtyBits.NODE_TRANSFORMED_BOUNDS)) {
            if (this.isDirty(DirtyBits.NODE_TRANSFORM)) {
                this.updateLocalToParentTransform();
            }
            this._txBounds = this.getTransformedBounds(this._txBounds, BaseTransform.IDENTITY_TRANSFORM);
        }
        if (this.isDirty(DirtyBits.NODE_BOUNDS)) {
            this._geomBounds = this.getGeomBounds(this._geomBounds, BaseTransform.IDENTITY_TRANSFORM);
        }
    }
    
    private void doUpdatePeer() {
        final NGNode peer = this.getPeer();
        if (PrismSettings.printRenderGraph && this.isDirty(DirtyBits.DEBUG)) {
            final String id = this.getId();
            String s = this.getClass().getSimpleName();
            if (s.isEmpty()) {
                s = this.getClass().getName();
            }
            peer.setName((id == null) ? s : invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, id, s));
        }
        if (this.isDirty(DirtyBits.NODE_TRANSFORM)) {
            peer.setTransformMatrix(this.localToParentTx);
        }
        if (this.isDirty(DirtyBits.NODE_VIEW_ORDER)) {
            peer.setViewOrder(this.getViewOrder());
        }
        if (this.isDirty(DirtyBits.NODE_BOUNDS)) {
            peer.setContentBounds(this._geomBounds);
        }
        if (this.isDirty(DirtyBits.NODE_TRANSFORMED_BOUNDS)) {
            peer.setTransformedBounds(this._txBounds, !this.isDirty(DirtyBits.NODE_BOUNDS));
        }
        if (this.isDirty(DirtyBits.NODE_OPACITY)) {
            peer.setOpacity((float)Utils.clamp(0.0, this.getOpacity(), 1.0));
        }
        if (this.isDirty(DirtyBits.NODE_CACHE)) {
            peer.setCachedAsBitmap(this.isCache(), this.getCacheHint());
        }
        if (this.isDirty(DirtyBits.NODE_CLIP)) {
            peer.setClipNode((this.getClip() != null) ? this.getClip().getPeer() : null);
        }
        if (this.isDirty(DirtyBits.EFFECT_EFFECT) && this.getEffect() != null) {
            EffectHelper.sync(this.getEffect());
            peer.effectChanged();
        }
        if (this.isDirty(DirtyBits.NODE_EFFECT)) {
            peer.setEffect((this.getEffect() != null) ? EffectHelper.getPeer(this.getEffect()) : null);
        }
        if (this.isDirty(DirtyBits.NODE_VISIBLE)) {
            peer.setVisible(this.isVisible());
        }
        if (this.isDirty(DirtyBits.NODE_DEPTH_TEST)) {
            peer.setDepthTest(this.isDerivedDepthTest());
        }
        if (this.isDirty(DirtyBits.NODE_BLENDMODE)) {
            final BlendMode blendMode = this.getBlendMode();
            peer.setNodeBlendMode((blendMode == null) ? null : EffectHelper.getToolkitBlendMode(blendMode));
        }
    }
    
    public final ObservableMap<Object, Object> getProperties() {
        if (this.properties == null) {
            this.properties = FXCollections.observableMap(new HashMap<Object, Object>());
        }
        return this.properties;
    }
    
    public boolean hasProperties() {
        return this.properties != null && !this.properties.isEmpty();
    }
    
    public void setUserData(final Object o) {
        this.getProperties().put(Node.USER_DATA_KEY, o);
    }
    
    public Object getUserData() {
        return this.getProperties().get(Node.USER_DATA_KEY);
    }
    
    final void setParent(final Parent parent) {
        this.parentPropertyImpl().set(parent);
    }
    
    public final Parent getParent() {
        return (this.parent == null) ? null : this.parent.get();
    }
    
    public final ReadOnlyObjectProperty<Parent> parentProperty() {
        return this.parentPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyObjectWrapper<Parent> parentPropertyImpl() {
        if (this.parent == null) {
            this.parent = new ReadOnlyObjectWrapper<Parent>() {
                private Parent oldParent;
                
                @Override
                protected void invalidated() {
                    if (this.oldParent != null) {
                        this.oldParent.disabledProperty().removeListener(Node.this.parentDisabledChangedListener);
                        this.oldParent.treeVisibleProperty().removeListener(Node.this.parentTreeVisibleChangedListener);
                        if (Node.this.nodeTransformation != null && Node.this.nodeTransformation.listenerReasons > 0) {
                            this.oldParent.localToSceneTransformProperty().removeListener(Node.this.nodeTransformation.getLocalToSceneInvalidationListener());
                        }
                    }
                    Node.this.updateDisabled();
                    Node.this.computeDerivedDepthTest();
                    final Parent oldParent = this.get();
                    if (oldParent != null) {
                        oldParent.disabledProperty().addListener(Node.this.parentDisabledChangedListener);
                        oldParent.treeVisibleProperty().addListener(Node.this.parentTreeVisibleChangedListener);
                        if (Node.this.nodeTransformation != null && Node.this.nodeTransformation.listenerReasons > 0) {
                            oldParent.localToSceneTransformProperty().addListener(Node.this.nodeTransformation.getLocalToSceneInvalidationListener());
                        }
                        Node.this.reapplyCSS();
                    }
                    else {
                        Node.this.cssFlag = CssFlags.CLEAN;
                    }
                    Node.this.updateTreeVisible(true);
                    this.oldParent = oldParent;
                    Node.this.invalidateLocalToSceneTransform();
                    Node.this.parentResolvedOrientationInvalidated();
                    Node.this.notifyAccessibleAttributeChanged(AccessibleAttribute.PARENT);
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "parent";
                }
            };
        }
        return this.parent;
    }
    
    private void invalidatedScenes(final Scene scene, final SubScene subScene) {
        final Scene scene2 = this.sceneProperty().get();
        final boolean b = scene != scene2;
        final SubScene subScene2 = this.subScene;
        if (this.getClip() != null) {
            this.getClip().setScenes(scene2, subScene2);
        }
        if (b) {
            this.updateCanReceiveFocus();
            if (this.isFocusTraversable() && scene2 != null) {
                scene2.initializeInternalEventDispatcher();
            }
            this.focusSetDirty(scene);
            this.focusSetDirty(scene2);
        }
        this.scenesChanged(scene2, subScene2, scene, subScene);
        if (scene != null) {
            scene.windowProperty().removeListener(this.sceneWindowChangedListener);
        }
        if (scene2 != null) {
            scene2.windowProperty().addListener(this.sceneWindowChangedListener);
        }
        this.updateTreeShowing();
        if (b) {
            this.reapplyCSS();
        }
        if (b && !this.isDirtyEmpty()) {
            this.addToSceneDirtyList();
        }
        if (scene2 == null && this.peer != null) {
            this.peer.release();
        }
        if (scene != null) {
            scene.clearNodeMnemonics(this);
        }
        if (this.getParent() == null) {
            this.parentResolvedOrientationInvalidated();
        }
        if (b) {
            this.scene.fireSuperValueChangedEvent();
        }
        if (this.accessible != null) {
            if (scene != null && scene != scene2 && scene2 == null) {
                scene.addAccessible(this, this.accessible);
            }
            else {
                this.accessible.dispose();
            }
            this.accessible = null;
        }
    }
    
    final void setScenes(final Scene scene, final SubScene subScene) {
        final Scene scene2 = this.sceneProperty().get();
        if (scene != scene2 || subScene != this.subScene) {
            this.scene.set(scene);
            final SubScene subScene2 = this.subScene;
            this.subScene = subScene;
            this.invalidatedScenes(scene2, subScene2);
            if (this instanceof SubScene) {
                final SubScene subScene3 = (SubScene)this;
                subScene3.getRoot().setScenes(scene, subScene3);
            }
        }
    }
    
    final SubScene getSubScene() {
        return this.subScene;
    }
    
    public final Scene getScene() {
        return this.scene.get();
    }
    
    public final ReadOnlyObjectProperty<Scene> sceneProperty() {
        return this.scene.getReadOnlyProperty();
    }
    
    void scenesChanged(final Scene scene, final SubScene subScene, final Scene scene2, final SubScene subScene2) {
    }
    
    public final void setId(final String s) {
        this.idProperty().set(s);
    }
    
    @Override
    public final String getId() {
        return (this.id == null) ? null : this.id.get();
    }
    
    public final StringProperty idProperty() {
        if (this.id == null) {
            this.id = new StringPropertyBase() {
                @Override
                protected void invalidated() {
                    Node.this.reapplyCSS();
                    if (PrismSettings.printRenderGraph) {
                        NodeHelper.markDirty(Node.this, DirtyBits.DEBUG);
                    }
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "id";
                }
            };
        }
        return this.id;
    }
    
    @Override
    public final ObservableList<String> getStyleClass() {
        return this.styleClass;
    }
    
    public final void setStyle(final String s) {
        this.styleProperty().set(s);
    }
    
    @Override
    public final String getStyle() {
        return (this.style == null) ? "" : this.style.get();
    }
    
    public final StringProperty styleProperty() {
        if (this.style == null) {
            this.style = new StringPropertyBase("") {
                @Override
                public void set(final String s) {
                    super.set((s != null) ? s : "");
                }
                
                @Override
                protected void invalidated() {
                    Node.this.reapplyCSS();
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "style";
                }
            };
        }
        return this.style;
    }
    
    public final void setVisible(final boolean b) {
        this.visibleProperty().set(b);
    }
    
    public final boolean isVisible() {
        return this.visible == null || this.visible.get();
    }
    
    public final BooleanProperty visibleProperty() {
        if (this.visible == null) {
            this.visible = new StyleableBooleanProperty(true) {
                boolean oldValue = true;
                
                @Override
                protected void invalidated() {
                    if (this.oldValue != this.get()) {
                        NodeHelper.markDirty(Node.this, DirtyBits.NODE_VISIBLE);
                        NodeHelper.geomChanged(Node.this);
                        Node.this.updateTreeVisible(false);
                        if (Node.this.getParent() != null) {
                            Node.this.getParent().childVisibilityChanged(Node.this);
                        }
                        this.oldValue = this.get();
                    }
                }
                
                @Override
                public CssMetaData getCssMetaData() {
                    return StyleableProperties.VISIBILITY;
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "visible";
                }
            };
        }
        return this.visible;
    }
    
    public final void setCursor(final Cursor cursor) {
        this.cursorProperty().set(cursor);
    }
    
    public final Cursor getCursor() {
        return (this.miscProperties == null) ? Node.DEFAULT_CURSOR : this.miscProperties.getCursor();
    }
    
    public final ObjectProperty<Cursor> cursorProperty() {
        return this.getMiscProperties().cursorProperty();
    }
    
    public final void setOpacity(final double n) {
        this.opacityProperty().set(n);
    }
    
    public final double getOpacity() {
        return (this.opacity == null) ? 1.0 : this.opacity.get();
    }
    
    public final DoubleProperty opacityProperty() {
        if (this.opacity == null) {
            this.opacity = new StyleableDoubleProperty(1.0) {
                public void invalidated() {
                    NodeHelper.markDirty(Node.this, DirtyBits.NODE_OPACITY);
                }
                
                @Override
                public CssMetaData getCssMetaData() {
                    return StyleableProperties.OPACITY;
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "opacity";
                }
            };
        }
        return this.opacity;
    }
    
    public final void setBlendMode(final BlendMode blendMode) {
        this.blendModeProperty().set(blendMode);
    }
    
    public final BlendMode getBlendMode() {
        return (this.blendMode == null) ? null : this.blendMode.get();
    }
    
    public final ObjectProperty<BlendMode> blendModeProperty() {
        if (this.blendMode == null) {
            this.blendMode = new StyleableObjectProperty<BlendMode>(null) {
                public void invalidated() {
                    NodeHelper.markDirty(Node.this, DirtyBits.NODE_BLENDMODE);
                }
                
                @Override
                public CssMetaData getCssMetaData() {
                    return StyleableProperties.BLEND_MODE;
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "blendMode";
                }
            };
        }
        return this.blendMode;
    }
    
    public final void setClip(final Node node) {
        this.clipProperty().set(node);
    }
    
    public final Node getClip() {
        return (this.miscProperties == null) ? Node.DEFAULT_CLIP : this.miscProperties.getClip();
    }
    
    public final ObjectProperty<Node> clipProperty() {
        return this.getMiscProperties().clipProperty();
    }
    
    public final void setCache(final boolean b) {
        this.cacheProperty().set(b);
    }
    
    public final boolean isCache() {
        return this.miscProperties != null && this.miscProperties.isCache();
    }
    
    public final BooleanProperty cacheProperty() {
        return this.getMiscProperties().cacheProperty();
    }
    
    public final void setCacheHint(final CacheHint cacheHint) {
        this.cacheHintProperty().set(cacheHint);
    }
    
    public final CacheHint getCacheHint() {
        return (this.miscProperties == null) ? Node.DEFAULT_CACHE_HINT : this.miscProperties.getCacheHint();
    }
    
    public final ObjectProperty<CacheHint> cacheHintProperty() {
        return this.getMiscProperties().cacheHintProperty();
    }
    
    public final void setEffect(final Effect effect) {
        this.effectProperty().set(effect);
    }
    
    public final Effect getEffect() {
        return (this.miscProperties == null) ? Node.DEFAULT_EFFECT : this.miscProperties.getEffect();
    }
    
    public final ObjectProperty<Effect> effectProperty() {
        return this.getMiscProperties().effectProperty();
    }
    
    public final void setDepthTest(final DepthTest depthTest) {
        this.depthTestProperty().set(depthTest);
    }
    
    public final DepthTest getDepthTest() {
        return (this.miscProperties == null) ? Node.DEFAULT_DEPTH_TEST : this.miscProperties.getDepthTest();
    }
    
    public final ObjectProperty<DepthTest> depthTestProperty() {
        return this.getMiscProperties().depthTestProperty();
    }
    
    void computeDerivedDepthTest() {
        boolean derivedDepthTest;
        if (this.getDepthTest() == DepthTest.INHERIT) {
            derivedDepthTest = (this.getParent() == null || this.getParent().isDerivedDepthTest());
        }
        else {
            derivedDepthTest = (this.getDepthTest() == DepthTest.ENABLE);
        }
        if (this.isDerivedDepthTest() != derivedDepthTest) {
            NodeHelper.markDirty(this, DirtyBits.NODE_DEPTH_TEST);
            this.setDerivedDepthTest(derivedDepthTest);
        }
    }
    
    void setDerivedDepthTest(final boolean derivedDepthTest) {
        this.derivedDepthTest = derivedDepthTest;
    }
    
    boolean isDerivedDepthTest() {
        return this.derivedDepthTest;
    }
    
    public final void setDisable(final boolean b) {
        this.disableProperty().set(b);
    }
    
    public final boolean isDisable() {
        return this.miscProperties != null && this.miscProperties.isDisable();
    }
    
    public final BooleanProperty disableProperty() {
        return this.getMiscProperties().disableProperty();
    }
    
    public final void setPickOnBounds(final boolean b) {
        this.pickOnBoundsProperty().set(b);
    }
    
    public final boolean isPickOnBounds() {
        return this.pickOnBounds != null && this.pickOnBounds.get();
    }
    
    public final BooleanProperty pickOnBoundsProperty() {
        if (this.pickOnBounds == null) {
            this.pickOnBounds = new SimpleBooleanProperty(this, "pickOnBounds");
        }
        return this.pickOnBounds;
    }
    
    protected final void setDisabled(final boolean b) {
        this.disabledPropertyImpl().set(b);
    }
    
    public final boolean isDisabled() {
        return this.disabled != null && this.disabled.get();
    }
    
    public final ReadOnlyBooleanProperty disabledProperty() {
        return this.disabledPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper disabledPropertyImpl() {
        if (this.disabled == null) {
            this.disabled = new ReadOnlyBooleanWrapper() {
                @Override
                protected void invalidated() {
                    Node.this.pseudoClassStateChanged(Node.DISABLED_PSEUDOCLASS_STATE, this.get());
                    Node.this.updateCanReceiveFocus();
                    Node.this.focusSetDirty(Node.this.getScene());
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "disabled";
                }
            };
        }
        return this.disabled;
    }
    
    private void updateDisabled() {
        boolean disable = this.isDisable();
        if (!disable) {
            disable = ((this.getParent() != null) ? this.getParent().isDisabled() : (this.getSubScene() != null && this.getSubScene().isDisabled()));
        }
        this.setDisabled(disable);
        if (this instanceof SubScene) {
            ((SubScene)this).getRoot().setDisabled(disable);
        }
    }
    
    public Node lookup(final String s) {
        if (s == null) {
            return null;
        }
        final Selector selector = Selector.createSelector(s);
        return (selector != null && selector.applies(this)) ? this : null;
    }
    
    public Set<Node> lookupAll(final String s) {
        final Selector selector = Selector.createSelector(s);
        final Set<Node> emptySet = Collections.emptySet();
        if (selector == null) {
            return emptySet;
        }
        final List<Node> lookupAll = this.lookupAll(selector, null);
        return (lookupAll == null) ? emptySet : new UnmodifiableListSet<Node>((List<Object>)lookupAll);
    }
    
    List<Node> lookupAll(final Selector selector, List<Node> list) {
        if (selector.applies(this)) {
            if (list == null) {
                list = new LinkedList<Node>();
            }
            list.add(this);
        }
        return list;
    }
    
    public void toBack() {
        if (this.getParent() != null) {
            this.getParent().toBack(this);
        }
    }
    
    public void toFront() {
        if (this.getParent() != null) {
            this.getParent().toFront(this);
        }
    }
    
    private void doCSSPass() {
        if (this.cssFlag != CssFlags.CLEAN) {
            this.processCSS();
        }
    }
    
    private static void syncAll(final Node node) {
        node.syncPeer();
        if (node instanceof Parent) {
            final Parent parent = (Parent)node;
            for (int size = parent.getChildren().size(), i = 0; i < size; ++i) {
                final Node node2 = parent.getChildren().get(i);
                if (node2 != null) {
                    syncAll(node2);
                }
            }
        }
        if (node.getClip() != null) {
            syncAll(node.getClip());
        }
    }
    
    private void doLayoutPass() {
        if (this instanceof Parent) {
            final Parent parent = (Parent)this;
            for (int i = 0; i < 3; ++i) {
                parent.layout();
            }
        }
    }
    
    private void doCSSLayoutSyncForSnapshot() {
        this.doCSSPass();
        this.doLayoutPass();
        this.updateBounds();
        Scene.setAllowPGAccess(true);
        syncAll(this);
        Scene.setAllowPGAccess(false);
    }
    
    private WritableImage doSnapshot(final SnapshotParameters snapshotParameters, final WritableImage writableImage) {
        if (this.getScene() != null) {
            this.getScene().doCSSLayoutSyncForSnapshot(this);
        }
        else {
            this.doCSSLayoutSyncForSnapshot();
        }
        BaseTransform identity_TRANSFORM = BaseTransform.IDENTITY_TRANSFORM;
        if (snapshotParameters.getTransform() != null) {
            final Affine3D affine3D = new Affine3D();
            TransformHelper.apply(snapshotParameters.getTransform(), affine3D);
            identity_TRANSFORM = affine3D;
        }
        final Rectangle2D viewport = snapshotParameters.getViewport();
        double minX;
        double minY;
        double width;
        double height;
        if (viewport != null) {
            minX = viewport.getMinX();
            minY = viewport.getMinY();
            width = viewport.getWidth();
            height = viewport.getHeight();
        }
        else {
            final BaseBounds transformedBounds = this.getTransformedBounds(TempState.getInstance().bounds, identity_TRANSFORM);
            minX = transformedBounds.getMinX();
            minY = transformedBounds.getMinY();
            width = transformedBounds.getWidth();
            height = transformedBounds.getHeight();
        }
        return Scene.doSnapshot(this.getScene(), minX, minY, width, height, this, identity_TRANSFORM, snapshotParameters.isDepthBufferInternal(), snapshotParameters.getFill(), snapshotParameters.getEffectiveCamera(), writableImage);
    }
    
    public WritableImage snapshot(SnapshotParameters snapshotParameters, final WritableImage writableImage) {
        Toolkit.getToolkit().checkFxUserThread();
        if (snapshotParameters == null) {
            snapshotParameters = new SnapshotParameters();
            final Scene scene = this.getScene();
            if (scene != null) {
                snapshotParameters.setCamera(scene.getEffectiveCamera());
                snapshotParameters.setDepthBuffer(scene.isDepthBufferInternal());
                snapshotParameters.setFill(scene.getFill());
            }
        }
        return this.doSnapshot(snapshotParameters, writableImage);
    }
    
    public void snapshot(final Callback<SnapshotResult, Void> callback, SnapshotParameters copy, final WritableImage writableImage) {
        Toolkit.getToolkit().checkFxUserThread();
        if (callback == null) {
            throw new NullPointerException("The callback must not be null");
        }
        if (copy == null) {
            copy = new SnapshotParameters();
            final Scene scene = this.getScene();
            if (scene != null) {
                copy.setCamera(scene.getEffectiveCamera());
                copy.setDepthBuffer(scene.isDepthBufferInternal());
                copy.setFill(scene.getFill());
            }
        }
        else {
            copy = copy.copy();
        }
        final SnapshotResult snapshotResult;
        Void void1;
        Scene.addSnapshotRunnable(() -> {
            snapshotResult = new SnapshotResult(this.doSnapshot(copy, writableImage), this, copy);
            try {
                void1 = callback.call(snapshotResult);
            }
            catch (Throwable t) {
                System.err.println("Exception in snapshot callback");
                t.printStackTrace(System.err);
            }
        });
    }
    
    public final void setOnDragEntered(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragEnteredProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragEntered() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnDragEntered();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragEnteredProperty() {
        return this.getEventHandlerProperties().onDragEnteredProperty();
    }
    
    public final void setOnDragExited(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragExitedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragExited() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnDragExited();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragExitedProperty() {
        return this.getEventHandlerProperties().onDragExitedProperty();
    }
    
    public final void setOnDragOver(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragOverProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragOver() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnDragOver();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragOverProperty() {
        return this.getEventHandlerProperties().onDragOverProperty();
    }
    
    public final void setOnDragDropped(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragDroppedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragDropped() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnDragDropped();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragDroppedProperty() {
        return this.getEventHandlerProperties().onDragDroppedProperty();
    }
    
    public final void setOnDragDone(final EventHandler<? super DragEvent> eventHandler) {
        this.onDragDoneProperty().set(eventHandler);
    }
    
    public final EventHandler<? super DragEvent> getOnDragDone() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnDragDone();
    }
    
    public final ObjectProperty<EventHandler<? super DragEvent>> onDragDoneProperty() {
        return this.getEventHandlerProperties().onDragDoneProperty();
    }
    
    public Dragboard startDragAndDrop(final TransferMode... array) {
        if (this.getScene() != null) {
            return this.getScene().startDragAndDrop(this, array);
        }
        throw new IllegalStateException("Cannot start drag and drop on node that is not in scene");
    }
    
    public void startFullDrag() {
        if (this.getScene() != null) {
            this.getScene().startFullDrag(this);
            return;
        }
        throw new IllegalStateException("Cannot start full drag on node that is not in scene");
    }
    
    final Node getClipParent() {
        return this.clipParent;
    }
    
    boolean isConnected() {
        return this.getParent() != null || this.clipParent != null;
    }
    
    boolean wouldCreateCycle(final Node node, final Node node2) {
        if (node2 != null && node2.getClip() == null && !(node2 instanceof Parent)) {
            return false;
        }
        Node node3 = node;
        while (node3 != node2) {
            if (node3.getParent() != null) {
                node3 = node3.getParent();
            }
            else if (node3.getSubScene() != null) {
                node3 = node3.getSubScene();
            }
            else {
                if (node3.clipParent == null) {
                    return false;
                }
                node3 = node3.clipParent;
            }
        }
        return true;
    }
    
     <P extends NGNode> P getPeer() {
        if (Utils.assertionEnabled() && this.getScene() != null && !Scene.isPGAccessAllowed()) {
            System.err.println();
            System.err.println("*** unexpected PG access");
            Thread.dumpStack();
        }
        if (this.peer == null) {
            this.peer = NodeHelper.createPeer(this);
        }
        return (P)this.peer;
    }
    
    protected Node() {
        this.nodeHelper = null;
        this._geomBounds = new RectBounds(0.0f, 0.0f, -1.0f, -1.0f);
        this._txBounds = new RectBounds(0.0f, 0.0f, -1.0f, -1.0f);
        this.pendingUpdateBounds = false;
        this.parentDisabledChangedListener = (p0 -> this.updateDisabled());
        this.parentTreeVisibleChangedListener = (p0 -> this.updateTreeVisible(true));
        this.windowShowingChangedListener = ((p0, p1, p2) -> this.updateTreeShowing());
        this.sceneWindowChangedListener = ((p0, window, window2) -> {
            if (window != null) {
                window.showingProperty().removeListener(this.windowShowingChangedListener);
            }
            if (window2 != null) {
                window2.showingProperty().addListener(this.windowShowingChangedListener);
            }
            this.updateTreeShowing();
            return;
        });
        this.subScene = null;
        this.scene = new ReadOnlyObjectWrapperManualFire<Scene>();
        this.styleClass = new TrackableObservableList<String>() {
            @Override
            protected void onChanged(final ListChangeListener.Change<String> change) {
                Node.this.reapplyCSS();
            }
            
            @Override
            public String toString() {
                if (this.size() == 0) {
                    return "";
                }
                if (this.size() == 1) {
                    return this.get(0);
                }
                final StringBuilder sb = new StringBuilder();
                for (int i = 0; i < this.size(); ++i) {
                    sb.append(this.get(i));
                    if (i + 1 < this.size()) {
                        sb.append(' ');
                    }
                }
                return sb.toString();
            }
        };
        this.derivedDepthTest = true;
        this.layoutBounds = new LazyBoundsProperty() {
            @Override
            protected Bounds computeBounds() {
                return NodeHelper.computeLayoutBounds(Node.this);
            }
            
            @Override
            public Object getBean() {
                return Node.this;
            }
            
            @Override
            public String getName() {
                return "layoutBounds";
            }
        };
        this.localToParentTx = BaseTransform.IDENTITY_TRANSFORM;
        this.transformDirty = true;
        this.txBounds = new RectBounds();
        this.geomBounds = new RectBounds();
        this.localBounds = null;
        this.geomBoundsInvalid = true;
        this.localBoundsInvalid = true;
        this.txBoundsInvalid = true;
        this.resolvedNodeOrientation = 0;
        this.canReceiveFocus = false;
        this.labeledBy = null;
        this.cssFlag = CssFlags.CLEAN;
        this.pseudoClassStates = new PseudoClassState();
        this.setDirty();
        this.updateTreeVisible(false);
    }
    
    public final void setManaged(final boolean b) {
        this.managedProperty().set(b);
    }
    
    public final boolean isManaged() {
        return this.managed == null || this.managed.get();
    }
    
    public final BooleanProperty managedProperty() {
        if (this.managed == null) {
            this.managed = new BooleanPropertyBase(true) {
                @Override
                protected void invalidated() {
                    final Parent parent = Node.this.getParent();
                    if (parent != null) {
                        parent.managedChildChanged();
                    }
                    Node.this.notifyManagedChanged();
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "managed";
                }
            };
        }
        return this.managed;
    }
    
    void notifyManagedChanged() {
    }
    
    public final void setLayoutX(final double n) {
        this.layoutXProperty().set(n);
    }
    
    public final double getLayoutX() {
        return (this.layoutX == null) ? 0.0 : this.layoutX.get();
    }
    
    public final DoubleProperty layoutXProperty() {
        if (this.layoutX == null) {
            this.layoutX = new DoublePropertyBase(0.0) {
                @Override
                protected void invalidated() {
                    NodeHelper.transformsChanged(Node.this);
                    final Parent parent = Node.this.getParent();
                    if (parent != null && !parent.isCurrentLayoutChild(Node.this)) {
                        if (Node.this.isManaged()) {
                            parent.requestLayout(true);
                        }
                        else {
                            parent.clearSizeCache();
                            parent.requestParentLayout();
                        }
                    }
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "layoutX";
                }
            };
        }
        return this.layoutX;
    }
    
    public final void setLayoutY(final double n) {
        this.layoutYProperty().set(n);
    }
    
    public final double getLayoutY() {
        return (this.layoutY == null) ? 0.0 : this.layoutY.get();
    }
    
    public final DoubleProperty layoutYProperty() {
        if (this.layoutY == null) {
            this.layoutY = new DoublePropertyBase(0.0) {
                @Override
                protected void invalidated() {
                    NodeHelper.transformsChanged(Node.this);
                    final Parent parent = Node.this.getParent();
                    if (parent != null && !parent.isCurrentLayoutChild(Node.this)) {
                        if (Node.this.isManaged()) {
                            parent.requestLayout(true);
                        }
                        else {
                            parent.clearSizeCache();
                            parent.requestParentLayout();
                        }
                    }
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "layoutY";
                }
            };
        }
        return this.layoutY;
    }
    
    public void relocate(final double n, final double n2) {
        this.setLayoutX(n - this.getLayoutBounds().getMinX());
        this.setLayoutY(n2 - this.getLayoutBounds().getMinY());
        final PlatformLogger layoutLogger = Logging.getLayoutLogger();
        if (layoutLogger.isLoggable(PlatformLogger.Level.FINER)) {
            layoutLogger.finer(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;DD)Ljava/lang/String;, this.toString(), n, n2));
        }
    }
    
    public boolean isResizable() {
        return false;
    }
    
    public Orientation getContentBias() {
        return null;
    }
    
    public double minWidth(final double n) {
        return this.prefWidth(n);
    }
    
    public double minHeight(final double n) {
        return this.prefHeight(n);
    }
    
    public double prefWidth(final double n) {
        final double width = this.getLayoutBounds().getWidth();
        return (Double.isNaN(width) || width < 0.0) ? 0.0 : width;
    }
    
    public double prefHeight(final double n) {
        final double height = this.getLayoutBounds().getHeight();
        return (Double.isNaN(height) || height < 0.0) ? 0.0 : height;
    }
    
    public double maxWidth(final double n) {
        return this.prefWidth(n);
    }
    
    public double maxHeight(final double n) {
        return this.prefHeight(n);
    }
    
    public void resize(final double n, final double n2) {
    }
    
    public final void autosize() {
        if (this.isResizable()) {
            final Orientation contentBias = this.getContentBias();
            double n;
            double n2;
            if (contentBias == null) {
                n = this.boundedSize(this.prefWidth(-1.0), this.minWidth(-1.0), this.maxWidth(-1.0));
                n2 = this.boundedSize(this.prefHeight(-1.0), this.minHeight(-1.0), this.maxHeight(-1.0));
            }
            else if (contentBias == Orientation.HORIZONTAL) {
                n = this.boundedSize(this.prefWidth(-1.0), this.minWidth(-1.0), this.maxWidth(-1.0));
                n2 = this.boundedSize(this.prefHeight(n), this.minHeight(n), this.maxHeight(n));
            }
            else {
                n2 = this.boundedSize(this.prefHeight(-1.0), this.minHeight(-1.0), this.maxHeight(-1.0));
                n = this.boundedSize(this.prefWidth(n2), this.minWidth(n2), this.maxWidth(n2));
            }
            this.resize(n, n2);
        }
    }
    
    double boundedSize(final double a, final double n, final double b) {
        return Math.min(Math.max(a, n), Math.max(n, b));
    }
    
    public void resizeRelocate(final double n, final double n2, final double n3, final double n4) {
        this.resize(n3, n4);
        this.relocate(n, n2);
    }
    
    public double getBaselineOffset() {
        if (this.isResizable()) {
            return Double.NEGATIVE_INFINITY;
        }
        return this.getLayoutBounds().getHeight();
    }
    
    public double computeAreaInScreen() {
        return this.doComputeAreaInScreen();
    }
    
    private double doComputeAreaInScreen() {
        final Scene scene = this.getScene();
        if (scene != null) {
            final Bounds boundsInLocal = this.getBoundsInLocal();
            final Camera effectiveCamera = scene.getEffectiveCamera();
            final boolean b = effectiveCamera instanceof PerspectiveCamera;
            final Transform localToSceneTransform = this.getLocalToSceneTransform();
            final Affine3D tempTx = TempState.getInstance().tempTx;
            final BoxBounds boxBounds = new BoxBounds((float)boundsInLocal.getMinX(), (float)boundsInLocal.getMinY(), (float)boundsInLocal.getMinZ(), (float)boundsInLocal.getMaxX(), (float)boundsInLocal.getMaxY(), (float)boundsInLocal.getMaxZ());
            if (b) {
                final Transform localToSceneTransform2 = effectiveCamera.getLocalToSceneTransform();
                if (localToSceneTransform2.getMxx() == 1.0 && localToSceneTransform2.getMxy() == 0.0 && localToSceneTransform2.getMxz() == 0.0 && localToSceneTransform2.getMyx() == 0.0 && localToSceneTransform2.getMyy() == 1.0 && localToSceneTransform2.getMyz() == 0.0 && localToSceneTransform2.getMzx() == 0.0 && localToSceneTransform2.getMzy() == 0.0 && localToSceneTransform2.getMzz() == 1.0) {
                    double n;
                    double n2;
                    if (localToSceneTransform.getMxx() == 1.0 && localToSceneTransform.getMxy() == 0.0 && localToSceneTransform.getMxz() == 0.0 && localToSceneTransform.getMyx() == 0.0 && localToSceneTransform.getMyy() == 1.0 && localToSceneTransform.getMyz() == 0.0 && localToSceneTransform.getMzx() == 0.0 && localToSceneTransform.getMzy() == 0.0 && localToSceneTransform.getMzz() == 1.0) {
                        final Vec3d vec3d = TempState.getInstance().vec3d;
                        vec3d.set(0.0, 0.0, boundsInLocal.getMinZ());
                        this.localToScene(vec3d);
                        n = vec3d.z;
                        vec3d.set(0.0, 0.0, boundsInLocal.getMaxZ());
                        this.localToScene(vec3d);
                        n2 = vec3d.z;
                    }
                    else {
                        final Bounds localToScene = this.localToScene(boundsInLocal);
                        n = localToScene.getMinZ();
                        n2 = localToScene.getMaxZ();
                    }
                    if (n > effectiveCamera.getFarClipInScene() || n2 < effectiveCamera.getNearClipInScene()) {
                        return 0.0;
                    }
                }
                else {
                    final BoxBounds boxBounds2 = new BoxBounds();
                    tempTx.setToIdentity();
                    TransformHelper.apply(localToSceneTransform, tempTx);
                    tempTx.preConcatenate(effectiveCamera.getSceneToLocalTransform());
                    tempTx.transform(boxBounds, boxBounds2);
                    if (boxBounds2.getMinZ() > effectiveCamera.getFarClip() || boxBounds2.getMaxZ() < effectiveCamera.getNearClip()) {
                        return 0.0;
                    }
                }
            }
            final GeneralTransform3D projViewTx = TempState.getInstance().projViewTx;
            projViewTx.set(effectiveCamera.getProjViewTransform());
            tempTx.setToIdentity();
            TransformHelper.apply(localToSceneTransform, tempTx);
            final BaseBounds transform = projViewTx.mul(tempTx).transform(boxBounds, boxBounds);
            double n3 = transform.getWidth() * transform.getHeight();
            if (b) {
                transform.intersectWith(-1.0f, -1.0f, 0.0f, 1.0f, 1.0f, 1.0f);
                n3 = ((transform.getWidth() < 0.0f || transform.getHeight() < 0.0f) ? 0.0 : n3);
            }
            return n3 * (effectiveCamera.getViewWidth() / 2.0 * effectiveCamera.getViewHeight() / 2.0);
        }
        return 0.0;
    }
    
    public final Bounds getBoundsInParent() {
        return this.boundsInParentProperty().get();
    }
    
    public final ReadOnlyObjectProperty<Bounds> boundsInParentProperty() {
        return this.getMiscProperties().boundsInParentProperty();
    }
    
    private void invalidateBoundsInParent() {
        if (this.miscProperties != null) {
            this.miscProperties.invalidateBoundsInParent();
        }
    }
    
    public final Bounds getBoundsInLocal() {
        return this.boundsInLocalProperty().get();
    }
    
    public final ReadOnlyObjectProperty<Bounds> boundsInLocalProperty() {
        return this.getMiscProperties().boundsInLocalProperty();
    }
    
    private void invalidateBoundsInLocal() {
        if (this.miscProperties != null) {
            this.miscProperties.invalidateBoundsInLocal();
        }
    }
    
    public final Bounds getLayoutBounds() {
        return this.layoutBoundsProperty().get();
    }
    
    public final ReadOnlyObjectProperty<Bounds> layoutBoundsProperty() {
        return this.layoutBounds;
    }
    
    private Bounds doComputeLayoutBounds() {
        final BaseBounds geomBounds = this.getGeomBounds(TempState.getInstance().bounds, BaseTransform.IDENTITY_TRANSFORM);
        return new BoundingBox(geomBounds.getMinX(), geomBounds.getMinY(), geomBounds.getMinZ(), geomBounds.getWidth(), geomBounds.getHeight(), geomBounds.getDepth());
    }
    
    final void layoutBoundsChanged() {
        if (!this.layoutBounds.valid) {
            return;
        }
        this.layoutBounds.invalidate();
        if ((this.nodeTransformation != null && this.nodeTransformation.hasScaleOrRotate()) || this.hasMirroring()) {
            NodeHelper.transformsChanged(this);
        }
    }
    
    BaseBounds getTransformedBounds(BaseBounds baseBounds, final BaseTransform baseTransform) {
        this.updateLocalToParentTransform();
        if (baseTransform.isTranslateOrIdentity()) {
            this.updateTxBounds();
            baseBounds = baseBounds.deriveWithNewBounds(this.txBounds);
            if (!baseTransform.isIdentity()) {
                final double mxt = baseTransform.getMxt();
                final double myt = baseTransform.getMyt();
                final double mzt = baseTransform.getMzt();
                baseBounds = baseBounds.deriveWithNewBounds((float)(baseBounds.getMinX() + mxt), (float)(baseBounds.getMinY() + myt), (float)(baseBounds.getMinZ() + mzt), (float)(baseBounds.getMaxX() + mxt), (float)(baseBounds.getMaxY() + myt), (float)(baseBounds.getMaxZ() + mzt));
            }
            return baseBounds;
        }
        if (this.localToParentTx.isIdentity()) {
            return this.getLocalBounds(baseBounds, baseTransform);
        }
        final double mxx = baseTransform.getMxx();
        final double mxy = baseTransform.getMxy();
        final double mxz = baseTransform.getMxz();
        final double mxt2 = baseTransform.getMxt();
        final double myx = baseTransform.getMyx();
        final double myy = baseTransform.getMyy();
        final double myz = baseTransform.getMyz();
        final double myt2 = baseTransform.getMyt();
        final double mzx = baseTransform.getMzx();
        final double mzy = baseTransform.getMzy();
        final double mzz = baseTransform.getMzz();
        final double mzt2 = baseTransform.getMzt();
        final BaseTransform deriveWithConcatenation = baseTransform.deriveWithConcatenation(this.localToParentTx);
        baseBounds = this.getLocalBounds(baseBounds, deriveWithConcatenation);
        if (deriveWithConcatenation == baseTransform) {
            baseTransform.restoreTransform(mxx, mxy, mxz, mxt2, myx, myy, myz, myt2, mzx, mzy, mzz, mzt2);
        }
        return baseBounds;
    }
    
    BaseBounds getLocalBounds(BaseBounds baseBounds, final BaseTransform baseTransform) {
        if (this.getEffect() == null && this.getClip() == null) {
            return this.getGeomBounds(baseBounds, baseTransform);
        }
        if (baseTransform.isTranslateOrIdentity()) {
            this.updateLocalBounds();
            baseBounds = baseBounds.deriveWithNewBounds(this.localBounds);
            if (!baseTransform.isIdentity()) {
                final double mxt = baseTransform.getMxt();
                final double myt = baseTransform.getMyt();
                final double mzt = baseTransform.getMzt();
                baseBounds = baseBounds.deriveWithNewBounds((float)(baseBounds.getMinX() + mxt), (float)(baseBounds.getMinY() + myt), (float)(baseBounds.getMinZ() + mzt), (float)(baseBounds.getMaxX() + mxt), (float)(baseBounds.getMaxY() + myt), (float)(baseBounds.getMaxZ() + mzt));
            }
            return baseBounds;
        }
        if (baseTransform.is2D() && (baseTransform.getType() & 0xFFFFFFB4) != 0x0) {
            return this.computeLocalBounds(baseBounds, baseTransform);
        }
        this.updateLocalBounds();
        return baseTransform.transform(this.localBounds, baseBounds);
    }
    
    BaseBounds getGeomBounds(BaseBounds baseBounds, final BaseTransform baseTransform) {
        if (baseTransform.isTranslateOrIdentity()) {
            this.updateGeomBounds();
            baseBounds = baseBounds.deriveWithNewBounds(this.geomBounds);
            if (!baseTransform.isIdentity()) {
                final double mxt = baseTransform.getMxt();
                final double myt = baseTransform.getMyt();
                final double mzt = baseTransform.getMzt();
                baseBounds = baseBounds.deriveWithNewBounds((float)(baseBounds.getMinX() + mxt), (float)(baseBounds.getMinY() + myt), (float)(baseBounds.getMinZ() + mzt), (float)(baseBounds.getMaxX() + mxt), (float)(baseBounds.getMaxY() + myt), (float)(baseBounds.getMaxZ() + mzt));
            }
            return baseBounds;
        }
        if (baseTransform.is2D() && (baseTransform.getType() & 0xFFFFFFB4) != 0x0) {
            return NodeHelper.computeGeomBounds(this, baseBounds, baseTransform);
        }
        this.updateGeomBounds();
        return baseTransform.transform(this.geomBounds, baseBounds);
    }
    
    void updateGeomBounds() {
        if (this.geomBoundsInvalid) {
            this.geomBounds = NodeHelper.computeGeomBounds(this, this.geomBounds, BaseTransform.IDENTITY_TRANSFORM);
            this.geomBoundsInvalid = false;
        }
    }
    
    private BaseBounds computeLocalBounds(BaseBounds baseBounds, final BaseTransform baseTransform) {
        if (this.getEffect() != null) {
            baseBounds = baseBounds.deriveWithNewBounds(EffectHelper.getBounds(this.getEffect(), baseBounds, baseTransform, this, Node.boundsAccessor));
        }
        else {
            baseBounds = this.getGeomBounds(baseBounds, baseTransform);
        }
        if (this.getClip() != null && !(this instanceof Shape3D) && !(this.getClip() instanceof Shape3D)) {
            final double n = baseBounds.getMinX();
            final double n2 = baseBounds.getMinY();
            final double n3 = baseBounds.getMaxX();
            final double n4 = baseBounds.getMaxY();
            final double n5 = baseBounds.getMinZ();
            final double n6 = baseBounds.getMaxZ();
            baseBounds = this.getClip().getTransformedBounds(baseBounds, baseTransform);
            baseBounds.intersectWith((float)n, (float)n2, (float)n5, (float)n3, (float)n4, (float)n6);
        }
        return baseBounds;
    }
    
    private void updateLocalBounds() {
        if (this.localBoundsInvalid) {
            if (this.getClip() != null || this.getEffect() != null) {
                this.localBounds = this.computeLocalBounds((this.localBounds == null) ? new RectBounds() : this.localBounds, BaseTransform.IDENTITY_TRANSFORM);
            }
            else {
                this.localBounds = null;
            }
            this.localBoundsInvalid = false;
        }
    }
    
    void updateTxBounds() {
        if (this.txBoundsInvalid) {
            this.updateLocalToParentTransform();
            this.txBounds = this.getLocalBounds(this.txBounds, this.localToParentTx);
            this.txBoundsInvalid = false;
        }
    }
    
    private void doGeomChanged() {
        if (this.geomBoundsInvalid) {
            NodeHelper.notifyLayoutBoundsChanged(this);
            this.transformedBoundsChanged();
            return;
        }
        this.geomBounds.makeEmpty();
        this.geomBoundsInvalid = true;
        NodeHelper.markDirty(this, DirtyBits.NODE_BOUNDS);
        NodeHelper.notifyLayoutBoundsChanged(this);
        this.localBoundsChanged();
    }
    
    void localBoundsChanged() {
        this.localBoundsInvalid = true;
        this.invalidateBoundsInLocal();
        this.transformedBoundsChanged();
    }
    
    void transformedBoundsChanged() {
        if (!this.txBoundsInvalid) {
            this.txBounds.makeEmpty();
            this.txBoundsInvalid = true;
            this.invalidateBoundsInParent();
            NodeHelper.markDirty(this, DirtyBits.NODE_TRANSFORMED_BOUNDS);
        }
        if (this.isVisible()) {
            this.notifyParentOfBoundsChange();
        }
    }
    
    private void doNotifyLayoutBoundsChanged() {
        this.layoutBoundsChanged();
        final Parent parent = this.getParent();
        if (this.isManaged() && parent != null && (!(parent instanceof Group) || this.isResizable()) && !parent.isPerformingLayout()) {
            parent.requestLayout(true);
        }
    }
    
    void notifyParentOfBoundsChange() {
        final Parent parent = this.getParent();
        if (parent != null) {
            parent.childBoundsChanged(this);
        }
        if (this.clipParent != null) {
            this.clipParent.localBoundsChanged();
        }
    }
    
    public boolean contains(final double n, final double n2) {
        return this.containsBounds(n, n2) && (this.isPickOnBounds() || NodeHelper.computeContains(this, n, n2));
    }
    
    private boolean containsBounds(final double n, final double n2) {
        final TempState instance = TempState.getInstance();
        if (this.getLocalBounds(instance.bounds, BaseTransform.IDENTITY_TRANSFORM).contains((float)n, (float)n2)) {
            if (this.getClip() != null) {
                instance.point.x = (float)n;
                instance.point.y = (float)n2;
                try {
                    this.getClip().parentToLocal(instance.point);
                }
                catch (NoninvertibleTransformException ex) {
                    return false;
                }
                if (!this.getClip().contains(instance.point.x, instance.point.y)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    
    public boolean contains(final Point2D point2D) {
        return this.contains(point2D.getX(), point2D.getY());
    }
    
    public boolean intersects(final double n, final double n2, final double n3, final double n4) {
        return this.getLocalBounds(TempState.getInstance().bounds, BaseTransform.IDENTITY_TRANSFORM).intersects((float)n, (float)n2, (float)n3, (float)n4);
    }
    
    public boolean intersects(final Bounds bounds) {
        return this.intersects(bounds.getMinX(), bounds.getMinY(), bounds.getWidth(), bounds.getHeight());
    }
    
    public Point2D screenToLocal(final double n, final double n2) {
        final Scene scene = this.getScene();
        if (scene == null) {
            return null;
        }
        final Window window = scene.getWindow();
        if (window == null) {
            return null;
        }
        final com.sun.javafx.geom.Point2D point = TempState.getInstance().point;
        point.setLocation((float)(n - scene.getX() - window.getX()), (float)(n2 - scene.getY() - window.getY()));
        final SubScene subScene = this.getSubScene();
        if (subScene != null) {
            final Point2D sceneToSubScenePlane = SceneUtils.sceneToSubScenePlane(subScene, new Point2D(point.x, point.y));
            if (sceneToSubScenePlane == null) {
                return null;
            }
            point.setLocation((float)sceneToSubScenePlane.getX(), (float)sceneToSubScenePlane.getY());
        }
        final Point3D pickProjectPlane = scene.getEffectiveCamera().pickProjectPlane(point.x, point.y);
        point.setLocation((float)pickProjectPlane.getX(), (float)pickProjectPlane.getY());
        try {
            this.sceneToLocal(point);
        }
        catch (NoninvertibleTransformException ex) {
            return null;
        }
        return new Point2D(point.x, point.y);
    }
    
    public Point2D screenToLocal(final Point2D point2D) {
        return this.screenToLocal(point2D.getX(), point2D.getY());
    }
    
    public Bounds screenToLocal(final Bounds bounds) {
        return BoundsUtils.createBoundingBox(this.screenToLocal(bounds.getMinX(), bounds.getMinY()), this.screenToLocal(bounds.getMinX(), bounds.getMaxY()), this.screenToLocal(bounds.getMaxX(), bounds.getMinY()), this.screenToLocal(bounds.getMaxX(), bounds.getMaxY()));
    }
    
    public Point2D sceneToLocal(final double n, final double n2, final boolean b) {
        if (!b) {
            return this.sceneToLocal(n, n2);
        }
        final com.sun.javafx.geom.Point2D point = TempState.getInstance().point;
        point.setLocation((float)n, (float)n2);
        final SubScene subScene = this.getSubScene();
        if (subScene != null) {
            final Point2D sceneToSubScenePlane = SceneUtils.sceneToSubScenePlane(subScene, new Point2D(point.x, point.y));
            if (sceneToSubScenePlane == null) {
                return null;
            }
            point.setLocation((float)sceneToSubScenePlane.getX(), (float)sceneToSubScenePlane.getY());
        }
        try {
            this.sceneToLocal(point);
            return new Point2D(point.x, point.y);
        }
        catch (NoninvertibleTransformException ex) {
            return null;
        }
    }
    
    public Point2D sceneToLocal(final Point2D point2D, final boolean b) {
        return this.sceneToLocal(point2D.getX(), point2D.getY(), b);
    }
    
    public Bounds sceneToLocal(final Bounds bounds, final boolean b) {
        if (!b) {
            return this.sceneToLocal(bounds);
        }
        if (bounds.getMinZ() != 0.0 || bounds.getMaxZ() != 0.0) {
            return null;
        }
        return BoundsUtils.createBoundingBox(this.sceneToLocal(bounds.getMinX(), bounds.getMinY(), true), this.sceneToLocal(bounds.getMinX(), bounds.getMaxY(), true), this.sceneToLocal(bounds.getMaxX(), bounds.getMinY(), true), this.sceneToLocal(bounds.getMaxX(), bounds.getMaxY(), true));
    }
    
    public Point2D sceneToLocal(final double n, final double n2) {
        final com.sun.javafx.geom.Point2D point = TempState.getInstance().point;
        point.setLocation((float)n, (float)n2);
        try {
            this.sceneToLocal(point);
        }
        catch (NoninvertibleTransformException ex) {
            return null;
        }
        return new Point2D(point.x, point.y);
    }
    
    public Point2D sceneToLocal(final Point2D point2D) {
        return this.sceneToLocal(point2D.getX(), point2D.getY());
    }
    
    public Point3D sceneToLocal(final Point3D point3D) {
        return this.sceneToLocal(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Point3D sceneToLocal(final double n, final double n2, final double n3) {
        try {
            return this.sceneToLocal0(n, n2, n3);
        }
        catch (NoninvertibleTransformException ex) {
            return null;
        }
    }
    
    private Point3D sceneToLocal0(final double n, final double n2, final double n3) throws NoninvertibleTransformException {
        final Vec3d vec3d = TempState.getInstance().vec3d;
        vec3d.set(n, n2, n3);
        this.sceneToLocal(vec3d);
        return new Point3D(vec3d.x, vec3d.y, vec3d.z);
    }
    
    public Bounds sceneToLocal(final Bounds bounds) {
        this.updateLocalToParentTransform();
        if (this.localToParentTx.is2D() && bounds.getMinZ() == 0.0 && bounds.getMaxZ() == 0.0) {
            return BoundsUtils.createBoundingBox(this.sceneToLocal(bounds.getMinX(), bounds.getMinY()), this.sceneToLocal(bounds.getMaxX(), bounds.getMinY()), this.sceneToLocal(bounds.getMaxX(), bounds.getMaxY()), this.sceneToLocal(bounds.getMinX(), bounds.getMaxY()));
        }
        try {
            return BoundsUtils.createBoundingBox(this.sceneToLocal0(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ()), this.sceneToLocal0(bounds.getMinX(), bounds.getMinY(), bounds.getMaxZ()), this.sceneToLocal0(bounds.getMinX(), bounds.getMaxY(), bounds.getMinZ()), this.sceneToLocal0(bounds.getMinX(), bounds.getMaxY(), bounds.getMaxZ()), this.sceneToLocal0(bounds.getMaxX(), bounds.getMaxY(), bounds.getMinZ()), this.sceneToLocal0(bounds.getMaxX(), bounds.getMaxY(), bounds.getMaxZ()), this.sceneToLocal0(bounds.getMaxX(), bounds.getMinY(), bounds.getMinZ()), this.sceneToLocal0(bounds.getMaxX(), bounds.getMinY(), bounds.getMaxZ()));
        }
        catch (NoninvertibleTransformException ex) {
            return null;
        }
    }
    
    public Point2D localToScreen(final double n, final double n2) {
        return this.localToScreen(n, n2, 0.0);
    }
    
    public Point2D localToScreen(final Point2D point2D) {
        return this.localToScreen(point2D.getX(), point2D.getY());
    }
    
    public Point2D localToScreen(final double n, final double n2, final double n3) {
        final Scene scene = this.getScene();
        if (scene == null) {
            return null;
        }
        final Window window = scene.getWindow();
        if (window == null) {
            return null;
        }
        Point3D point3D = this.localToScene(n, n2, n3);
        final SubScene subScene = this.getSubScene();
        if (subScene != null) {
            point3D = SceneUtils.subSceneToScene(subScene, point3D);
        }
        final Point2D project = CameraHelper.project(SceneHelper.getEffectiveCamera(this.getScene()), point3D);
        return new Point2D(project.getX() + scene.getX() + window.getX(), project.getY() + scene.getY() + window.getY());
    }
    
    public Point2D localToScreen(final Point3D point3D) {
        return this.localToScreen(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Bounds localToScreen(final Bounds bounds) {
        return BoundsUtils.createBoundingBox(this.localToScreen(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ()), this.localToScreen(bounds.getMinX(), bounds.getMinY(), bounds.getMaxZ()), this.localToScreen(bounds.getMinX(), bounds.getMaxY(), bounds.getMinZ()), this.localToScreen(bounds.getMinX(), bounds.getMaxY(), bounds.getMaxZ()), this.localToScreen(bounds.getMaxX(), bounds.getMaxY(), bounds.getMinZ()), this.localToScreen(bounds.getMaxX(), bounds.getMaxY(), bounds.getMaxZ()), this.localToScreen(bounds.getMaxX(), bounds.getMinY(), bounds.getMinZ()), this.localToScreen(bounds.getMaxX(), bounds.getMinY(), bounds.getMaxZ()));
    }
    
    public Point2D localToScene(final double n, final double n2) {
        final com.sun.javafx.geom.Point2D point = TempState.getInstance().point;
        point.setLocation((float)n, (float)n2);
        this.localToScene(point);
        return new Point2D(point.x, point.y);
    }
    
    public Point2D localToScene(final Point2D point2D) {
        return this.localToScene(point2D.getX(), point2D.getY());
    }
    
    public Point3D localToScene(final Point3D point3D) {
        return this.localToScene(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Point3D localToScene(final double n, final double n2, final double n3) {
        final Vec3d vec3d = TempState.getInstance().vec3d;
        vec3d.set(n, n2, n3);
        this.localToScene(vec3d);
        return new Point3D(vec3d.x, vec3d.y, vec3d.z);
    }
    
    public Point3D localToScene(final Point3D point3D, final boolean b) {
        Point3D point3D2 = this.localToScene(point3D);
        if (b) {
            final SubScene subScene = this.getSubScene();
            if (subScene != null) {
                point3D2 = SceneUtils.subSceneToScene(subScene, point3D2);
            }
        }
        return point3D2;
    }
    
    public Point3D localToScene(final double n, final double n2, final double n3, final boolean b) {
        return this.localToScene(new Point3D(n, n2, n3), b);
    }
    
    public Point2D localToScene(final Point2D point2D, final boolean b) {
        if (!b) {
            return this.localToScene(point2D);
        }
        final Point3D localToScene = this.localToScene(point2D.getX(), point2D.getY(), 0.0, b);
        return new Point2D(localToScene.getX(), localToScene.getY());
    }
    
    public Point2D localToScene(final double n, final double n2, final boolean b) {
        return this.localToScene(new Point2D(n, n2), b);
    }
    
    public Bounds localToScene(final Bounds bounds, final boolean b) {
        if (!b) {
            return this.localToScene(bounds);
        }
        return BoundsUtils.createBoundingBox(this.localToScene(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ(), true), this.localToScene(bounds.getMinX(), bounds.getMinY(), bounds.getMaxZ(), true), this.localToScene(bounds.getMinX(), bounds.getMaxY(), bounds.getMinZ(), true), this.localToScene(bounds.getMinX(), bounds.getMaxY(), bounds.getMaxZ(), true), this.localToScene(bounds.getMaxX(), bounds.getMaxY(), bounds.getMinZ(), true), this.localToScene(bounds.getMaxX(), bounds.getMaxY(), bounds.getMaxZ(), true), this.localToScene(bounds.getMaxX(), bounds.getMinY(), bounds.getMinZ(), true), this.localToScene(bounds.getMaxX(), bounds.getMinY(), bounds.getMaxZ(), true));
    }
    
    public Bounds localToScene(final Bounds bounds) {
        this.updateLocalToParentTransform();
        if (this.localToParentTx.is2D() && bounds.getMinZ() == 0.0 && bounds.getMaxZ() == 0.0) {
            return BoundsUtils.createBoundingBox(this.localToScene(bounds.getMinX(), bounds.getMinY()), this.localToScene(bounds.getMaxX(), bounds.getMinY()), this.localToScene(bounds.getMaxX(), bounds.getMaxY()), this.localToScene(bounds.getMinX(), bounds.getMaxY()));
        }
        return BoundsUtils.createBoundingBox(this.localToScene(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ()), this.localToScene(bounds.getMinX(), bounds.getMinY(), bounds.getMaxZ()), this.localToScene(bounds.getMinX(), bounds.getMaxY(), bounds.getMinZ()), this.localToScene(bounds.getMinX(), bounds.getMaxY(), bounds.getMaxZ()), this.localToScene(bounds.getMaxX(), bounds.getMaxY(), bounds.getMinZ()), this.localToScene(bounds.getMaxX(), bounds.getMaxY(), bounds.getMaxZ()), this.localToScene(bounds.getMaxX(), bounds.getMinY(), bounds.getMinZ()), this.localToScene(bounds.getMaxX(), bounds.getMinY(), bounds.getMaxZ()));
    }
    
    public Point2D parentToLocal(final double n, final double n2) {
        final com.sun.javafx.geom.Point2D point = TempState.getInstance().point;
        point.setLocation((float)n, (float)n2);
        try {
            this.parentToLocal(point);
        }
        catch (NoninvertibleTransformException ex) {
            return null;
        }
        return new Point2D(point.x, point.y);
    }
    
    public Point2D parentToLocal(final Point2D point2D) {
        return this.parentToLocal(point2D.getX(), point2D.getY());
    }
    
    public Point3D parentToLocal(final Point3D point3D) {
        return this.parentToLocal(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Point3D parentToLocal(final double n, final double n2, final double n3) {
        final Vec3d vec3d = TempState.getInstance().vec3d;
        vec3d.set(n, n2, n3);
        try {
            this.parentToLocal(vec3d);
        }
        catch (NoninvertibleTransformException ex) {
            return null;
        }
        return new Point3D(vec3d.x, vec3d.y, vec3d.z);
    }
    
    public Bounds parentToLocal(final Bounds bounds) {
        this.updateLocalToParentTransform();
        if (this.localToParentTx.is2D() && bounds.getMinZ() == 0.0 && bounds.getMaxZ() == 0.0) {
            return BoundsUtils.createBoundingBox(this.parentToLocal(bounds.getMinX(), bounds.getMinY()), this.parentToLocal(bounds.getMaxX(), bounds.getMinY()), this.parentToLocal(bounds.getMaxX(), bounds.getMaxY()), this.parentToLocal(bounds.getMinX(), bounds.getMaxY()));
        }
        return BoundsUtils.createBoundingBox(this.parentToLocal(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ()), this.parentToLocal(bounds.getMinX(), bounds.getMinY(), bounds.getMaxZ()), this.parentToLocal(bounds.getMinX(), bounds.getMaxY(), bounds.getMinZ()), this.parentToLocal(bounds.getMinX(), bounds.getMaxY(), bounds.getMaxZ()), this.parentToLocal(bounds.getMaxX(), bounds.getMaxY(), bounds.getMinZ()), this.parentToLocal(bounds.getMaxX(), bounds.getMaxY(), bounds.getMaxZ()), this.parentToLocal(bounds.getMaxX(), bounds.getMinY(), bounds.getMinZ()), this.parentToLocal(bounds.getMaxX(), bounds.getMinY(), bounds.getMaxZ()));
    }
    
    public Point2D localToParent(final double n, final double n2) {
        final com.sun.javafx.geom.Point2D point = TempState.getInstance().point;
        point.setLocation((float)n, (float)n2);
        this.localToParent(point);
        return new Point2D(point.x, point.y);
    }
    
    public Point2D localToParent(final Point2D point2D) {
        return this.localToParent(point2D.getX(), point2D.getY());
    }
    
    public Point3D localToParent(final Point3D point3D) {
        return this.localToParent(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Point3D localToParent(final double n, final double n2, final double n3) {
        final Vec3d vec3d = TempState.getInstance().vec3d;
        vec3d.set(n, n2, n3);
        this.localToParent(vec3d);
        return new Point3D(vec3d.x, vec3d.y, vec3d.z);
    }
    
    public Bounds localToParent(final Bounds bounds) {
        this.updateLocalToParentTransform();
        if (this.localToParentTx.is2D() && bounds.getMinZ() == 0.0 && bounds.getMaxZ() == 0.0) {
            return BoundsUtils.createBoundingBox(this.localToParent(bounds.getMinX(), bounds.getMinY()), this.localToParent(bounds.getMaxX(), bounds.getMinY()), this.localToParent(bounds.getMaxX(), bounds.getMaxY()), this.localToParent(bounds.getMinX(), bounds.getMaxY()));
        }
        return BoundsUtils.createBoundingBox(this.localToParent(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ()), this.localToParent(bounds.getMinX(), bounds.getMinY(), bounds.getMaxZ()), this.localToParent(bounds.getMinX(), bounds.getMaxY(), bounds.getMinZ()), this.localToParent(bounds.getMinX(), bounds.getMaxY(), bounds.getMaxZ()), this.localToParent(bounds.getMaxX(), bounds.getMaxY(), bounds.getMinZ()), this.localToParent(bounds.getMaxX(), bounds.getMaxY(), bounds.getMaxZ()), this.localToParent(bounds.getMaxX(), bounds.getMinY(), bounds.getMinZ()), this.localToParent(bounds.getMaxX(), bounds.getMinY(), bounds.getMaxZ()));
    }
    
    BaseTransform getLocalToParentTransform(final BaseTransform baseTransform) {
        this.updateLocalToParentTransform();
        baseTransform.setTransform(this.localToParentTx);
        return baseTransform;
    }
    
    final BaseTransform getLeafTransform() {
        return this.getLocalToParentTransform(TempState.getInstance().leafTx);
    }
    
    private void doTransformsChanged() {
        if (!this.transformDirty) {
            NodeHelper.markDirty(this, DirtyBits.NODE_TRANSFORM);
            this.transformDirty = true;
            this.transformedBoundsChanged();
        }
        this.invalidateLocalToParentTransform();
        this.invalidateLocalToSceneTransform();
    }
    
    final double getPivotX() {
        final Bounds layoutBounds = this.getLayoutBounds();
        return layoutBounds.getMinX() + layoutBounds.getWidth() / 2.0;
    }
    
    final double getPivotY() {
        final Bounds layoutBounds = this.getLayoutBounds();
        return layoutBounds.getMinY() + layoutBounds.getHeight() / 2.0;
    }
    
    final double getPivotZ() {
        final Bounds layoutBounds = this.getLayoutBounds();
        return layoutBounds.getMinZ() + layoutBounds.getDepth() / 2.0;
    }
    
    void updateLocalToParentTransform() {
        if (this.transformDirty) {
            this.localToParentTx.setToIdentity();
            boolean b = false;
            double n = 0.0;
            if (this.hasMirroring()) {
                final Scene scene = this.getScene();
                if (scene != null && scene.getRoot() == this) {
                    n = scene.getWidth() / 2.0;
                    if (n == 0.0) {
                        n = this.getPivotX();
                    }
                    this.localToParentTx = this.localToParentTx.deriveWithTranslation(n, 0.0);
                    this.localToParentTx = this.localToParentTx.deriveWithScale(-1.0, 1.0, 1.0);
                    this.localToParentTx = this.localToParentTx.deriveWithTranslation(-n, 0.0);
                }
                else {
                    b = true;
                    n = this.getPivotX();
                }
            }
            if (this.getScaleX() != 1.0 || this.getScaleY() != 1.0 || this.getScaleZ() != 1.0 || this.getRotate() != 0.0) {
                final double pivotX = this.getPivotX();
                final double pivotY = this.getPivotY();
                final double pivotZ = this.getPivotZ();
                this.localToParentTx = this.localToParentTx.deriveWithTranslation(this.getTranslateX() + this.getLayoutX() + pivotX, this.getTranslateY() + this.getLayoutY() + pivotY, this.getTranslateZ() + pivotZ);
                this.localToParentTx = this.localToParentTx.deriveWithRotation(Math.toRadians(this.getRotate()), this.getRotationAxis().getX(), this.getRotationAxis().getY(), this.getRotationAxis().getZ());
                this.localToParentTx = this.localToParentTx.deriveWithScale(this.getScaleX(), this.getScaleY(), this.getScaleZ());
                this.localToParentTx = this.localToParentTx.deriveWithTranslation(-pivotX, -pivotY, -pivotZ);
            }
            else {
                this.localToParentTx = this.localToParentTx.deriveWithTranslation(this.getTranslateX() + this.getLayoutX(), this.getTranslateY() + this.getLayoutY(), this.getTranslateZ());
            }
            if (this.hasTransforms()) {
                final Iterator<Transform> iterator = this.getTransforms().iterator();
                while (iterator.hasNext()) {
                    this.localToParentTx = TransformHelper.derive(iterator.next(), this.localToParentTx);
                }
            }
            if (b) {
                this.localToParentTx = this.localToParentTx.deriveWithTranslation(n, 0.0);
                this.localToParentTx = this.localToParentTx.deriveWithScale(-1.0, 1.0, 1.0);
                this.localToParentTx = this.localToParentTx.deriveWithTranslation(-n, 0.0);
            }
            this.transformDirty = false;
        }
    }
    
    void parentToLocal(final com.sun.javafx.geom.Point2D point2D) throws NoninvertibleTransformException {
        this.updateLocalToParentTransform();
        this.localToParentTx.inverseTransform(point2D, point2D);
    }
    
    void parentToLocal(final Vec3d vec3d) throws NoninvertibleTransformException {
        this.updateLocalToParentTransform();
        this.localToParentTx.inverseTransform(vec3d, vec3d);
    }
    
    void sceneToLocal(final com.sun.javafx.geom.Point2D point2D) throws NoninvertibleTransformException {
        if (this.getParent() != null) {
            this.getParent().sceneToLocal(point2D);
        }
        this.parentToLocal(point2D);
    }
    
    void sceneToLocal(final Vec3d vec3d) throws NoninvertibleTransformException {
        if (this.getParent() != null) {
            this.getParent().sceneToLocal(vec3d);
        }
        this.parentToLocal(vec3d);
    }
    
    void localToScene(final com.sun.javafx.geom.Point2D point2D) {
        this.localToParent(point2D);
        if (this.getParent() != null) {
            this.getParent().localToScene(point2D);
        }
    }
    
    void localToScene(final Vec3d vec3d) {
        this.localToParent(vec3d);
        if (this.getParent() != null) {
            this.getParent().localToScene(vec3d);
        }
    }
    
    void localToParent(final com.sun.javafx.geom.Point2D point2D) {
        this.updateLocalToParentTransform();
        this.localToParentTx.transform(point2D, point2D);
    }
    
    void localToParent(final Vec3d vec3d) {
        this.updateLocalToParentTransform();
        this.localToParentTx.transform(vec3d, vec3d);
    }
    
    private void doPickNodeLocal(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        this.intersects(pickRay, pickResultChooser);
    }
    
    final void pickNode(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        if (!this.isVisible() || this.isDisable() || this.isMouseTransparent()) {
            return;
        }
        final Vec3d originNoClone = pickRay.getOriginNoClone();
        final double x = originNoClone.x;
        final double y = originNoClone.y;
        final double z = originNoClone.z;
        final Vec3d directionNoClone = pickRay.getDirectionNoClone();
        final double x2 = directionNoClone.x;
        final double y2 = directionNoClone.y;
        final double z2 = directionNoClone.z;
        this.updateLocalToParentTransform();
        try {
            this.localToParentTx.inverseTransform(originNoClone, originNoClone);
            this.localToParentTx.inverseDeltaTransform(directionNoClone, directionNoClone);
            NodeHelper.pickNodeLocal(this, pickRay, pickResultChooser);
        }
        catch (NoninvertibleTransformException ex) {}
        pickRay.setOrigin(x, y, z);
        pickRay.setDirection(x2, y2, z2);
    }
    
    final boolean intersects(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        final double intersectsBounds = this.intersectsBounds(pickRay);
        if (Double.isNaN(intersectsBounds)) {
            return false;
        }
        if (this.isPickOnBounds()) {
            if (pickResultChooser != null) {
                pickResultChooser.offer(this, intersectsBounds, PickResultChooser.computePoint(pickRay, intersectsBounds));
            }
            return true;
        }
        return NodeHelper.computeIntersects(this, pickRay, pickResultChooser);
    }
    
    private boolean doComputeIntersects(final PickRay pickRay, final PickResultChooser pickResultChooser) {
        final double z = pickRay.getOriginNoClone().z;
        final double z2 = pickRay.getDirectionNoClone().z;
        if (almostZero(z2)) {
            return false;
        }
        final double n = -z / z2;
        if (n < pickRay.getNearClip() || n > pickRay.getFarClip()) {
            return false;
        }
        if (this.contains((float)(pickRay.getOriginNoClone().x + pickRay.getDirectionNoClone().x * n), (float)(pickRay.getOriginNoClone().y + pickRay.getDirectionNoClone().y * n))) {
            if (pickResultChooser != null) {
                pickResultChooser.offer(this, n, PickResultChooser.computePoint(pickRay, n));
            }
            return true;
        }
        return false;
    }
    
    final double intersectsBounds(final PickRay pickRay) {
        final Vec3d directionNoClone = pickRay.getDirectionNoClone();
        final Vec3d originNoClone = pickRay.getOriginNoClone();
        final double x = originNoClone.x;
        final double y = originNoClone.y;
        final double z = originNoClone.z;
        final BaseBounds localBounds = this.getLocalBounds(TempState.getInstance().bounds, BaseTransform.IDENTITY_TRANSFORM);
        double n4;
        double n5;
        if (directionNoClone.x == 0.0 && directionNoClone.y == 0.0) {
            if (directionNoClone.z == 0.0) {
                return Double.NaN;
            }
            if (x < localBounds.getMinX() || x > localBounds.getMaxX() || y < localBounds.getMinY() || y > localBounds.getMaxY()) {
                return Double.NaN;
            }
            final double n = 1.0 / directionNoClone.z;
            final boolean b = n < 0.0;
            final double n2 = localBounds.getMinZ();
            final double n3 = localBounds.getMaxZ();
            n4 = ((b ? n3 : n2) - z) * n;
            n5 = ((b ? n2 : n3) - z) * n;
        }
        else if (localBounds.getDepth() == 0.0) {
            if (almostZero(directionNoClone.z)) {
                return Double.NaN;
            }
            final double n6 = (localBounds.getMinZ() - z) / directionNoClone.z;
            final double n7 = x + directionNoClone.x * n6;
            final double n8 = y + directionNoClone.y * n6;
            if (n7 < localBounds.getMinX() || n7 > localBounds.getMaxX() || n8 < localBounds.getMinY() || n8 > localBounds.getMaxY()) {
                return Double.NaN;
            }
            n5 = (n4 = n6);
        }
        else {
            final double v = (directionNoClone.x == 0.0) ? Double.POSITIVE_INFINITY : (1.0 / directionNoClone.x);
            final double v2 = (directionNoClone.y == 0.0) ? Double.POSITIVE_INFINITY : (1.0 / directionNoClone.y);
            final double v3 = (directionNoClone.z == 0.0) ? Double.POSITIVE_INFINITY : (1.0 / directionNoClone.z);
            final boolean b2 = v < 0.0;
            final boolean b3 = v2 < 0.0;
            final boolean b4 = v3 < 0.0;
            final double n9 = localBounds.getMinX();
            final double n10 = localBounds.getMinY();
            final double n11 = localBounds.getMaxX();
            final double n12 = localBounds.getMaxY();
            n4 = Double.NEGATIVE_INFINITY;
            n5 = Double.POSITIVE_INFINITY;
            if (Double.isInfinite(v)) {
                if (n9 > x || n11 < x) {
                    return Double.NaN;
                }
            }
            else {
                n4 = ((b2 ? n11 : n9) - x) * v;
                n5 = ((b2 ? n9 : n11) - x) * v;
            }
            if (Double.isInfinite(v2)) {
                if (n10 > y || n12 < y) {
                    return Double.NaN;
                }
            }
            else {
                final double n13 = ((b3 ? n12 : n10) - y) * v2;
                final double n14 = ((b3 ? n10 : n12) - y) * v2;
                if (n4 > n14 || n13 > n5) {
                    return Double.NaN;
                }
                if (n13 > n4) {
                    n4 = n13;
                }
                if (n14 < n5) {
                    n5 = n14;
                }
            }
            final double n15 = localBounds.getMinZ();
            final double n16 = localBounds.getMaxZ();
            if (Double.isInfinite(v3)) {
                if (n15 > z || n16 < z) {
                    return Double.NaN;
                }
            }
            else {
                final double n17 = ((b4 ? n16 : n15) - z) * v3;
                final double n18 = ((b4 ? n15 : n16) - z) * v3;
                if (n4 > n18 || n17 > n5) {
                    return Double.NaN;
                }
                if (n17 > n4) {
                    n4 = n17;
                }
                if (n18 < n5) {
                    n5 = n18;
                }
            }
        }
        final Node clip = this.getClip();
        if (clip != null && !(this instanceof Shape3D) && !(clip instanceof Shape3D)) {
            final double x2 = directionNoClone.x;
            final double y2 = directionNoClone.y;
            final double z2 = directionNoClone.z;
            clip.updateLocalToParentTransform();
            boolean b5 = true;
            try {
                clip.localToParentTx.inverseTransform(originNoClone, originNoClone);
                clip.localToParentTx.inverseDeltaTransform(directionNoClone, directionNoClone);
            }
            catch (NoninvertibleTransformException ex) {
                b5 = false;
            }
            final boolean b6 = b5 && clip.intersects(pickRay, null);
            pickRay.setOrigin(x, y, z);
            pickRay.setDirection(x2, y2, z2);
            if (!b6) {
                return Double.NaN;
            }
        }
        if (Double.isInfinite(n4) || Double.isNaN(n4)) {
            return Double.NaN;
        }
        final double nearClip = pickRay.getNearClip();
        final double farClip = pickRay.getFarClip();
        if (n4 < nearClip) {
            if (n5 >= nearClip) {
                return 0.0;
            }
            return Double.NaN;
        }
        else {
            if (n4 > farClip) {
                return Double.NaN;
            }
            return n4;
        }
    }
    
    static boolean almostZero(final double n) {
        return n < 1.0E-5 && n > -1.0E-5;
    }
    
    public final DoubleProperty viewOrderProperty() {
        return this.getMiscProperties().viewOrderProperty();
    }
    
    public final void setViewOrder(final double n) {
        this.viewOrderProperty().set(n);
    }
    
    public final double getViewOrder() {
        return (this.miscProperties == null) ? 0.0 : this.miscProperties.getViewOrder();
    }
    
    public final ObservableList<Transform> getTransforms() {
        return this.transformsProperty();
    }
    
    private ObservableList<Transform> transformsProperty() {
        return this.getNodeTransformation().getTransforms();
    }
    
    public final void setTranslateX(final double n) {
        this.translateXProperty().set(n);
    }
    
    public final double getTranslateX() {
        return (this.nodeTransformation == null) ? 0.0 : this.nodeTransformation.getTranslateX();
    }
    
    public final DoubleProperty translateXProperty() {
        return this.getNodeTransformation().translateXProperty();
    }
    
    public final void setTranslateY(final double n) {
        this.translateYProperty().set(n);
    }
    
    public final double getTranslateY() {
        return (this.nodeTransformation == null) ? 0.0 : this.nodeTransformation.getTranslateY();
    }
    
    public final DoubleProperty translateYProperty() {
        return this.getNodeTransformation().translateYProperty();
    }
    
    public final void setTranslateZ(final double n) {
        this.translateZProperty().set(n);
    }
    
    public final double getTranslateZ() {
        return (this.nodeTransformation == null) ? 0.0 : this.nodeTransformation.getTranslateZ();
    }
    
    public final DoubleProperty translateZProperty() {
        return this.getNodeTransformation().translateZProperty();
    }
    
    public final void setScaleX(final double n) {
        this.scaleXProperty().set(n);
    }
    
    public final double getScaleX() {
        return (this.nodeTransformation == null) ? 1.0 : this.nodeTransformation.getScaleX();
    }
    
    public final DoubleProperty scaleXProperty() {
        return this.getNodeTransformation().scaleXProperty();
    }
    
    public final void setScaleY(final double n) {
        this.scaleYProperty().set(n);
    }
    
    public final double getScaleY() {
        return (this.nodeTransformation == null) ? 1.0 : this.nodeTransformation.getScaleY();
    }
    
    public final DoubleProperty scaleYProperty() {
        return this.getNodeTransformation().scaleYProperty();
    }
    
    public final void setScaleZ(final double n) {
        this.scaleZProperty().set(n);
    }
    
    public final double getScaleZ() {
        return (this.nodeTransformation == null) ? 1.0 : this.nodeTransformation.getScaleZ();
    }
    
    public final DoubleProperty scaleZProperty() {
        return this.getNodeTransformation().scaleZProperty();
    }
    
    public final void setRotate(final double n) {
        this.rotateProperty().set(n);
    }
    
    public final double getRotate() {
        return (this.nodeTransformation == null) ? 0.0 : this.nodeTransformation.getRotate();
    }
    
    public final DoubleProperty rotateProperty() {
        return this.getNodeTransformation().rotateProperty();
    }
    
    public final void setRotationAxis(final Point3D point3D) {
        this.rotationAxisProperty().set(point3D);
    }
    
    public final Point3D getRotationAxis() {
        return (this.nodeTransformation == null) ? Node.DEFAULT_ROTATION_AXIS : this.nodeTransformation.getRotationAxis();
    }
    
    public final ObjectProperty<Point3D> rotationAxisProperty() {
        return this.getNodeTransformation().rotationAxisProperty();
    }
    
    public final ReadOnlyObjectProperty<Transform> localToParentTransformProperty() {
        return this.getNodeTransformation().localToParentTransformProperty();
    }
    
    private void invalidateLocalToParentTransform() {
        if (this.nodeTransformation != null) {
            this.nodeTransformation.invalidateLocalToParentTransform();
        }
    }
    
    public final Transform getLocalToParentTransform() {
        return this.localToParentTransformProperty().get();
    }
    
    public final ReadOnlyObjectProperty<Transform> localToSceneTransformProperty() {
        return this.getNodeTransformation().localToSceneTransformProperty();
    }
    
    private void invalidateLocalToSceneTransform() {
        if (this.nodeTransformation != null) {
            this.nodeTransformation.invalidateLocalToSceneTransform();
        }
    }
    
    public final Transform getLocalToSceneTransform() {
        return this.localToSceneTransformProperty().get();
    }
    
    private NodeTransformation getNodeTransformation() {
        if (this.nodeTransformation == null) {
            this.nodeTransformation = new NodeTransformation();
        }
        return this.nodeTransformation;
    }
    
    private boolean hasTransforms() {
        return this.nodeTransformation != null && this.nodeTransformation.hasTransforms();
    }
    
    Transform getCurrentLocalToSceneTransformState() {
        if (this.nodeTransformation == null || this.nodeTransformation.localToSceneTransform == null) {
            return null;
        }
        return this.nodeTransformation.localToSceneTransform.transform;
    }
    
    private EventHandlerProperties getEventHandlerProperties() {
        if (this.eventHandlerProperties == null) {
            this.eventHandlerProperties = new EventHandlerProperties(this.getInternalEventDispatcher().getEventHandlerManager(), this);
        }
        return this.eventHandlerProperties;
    }
    
    public final void setNodeOrientation(final NodeOrientation nodeOrientation) {
        this.nodeOrientationProperty().set(nodeOrientation);
    }
    
    public final NodeOrientation getNodeOrientation() {
        return (this.nodeOrientation == null) ? NodeOrientation.INHERIT : this.nodeOrientation.get();
    }
    
    public final ObjectProperty<NodeOrientation> nodeOrientationProperty() {
        if (this.nodeOrientation == null) {
            this.nodeOrientation = new StyleableObjectProperty<NodeOrientation>(NodeOrientation.INHERIT) {
                @Override
                protected void invalidated() {
                    Node.this.nodeResolvedOrientationInvalidated();
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "nodeOrientation";
                }
                
                @Override
                public CssMetaData getCssMetaData() {
                    throw new UnsupportedOperationException("Not supported yet.");
                }
            };
        }
        return this.nodeOrientation;
    }
    
    public final NodeOrientation getEffectiveNodeOrientation() {
        return (getEffectiveOrientation(this.resolvedNodeOrientation) == 0) ? NodeOrientation.LEFT_TO_RIGHT : NodeOrientation.RIGHT_TO_LEFT;
    }
    
    public final ReadOnlyObjectProperty<NodeOrientation> effectiveNodeOrientationProperty() {
        if (this.effectiveNodeOrientationProperty == null) {
            this.effectiveNodeOrientationProperty = new EffectiveOrientationProperty();
        }
        return this.effectiveNodeOrientationProperty;
    }
    
    public boolean usesMirroring() {
        return true;
    }
    
    final void parentResolvedOrientationInvalidated() {
        if (this.getNodeOrientation() == NodeOrientation.INHERIT) {
            this.nodeResolvedOrientationInvalidated();
        }
        else {
            NodeHelper.transformsChanged(this);
        }
    }
    
    final void nodeResolvedOrientationInvalidated() {
        final byte resolvedNodeOrientation = this.resolvedNodeOrientation;
        this.resolvedNodeOrientation = (byte)(this.calcEffectiveNodeOrientation() | this.calcAutomaticNodeOrientation());
        if (this.effectiveNodeOrientationProperty != null && getEffectiveOrientation(this.resolvedNodeOrientation) != getEffectiveOrientation(resolvedNodeOrientation)) {
            this.effectiveNodeOrientationProperty.invalidate();
        }
        NodeHelper.transformsChanged(this);
        if (this.resolvedNodeOrientation != resolvedNodeOrientation) {
            this.nodeResolvedOrientationChanged();
        }
    }
    
    void nodeResolvedOrientationChanged() {
    }
    
    private Node getMirroringOrientationParent() {
        for (Parent parent = this.getParent(); parent != null; parent = parent.getParent()) {
            if (parent.usesMirroring()) {
                return parent;
            }
        }
        final SubScene subScene = this.getSubScene();
        if (subScene != null) {
            return subScene;
        }
        return null;
    }
    
    private Node getOrientationParent() {
        final Parent parent = this.getParent();
        if (parent != null) {
            return parent;
        }
        final SubScene subScene = this.getSubScene();
        if (subScene != null) {
            return subScene;
        }
        return null;
    }
    
    private byte calcEffectiveNodeOrientation() {
        final NodeOrientation nodeOrientation = this.getNodeOrientation();
        if (nodeOrientation != NodeOrientation.INHERIT) {
            return (byte)((nodeOrientation != NodeOrientation.LEFT_TO_RIGHT) ? 1 : 0);
        }
        final Node orientationParent = this.getOrientationParent();
        if (orientationParent != null) {
            return getEffectiveOrientation(orientationParent.resolvedNodeOrientation);
        }
        final Scene scene = this.getScene();
        return (byte)((scene != null && scene.getEffectiveNodeOrientation() != NodeOrientation.LEFT_TO_RIGHT) ? 1 : 0);
    }
    
    private byte calcAutomaticNodeOrientation() {
        if (!this.usesMirroring()) {
            return 0;
        }
        final NodeOrientation nodeOrientation = this.getNodeOrientation();
        if (nodeOrientation != NodeOrientation.INHERIT) {
            return (byte)((nodeOrientation == NodeOrientation.LEFT_TO_RIGHT) ? 0 : 2);
        }
        final Node mirroringOrientationParent = this.getMirroringOrientationParent();
        if (mirroringOrientationParent != null) {
            return getAutomaticOrientation(mirroringOrientationParent.resolvedNodeOrientation);
        }
        final Scene scene = this.getScene();
        if (scene != null) {
            return (byte)((scene.getEffectiveNodeOrientation() == NodeOrientation.LEFT_TO_RIGHT) ? 0 : 2);
        }
        return 0;
    }
    
    final boolean hasMirroring() {
        final Node orientationParent = this.getOrientationParent();
        return getAutomaticOrientation(this.resolvedNodeOrientation) != ((orientationParent != null) ? getAutomaticOrientation(orientationParent.resolvedNodeOrientation) : 0);
    }
    
    private static byte getEffectiveOrientation(final byte b) {
        return (byte)(b & 0x1);
    }
    
    private static byte getAutomaticOrientation(final byte b) {
        return (byte)(b & 0x2);
    }
    
    private MiscProperties getMiscProperties() {
        if (this.miscProperties == null) {
            this.miscProperties = new MiscProperties();
        }
        return this.miscProperties;
    }
    
    public final void setMouseTransparent(final boolean b) {
        this.mouseTransparentProperty().set(b);
    }
    
    public final boolean isMouseTransparent() {
        return this.miscProperties != null && this.miscProperties.isMouseTransparent();
    }
    
    public final BooleanProperty mouseTransparentProperty() {
        return this.getMiscProperties().mouseTransparentProperty();
    }
    
    protected final void setHover(final boolean b) {
        this.hoverPropertyImpl().set(b);
    }
    
    public final boolean isHover() {
        return this.hover != null && this.hover.get();
    }
    
    public final ReadOnlyBooleanProperty hoverProperty() {
        return this.hoverPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper hoverPropertyImpl() {
        if (this.hover == null) {
            this.hover = new ReadOnlyBooleanWrapper() {
                @Override
                protected void invalidated() {
                    final PlatformLogger inputLogger = Logging.getInputLogger();
                    if (inputLogger.isLoggable(PlatformLogger.Level.FINER)) {
                        inputLogger.finer(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Node$15;Z)Ljava/lang/String;, this, this.get()));
                    }
                    Node.this.pseudoClassStateChanged(Node.HOVER_PSEUDOCLASS_STATE, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "hover";
                }
            };
        }
        return this.hover;
    }
    
    protected final void setPressed(final boolean b) {
        this.pressedPropertyImpl().set(b);
    }
    
    public final boolean isPressed() {
        return this.pressed != null && this.pressed.get();
    }
    
    public final ReadOnlyBooleanProperty pressedProperty() {
        return this.pressedPropertyImpl().getReadOnlyProperty();
    }
    
    private ReadOnlyBooleanWrapper pressedPropertyImpl() {
        if (this.pressed == null) {
            this.pressed = new ReadOnlyBooleanWrapper() {
                @Override
                protected void invalidated() {
                    final PlatformLogger inputLogger = Logging.getInputLogger();
                    if (inputLogger.isLoggable(PlatformLogger.Level.FINER)) {
                        inputLogger.finer(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Node$16;Z)Ljava/lang/String;, this, this.get()));
                    }
                    Node.this.pseudoClassStateChanged(Node.PRESSED_PSEUDOCLASS_STATE, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "pressed";
                }
            };
        }
        return this.pressed;
    }
    
    public final void setOnContextMenuRequested(final EventHandler<? super ContextMenuEvent> eventHandler) {
        this.onContextMenuRequestedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ContextMenuEvent> getOnContextMenuRequested() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.onContextMenuRequested();
    }
    
    public final ObjectProperty<EventHandler<? super ContextMenuEvent>> onContextMenuRequestedProperty() {
        return this.getEventHandlerProperties().onContextMenuRequestedProperty();
    }
    
    public final void setOnMouseClicked(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseClickedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseClicked() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseClicked();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseClickedProperty() {
        return this.getEventHandlerProperties().onMouseClickedProperty();
    }
    
    public final void setOnMouseDragged(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseDraggedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseDragged() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseDragged();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseDraggedProperty() {
        return this.getEventHandlerProperties().onMouseDraggedProperty();
    }
    
    public final void setOnMouseEntered(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseEnteredProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseEntered() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseEntered();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseEnteredProperty() {
        return this.getEventHandlerProperties().onMouseEnteredProperty();
    }
    
    public final void setOnMouseExited(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseExitedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseExited() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseExited();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseExitedProperty() {
        return this.getEventHandlerProperties().onMouseExitedProperty();
    }
    
    public final void setOnMouseMoved(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseMovedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseMoved() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseMoved();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseMovedProperty() {
        return this.getEventHandlerProperties().onMouseMovedProperty();
    }
    
    public final void setOnMousePressed(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMousePressedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMousePressed() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMousePressed();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMousePressedProperty() {
        return this.getEventHandlerProperties().onMousePressedProperty();
    }
    
    public final void setOnMouseReleased(final EventHandler<? super MouseEvent> eventHandler) {
        this.onMouseReleasedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnMouseReleased() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseReleased();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onMouseReleasedProperty() {
        return this.getEventHandlerProperties().onMouseReleasedProperty();
    }
    
    public final void setOnDragDetected(final EventHandler<? super MouseEvent> eventHandler) {
        this.onDragDetectedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseEvent> getOnDragDetected() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnDragDetected();
    }
    
    public final ObjectProperty<EventHandler<? super MouseEvent>> onDragDetectedProperty() {
        return this.getEventHandlerProperties().onDragDetectedProperty();
    }
    
    public final void setOnMouseDragOver(final EventHandler<? super MouseDragEvent> eventHandler) {
        this.onMouseDragOverProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseDragEvent> getOnMouseDragOver() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseDragOver();
    }
    
    public final ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragOverProperty() {
        return this.getEventHandlerProperties().onMouseDragOverProperty();
    }
    
    public final void setOnMouseDragReleased(final EventHandler<? super MouseDragEvent> eventHandler) {
        this.onMouseDragReleasedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseDragEvent> getOnMouseDragReleased() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseDragReleased();
    }
    
    public final ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragReleasedProperty() {
        return this.getEventHandlerProperties().onMouseDragReleasedProperty();
    }
    
    public final void setOnMouseDragEntered(final EventHandler<? super MouseDragEvent> eventHandler) {
        this.onMouseDragEnteredProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseDragEvent> getOnMouseDragEntered() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseDragEntered();
    }
    
    public final ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragEnteredProperty() {
        return this.getEventHandlerProperties().onMouseDragEnteredProperty();
    }
    
    public final void setOnMouseDragExited(final EventHandler<? super MouseDragEvent> eventHandler) {
        this.onMouseDragExitedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super MouseDragEvent> getOnMouseDragExited() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnMouseDragExited();
    }
    
    public final ObjectProperty<EventHandler<? super MouseDragEvent>> onMouseDragExitedProperty() {
        return this.getEventHandlerProperties().onMouseDragExitedProperty();
    }
    
    public final void setOnScrollStarted(final EventHandler<? super ScrollEvent> eventHandler) {
        this.onScrollStartedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ScrollEvent> getOnScrollStarted() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnScrollStarted();
    }
    
    public final ObjectProperty<EventHandler<? super ScrollEvent>> onScrollStartedProperty() {
        return this.getEventHandlerProperties().onScrollStartedProperty();
    }
    
    public final void setOnScroll(final EventHandler<? super ScrollEvent> eventHandler) {
        this.onScrollProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ScrollEvent> getOnScroll() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnScroll();
    }
    
    public final ObjectProperty<EventHandler<? super ScrollEvent>> onScrollProperty() {
        return this.getEventHandlerProperties().onScrollProperty();
    }
    
    public final void setOnScrollFinished(final EventHandler<? super ScrollEvent> eventHandler) {
        this.onScrollFinishedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ScrollEvent> getOnScrollFinished() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnScrollFinished();
    }
    
    public final ObjectProperty<EventHandler<? super ScrollEvent>> onScrollFinishedProperty() {
        return this.getEventHandlerProperties().onScrollFinishedProperty();
    }
    
    public final void setOnRotationStarted(final EventHandler<? super RotateEvent> eventHandler) {
        this.onRotationStartedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super RotateEvent> getOnRotationStarted() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnRotationStarted();
    }
    
    public final ObjectProperty<EventHandler<? super RotateEvent>> onRotationStartedProperty() {
        return this.getEventHandlerProperties().onRotationStartedProperty();
    }
    
    public final void setOnRotate(final EventHandler<? super RotateEvent> eventHandler) {
        this.onRotateProperty().set(eventHandler);
    }
    
    public final EventHandler<? super RotateEvent> getOnRotate() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnRotate();
    }
    
    public final ObjectProperty<EventHandler<? super RotateEvent>> onRotateProperty() {
        return this.getEventHandlerProperties().onRotateProperty();
    }
    
    public final void setOnRotationFinished(final EventHandler<? super RotateEvent> eventHandler) {
        this.onRotationFinishedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super RotateEvent> getOnRotationFinished() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnRotationFinished();
    }
    
    public final ObjectProperty<EventHandler<? super RotateEvent>> onRotationFinishedProperty() {
        return this.getEventHandlerProperties().onRotationFinishedProperty();
    }
    
    public final void setOnZoomStarted(final EventHandler<? super ZoomEvent> eventHandler) {
        this.onZoomStartedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ZoomEvent> getOnZoomStarted() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnZoomStarted();
    }
    
    public final ObjectProperty<EventHandler<? super ZoomEvent>> onZoomStartedProperty() {
        return this.getEventHandlerProperties().onZoomStartedProperty();
    }
    
    public final void setOnZoom(final EventHandler<? super ZoomEvent> eventHandler) {
        this.onZoomProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ZoomEvent> getOnZoom() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnZoom();
    }
    
    public final ObjectProperty<EventHandler<? super ZoomEvent>> onZoomProperty() {
        return this.getEventHandlerProperties().onZoomProperty();
    }
    
    public final void setOnZoomFinished(final EventHandler<? super ZoomEvent> eventHandler) {
        this.onZoomFinishedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super ZoomEvent> getOnZoomFinished() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnZoomFinished();
    }
    
    public final ObjectProperty<EventHandler<? super ZoomEvent>> onZoomFinishedProperty() {
        return this.getEventHandlerProperties().onZoomFinishedProperty();
    }
    
    public final void setOnSwipeUp(final EventHandler<? super SwipeEvent> eventHandler) {
        this.onSwipeUpProperty().set(eventHandler);
    }
    
    public final EventHandler<? super SwipeEvent> getOnSwipeUp() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnSwipeUp();
    }
    
    public final ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeUpProperty() {
        return this.getEventHandlerProperties().onSwipeUpProperty();
    }
    
    public final void setOnSwipeDown(final EventHandler<? super SwipeEvent> eventHandler) {
        this.onSwipeDownProperty().set(eventHandler);
    }
    
    public final EventHandler<? super SwipeEvent> getOnSwipeDown() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnSwipeDown();
    }
    
    public final ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeDownProperty() {
        return this.getEventHandlerProperties().onSwipeDownProperty();
    }
    
    public final void setOnSwipeLeft(final EventHandler<? super SwipeEvent> eventHandler) {
        this.onSwipeLeftProperty().set(eventHandler);
    }
    
    public final EventHandler<? super SwipeEvent> getOnSwipeLeft() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnSwipeLeft();
    }
    
    public final ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeLeftProperty() {
        return this.getEventHandlerProperties().onSwipeLeftProperty();
    }
    
    public final void setOnSwipeRight(final EventHandler<? super SwipeEvent> eventHandler) {
        this.onSwipeRightProperty().set(eventHandler);
    }
    
    public final EventHandler<? super SwipeEvent> getOnSwipeRight() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnSwipeRight();
    }
    
    public final ObjectProperty<EventHandler<? super SwipeEvent>> onSwipeRightProperty() {
        return this.getEventHandlerProperties().onSwipeRightProperty();
    }
    
    public final void setOnTouchPressed(final EventHandler<? super TouchEvent> eventHandler) {
        this.onTouchPressedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super TouchEvent> getOnTouchPressed() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnTouchPressed();
    }
    
    public final ObjectProperty<EventHandler<? super TouchEvent>> onTouchPressedProperty() {
        return this.getEventHandlerProperties().onTouchPressedProperty();
    }
    
    public final void setOnTouchMoved(final EventHandler<? super TouchEvent> eventHandler) {
        this.onTouchMovedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super TouchEvent> getOnTouchMoved() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnTouchMoved();
    }
    
    public final ObjectProperty<EventHandler<? super TouchEvent>> onTouchMovedProperty() {
        return this.getEventHandlerProperties().onTouchMovedProperty();
    }
    
    public final void setOnTouchReleased(final EventHandler<? super TouchEvent> eventHandler) {
        this.onTouchReleasedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super TouchEvent> getOnTouchReleased() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnTouchReleased();
    }
    
    public final ObjectProperty<EventHandler<? super TouchEvent>> onTouchReleasedProperty() {
        return this.getEventHandlerProperties().onTouchReleasedProperty();
    }
    
    public final void setOnTouchStationary(final EventHandler<? super TouchEvent> eventHandler) {
        this.onTouchStationaryProperty().set(eventHandler);
    }
    
    public final EventHandler<? super TouchEvent> getOnTouchStationary() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnTouchStationary();
    }
    
    public final ObjectProperty<EventHandler<? super TouchEvent>> onTouchStationaryProperty() {
        return this.getEventHandlerProperties().onTouchStationaryProperty();
    }
    
    public final void setOnKeyPressed(final EventHandler<? super KeyEvent> eventHandler) {
        this.onKeyPressedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super KeyEvent> getOnKeyPressed() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnKeyPressed();
    }
    
    public final ObjectProperty<EventHandler<? super KeyEvent>> onKeyPressedProperty() {
        return this.getEventHandlerProperties().onKeyPressedProperty();
    }
    
    public final void setOnKeyReleased(final EventHandler<? super KeyEvent> eventHandler) {
        this.onKeyReleasedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super KeyEvent> getOnKeyReleased() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnKeyReleased();
    }
    
    public final ObjectProperty<EventHandler<? super KeyEvent>> onKeyReleasedProperty() {
        return this.getEventHandlerProperties().onKeyReleasedProperty();
    }
    
    public final void setOnKeyTyped(final EventHandler<? super KeyEvent> eventHandler) {
        this.onKeyTypedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super KeyEvent> getOnKeyTyped() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnKeyTyped();
    }
    
    public final ObjectProperty<EventHandler<? super KeyEvent>> onKeyTypedProperty() {
        return this.getEventHandlerProperties().onKeyTypedProperty();
    }
    
    public final void setOnInputMethodTextChanged(final EventHandler<? super InputMethodEvent> eventHandler) {
        this.onInputMethodTextChangedProperty().set(eventHandler);
    }
    
    public final EventHandler<? super InputMethodEvent> getOnInputMethodTextChanged() {
        return (this.eventHandlerProperties == null) ? null : this.eventHandlerProperties.getOnInputMethodTextChanged();
    }
    
    public final ObjectProperty<EventHandler<? super InputMethodEvent>> onInputMethodTextChangedProperty() {
        return this.getEventHandlerProperties().onInputMethodTextChangedProperty();
    }
    
    public final void setInputMethodRequests(final InputMethodRequests inputMethodRequests) {
        this.inputMethodRequestsProperty().set(inputMethodRequests);
    }
    
    public final InputMethodRequests getInputMethodRequests() {
        return (this.miscProperties == null) ? Node.DEFAULT_INPUT_METHOD_REQUESTS : this.miscProperties.getInputMethodRequests();
    }
    
    public final ObjectProperty<InputMethodRequests> inputMethodRequestsProperty() {
        return this.getMiscProperties().inputMethodRequestsProperty();
    }
    
    protected final void setFocused(final boolean b) {
        final FocusedProperty focusedPropertyImpl = this.focusedPropertyImpl();
        if (focusedPropertyImpl.value != b) {
            focusedPropertyImpl.store(b);
            focusedPropertyImpl.notifyListeners();
        }
    }
    
    public final boolean isFocused() {
        return this.focused != null && this.focused.get();
    }
    
    public final ReadOnlyBooleanProperty focusedProperty() {
        return this.focusedPropertyImpl();
    }
    
    private FocusedProperty focusedPropertyImpl() {
        if (this.focused == null) {
            this.focused = new FocusedProperty();
        }
        return this.focused;
    }
    
    public final void setFocusTraversable(final boolean b) {
        this.focusTraversableProperty().set(b);
    }
    
    public final boolean isFocusTraversable() {
        return this.focusTraversable != null && this.focusTraversable.get();
    }
    
    public final BooleanProperty focusTraversableProperty() {
        if (this.focusTraversable == null) {
            this.focusTraversable = new StyleableBooleanProperty(false) {
                public void invalidated() {
                    final Scene scene = Node.this.getScene();
                    if (scene != null) {
                        if (this.get()) {
                            scene.initializeInternalEventDispatcher();
                        }
                        Node.this.focusSetDirty(scene);
                    }
                }
                
                @Override
                public CssMetaData getCssMetaData() {
                    return StyleableProperties.FOCUS_TRAVERSABLE;
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "focusTraversable";
                }
            };
        }
        return this.focusTraversable;
    }
    
    private void focusSetDirty(final Scene scene) {
        if (scene != null && (this == scene.getFocusOwner() || this.isFocusTraversable())) {
            scene.setFocusDirty(true);
        }
    }
    
    public void requestFocus() {
        if (this.getScene() != null) {
            this.getScene().requestFocus(this);
        }
    }
    
    final boolean traverse(final Direction direction) {
        return this.getScene() != null && this.getScene().traverse(this, direction);
    }
    
    @Override
    public String toString() {
        final String name = this.getClass().getName();
        final StringBuilder sb = new StringBuilder(name.substring(name.lastIndexOf(46) + 1));
        final boolean b = this.id != null && !"".equals(this.getId());
        final boolean b2 = !this.getStyleClass().isEmpty();
        if (!b) {
            sb.append('@');
            sb.append(Integer.toHexString(this.hashCode()));
        }
        else {
            sb.append("[id=");
            sb.append(this.getId());
            if (!b2) {
                sb.append("]");
            }
        }
        if (b2) {
            if (!b) {
                sb.append('[');
            }
            else {
                sb.append(", ");
            }
            sb.append("styleClass=");
            sb.append(this.getStyleClass());
            sb.append("]");
        }
        return sb.toString();
    }
    
    private void preprocessMouseEvent(final MouseEvent mouseEvent) {
        final EventType<? extends MouseEvent> eventType = mouseEvent.getEventType();
        if (eventType == MouseEvent.MOUSE_PRESSED) {
            for (Node parent = this; parent != null; parent = parent.getParent()) {
                parent.setPressed(mouseEvent.isPrimaryButtonDown());
            }
            return;
        }
        if (eventType == MouseEvent.MOUSE_RELEASED) {
            for (Node parent2 = this; parent2 != null; parent2 = parent2.getParent()) {
                parent2.setPressed(mouseEvent.isPrimaryButtonDown());
            }
            return;
        }
        if (mouseEvent.getTarget() == this) {
            if (eventType == MouseEvent.MOUSE_ENTERED || eventType == MouseEvent.MOUSE_ENTERED_TARGET) {
                this.setHover(true);
                return;
            }
            if (eventType == MouseEvent.MOUSE_EXITED || eventType == MouseEvent.MOUSE_EXITED_TARGET) {
                this.setHover(false);
            }
        }
    }
    
    void markDirtyLayoutBranch() {
        for (Parent dirtyLayout = this.getParent(); dirtyLayout != null && dirtyLayout.layoutFlag == LayoutFlags.CLEAN; dirtyLayout = dirtyLayout.getParent()) {
            dirtyLayout.setLayoutFlag(LayoutFlags.DIRTY_BRANCH);
            if (dirtyLayout.isSceneRoot()) {
                Toolkit.getToolkit().requestNextPulse();
                if (this.getSubScene() != null) {
                    this.getSubScene().setDirtyLayout(dirtyLayout);
                }
            }
        }
    }
    
    private boolean isWindowShowing() {
        final Scene scene = this.getScene();
        if (scene == null) {
            return false;
        }
        final Window window = scene.getWindow();
        return window != null && window.isShowing();
    }
    
    private void updateTreeShowing() {
        this.setTreeShowing(this.isTreeVisible() && this.isWindowShowing());
    }
    
    final void setTreeShowing(final boolean treeShowing) {
        if (this.treeShowing != treeShowing) {
            this.treeShowing = treeShowing;
            ((TreeShowingPropertyReadOnly)this.treeShowingProperty()).invalidate();
        }
    }
    
    final boolean isTreeShowing() {
        return this.treeShowingProperty().get();
    }
    
    final BooleanExpression treeShowingProperty() {
        if (this.treeShowingRO == null) {
            this.treeShowingRO = new TreeShowingPropertyReadOnly();
        }
        return this.treeShowingRO;
    }
    
    private void updateTreeVisible(final boolean b) {
        boolean visible = this.isVisible();
        final Node node = (this.getParent() != null) ? this.getParent() : ((this.clipParent != null) ? this.clipParent : ((this.getSubScene() != null) ? this.getSubScene() : null));
        if (visible) {
            visible = (node == null || node.isTreeVisible());
        }
        if (b && node != null && node.isTreeVisible() && this.isDirty(DirtyBits.NODE_VISIBLE)) {
            this.addToSceneDirtyList();
        }
        this.setTreeVisible(visible);
        this.updateTreeShowing();
    }
    
    final void setTreeVisible(final boolean treeVisible) {
        if (this.treeVisible != treeVisible) {
            this.treeVisible = treeVisible;
            this.updateCanReceiveFocus();
            this.focusSetDirty(this.getScene());
            if (this.getClip() != null) {
                this.getClip().updateTreeVisible(true);
            }
            if (this.treeVisible && !this.isDirtyEmpty()) {
                this.addToSceneDirtyList();
            }
            ((TreeVisiblePropertyReadOnly)this.treeVisibleProperty()).invalidate();
            if (this instanceof SubScene) {
                final Parent root = ((SubScene)this).getRoot();
                if (root != null) {
                    root.setTreeVisible(treeVisible && root.isVisible());
                }
            }
        }
    }
    
    final boolean isTreeVisible() {
        return this.treeVisibleProperty().get();
    }
    
    final BooleanExpression treeVisibleProperty() {
        if (this.treeVisibleRO == null) {
            this.treeVisibleRO = new TreeVisiblePropertyReadOnly();
        }
        return this.treeVisibleRO;
    }
    
    private void setCanReceiveFocus(final boolean canReceiveFocus) {
        this.canReceiveFocus = canReceiveFocus;
    }
    
    final boolean isCanReceiveFocus() {
        return this.canReceiveFocus;
    }
    
    private void updateCanReceiveFocus() {
        this.setCanReceiveFocus(this.getScene() != null && !this.isDisabled() && this.isTreeVisible());
    }
    
    String indent() {
        String s = "";
        for (Parent parent = this.getParent(); parent != null; parent = parent.getParent()) {
            s = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s);
        }
        return s;
    }
    
    final void setShowMnemonics(final boolean b) {
        this.showMnemonicsProperty().set(b);
    }
    
    final boolean isShowMnemonics() {
        return this.showMnemonics != null && this.showMnemonics.get();
    }
    
    final BooleanProperty showMnemonicsProperty() {
        if (this.showMnemonics == null) {
            this.showMnemonics = new BooleanPropertyBase(false) {
                @Override
                protected void invalidated() {
                    Node.this.pseudoClassStateChanged(Node.SHOW_MNEMONICS_PSEUDOCLASS_STATE, this.get());
                }
                
                @Override
                public Object getBean() {
                    return Node.this;
                }
                
                @Override
                public String getName() {
                    return "showMnemonics";
                }
            };
        }
        return this.showMnemonics;
    }
    
    public final void setEventDispatcher(final EventDispatcher eventDispatcher) {
        this.eventDispatcherProperty().set(eventDispatcher);
    }
    
    public final EventDispatcher getEventDispatcher() {
        return this.eventDispatcherProperty().get();
    }
    
    public final ObjectProperty<EventDispatcher> eventDispatcherProperty() {
        this.initializeInternalEventDispatcher();
        return this.eventDispatcher;
    }
    
    public final <T extends Event> void addEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().addEventHandler(eventType, eventHandler);
    }
    
    public final <T extends Event> void removeEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().removeEventHandler(eventType, eventHandler);
    }
    
    public final <T extends Event> void addEventFilter(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().addEventFilter(eventType, eventHandler);
    }
    
    public final <T extends Event> void removeEventFilter(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().removeEventFilter(eventType, eventHandler);
    }
    
    protected final <T extends Event> void setEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().getEventHandlerManager().setEventHandler(eventType, eventHandler);
    }
    
    private NodeEventDispatcher getInternalEventDispatcher() {
        this.initializeInternalEventDispatcher();
        return this.internalEventDispatcher;
    }
    
    private void initializeInternalEventDispatcher() {
        if (this.internalEventDispatcher == null) {
            this.internalEventDispatcher = this.createInternalEventDispatcher();
            this.eventDispatcher = new SimpleObjectProperty<EventDispatcher>(this, "eventDispatcher", this.internalEventDispatcher);
        }
    }
    
    private NodeEventDispatcher createInternalEventDispatcher() {
        return new NodeEventDispatcher(this);
    }
    
    @Override
    public EventDispatchChain buildEventDispatchChain(EventDispatchChain eventDispatchChain) {
        if (this.preprocessMouseEventDispatcher == null) {
            this.preprocessMouseEventDispatcher = ((dispatchEvent, eventDispatchChain2) -> {
                dispatchEvent = (MouseEvent)eventDispatchChain2.dispatchEvent(dispatchEvent);
                if (dispatchEvent instanceof MouseEvent) {
                    this.preprocessMouseEvent(dispatchEvent);
                }
                return dispatchEvent;
            });
        }
        eventDispatchChain = eventDispatchChain.prepend(this.preprocessMouseEventDispatcher);
        Node node = this;
        do {
            if (node.eventDispatcher != null) {
                final EventDispatcher eventDispatcher = node.eventDispatcher.get();
                if (eventDispatcher != null) {
                    eventDispatchChain = eventDispatchChain.prepend(eventDispatcher);
                }
            }
            final Parent parent = node.getParent();
            node = ((parent != null) ? parent : node.getSubScene());
        } while (node != null);
        if (this.getScene() != null) {
            eventDispatchChain = this.getScene().buildEventDispatchChain(eventDispatchChain);
        }
        return eventDispatchChain;
    }
    
    public final void fireEvent(final Event event) {
        if (event instanceof InputEvent) {
            final PlatformLogger inputLogger = Logging.getInputLogger();
            if (inputLogger.isLoggable(PlatformLogger.Level.FINE)) {
                final EventType<? extends Event> eventType = event.getEventType();
                if (eventType == MouseEvent.MOUSE_ENTERED || eventType == MouseEvent.MOUSE_EXITED) {
                    inputLogger.finer(event.toString());
                }
                else if (eventType == MouseEvent.MOUSE_MOVED || eventType == MouseEvent.MOUSE_DRAGGED) {
                    inputLogger.finest(event.toString());
                }
                else {
                    inputLogger.fine(event.toString());
                }
            }
        }
        Event.fireEvent(this, event);
    }
    
    @Override
    public String getTypeSelector() {
        final Class<? extends Node> class1 = this.getClass();
        final Package package1 = class1.getPackage();
        int length = 0;
        if (package1 != null) {
            length = package1.getName().length();
        }
        final int length2 = class1.getName().length();
        return class1.getName().substring((0 < length && length < length2) ? (length + 1) : 0);
    }
    
    @Override
    public Styleable getStyleableParent() {
        return this.getParent();
    }
    
    protected Boolean getInitialFocusTraversable() {
        return Boolean.FALSE;
    }
    
    protected Cursor getInitialCursor() {
        return null;
    }
    
    public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
        return StyleableProperties.STYLEABLES;
    }
    
    @Override
    public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
        return getClassCssMetaData();
    }
    
    static List<Style> getMatchingStyles(final CssMetaData cssMetaData, final Styleable styleable) {
        return CssStyleHelper.getMatchingStyles(styleable, cssMetaData);
    }
    
    final ObservableMap<StyleableProperty<?>, List<Style>> getStyleMap() {
        final Map<StyleableProperty<?>, List<Style>> matchingStyles = CssStyleHelper.getMatchingStyles(this.getProperties().get("STYLEMAP"), this);
        if (matchingStyles == null) {
            return FXCollections.emptyObservableMap();
        }
        if (matchingStyles instanceof ObservableMap) {
            return (ObservableMap<StyleableProperty<?>, List<Style>>)matchingStyles;
        }
        return FXCollections.observableMap(matchingStyles);
    }
    
    final void setStyleMap(final ObservableMap<StyleableProperty<?>, List<Style>> observableMap) {
        if (observableMap != null) {
            this.getProperties().put("STYLEMAP", observableMap);
        }
        else {
            this.getProperties().remove("STYLEMAP");
        }
    }
    
    Map<StyleableProperty<?>, List<Style>> findStyles(final Map<StyleableProperty<?>, List<Style>> map) {
        final Map<StyleableProperty<?>, List<Style>> matchingStyles = CssStyleHelper.getMatchingStyles(map, this);
        return (Map<StyleableProperty<?>, List<Style>>)((matchingStyles != null) ? matchingStyles : Collections.emptyMap());
    }
    
    final CssFlags getCSSFlags() {
        return this.cssFlag;
    }
    
    private void requestCssStateTransition() {
        if (this.getScene() == null) {
            return;
        }
        if (this.cssFlag == CssFlags.CLEAN || this.cssFlag == CssFlags.DIRTY_BRANCH) {
            this.cssFlag = CssFlags.UPDATE;
            this.notifyParentsOfInvalidatedCSS();
        }
    }
    
    public final void pseudoClassStateChanged(final PseudoClass pseudoClass, final boolean b) {
        if ((b ? this.pseudoClassStates.add(pseudoClass) : this.pseudoClassStates.remove(pseudoClass)) && this.styleHelper != null && this.styleHelper.pseudoClassStateChanged(pseudoClass)) {
            this.requestCssStateTransition();
        }
    }
    
    @Override
    public final ObservableSet<PseudoClass> getPseudoClassStates() {
        return FXCollections.unmodifiableObservableSet(this.pseudoClassStates);
    }
    
    final void notifyParentsOfInvalidatedCSS() {
        final SubScene subScene = this.getSubScene();
        final Parent parent = (subScene != null) ? subScene.getRoot() : this.getScene().getRoot();
        if (!parent.isDirty(DirtyBits.NODE_CSS)) {
            NodeHelper.markDirty(parent, DirtyBits.NODE_CSS);
            if (subScene != null) {
                subScene.cssFlag = CssFlags.UPDATE;
                subScene.notifyParentsOfInvalidatedCSS();
            }
        }
        Parent parent2 = this.getParent();
        while (parent2 != null) {
            if (parent2.cssFlag == CssFlags.CLEAN) {
                parent2.cssFlag = CssFlags.DIRTY_BRANCH;
                parent2 = parent2.getParent();
            }
            else {
                parent2 = null;
            }
        }
    }
    
    final void reapplyCSS() {
        if (this.getScene() == null) {
            return;
        }
        if (this.cssFlag == CssFlags.REAPPLY) {
            return;
        }
        if (this.cssFlag == CssFlags.UPDATE) {
            this.cssFlag = CssFlags.REAPPLY;
            this.notifyParentsOfInvalidatedCSS();
            return;
        }
        this.reapplyCss();
        if (this.getParent() != null && this.getParent().isPerformingLayout()) {
            NodeHelper.processCSS(this);
        }
        else {
            this.notifyParentsOfInvalidatedCSS();
        }
    }
    
    private void reapplyCss() {
        final CssStyleHelper styleHelper = this.styleHelper;
        this.cssFlag = CssFlags.REAPPLY;
        this.styleHelper = CssStyleHelper.createStyleHelper(this);
        if (this instanceof Parent) {
            if (this.styleHelper == null || styleHelper != this.styleHelper || this.getParent() == null || this.getParent().cssFlag != CssFlags.CLEAN) {
                final ObservableList<Node> children = ((Parent)this).getChildren();
                for (int i = 0; i < children.size(); ++i) {
                    ((Node)children.get(i)).reapplyCss();
                }
            }
        }
        else if (this instanceof SubScene) {
            final Parent root = ((SubScene)this).getRoot();
            if (root != null) {
                root.reapplyCss();
            }
        }
        else if (this.styleHelper == null) {
            this.cssFlag = CssFlags.CLEAN;
            return;
        }
        this.cssFlag = CssFlags.UPDATE;
    }
    
    void processCSS() {
        switch (this.cssFlag) {
            case CLEAN: {
                break;
            }
            case DIRTY_BRANCH: {
                final Parent parent = (Parent)this;
                parent.cssFlag = CssFlags.CLEAN;
                final ObservableList<Node> children = parent.getChildren();
                for (int i = 0; i < children.size(); ++i) {
                    ((Node)children.get(i)).processCSS();
                }
                break;
            }
            default: {
                NodeHelper.processCSS(this);
                break;
            }
        }
    }
    
    public final void applyCss() {
        if (this.getScene() == null) {
            return;
        }
        if (this.cssFlag != CssFlags.REAPPLY) {
            this.cssFlag = CssFlags.UPDATE;
        }
        Node node = this;
        if (this.getScene().getRoot().isDirty(DirtyBits.NODE_CSS)) {
            for (Parent parent = this.getParent(); parent != null; parent = parent.getParent()) {
                if (parent.cssFlag == CssFlags.UPDATE || parent.cssFlag == CssFlags.REAPPLY) {
                    node = parent;
                }
            }
            if (node == this.getScene().getRoot()) {
                this.getScene().getRoot().clearDirty(DirtyBits.NODE_CSS);
            }
        }
        node.processCSS();
    }
    
    private void doProcessCSS() {
        if (this.cssFlag == CssFlags.CLEAN) {
            return;
        }
        if (this.cssFlag == CssFlags.REAPPLY) {
            this.reapplyCss();
        }
        this.cssFlag = CssFlags.CLEAN;
        if (this.styleHelper != null && this.getScene() != null) {
            this.styleHelper.transitionToState(this);
        }
    }
    
    public final void setAccessibleRole(AccessibleRole node) {
        if (node == null) {
            node = AccessibleRole.NODE;
        }
        this.accessibleRoleProperty().set(node);
    }
    
    public final AccessibleRole getAccessibleRole() {
        if (this.accessibleRole == null) {
            return AccessibleRole.NODE;
        }
        return this.accessibleRoleProperty().get();
    }
    
    public final ObjectProperty<AccessibleRole> accessibleRoleProperty() {
        if (this.accessibleRole == null) {
            this.accessibleRole = new SimpleObjectProperty<AccessibleRole>(this, "accessibleRole", AccessibleRole.NODE);
        }
        return this.accessibleRole;
    }
    
    public final void setAccessibleRoleDescription(final String s) {
        this.accessibleRoleDescriptionProperty().set(s);
    }
    
    public final String getAccessibleRoleDescription() {
        if (this.accessibilityProperties == null) {
            return null;
        }
        if (this.accessibilityProperties.accessibleRoleDescription == null) {
            return null;
        }
        return this.accessibleRoleDescriptionProperty().get();
    }
    
    public final ObjectProperty<String> accessibleRoleDescriptionProperty() {
        return this.getAccessibilityProperties().getAccessibleRoleDescription();
    }
    
    public final void setAccessibleText(final String s) {
        this.accessibleTextProperty().set(s);
    }
    
    public final String getAccessibleText() {
        if (this.accessibilityProperties == null) {
            return null;
        }
        if (this.accessibilityProperties.accessibleText == null) {
            return null;
        }
        return this.accessibleTextProperty().get();
    }
    
    public final ObjectProperty<String> accessibleTextProperty() {
        return this.getAccessibilityProperties().getAccessibleText();
    }
    
    public final void setAccessibleHelp(final String s) {
        this.accessibleHelpProperty().set(s);
    }
    
    public final String getAccessibleHelp() {
        if (this.accessibilityProperties == null) {
            return null;
        }
        if (this.accessibilityProperties.accessibleHelp == null) {
            return null;
        }
        return this.accessibleHelpProperty().get();
    }
    
    public final ObjectProperty<String> accessibleHelpProperty() {
        return this.getAccessibilityProperties().getAccessibleHelp();
    }
    
    private AccessibilityProperties getAccessibilityProperties() {
        if (this.accessibilityProperties == null) {
            this.accessibilityProperties = new AccessibilityProperties();
        }
        return this.accessibilityProperties;
    }
    
    public Object queryAccessibleAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
        switch (accessibleAttribute) {
            case ROLE: {
                return this.getAccessibleRole();
            }
            case ROLE_DESCRIPTION: {
                return this.getAccessibleRoleDescription();
            }
            case TEXT: {
                return this.getAccessibleText();
            }
            case HELP: {
                return this.getAccessibleHelp();
            }
            case PARENT: {
                return this.getParent();
            }
            case SCENE: {
                return this.getScene();
            }
            case BOUNDS: {
                return this.localToScreen(this.getBoundsInLocal());
            }
            case DISABLED: {
                return this.isDisabled();
            }
            case FOCUSED: {
                return this.isFocused();
            }
            case VISIBLE: {
                return this.isVisible();
            }
            case LABELED_BY: {
                return this.labeledBy;
            }
            default: {
                return null;
            }
        }
    }
    
    public void executeAccessibleAction(final AccessibleAction accessibleAction, final Object... array) {
        switch (accessibleAction) {
            case REQUEST_FOCUS: {
                if (this.isFocusTraversable()) {
                    this.requestFocus();
                    break;
                }
                break;
            }
            case SHOW_MENU: {
                final Bounds boundsInLocal = this.getBoundsInLocal();
                final Point2D localToScreen = this.localToScreen(boundsInLocal.getMaxX(), boundsInLocal.getMaxY());
                Event.fireEvent(this, new ContextMenuEvent(ContextMenuEvent.CONTEXT_MENU_REQUESTED, boundsInLocal.getMaxX(), boundsInLocal.getMaxY(), localToScreen.getX(), localToScreen.getY(), false, new PickResult(this, boundsInLocal.getMaxX(), boundsInLocal.getMaxY())));
                break;
            }
        }
    }
    
    public final void notifyAccessibleAttributeChanged(final AccessibleAttribute accessibleAttribute) {
        if (this.accessible == null) {
            final Scene scene = this.getScene();
            if (scene != null) {
                this.accessible = scene.removeAccessible(this);
            }
        }
        if (this.accessible != null) {
            this.accessible.sendNotification(accessibleAttribute);
        }
    }
    
    Accessible getAccessible() {
        if (this.accessible == null) {
            final Scene scene = this.getScene();
            if (scene != null) {
                this.accessible = scene.removeAccessible(this);
            }
        }
        if (this.accessible == null) {
            (this.accessible = Application.GetApplication().createAccessible()).setEventHandler(new Accessible.EventHandler() {
                @Override
                public AccessControlContext getAccessControlContext() {
                    final Scene scene = Node.this.getScene();
                    if (scene == null) {
                        throw new RuntimeException("Accessbility requested for node not on a scene");
                    }
                    if (scene.getPeer() != null) {
                        return scene.getPeer().getAccessControlContext();
                    }
                    return scene.acc;
                }
                
                @Override
                public Object getAttribute(final AccessibleAttribute accessibleAttribute, final Object... array) {
                    return Node.this.queryAccessibleAttribute(accessibleAttribute, array);
                }
                
                @Override
                public void executeAction(final AccessibleAction accessibleAction, final Object... array) {
                    Node.this.executeAccessibleAction(accessibleAction, array);
                }
                
                @Override
                public String toString() {
                    final String name = Node.this.getClass().getName();
                    return name.substring(name.lastIndexOf(46) + 1);
                }
            });
        }
        return this.accessible;
    }
    
    void releaseAccessible() {
        final Accessible accessible = this.accessible;
        if (accessible != null) {
            this.accessible = null;
            accessible.dispose();
        }
    }
    
    static {
        PerformanceTracker.logEvent("Node class loaded");
        NodeHelper.setNodeAccessor(new NodeHelper.NodeAccessor() {
            @Override
            public NodeHelper getHelper(final Node node) {
                return node.nodeHelper;
            }
            
            @Override
            public void setHelper(final Node node, final NodeHelper nodeHelper) {
                node.nodeHelper = nodeHelper;
            }
            
            @Override
            public void doMarkDirty(final Node node, final DirtyBits dirtyBits) {
                node.doMarkDirty(dirtyBits);
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                node.doUpdatePeer();
            }
            
            @Override
            public BaseTransform getLeafTransform(final Node node) {
                return node.getLeafTransform();
            }
            
            @Override
            public Bounds doComputeLayoutBounds(final Node node) {
                return node.doComputeLayoutBounds();
            }
            
            @Override
            public void doTransformsChanged(final Node node) {
                node.doTransformsChanged();
            }
            
            @Override
            public void doPickNodeLocal(final Node node, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                node.doPickNodeLocal(pickRay, pickResultChooser);
            }
            
            @Override
            public boolean doComputeIntersects(final Node node, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                return node.doComputeIntersects(pickRay, pickResultChooser);
            }
            
            @Override
            public void doGeomChanged(final Node node) {
                node.doGeomChanged();
            }
            
            @Override
            public void doNotifyLayoutBoundsChanged(final Node node) {
                node.doNotifyLayoutBoundsChanged();
            }
            
            @Override
            public void doProcessCSS(final Node node) {
                node.doProcessCSS();
            }
            
            @Override
            public boolean isDirty(final Node node, final DirtyBits dirtyBits) {
                return node.isDirty(dirtyBits);
            }
            
            @Override
            public boolean isDirtyEmpty(final Node node) {
                return node.isDirtyEmpty();
            }
            
            @Override
            public void syncPeer(final Node node) {
                node.syncPeer();
            }
            
            @Override
            public void layoutBoundsChanged(final Node node) {
                node.layoutBoundsChanged();
            }
            
            @Override
            public <P extends NGNode> P getPeer(final Node node) {
                return node.getPeer();
            }
            
            @Override
            public void setShowMnemonics(final Node node, final boolean showMnemonics) {
                node.setShowMnemonics(showMnemonics);
            }
            
            @Override
            public boolean isShowMnemonics(final Node node) {
                return node.isShowMnemonics();
            }
            
            @Override
            public BooleanProperty showMnemonicsProperty(final Node node) {
                return node.showMnemonicsProperty();
            }
            
            @Override
            public boolean traverse(final Node node, final Direction direction) {
                return node.traverse(direction);
            }
            
            @Override
            public double getPivotX(final Node node) {
                return node.getPivotX();
            }
            
            @Override
            public double getPivotY(final Node node) {
                return node.getPivotY();
            }
            
            @Override
            public double getPivotZ(final Node node) {
                return node.getPivotZ();
            }
            
            @Override
            public void pickNode(final Node node, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                node.pickNode(pickRay, pickResultChooser);
            }
            
            @Override
            public boolean intersects(final Node node, final PickRay pickRay, final PickResultChooser pickResultChooser) {
                return node.intersects(pickRay, pickResultChooser);
            }
            
            @Override
            public double intersectsBounds(final Node node, final PickRay pickRay) {
                return node.intersectsBounds(pickRay);
            }
            
            @Override
            public void layoutNodeForPrinting(final Node node) {
                node.doCSSLayoutSyncForSnapshot();
            }
            
            @Override
            public boolean isDerivedDepthTest(final Node node) {
                return node.isDerivedDepthTest();
            }
            
            @Override
            public SubScene getSubScene(final Node node) {
                return node.getSubScene();
            }
            
            @Override
            public void setLabeledBy(final Node node, final Node node2) {
                node.labeledBy = node2;
            }
            
            @Override
            public Accessible getAccessible(final Node node) {
                return node.getAccessible();
            }
            
            @Override
            public void reapplyCSS(final Node node) {
                node.reapplyCSS();
            }
            
            @Override
            public boolean isTreeVisible(final Node node) {
                return node.isTreeVisible();
            }
            
            @Override
            public BooleanExpression treeVisibleProperty(final Node node) {
                return node.treeVisibleProperty();
            }
            
            @Override
            public boolean isTreeShowing(final Node node) {
                return node.isTreeShowing();
            }
            
            @Override
            public BooleanExpression treeShowingProperty(final Node node) {
                return node.treeShowingProperty();
            }
            
            @Override
            public List<Style> getMatchingStyles(final CssMetaData cssMetaData, final Styleable styleable) {
                return Node.getMatchingStyles(cssMetaData, styleable);
            }
            
            @Override
            public Map<StyleableProperty<?>, List<Style>> findStyles(final Node node, final Map<StyleableProperty<?>, List<Style>> map) {
                return node.findStyles(map);
            }
        });
        USER_DATA_KEY = new Object();
        DEFAULT_ROTATION_AXIS = Rotate.Z_AXIS;
        DEFAULT_CACHE_HINT = CacheHint.DEFAULT;
        DEFAULT_CLIP = null;
        DEFAULT_CURSOR = null;
        DEFAULT_DEPTH_TEST = DepthTest.INHERIT;
        DEFAULT_EFFECT = null;
        DEFAULT_INPUT_METHOD_REQUESTS = null;
        HOVER_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("hover");
        PRESSED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("pressed");
        DISABLED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("disabled");
        FOCUSED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("focused");
        SHOW_MNEMONICS_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("show-mnemonics");
        boundsAccessor = ((baseBounds, baseTransform, node) -> node.getGeomBounds(baseBounds, baseTransform));
    }
    
    private class ReadOnlyObjectWrapperManualFire<T> extends ReadOnlyObjectWrapper<T>
    {
        @Override
        public Object getBean() {
            return Node.this;
        }
        
        @Override
        public String getName() {
            return "scene";
        }
        
        @Override
        protected void fireValueChangedEvent() {
        }
        
        public void fireSuperValueChangedEvent() {
            super.fireValueChangedEvent();
        }
    }
    
    private final class NodeTransformation
    {
        private DoubleProperty translateX;
        private DoubleProperty translateY;
        private DoubleProperty translateZ;
        private DoubleProperty scaleX;
        private DoubleProperty scaleY;
        private DoubleProperty scaleZ;
        private DoubleProperty rotate;
        private ObjectProperty<Point3D> rotationAxis;
        private ObservableList<Transform> transforms;
        private LazyTransformProperty localToParentTransform;
        private LazyTransformProperty localToSceneTransform;
        private int listenerReasons;
        private InvalidationListener localToSceneInvLstnr;
        
        private NodeTransformation() {
            this.listenerReasons = 0;
        }
        
        private InvalidationListener getLocalToSceneInvalidationListener() {
            if (this.localToSceneInvLstnr == null) {
                this.localToSceneInvLstnr = (p0 -> this.invalidateLocalToSceneTransform());
            }
            return this.localToSceneInvLstnr;
        }
        
        public void incListenerReasons() {
            if (this.listenerReasons == 0) {
                final Parent parent = Node.this.getParent();
                if (parent != null) {
                    parent.localToSceneTransformProperty().addListener(this.getLocalToSceneInvalidationListener());
                }
            }
            ++this.listenerReasons;
        }
        
        public void decListenerReasons() {
            --this.listenerReasons;
            if (this.listenerReasons == 0) {
                final Parent parent = Node.this.getParent();
                if (parent != null) {
                    parent.localToSceneTransformProperty().removeListener(this.getLocalToSceneInvalidationListener());
                }
                if (this.localToSceneTransform != null) {
                    this.localToSceneTransform.validityUnknown();
                }
            }
        }
        
        public final Transform getLocalToParentTransform() {
            return this.localToParentTransformProperty().get();
        }
        
        public final ReadOnlyObjectProperty<Transform> localToParentTransformProperty() {
            if (this.localToParentTransform == null) {
                this.localToParentTransform = new LazyTransformProperty() {
                    @Override
                    protected Transform computeTransform(final Transform transform) {
                        Node.this.updateLocalToParentTransform();
                        return TransformUtils.immutableTransform(transform, Node.this.localToParentTx.getMxx(), Node.this.localToParentTx.getMxy(), Node.this.localToParentTx.getMxz(), Node.this.localToParentTx.getMxt(), Node.this.localToParentTx.getMyx(), Node.this.localToParentTx.getMyy(), Node.this.localToParentTx.getMyz(), Node.this.localToParentTx.getMyt(), Node.this.localToParentTx.getMzx(), Node.this.localToParentTx.getMzy(), Node.this.localToParentTx.getMzz(), Node.this.localToParentTx.getMzt());
                    }
                    
                    @Override
                    protected boolean validityKnown() {
                        return true;
                    }
                    
                    @Override
                    protected int computeValidity() {
                        return this.valid;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "localToParentTransform";
                    }
                };
            }
            return this.localToParentTransform;
        }
        
        public void invalidateLocalToParentTransform() {
            if (this.localToParentTransform != null) {
                this.localToParentTransform.invalidate();
            }
        }
        
        public final Transform getLocalToSceneTransform() {
            return this.localToSceneTransformProperty().get();
        }
        
        public final ReadOnlyObjectProperty<Transform> localToSceneTransformProperty() {
            if (this.localToSceneTransform == null) {
                this.localToSceneTransform = new LocalToSceneTransformProperty();
            }
            return this.localToSceneTransform;
        }
        
        public void invalidateLocalToSceneTransform() {
            if (this.localToSceneTransform != null) {
                this.localToSceneTransform.invalidate();
            }
        }
        
        public double getTranslateX() {
            return (this.translateX == null) ? 0.0 : this.translateX.get();
        }
        
        public final DoubleProperty translateXProperty() {
            if (this.translateX == null) {
                this.translateX = new StyleableDoubleProperty(0.0) {
                    public void invalidated() {
                        NodeHelper.transformsChanged(Node.this);
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.TRANSLATE_X;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "translateX";
                    }
                };
            }
            return this.translateX;
        }
        
        public double getTranslateY() {
            return (this.translateY == null) ? 0.0 : this.translateY.get();
        }
        
        public final DoubleProperty translateYProperty() {
            if (this.translateY == null) {
                this.translateY = new StyleableDoubleProperty(0.0) {
                    public void invalidated() {
                        NodeHelper.transformsChanged(Node.this);
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.TRANSLATE_Y;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "translateY";
                    }
                };
            }
            return this.translateY;
        }
        
        public double getTranslateZ() {
            return (this.translateZ == null) ? 0.0 : this.translateZ.get();
        }
        
        public final DoubleProperty translateZProperty() {
            if (this.translateZ == null) {
                this.translateZ = new StyleableDoubleProperty(0.0) {
                    public void invalidated() {
                        NodeHelper.transformsChanged(Node.this);
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.TRANSLATE_Z;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "translateZ";
                    }
                };
            }
            return this.translateZ;
        }
        
        public double getScaleX() {
            return (this.scaleX == null) ? 1.0 : this.scaleX.get();
        }
        
        public final DoubleProperty scaleXProperty() {
            if (this.scaleX == null) {
                this.scaleX = new StyleableDoubleProperty(1.0) {
                    public void invalidated() {
                        NodeHelper.transformsChanged(Node.this);
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.SCALE_X;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "scaleX";
                    }
                };
            }
            return this.scaleX;
        }
        
        public double getScaleY() {
            return (this.scaleY == null) ? 1.0 : this.scaleY.get();
        }
        
        public final DoubleProperty scaleYProperty() {
            if (this.scaleY == null) {
                this.scaleY = new StyleableDoubleProperty(1.0) {
                    public void invalidated() {
                        NodeHelper.transformsChanged(Node.this);
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.SCALE_Y;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "scaleY";
                    }
                };
            }
            return this.scaleY;
        }
        
        public double getScaleZ() {
            return (this.scaleZ == null) ? 1.0 : this.scaleZ.get();
        }
        
        public final DoubleProperty scaleZProperty() {
            if (this.scaleZ == null) {
                this.scaleZ = new StyleableDoubleProperty(1.0) {
                    public void invalidated() {
                        NodeHelper.transformsChanged(Node.this);
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.SCALE_Z;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "scaleZ";
                    }
                };
            }
            return this.scaleZ;
        }
        
        public double getRotate() {
            return (this.rotate == null) ? 0.0 : this.rotate.get();
        }
        
        public final DoubleProperty rotateProperty() {
            if (this.rotate == null) {
                this.rotate = new StyleableDoubleProperty(0.0) {
                    public void invalidated() {
                        NodeHelper.transformsChanged(Node.this);
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.ROTATE;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "rotate";
                    }
                };
            }
            return this.rotate;
        }
        
        public Point3D getRotationAxis() {
            return (this.rotationAxis == null) ? Node.DEFAULT_ROTATION_AXIS : this.rotationAxis.get();
        }
        
        public final ObjectProperty<Point3D> rotationAxisProperty() {
            if (this.rotationAxis == null) {
                this.rotationAxis = new ObjectPropertyBase<Point3D>(Node.DEFAULT_ROTATION_AXIS) {
                    @Override
                    protected void invalidated() {
                        NodeHelper.transformsChanged(Node.this);
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "rotationAxis";
                    }
                };
            }
            return this.rotationAxis;
        }
        
        public ObservableList<Transform> getTransforms() {
            if (this.transforms == null) {
                this.transforms = new TrackableObservableList<Transform>() {
                    @Override
                    protected void onChanged(final ListChangeListener.Change<Transform> change) {
                        while (change.next()) {
                            final Iterator<Transform> iterator = change.getRemoved().iterator();
                            while (iterator.hasNext()) {
                                TransformHelper.remove(iterator.next(), Node.this);
                            }
                            final Iterator<Transform> iterator2 = change.getAddedSubList().iterator();
                            while (iterator2.hasNext()) {
                                TransformHelper.add(iterator2.next(), Node.this);
                            }
                        }
                        NodeHelper.transformsChanged(Node.this);
                    }
                };
            }
            return this.transforms;
        }
        
        public boolean canSetTranslateX() {
            return this.translateX == null || !this.translateX.isBound();
        }
        
        public boolean canSetTranslateY() {
            return this.translateY == null || !this.translateY.isBound();
        }
        
        public boolean canSetTranslateZ() {
            return this.translateZ == null || !this.translateZ.isBound();
        }
        
        public boolean canSetScaleX() {
            return this.scaleX == null || !this.scaleX.isBound();
        }
        
        public boolean canSetScaleY() {
            return this.scaleY == null || !this.scaleY.isBound();
        }
        
        public boolean canSetScaleZ() {
            return this.scaleZ == null || !this.scaleZ.isBound();
        }
        
        public boolean canSetRotate() {
            return this.rotate == null || !this.rotate.isBound();
        }
        
        public boolean hasTransforms() {
            return this.transforms != null && !this.transforms.isEmpty();
        }
        
        public boolean hasScaleOrRotate() {
            return (this.scaleX != null && this.scaleX.get() != 1.0) || (this.scaleY != null && this.scaleY.get() != 1.0) || (this.scaleZ != null && this.scaleZ.get() != 1.0) || (this.rotate != null && this.rotate.get() != 0.0);
        }
        
        class LocalToSceneTransformProperty extends LazyTransformProperty
        {
            private List localToSceneListeners;
            private long stamp;
            private long parentStamp;
            
            @Override
            protected Transform computeTransform(final Transform transform) {
                ++this.stamp;
                Node.this.updateLocalToParentTransform();
                final Parent parent = Node.this.getParent();
                if (parent != null) {
                    final LocalToSceneTransformProperty localToSceneTransformProperty = (LocalToSceneTransformProperty)parent.localToSceneTransformProperty();
                    final Transform internalValue = localToSceneTransformProperty.getInternalValue();
                    this.parentStamp = localToSceneTransformProperty.stamp;
                    return TransformUtils.immutableTransform(transform, internalValue, ((LazyTransformProperty)NodeTransformation.this.localToParentTransformProperty()).getInternalValue());
                }
                return TransformUtils.immutableTransform(transform, ((LazyTransformProperty)NodeTransformation.this.localToParentTransformProperty()).getInternalValue());
            }
            
            @Override
            public Object getBean() {
                return Node.this;
            }
            
            @Override
            public String getName() {
                return "localToSceneTransform";
            }
            
            @Override
            protected boolean validityKnown() {
                return NodeTransformation.this.listenerReasons > 0;
            }
            
            @Override
            protected int computeValidity() {
                if (this.valid != 2) {
                    return this.valid;
                }
                final Parent parent = ((Node)this.getBean()).getParent();
                if (parent == null) {
                    return 0;
                }
                final LocalToSceneTransformProperty localToSceneTransformProperty = (LocalToSceneTransformProperty)parent.localToSceneTransformProperty();
                if (this.parentStamp != localToSceneTransformProperty.stamp) {
                    return this.valid = 1;
                }
                final int computeValidity = localToSceneTransformProperty.computeValidity();
                if (computeValidity == 1) {
                    this.valid = 1;
                }
                return computeValidity;
            }
            
            @Override
            public void addListener(final InvalidationListener invalidationListener) {
                NodeTransformation.this.incListenerReasons();
                if (this.localToSceneListeners == null) {
                    this.localToSceneListeners = new LinkedList();
                }
                this.localToSceneListeners.add(invalidationListener);
                super.addListener(invalidationListener);
            }
            
            @Override
            public void addListener(final ChangeListener<? super Transform> changeListener) {
                NodeTransformation.this.incListenerReasons();
                if (this.localToSceneListeners == null) {
                    this.localToSceneListeners = new LinkedList();
                }
                this.localToSceneListeners.add(changeListener);
                super.addListener(changeListener);
            }
            
            @Override
            public void removeListener(final InvalidationListener invalidationListener) {
                if (this.localToSceneListeners != null && this.localToSceneListeners.remove(invalidationListener)) {
                    NodeTransformation.this.decListenerReasons();
                }
                super.removeListener(invalidationListener);
            }
            
            @Override
            public void removeListener(final ChangeListener<? super Transform> changeListener) {
                if (this.localToSceneListeners != null && this.localToSceneListeners.remove(changeListener)) {
                    NodeTransformation.this.decListenerReasons();
                }
                super.removeListener(changeListener);
            }
        }
    }
    
    private final class EffectiveOrientationProperty extends ReadOnlyObjectPropertyBase<NodeOrientation>
    {
        @Override
        public NodeOrientation get() {
            return Node.this.getEffectiveNodeOrientation();
        }
        
        @Override
        public Object getBean() {
            return Node.this;
        }
        
        @Override
        public String getName() {
            return "effectiveNodeOrientation";
        }
        
        public void invalidate() {
            this.fireValueChangedEvent();
        }
    }
    
    private final class MiscProperties
    {
        private LazyBoundsProperty boundsInParent;
        private LazyBoundsProperty boundsInLocal;
        private BooleanProperty cache;
        private ObjectProperty<CacheHint> cacheHint;
        private ObjectProperty<Node> clip;
        private ObjectProperty<Cursor> cursor;
        private ObjectProperty<DepthTest> depthTest;
        private BooleanProperty disable;
        private ObjectProperty<Effect> effect;
        private ObjectProperty<InputMethodRequests> inputMethodRequests;
        private BooleanProperty mouseTransparent;
        private DoubleProperty viewOrder;
        
        public double getViewOrder() {
            return (this.viewOrder == null) ? 0.0 : this.viewOrder.get();
        }
        
        public final DoubleProperty viewOrderProperty() {
            if (this.viewOrder == null) {
                this.viewOrder = new StyleableDoubleProperty(0.0) {
                    public void invalidated() {
                        final Parent parent = Node.this.getParent();
                        if (parent != null) {
                            parent.markViewOrderChildrenDirty();
                        }
                        NodeHelper.markDirty(Node.this, DirtyBits.NODE_VIEW_ORDER);
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.VIEW_ORDER;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "viewOrder";
                    }
                };
            }
            return this.viewOrder;
        }
        
        public final Bounds getBoundsInParent() {
            return this.boundsInParentProperty().get();
        }
        
        public final ReadOnlyObjectProperty<Bounds> boundsInParentProperty() {
            if (this.boundsInParent == null) {
                this.boundsInParent = new LazyBoundsProperty() {
                    @Override
                    protected Bounds computeBounds() {
                        final BaseBounds transformedBounds = Node.this.getTransformedBounds(TempState.getInstance().bounds, BaseTransform.IDENTITY_TRANSFORM);
                        return new BoundingBox(transformedBounds.getMinX(), transformedBounds.getMinY(), transformedBounds.getMinZ(), transformedBounds.getWidth(), transformedBounds.getHeight(), transformedBounds.getDepth());
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "boundsInParent";
                    }
                };
            }
            return this.boundsInParent;
        }
        
        public void invalidateBoundsInParent() {
            if (this.boundsInParent != null) {
                this.boundsInParent.invalidate();
            }
        }
        
        public final Bounds getBoundsInLocal() {
            return this.boundsInLocalProperty().get();
        }
        
        public final ReadOnlyObjectProperty<Bounds> boundsInLocalProperty() {
            if (this.boundsInLocal == null) {
                this.boundsInLocal = new LazyBoundsProperty() {
                    @Override
                    protected Bounds computeBounds() {
                        final BaseBounds localBounds = Node.this.getLocalBounds(TempState.getInstance().bounds, BaseTransform.IDENTITY_TRANSFORM);
                        return new BoundingBox(localBounds.getMinX(), localBounds.getMinY(), localBounds.getMinZ(), localBounds.getWidth(), localBounds.getHeight(), localBounds.getDepth());
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "boundsInLocal";
                    }
                };
            }
            return this.boundsInLocal;
        }
        
        public void invalidateBoundsInLocal() {
            if (this.boundsInLocal != null) {
                this.boundsInLocal.invalidate();
            }
        }
        
        public final boolean isCache() {
            return this.cache != null && this.cache.get();
        }
        
        public final BooleanProperty cacheProperty() {
            if (this.cache == null) {
                this.cache = new BooleanPropertyBase(false) {
                    @Override
                    protected void invalidated() {
                        NodeHelper.markDirty(Node.this, DirtyBits.NODE_CACHE);
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "cache";
                    }
                };
            }
            return this.cache;
        }
        
        public final CacheHint getCacheHint() {
            return (this.cacheHint == null) ? Node.DEFAULT_CACHE_HINT : this.cacheHint.get();
        }
        
        public final ObjectProperty<CacheHint> cacheHintProperty() {
            if (this.cacheHint == null) {
                this.cacheHint = new ObjectPropertyBase<CacheHint>(Node.DEFAULT_CACHE_HINT) {
                    @Override
                    protected void invalidated() {
                        NodeHelper.markDirty(Node.this, DirtyBits.NODE_CACHE);
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "cacheHint";
                    }
                };
            }
            return this.cacheHint;
        }
        
        public final Node getClip() {
            return (this.clip == null) ? Node.DEFAULT_CLIP : this.clip.get();
        }
        
        public final ObjectProperty<Node> clipProperty() {
            if (this.clip == null) {
                this.clip = new ObjectPropertyBase<Node>(Node.DEFAULT_CLIP) {
                    private Node oldClip;
                    
                    @Override
                    protected void invalidated() {
                        final Node oldClip = this.get();
                        if (oldClip == null || ((oldClip.isConnected() || oldClip.clipParent == Node.this) && !Node.this.wouldCreateCycle(Node.this, oldClip))) {
                            if (this.oldClip != null) {
                                this.oldClip.clipParent = null;
                                this.oldClip.setScenes(null, null);
                                this.oldClip.updateTreeVisible(false);
                            }
                            if (oldClip != null) {
                                oldClip.clipParent = Node.this;
                                oldClip.setScenes(Node.this.getScene(), Node.this.getSubScene());
                                oldClip.updateTreeVisible(true);
                            }
                            NodeHelper.markDirty(Node.this, DirtyBits.NODE_CLIP);
                            Node.this.localBoundsChanged();
                            this.oldClip = oldClip;
                            return;
                        }
                        final String s = (oldClip.isConnected() && oldClip.clipParent != Node.this) ? "node already connected" : "cycle detected";
                        if (this.isBound()) {
                            this.unbind();
                            this.set(this.oldClip);
                            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/Node;Ljavafx/beans/property/ObjectProperty;)Ljava/lang/String;, s, Node.this, MiscProperties.this.clip));
                        }
                        this.set(this.oldClip);
                        throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljavafx/scene/Node;Ljavafx/beans/property/ObjectProperty;)Ljava/lang/String;, s, Node.this, MiscProperties.this.clip));
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "clip";
                    }
                };
            }
            return this.clip;
        }
        
        public final Cursor getCursor() {
            return (this.cursor == null) ? Node.DEFAULT_CURSOR : this.cursor.get();
        }
        
        public final ObjectProperty<Cursor> cursorProperty() {
            if (this.cursor == null) {
                this.cursor = new StyleableObjectProperty<Cursor>(Node.DEFAULT_CURSOR) {
                    @Override
                    protected void invalidated() {
                        final Scene scene = Node.this.getScene();
                        if (scene != null) {
                            scene.markCursorDirty();
                        }
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.CURSOR;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "cursor";
                    }
                };
            }
            return this.cursor;
        }
        
        public final DepthTest getDepthTest() {
            return (this.depthTest == null) ? Node.DEFAULT_DEPTH_TEST : this.depthTest.get();
        }
        
        public final ObjectProperty<DepthTest> depthTestProperty() {
            if (this.depthTest == null) {
                this.depthTest = new ObjectPropertyBase<DepthTest>(Node.DEFAULT_DEPTH_TEST) {
                    @Override
                    protected void invalidated() {
                        Node.this.computeDerivedDepthTest();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "depthTest";
                    }
                };
            }
            return this.depthTest;
        }
        
        public final boolean isDisable() {
            return this.disable != null && this.disable.get();
        }
        
        public final BooleanProperty disableProperty() {
            if (this.disable == null) {
                this.disable = new BooleanPropertyBase(false) {
                    @Override
                    protected void invalidated() {
                        Node.this.updateDisabled();
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "disable";
                    }
                };
            }
            return this.disable;
        }
        
        public final Effect getEffect() {
            return (this.effect == null) ? Node.DEFAULT_EFFECT : this.effect.get();
        }
        
        public final ObjectProperty<Effect> effectProperty() {
            if (this.effect == null) {
                this.effect = new StyleableObjectProperty<Effect>() {
                    private Effect oldEffect = null;
                    private int oldBits;
                    private final AbstractNotifyListener effectChangeListener = new AbstractNotifyListener() {
                        @Override
                        public void invalidated(final Observable observable) {
                            final int value = ((IntegerProperty)observable).get();
                            final int n = value ^ StyleableObjectProperty.this.oldBits;
                            StyleableObjectProperty.this.oldBits = value;
                            if (EffectDirtyBits.isSet(n, EffectDirtyBits.EFFECT_DIRTY) && EffectDirtyBits.isSet(value, EffectDirtyBits.EFFECT_DIRTY)) {
                                NodeHelper.markDirty(Node.this, DirtyBits.EFFECT_EFFECT);
                            }
                            if (EffectDirtyBits.isSet(n, EffectDirtyBits.BOUNDS_CHANGED)) {
                                Node.this.localBoundsChanged();
                            }
                        }
                    };
                    
                    @Override
                    protected void invalidated() {
                        final Effect oldEffect = this.get();
                        if (this.oldEffect != null) {
                            EffectHelper.effectDirtyProperty(this.oldEffect).removeListener(this.effectChangeListener.getWeakListener());
                        }
                        if ((this.oldEffect = oldEffect) != null) {
                            EffectHelper.effectDirtyProperty(oldEffect).addListener(this.effectChangeListener.getWeakListener());
                            if (EffectHelper.isEffectDirty(oldEffect)) {
                                NodeHelper.markDirty(Node.this, DirtyBits.EFFECT_EFFECT);
                            }
                            this.oldBits = EffectHelper.effectDirtyProperty(oldEffect).get();
                        }
                        NodeHelper.markDirty(Node.this, DirtyBits.NODE_EFFECT);
                        Node.this.localBoundsChanged();
                    }
                    
                    @Override
                    public CssMetaData getCssMetaData() {
                        return StyleableProperties.EFFECT;
                    }
                    
                    @Override
                    public Object getBean() {
                        return Node.this;
                    }
                    
                    @Override
                    public String getName() {
                        return "effect";
                    }
                };
            }
            return this.effect;
        }
        
        public final InputMethodRequests getInputMethodRequests() {
            return (this.inputMethodRequests == null) ? Node.DEFAULT_INPUT_METHOD_REQUESTS : this.inputMethodRequests.get();
        }
        
        public ObjectProperty<InputMethodRequests> inputMethodRequestsProperty() {
            if (this.inputMethodRequests == null) {
                this.inputMethodRequests = new SimpleObjectProperty<InputMethodRequests>(Node.this, "inputMethodRequests", Node.DEFAULT_INPUT_METHOD_REQUESTS);
            }
            return this.inputMethodRequests;
        }
        
        public final boolean isMouseTransparent() {
            return this.mouseTransparent != null && this.mouseTransparent.get();
        }
        
        public final BooleanProperty mouseTransparentProperty() {
            if (this.mouseTransparent == null) {
                this.mouseTransparent = new SimpleBooleanProperty(Node.this, "mouseTransparent", false);
            }
            return this.mouseTransparent;
        }
        
        public boolean canSetCursor() {
            return this.cursor == null || !this.cursor.isBound();
        }
        
        public boolean canSetEffect() {
            return this.effect == null || !this.effect.isBound();
        }
    }
    
    final class FocusedProperty extends ReadOnlyBooleanPropertyBase
    {
        private boolean value;
        private boolean valid;
        private boolean needsChangeEvent;
        
        FocusedProperty() {
            this.valid = true;
            this.needsChangeEvent = false;
        }
        
        public void store(final boolean value) {
            if (value != this.value) {
                this.value = value;
                this.markInvalid();
            }
        }
        
        public void notifyListeners() {
            if (this.needsChangeEvent) {
                this.fireValueChangedEvent();
                this.needsChangeEvent = false;
            }
        }
        
        private void markInvalid() {
            if (this.valid) {
                this.valid = false;
                Node.this.pseudoClassStateChanged(Node.FOCUSED_PSEUDOCLASS_STATE, this.get());
                final PlatformLogger focusLogger = Logging.getFocusLogger();
                if (focusLogger.isLoggable(PlatformLogger.Level.FINE)) {
                    focusLogger.fine(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/Node$FocusedProperty;Z)Ljava/lang/String;, this, this.get()));
                }
                this.needsChangeEvent = true;
                Node.this.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUSED);
            }
        }
        
        @Override
        public boolean get() {
            this.valid = true;
            return this.value;
        }
        
        @Override
        public Object getBean() {
            return Node.this;
        }
        
        @Override
        public String getName() {
            return "focused";
        }
    }
    
    class TreeShowingPropertyReadOnly extends BooleanExpression
    {
        private ExpressionHelper<Boolean> helper;
        private boolean valid;
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, invalidationListener);
        }
        
        @Override
        public void addListener(final ChangeListener<? super Boolean> changeListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, changeListener);
        }
        
        @Override
        public void removeListener(final ChangeListener<? super Boolean> changeListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, changeListener);
        }
        
        protected void invalidate() {
            if (this.valid) {
                this.valid = false;
                ExpressionHelper.fireValueChangedEvent(this.helper);
            }
        }
        
        @Override
        public boolean get() {
            this.valid = true;
            return Node.this.treeShowing;
        }
    }
    
    class TreeVisiblePropertyReadOnly extends BooleanExpression
    {
        private ExpressionHelper<Boolean> helper;
        private boolean valid;
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, invalidationListener);
        }
        
        @Override
        public void addListener(final ChangeListener<? super Boolean> changeListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, changeListener);
        }
        
        @Override
        public void removeListener(final ChangeListener<? super Boolean> changeListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, changeListener);
        }
        
        protected void invalidate() {
            if (this.valid) {
                this.valid = false;
                ExpressionHelper.fireValueChangedEvent(this.helper);
            }
        }
        
        @Override
        public boolean get() {
            this.valid = true;
            return Node.this.treeVisible;
        }
    }
    
    private static class StyleableProperties
    {
        private static final CssMetaData<Node, Cursor> CURSOR;
        private static final CssMetaData<Node, Effect> EFFECT;
        private static final CssMetaData<Node, Boolean> FOCUS_TRAVERSABLE;
        private static final CssMetaData<Node, Number> OPACITY;
        private static final CssMetaData<Node, BlendMode> BLEND_MODE;
        private static final CssMetaData<Node, Number> ROTATE;
        private static final CssMetaData<Node, Number> SCALE_X;
        private static final CssMetaData<Node, Number> SCALE_Y;
        private static final CssMetaData<Node, Number> SCALE_Z;
        private static final CssMetaData<Node, Number> TRANSLATE_X;
        private static final CssMetaData<Node, Number> TRANSLATE_Y;
        private static final CssMetaData<Node, Number> TRANSLATE_Z;
        private static final CssMetaData<Node, Number> VIEW_ORDER;
        private static final CssMetaData<Node, Boolean> VISIBILITY;
        private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
        
        static {
            CURSOR = new CssMetaData<Node, Cursor>((StyleConverter)CursorConverter.getInstance()) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.miscProperties == null || node.miscProperties.canSetCursor();
                }
                
                @Override
                public StyleableProperty<Cursor> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Cursor>)(StyleableProperty)node.cursorProperty();
                }
                
                @Override
                public Cursor getInitialValue(final Node node) {
                    return node.getInitialCursor();
                }
            };
            EFFECT = new CssMetaData<Node, Effect>((StyleConverter)EffectConverter.getInstance()) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.miscProperties == null || node.miscProperties.canSetEffect();
                }
                
                @Override
                public StyleableProperty<Effect> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Effect>)(StyleableProperty)node.effectProperty();
                }
            };
            FOCUS_TRAVERSABLE = new CssMetaData<Node, Boolean>((StyleConverter)BooleanConverter.getInstance(), Boolean.FALSE) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.focusTraversable == null || !node.focusTraversable.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Boolean>)node.focusTraversableProperty();
                }
                
                @Override
                public Boolean getInitialValue(final Node node) {
                    return node.getInitialFocusTraversable();
                }
            };
            OPACITY = new CssMetaData<Node, Number>((StyleConverter)SizeConverter.getInstance(), (Number)1.0) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.opacity == null || !node.opacity.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Number>)node.opacityProperty();
                }
            };
            BLEND_MODE = new CssMetaData<Node, BlendMode>((StyleConverter)new EnumConverter(BlendMode.class)) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.blendMode == null || !node.blendMode.isBound();
                }
                
                @Override
                public StyleableProperty<BlendMode> getStyleableProperty(final Node node) {
                    return (StyleableProperty<BlendMode>)(StyleableProperty)node.blendModeProperty();
                }
            };
            ROTATE = new CssMetaData<Node, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.nodeTransformation == null || node.nodeTransformation.rotate == null || node.nodeTransformation.canSetRotate();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Number>)node.rotateProperty();
                }
            };
            SCALE_X = new CssMetaData<Node, Number>((StyleConverter)SizeConverter.getInstance(), (Number)1.0) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.nodeTransformation == null || node.nodeTransformation.scaleX == null || node.nodeTransformation.canSetScaleX();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Number>)node.scaleXProperty();
                }
            };
            SCALE_Y = new CssMetaData<Node, Number>((StyleConverter)SizeConverter.getInstance(), (Number)1.0) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.nodeTransformation == null || node.nodeTransformation.scaleY == null || node.nodeTransformation.canSetScaleY();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Number>)node.scaleYProperty();
                }
            };
            SCALE_Z = new CssMetaData<Node, Number>((StyleConverter)SizeConverter.getInstance(), (Number)1.0) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.nodeTransformation == null || node.nodeTransformation.scaleZ == null || node.nodeTransformation.canSetScaleZ();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Number>)node.scaleZProperty();
                }
            };
            TRANSLATE_X = new CssMetaData<Node, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.nodeTransformation == null || node.nodeTransformation.translateX == null || node.nodeTransformation.canSetTranslateX();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Number>)node.translateXProperty();
                }
            };
            TRANSLATE_Y = new CssMetaData<Node, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.nodeTransformation == null || node.nodeTransformation.translateY == null || node.nodeTransformation.canSetTranslateY();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Number>)node.translateYProperty();
                }
            };
            TRANSLATE_Z = new CssMetaData<Node, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.nodeTransformation == null || node.nodeTransformation.translateZ == null || node.nodeTransformation.canSetTranslateZ();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Number>)node.translateZProperty();
                }
            };
            VIEW_ORDER = new CssMetaData<Node, Number>((StyleConverter)SizeConverter.getInstance(), (Number)0.0) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.miscProperties == null || node.miscProperties.viewOrder == null || !node.miscProperties.viewOrder.isBound();
                }
                
                @Override
                public StyleableProperty<Number> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Number>)node.viewOrderProperty();
                }
            };
            VISIBILITY = new CssMetaData<Node, Boolean>((StyleConverter)new StyleConverter<String, Boolean>() {
                @Override
                public Boolean convert(final ParsedValue<String, Boolean> parsedValue, final Font font) {
                    return "visible".equalsIgnoreCase((parsedValue != null) ? parsedValue.getValue() : null);
                }
            }, Boolean.TRUE) {
                @Override
                public boolean isSettable(final Node node) {
                    return node.visible == null || !node.visible.isBound();
                }
                
                @Override
                public StyleableProperty<Boolean> getStyleableProperty(final Node node) {
                    return (StyleableProperty<Boolean>)node.visibleProperty();
                }
            };
            final ArrayList<CssMetaData<Node, Cursor>> list = new ArrayList<CssMetaData<Node, Cursor>>();
            list.add(StyleableProperties.CURSOR);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.EFFECT);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.FOCUS_TRAVERSABLE);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.OPACITY);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.BLEND_MODE);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.ROTATE);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.SCALE_X);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.SCALE_Y);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.SCALE_Z);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.VIEW_ORDER);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.TRANSLATE_X);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.TRANSLATE_Y);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.TRANSLATE_Z);
            list.add((CssMetaData<Node, Cursor>)StyleableProperties.VISIBILITY);
            STYLEABLES = Collections.unmodifiableList((List<?>)list);
        }
    }
    
    private abstract static class LazyTransformProperty extends ReadOnlyObjectProperty<Transform>
    {
        protected static final int VALID = 0;
        protected static final int INVALID = 1;
        protected static final int VALIDITY_UNKNOWN = 2;
        protected int valid;
        private ExpressionHelper<Transform> helper;
        private Transform transform;
        private boolean canReuse;
        
        private LazyTransformProperty() {
            this.valid = 1;
            this.canReuse = false;
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, invalidationListener);
        }
        
        @Override
        public void addListener(final ChangeListener<? super Transform> changeListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, changeListener);
        }
        
        @Override
        public void removeListener(final ChangeListener<? super Transform> changeListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, changeListener);
        }
        
        protected Transform getInternalValue() {
            if (this.valid == 1 || (this.valid == 2 && this.computeValidity() == 1)) {
                this.transform = this.computeTransform(this.canReuse ? this.transform : null);
                this.canReuse = true;
                this.valid = (this.validityKnown() ? 0 : 2);
            }
            return this.transform;
        }
        
        @Override
        public Transform get() {
            this.transform = this.getInternalValue();
            this.canReuse = false;
            return this.transform;
        }
        
        public void validityUnknown() {
            if (this.valid == 0) {
                this.valid = 2;
            }
        }
        
        public void invalidate() {
            if (this.valid != 1) {
                this.valid = 1;
                ExpressionHelper.fireValueChangedEvent(this.helper);
            }
        }
        
        protected abstract boolean validityKnown();
        
        protected abstract int computeValidity();
        
        protected abstract Transform computeTransform(final Transform p0);
    }
    
    private abstract static class LazyBoundsProperty extends ReadOnlyObjectProperty<Bounds>
    {
        private ExpressionHelper<Bounds> helper;
        private boolean valid;
        private Bounds bounds;
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, invalidationListener);
        }
        
        @Override
        public void addListener(final ChangeListener<? super Bounds> changeListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, changeListener);
        }
        
        @Override
        public void removeListener(final ChangeListener<? super Bounds> changeListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, changeListener);
        }
        
        @Override
        public Bounds get() {
            if (!this.valid) {
                this.bounds = this.computeBounds();
                this.valid = true;
            }
            return this.bounds;
        }
        
        public void invalidate() {
            if (this.valid) {
                this.valid = false;
                ExpressionHelper.fireValueChangedEvent(this.helper);
            }
        }
        
        protected abstract Bounds computeBounds();
    }
    
    private class AccessibilityProperties
    {
        ObjectProperty<String> accessibleRoleDescription;
        ObjectProperty<String> accessibleText;
        ObjectProperty<String> accessibleHelp;
        
        ObjectProperty<String> getAccessibleRoleDescription() {
            if (this.accessibleRoleDescription == null) {
                this.accessibleRoleDescription = new SimpleObjectProperty<String>(Node.this, "accessibleRoleDescription", null);
            }
            return this.accessibleRoleDescription;
        }
        
        ObjectProperty<String> getAccessibleText() {
            if (this.accessibleText == null) {
                this.accessibleText = new SimpleObjectProperty<String>(Node.this, "accessibleText", null);
            }
            return this.accessibleText;
        }
        
        ObjectProperty<String> getAccessibleHelp() {
            if (this.accessibleHelp == null) {
                this.accessibleHelp = new SimpleObjectProperty<String>(Node.this, "accessibleHelp", null);
            }
            return this.accessibleHelp;
        }
    }
}
