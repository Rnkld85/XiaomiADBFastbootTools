// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import com.sun.javafx.sg.prism.NGPointLight;
import com.sun.javafx.sg.prism.NGNode;
import javafx.scene.paint.Color;
import com.sun.javafx.scene.PointLightHelper;

public class PointLight extends LightBase
{
    public PointLight() {
        PointLightHelper.initHelper(this);
    }
    
    public PointLight(final Color color) {
        super(color);
        PointLightHelper.initHelper(this);
    }
    
    private NGNode doCreatePeer() {
        return new NGPointLight();
    }
    
    static {
        PointLightHelper.setPointLightAccessor(new PointLightHelper.PointLightAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((PointLight)node).doCreatePeer();
            }
        });
    }
}
