// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

public enum CacheHint
{
    DEFAULT, 
    SPEED, 
    QUALITY, 
    SCALE, 
    ROTATE, 
    SCALE_AND_ROTATE;
}
