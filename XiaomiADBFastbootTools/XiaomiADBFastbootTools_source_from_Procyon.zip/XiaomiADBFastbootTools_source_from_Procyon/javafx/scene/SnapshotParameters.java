// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import com.sun.javafx.logging.PlatformLogger;
import javafx.application.Platform;
import javafx.application.ConditionalFeature;
import javafx.geometry.Rectangle2D;
import javafx.scene.paint.Paint;
import javafx.scene.transform.Transform;

public class SnapshotParameters
{
    private boolean depthBuffer;
    private Camera camera;
    private Transform transform;
    private Paint fill;
    private Rectangle2D viewport;
    Camera defaultCamera;
    
    public boolean isDepthBuffer() {
        return this.depthBuffer;
    }
    
    boolean isDepthBufferInternal() {
        return Platform.isSupported(ConditionalFeature.SCENE3D) && this.depthBuffer;
    }
    
    public void setDepthBuffer(final boolean depthBuffer) {
        if (depthBuffer && !Platform.isSupported(ConditionalFeature.SCENE3D)) {
            PlatformLogger.getLogger(SnapshotParameters.class.getName()).warning("System can't support ConditionalFeature.SCENE3D");
        }
        this.depthBuffer = depthBuffer;
    }
    
    public Camera getCamera() {
        return this.camera;
    }
    
    Camera getEffectiveCamera() {
        if (this.camera instanceof PerspectiveCamera && !Platform.isSupported(ConditionalFeature.SCENE3D)) {
            if (this.defaultCamera == null) {
                this.defaultCamera = new ParallelCamera();
            }
            return this.defaultCamera;
        }
        return this.camera;
    }
    
    public void setCamera(final Camera camera) {
        if (camera instanceof PerspectiveCamera && !Platform.isSupported(ConditionalFeature.SCENE3D)) {
            PlatformLogger.getLogger(SnapshotParameters.class.getName()).warning("System can't support ConditionalFeature.SCENE3D");
        }
        this.camera = camera;
    }
    
    public Transform getTransform() {
        return this.transform;
    }
    
    public void setTransform(final Transform transform) {
        this.transform = transform;
    }
    
    public Paint getFill() {
        return this.fill;
    }
    
    public void setFill(final Paint fill) {
        this.fill = fill;
    }
    
    public Rectangle2D getViewport() {
        return this.viewport;
    }
    
    public void setViewport(final Rectangle2D viewport) {
        this.viewport = viewport;
    }
    
    SnapshotParameters copy() {
        final SnapshotParameters snapshotParameters = new SnapshotParameters();
        snapshotParameters.camera = ((this.camera == null) ? null : this.camera.copy());
        snapshotParameters.depthBuffer = this.depthBuffer;
        snapshotParameters.fill = this.fill;
        snapshotParameters.viewport = this.viewport;
        snapshotParameters.transform = ((this.transform == null) ? null : this.transform.clone());
        return snapshotParameters;
    }
}
