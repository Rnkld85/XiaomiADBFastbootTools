// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import javafx.beans.Observable;
import com.sun.javafx.geom.BoxBounds;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.scene.transform.TransformHelper;
import javafx.scene.paint.Paint;
import com.sun.javafx.tk.Toolkit;
import com.sun.javafx.sg.prism.NGLightBase;
import java.util.Iterator;
import javafx.scene.shape.Shape3D;
import javafx.collections.ListChangeListener;
import com.sun.javafx.collections.TrackableObservableList;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import com.sun.javafx.scene.NodeHelper;
import com.sun.javafx.scene.DirtyBits;
import com.sun.javafx.logging.PlatformLogger;
import javafx.application.Platform;
import javafx.application.ConditionalFeature;
import com.sun.javafx.scene.LightBaseHelper;
import javafx.collections.ObservableList;
import javafx.beans.property.BooleanProperty;
import javafx.scene.paint.Color;
import javafx.beans.property.ObjectProperty;
import com.sun.javafx.geom.transform.Affine3D;

public abstract class LightBase extends Node
{
    private Affine3D localToSceneTx;
    private ObjectProperty<Color> color;
    private BooleanProperty lightOn;
    private ObservableList<Node> scope;
    
    protected LightBase() {
        this(Color.WHITE);
    }
    
    protected LightBase(final Color color) {
        this.localToSceneTx = new Affine3D();
        LightBaseHelper.initHelper(this);
        if (!Platform.isSupported(ConditionalFeature.SCENE3D)) {
            PlatformLogger.getLogger(LightBase.class.getName()).warning("System can't support ConditionalFeature.SCENE3D");
        }
        this.setColor(color);
        this.localToSceneTransformProperty().addListener(p0 -> NodeHelper.markDirty(this, DirtyBits.NODE_LIGHT_TRANSFORM));
    }
    
    public final void setColor(final Color color) {
        this.colorProperty().set(color);
    }
    
    public final Color getColor() {
        return (this.color == null) ? null : this.color.get();
    }
    
    public final ObjectProperty<Color> colorProperty() {
        if (this.color == null) {
            this.color = new SimpleObjectProperty<Color>(this, "color") {
                @Override
                protected void invalidated() {
                    NodeHelper.markDirty(LightBase.this, DirtyBits.NODE_LIGHT);
                }
            };
        }
        return this.color;
    }
    
    public final void setLightOn(final boolean b) {
        this.lightOnProperty().set(b);
    }
    
    public final boolean isLightOn() {
        return this.lightOn == null || this.lightOn.get();
    }
    
    public final BooleanProperty lightOnProperty() {
        if (this.lightOn == null) {
            this.lightOn = new SimpleBooleanProperty(this, "lightOn", true) {
                @Override
                protected void invalidated() {
                    NodeHelper.markDirty(LightBase.this, DirtyBits.NODE_LIGHT);
                }
            };
        }
        return this.lightOn;
    }
    
    public ObservableList<Node> getScope() {
        if (this.scope == null) {
            this.scope = new TrackableObservableList<Node>() {
                @Override
                protected void onChanged(final ListChangeListener.Change<Node> change) {
                    NodeHelper.markDirty(LightBase.this, DirtyBits.NODE_LIGHT_SCOPE);
                    while (change.next()) {
                        for (final Node node : change.getRemoved()) {
                            if (node instanceof Parent || node instanceof Shape3D) {
                                LightBase.this.markChildrenDirty(node);
                            }
                        }
                        for (final Node node2 : change.getAddedSubList()) {
                            if (node2 instanceof Parent || node2 instanceof Shape3D) {
                                LightBase.this.markChildrenDirty(node2);
                            }
                        }
                    }
                }
            };
        }
        return this.scope;
    }
    
    @Override
    void scenesChanged(final Scene scene, final SubScene subScene, final Scene scene2, final SubScene subScene2) {
        if (subScene2 != null) {
            subScene2.removeLight(this);
        }
        else if (scene2 != null) {
            scene2.removeLight(this);
        }
        if (subScene != null) {
            subScene.addLight(this);
        }
        else if (scene != null) {
            scene.addLight(this);
        }
    }
    
    private void markOwnerDirty() {
        final SubScene subScene = this.getSubScene();
        if (subScene != null) {
            subScene.markContentDirty();
        }
        else {
            final Scene scene = this.getScene();
            if (scene != null) {
                scene.setNeedsRepaint();
            }
        }
    }
    
    private void markChildrenDirty(final Node node) {
        if (node instanceof Shape3D) {
            NodeHelper.markDirty(node, DirtyBits.NODE_DRAWMODE);
        }
        else if (node instanceof Parent) {
            final Iterator<Node> iterator = ((Parent)node).getChildren().iterator();
            while (iterator.hasNext()) {
                this.markChildrenDirty(iterator.next());
            }
        }
    }
    
    private void doMarkDirty(final DirtyBits dirtyBits) {
        if (this.scope == null || this.getScope().isEmpty()) {
            this.markOwnerDirty();
        }
        else if (dirtyBits != DirtyBits.NODE_LIGHT_SCOPE) {
            final ObservableList<Node> scope = this.getScope();
            for (int i = 0; i < scope.size(); ++i) {
                this.markChildrenDirty((Node)scope.get(i));
            }
        }
    }
    
    private void doUpdatePeer() {
        final NGLightBase ngLightBase = this.getPeer();
        if (this.isDirty(DirtyBits.NODE_LIGHT)) {
            ngLightBase.setColor((this.getColor() == null) ? Toolkit.getPaintAccessor().getPlatformPaint(Color.WHITE) : Toolkit.getPaintAccessor().getPlatformPaint(this.getColor()));
            ngLightBase.setLightOn(this.isLightOn());
        }
        if (this.isDirty(DirtyBits.NODE_LIGHT_SCOPE) && this.scope != null) {
            final ObservableList<Node> scope = this.getScope();
            if (scope.isEmpty()) {
                ngLightBase.setScope(null);
            }
            else {
                final Object[] scope2 = new Object[scope.size()];
                for (int i = 0; i < scope.size(); ++i) {
                    scope2[i] = ((Node)scope.get(i)).getPeer();
                }
                ngLightBase.setScope(scope2);
            }
        }
        if (this.isDirty(DirtyBits.NODE_LIGHT_TRANSFORM)) {
            this.localToSceneTx.setToIdentity();
            TransformHelper.apply(this.getLocalToSceneTransform(), this.localToSceneTx);
            ngLightBase.setWorldTransform(this.localToSceneTx);
        }
    }
    
    private BaseBounds doComputeGeomBounds(final BaseBounds baseBounds, final BaseTransform baseTransform) {
        return new BoxBounds();
    }
    
    private boolean doComputeContains(final double n, final double n2) {
        return false;
    }
    
    static {
        LightBaseHelper.setLightBaseAccessor(new LightBaseHelper.LightBaseAccessor() {
            @Override
            public void doMarkDirty(final Node node, final DirtyBits dirtyBits) {
                ((LightBase)node).doMarkDirty(dirtyBits);
            }
            
            @Override
            public void doUpdatePeer(final Node node) {
                ((LightBase)node).doUpdatePeer();
            }
            
            @Override
            public BaseBounds doComputeGeomBounds(final Node node, final BaseBounds baseBounds, final BaseTransform baseTransform) {
                return ((LightBase)node).doComputeGeomBounds(baseBounds, baseTransform);
            }
            
            @Override
            public boolean doComputeContains(final Node node, final double n, final double n2) {
                return ((LightBase)node).doComputeContains(n, n2);
            }
        });
    }
}
