// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import com.sun.javafx.sg.prism.NGAmbientLight;
import com.sun.javafx.sg.prism.NGNode;
import javafx.scene.paint.Color;
import com.sun.javafx.scene.AmbientLightHelper;

public class AmbientLight extends LightBase
{
    public AmbientLight() {
        AmbientLightHelper.initHelper(this);
    }
    
    public AmbientLight(final Color color) {
        super(color);
        AmbientLightHelper.initHelper(this);
    }
    
    private NGNode doCreatePeer() {
        return new NGAmbientLight();
    }
    
    static {
        AmbientLightHelper.setAmbientLightAccessor(new AmbientLightHelper.AmbientLightAccessor() {
            @Override
            public NGNode doCreatePeer(final Node node) {
                return ((AmbientLight)node).doCreatePeer();
            }
        });
    }
}
