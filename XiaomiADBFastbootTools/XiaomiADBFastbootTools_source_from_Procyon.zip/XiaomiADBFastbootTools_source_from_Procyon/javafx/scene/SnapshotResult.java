// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import javafx.scene.image.WritableImage;

public class SnapshotResult
{
    private WritableImage image;
    private Object source;
    private SnapshotParameters params;
    
    SnapshotResult(final WritableImage image, final Object source, final SnapshotParameters params) {
        this.image = image;
        this.source = source;
        this.params = params;
    }
    
    public WritableImage getImage() {
        return this.image;
    }
    
    public Object getSource() {
        return this.source;
    }
    
    public SnapshotParameters getSnapshotParameters() {
        return this.params;
    }
}
