// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.transform;

import javafx.beans.NamedArg;

public class NonInvertibleTransformException extends Exception
{
    public NonInvertibleTransformException(@NamedArg("message") final String message) {
        super(message);
    }
}
