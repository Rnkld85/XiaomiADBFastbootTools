// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.transform;

import javafx.event.EventTarget;
import javafx.event.EventType;
import javafx.event.Event;

public final class TransformChangedEvent extends Event
{
    private static final long serialVersionUID = 20121107L;
    public static final EventType<TransformChangedEvent> TRANSFORM_CHANGED;
    public static final EventType<TransformChangedEvent> ANY;
    
    public TransformChangedEvent() {
        super(TransformChangedEvent.TRANSFORM_CHANGED);
    }
    
    public TransformChangedEvent(final Object o, final EventTarget eventTarget) {
        super(o, eventTarget, TransformChangedEvent.TRANSFORM_CHANGED);
    }
    
    static {
        TRANSFORM_CHANGED = new EventType<TransformChangedEvent>(Event.ANY, "TRANSFORM_CHANGED");
        ANY = TransformChangedEvent.TRANSFORM_CHANGED;
    }
}
