// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.transform;

import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.transform.Affine3D;
import javafx.geometry.Point2D;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Point3D;

public class Rotate extends Transform
{
    public static final Point3D X_AXIS;
    public static final Point3D Y_AXIS;
    public static final Point3D Z_AXIS;
    private MatrixCache cache;
    private MatrixCache inverseCache;
    private DoubleProperty angle;
    private DoubleProperty pivotX;
    private DoubleProperty pivotY;
    private DoubleProperty pivotZ;
    private ObjectProperty<Point3D> axis;
    
    public Rotate() {
    }
    
    public Rotate(final double angle) {
        this.setAngle(angle);
    }
    
    public Rotate(final double angle, final Point3D axis) {
        this.setAngle(angle);
        this.setAxis(axis);
    }
    
    public Rotate(final double angle, final double pivotX, final double pivotY) {
        this.setAngle(angle);
        this.setPivotX(pivotX);
        this.setPivotY(pivotY);
    }
    
    public Rotate(final double n, final double n2, final double n3, final double pivotZ) {
        this(n, n2, n3);
        this.setPivotZ(pivotZ);
    }
    
    public Rotate(final double n, final double n2, final double n3, final double pivotZ, final Point3D axis) {
        this(n, n2, n3);
        this.setPivotZ(pivotZ);
        this.setAxis(axis);
    }
    
    public final void setAngle(final double n) {
        this.angleProperty().set(n);
    }
    
    public final double getAngle() {
        return (this.angle == null) ? 0.0 : this.angle.get();
    }
    
    public final DoubleProperty angleProperty() {
        if (this.angle == null) {
            this.angle = new DoublePropertyBase() {
                public void invalidated() {
                    Rotate.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Rotate.this;
                }
                
                @Override
                public String getName() {
                    return "angle";
                }
            };
        }
        return this.angle;
    }
    
    public final void setPivotX(final double n) {
        this.pivotXProperty().set(n);
    }
    
    public final double getPivotX() {
        return (this.pivotX == null) ? 0.0 : this.pivotX.get();
    }
    
    public final DoubleProperty pivotXProperty() {
        if (this.pivotX == null) {
            this.pivotX = new DoublePropertyBase() {
                public void invalidated() {
                    Rotate.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Rotate.this;
                }
                
                @Override
                public String getName() {
                    return "pivotX";
                }
            };
        }
        return this.pivotX;
    }
    
    public final void setPivotY(final double n) {
        this.pivotYProperty().set(n);
    }
    
    public final double getPivotY() {
        return (this.pivotY == null) ? 0.0 : this.pivotY.get();
    }
    
    public final DoubleProperty pivotYProperty() {
        if (this.pivotY == null) {
            this.pivotY = new DoublePropertyBase() {
                public void invalidated() {
                    Rotate.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Rotate.this;
                }
                
                @Override
                public String getName() {
                    return "pivotY";
                }
            };
        }
        return this.pivotY;
    }
    
    public final void setPivotZ(final double n) {
        this.pivotZProperty().set(n);
    }
    
    public final double getPivotZ() {
        return (this.pivotZ == null) ? 0.0 : this.pivotZ.get();
    }
    
    public final DoubleProperty pivotZProperty() {
        if (this.pivotZ == null) {
            this.pivotZ = new DoublePropertyBase() {
                public void invalidated() {
                    Rotate.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Rotate.this;
                }
                
                @Override
                public String getName() {
                    return "pivotZ";
                }
            };
        }
        return this.pivotZ;
    }
    
    public final void setAxis(final Point3D point3D) {
        this.axisProperty().set(point3D);
    }
    
    public final Point3D getAxis() {
        return (this.axis == null) ? Rotate.Z_AXIS : this.axis.get();
    }
    
    public final ObjectProperty<Point3D> axisProperty() {
        if (this.axis == null) {
            this.axis = new ObjectPropertyBase<Point3D>(Rotate.Z_AXIS) {
                public void invalidated() {
                    Rotate.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Rotate.this;
                }
                
                @Override
                public String getName() {
                    return "axis";
                }
            };
        }
        return this.axis;
    }
    
    @Override
    public double getMxx() {
        this.updateCache();
        return this.cache.mxx;
    }
    
    @Override
    public double getMxy() {
        this.updateCache();
        return this.cache.mxy;
    }
    
    @Override
    public double getMxz() {
        this.updateCache();
        return this.cache.mxz;
    }
    
    @Override
    public double getTx() {
        this.updateCache();
        return this.cache.tx;
    }
    
    @Override
    public double getMyx() {
        this.updateCache();
        return this.cache.myx;
    }
    
    @Override
    public double getMyy() {
        this.updateCache();
        return this.cache.myy;
    }
    
    @Override
    public double getMyz() {
        this.updateCache();
        return this.cache.myz;
    }
    
    @Override
    public double getTy() {
        this.updateCache();
        return this.cache.ty;
    }
    
    @Override
    public double getMzx() {
        this.updateCache();
        return this.cache.mzx;
    }
    
    @Override
    public double getMzy() {
        this.updateCache();
        return this.cache.mzy;
    }
    
    @Override
    public double getMzz() {
        this.updateCache();
        return this.cache.mzz;
    }
    
    @Override
    public double getTz() {
        this.updateCache();
        return this.cache.tz;
    }
    
    @Override
    boolean computeIs2D() {
        final Point3D axis = this.getAxis();
        return (axis.getX() == 0.0 && axis.getY() == 0.0) || this.getAngle() == 0.0;
    }
    
    @Override
    boolean computeIsIdentity() {
        if (this.getAngle() == 0.0) {
            return true;
        }
        final Point3D axis = this.getAxis();
        return axis.getX() == 0.0 && axis.getY() == 0.0 && axis.getZ() == 0.0;
    }
    
    @Override
    void fill2DArray(final double[] array) {
        this.updateCache();
        array[0] = this.cache.mxx;
        array[1] = this.cache.mxy;
        array[2] = this.cache.tx;
        array[3] = this.cache.myx;
        array[4] = this.cache.myy;
        array[5] = this.cache.ty;
    }
    
    @Override
    void fill3DArray(final double[] array) {
        this.updateCache();
        array[0] = this.cache.mxx;
        array[1] = this.cache.mxy;
        array[2] = this.cache.mxz;
        array[3] = this.cache.tx;
        array[4] = this.cache.myx;
        array[5] = this.cache.myy;
        array[6] = this.cache.myz;
        array[7] = this.cache.ty;
        array[8] = this.cache.mzx;
        array[9] = this.cache.mzy;
        array[10] = this.cache.mzz;
        array[11] = this.cache.tz;
    }
    
    @Override
    public Transform createConcatenation(final Transform transform) {
        if (transform instanceof Rotate) {
            final Rotate rotate = (Rotate)transform;
            final double pivotX = this.getPivotX();
            final double pivotY = this.getPivotY();
            final double pivotZ = this.getPivotZ();
            if ((rotate.getAxis() == this.getAxis() || rotate.getAxis().normalize().equals(this.getAxis().normalize())) && pivotX == rotate.getPivotX() && pivotY == rotate.getPivotY() && pivotZ == rotate.getPivotZ()) {
                return new Rotate(this.getAngle() + rotate.getAngle(), pivotX, pivotY, pivotZ, this.getAxis());
            }
        }
        if (transform instanceof Affine) {
            final Affine affine = (Affine)transform.clone();
            affine.prepend(this);
            return affine;
        }
        return super.createConcatenation(transform);
    }
    
    @Override
    public Transform createInverse() throws NonInvertibleTransformException {
        return new Rotate(-this.getAngle(), this.getPivotX(), this.getPivotY(), this.getPivotZ(), this.getAxis());
    }
    
    @Override
    public Rotate clone() {
        return new Rotate(this.getAngle(), this.getPivotX(), this.getPivotY(), this.getPivotZ(), this.getAxis());
    }
    
    @Override
    public Point2D transform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        this.updateCache();
        return new Point2D(this.cache.mxx * n + this.cache.mxy * n2 + this.cache.tx, this.cache.myx * n + this.cache.myy * n2 + this.cache.ty);
    }
    
    @Override
    public Point3D transform(final double n, final double n2, final double n3) {
        this.updateCache();
        return new Point3D(this.cache.mxx * n + this.cache.mxy * n2 + this.cache.mxz * n3 + this.cache.tx, this.cache.myx * n + this.cache.myy * n2 + this.cache.myz * n3 + this.cache.ty, this.cache.mzx * n + this.cache.mzy * n2 + this.cache.mzz * n3 + this.cache.tz);
    }
    
    @Override
    void transform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        this.updateCache();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            array2[n2++] = this.cache.mxx * n4 + this.cache.mxy * n5 + this.cache.tx;
            array2[n2++] = this.cache.myx * n4 + this.cache.myy * n5 + this.cache.ty;
        }
    }
    
    @Override
    void transform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        this.updateCache();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            final double n6 = array[n++];
            array2[n2++] = this.cache.mxx * n4 + this.cache.mxy * n5 + this.cache.mxz * n6 + this.cache.tx;
            array2[n2++] = this.cache.myx * n4 + this.cache.myy * n5 + this.cache.myz * n6 + this.cache.ty;
            array2[n2++] = this.cache.mzx * n4 + this.cache.mzy * n5 + this.cache.mzz * n6 + this.cache.tz;
        }
    }
    
    @Override
    public Point2D deltaTransform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        this.updateCache();
        return new Point2D(this.cache.mxx * n + this.cache.mxy * n2, this.cache.myx * n + this.cache.myy * n2);
    }
    
    @Override
    public Point3D deltaTransform(final double n, final double n2, final double n3) {
        this.updateCache();
        return new Point3D(this.cache.mxx * n + this.cache.mxy * n2 + this.cache.mxz * n3, this.cache.myx * n + this.cache.myy * n2 + this.cache.myz * n3, this.cache.mzx * n + this.cache.mzy * n2 + this.cache.mzz * n3);
    }
    
    @Override
    public Point2D inverseTransform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        this.updateInverseCache();
        return new Point2D(this.inverseCache.mxx * n + this.inverseCache.mxy * n2 + this.inverseCache.tx, this.inverseCache.myx * n + this.inverseCache.myy * n2 + this.inverseCache.ty);
    }
    
    @Override
    public Point3D inverseTransform(final double n, final double n2, final double n3) {
        this.updateInverseCache();
        return new Point3D(this.inverseCache.mxx * n + this.inverseCache.mxy * n2 + this.inverseCache.mxz * n3 + this.inverseCache.tx, this.inverseCache.myx * n + this.inverseCache.myy * n2 + this.inverseCache.myz * n3 + this.inverseCache.ty, this.inverseCache.mzx * n + this.inverseCache.mzy * n2 + this.inverseCache.mzz * n3 + this.inverseCache.tz);
    }
    
    @Override
    void inverseTransform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        this.updateInverseCache();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            array2[n2++] = this.inverseCache.mxx * n4 + this.inverseCache.mxy * n5 + this.inverseCache.tx;
            array2[n2++] = this.inverseCache.myx * n4 + this.inverseCache.myy * n5 + this.inverseCache.ty;
        }
    }
    
    @Override
    void inverseTransform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        this.updateInverseCache();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            final double n6 = array[n++];
            array2[n2++] = this.inverseCache.mxx * n4 + this.inverseCache.mxy * n5 + this.inverseCache.mxz * n6 + this.inverseCache.tx;
            array2[n2++] = this.inverseCache.myx * n4 + this.inverseCache.myy * n5 + this.inverseCache.myz * n6 + this.inverseCache.ty;
            array2[n2++] = this.inverseCache.mzx * n4 + this.inverseCache.mzy * n5 + this.inverseCache.mzz * n6 + this.inverseCache.tz;
        }
    }
    
    @Override
    public Point2D inverseDeltaTransform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        this.updateInverseCache();
        return new Point2D(this.inverseCache.mxx * n + this.inverseCache.mxy * n2, this.inverseCache.myx * n + this.inverseCache.myy * n2);
    }
    
    @Override
    public Point3D inverseDeltaTransform(final double n, final double n2, final double n3) {
        this.updateInverseCache();
        return new Point3D(this.inverseCache.mxx * n + this.inverseCache.mxy * n2 + this.inverseCache.mxz * n3, this.inverseCache.myx * n + this.inverseCache.myy * n2 + this.inverseCache.myz * n3, this.inverseCache.mzx * n + this.inverseCache.mzy * n2 + this.inverseCache.mzz * n3);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Rotate [");
        sb.append("angle=").append(this.getAngle());
        sb.append(", pivotX=").append(this.getPivotX());
        sb.append(", pivotY=").append(this.getPivotY());
        sb.append(", pivotZ=").append(this.getPivotZ());
        sb.append(", axis=").append(this.getAxis());
        return sb.append("]").toString();
    }
    
    @Override
    void apply(final Affine3D affine3D) {
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        final double pivotZ = this.getPivotZ();
        final double angle = this.getAngle();
        if (pivotX != 0.0 || pivotY != 0.0 || pivotZ != 0.0) {
            affine3D.translate(pivotX, pivotY, pivotZ);
            affine3D.rotate(Math.toRadians(angle), this.getAxis().getX(), this.getAxis().getY(), this.getAxis().getZ());
            affine3D.translate(-pivotX, -pivotY, -pivotZ);
        }
        else {
            affine3D.rotate(Math.toRadians(angle), this.getAxis().getX(), this.getAxis().getY(), this.getAxis().getZ());
        }
    }
    
    @Override
    BaseTransform derive(BaseTransform baseTransform) {
        if (this.isIdentity()) {
            return baseTransform;
        }
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        final double pivotZ = this.getPivotZ();
        final double angle = this.getAngle();
        if (pivotX != 0.0 || pivotY != 0.0 || pivotZ != 0.0) {
            baseTransform = baseTransform.deriveWithTranslation(pivotX, pivotY, pivotZ);
            baseTransform = baseTransform.deriveWithRotation(Math.toRadians(angle), this.getAxis().getX(), this.getAxis().getY(), this.getAxis().getZ());
            return baseTransform.deriveWithTranslation(-pivotX, -pivotY, -pivotZ);
        }
        return baseTransform.deriveWithRotation(Math.toRadians(angle), this.getAxis().getX(), this.getAxis().getY(), this.getAxis().getZ());
    }
    
    @Override
    void validate() {
        this.getAxis();
        this.getAngle();
        this.getPivotX();
        this.getPivotY();
        this.getPivotZ();
    }
    
    @Override
    protected void transformChanged() {
        if (this.cache != null) {
            this.cache.invalidate();
        }
        super.transformChanged();
    }
    
    @Override
    void appendTo(final Affine affine) {
        affine.appendRotation(this.getAngle(), this.getPivotX(), this.getPivotY(), this.getPivotZ(), this.getAxis());
    }
    
    @Override
    void prependTo(final Affine affine) {
        affine.prependRotation(this.getAngle(), this.getPivotX(), this.getPivotY(), this.getPivotZ(), this.getAxis());
    }
    
    private void updateCache() {
        if (this.cache == null) {
            this.cache = new MatrixCache();
        }
        if (!this.cache.valid) {
            this.cache.update(this.getAngle(), this.getAxis(), this.getPivotX(), this.getPivotY(), this.getPivotZ());
        }
    }
    
    private void updateInverseCache() {
        if (this.inverseCache == null) {
            this.inverseCache = new MatrixCache();
        }
        if (!this.inverseCache.valid) {
            this.inverseCache.update(-this.getAngle(), this.getAxis(), this.getPivotX(), this.getPivotY(), this.getPivotZ());
        }
    }
    
    static {
        X_AXIS = new Point3D(1.0, 0.0, 0.0);
        Y_AXIS = new Point3D(0.0, 1.0, 0.0);
        Z_AXIS = new Point3D(0.0, 0.0, 1.0);
    }
    
    private static class MatrixCache
    {
        boolean valid;
        boolean is3D;
        double mxx;
        double mxy;
        double mxz;
        double tx;
        double myx;
        double myy;
        double myz;
        double ty;
        double mzx;
        double mzy;
        double mzz;
        double tz;
        
        public MatrixCache() {
            this.valid = false;
            this.is3D = false;
            this.mzz = 1.0;
        }
        
        public void update(final double angdeg, final Point3D point3D, final double n, final double n2, final double n3) {
            final double radians = Math.toRadians(angdeg);
            final double sin = Math.sin(radians);
            final double cos = Math.cos(radians);
            if (point3D == Rotate.Z_AXIS || (point3D.getX() == 0.0 && point3D.getY() == 0.0 && point3D.getZ() > 0.0)) {
                this.mxx = cos;
                this.mxy = -sin;
                this.tx = n * (1.0 - cos) + n2 * sin;
                this.myx = sin;
                this.myy = cos;
                this.ty = n2 * (1.0 - cos) - n * sin;
                if (this.is3D) {
                    this.mxz = 0.0;
                    this.myz = 0.0;
                    this.mzx = 0.0;
                    this.mzy = 0.0;
                    this.mzz = 1.0;
                    this.tz = 0.0;
                    this.is3D = false;
                }
                this.valid = true;
                return;
            }
            this.is3D = true;
            double x;
            double y;
            double z;
            if (point3D == Rotate.X_AXIS || point3D == Rotate.Y_AXIS || point3D == Rotate.Z_AXIS) {
                x = point3D.getX();
                y = point3D.getY();
                z = point3D.getZ();
            }
            else {
                final double sqrt = Math.sqrt(point3D.getX() * point3D.getX() + point3D.getY() * point3D.getY() + point3D.getZ() * point3D.getZ());
                if (sqrt == 0.0) {
                    this.mxx = 1.0;
                    this.mxy = 0.0;
                    this.mxz = 0.0;
                    this.tx = 0.0;
                    this.myx = 0.0;
                    this.myy = 1.0;
                    this.myz = 0.0;
                    this.ty = 0.0;
                    this.mzx = 0.0;
                    this.mzy = 0.0;
                    this.mzz = 1.0;
                    this.tz = 0.0;
                    this.valid = true;
                    return;
                }
                x = point3D.getX() / sqrt;
                y = point3D.getY() / sqrt;
                z = point3D.getZ() / sqrt;
            }
            this.mxx = cos + x * x * (1.0 - cos);
            this.mxy = x * y * (1.0 - cos) - z * sin;
            this.mxz = x * z * (1.0 - cos) + y * sin;
            this.tx = n * (1.0 - this.mxx) - n2 * this.mxy - n3 * this.mxz;
            this.myx = y * x * (1.0 - cos) + z * sin;
            this.myy = cos + y * y * (1.0 - cos);
            this.myz = y * z * (1.0 - cos) - x * sin;
            this.ty = n2 * (1.0 - this.myy) - n * this.myx - n3 * this.myz;
            this.mzx = z * x * (1.0 - cos) - y * sin;
            this.mzy = z * y * (1.0 - cos) + x * sin;
            this.mzz = cos + z * z * (1.0 - cos);
            this.tz = n3 * (1.0 - this.mzz) - n * this.mzx - n2 * this.mzy;
            this.valid = true;
        }
        
        public void invalidate() {
            this.valid = false;
        }
    }
}
