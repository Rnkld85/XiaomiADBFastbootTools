// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.transform;

import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.transform.Affine3D;
import javafx.geometry.Point3D;
import javafx.geometry.Point2D;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;

public class Shear extends Transform
{
    private DoubleProperty x;
    private DoubleProperty y;
    private DoubleProperty pivotX;
    private DoubleProperty pivotY;
    
    public Shear() {
    }
    
    public Shear(final double x, final double y) {
        this.setX(x);
        this.setY(y);
    }
    
    public Shear(final double x, final double y, final double pivotX, final double pivotY) {
        this.setX(x);
        this.setY(y);
        this.setPivotX(pivotX);
        this.setPivotY(pivotY);
    }
    
    public final void setX(final double n) {
        this.xProperty().set(n);
    }
    
    public final double getX() {
        return (this.x == null) ? 0.0 : this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        if (this.x == null) {
            this.x = new DoublePropertyBase() {
                public void invalidated() {
                    Shear.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Shear.this;
                }
                
                @Override
                public String getName() {
                    return "x";
                }
            };
        }
        return this.x;
    }
    
    public final void setY(final double n) {
        this.yProperty().set(n);
    }
    
    public final double getY() {
        return (this.y == null) ? 0.0 : this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        if (this.y == null) {
            this.y = new DoublePropertyBase() {
                public void invalidated() {
                    Shear.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Shear.this;
                }
                
                @Override
                public String getName() {
                    return "y";
                }
            };
        }
        return this.y;
    }
    
    public final void setPivotX(final double n) {
        this.pivotXProperty().set(n);
    }
    
    public final double getPivotX() {
        return (this.pivotX == null) ? 0.0 : this.pivotX.get();
    }
    
    public final DoubleProperty pivotXProperty() {
        if (this.pivotX == null) {
            this.pivotX = new DoublePropertyBase() {
                public void invalidated() {
                    Shear.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Shear.this;
                }
                
                @Override
                public String getName() {
                    return "pivotX";
                }
            };
        }
        return this.pivotX;
    }
    
    public final void setPivotY(final double n) {
        this.pivotYProperty().set(n);
    }
    
    public final double getPivotY() {
        return (this.pivotY == null) ? 0.0 : this.pivotY.get();
    }
    
    public final DoubleProperty pivotYProperty() {
        if (this.pivotY == null) {
            this.pivotY = new DoublePropertyBase() {
                public void invalidated() {
                    Shear.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Shear.this;
                }
                
                @Override
                public String getName() {
                    return "pivotY";
                }
            };
        }
        return this.pivotY;
    }
    
    @Override
    public double getMxy() {
        return this.getX();
    }
    
    @Override
    public double getMyx() {
        return this.getY();
    }
    
    @Override
    public double getTx() {
        return -this.getX() * this.getPivotY();
    }
    
    @Override
    public double getTy() {
        return -this.getY() * this.getPivotX();
    }
    
    @Override
    boolean computeIs2D() {
        return true;
    }
    
    @Override
    boolean computeIsIdentity() {
        return this.getX() == 0.0 && this.getY() == 0.0;
    }
    
    @Override
    void fill2DArray(final double[] array) {
        final double x = this.getX();
        final double y = this.getY();
        array[0] = 1.0;
        array[1] = x;
        array[2] = -x * this.getPivotY();
        array[3] = y;
        array[4] = 1.0;
        array[5] = -y * this.getPivotX();
    }
    
    @Override
    void fill3DArray(final double[] array) {
        final double x = this.getX();
        final double y = this.getY();
        array[0] = 1.0;
        array[1] = x;
        array[2] = 0.0;
        array[3] = -x * this.getPivotY();
        array[4] = y;
        array[5] = 1.0;
        array[6] = 0.0;
        array[7] = -y * this.getPivotX();
        array[9] = (array[8] = 0.0);
        array[10] = 1.0;
        array[11] = 0.0;
    }
    
    @Override
    public Transform createConcatenation(final Transform transform) {
        if (transform instanceof Affine) {
            final Affine affine = (Affine)transform.clone();
            affine.prepend(this);
            return affine;
        }
        final double x = this.getX();
        final double y = this.getY();
        final double mxx = transform.getMxx();
        final double mxy = transform.getMxy();
        final double mxz = transform.getMxz();
        final double tx = transform.getTx();
        final double myx = transform.getMyx();
        final double myy = transform.getMyy();
        final double myz = transform.getMyz();
        final double ty = transform.getTy();
        return new Affine(mxx + x * myx, mxy + x * myy, mxz + x * myz, tx + x * ty - x * this.getPivotY(), y * mxx + myx, y * mxy + myy, y * mxz + myz, y * tx + ty - y * this.getPivotX(), transform.getMzx(), transform.getMzy(), transform.getMzz(), transform.getTz());
    }
    
    @Override
    public Transform createInverse() {
        final double x = this.getX();
        final double y = this.getY();
        if (y == 0.0) {
            return new Shear(-x, 0.0, 0.0, this.getPivotY());
        }
        if (x == 0.0) {
            return new Shear(0.0, -y, this.getPivotX(), 0.0);
        }
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        final double n = 1.0 / (1.0 - x * y);
        return new Affine(n, -x * n, 0.0, x * (pivotY - y * pivotX) * n, -y * n, 1.0 + x * y * n, 0.0, y * pivotX + y * (x * y * pivotX - x * pivotY) * n, 0.0, 0.0, 1.0, 0.0);
    }
    
    @Override
    public Shear clone() {
        return new Shear(this.getX(), this.getY(), this.getPivotX(), this.getPivotY());
    }
    
    @Override
    public Point2D transform(final double n, final double n2) {
        final double x = this.getX();
        final double y = this.getY();
        return new Point2D(n + x * n2 - x * this.getPivotY(), y * n + n2 - y * this.getPivotX());
    }
    
    @Override
    public Point3D transform(final double n, final double n2, final double n3) {
        final double x = this.getX();
        final double y = this.getY();
        return new Point3D(n + x * n2 - x * this.getPivotY(), y * n + n2 - y * this.getPivotX(), n3);
    }
    
    @Override
    void transform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double x = this.getX();
        final double y = this.getY();
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            array2[n2++] = n4 + x * n5 - x * pivotY;
            array2[n2++] = y * n4 + n5 - y * pivotX;
        }
    }
    
    @Override
    void transform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double x = this.getX();
        final double y = this.getY();
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            array2[n2++] = n4 + x * n5 - x * pivotY;
            array2[n2++] = y * n4 + n5 - y * pivotX;
            array2[n2++] = array[n++];
        }
    }
    
    @Override
    public Point2D deltaTransform(final double n, final double n2) {
        return new Point2D(n + this.getX() * n2, this.getY() * n + n2);
    }
    
    @Override
    public Point3D deltaTransform(final double n, final double n2, final double n3) {
        return new Point3D(n + this.getX() * n2, this.getY() * n + n2, n3);
    }
    
    @Override
    public Point2D inverseTransform(final double n, final double n2) throws NonInvertibleTransformException {
        final double x = this.getX();
        if (this.getY() == 0.0) {
            final double n3 = -this.getX();
            return new Point2D(n + n3 * n2 - n3 * this.getPivotY(), n2);
        }
        if (x == 0.0) {
            final double n4 = -this.getY();
            return new Point2D(n, n4 * n + n2 - n4 * this.getPivotX());
        }
        return super.inverseTransform(n, n2);
    }
    
    @Override
    public Point3D inverseTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
        final double x = this.getX();
        if (this.getY() == 0.0) {
            final double n4 = -this.getX();
            return new Point3D(n + n4 * n2 - n4 * this.getPivotY(), n2, n3);
        }
        if (x == 0.0) {
            final double n5 = -this.getY();
            return new Point3D(n, n5 * n + n2 - n5 * this.getPivotX(), n3);
        }
        return super.inverseTransform(n, n2, n3);
    }
    
    @Override
    void inverseTransform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) throws NonInvertibleTransformException {
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        final double x = this.getX();
        final double y = this.getY();
        if (y == 0.0) {
            final double n4 = -x;
            while (--n3 >= 0) {
                final double n5 = array[n++];
                final double n6 = array[n++];
                array2[n2++] = n5 + n4 * n6 - n4 * pivotY;
                array2[n2++] = n6;
            }
            return;
        }
        if (x == 0.0) {
            final double n7 = -y;
            while (--n3 >= 0) {
                final double n8 = array[n++];
                final double n9 = array[n++];
                array2[n2++] = n8;
                array2[n2++] = n7 * n8 + n9 - n7 * pivotX;
            }
            return;
        }
        super.inverseTransform2DPointsImpl(array, n, array2, n2, n3);
    }
    
    @Override
    void inverseTransform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) throws NonInvertibleTransformException {
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        final double x = this.getX();
        final double y = this.getY();
        if (y == 0.0) {
            final double n4 = -x;
            while (--n3 >= 0) {
                final double n5 = array[n++];
                final double n6 = array[n++];
                array2[n2++] = n5 + n4 * n6 - n4 * pivotY;
                array2[n2++] = n6;
                array2[n2++] = array[n++];
            }
            return;
        }
        if (x == 0.0) {
            final double n7 = -y;
            while (--n3 >= 0) {
                final double n8 = array[n++];
                final double n9 = array[n++];
                array2[n2++] = n8;
                array2[n2++] = n7 * n8 + n9 - n7 * pivotX;
                array2[n2++] = array[n++];
            }
            return;
        }
        super.inverseTransform3DPointsImpl(array, n, array2, n2, n3);
    }
    
    @Override
    public Point2D inverseDeltaTransform(final double n, final double n2) throws NonInvertibleTransformException {
        final double x = this.getX();
        if (this.getY() == 0.0) {
            return new Point2D(n - this.getX() * n2, n2);
        }
        if (x == 0.0) {
            return new Point2D(n, -this.getY() * n + n2);
        }
        return super.inverseDeltaTransform(n, n2);
    }
    
    @Override
    public Point3D inverseDeltaTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
        final double x = this.getX();
        if (this.getY() == 0.0) {
            return new Point3D(n - this.getX() * n2, n2, n3);
        }
        if (x == 0.0) {
            return new Point3D(n, -this.getY() * n + n2, n3);
        }
        return super.inverseDeltaTransform(n, n2, n3);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Shear [");
        sb.append("x=").append(this.getX());
        sb.append(", y=").append(this.getY());
        sb.append(", pivotX=").append(this.getPivotX());
        sb.append(", pivotY=").append(this.getPivotY());
        return sb.append("]").toString();
    }
    
    @Override
    void apply(final Affine3D affine3D) {
        if (this.getPivotX() != 0.0 || this.getPivotY() != 0.0) {
            affine3D.translate(this.getPivotX(), this.getPivotY());
            affine3D.shear(this.getX(), this.getY());
            affine3D.translate(-this.getPivotX(), -this.getPivotY());
        }
        else {
            affine3D.shear(this.getX(), this.getY());
        }
    }
    
    @Override
    BaseTransform derive(final BaseTransform baseTransform) {
        return baseTransform.deriveWithConcatenation(1.0, this.getY(), this.getX(), 1.0, this.getTx(), this.getTy());
    }
    
    @Override
    void validate() {
        this.getX();
        this.getPivotX();
        this.getY();
        this.getPivotY();
    }
    
    @Override
    void appendTo(final Affine affine) {
        affine.appendShear(this.getX(), this.getY(), this.getPivotX(), this.getPivotY());
    }
    
    @Override
    void prependTo(final Affine affine) {
        affine.prependShear(this.getX(), this.getY(), this.getPivotX(), this.getPivotY());
    }
}
