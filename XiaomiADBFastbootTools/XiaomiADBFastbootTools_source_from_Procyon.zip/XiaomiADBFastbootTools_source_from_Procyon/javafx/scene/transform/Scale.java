// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.transform;

import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.transform.Affine3D;
import javafx.geometry.Point3D;
import javafx.geometry.Point2D;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;

public class Scale extends Transform
{
    private DoubleProperty x;
    private DoubleProperty y;
    private DoubleProperty z;
    private DoubleProperty pivotX;
    private DoubleProperty pivotY;
    private DoubleProperty pivotZ;
    
    public Scale() {
    }
    
    public Scale(final double x, final double y) {
        this.setX(x);
        this.setY(y);
    }
    
    public Scale(final double n, final double n2, final double pivotX, final double pivotY) {
        this(n, n2);
        this.setPivotX(pivotX);
        this.setPivotY(pivotY);
    }
    
    public Scale(final double n, final double n2, final double z) {
        this(n, n2);
        this.setZ(z);
    }
    
    public Scale(final double n, final double n2, final double z, final double n3, final double n4, final double pivotZ) {
        this(n, n2, n3, n4);
        this.setZ(z);
        this.setPivotZ(pivotZ);
    }
    
    public final void setX(final double n) {
        this.xProperty().set(n);
    }
    
    public final double getX() {
        return (this.x == null) ? 1.0 : this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        if (this.x == null) {
            this.x = new DoublePropertyBase(1.0) {
                public void invalidated() {
                    Scale.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Scale.this;
                }
                
                @Override
                public String getName() {
                    return "x";
                }
            };
        }
        return this.x;
    }
    
    public final void setY(final double n) {
        this.yProperty().set(n);
    }
    
    public final double getY() {
        return (this.y == null) ? 1.0 : this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        if (this.y == null) {
            this.y = new DoublePropertyBase(1.0) {
                public void invalidated() {
                    Scale.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Scale.this;
                }
                
                @Override
                public String getName() {
                    return "y";
                }
            };
        }
        return this.y;
    }
    
    public final void setZ(final double n) {
        this.zProperty().set(n);
    }
    
    public final double getZ() {
        return (this.z == null) ? 1.0 : this.z.get();
    }
    
    public final DoubleProperty zProperty() {
        if (this.z == null) {
            this.z = new DoublePropertyBase(1.0) {
                public void invalidated() {
                    Scale.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Scale.this;
                }
                
                @Override
                public String getName() {
                    return "z";
                }
            };
        }
        return this.z;
    }
    
    public final void setPivotX(final double n) {
        this.pivotXProperty().set(n);
    }
    
    public final double getPivotX() {
        return (this.pivotX == null) ? 0.0 : this.pivotX.get();
    }
    
    public final DoubleProperty pivotXProperty() {
        if (this.pivotX == null) {
            this.pivotX = new DoublePropertyBase() {
                public void invalidated() {
                    Scale.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Scale.this;
                }
                
                @Override
                public String getName() {
                    return "pivotX";
                }
            };
        }
        return this.pivotX;
    }
    
    public final void setPivotY(final double n) {
        this.pivotYProperty().set(n);
    }
    
    public final double getPivotY() {
        return (this.pivotY == null) ? 0.0 : this.pivotY.get();
    }
    
    public final DoubleProperty pivotYProperty() {
        if (this.pivotY == null) {
            this.pivotY = new DoublePropertyBase() {
                public void invalidated() {
                    Scale.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Scale.this;
                }
                
                @Override
                public String getName() {
                    return "pivotY";
                }
            };
        }
        return this.pivotY;
    }
    
    public final void setPivotZ(final double n) {
        this.pivotZProperty().set(n);
    }
    
    public final double getPivotZ() {
        return (this.pivotZ == null) ? 0.0 : this.pivotZ.get();
    }
    
    public final DoubleProperty pivotZProperty() {
        if (this.pivotZ == null) {
            this.pivotZ = new DoublePropertyBase() {
                public void invalidated() {
                    Scale.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Scale.this;
                }
                
                @Override
                public String getName() {
                    return "pivotZ";
                }
            };
        }
        return this.pivotZ;
    }
    
    @Override
    public double getMxx() {
        return this.getX();
    }
    
    @Override
    public double getMyy() {
        return this.getY();
    }
    
    @Override
    public double getMzz() {
        return this.getZ();
    }
    
    @Override
    public double getTx() {
        return (1.0 - this.getX()) * this.getPivotX();
    }
    
    @Override
    public double getTy() {
        return (1.0 - this.getY()) * this.getPivotY();
    }
    
    @Override
    public double getTz() {
        return (1.0 - this.getZ()) * this.getPivotZ();
    }
    
    @Override
    boolean computeIs2D() {
        return this.getZ() == 1.0;
    }
    
    @Override
    boolean computeIsIdentity() {
        return this.getX() == 1.0 && this.getY() == 1.0 && this.getZ() == 1.0;
    }
    
    @Override
    void fill2DArray(final double[] array) {
        final double x = this.getX();
        final double y = this.getY();
        array[0] = x;
        array[1] = 0.0;
        array[2] = (1.0 - x) * this.getPivotX();
        array[3] = 0.0;
        array[4] = y;
        array[5] = (1.0 - y) * this.getPivotY();
    }
    
    @Override
    void fill3DArray(final double[] array) {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        array[0] = x;
        array[2] = (array[1] = 0.0);
        array[3] = (1.0 - x) * this.getPivotX();
        array[4] = 0.0;
        array[5] = y;
        array[6] = 0.0;
        array[7] = (1.0 - y) * this.getPivotY();
        array[9] = (array[8] = 0.0);
        array[10] = z;
        array[11] = (1.0 - z) * this.getPivotZ();
    }
    
    @Override
    public Transform createConcatenation(final Transform transform) {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        if (transform instanceof Scale) {
            final Scale scale = (Scale)transform;
            if (scale.getPivotX() == this.getPivotX() && scale.getPivotY() == this.getPivotY() && scale.getPivotZ() == this.getPivotZ()) {
                return new Scale(x * scale.getX(), y * scale.getY(), z * scale.getZ(), this.getPivotX(), this.getPivotY(), this.getPivotZ());
            }
        }
        if (transform instanceof Translate) {
            final Translate translate = (Translate)transform;
            final double x2 = translate.getX();
            final double y2 = translate.getY();
            final double z2 = translate.getZ();
            if ((x2 == 0.0 || (x != 1.0 && x != 0.0)) && (y2 == 0.0 || (y != 1.0 && y != 0.0)) && (z2 == 0.0 || (z != 1.0 && z != 0.0))) {
                return new Scale(x, y, z, ((x != 1.0) ? (x * x2 / (1.0 - x)) : 0.0) + this.getPivotX(), ((y != 1.0) ? (y * y2 / (1.0 - y)) : 0.0) + this.getPivotY(), ((z != 1.0) ? (z * z2 / (1.0 - z)) : 0.0) + this.getPivotZ());
            }
        }
        if (transform instanceof Affine) {
            final Affine affine = (Affine)transform.clone();
            affine.prepend(this);
            return affine;
        }
        return new Affine(x * transform.getMxx(), x * transform.getMxy(), x * transform.getMxz(), x * transform.getTx() + (1.0 - x) * this.getPivotX(), y * transform.getMyx(), y * transform.getMyy(), y * transform.getMyz(), y * transform.getTy() + (1.0 - y) * this.getPivotY(), z * transform.getMzx(), z * transform.getMzy(), z * transform.getMzz(), z * transform.getTz() + (1.0 - z) * this.getPivotZ());
    }
    
    @Override
    public Scale createInverse() throws NonInvertibleTransformException {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        if (x == 0.0 || y == 0.0 || z == 0.0) {
            throw new NonInvertibleTransformException("Zero scale is not invertible");
        }
        return new Scale(1.0 / x, 1.0 / y, 1.0 / z, this.getPivotX(), this.getPivotY(), this.getPivotZ());
    }
    
    @Override
    public Scale clone() {
        return new Scale(this.getX(), this.getY(), this.getZ(), this.getPivotX(), this.getPivotY(), this.getPivotZ());
    }
    
    @Override
    public Point2D transform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        final double x = this.getX();
        final double y = this.getY();
        return new Point2D(x * n + (1.0 - x) * this.getPivotX(), y * n2 + (1.0 - y) * this.getPivotY());
    }
    
    @Override
    public Point3D transform(final double n, final double n2, final double n3) {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        return new Point3D(x * n + (1.0 - x) * this.getPivotX(), y * n2 + (1.0 - y) * this.getPivotY(), z * n3 + (1.0 - z) * this.getPivotZ());
    }
    
    @Override
    void transform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double x = this.getX();
        final double y = this.getY();
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            array2[n2++] = x * n4 + (1.0 - x) * pivotX;
            array2[n2++] = y * n5 + (1.0 - y) * pivotY;
        }
    }
    
    @Override
    void transform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        final double pivotZ = this.getPivotZ();
        while (--n3 >= 0) {
            array2[n2++] = x * array[n++] + (1.0 - x) * pivotX;
            array2[n2++] = y * array[n++] + (1.0 - y) * pivotY;
            array2[n2++] = z * array[n++] + (1.0 - z) * pivotZ;
        }
    }
    
    @Override
    public Point2D deltaTransform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        return new Point2D(this.getX() * n, this.getY() * n2);
    }
    
    @Override
    public Point3D deltaTransform(final double n, final double n2, final double n3) {
        return new Point3D(this.getX() * n, this.getY() * n2, this.getZ() * n3);
    }
    
    @Override
    public Point2D inverseTransform(final double n, final double n2) throws NonInvertibleTransformException {
        this.ensureCanTransform2DPoint();
        final double x = this.getX();
        final double y = this.getY();
        if (x == 0.0 || y == 0.0) {
            throw new NonInvertibleTransformException("Zero scale is not invertible");
        }
        final double n3 = 1.0 / x;
        final double n4 = 1.0 / y;
        return new Point2D(n3 * n + (1.0 - n3) * this.getPivotX(), n4 * n2 + (1.0 - n4) * this.getPivotY());
    }
    
    @Override
    public Point3D inverseTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        if (x == 0.0 || y == 0.0 || z == 0.0) {
            throw new NonInvertibleTransformException("Zero scale is not invertible");
        }
        final double n4 = 1.0 / x;
        final double n5 = 1.0 / y;
        final double n6 = 1.0 / z;
        return new Point3D(n4 * n + (1.0 - n4) * this.getPivotX(), n5 * n2 + (1.0 - n5) * this.getPivotY(), n6 * n3 + (1.0 - n6) * this.getPivotZ());
    }
    
    @Override
    void inverseTransform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) throws NonInvertibleTransformException {
        final double x = this.getX();
        final double y = this.getY();
        if (x == 0.0 || y == 0.0) {
            throw new NonInvertibleTransformException("Zero scale is not invertible");
        }
        final double n4 = 1.0 / x;
        final double n5 = 1.0 / y;
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        while (--n3 >= 0) {
            array2[n2++] = n4 * array[n++] + (1.0 - n4) * pivotX;
            array2[n2++] = n5 * array[n++] + (1.0 - n5) * pivotY;
        }
    }
    
    @Override
    void inverseTransform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) throws NonInvertibleTransformException {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        if (x == 0.0 || y == 0.0 || z == 0.0) {
            throw new NonInvertibleTransformException("Zero scale is not invertible");
        }
        final double n4 = 1.0 / x;
        final double n5 = 1.0 / y;
        final double n6 = 1.0 / z;
        final double pivotX = this.getPivotX();
        final double pivotY = this.getPivotY();
        final double pivotZ = this.getPivotZ();
        while (--n3 >= 0) {
            array2[n2++] = n4 * array[n++] + (1.0 - n4) * pivotX;
            array2[n2++] = n5 * array[n++] + (1.0 - n5) * pivotY;
            array2[n2++] = n6 * array[n++] + (1.0 - n6) * pivotZ;
        }
    }
    
    @Override
    public Point2D inverseDeltaTransform(final double n, final double n2) throws NonInvertibleTransformException {
        this.ensureCanTransform2DPoint();
        final double x = this.getX();
        final double y = this.getY();
        if (x == 0.0 || y == 0.0) {
            throw new NonInvertibleTransformException("Zero scale is not invertible");
        }
        return new Point2D(1.0 / x * n, 1.0 / y * n2);
    }
    
    @Override
    public Point3D inverseDeltaTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        if (x == 0.0 || y == 0.0 || z == 0.0) {
            throw new NonInvertibleTransformException("Zero scale is not invertible");
        }
        return new Point3D(1.0 / x * n, 1.0 / y * n2, 1.0 / z * n3);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Scale [");
        sb.append("x=").append(this.getX());
        sb.append(", y=").append(this.getY());
        sb.append(", z=").append(this.getZ());
        sb.append(", pivotX=").append(this.getPivotX());
        sb.append(", pivotY=").append(this.getPivotY());
        sb.append(", pivotZ=").append(this.getPivotZ());
        return sb.append("]").toString();
    }
    
    @Override
    void apply(final Affine3D affine3D) {
        if (this.getPivotX() != 0.0 || this.getPivotY() != 0.0 || this.getPivotZ() != 0.0) {
            affine3D.translate(this.getPivotX(), this.getPivotY(), this.getPivotZ());
            affine3D.scale(this.getX(), this.getY(), this.getZ());
            affine3D.translate(-this.getPivotX(), -this.getPivotY(), -this.getPivotZ());
        }
        else {
            affine3D.scale(this.getX(), this.getY(), this.getZ());
        }
    }
    
    @Override
    BaseTransform derive(BaseTransform baseTransform) {
        if (this.isIdentity()) {
            return baseTransform;
        }
        if (this.getPivotX() != 0.0 || this.getPivotY() != 0.0 || this.getPivotZ() != 0.0) {
            baseTransform = baseTransform.deriveWithTranslation(this.getPivotX(), this.getPivotY(), this.getPivotZ());
            baseTransform = baseTransform.deriveWithScale(this.getX(), this.getY(), this.getZ());
            return baseTransform.deriveWithTranslation(-this.getPivotX(), -this.getPivotY(), -this.getPivotZ());
        }
        return baseTransform.deriveWithScale(this.getX(), this.getY(), this.getZ());
    }
    
    @Override
    void validate() {
        this.getX();
        this.getPivotX();
        this.getY();
        this.getPivotY();
        this.getZ();
        this.getPivotZ();
    }
    
    @Override
    void appendTo(final Affine affine) {
        affine.appendScale(this.getX(), this.getY(), this.getZ(), this.getPivotX(), this.getPivotY(), this.getPivotZ());
    }
    
    @Override
    void prependTo(final Affine affine) {
        affine.prependScale(this.getX(), this.getY(), this.getZ(), this.getPivotX(), this.getPivotY(), this.getPivotZ());
    }
}
