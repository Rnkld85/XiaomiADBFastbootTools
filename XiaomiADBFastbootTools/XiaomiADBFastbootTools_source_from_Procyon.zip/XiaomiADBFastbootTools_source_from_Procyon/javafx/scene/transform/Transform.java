// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.transform;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.beans.InvalidationListener;
import com.sun.javafx.binding.ExpressionHelper;
import com.sun.javafx.scene.transform.TransformHelper;
import java.util.Iterator;
import com.sun.javafx.scene.NodeHelper;
import javafx.scene.Node;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.transform.Affine3D;
import javafx.beans.property.SimpleObjectProperty;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.event.EventDispatcher;
import javafx.event.EventDispatchChain;
import com.sun.javafx.geometry.BoundsUtils;
import javafx.geometry.Point3D;
import javafx.geometry.Point2D;
import com.sun.javafx.scene.transform.TransformUtils;
import javafx.geometry.Bounds;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.event.EventHandler;
import javafx.beans.property.ObjectProperty;
import com.sun.javafx.event.EventHandlerManager;
import com.sun.javafx.util.WeakReferenceQueue;
import java.lang.ref.SoftReference;
import javafx.event.EventTarget;

public abstract class Transform implements Cloneable, EventTarget
{
    private SoftReference<Transform> inverseCache;
    private WeakReferenceQueue nodes;
    private LazyBooleanProperty type2D;
    private LazyBooleanProperty identity;
    private EventHandlerManager internalEventDispatcher;
    private ObjectProperty<EventHandler<? super TransformChangedEvent>> onTransformChanged;
    
    public Transform() {
        this.inverseCache = null;
        this.nodes = new WeakReferenceQueue();
    }
    
    public static Affine affine(final double mxx, final double myx, final double mxy, final double myy, final double tx, final double ty) {
        final Affine affine = new Affine();
        affine.setMxx(mxx);
        affine.setMxy(mxy);
        affine.setTx(tx);
        affine.setMyx(myx);
        affine.setMyy(myy);
        affine.setTy(ty);
        return affine;
    }
    
    public static Affine affine(final double mxx, final double mxy, final double mxz, final double tx, final double myx, final double myy, final double myz, final double ty, final double mzx, final double mzy, final double mzz, final double tz) {
        final Affine affine = new Affine();
        affine.setMxx(mxx);
        affine.setMxy(mxy);
        affine.setMxz(mxz);
        affine.setTx(tx);
        affine.setMyx(myx);
        affine.setMyy(myy);
        affine.setMyz(myz);
        affine.setTy(ty);
        affine.setMzx(mzx);
        affine.setMzy(mzy);
        affine.setMzz(mzz);
        affine.setTz(tz);
        return affine;
    }
    
    public static Translate translate(final double x, final double y) {
        final Translate translate = new Translate();
        translate.setX(x);
        translate.setY(y);
        return translate;
    }
    
    public static Rotate rotate(final double angle, final double pivotX, final double pivotY) {
        final Rotate rotate = new Rotate();
        rotate.setAngle(angle);
        rotate.setPivotX(pivotX);
        rotate.setPivotY(pivotY);
        return rotate;
    }
    
    public static Scale scale(final double x, final double y) {
        final Scale scale = new Scale();
        scale.setX(x);
        scale.setY(y);
        return scale;
    }
    
    public static Scale scale(final double x, final double y, final double pivotX, final double pivotY) {
        final Scale scale = new Scale();
        scale.setX(x);
        scale.setY(y);
        scale.setPivotX(pivotX);
        scale.setPivotY(pivotY);
        return scale;
    }
    
    public static Shear shear(final double x, final double y) {
        final Shear shear = new Shear();
        shear.setX(x);
        shear.setY(y);
        return shear;
    }
    
    public static Shear shear(final double x, final double y, final double pivotX, final double pivotY) {
        final Shear shear = new Shear();
        shear.setX(x);
        shear.setY(y);
        shear.setPivotX(pivotX);
        shear.setPivotY(pivotY);
        return shear;
    }
    
    public double getMxx() {
        return 1.0;
    }
    
    public double getMxy() {
        return 0.0;
    }
    
    public double getMxz() {
        return 0.0;
    }
    
    public double getTx() {
        return 0.0;
    }
    
    public double getMyx() {
        return 0.0;
    }
    
    public double getMyy() {
        return 1.0;
    }
    
    public double getMyz() {
        return 0.0;
    }
    
    public double getTy() {
        return 0.0;
    }
    
    public double getMzx() {
        return 0.0;
    }
    
    public double getMzy() {
        return 0.0;
    }
    
    public double getMzz() {
        return 1.0;
    }
    
    public double getTz() {
        return 0.0;
    }
    
    public double getElement(final MatrixType matrixType, final int n, final int n2) {
        if (n < 0 || n >= matrixType.rows() || n2 < 0 || n2 >= matrixType.columns()) {
            throw new IndexOutOfBoundsException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/transform/MatrixType;II)Ljava/lang/String;, matrixType, n, n2));
        }
        Label_0476: {
            switch (matrixType) {
                case MT_2D_2x3:
                case MT_2D_3x3: {
                    if (!this.isType2D()) {
                        throw new IllegalArgumentException("Cannot access 2D matrix of a 3D transform");
                    }
                    Label_0211: {
                        switch (n) {
                            case 0: {
                                switch (n2) {
                                    case 0: {
                                        return this.getMxx();
                                    }
                                    case 1: {
                                        return this.getMxy();
                                    }
                                    case 2: {
                                        return this.getTx();
                                    }
                                    default: {
                                        break Label_0211;
                                    }
                                }
                                break;
                            }
                            case 1: {
                                switch (n2) {
                                    case 0: {
                                        return this.getMyx();
                                    }
                                    case 1: {
                                        return this.getMyy();
                                    }
                                    case 2: {
                                        return this.getTy();
                                    }
                                    default: {
                                        break Label_0211;
                                    }
                                }
                                break;
                            }
                            case 2: {
                                switch (n2) {
                                    case 0: {
                                        return 0.0;
                                    }
                                    case 1: {
                                        return 0.0;
                                    }
                                    case 2: {
                                        return 1.0;
                                    }
                                    default: {
                                        break Label_0211;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    break;
                }
                case MT_3D_3x4:
                case MT_3D_4x4: {
                    Label_0436: {
                        switch (n) {
                            case 0: {
                                switch (n2) {
                                    case 0: {
                                        return this.getMxx();
                                    }
                                    case 1: {
                                        return this.getMxy();
                                    }
                                    case 2: {
                                        return this.getMxz();
                                    }
                                    case 3: {
                                        return this.getTx();
                                    }
                                    default: {
                                        break Label_0436;
                                    }
                                }
                                break;
                            }
                            case 1: {
                                switch (n2) {
                                    case 0: {
                                        return this.getMyx();
                                    }
                                    case 1: {
                                        return this.getMyy();
                                    }
                                    case 2: {
                                        return this.getMyz();
                                    }
                                    case 3: {
                                        return this.getTy();
                                    }
                                    default: {
                                        break Label_0436;
                                    }
                                }
                                break;
                            }
                            case 2: {
                                switch (n2) {
                                    case 0: {
                                        return this.getMzx();
                                    }
                                    case 1: {
                                        return this.getMzy();
                                    }
                                    case 2: {
                                        return this.getMzz();
                                    }
                                    case 3: {
                                        return this.getTz();
                                    }
                                    default: {
                                        break Label_0436;
                                    }
                                }
                                break;
                            }
                            case 3: {
                                switch (n2) {
                                    case 0: {
                                        return 0.0;
                                    }
                                    case 1: {
                                        return 0.0;
                                    }
                                    case 2: {
                                        return 0.0;
                                    }
                                    case 3: {
                                        return 1.0;
                                    }
                                    default: {
                                        break Label_0476;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
        throw new InternalError(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/transform/MatrixType;)Ljava/lang/String;, matrixType));
    }
    
    boolean computeIs2D() {
        return this.getMxz() == 0.0 && this.getMzx() == 0.0 && this.getMzy() == 0.0 && this.getMzz() == 1.0 && this.getTz() == 0.0;
    }
    
    boolean computeIsIdentity() {
        return this.getMxx() == 1.0 && this.getMxy() == 0.0 && this.getMxz() == 0.0 && this.getTx() == 0.0 && this.getMyx() == 0.0 && this.getMyy() == 1.0 && this.getMyz() == 0.0 && this.getTy() == 0.0 && this.getMzx() == 0.0 && this.getMzy() == 0.0 && this.getMzz() == 1.0 && this.getTz() == 0.0;
    }
    
    public double determinant() {
        final double myx = this.getMyx();
        final double myy = this.getMyy();
        final double myz = this.getMyz();
        final double mzx = this.getMzx();
        final double mzy = this.getMzy();
        final double mzz = this.getMzz();
        return this.getMxx() * (myy * mzz - mzy * myz) + this.getMxy() * (myz * mzx - mzz * myx) + this.getMxz() * (myx * mzy - mzx * myy);
    }
    
    public final boolean isType2D() {
        return (this.type2D == null) ? this.computeIs2D() : this.type2D.get();
    }
    
    public final ReadOnlyBooleanProperty type2DProperty() {
        if (this.type2D == null) {
            this.type2D = new LazyBooleanProperty() {
                @Override
                protected boolean computeValue() {
                    return Transform.this.computeIs2D();
                }
                
                @Override
                public Object getBean() {
                    return Transform.this;
                }
                
                @Override
                public String getName() {
                    return "type2D";
                }
            };
        }
        return this.type2D;
    }
    
    public final boolean isIdentity() {
        return (this.identity == null) ? this.computeIsIdentity() : this.identity.get();
    }
    
    public final ReadOnlyBooleanProperty identityProperty() {
        if (this.identity == null) {
            this.identity = new LazyBooleanProperty() {
                @Override
                protected boolean computeValue() {
                    return Transform.this.computeIsIdentity();
                }
                
                @Override
                public Object getBean() {
                    return Transform.this;
                }
                
                @Override
                public String getName() {
                    return "identity";
                }
            };
        }
        return this.identity;
    }
    
    private double transformDiff(final Transform transform, final double n, final double n2) {
        return this.transform(n, n2).distance(transform.transform(n, n2));
    }
    
    private double transformDiff(final Transform transform, final double n, final double n2, final double n3) {
        return this.transform(n, n2, n3).distance(transform.transform(n, n2, n3));
    }
    
    public boolean similarTo(final Transform transform, final Bounds bounds, final double n) {
        if (this.isType2D() && transform.isType2D()) {
            final double minX = bounds.getMinX();
            if (this.transformDiff(transform, minX, bounds.getMinY()) > n) {
                return false;
            }
            if (this.transformDiff(transform, minX, bounds.getMaxY()) > n) {
                return false;
            }
            final double maxX = bounds.getMaxX();
            return this.transformDiff(transform, maxX, bounds.getMinY()) <= n && this.transformDiff(transform, maxX, bounds.getMaxY()) <= n;
        }
        else {
            final double minX2 = bounds.getMinX();
            final double minY = bounds.getMinY();
            final double minZ = bounds.getMinZ();
            if (this.transformDiff(transform, minX2, minY, minZ) > n) {
                return false;
            }
            if (this.transformDiff(transform, minX2, bounds.getMaxY(), minZ) > n) {
                return false;
            }
            final double maxX2 = bounds.getMaxX();
            if (this.transformDiff(transform, maxX2, bounds.getMinY(), minZ) > n) {
                return false;
            }
            if (this.transformDiff(transform, maxX2, bounds.getMaxY(), minZ) > n) {
                return false;
            }
            if (bounds.getDepth() != 0.0) {
                final double minX3 = bounds.getMinX();
                final double minY2 = bounds.getMinY();
                final double maxZ = bounds.getMaxZ();
                if (this.transformDiff(transform, minX3, minY2, maxZ) > n) {
                    return false;
                }
                if (this.transformDiff(transform, minX3, bounds.getMaxY(), maxZ) > n) {
                    return false;
                }
                final double maxX3 = bounds.getMaxX();
                if (this.transformDiff(transform, maxX3, bounds.getMinY(), maxZ) > n) {
                    return false;
                }
                if (this.transformDiff(transform, maxX3, bounds.getMaxY(), maxZ) > n) {
                    return false;
                }
            }
            return true;
        }
    }
    
    void fill2DArray(final double[] array) {
        array[0] = this.getMxx();
        array[1] = this.getMxy();
        array[2] = this.getTx();
        array[3] = this.getMyx();
        array[4] = this.getMyy();
        array[5] = this.getTy();
    }
    
    void fill3DArray(final double[] array) {
        array[0] = this.getMxx();
        array[1] = this.getMxy();
        array[2] = this.getMxz();
        array[3] = this.getTx();
        array[4] = this.getMyx();
        array[5] = this.getMyy();
        array[6] = this.getMyz();
        array[7] = this.getTy();
        array[8] = this.getMzx();
        array[9] = this.getMzy();
        array[10] = this.getMzz();
        array[11] = this.getTz();
    }
    
    public double[] toArray(final MatrixType matrixType, double[] array) {
        this.checkRequestedMAT(matrixType);
        if (array == null || array.length < matrixType.elements()) {
            array = new double[matrixType.elements()];
        }
        switch (matrixType) {
            case MT_2D_3x3: {
                array[7] = (array[6] = 0.0);
                array[8] = 1.0;
            }
            case MT_2D_2x3: {
                this.fill2DArray(array);
                break;
            }
            case MT_3D_4x4: {
                array[12] = 0.0;
                array[14] = (array[13] = 0.0);
                array[15] = 1.0;
            }
            case MT_3D_3x4: {
                this.fill3DArray(array);
                break;
            }
            default: {
                throw new InternalError(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/transform/MatrixType;)Ljava/lang/String;, matrixType));
            }
        }
        return array;
    }
    
    public double[] toArray(final MatrixType matrixType) {
        return this.toArray(matrixType, null);
    }
    
    public double[] row(final MatrixType matrixType, final int n, double[] array) {
        this.checkRequestedMAT(matrixType);
        if (n < 0 || n >= matrixType.rows()) {
            throw new IndexOutOfBoundsException(invokedynamic(makeConcatWithConstants:(ILjavafx/scene/transform/MatrixType;)Ljava/lang/String;, n, matrixType));
        }
        if (array == null || array.length < matrixType.columns()) {
            array = new double[matrixType.columns()];
        }
        switch (matrixType) {
            case MT_2D_2x3:
            case MT_2D_3x3: {
                switch (n) {
                    case 0: {
                        array[0] = this.getMxx();
                        array[1] = this.getMxy();
                        array[2] = this.getTx();
                        break;
                    }
                    case 1: {
                        array[0] = this.getMyx();
                        array[1] = this.getMyy();
                        array[2] = this.getTy();
                        break;
                    }
                    case 2: {
                        array[1] = (array[0] = 0.0);
                        array[2] = 1.0;
                        break;
                    }
                }
                break;
            }
            case MT_3D_3x4:
            case MT_3D_4x4: {
                switch (n) {
                    case 0: {
                        array[0] = this.getMxx();
                        array[1] = this.getMxy();
                        array[2] = this.getMxz();
                        array[3] = this.getTx();
                        break;
                    }
                    case 1: {
                        array[0] = this.getMyx();
                        array[1] = this.getMyy();
                        array[2] = this.getMyz();
                        array[3] = this.getTy();
                        break;
                    }
                    case 2: {
                        array[0] = this.getMzx();
                        array[1] = this.getMzy();
                        array[2] = this.getMzz();
                        array[3] = this.getTz();
                        break;
                    }
                    case 3: {
                        array[0] = 0.0;
                        array[2] = (array[1] = 0.0);
                        array[3] = 1.0;
                        break;
                    }
                }
                break;
            }
            default: {
                throw new InternalError(invokedynamic(makeConcatWithConstants:(ILjavafx/scene/transform/MatrixType;)Ljava/lang/String;, n, matrixType));
            }
        }
        return array;
    }
    
    public double[] row(final MatrixType matrixType, final int n) {
        return this.row(matrixType, n, null);
    }
    
    public double[] column(final MatrixType matrixType, final int n, double[] array) {
        this.checkRequestedMAT(matrixType);
        if (n < 0 || n >= matrixType.columns()) {
            throw new IndexOutOfBoundsException(invokedynamic(makeConcatWithConstants:(ILjavafx/scene/transform/MatrixType;)Ljava/lang/String;, n, matrixType));
        }
        if (array == null || array.length < matrixType.rows()) {
            array = new double[matrixType.rows()];
        }
        switch (matrixType) {
            case MT_2D_2x3: {
                switch (n) {
                    case 0: {
                        array[0] = this.getMxx();
                        array[1] = this.getMyx();
                        break;
                    }
                    case 1: {
                        array[0] = this.getMxy();
                        array[1] = this.getMyy();
                        break;
                    }
                    case 2: {
                        array[0] = this.getTx();
                        array[1] = this.getTy();
                        break;
                    }
                }
                break;
            }
            case MT_2D_3x3: {
                switch (n) {
                    case 0: {
                        array[0] = this.getMxx();
                        array[1] = this.getMyx();
                        array[2] = 0.0;
                        break;
                    }
                    case 1: {
                        array[0] = this.getMxy();
                        array[1] = this.getMyy();
                        array[2] = 0.0;
                        break;
                    }
                    case 2: {
                        array[0] = this.getTx();
                        array[1] = this.getTy();
                        array[2] = 1.0;
                        break;
                    }
                }
                break;
            }
            case MT_3D_3x4: {
                switch (n) {
                    case 0: {
                        array[0] = this.getMxx();
                        array[1] = this.getMyx();
                        array[2] = this.getMzx();
                        break;
                    }
                    case 1: {
                        array[0] = this.getMxy();
                        array[1] = this.getMyy();
                        array[2] = this.getMzy();
                        break;
                    }
                    case 2: {
                        array[0] = this.getMxz();
                        array[1] = this.getMyz();
                        array[2] = this.getMzz();
                        break;
                    }
                    case 3: {
                        array[0] = this.getTx();
                        array[1] = this.getTy();
                        array[2] = this.getTz();
                        break;
                    }
                }
                break;
            }
            case MT_3D_4x4: {
                switch (n) {
                    case 0: {
                        array[0] = this.getMxx();
                        array[1] = this.getMyx();
                        array[2] = this.getMzx();
                        array[3] = 0.0;
                        break;
                    }
                    case 1: {
                        array[0] = this.getMxy();
                        array[1] = this.getMyy();
                        array[2] = this.getMzy();
                        array[3] = 0.0;
                        break;
                    }
                    case 2: {
                        array[0] = this.getMxz();
                        array[1] = this.getMyz();
                        array[2] = this.getMzz();
                        array[3] = 0.0;
                        break;
                    }
                    case 3: {
                        array[0] = this.getTx();
                        array[1] = this.getTy();
                        array[2] = this.getTz();
                        array[3] = 1.0;
                        break;
                    }
                }
                break;
            }
            default: {
                throw new InternalError(invokedynamic(makeConcatWithConstants:(ILjavafx/scene/transform/MatrixType;)Ljava/lang/String;, n, matrixType));
            }
        }
        return array;
    }
    
    public double[] column(final MatrixType matrixType, final int n) {
        return this.column(matrixType, n, null);
    }
    
    public Transform createConcatenation(final Transform transform) {
        final double mxx = transform.getMxx();
        final double mxy = transform.getMxy();
        final double mxz = transform.getMxz();
        final double tx = transform.getTx();
        final double myx = transform.getMyx();
        final double myy = transform.getMyy();
        final double myz = transform.getMyz();
        final double ty = transform.getTy();
        final double mzx = transform.getMzx();
        final double mzy = transform.getMzy();
        final double mzz = transform.getMzz();
        final double tz = transform.getTz();
        return new Affine(this.getMxx() * mxx + this.getMxy() * myx + this.getMxz() * mzx, this.getMxx() * mxy + this.getMxy() * myy + this.getMxz() * mzy, this.getMxx() * mxz + this.getMxy() * myz + this.getMxz() * mzz, this.getMxx() * tx + this.getMxy() * ty + this.getMxz() * tz + this.getTx(), this.getMyx() * mxx + this.getMyy() * myx + this.getMyz() * mzx, this.getMyx() * mxy + this.getMyy() * myy + this.getMyz() * mzy, this.getMyx() * mxz + this.getMyy() * myz + this.getMyz() * mzz, this.getMyx() * tx + this.getMyy() * ty + this.getMyz() * tz + this.getTy(), this.getMzx() * mxx + this.getMzy() * myx + this.getMzz() * mzx, this.getMzx() * mxy + this.getMzy() * myy + this.getMzz() * mzy, this.getMzx() * mxz + this.getMzy() * myz + this.getMzz() * mzz, this.getMzx() * tx + this.getMzy() * ty + this.getMzz() * tz + this.getTz());
    }
    
    public Transform createInverse() throws NonInvertibleTransformException {
        return this.getInverseCache().clone();
    }
    
    public Transform clone() {
        return TransformUtils.immutableTransform(this);
    }
    
    public Point2D transform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        return new Point2D(this.getMxx() * n + this.getMxy() * n2 + this.getTx(), this.getMyx() * n + this.getMyy() * n2 + this.getTy());
    }
    
    public Point2D transform(final Point2D point2D) {
        return this.transform(point2D.getX(), point2D.getY());
    }
    
    public Point3D transform(final double n, final double n2, final double n3) {
        return new Point3D(this.getMxx() * n + this.getMxy() * n2 + this.getMxz() * n3 + this.getTx(), this.getMyx() * n + this.getMyy() * n2 + this.getMyz() * n3 + this.getTy(), this.getMzx() * n + this.getMzy() * n2 + this.getMzz() * n3 + this.getTz());
    }
    
    public Point3D transform(final Point3D point3D) {
        return this.transform(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Bounds transform(final Bounds bounds) {
        if (this.isType2D() && bounds.getMinZ() == 0.0 && bounds.getMaxZ() == 0.0) {
            return BoundsUtils.createBoundingBox(this.transform(bounds.getMinX(), bounds.getMinY()), this.transform(bounds.getMaxX(), bounds.getMinY()), this.transform(bounds.getMaxX(), bounds.getMaxY()), this.transform(bounds.getMinX(), bounds.getMaxY()));
        }
        return BoundsUtils.createBoundingBox(this.transform(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ()), this.transform(bounds.getMinX(), bounds.getMinY(), bounds.getMaxZ()), this.transform(bounds.getMinX(), bounds.getMaxY(), bounds.getMinZ()), this.transform(bounds.getMinX(), bounds.getMaxY(), bounds.getMaxZ()), this.transform(bounds.getMaxX(), bounds.getMaxY(), bounds.getMinZ()), this.transform(bounds.getMaxX(), bounds.getMaxY(), bounds.getMaxZ()), this.transform(bounds.getMaxX(), bounds.getMinY(), bounds.getMinZ()), this.transform(bounds.getMaxX(), bounds.getMinY(), bounds.getMaxZ()));
    }
    
    void transform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double mxx = this.getMxx();
        final double mxy = this.getMxy();
        final double tx = this.getTx();
        final double myx = this.getMyx();
        final double myy = this.getMyy();
        final double ty = this.getTy();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            array2[n2++] = mxx * n4 + mxy * n5 + tx;
            array2[n2++] = myx * n4 + myy * n5 + ty;
        }
    }
    
    void transform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double mxx = this.getMxx();
        final double mxy = this.getMxy();
        final double mxz = this.getMxz();
        final double tx = this.getTx();
        final double myx = this.getMyx();
        final double myy = this.getMyy();
        final double myz = this.getMyz();
        final double ty = this.getTy();
        final double mzx = this.getMzx();
        final double mzy = this.getMzy();
        final double mzz = this.getMzz();
        final double tz = this.getTz();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            final double n6 = array[n++];
            array2[n2++] = mxx * n4 + mxy * n5 + mxz * n6 + tx;
            array2[n2++] = myx * n4 + myy * n5 + myz * n6 + ty;
            array2[n2++] = mzx * n4 + mzy * n5 + mzz * n6 + tz;
        }
    }
    
    public void transform2DPoints(final double[] array, int fixedSrcOffset, final double[] array2, final int n, final int n2) {
        if (array == null || array2 == null) {
            throw new NullPointerException();
        }
        if (!this.isType2D()) {
            throw new IllegalStateException("Cannot transform 2D points with a 3D transform");
        }
        fixedSrcOffset = this.getFixedSrcOffset(array, fixedSrcOffset, array2, n, n2, 2);
        this.transform2DPointsImpl(array, fixedSrcOffset, array2, n, n2);
    }
    
    public void transform3DPoints(final double[] array, int fixedSrcOffset, final double[] array2, final int n, final int n2) {
        if (array == null || array2 == null) {
            throw new NullPointerException();
        }
        fixedSrcOffset = this.getFixedSrcOffset(array, fixedSrcOffset, array2, n, n2, 3);
        this.transform3DPointsImpl(array, fixedSrcOffset, array2, n, n2);
    }
    
    public Point2D deltaTransform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        return new Point2D(this.getMxx() * n + this.getMxy() * n2, this.getMyx() * n + this.getMyy() * n2);
    }
    
    public Point2D deltaTransform(final Point2D point2D) {
        return this.deltaTransform(point2D.getX(), point2D.getY());
    }
    
    public Point3D deltaTransform(final double n, final double n2, final double n3) {
        return new Point3D(this.getMxx() * n + this.getMxy() * n2 + this.getMxz() * n3, this.getMyx() * n + this.getMyy() * n2 + this.getMyz() * n3, this.getMzx() * n + this.getMzy() * n2 + this.getMzz() * n3);
    }
    
    public Point3D deltaTransform(final Point3D point3D) {
        return this.deltaTransform(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Point2D inverseTransform(final double n, final double n2) throws NonInvertibleTransformException {
        this.ensureCanTransform2DPoint();
        return this.getInverseCache().transform(n, n2);
    }
    
    public Point2D inverseTransform(final Point2D point2D) throws NonInvertibleTransformException {
        return this.inverseTransform(point2D.getX(), point2D.getY());
    }
    
    public Point3D inverseTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
        return this.getInverseCache().transform(n, n2, n3);
    }
    
    public Point3D inverseTransform(final Point3D point3D) throws NonInvertibleTransformException {
        return this.inverseTransform(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public Bounds inverseTransform(final Bounds bounds) throws NonInvertibleTransformException {
        if (this.isType2D() && bounds.getMinZ() == 0.0 && bounds.getMaxZ() == 0.0) {
            return BoundsUtils.createBoundingBox(this.inverseTransform(bounds.getMinX(), bounds.getMinY()), this.inverseTransform(bounds.getMaxX(), bounds.getMinY()), this.inverseTransform(bounds.getMaxX(), bounds.getMaxY()), this.inverseTransform(bounds.getMinX(), bounds.getMaxY()));
        }
        return BoundsUtils.createBoundingBox(this.inverseTransform(bounds.getMinX(), bounds.getMinY(), bounds.getMinZ()), this.inverseTransform(bounds.getMinX(), bounds.getMinY(), bounds.getMaxZ()), this.inverseTransform(bounds.getMinX(), bounds.getMaxY(), bounds.getMinZ()), this.inverseTransform(bounds.getMinX(), bounds.getMaxY(), bounds.getMaxZ()), this.inverseTransform(bounds.getMaxX(), bounds.getMaxY(), bounds.getMinZ()), this.inverseTransform(bounds.getMaxX(), bounds.getMaxY(), bounds.getMaxZ()), this.inverseTransform(bounds.getMaxX(), bounds.getMinY(), bounds.getMinZ()), this.inverseTransform(bounds.getMaxX(), bounds.getMinY(), bounds.getMaxZ()));
    }
    
    void inverseTransform2DPointsImpl(final double[] array, final int n, final double[] array2, final int n2, final int n3) throws NonInvertibleTransformException {
        this.getInverseCache().transform2DPointsImpl(array, n, array2, n2, n3);
    }
    
    void inverseTransform3DPointsImpl(final double[] array, final int n, final double[] array2, final int n2, final int n3) throws NonInvertibleTransformException {
        this.getInverseCache().transform3DPointsImpl(array, n, array2, n2, n3);
    }
    
    public void inverseTransform2DPoints(final double[] array, int fixedSrcOffset, final double[] array2, final int n, final int n2) throws NonInvertibleTransformException {
        if (array == null || array2 == null) {
            throw new NullPointerException();
        }
        if (!this.isType2D()) {
            throw new IllegalStateException("Cannot transform 2D points with a 3D transform");
        }
        fixedSrcOffset = this.getFixedSrcOffset(array, fixedSrcOffset, array2, n, n2, 2);
        this.inverseTransform2DPointsImpl(array, fixedSrcOffset, array2, n, n2);
    }
    
    public void inverseTransform3DPoints(final double[] array, int fixedSrcOffset, final double[] array2, final int n, final int n2) throws NonInvertibleTransformException {
        if (array == null || array2 == null) {
            throw new NullPointerException();
        }
        fixedSrcOffset = this.getFixedSrcOffset(array, fixedSrcOffset, array2, n, n2, 3);
        this.inverseTransform3DPointsImpl(array, fixedSrcOffset, array2, n, n2);
    }
    
    public Point2D inverseDeltaTransform(final double n, final double n2) throws NonInvertibleTransformException {
        this.ensureCanTransform2DPoint();
        return this.getInverseCache().deltaTransform(n, n2);
    }
    
    public Point2D inverseDeltaTransform(final Point2D point2D) throws NonInvertibleTransformException {
        return this.inverseDeltaTransform(point2D.getX(), point2D.getY());
    }
    
    public Point3D inverseDeltaTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
        return this.getInverseCache().deltaTransform(n, n2, n3);
    }
    
    public Point3D inverseDeltaTransform(final Point3D point3D) throws NonInvertibleTransformException {
        return this.inverseDeltaTransform(point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    private int getFixedSrcOffset(final double[] array, final int n, final double[] array2, final int n2, final int n3, final int n4) {
        if (array2 == array && n2 > n && n2 < n + n3 * n4) {
            System.arraycopy(array, n, array2, n2, n3 * n4);
            return n2;
        }
        return n;
    }
    
    private EventHandlerManager getInternalEventDispatcher() {
        if (this.internalEventDispatcher == null) {
            this.internalEventDispatcher = new EventHandlerManager(this);
        }
        return this.internalEventDispatcher;
    }
    
    @Override
    public EventDispatchChain buildEventDispatchChain(final EventDispatchChain eventDispatchChain) {
        return (this.internalEventDispatcher == null) ? eventDispatchChain : eventDispatchChain.append(this.getInternalEventDispatcher());
    }
    
    public final <T extends Event> void addEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().addEventHandler(eventType, eventHandler);
        this.validate();
    }
    
    public final <T extends Event> void removeEventHandler(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().removeEventHandler(eventType, eventHandler);
    }
    
    public final <T extends Event> void addEventFilter(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().addEventFilter(eventType, eventHandler);
        this.validate();
    }
    
    public final <T extends Event> void removeEventFilter(final EventType<T> eventType, final EventHandler<? super T> eventHandler) {
        this.getInternalEventDispatcher().removeEventFilter(eventType, eventHandler);
    }
    
    public final void setOnTransformChanged(final EventHandler<? super TransformChangedEvent> eventHandler) {
        this.onTransformChangedProperty().set(eventHandler);
        this.validate();
    }
    
    public final EventHandler<? super TransformChangedEvent> getOnTransformChanged() {
        return (this.onTransformChanged == null) ? null : this.onTransformChanged.get();
    }
    
    public final ObjectProperty<EventHandler<? super TransformChangedEvent>> onTransformChangedProperty() {
        if (this.onTransformChanged == null) {
            this.onTransformChanged = new SimpleObjectProperty<EventHandler<? super TransformChangedEvent>>(this, "onTransformChanged") {
                @Override
                protected void invalidated() {
                    Transform.this.getInternalEventDispatcher().setEventHandler(TransformChangedEvent.TRANSFORM_CHANGED, this.get());
                }
            };
        }
        return this.onTransformChanged;
    }
    
    void checkRequestedMAT(final MatrixType matrixType) throws IllegalArgumentException {
        if (matrixType.is2D() && !this.isType2D()) {
            throw new IllegalArgumentException("Cannot access 2D matrix for a 3D transform");
        }
    }
    
    void ensureCanTransform2DPoint() throws IllegalStateException {
        if (!this.isType2D()) {
            throw new IllegalStateException("Cannot transform 2D point with a 3D transform");
        }
    }
    
    void validate() {
        this.getMxx();
        this.getMxy();
        this.getMxz();
        this.getTx();
        this.getMyx();
        this.getMyy();
        this.getMyz();
        this.getTy();
        this.getMzx();
        this.getMzy();
        this.getMzz();
        this.getTz();
    }
    
    abstract void apply(final Affine3D p0);
    
    abstract BaseTransform derive(final BaseTransform p0);
    
    void add(final Node node) {
        this.nodes.add(node);
    }
    
    void remove(final Node node) {
        this.nodes.remove(node);
    }
    
    protected void transformChanged() {
        this.inverseCache = null;
        final Iterator iterator = this.nodes.iterator();
        while (iterator.hasNext()) {
            NodeHelper.transformsChanged(iterator.next());
        }
        if (this.type2D != null) {
            this.type2D.invalidate();
        }
        if (this.identity != null) {
            this.identity.invalidate();
        }
        if (this.internalEventDispatcher != null) {
            this.validate();
            Event.fireEvent(this, new TransformChangedEvent(this, this));
        }
    }
    
    void appendTo(final Affine affine) {
        affine.append(this.getMxx(), this.getMxy(), this.getMxz(), this.getTx(), this.getMyx(), this.getMyy(), this.getMyz(), this.getTy(), this.getMzx(), this.getMzy(), this.getMzz(), this.getTz());
    }
    
    void prependTo(final Affine affine) {
        affine.prepend(this.getMxx(), this.getMxy(), this.getMxz(), this.getTx(), this.getMyx(), this.getMyy(), this.getMyz(), this.getTy(), this.getMzx(), this.getMzy(), this.getMzz(), this.getTz());
    }
    
    private Transform getInverseCache() throws NonInvertibleTransformException {
        if (this.inverseCache == null || this.inverseCache.get() == null) {
            final Affine referent = new Affine(this.getMxx(), this.getMxy(), this.getMxz(), this.getTx(), this.getMyx(), this.getMyy(), this.getMyz(), this.getTy(), this.getMzx(), this.getMzy(), this.getMzz(), this.getTz());
            referent.invert();
            this.inverseCache = new SoftReference<Transform>(referent);
            return referent;
        }
        return this.inverseCache.get();
    }
    
    void clearInverseCache() {
        if (this.inverseCache != null) {
            this.inverseCache.clear();
        }
    }
    
    static Transform createImmutableTransform() {
        return new ImmutableTransform();
    }
    
    static Transform createImmutableTransform(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final double n8, final double n9, final double n10, final double n11, final double n12) {
        return new ImmutableTransform(n, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12);
    }
    
    static Transform createImmutableTransform(final Transform transform, final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final double n8, final double n9, final double n10, final double n11, final double n12) {
        if (transform == null) {
            return new ImmutableTransform(n, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12);
        }
        ((ImmutableTransform)transform).setToTransform(n, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12);
        return transform;
    }
    
    static Transform createImmutableTransform(Transform transform, final Transform transform2, final Transform transform3) {
        if (transform == null) {
            transform = new ImmutableTransform();
        }
        ((ImmutableTransform)transform).setToConcatenation((ImmutableTransform)transform2, (ImmutableTransform)transform3);
        return transform;
    }
    
    static {
        TransformHelper.setTransformAccessor(new TransformHelper.TransformAccessor() {
            @Override
            public void add(final Transform transform, final Node node) {
                transform.add(node);
            }
            
            @Override
            public void remove(final Transform transform, final Node node) {
                transform.remove(node);
            }
            
            @Override
            public void apply(final Transform transform, final Affine3D affine3D) {
                transform.apply(affine3D);
            }
            
            @Override
            public BaseTransform derive(final Transform transform, final BaseTransform baseTransform) {
                return transform.derive(baseTransform);
            }
            
            @Override
            public Transform createImmutableTransform() {
                return Transform.createImmutableTransform();
            }
            
            @Override
            public Transform createImmutableTransform(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final double n8, final double n9, final double n10, final double n11, final double n12) {
                return Transform.createImmutableTransform(n, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12);
            }
            
            @Override
            public Transform createImmutableTransform(final Transform transform, final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final double n8, final double n9, final double n10, final double n11, final double n12) {
                return Transform.createImmutableTransform(transform, n, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12);
            }
            
            @Override
            public Transform createImmutableTransform(final Transform transform, final Transform transform2, final Transform transform3) {
                return Transform.createImmutableTransform(transform, transform2, transform3);
            }
        });
    }
    
    private abstract static class LazyBooleanProperty extends ReadOnlyBooleanProperty
    {
        private ExpressionHelper<Boolean> helper;
        private boolean valid;
        private boolean value;
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, invalidationListener);
        }
        
        @Override
        public void addListener(final ChangeListener<? super Boolean> changeListener) {
            this.helper = ExpressionHelper.addListener(this.helper, this, changeListener);
        }
        
        @Override
        public void removeListener(final ChangeListener<? super Boolean> changeListener) {
            this.helper = ExpressionHelper.removeListener(this.helper, changeListener);
        }
        
        @Override
        public boolean get() {
            if (!this.valid) {
                this.value = this.computeValue();
                this.valid = true;
            }
            return this.value;
        }
        
        public void invalidate() {
            if (this.valid) {
                this.valid = false;
                ExpressionHelper.fireValueChangedEvent(this.helper);
            }
        }
        
        protected abstract boolean computeValue();
    }
    
    static class ImmutableTransform extends Transform
    {
        private static final int APPLY_IDENTITY = 0;
        private static final int APPLY_TRANSLATE = 1;
        private static final int APPLY_SCALE = 2;
        private static final int APPLY_SHEAR = 4;
        private static final int APPLY_NON_3D = 0;
        private static final int APPLY_3D_COMPLEX = 4;
        private transient int state2d;
        private transient int state3d;
        private double xx;
        private double xy;
        private double xz;
        private double yx;
        private double yy;
        private double yz;
        private double zx;
        private double zy;
        private double zz;
        private double xt;
        private double yt;
        private double zt;
        
        ImmutableTransform() {
            final double xx = 1.0;
            this.zz = xx;
            this.yy = xx;
            this.xx = xx;
        }
        
        ImmutableTransform(final Transform transform) {
            this(transform.getMxx(), transform.getMxy(), transform.getMxz(), transform.getTx(), transform.getMyx(), transform.getMyy(), transform.getMyz(), transform.getTy(), transform.getMzx(), transform.getMzy(), transform.getMzz(), transform.getTz());
        }
        
        ImmutableTransform(final double xx, final double xy, final double xz, final double xt, final double yx, final double yy, final double yz, final double yt, final double zx, final double zy, final double zz, final double zt) {
            this.xx = xx;
            this.xy = xy;
            this.xz = xz;
            this.xt = xt;
            this.yx = yx;
            this.yy = yy;
            this.yz = yz;
            this.yt = yt;
            this.zx = zx;
            this.zy = zy;
            this.zz = zz;
            this.zt = zt;
            this.updateState();
        }
        
        private void setToTransform(final double xx, final double xy, final double xz, final double xt, final double yx, final double yy, final double yz, final double yt, final double zx, final double zy, final double zz, final double zt) {
            this.xx = xx;
            this.xy = xy;
            this.xz = xz;
            this.xt = xt;
            this.yx = yx;
            this.yy = yy;
            this.yz = yz;
            this.yt = yt;
            this.zx = zx;
            this.zy = zy;
            this.zz = zz;
            this.zt = zt;
            this.updateState();
        }
        
        private void setToConcatenation(final ImmutableTransform immutableTransform, final ImmutableTransform immutableTransform2) {
            if (immutableTransform.state3d == 0 && immutableTransform2.state3d == 0) {
                this.xx = immutableTransform.xx * immutableTransform2.xx + immutableTransform.xy * immutableTransform2.yx;
                this.xy = immutableTransform.xx * immutableTransform2.xy + immutableTransform.xy * immutableTransform2.yy;
                this.xt = immutableTransform.xx * immutableTransform2.xt + immutableTransform.xy * immutableTransform2.yt + immutableTransform.xt;
                this.yx = immutableTransform.yx * immutableTransform2.xx + immutableTransform.yy * immutableTransform2.yx;
                this.yy = immutableTransform.yx * immutableTransform2.xy + immutableTransform.yy * immutableTransform2.yy;
                this.yt = immutableTransform.yx * immutableTransform2.xt + immutableTransform.yy * immutableTransform2.yt + immutableTransform.yt;
                if (this.state3d != 0) {
                    final double xz = 0.0;
                    this.zt = xz;
                    this.zy = xz;
                    this.zx = xz;
                    this.yz = xz;
                    this.xz = xz;
                    this.zz = 1.0;
                    this.state3d = 0;
                }
                this.updateState2D();
            }
            else {
                this.xx = immutableTransform.xx * immutableTransform2.xx + immutableTransform.xy * immutableTransform2.yx + immutableTransform.xz * immutableTransform2.zx;
                this.xy = immutableTransform.xx * immutableTransform2.xy + immutableTransform.xy * immutableTransform2.yy + immutableTransform.xz * immutableTransform2.zy;
                this.xz = immutableTransform.xx * immutableTransform2.xz + immutableTransform.xy * immutableTransform2.yz + immutableTransform.xz * immutableTransform2.zz;
                this.xt = immutableTransform.xx * immutableTransform2.xt + immutableTransform.xy * immutableTransform2.yt + immutableTransform.xz * immutableTransform2.zt + immutableTransform.xt;
                this.yx = immutableTransform.yx * immutableTransform2.xx + immutableTransform.yy * immutableTransform2.yx + immutableTransform.yz * immutableTransform2.zx;
                this.yy = immutableTransform.yx * immutableTransform2.xy + immutableTransform.yy * immutableTransform2.yy + immutableTransform.yz * immutableTransform2.zy;
                this.yz = immutableTransform.yx * immutableTransform2.xz + immutableTransform.yy * immutableTransform2.yz + immutableTransform.yz * immutableTransform2.zz;
                this.yt = immutableTransform.yx * immutableTransform2.xt + immutableTransform.yy * immutableTransform2.yt + immutableTransform.yz * immutableTransform2.zt + immutableTransform.yt;
                this.zx = immutableTransform.zx * immutableTransform2.xx + immutableTransform.zy * immutableTransform2.yx + immutableTransform.zz * immutableTransform2.zx;
                this.zy = immutableTransform.zx * immutableTransform2.xy + immutableTransform.zy * immutableTransform2.yy + immutableTransform.zz * immutableTransform2.zy;
                this.zz = immutableTransform.zx * immutableTransform2.xz + immutableTransform.zy * immutableTransform2.yz + immutableTransform.zz * immutableTransform2.zz;
                this.zt = immutableTransform.zx * immutableTransform2.xt + immutableTransform.zy * immutableTransform2.yt + immutableTransform.zz * immutableTransform2.zt + immutableTransform.zt;
                this.updateState();
            }
        }
        
        @Override
        public double getMxx() {
            return this.xx;
        }
        
        @Override
        public double getMxy() {
            return this.xy;
        }
        
        @Override
        public double getMxz() {
            return this.xz;
        }
        
        @Override
        public double getTx() {
            return this.xt;
        }
        
        @Override
        public double getMyx() {
            return this.yx;
        }
        
        @Override
        public double getMyy() {
            return this.yy;
        }
        
        @Override
        public double getMyz() {
            return this.yz;
        }
        
        @Override
        public double getTy() {
            return this.yt;
        }
        
        @Override
        public double getMzx() {
            return this.zx;
        }
        
        @Override
        public double getMzy() {
            return this.zy;
        }
        
        @Override
        public double getMzz() {
            return this.zz;
        }
        
        @Override
        public double getTz() {
            return this.zt;
        }
        
        @Override
        public double determinant() {
            switch (this.state3d) {
                default: {
                    stateError();
                }
                case 0: {
                    switch (this.state2d) {
                        default: {
                            stateError();
                            return this.xx * this.yy - this.xy * this.yx;
                        }
                        case 6:
                        case 7: {
                            return this.xx * this.yy - this.xy * this.yx;
                        }
                        case 4:
                        case 5: {
                            return -(this.xy * this.yx);
                        }
                        case 2:
                        case 3: {
                            return this.xx * this.yy;
                        }
                        case 0:
                        case 1: {
                            return 1.0;
                        }
                    }
                    break;
                }
                case 1: {
                    return 1.0;
                }
                case 2:
                case 3: {
                    return this.xx * this.yy * this.zz;
                }
                case 4: {
                    return this.xx * (this.yy * this.zz - this.zy * this.yz) + this.xy * (this.yz * this.zx - this.zz * this.yx) + this.xz * (this.yx * this.zy - this.zx * this.yy);
                }
            }
        }
        
        @Override
        public Transform createConcatenation(final Transform transform) {
            final Affine affine = new Affine(this);
            affine.append(transform);
            return affine;
        }
        
        @Override
        public Affine createInverse() throws NonInvertibleTransformException {
            final Affine affine = new Affine(this);
            affine.invert();
            return affine;
        }
        
        @Override
        public Transform clone() {
            return new ImmutableTransform(this);
        }
        
        @Override
        public Point2D transform(final double n, final double n2) {
            this.ensureCanTransform2DPoint();
            switch (this.state2d) {
                default: {
                    stateError();
                    return new Point2D(this.xx * n + this.xy * n2 + this.xt, this.yx * n + this.yy * n2 + this.yt);
                }
                case 7: {
                    return new Point2D(this.xx * n + this.xy * n2 + this.xt, this.yx * n + this.yy * n2 + this.yt);
                }
                case 6: {
                    return new Point2D(this.xx * n + this.xy * n2, this.yx * n + this.yy * n2);
                }
                case 5: {
                    return new Point2D(this.xy * n2 + this.xt, this.yx * n + this.yt);
                }
                case 4: {
                    return new Point2D(this.xy * n2, this.yx * n);
                }
                case 3: {
                    return new Point2D(this.xx * n + this.xt, this.yy * n2 + this.yt);
                }
                case 2: {
                    return new Point2D(this.xx * n, this.yy * n2);
                }
                case 1: {
                    return new Point2D(n + this.xt, n2 + this.yt);
                }
                case 0: {
                    return new Point2D(n, n2);
                }
            }
        }
        
        @Override
        public Point3D transform(final double n, final double n2, final double n3) {
            switch (this.state3d) {
                default: {
                    stateError();
                }
                case 0: {
                    switch (this.state2d) {
                        default: {
                            stateError();
                            return new Point3D(this.xx * n + this.xy * n2 + this.xt, this.yx * n + this.yy * n2 + this.yt, n3);
                        }
                        case 7: {
                            return new Point3D(this.xx * n + this.xy * n2 + this.xt, this.yx * n + this.yy * n2 + this.yt, n3);
                        }
                        case 6: {
                            return new Point3D(this.xx * n + this.xy * n2, this.yx * n + this.yy * n2, n3);
                        }
                        case 5: {
                            return new Point3D(this.xy * n2 + this.xt, this.yx * n + this.yt, n3);
                        }
                        case 4: {
                            return new Point3D(this.xy * n2, this.yx * n, n3);
                        }
                        case 3: {
                            return new Point3D(this.xx * n + this.xt, this.yy * n2 + this.yt, n3);
                        }
                        case 2: {
                            return new Point3D(this.xx * n, this.yy * n2, n3);
                        }
                        case 1: {
                            return new Point3D(n + this.xt, n2 + this.yt, n3);
                        }
                        case 0: {
                            return new Point3D(n, n2, n3);
                        }
                    }
                    break;
                }
                case 1: {
                    return new Point3D(n + this.xt, n2 + this.yt, n3 + this.zt);
                }
                case 2: {
                    return new Point3D(this.xx * n, this.yy * n2, this.zz * n3);
                }
                case 3: {
                    return new Point3D(this.xx * n + this.xt, this.yy * n2 + this.yt, this.zz * n3 + this.zt);
                }
                case 4: {
                    return new Point3D(this.xx * n + this.xy * n2 + this.xz * n3 + this.xt, this.yx * n + this.yy * n2 + this.yz * n3 + this.yt, this.zx * n + this.zy * n2 + this.zz * n3 + this.zt);
                }
            }
        }
        
        @Override
        public Point2D deltaTransform(final double n, final double n2) {
            this.ensureCanTransform2DPoint();
            switch (this.state2d) {
                default: {
                    stateError();
                    return new Point2D(this.xx * n + this.xy * n2, this.yx * n + this.yy * n2);
                }
                case 6:
                case 7: {
                    return new Point2D(this.xx * n + this.xy * n2, this.yx * n + this.yy * n2);
                }
                case 4:
                case 5: {
                    return new Point2D(this.xy * n2, this.yx * n);
                }
                case 2:
                case 3: {
                    return new Point2D(this.xx * n, this.yy * n2);
                }
                case 0:
                case 1: {
                    return new Point2D(n, n2);
                }
            }
        }
        
        @Override
        public Point3D deltaTransform(final double n, final double n2, final double n3) {
            switch (this.state3d) {
                default: {
                    stateError();
                }
                case 0: {
                    switch (this.state2d) {
                        default: {
                            stateError();
                            return new Point3D(this.xx * n + this.xy * n2, this.yx * n + this.yy * n2, n3);
                        }
                        case 6:
                        case 7: {
                            return new Point3D(this.xx * n + this.xy * n2, this.yx * n + this.yy * n2, n3);
                        }
                        case 4:
                        case 5: {
                            return new Point3D(this.xy * n2, this.yx * n, n3);
                        }
                        case 2:
                        case 3: {
                            return new Point3D(this.xx * n, this.yy * n2, n3);
                        }
                        case 0:
                        case 1: {
                            return new Point3D(n, n2, n3);
                        }
                    }
                    break;
                }
                case 1: {
                    return new Point3D(n, n2, n3);
                }
                case 2:
                case 3: {
                    return new Point3D(this.xx * n, this.yy * n2, this.zz * n3);
                }
                case 4: {
                    return new Point3D(this.xx * n + this.xy * n2 + this.xz * n3, this.yx * n + this.yy * n2 + this.yz * n3, this.zx * n + this.zy * n2 + this.zz * n3);
                }
            }
        }
        
        @Override
        public Point2D inverseTransform(final double n, final double n2) throws NonInvertibleTransformException {
            this.ensureCanTransform2DPoint();
            switch (this.state2d) {
                default: {
                    return super.inverseTransform(n, n2);
                }
                case 5: {
                    if (this.xy == 0.0 || this.yx == 0.0) {
                        throw new NonInvertibleTransformException("Determinant is 0");
                    }
                    return new Point2D(1.0 / this.yx * n2 - this.yt / this.yx, 1.0 / this.xy * n - this.xt / this.xy);
                }
                case 4: {
                    if (this.xy == 0.0 || this.yx == 0.0) {
                        throw new NonInvertibleTransformException("Determinant is 0");
                    }
                    return new Point2D(1.0 / this.yx * n2, 1.0 / this.xy * n);
                }
                case 3: {
                    if (this.xx == 0.0 || this.yy == 0.0) {
                        throw new NonInvertibleTransformException("Determinant is 0");
                    }
                    return new Point2D(1.0 / this.xx * n - this.xt / this.xx, 1.0 / this.yy * n2 - this.yt / this.yy);
                }
                case 2: {
                    if (this.xx == 0.0 || this.yy == 0.0) {
                        throw new NonInvertibleTransformException("Determinant is 0");
                    }
                    return new Point2D(1.0 / this.xx * n, 1.0 / this.yy * n2);
                }
                case 1: {
                    return new Point2D(n - this.xt, n2 - this.yt);
                }
                case 0: {
                    return new Point2D(n, n2);
                }
            }
        }
        
        @Override
        public Point3D inverseTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
            switch (this.state3d) {
                default: {
                    stateError();
                }
                case 0: {
                    switch (this.state2d) {
                        default: {
                            return super.inverseTransform(n, n2, n3);
                        }
                        case 5: {
                            if (this.xy == 0.0 || this.yx == 0.0) {
                                throw new NonInvertibleTransformException("Determinant is 0");
                            }
                            return new Point3D(1.0 / this.yx * n2 - this.yt / this.yx, 1.0 / this.xy * n - this.xt / this.xy, n3);
                        }
                        case 4: {
                            if (this.xy == 0.0 || this.yx == 0.0) {
                                throw new NonInvertibleTransformException("Determinant is 0");
                            }
                            return new Point3D(1.0 / this.yx * n2, 1.0 / this.xy * n, n3);
                        }
                        case 3: {
                            if (this.xx == 0.0 || this.yy == 0.0) {
                                throw new NonInvertibleTransformException("Determinant is 0");
                            }
                            return new Point3D(1.0 / this.xx * n - this.xt / this.xx, 1.0 / this.yy * n2 - this.yt / this.yy, n3);
                        }
                        case 2: {
                            if (this.xx == 0.0 || this.yy == 0.0) {
                                throw new NonInvertibleTransformException("Determinant is 0");
                            }
                            return new Point3D(1.0 / this.xx * n, 1.0 / this.yy * n2, n3);
                        }
                        case 1: {
                            return new Point3D(n - this.xt, n2 - this.yt, n3);
                        }
                        case 0: {
                            return new Point3D(n, n2, n3);
                        }
                    }
                    break;
                }
                case 1: {
                    return new Point3D(n - this.xt, n2 - this.yt, n3 - this.zt);
                }
                case 2: {
                    if (this.xx == 0.0 || this.yy == 0.0 || this.zz == 0.0) {
                        throw new NonInvertibleTransformException("Determinant is 0");
                    }
                    return new Point3D(1.0 / this.xx * n, 1.0 / this.yy * n2, 1.0 / this.zz * n3);
                }
                case 3: {
                    if (this.xx == 0.0 || this.yy == 0.0 || this.zz == 0.0) {
                        throw new NonInvertibleTransformException("Determinant is 0");
                    }
                    return new Point3D(1.0 / this.xx * n - this.xt / this.xx, 1.0 / this.yy * n2 - this.yt / this.yy, 1.0 / this.zz * n3 - this.zt / this.zz);
                }
                case 4: {
                    return super.inverseTransform(n, n2, n3);
                }
            }
        }
        
        @Override
        public Point2D inverseDeltaTransform(final double n, final double n2) throws NonInvertibleTransformException {
            this.ensureCanTransform2DPoint();
            switch (this.state2d) {
                default: {
                    return super.inverseDeltaTransform(n, n2);
                }
                case 4:
                case 5: {
                    if (this.xy == 0.0 || this.yx == 0.0) {
                        throw new NonInvertibleTransformException("Determinant is 0");
                    }
                    return new Point2D(1.0 / this.yx * n2, 1.0 / this.xy * n);
                }
                case 2:
                case 3: {
                    if (this.xx == 0.0 || this.yy == 0.0) {
                        throw new NonInvertibleTransformException("Determinant is 0");
                    }
                    return new Point2D(1.0 / this.xx * n, 1.0 / this.yy * n2);
                }
                case 0:
                case 1: {
                    return new Point2D(n, n2);
                }
            }
        }
        
        @Override
        public Point3D inverseDeltaTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
            switch (this.state3d) {
                default: {
                    stateError();
                }
                case 0: {
                    switch (this.state2d) {
                        default: {
                            return super.inverseDeltaTransform(n, n2, n3);
                        }
                        case 4:
                        case 5: {
                            if (this.xy == 0.0 || this.yx == 0.0) {
                                throw new NonInvertibleTransformException("Determinant is 0");
                            }
                            return new Point3D(1.0 / this.yx * n2, 1.0 / this.xy * n, n3);
                        }
                        case 2:
                        case 3: {
                            if (this.xx == 0.0 || this.yy == 0.0) {
                                throw new NonInvertibleTransformException("Determinant is 0");
                            }
                            return new Point3D(1.0 / this.xx * n, 1.0 / this.yy * n2, n3);
                        }
                        case 0:
                        case 1: {
                            return new Point3D(n, n2, n3);
                        }
                    }
                    break;
                }
                case 1: {
                    return new Point3D(n, n2, n3);
                }
                case 2:
                case 3: {
                    if (this.xx == 0.0 || this.yy == 0.0 || this.zz == 0.0) {
                        throw new NonInvertibleTransformException("Determinant is 0");
                    }
                    return new Point3D(1.0 / this.xx * n, 1.0 / this.yy * n2, 1.0 / this.zz * n3);
                }
                case 4: {
                    return super.inverseDeltaTransform(n, n2, n3);
                }
            }
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("Transform [\n");
            sb.append("\t").append(this.xx);
            sb.append(", ").append(this.xy);
            sb.append(", ").append(this.xz);
            sb.append(", ").append(this.xt);
            sb.append('\n');
            sb.append("\t").append(this.yx);
            sb.append(", ").append(this.yy);
            sb.append(", ").append(this.yz);
            sb.append(", ").append(this.yt);
            sb.append('\n');
            sb.append("\t").append(this.zx);
            sb.append(", ").append(this.zy);
            sb.append(", ").append(this.zz);
            sb.append(", ").append(this.zt);
            return sb.append("\n]").toString();
        }
        
        private void updateState() {
            this.updateState2D();
            this.state3d = 0;
            if (this.xz != 0.0 || this.yz != 0.0 || this.zx != 0.0 || this.zy != 0.0) {
                this.state3d = 4;
            }
            else if ((this.state2d & 0x4) == 0x0) {
                if (this.zt != 0.0) {
                    this.state3d |= 0x1;
                }
                if (this.zz != 1.0) {
                    this.state3d |= 0x2;
                }
                if (this.state3d != 0) {
                    this.state3d |= (this.state2d & 0x3);
                }
            }
            else if (this.zz != 1.0 || this.zt != 0.0) {
                this.state3d = 4;
            }
        }
        
        private void updateState2D() {
            if (this.xy == 0.0 && this.yx == 0.0) {
                if (this.xx == 1.0 && this.yy == 1.0) {
                    if (this.xt == 0.0 && this.yt == 0.0) {
                        this.state2d = 0;
                    }
                    else {
                        this.state2d = 1;
                    }
                }
                else if (this.xt == 0.0 && this.yt == 0.0) {
                    this.state2d = 2;
                }
                else {
                    this.state2d = 3;
                }
            }
            else if (this.xx == 0.0 && this.yy == 0.0) {
                if (this.xt == 0.0 && this.yt == 0.0) {
                    this.state2d = 4;
                }
                else {
                    this.state2d = 5;
                }
            }
            else if (this.xt == 0.0 && this.yt == 0.0) {
                this.state2d = 6;
            }
            else {
                this.state2d = 7;
            }
        }
        
        @Override
        void ensureCanTransform2DPoint() throws IllegalStateException {
            if (this.state3d != 0) {
                throw new IllegalStateException("Cannot transform 2D point with a 3D transform");
            }
        }
        
        private static void stateError() {
            throw new InternalError("missing case in a switch");
        }
        
        @Override
        void apply(final Affine3D affine3D) {
            affine3D.concatenate(this.xx, this.xy, this.xz, this.xt, this.yx, this.yy, this.yz, this.yt, this.zx, this.zy, this.zz, this.zt);
        }
        
        @Override
        BaseTransform derive(final BaseTransform baseTransform) {
            return baseTransform.deriveWithConcatenation(this.xx, this.xy, this.xz, this.xt, this.yx, this.yy, this.yz, this.yt, this.zx, this.zy, this.zz, this.zt);
        }
        
        int getState2d() {
            return this.state2d;
        }
        
        int getState3d() {
            return this.state3d;
        }
    }
}
