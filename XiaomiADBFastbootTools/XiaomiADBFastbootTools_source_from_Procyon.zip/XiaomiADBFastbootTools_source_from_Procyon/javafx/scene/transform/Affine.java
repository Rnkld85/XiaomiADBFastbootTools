// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.transform;

import javafx.beans.property.SimpleDoubleProperty;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.transform.Affine3D;
import javafx.geometry.Point3D;
import javafx.geometry.Point2D;
import javafx.beans.property.DoubleProperty;

public class Affine extends Transform
{
    AffineAtomicChange atomicChange;
    private static final int APPLY_IDENTITY = 0;
    private static final int APPLY_TRANSLATE = 1;
    private static final int APPLY_SCALE = 2;
    private static final int APPLY_SHEAR = 4;
    private static final int APPLY_NON_3D = 0;
    private static final int APPLY_3D_COMPLEX = 4;
    private transient int state2d;
    private transient int state3d;
    private double xx;
    private double xy;
    private double xz;
    private double yx;
    private double yy;
    private double yz;
    private double zx;
    private double zy;
    private double zz;
    private double xt;
    private double yt;
    private double zt;
    private AffineElementProperty mxx;
    private AffineElementProperty mxy;
    private AffineElementProperty mxz;
    private AffineElementProperty tx;
    private AffineElementProperty myx;
    private AffineElementProperty myy;
    private AffineElementProperty myz;
    private AffineElementProperty ty;
    private AffineElementProperty mzx;
    private AffineElementProperty mzy;
    private AffineElementProperty mzz;
    private AffineElementProperty tz;
    private static final int[] rot90conversion;
    
    public Affine() {
        this.atomicChange = new AffineAtomicChange();
        final double xx = 1.0;
        this.zz = xx;
        this.yy = xx;
        this.xx = xx;
    }
    
    public Affine(final Transform transform) {
        this(transform.getMxx(), transform.getMxy(), transform.getMxz(), transform.getTx(), transform.getMyx(), transform.getMyy(), transform.getMyz(), transform.getTy(), transform.getMzx(), transform.getMzy(), transform.getMzz(), transform.getTz());
    }
    
    public Affine(final double xx, final double xy, final double xt, final double yx, final double yy, final double yt) {
        this.atomicChange = new AffineAtomicChange();
        this.xx = xx;
        this.xy = xy;
        this.xt = xt;
        this.yx = yx;
        this.yy = yy;
        this.yt = yt;
        this.zz = 1.0;
        this.updateState2D();
    }
    
    public Affine(final double xx, final double xy, final double xz, final double xt, final double yx, final double yy, final double yz, final double yt, final double zx, final double zy, final double zz, final double zt) {
        this.atomicChange = new AffineAtomicChange();
        this.xx = xx;
        this.xy = xy;
        this.xz = xz;
        this.xt = xt;
        this.yx = yx;
        this.yy = yy;
        this.yz = yz;
        this.yt = yt;
        this.zx = zx;
        this.zy = zy;
        this.zz = zz;
        this.zt = zt;
        this.updateState();
    }
    
    public Affine(final double[] array, final MatrixType matrixType, int n) {
        this.atomicChange = new AffineAtomicChange();
        if (array.length < n + matrixType.elements()) {
            throw new IndexOutOfBoundsException("The array is too short.");
        }
        switch (matrixType) {
            default: {
                stateError();
            }
            case MT_2D_3x3: {
                if (array[n + 6] != 0.0 || array[n + 7] != 0.0 || array[n + 8] != 1.0) {
                    throw new IllegalArgumentException("The matrix is not affine");
                }
            }
            case MT_2D_2x3: {
                this.xx = array[n++];
                this.xy = array[n++];
                this.xt = array[n++];
                this.yx = array[n++];
                this.yy = array[n++];
                this.yt = array[n];
                this.zz = 1.0;
                this.updateState2D();
            }
            case MT_3D_4x4: {
                if (array[n + 12] != 0.0 || array[n + 13] != 0.0 || array[n + 14] != 0.0 || array[n + 15] != 1.0) {
                    throw new IllegalArgumentException("The matrix is not affine");
                }
            }
            case MT_3D_3x4: {
                this.xx = array[n++];
                this.xy = array[n++];
                this.xz = array[n++];
                this.xt = array[n++];
                this.yx = array[n++];
                this.yy = array[n++];
                this.yz = array[n++];
                this.yt = array[n++];
                this.zx = array[n++];
                this.zy = array[n++];
                this.zz = array[n++];
                this.zt = array[n];
                this.updateState();
            }
        }
    }
    
    public final void setMxx(final double xx) {
        if (this.mxx == null) {
            if (this.xx != xx) {
                this.xx = xx;
                this.postProcessChange();
            }
        }
        else {
            this.mxxProperty().set(xx);
        }
    }
    
    @Override
    public final double getMxx() {
        return (this.mxx == null) ? this.xx : this.mxx.get();
    }
    
    public final DoubleProperty mxxProperty() {
        if (this.mxx == null) {
            this.mxx = new AffineElementProperty(this.xx) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "mxx";
                }
            };
        }
        return this.mxx;
    }
    
    public final void setMxy(final double xy) {
        if (this.mxy == null) {
            if (this.xy != xy) {
                this.xy = xy;
                this.postProcessChange();
            }
        }
        else {
            this.mxyProperty().set(xy);
        }
    }
    
    @Override
    public final double getMxy() {
        return (this.mxy == null) ? this.xy : this.mxy.get();
    }
    
    public final DoubleProperty mxyProperty() {
        if (this.mxy == null) {
            this.mxy = new AffineElementProperty(this.xy) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "mxy";
                }
            };
        }
        return this.mxy;
    }
    
    public final void setMxz(final double xz) {
        if (this.mxz == null) {
            if (this.xz != xz) {
                this.xz = xz;
                this.postProcessChange();
            }
        }
        else {
            this.mxzProperty().set(xz);
        }
    }
    
    @Override
    public final double getMxz() {
        return (this.mxz == null) ? this.xz : this.mxz.get();
    }
    
    public final DoubleProperty mxzProperty() {
        if (this.mxz == null) {
            this.mxz = new AffineElementProperty(this.xz) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "mxz";
                }
            };
        }
        return this.mxz;
    }
    
    public final void setTx(final double xt) {
        if (this.tx == null) {
            if (this.xt != xt) {
                this.xt = xt;
                this.postProcessChange();
            }
        }
        else {
            this.txProperty().set(xt);
        }
    }
    
    @Override
    public final double getTx() {
        return (this.tx == null) ? this.xt : this.tx.get();
    }
    
    public final DoubleProperty txProperty() {
        if (this.tx == null) {
            this.tx = new AffineElementProperty(this.xt) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "tx";
                }
            };
        }
        return this.tx;
    }
    
    public final void setMyx(final double yx) {
        if (this.myx == null) {
            if (this.yx != yx) {
                this.yx = yx;
                this.postProcessChange();
            }
        }
        else {
            this.myxProperty().set(yx);
        }
    }
    
    @Override
    public final double getMyx() {
        return (this.myx == null) ? this.yx : this.myx.get();
    }
    
    public final DoubleProperty myxProperty() {
        if (this.myx == null) {
            this.myx = new AffineElementProperty(this.yx) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "myx";
                }
            };
        }
        return this.myx;
    }
    
    public final void setMyy(final double yy) {
        if (this.myy == null) {
            if (this.yy != yy) {
                this.yy = yy;
                this.postProcessChange();
            }
        }
        else {
            this.myyProperty().set(yy);
        }
    }
    
    @Override
    public final double getMyy() {
        return (this.myy == null) ? this.yy : this.myy.get();
    }
    
    public final DoubleProperty myyProperty() {
        if (this.myy == null) {
            this.myy = new AffineElementProperty(this.yy) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "myy";
                }
            };
        }
        return this.myy;
    }
    
    public final void setMyz(final double yz) {
        if (this.myz == null) {
            if (this.yz != yz) {
                this.yz = yz;
                this.postProcessChange();
            }
        }
        else {
            this.myzProperty().set(yz);
        }
    }
    
    @Override
    public final double getMyz() {
        return (this.myz == null) ? this.yz : this.myz.get();
    }
    
    public final DoubleProperty myzProperty() {
        if (this.myz == null) {
            this.myz = new AffineElementProperty(this.yz) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "myz";
                }
            };
        }
        return this.myz;
    }
    
    public final void setTy(final double yt) {
        if (this.ty == null) {
            if (this.yt != yt) {
                this.yt = yt;
                this.postProcessChange();
            }
        }
        else {
            this.tyProperty().set(yt);
        }
    }
    
    @Override
    public final double getTy() {
        return (this.ty == null) ? this.yt : this.ty.get();
    }
    
    public final DoubleProperty tyProperty() {
        if (this.ty == null) {
            this.ty = new AffineElementProperty(this.yt) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "ty";
                }
            };
        }
        return this.ty;
    }
    
    public final void setMzx(final double zx) {
        if (this.mzx == null) {
            if (this.zx != zx) {
                this.zx = zx;
                this.postProcessChange();
            }
        }
        else {
            this.mzxProperty().set(zx);
        }
    }
    
    @Override
    public final double getMzx() {
        return (this.mzx == null) ? this.zx : this.mzx.get();
    }
    
    public final DoubleProperty mzxProperty() {
        if (this.mzx == null) {
            this.mzx = new AffineElementProperty(this.zx) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "mzx";
                }
            };
        }
        return this.mzx;
    }
    
    public final void setMzy(final double zy) {
        if (this.mzy == null) {
            if (this.zy != zy) {
                this.zy = zy;
                this.postProcessChange();
            }
        }
        else {
            this.mzyProperty().set(zy);
        }
    }
    
    @Override
    public final double getMzy() {
        return (this.mzy == null) ? this.zy : this.mzy.get();
    }
    
    public final DoubleProperty mzyProperty() {
        if (this.mzy == null) {
            this.mzy = new AffineElementProperty(this.zy) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "mzy";
                }
            };
        }
        return this.mzy;
    }
    
    public final void setMzz(final double zz) {
        if (this.mzz == null) {
            if (this.zz != zz) {
                this.zz = zz;
                this.postProcessChange();
            }
        }
        else {
            this.mzzProperty().set(zz);
        }
    }
    
    @Override
    public final double getMzz() {
        return (this.mzz == null) ? this.zz : this.mzz.get();
    }
    
    public final DoubleProperty mzzProperty() {
        if (this.mzz == null) {
            this.mzz = new AffineElementProperty(this.zz) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "mzz";
                }
            };
        }
        return this.mzz;
    }
    
    public final void setTz(final double zt) {
        if (this.tz == null) {
            if (this.zt != zt) {
                this.zt = zt;
                this.postProcessChange();
            }
        }
        else {
            this.tzProperty().set(zt);
        }
    }
    
    @Override
    public final double getTz() {
        return (this.tz == null) ? this.zt : this.tz.get();
    }
    
    public final DoubleProperty tzProperty() {
        if (this.tz == null) {
            this.tz = new AffineElementProperty(this.zt) {
                @Override
                public Object getBean() {
                    return Affine.this;
                }
                
                @Override
                public String getName() {
                    return "tz";
                }
            };
        }
        return this.tz;
    }
    
    public void setElement(final MatrixType matrixType, final int n, final int n2, final double n3) {
        if (n < 0 || n >= matrixType.rows() || n2 < 0 || n2 >= matrixType.columns()) {
            throw new IndexOutOfBoundsException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/transform/MatrixType;II)Ljava/lang/String;, matrixType, n, n2));
        }
        Label_0556: {
            switch (matrixType) {
                default: {
                    stateError();
                }
                case MT_2D_3x3:
                case MT_2D_2x3: {
                    if (!this.isType2D()) {
                        throw new IllegalArgumentException("Cannot access 2D matrix of a 3D transform");
                    }
                    Label_0225: {
                        switch (n) {
                            case 0: {
                                switch (n2) {
                                    case 0: {
                                        this.setMxx(n3);
                                        return;
                                    }
                                    case 1: {
                                        this.setMxy(n3);
                                        return;
                                    }
                                    case 2: {
                                        this.setTx(n3);
                                        return;
                                    }
                                    default: {
                                        break Label_0225;
                                    }
                                }
                                break;
                            }
                            case 1: {
                                switch (n2) {
                                    case 0: {
                                        this.setMyx(n3);
                                        return;
                                    }
                                    case 1: {
                                        this.setMyy(n3);
                                        return;
                                    }
                                    case 2: {
                                        this.setTy(n3);
                                        return;
                                    }
                                    default: {
                                        break Label_0225;
                                    }
                                }
                                break;
                            }
                            case 2: {
                                switch (n2) {
                                    case 0: {
                                        if (n3 == 0.0) {
                                            return;
                                        }
                                        break Label_0225;
                                    }
                                    case 1: {
                                        if (n3 == 0.0) {
                                            return;
                                        }
                                        break Label_0225;
                                    }
                                    case 2: {
                                        if (n3 == 1.0) {
                                            return;
                                        }
                                        break Label_0225;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    break;
                }
                case MT_3D_4x4:
                case MT_3D_3x4: {
                    Label_0492: {
                        switch (n) {
                            case 0: {
                                switch (n2) {
                                    case 0: {
                                        this.setMxx(n3);
                                        return;
                                    }
                                    case 1: {
                                        this.setMxy(n3);
                                        return;
                                    }
                                    case 2: {
                                        this.setMxz(n3);
                                        return;
                                    }
                                    case 3: {
                                        this.setTx(n3);
                                        return;
                                    }
                                    default: {
                                        break Label_0492;
                                    }
                                }
                                break;
                            }
                            case 1: {
                                switch (n2) {
                                    case 0: {
                                        this.setMyx(n3);
                                        return;
                                    }
                                    case 1: {
                                        this.setMyy(n3);
                                        return;
                                    }
                                    case 2: {
                                        this.setMyz(n3);
                                        return;
                                    }
                                    case 3: {
                                        this.setTy(n3);
                                        return;
                                    }
                                    default: {
                                        break Label_0492;
                                    }
                                }
                                break;
                            }
                            case 2: {
                                switch (n2) {
                                    case 0: {
                                        this.setMzx(n3);
                                        return;
                                    }
                                    case 1: {
                                        this.setMzy(n3);
                                        return;
                                    }
                                    case 2: {
                                        this.setMzz(n3);
                                        return;
                                    }
                                    case 3: {
                                        this.setTz(n3);
                                        return;
                                    }
                                    default: {
                                        break Label_0492;
                                    }
                                }
                                break;
                            }
                            case 3: {
                                switch (n2) {
                                    case 0: {
                                        if (n3 == 0.0) {
                                            return;
                                        }
                                        break Label_0556;
                                    }
                                    case 1: {
                                        if (n3 == 0.0) {
                                            return;
                                        }
                                        break Label_0556;
                                    }
                                    case 2: {
                                        if (n3 == 0.0) {
                                            return;
                                        }
                                        break Label_0556;
                                    }
                                    case 3: {
                                        if (n3 == 1.0) {
                                            return;
                                        }
                                        break Label_0556;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
        throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljavafx/scene/transform/MatrixType;IID)Ljava/lang/String;, matrixType, n, n2, n3));
    }
    
    private void postProcessChange() {
        if (!this.atomicChange.runs()) {
            this.updateState();
            this.transformChanged();
        }
    }
    
    @Override
    boolean computeIs2D() {
        return this.state3d == 0;
    }
    
    @Override
    boolean computeIsIdentity() {
        return this.state3d == 0 && this.state2d == 0;
    }
    
    @Override
    public double determinant() {
        if (this.state3d == 0) {
            return this.getDeterminant2D();
        }
        return this.getDeterminant3D();
    }
    
    private double getDeterminant2D() {
        switch (this.state2d) {
            default: {
                stateError();
                return this.getMxx() * this.getMyy() - this.getMxy() * this.getMyx();
            }
            case 6:
            case 7: {
                return this.getMxx() * this.getMyy() - this.getMxy() * this.getMyx();
            }
            case 4:
            case 5: {
                return -(this.getMxy() * this.getMyx());
            }
            case 2:
            case 3: {
                return this.getMxx() * this.getMyy();
            }
            case 0:
            case 1: {
                return 1.0;
            }
        }
    }
    
    private double getDeterminant3D() {
        switch (this.state3d) {
            default: {
                stateError();
                return 1.0;
            }
            case 1: {
                return 1.0;
            }
            case 2:
            case 3: {
                return this.getMxx() * this.getMyy() * this.getMzz();
            }
            case 4: {
                final double myx = this.getMyx();
                final double myy = this.getMyy();
                final double myz = this.getMyz();
                final double mzx = this.getMzx();
                final double mzy = this.getMzy();
                final double mzz = this.getMzz();
                return this.getMxx() * (myy * mzz - mzy * myz) + this.getMxy() * (myz * mzx - mzz * myx) + this.getMxz() * (myx * mzy - mzx * myy);
            }
        }
    }
    
    @Override
    public Transform createConcatenation(final Transform transform) {
        final Affine clone = this.clone();
        clone.append(transform);
        return clone;
    }
    
    @Override
    public Affine createInverse() throws NonInvertibleTransformException {
        final Affine clone = this.clone();
        clone.invert();
        return clone;
    }
    
    @Override
    public Affine clone() {
        return new Affine(this);
    }
    
    public void setToTransform(final Transform transform) {
        this.setToTransform(transform.getMxx(), transform.getMxy(), transform.getMxz(), transform.getTx(), transform.getMyx(), transform.getMyy(), transform.getMyz(), transform.getTy(), transform.getMzx(), transform.getMzy(), transform.getMzz(), transform.getTz());
    }
    
    public void setToTransform(final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        this.setToTransform(n, n2, 0.0, n3, n4, n5, 0.0, n6, 0.0, 0.0, 1.0, 0.0);
    }
    
    public void setToTransform(final double mxx, final double mxy, final double mxz, final double tx, final double myx, final double myy, final double myz, final double ty, final double mzx, final double mzy, final double mzz, final double tz) {
        this.atomicChange.start();
        this.setMxx(mxx);
        this.setMxy(mxy);
        this.setMxz(mxz);
        this.setTx(tx);
        this.setMyx(myx);
        this.setMyy(myy);
        this.setMyz(myz);
        this.setTy(ty);
        this.setMzx(mzx);
        this.setMzy(mzy);
        this.setMzz(mzz);
        this.setTz(tz);
        this.updateState();
        this.atomicChange.end();
    }
    
    public void setToTransform(final double[] array, final MatrixType matrixType, int n) {
        if (array.length < n + matrixType.elements()) {
            throw new IndexOutOfBoundsException("The array is too short.");
        }
        switch (matrixType) {
            default: {
                stateError();
            }
            case MT_2D_3x3: {
                if (array[n + 6] != 0.0 || array[n + 7] != 0.0 || array[n + 8] != 1.0) {
                    throw new IllegalArgumentException("The matrix is not affine");
                }
            }
            case MT_2D_2x3: {
                this.setToTransform(array[n++], array[n++], array[n++], array[n++], array[n++], array[n++]);
            }
            case MT_3D_4x4: {
                if (array[n + 12] != 0.0 || array[n + 13] != 0.0 || array[n + 14] != 0.0 || array[n + 15] != 1.0) {
                    throw new IllegalArgumentException("The matrix is not affine");
                }
            }
            case MT_3D_3x4: {
                this.setToTransform(array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++]);
            }
        }
    }
    
    public void setToIdentity() {
        this.atomicChange.start();
        if (this.state3d != 0) {
            this.setMxx(1.0);
            this.setMxy(0.0);
            this.setMxz(0.0);
            this.setTx(0.0);
            this.setMyx(0.0);
            this.setMyy(1.0);
            this.setMyz(0.0);
            this.setTy(0.0);
            this.setMzx(0.0);
            this.setMzy(0.0);
            this.setMzz(1.0);
            this.setTz(0.0);
            this.state3d = 0;
            this.state2d = 0;
        }
        else if (this.state2d != 0) {
            this.setMxx(1.0);
            this.setMxy(0.0);
            this.setTx(0.0);
            this.setMyx(0.0);
            this.setMyy(1.0);
            this.setTy(0.0);
            this.state2d = 0;
        }
        this.atomicChange.end();
    }
    
    public void invert() throws NonInvertibleTransformException {
        this.atomicChange.start();
        if (this.state3d == 0) {
            this.invert2D();
            this.updateState2D();
        }
        else {
            this.invert3D();
            this.updateState();
        }
        this.atomicChange.end();
    }
    
    private void invert2D() throws NonInvertibleTransformException {
        switch (this.state2d) {
            default: {
                stateError();
            }
            case 7: {
                final double mxx = this.getMxx();
                final double mxy = this.getMxy();
                final double tx = this.getTx();
                final double myx = this.getMyx();
                final double myy = this.getMyy();
                final double ty = this.getTy();
                final double determinant2D = this.getDeterminant2D();
                if (determinant2D == 0.0) {
                    this.atomicChange.cancel();
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                this.setMxx(myy / determinant2D);
                this.setMyx(-myx / determinant2D);
                this.setMxy(-mxy / determinant2D);
                this.setMyy(mxx / determinant2D);
                this.setTx((mxy * ty - myy * tx) / determinant2D);
                this.setTy((myx * tx - mxx * ty) / determinant2D);
            }
            case 6: {
                final double mxx2 = this.getMxx();
                final double mxy2 = this.getMxy();
                final double myx2 = this.getMyx();
                final double myy2 = this.getMyy();
                final double determinant2D2 = this.getDeterminant2D();
                if (determinant2D2 == 0.0) {
                    this.atomicChange.cancel();
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                this.setMxx(myy2 / determinant2D2);
                this.setMyx(-myx2 / determinant2D2);
                this.setMxy(-mxy2 / determinant2D2);
                this.setMyy(mxx2 / determinant2D2);
            }
            case 5: {
                final double mxy3 = this.getMxy();
                final double tx2 = this.getTx();
                final double myx3 = this.getMyx();
                final double ty2 = this.getTy();
                if (mxy3 == 0.0 || myx3 == 0.0) {
                    this.atomicChange.cancel();
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                this.setMyx(1.0 / mxy3);
                this.setMxy(1.0 / myx3);
                this.setTx(-ty2 / myx3);
                this.setTy(-tx2 / mxy3);
            }
            case 4: {
                final double mxy4 = this.getMxy();
                final double myx4 = this.getMyx();
                if (mxy4 == 0.0 || myx4 == 0.0) {
                    this.atomicChange.cancel();
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                this.setMyx(1.0 / mxy4);
                this.setMxy(1.0 / myx4);
            }
            case 3: {
                final double mxx3 = this.getMxx();
                final double tx3 = this.getTx();
                final double myy3 = this.getMyy();
                final double ty3 = this.getTy();
                if (mxx3 == 0.0 || myy3 == 0.0) {
                    this.atomicChange.cancel();
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                this.setMxx(1.0 / mxx3);
                this.setMyy(1.0 / myy3);
                this.setTx(-tx3 / mxx3);
                this.setTy(-ty3 / myy3);
            }
            case 2: {
                final double mxx4 = this.getMxx();
                final double myy4 = this.getMyy();
                if (mxx4 == 0.0 || myy4 == 0.0) {
                    this.atomicChange.cancel();
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                this.setMxx(1.0 / mxx4);
                this.setMyy(1.0 / myy4);
            }
            case 1: {
                this.setTx(-this.getTx());
                this.setTy(-this.getTy());
            }
            case 0: {}
        }
    }
    
    private void invert3D() throws NonInvertibleTransformException {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 1: {
                this.setTx(-this.getTx());
                this.setTy(-this.getTy());
                this.setTz(-this.getTz());
            }
            case 2: {
                final double mxx = this.getMxx();
                final double myy = this.getMyy();
                final double mzz = this.getMzz();
                if (mxx == 0.0 || myy == 0.0 || mzz == 0.0) {
                    this.atomicChange.cancel();
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                this.setMxx(1.0 / mxx);
                this.setMyy(1.0 / myy);
                this.setMzz(1.0 / mzz);
            }
            case 3: {
                final double mxx2 = this.getMxx();
                final double tx = this.getTx();
                final double myy2 = this.getMyy();
                final double ty = this.getTy();
                final double mzz2 = this.getMzz();
                final double tz = this.getTz();
                if (mxx2 == 0.0 || myy2 == 0.0 || mzz2 == 0.0) {
                    this.atomicChange.cancel();
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                this.setMxx(1.0 / mxx2);
                this.setMyy(1.0 / myy2);
                this.setMzz(1.0 / mzz2);
                this.setTx(-tx / mxx2);
                this.setTy(-ty / myy2);
                this.setTz(-tz / mzz2);
            }
            case 4: {
                final double mxx3 = this.getMxx();
                final double mxy = this.getMxy();
                final double mxz = this.getMxz();
                final double tx2 = this.getTx();
                final double myx = this.getMyx();
                final double myy3 = this.getMyy();
                final double myz = this.getMyz();
                final double ty2 = this.getTy();
                final double mzy = this.getMzy();
                final double mzx = this.getMzx();
                final double mzz3 = this.getMzz();
                final double tz2 = this.getTz();
                final double n = mxx3 * (myy3 * mzz3 - mzy * myz) + mxy * (myz * mzx - mzz3 * myx) + mxz * (myx * mzy - mzx * myy3);
                if (n == 0.0) {
                    this.atomicChange.cancel();
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                final double n2 = myy3 * mzz3 - myz * mzy;
                final double n3 = -myx * mzz3 + myz * mzx;
                final double n4 = myx * mzy - myy3 * mzx;
                final double n5 = -mxy * (myz * tz2 - mzz3 * ty2) - mxz * (ty2 * mzy - tz2 * myy3) - tx2 * (myy3 * mzz3 - mzy * myz);
                final double n6 = -mxy * mzz3 + mxz * mzy;
                final double n7 = mxx3 * mzz3 - mxz * mzx;
                final double n8 = -mxx3 * mzy + mxy * mzx;
                final double n9 = mxx3 * (myz * tz2 - mzz3 * ty2) + mxz * (ty2 * mzx - tz2 * myx) + tx2 * (myx * mzz3 - mzx * myz);
                final double n10 = mxy * myz - mxz * myy3;
                final double n11 = -mxx3 * myz + mxz * myx;
                final double n12 = mxx3 * myy3 - mxy * myx;
                final double n13 = -mxx3 * (myy3 * tz2 - mzy * ty2) - mxy * (ty2 * mzx - tz2 * myx) - tx2 * (myx * mzy - mzx * myy3);
                this.setMxx(n2 / n);
                this.setMxy(n6 / n);
                this.setMxz(n10 / n);
                this.setTx(n5 / n);
                this.setMyx(n3 / n);
                this.setMyy(n7 / n);
                this.setMyz(n11 / n);
                this.setTy(n9 / n);
                this.setMzx(n4 / n);
                this.setMzy(n8 / n);
                this.setMzz(n12 / n);
                this.setTz(n13 / n);
            }
        }
    }
    
    public void append(final Transform transform) {
        transform.appendTo(this);
    }
    
    public void append(final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        if (this.state3d == 0) {
            this.atomicChange.start();
            final double mxx = this.getMxx();
            final double mxy = this.getMxy();
            final double myx = this.getMyx();
            final double myy = this.getMyy();
            this.setMxx(mxx * n + mxy * n4);
            this.setMxy(mxx * n2 + mxy * n5);
            this.setTx(mxx * n3 + mxy * n6 + this.getTx());
            this.setMyx(myx * n + myy * n4);
            this.setMyy(myx * n2 + myy * n5);
            this.setTy(myx * n3 + myy * n6 + this.getTy());
            this.updateState();
            this.atomicChange.end();
        }
        else {
            this.append(n, n2, 0.0, n3, n4, n5, 0.0, n6, 0.0, 0.0, 1.0, 0.0);
        }
    }
    
    public void append(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final double n8, final double n9, final double n10, final double n11, final double n12) {
        this.atomicChange.start();
        final double mxx = this.getMxx();
        final double mxy = this.getMxy();
        final double mxz = this.getMxz();
        final double tx = this.getTx();
        final double myx = this.getMyx();
        final double myy = this.getMyy();
        final double myz = this.getMyz();
        final double ty = this.getTy();
        final double mzx = this.getMzx();
        final double mzy = this.getMzy();
        final double mzz = this.getMzz();
        final double tz = this.getTz();
        this.setMxx(mxx * n + mxy * n5 + mxz * n9);
        this.setMxy(mxx * n2 + mxy * n6 + mxz * n10);
        this.setMxz(mxx * n3 + mxy * n7 + mxz * n11);
        this.setTx(mxx * n4 + mxy * n8 + mxz * n12 + tx);
        this.setMyx(myx * n + myy * n5 + myz * n9);
        this.setMyy(myx * n2 + myy * n6 + myz * n10);
        this.setMyz(myx * n3 + myy * n7 + myz * n11);
        this.setTy(myx * n4 + myy * n8 + myz * n12 + ty);
        this.setMzx(mzx * n + mzy * n5 + mzz * n9);
        this.setMzy(mzx * n2 + mzy * n6 + mzz * n10);
        this.setMzz(mzx * n3 + mzy * n7 + mzz * n11);
        this.setTz(mzx * n4 + mzy * n8 + mzz * n12 + tz);
        this.updateState();
        this.atomicChange.end();
    }
    
    public void append(final double[] array, final MatrixType matrixType, int n) {
        if (array.length < n + matrixType.elements()) {
            throw new IndexOutOfBoundsException("The array is too short.");
        }
        switch (matrixType) {
            default: {
                stateError();
            }
            case MT_2D_3x3: {
                if (array[n + 6] != 0.0 || array[n + 7] != 0.0 || array[n + 8] != 1.0) {
                    throw new IllegalArgumentException("The matrix is not affine");
                }
            }
            case MT_2D_2x3: {
                this.append(array[n++], array[n++], array[n++], array[n++], array[n++], array[n++]);
            }
            case MT_3D_4x4: {
                if (array[n + 12] != 0.0 || array[n + 13] != 0.0 || array[n + 14] != 0.0 || array[n + 15] != 1.0) {
                    throw new IllegalArgumentException("The matrix is not affine");
                }
            }
            case MT_3D_3x4: {
                this.append(array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++]);
            }
        }
    }
    
    @Override
    void appendTo(final Affine affine) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                switch (this.state2d) {
                    case 0: {
                        return;
                    }
                    case 1: {
                        affine.appendTranslation(this.getTx(), this.getTy());
                        return;
                    }
                    case 2: {
                        affine.appendScale(this.getMxx(), this.getMyy());
                        return;
                    }
                    case 3: {
                        affine.appendTranslation(this.getTx(), this.getTy());
                        affine.appendScale(this.getMxx(), this.getMyy());
                        return;
                    }
                    default: {
                        affine.append(this.getMxx(), this.getMxy(), this.getTx(), this.getMyx(), this.getMyy(), this.getTy());
                        return;
                    }
                }
                break;
            }
            case 1: {
                affine.appendTranslation(this.getTx(), this.getTy(), this.getTz());
            }
            case 2: {
                affine.appendScale(this.getMxx(), this.getMyy(), this.getMzz());
            }
            case 3: {
                affine.appendTranslation(this.getTx(), this.getTy(), this.getTz());
                affine.appendScale(this.getMxx(), this.getMyy(), this.getMzz());
            }
            case 4: {
                affine.append(this.getMxx(), this.getMxy(), this.getMxz(), this.getTx(), this.getMyx(), this.getMyy(), this.getMyz(), this.getTy(), this.getMzx(), this.getMzy(), this.getMzz(), this.getTz());
            }
        }
    }
    
    public void prepend(final Transform transform) {
        transform.prependTo(this);
    }
    
    public void prepend(final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        if (this.state3d == 0) {
            this.atomicChange.start();
            final double mxx = this.getMxx();
            final double mxy = this.getMxy();
            final double tx = this.getTx();
            final double myx = this.getMyx();
            final double myy = this.getMyy();
            final double ty = this.getTy();
            this.setMxx(n * mxx + n2 * myx);
            this.setMxy(n * mxy + n2 * myy);
            this.setTx(n * tx + n2 * ty + n3);
            this.setMyx(n4 * mxx + n5 * myx);
            this.setMyy(n4 * mxy + n5 * myy);
            this.setTy(n4 * tx + n5 * ty + n6);
            this.updateState2D();
            this.atomicChange.end();
        }
        else {
            this.prepend(n, n2, 0.0, n3, n4, n5, 0.0, n6, 0.0, 0.0, 1.0, 0.0);
        }
    }
    
    public void prepend(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final double n8, final double n9, final double n10, final double n11, final double n12) {
        this.atomicChange.start();
        final double mxx = this.getMxx();
        final double mxy = this.getMxy();
        final double mxz = this.getMxz();
        final double tx = this.getTx();
        final double myx = this.getMyx();
        final double myy = this.getMyy();
        final double myz = this.getMyz();
        final double ty = this.getTy();
        final double mzx = this.getMzx();
        final double mzy = this.getMzy();
        final double mzz = this.getMzz();
        final double tz = this.getTz();
        this.setMxx(n * mxx + n2 * myx + n3 * mzx);
        this.setMxy(n * mxy + n2 * myy + n3 * mzy);
        this.setMxz(n * mxz + n2 * myz + n3 * mzz);
        this.setTx(n * tx + n2 * ty + n3 * tz + n4);
        this.setMyx(n5 * mxx + n6 * myx + n7 * mzx);
        this.setMyy(n5 * mxy + n6 * myy + n7 * mzy);
        this.setMyz(n5 * mxz + n6 * myz + n7 * mzz);
        this.setTy(n5 * tx + n6 * ty + n7 * tz + n8);
        this.setMzx(n9 * mxx + n10 * myx + n11 * mzx);
        this.setMzy(n9 * mxy + n10 * myy + n11 * mzy);
        this.setMzz(n9 * mxz + n10 * myz + n11 * mzz);
        this.setTz(n9 * tx + n10 * ty + n11 * tz + n12);
        this.updateState();
        this.atomicChange.end();
    }
    
    public void prepend(final double[] array, final MatrixType matrixType, int n) {
        if (array.length < n + matrixType.elements()) {
            throw new IndexOutOfBoundsException("The array is too short.");
        }
        switch (matrixType) {
            default: {
                stateError();
            }
            case MT_2D_3x3: {
                if (array[n + 6] != 0.0 || array[n + 7] != 0.0 || array[n + 8] != 1.0) {
                    throw new IllegalArgumentException("The matrix is not affine");
                }
            }
            case MT_2D_2x3: {
                this.prepend(array[n++], array[n++], array[n++], array[n++], array[n++], array[n++]);
            }
            case MT_3D_4x4: {
                if (array[n + 12] != 0.0 || array[n + 13] != 0.0 || array[n + 14] != 0.0 || array[n + 15] != 1.0) {
                    throw new IllegalArgumentException("The matrix is not affine");
                }
            }
            case MT_3D_3x4: {
                this.prepend(array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++], array[n++]);
            }
        }
    }
    
    @Override
    void prependTo(final Affine affine) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                switch (this.state2d) {
                    case 0: {
                        return;
                    }
                    case 1: {
                        affine.prependTranslation(this.getTx(), this.getTy());
                        return;
                    }
                    case 2: {
                        affine.prependScale(this.getMxx(), this.getMyy());
                        return;
                    }
                    case 3: {
                        affine.prependScale(this.getMxx(), this.getMyy());
                        affine.prependTranslation(this.getTx(), this.getTy());
                        return;
                    }
                    default: {
                        affine.prepend(this.getMxx(), this.getMxy(), this.getTx(), this.getMyx(), this.getMyy(), this.getTy());
                        return;
                    }
                }
                break;
            }
            case 1: {
                affine.prependTranslation(this.getTx(), this.getTy(), this.getTz());
            }
            case 2: {
                affine.prependScale(this.getMxx(), this.getMyy(), this.getMzz());
            }
            case 3: {
                affine.prependScale(this.getMxx(), this.getMyy(), this.getMzz());
                affine.prependTranslation(this.getTx(), this.getTy(), this.getTz());
            }
            case 4: {
                affine.prepend(this.getMxx(), this.getMxy(), this.getMxz(), this.getTx(), this.getMyx(), this.getMyy(), this.getMyz(), this.getTy(), this.getMzx(), this.getMzy(), this.getMzz(), this.getTz());
            }
        }
    }
    
    public void appendTranslation(final double n, final double n2) {
        this.atomicChange.start();
        this.translate2D(n, n2);
        this.atomicChange.end();
    }
    
    public void appendTranslation(final double n, final double n2, final double n3) {
        this.atomicChange.start();
        this.translate3D(n, n2, n3);
        this.atomicChange.end();
    }
    
    private void translate2D(final double tx, final double ty) {
        if (this.state3d != 0) {
            this.translate3D(tx, ty, 0.0);
            return;
        }
        switch (this.state2d) {
            default: {
                stateError();
            }
            case 7: {
                this.setTx(tx * this.getMxx() + ty * this.getMxy() + this.getTx());
                this.setTy(tx * this.getMyx() + ty * this.getMyy() + this.getTy());
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    this.state2d = 6;
                }
            }
            case 6: {
                this.setTx(tx * this.getMxx() + ty * this.getMxy());
                this.setTy(tx * this.getMyx() + ty * this.getMyy());
                if (this.getTx() != 0.0 || this.getTy() != 0.0) {
                    this.state2d = 7;
                }
            }
            case 5: {
                this.setTx(ty * this.getMxy() + this.getTx());
                this.setTy(tx * this.getMyx() + this.getTy());
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    this.state2d = 4;
                }
            }
            case 4: {
                this.setTx(ty * this.getMxy());
                this.setTy(tx * this.getMyx());
                if (this.getTx() != 0.0 || this.getTy() != 0.0) {
                    this.state2d = 5;
                }
            }
            case 3: {
                this.setTx(tx * this.getMxx() + this.getTx());
                this.setTy(ty * this.getMyy() + this.getTy());
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    this.state2d = 2;
                }
            }
            case 2: {
                this.setTx(tx * this.getMxx());
                this.setTy(ty * this.getMyy());
                if (this.getTx() != 0.0 || this.getTy() != 0.0) {
                    this.state2d = 3;
                }
            }
            case 1: {
                this.setTx(tx + this.getTx());
                this.setTy(ty + this.getTy());
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    this.state2d = 0;
                }
            }
            case 0: {
                this.setTx(tx);
                this.setTy(ty);
                if (tx != 0.0 || ty != 0.0) {
                    this.state2d = 1;
                }
            }
        }
    }
    
    private void translate3D(final double n, final double n2, final double tz) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                this.translate2D(n, n2);
                if (tz != 0.0) {
                    this.setTz(tz);
                    if ((this.state2d & 0x4) == 0x0) {
                        this.state3d = ((this.state2d & 0x2) | 0x1);
                    }
                    else {
                        this.state3d = 4;
                    }
                }
            }
            case 1: {
                this.setTx(n + this.getTx());
                this.setTy(n2 + this.getTy());
                this.setTz(tz + this.getTz());
                if (this.getTz() == 0.0) {
                    this.state3d = 0;
                    if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                        this.state2d = 0;
                    }
                    else {
                        this.state2d = 1;
                    }
                }
            }
            case 2: {
                this.setTx(n * this.getMxx());
                this.setTy(n2 * this.getMyy());
                this.setTz(tz * this.getMzz());
                if (this.getTx() != 0.0 || this.getTy() != 0.0 || this.getTz() != 0.0) {
                    this.state3d |= 0x1;
                }
            }
            case 3: {
                this.setTx(n * this.getMxx() + this.getTx());
                this.setTy(n2 * this.getMyy() + this.getTy());
                this.setTz(tz * this.getMzz() + this.getTz());
                if (this.getTz() == 0.0) {
                    if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                        this.state3d = 2;
                    }
                    if (this.getMzz() == 1.0) {
                        this.state2d = this.state3d;
                        this.state3d = 0;
                    }
                }
            }
            case 4: {
                this.setTx(n * this.getMxx() + n2 * this.getMxy() + tz * this.getMxz() + this.getTx());
                this.setTy(n * this.getMyx() + n2 * this.getMyy() + tz * this.getMyz() + this.getTy());
                this.setTz(n * this.getMzx() + n2 * this.getMzy() + tz * this.getMzz() + this.getTz());
                this.updateState();
            }
        }
    }
    
    public void prependTranslation(final double n, final double n2, final double n3) {
        this.atomicChange.start();
        this.preTranslate3D(n, n2, n3);
        this.atomicChange.end();
    }
    
    public void prependTranslation(final double n, final double n2) {
        this.atomicChange.start();
        this.preTranslate2D(n, n2);
        this.atomicChange.end();
    }
    
    private void preTranslate2D(final double n, final double n2) {
        if (this.state3d != 0) {
            this.preTranslate3D(n, n2, 0.0);
            return;
        }
        this.setTx(this.getTx() + n);
        this.setTy(this.getTy() + n2);
        if (this.getTx() == 0.0 && this.getTy() == 0.0) {
            this.state2d &= 0xFFFFFFFE;
        }
        else {
            this.state2d |= 0x1;
        }
    }
    
    private void preTranslate3D(final double tx, final double ty, final double n) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                this.preTranslate2D(tx, ty);
                if (n != 0.0) {
                    this.setTz(n);
                    if ((this.state2d & 0x4) == 0x0) {
                        this.state3d = ((this.state2d & 0x2) | 0x1);
                    }
                    else {
                        this.state3d = 4;
                    }
                }
            }
            case 1: {
                this.setTx(this.getTx() + tx);
                this.setTy(this.getTy() + ty);
                this.setTz(this.getTz() + n);
                if (this.getTz() == 0.0) {
                    this.state3d = 0;
                    if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                        this.state2d = 0;
                    }
                    else {
                        this.state2d = 1;
                    }
                }
            }
            case 2: {
                this.setTx(tx);
                this.setTy(ty);
                this.setTz(n);
                if (tx != 0.0 || ty != 0.0 || n != 0.0) {
                    this.state3d |= 0x1;
                }
            }
            case 3: {
                this.setTx(this.getTx() + tx);
                this.setTy(this.getTy() + ty);
                this.setTz(this.getTz() + n);
                if (this.getTz() == 0.0) {
                    if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                        this.state3d = 2;
                    }
                    if (this.getMzz() == 1.0) {
                        this.state2d = this.state3d;
                        this.state3d = 0;
                    }
                }
            }
            case 4: {
                this.setTx(this.getTx() + tx);
                this.setTy(this.getTy() + ty);
                this.setTz(this.getTz() + n);
                if (this.getTz() == 0.0 && this.getMxz() == 0.0 && this.getMyz() == 0.0 && this.getMzx() == 0.0 && this.getMzy() == 0.0 && this.getMzz() == 1.0) {
                    this.state3d = 0;
                    this.updateState2D();
                }
            }
        }
    }
    
    public void appendScale(final double n, final double n2) {
        this.atomicChange.start();
        this.scale2D(n, n2);
        this.atomicChange.end();
    }
    
    public void appendScale(final double n, final double n2, final double n3, final double n4) {
        this.atomicChange.start();
        if (n3 != 0.0 || n4 != 0.0) {
            this.translate2D(n3, n4);
            this.scale2D(n, n2);
            this.translate2D(-n3, -n4);
        }
        else {
            this.scale2D(n, n2);
        }
        this.atomicChange.end();
    }
    
    public void appendScale(final double n, final double n2, final Point2D point2D) {
        this.appendScale(n, n2, point2D.getX(), point2D.getY());
    }
    
    public void appendScale(final double n, final double n2, final double n3) {
        this.atomicChange.start();
        this.scale3D(n, n2, n3);
        this.atomicChange.end();
    }
    
    public void appendScale(final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        this.atomicChange.start();
        if (n4 != 0.0 || n5 != 0.0 || n6 != 0.0) {
            this.translate3D(n4, n5, n6);
            this.scale3D(n, n2, n3);
            this.translate3D(-n4, -n5, -n6);
        }
        else {
            this.scale3D(n, n2, n3);
        }
        this.atomicChange.end();
    }
    
    public void appendScale(final double n, final double n2, final double n3, final Point3D point3D) {
        this.appendScale(n, n2, n3, point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    private void scale2D(final double mxx, final double myy) {
        if (this.state3d != 0) {
            this.scale3D(mxx, myy, 1.0);
            return;
        }
        final int state2d = this.state2d;
        switch (state2d) {
            default: {
                stateError();
            }
            case 6:
            case 7: {
                this.setMxx(this.getMxx() * mxx);
                this.setMyy(this.getMyy() * myy);
            }
            case 4:
            case 5: {
                this.setMxy(this.getMxy() * myy);
                this.setMyx(this.getMyx() * mxx);
                if (this.getMxy() == 0.0 && this.getMyx() == 0.0) {
                    int state2d2 = state2d & 0x1;
                    if (this.getMxx() != 1.0 || this.getMyy() != 1.0) {
                        state2d2 |= 0x2;
                    }
                    this.state2d = state2d2;
                }
                else if (this.getMxx() == 0.0 && this.getMyy() == 0.0) {
                    this.state2d &= 0xFFFFFFFD;
                }
            }
            case 2:
            case 3: {
                this.setMxx(this.getMxx() * mxx);
                this.setMyy(this.getMyy() * myy);
                if (this.getMxx() == 1.0 && this.getMyy() == 1.0) {
                    this.state2d = (state2d & 0x1);
                }
            }
            case 0:
            case 1: {
                this.setMxx(mxx);
                this.setMyy(myy);
                if (mxx != 1.0 || myy != 1.0) {
                    this.state2d = (state2d | 0x2);
                }
            }
        }
    }
    
    private void scale3D(final double mxx, final double myy, final double n) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                this.scale2D(mxx, myy);
                if (n != 1.0) {
                    this.setMzz(n);
                    if ((this.state2d & 0x4) == 0x0) {
                        this.state3d = ((this.state2d & 0x1) | 0x2);
                    }
                    else {
                        this.state3d = 4;
                    }
                }
            }
            case 1: {
                this.setMxx(mxx);
                this.setMyy(myy);
                this.setMzz(n);
                if (mxx != 1.0 || myy != 1.0 || n != 1.0) {
                    this.state3d |= 0x2;
                }
            }
            case 2: {
                this.setMxx(this.getMxx() * mxx);
                this.setMyy(this.getMyy() * myy);
                this.setMzz(this.getMzz() * n);
                if (this.getMzz() == 1.0) {
                    this.state3d = 0;
                    if (this.getMxx() == 1.0 && this.getMyy() == 1.0) {
                        this.state2d = 0;
                    }
                    else {
                        this.state2d = 2;
                    }
                }
            }
            case 3: {
                this.setMxx(this.getMxx() * mxx);
                this.setMyy(this.getMyy() * myy);
                this.setMzz(this.getMzz() * n);
                if (this.getMxx() == 1.0 && this.getMyy() == 1.0 && this.getMzz() == 1.0) {
                    this.state3d &= 0xFFFFFFFD;
                }
                if (this.getTz() == 0.0 && this.getMzz() == 1.0) {
                    this.state2d = this.state3d;
                    this.state3d = 0;
                }
            }
            case 4: {
                this.setMxx(this.getMxx() * mxx);
                this.setMxy(this.getMxy() * myy);
                this.setMxz(this.getMxz() * n);
                this.setMyx(this.getMyx() * mxx);
                this.setMyy(this.getMyy() * myy);
                this.setMyz(this.getMyz() * n);
                this.setMzx(this.getMzx() * mxx);
                this.setMzy(this.getMzy() * myy);
                this.setMzz(this.getMzz() * n);
                if (mxx == 0.0 || myy == 0.0 || n == 0.0) {
                    this.updateState();
                }
            }
        }
    }
    
    public void prependScale(final double n, final double n2) {
        this.atomicChange.start();
        this.preScale2D(n, n2);
        this.atomicChange.end();
    }
    
    public void prependScale(final double n, final double n2, final double n3, final double n4) {
        this.atomicChange.start();
        if (n3 != 0.0 || n4 != 0.0) {
            this.preTranslate2D(-n3, -n4);
            this.preScale2D(n, n2);
            this.preTranslate2D(n3, n4);
        }
        else {
            this.preScale2D(n, n2);
        }
        this.atomicChange.end();
    }
    
    public void prependScale(final double n, final double n2, final Point2D point2D) {
        this.prependScale(n, n2, point2D.getX(), point2D.getY());
    }
    
    public void prependScale(final double n, final double n2, final double n3) {
        this.atomicChange.start();
        this.preScale3D(n, n2, n3);
        this.atomicChange.end();
    }
    
    public void prependScale(final double n, final double n2, final double n3, final double n4, final double n5, final double n6) {
        this.atomicChange.start();
        if (n4 != 0.0 || n5 != 0.0 || n6 != 0.0) {
            this.preTranslate3D(-n4, -n5, -n6);
            this.preScale3D(n, n2, n3);
            this.preTranslate3D(n4, n5, n6);
        }
        else {
            this.preScale3D(n, n2, n3);
        }
        this.atomicChange.end();
    }
    
    public void prependScale(final double n, final double n2, final double n3, final Point3D point3D) {
        this.prependScale(n, n2, n3, point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    private void preScale2D(final double mxx, final double myy) {
        if (this.state3d != 0) {
            this.preScale3D(mxx, myy, 1.0);
            return;
        }
        int state2d = this.state2d;
        switch (state2d) {
            default: {
                stateError();
            }
            case 7: {
                this.setTx(this.getTx() * mxx);
                this.setTy(this.getTy() * myy);
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    state2d &= 0xFFFFFFFE;
                    this.state2d = state2d;
                }
            }
            case 6: {
                this.setMxx(this.getMxx() * mxx);
                this.setMyy(this.getMyy() * myy);
            }
            case 4: {
                this.setMxy(this.getMxy() * mxx);
                this.setMyx(this.getMyx() * myy);
                if (this.getMxy() == 0.0 && this.getMyx() == 0.0) {
                    int state2d2 = state2d & 0x1;
                    if (this.getMxx() != 1.0 || this.getMyy() != 1.0) {
                        state2d2 |= 0x2;
                    }
                    this.state2d = state2d2;
                }
            }
            case 5: {
                this.setTx(this.getTx() * mxx);
                this.setTy(this.getTy() * myy);
                this.setMxy(this.getMxy() * mxx);
                this.setMyx(this.getMyx() * myy);
                if (this.getMxy() == 0.0 && this.getMyx() == 0.0) {
                    if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                        this.state2d = 2;
                    }
                    else {
                        this.state2d = 3;
                    }
                }
                else if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    this.state2d = 4;
                }
            }
            case 3: {
                this.setTx(this.getTx() * mxx);
                this.setTy(this.getTy() * myy);
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    state2d &= 0xFFFFFFFE;
                    this.state2d = state2d;
                }
            }
            case 2: {
                this.setMxx(this.getMxx() * mxx);
                this.setMyy(this.getMyy() * myy);
                if (this.getMxx() == 1.0 && this.getMyy() == 1.0) {
                    this.state2d = (state2d & 0x1);
                }
            }
            case 1: {
                this.setTx(this.getTx() * mxx);
                this.setTy(this.getTy() * myy);
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    state2d &= 0xFFFFFFFE;
                    this.state2d = state2d;
                }
            }
            case 0: {
                this.setMxx(mxx);
                this.setMyy(myy);
                if (mxx != 1.0 || myy != 1.0) {
                    this.state2d = (state2d | 0x2);
                }
            }
        }
    }
    
    private void preScale3D(final double mxx, final double myy, final double n) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                this.preScale2D(mxx, myy);
                if (n != 1.0) {
                    this.setMzz(n);
                    if ((this.state2d & 0x4) == 0x0) {
                        this.state3d = ((this.state2d & 0x1) | 0x2);
                    }
                    else {
                        this.state3d = 4;
                    }
                }
            }
            case 3: {
                this.setTx(this.getTx() * mxx);
                this.setTy(this.getTy() * myy);
                this.setTz(this.getTz() * n);
                this.setMxx(this.getMxx() * mxx);
                this.setMyy(this.getMyy() * myy);
                this.setMzz(this.getMzz() * n);
                if (this.getTx() == 0.0 && this.getTy() == 0.0 && this.getTz() == 0.0) {
                    this.state3d &= 0xFFFFFFFE;
                }
                if (this.getMxx() == 1.0 && this.getMyy() == 1.0 && this.getMzz() == 1.0) {
                    this.state3d &= 0xFFFFFFFD;
                }
                if (this.getTz() == 0.0 && this.getMzz() == 1.0) {
                    this.state2d = this.state3d;
                    this.state3d = 0;
                }
            }
            case 2: {
                this.setMxx(this.getMxx() * mxx);
                this.setMyy(this.getMyy() * myy);
                this.setMzz(this.getMzz() * n);
                if (this.getMzz() == 1.0) {
                    this.state3d = 0;
                    if (this.getMxx() == 1.0 && this.getMyy() == 1.0) {
                        this.state2d = 0;
                    }
                    else {
                        this.state2d = 2;
                    }
                }
            }
            case 1: {
                this.setTx(this.getTx() * mxx);
                this.setTy(this.getTy() * myy);
                this.setTz(this.getTz() * n);
                this.setMxx(mxx);
                this.setMyy(myy);
                this.setMzz(n);
                if (this.getTx() == 0.0 && this.getTy() == 0.0 && this.getTz() == 0.0) {
                    this.state3d &= 0xFFFFFFFE;
                }
                if (mxx != 1.0 || myy != 1.0 || n != 1.0) {
                    this.state3d |= 0x2;
                }
            }
            case 4: {
                this.setMxx(this.getMxx() * mxx);
                this.setMxy(this.getMxy() * mxx);
                this.setMxz(this.getMxz() * mxx);
                this.setTx(this.getTx() * mxx);
                this.setMyx(this.getMyx() * myy);
                this.setMyy(this.getMyy() * myy);
                this.setMyz(this.getMyz() * myy);
                this.setTy(this.getTy() * myy);
                this.setMzx(this.getMzx() * n);
                this.setMzy(this.getMzy() * n);
                this.setMzz(this.getMzz() * n);
                this.setTz(this.getTz() * n);
                if (mxx == 0.0 || myy == 0.0 || n == 0.0) {
                    this.updateState();
                }
            }
        }
    }
    
    public void appendShear(final double n, final double n2) {
        this.atomicChange.start();
        this.shear2D(n, n2);
        this.atomicChange.end();
    }
    
    public void appendShear(final double n, final double n2, final double n3, final double n4) {
        this.atomicChange.start();
        if (n3 != 0.0 || n4 != 0.0) {
            this.translate2D(n3, n4);
            this.shear2D(n, n2);
            this.translate2D(-n3, -n4);
        }
        else {
            this.shear2D(n, n2);
        }
        this.atomicChange.end();
    }
    
    public void appendShear(final double n, final double n2, final Point2D point2D) {
        this.appendShear(n, n2, point2D.getX(), point2D.getY());
    }
    
    private void shear2D(final double mxy, final double myx) {
        if (this.state3d != 0) {
            this.shear3D(mxy, myx);
            return;
        }
        final int state2d = this.state2d;
        switch (state2d) {
            default: {
                stateError();
            }
            case 6:
            case 7: {
                final double mxx = this.getMxx();
                final double mxy2 = this.getMxy();
                this.setMxx(mxx + mxy2 * myx);
                this.setMxy(mxx * mxy + mxy2);
                final double myx2 = this.getMyx();
                final double myy = this.getMyy();
                this.setMyx(myx2 + myy * myx);
                this.setMyy(myx2 * mxy + myy);
                this.updateState2D();
            }
            case 4:
            case 5: {
                this.setMxx(this.getMxy() * myx);
                this.setMyy(this.getMyx() * mxy);
                if (this.getMxx() != 0.0 || this.getMyy() != 0.0) {
                    this.state2d = (state2d | 0x2);
                }
            }
            case 2:
            case 3: {
                this.setMxy(this.getMxx() * mxy);
                this.setMyx(this.getMyy() * myx);
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state2d = (state2d | 0x4);
                }
            }
            case 0:
            case 1: {
                this.setMxy(mxy);
                this.setMyx(myx);
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state2d = (state2d | 0x2 | 0x4);
                }
            }
        }
    }
    
    private void shear3D(final double mxy, final double myx) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                this.shear2D(mxy, myx);
            }
            case 1: {
                this.setMxy(mxy);
                this.setMyx(myx);
                if (mxy != 0.0 || myx != 0.0) {
                    this.state3d = 4;
                }
            }
            case 2:
            case 3: {
                this.setMxy(this.getMxx() * mxy);
                this.setMyx(this.getMyy() * myx);
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state3d = 4;
                }
            }
            case 4: {
                final double mxx = this.getMxx();
                final double mxy2 = this.getMxy();
                final double myx2 = this.getMyx();
                final double myy = this.getMyy();
                final double mzx = this.getMzx();
                final double mzy = this.getMzy();
                this.setMxx(mxx + mxy2 * myx);
                this.setMxy(mxy2 + mxx * mxy);
                this.setMyx(myx2 + myy * myx);
                this.setMyy(myy + myx2 * mxy);
                this.setMzx(mzx + mzy * myx);
                this.setMzy(mzy + mzx * mxy);
                this.updateState();
            }
        }
    }
    
    public void prependShear(final double n, final double n2) {
        this.atomicChange.start();
        this.preShear2D(n, n2);
        this.atomicChange.end();
    }
    
    public void prependShear(final double n, final double n2, final double n3, final double n4) {
        this.atomicChange.start();
        if (n3 != 0.0 || n4 != 0.0) {
            this.preTranslate2D(-n3, -n4);
            this.preShear2D(n, n2);
            this.preTranslate2D(n3, n4);
        }
        else {
            this.preShear2D(n, n2);
        }
        this.atomicChange.end();
    }
    
    public void prependShear(final double n, final double n2, final Point2D point2D) {
        this.prependShear(n, n2, point2D.getX(), point2D.getY());
    }
    
    private void preShear2D(final double mxy, final double myx) {
        if (this.state3d != 0) {
            this.preShear3D(mxy, myx);
            return;
        }
        int state2d = this.state2d;
        switch (state2d) {
            default: {
                stateError();
            }
            case 5:
            case 7: {
                final double tx = this.getTx();
                final double ty = this.getTy();
                this.setTx(tx + mxy * ty);
                this.setTy(ty + myx * tx);
            }
            case 4:
            case 6: {
                final double mxx = this.getMxx();
                final double mxy2 = this.getMxy();
                final double myx2 = this.getMyx();
                final double myy = this.getMyy();
                this.setMxx(mxx + mxy * myx2);
                this.setMxy(mxy2 + mxy * myy);
                this.setMyx(myx * mxx + myx2);
                this.setMyy(myx * mxy2 + myy);
                this.updateState2D();
            }
            case 3: {
                final double tx2 = this.getTx();
                final double ty2 = this.getTy();
                this.setTx(tx2 + mxy * ty2);
                this.setTy(ty2 + myx * tx2);
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    state2d &= 0xFFFFFFFE;
                    this.state2d = state2d;
                }
            }
            case 2: {
                this.setMxy(mxy * this.getMyy());
                this.setMyx(myx * this.getMxx());
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state2d = (state2d | 0x4);
                }
            }
            case 1: {
                final double tx3 = this.getTx();
                final double ty3 = this.getTy();
                this.setTx(tx3 + mxy * ty3);
                this.setTy(ty3 + myx * tx3);
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    state2d &= 0xFFFFFFFE;
                    this.state2d = state2d;
                }
            }
            case 0: {
                this.setMxy(mxy);
                this.setMyx(myx);
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state2d = (state2d | 0x2 | 0x4);
                }
            }
        }
    }
    
    private void preShear3D(final double mxy, final double myx) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                this.preShear2D(mxy, myx);
            }
            case 1: {
                final double tx = this.getTx();
                this.setMxy(mxy);
                this.setTx(tx + this.getTy() * mxy);
                this.setMyx(myx);
                this.setTy(tx * myx + this.getTy());
                if (mxy != 0.0 || myx != 0.0) {
                    this.state3d = 4;
                }
            }
            case 2: {
                this.setMxy(this.getMyy() * mxy);
                this.setMyx(this.getMxx() * myx);
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state3d = 4;
                }
            }
            case 3: {
                final double tx2 = this.getTx();
                this.setMxy(this.getMyy() * mxy);
                this.setTx(tx2 + this.getTy() * mxy);
                this.setMyx(this.getMxx() * myx);
                this.setTy(tx2 * myx + this.getTy());
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state3d = 4;
                }
            }
            case 4: {
                final double mxx = this.getMxx();
                final double mxy2 = this.getMxy();
                final double myx2 = this.getMyx();
                final double tx3 = this.getTx();
                final double myy = this.getMyy();
                final double mxz = this.getMxz();
                final double myz = this.getMyz();
                final double ty = this.getTy();
                this.setMxx(mxx + myx2 * mxy);
                this.setMxy(mxy2 + myy * mxy);
                this.setMxz(mxz + myz * mxy);
                this.setTx(tx3 + ty * mxy);
                this.setMyx(mxx * myx + myx2);
                this.setMyy(mxy2 * myx + myy);
                this.setMyz(mxz * myx + myz);
                this.setTy(tx3 * myx + ty);
                this.updateState();
            }
        }
    }
    
    public void appendRotation(final double n) {
        this.atomicChange.start();
        this.rotate2D(n);
        this.atomicChange.end();
    }
    
    public void appendRotation(final double n, final double n2, final double n3) {
        this.atomicChange.start();
        if (n2 != 0.0 || n3 != 0.0) {
            this.translate2D(n2, n3);
            this.rotate2D(n);
            this.translate2D(-n2, -n3);
        }
        else {
            this.rotate2D(n);
        }
        this.atomicChange.end();
    }
    
    public void appendRotation(final double n, final Point2D point2D) {
        this.appendRotation(n, point2D.getX(), point2D.getY());
    }
    
    public void appendRotation(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7) {
        this.atomicChange.start();
        if (n2 != 0.0 || n3 != 0.0 || n4 != 0.0) {
            this.translate3D(n2, n3, n4);
            this.rotate3D(n, n5, n6, n7);
            this.translate3D(-n2, -n3, -n4);
        }
        else {
            this.rotate3D(n, n5, n6, n7);
        }
        this.atomicChange.end();
    }
    
    public void appendRotation(final double n, final double n2, final double n3, final double n4, final Point3D point3D) {
        this.appendRotation(n, n2, n3, n4, point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public void appendRotation(final double n, final Point3D point3D, final Point3D point3D2) {
        this.appendRotation(n, point3D.getX(), point3D.getY(), point3D.getZ(), point3D2.getX(), point3D2.getY(), point3D2.getZ());
    }
    
    private void rotate3D(final double n, final double n2, final double n3, final double n4) {
        if (n2 == 0.0 && n3 == 0.0) {
            if (n4 > 0.0) {
                this.rotate3D(n);
            }
            else if (n4 < 0.0) {
                this.rotate3D(-n);
            }
            return;
        }
        final double sqrt = Math.sqrt(n2 * n2 + n3 * n3 + n4 * n4);
        if (sqrt == 0.0) {
            return;
        }
        final double n5 = 1.0 / sqrt;
        final double n6 = n2 * n5;
        final double n7 = n3 * n5;
        final double n8 = n4 * n5;
        final double sin = Math.sin(Math.toRadians(n));
        final double cos = Math.cos(Math.toRadians(n));
        final double n9 = 1.0 - cos;
        final double n10 = n6 * n8;
        final double n11 = n6 * n7;
        final double n12 = n7 * n8;
        final double n13 = n9 * n6 * n6 + cos;
        final double n14 = n9 * n11 - sin * n8;
        final double n15 = n9 * n10 + sin * n7;
        final double n16 = n9 * n11 + sin * n8;
        final double n17 = n9 * n7 * n7 + cos;
        final double n18 = n9 * n12 - sin * n6;
        final double mzx = n9 * n10 - sin * n7;
        final double mzy = n9 * n12 + sin * n6;
        final double mzz = n9 * n8 * n8 + cos;
        Label_1119: {
            switch (this.state3d) {
                default: {
                    stateError();
                }
                case 0: {
                    switch (this.state2d) {
                        default: {
                            stateError();
                        }
                        case 6:
                        case 7: {
                            final double mxx = this.getMxx();
                            final double mxy = this.getMxy();
                            final double myx = this.getMyx();
                            final double myy = this.getMyy();
                            this.setMxx(mxx * n13 + mxy * n16);
                            this.setMxy(mxx * n14 + mxy * n17);
                            this.setMxz(mxx * n15 + mxy * n18);
                            this.setMyx(myx * n13 + myy * n16);
                            this.setMyy(myx * n14 + myy * n17);
                            this.setMyz(myx * n15 + myy * n18);
                            this.setMzx(mzx);
                            this.setMzy(mzy);
                            this.setMzz(mzz);
                            break Label_1119;
                        }
                        case 4:
                        case 5: {
                            final double mxy2 = this.getMxy();
                            final double myx2 = this.getMyx();
                            this.setMxx(mxy2 * n16);
                            this.setMxy(mxy2 * n17);
                            this.setMxz(mxy2 * n18);
                            this.setMyx(myx2 * n13);
                            this.setMyy(myx2 * n14);
                            this.setMyz(myx2 * n15);
                            this.setMzx(mzx);
                            this.setMzy(mzy);
                            this.setMzz(mzz);
                            break Label_1119;
                        }
                        case 2:
                        case 3: {
                            final double mxx2 = this.getMxx();
                            final double myy2 = this.getMyy();
                            this.setMxx(mxx2 * n13);
                            this.setMxy(mxx2 * n14);
                            this.setMxz(mxx2 * n15);
                            this.setMyx(myy2 * n16);
                            this.setMyy(myy2 * n17);
                            this.setMyz(myy2 * n18);
                            this.setMzx(mzx);
                            this.setMzy(mzy);
                            this.setMzz(mzz);
                            break Label_1119;
                        }
                        case 0:
                        case 1: {
                            this.setMxx(n13);
                            this.setMxy(n14);
                            this.setMxz(n15);
                            this.setMyx(n16);
                            this.setMyy(n17);
                            this.setMyz(n18);
                            this.setMzx(mzx);
                            this.setMzy(mzy);
                            this.setMzz(mzz);
                            break Label_1119;
                        }
                    }
                    break;
                }
                case 1: {
                    this.setMxx(n13);
                    this.setMxy(n14);
                    this.setMxz(n15);
                    this.setMyx(n16);
                    this.setMyy(n17);
                    this.setMyz(n18);
                    this.setMzx(mzx);
                    this.setMzy(mzy);
                    this.setMzz(mzz);
                    break;
                }
                case 2:
                case 3: {
                    final double mxx3 = this.getMxx();
                    final double myy3 = this.getMyy();
                    final double mzz2 = this.getMzz();
                    this.setMxx(mxx3 * n13);
                    this.setMxy(mxx3 * n14);
                    this.setMxz(mxx3 * n15);
                    this.setMyx(myy3 * n16);
                    this.setMyy(myy3 * n17);
                    this.setMyz(myy3 * n18);
                    this.setMzx(mzz2 * mzx);
                    this.setMzy(mzz2 * mzy);
                    this.setMzz(mzz2 * mzz);
                    break;
                }
                case 4: {
                    final double mxx4 = this.getMxx();
                    final double mxy3 = this.getMxy();
                    final double mxz = this.getMxz();
                    final double myx3 = this.getMyx();
                    final double myy4 = this.getMyy();
                    final double myz = this.getMyz();
                    final double mzx2 = this.getMzx();
                    final double mzy2 = this.getMzy();
                    final double mzz3 = this.getMzz();
                    this.setMxx(mxx4 * n13 + mxy3 * n16 + mxz * mzx);
                    this.setMxy(mxx4 * n14 + mxy3 * n17 + mxz * mzy);
                    this.setMxz(mxx4 * n15 + mxy3 * n18 + mxz * mzz);
                    this.setMyx(myx3 * n13 + myy4 * n16 + myz * mzx);
                    this.setMyy(myx3 * n14 + myy4 * n17 + myz * mzy);
                    this.setMyz(myx3 * n15 + myy4 * n18 + myz * mzz);
                    this.setMzx(mzx2 * n13 + mzy2 * n16 + mzz3 * mzx);
                    this.setMzy(mzx2 * n14 + mzy2 * n17 + mzz3 * mzy);
                    this.setMzz(mzx2 * n15 + mzy2 * n18 + mzz3 * mzz);
                    break;
                }
            }
        }
        this.updateState();
    }
    
    private void rotate2D(final double n) {
        if (this.state3d != 0) {
            this.rotate3D(n);
            return;
        }
        final double sin = Math.sin(Math.toRadians(n));
        if (sin == 1.0) {
            this.rotate2D_90();
        }
        else if (sin == -1.0) {
            this.rotate2D_270();
        }
        else {
            final double cos = Math.cos(Math.toRadians(n));
            if (cos == -1.0) {
                this.rotate2D_180();
            }
            else if (cos != 1.0) {
                final double mxx = this.getMxx();
                final double mxy = this.getMxy();
                this.setMxx(cos * mxx + sin * mxy);
                this.setMxy(-sin * mxx + cos * mxy);
                final double myx = this.getMyx();
                final double myy = this.getMyy();
                this.setMyx(cos * myx + sin * myy);
                this.setMyy(-sin * myx + cos * myy);
                this.updateState2D();
            }
        }
    }
    
    private void rotate2D_90() {
        final double mxx = this.getMxx();
        this.setMxx(this.getMxy());
        this.setMxy(-mxx);
        final double myx = this.getMyx();
        this.setMyx(this.getMyy());
        this.setMyy(-myx);
        int state2d = Affine.rot90conversion[this.state2d];
        if ((state2d & 0x6) == 0x2 && this.getMxx() == 1.0 && this.getMyy() == 1.0) {
            state2d -= 2;
        }
        else if ((state2d & 0x6) == 0x4 && this.getMxy() == 0.0 && this.getMyx() == 0.0) {
            state2d = ((state2d & 0xFFFFFFFB) | 0x2);
        }
        this.state2d = state2d;
    }
    
    private void rotate2D_180() {
        this.setMxx(-this.getMxx());
        this.setMyy(-this.getMyy());
        final int state2d = this.state2d;
        if ((state2d & 0x4) != 0x0) {
            this.setMxy(-this.getMxy());
            this.setMyx(-this.getMyx());
        }
        else if (this.getMxx() == 1.0 && this.getMyy() == 1.0) {
            this.state2d = (state2d & 0xFFFFFFFD);
        }
        else {
            this.state2d = (state2d | 0x2);
        }
    }
    
    private void rotate2D_270() {
        final double mxx = this.getMxx();
        this.setMxx(-this.getMxy());
        this.setMxy(mxx);
        final double myx = this.getMyx();
        this.setMyx(-this.getMyy());
        this.setMyy(myx);
        int state2d = Affine.rot90conversion[this.state2d];
        if ((state2d & 0x6) == 0x2 && this.getMxx() == 1.0 && this.getMyy() == 1.0) {
            state2d -= 2;
        }
        else if ((state2d & 0x6) == 0x4 && this.getMxy() == 0.0 && this.getMyx() == 0.0) {
            state2d = ((state2d & 0xFFFFFFFB) | 0x2);
        }
        this.state2d = state2d;
    }
    
    private void rotate3D(final double n) {
        if (this.state3d == 0) {
            this.rotate2D(n);
            return;
        }
        final double sin = Math.sin(Math.toRadians(n));
        if (sin == 1.0) {
            this.rotate3D_90();
        }
        else if (sin == -1.0) {
            this.rotate3D_270();
        }
        else {
            final double cos = Math.cos(Math.toRadians(n));
            if (cos == -1.0) {
                this.rotate3D_180();
            }
            else if (cos != 1.0) {
                final double mxx = this.getMxx();
                final double mxy = this.getMxy();
                this.setMxx(cos * mxx + sin * mxy);
                this.setMxy(-sin * mxx + cos * mxy);
                final double myx = this.getMyx();
                final double myy = this.getMyy();
                this.setMyx(cos * myx + sin * myy);
                this.setMyy(-sin * myx + cos * myy);
                final double mzx = this.getMzx();
                final double mzy = this.getMzy();
                this.setMzx(cos * mzx + sin * mzy);
                this.setMzy(-sin * mzx + cos * mzy);
                this.updateState();
            }
        }
    }
    
    private void rotate3D_90() {
        final double mxx = this.getMxx();
        this.setMxx(this.getMxy());
        this.setMxy(-mxx);
        final double myx = this.getMyx();
        this.setMyx(this.getMyy());
        this.setMyy(-myx);
        final double mzx = this.getMzx();
        this.setMzx(this.getMzy());
        this.setMzy(-mzx);
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 1: {
                this.state3d = 4;
            }
            case 2:
            case 3: {
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state3d = 4;
                }
            }
            case 4: {
                this.updateState();
            }
        }
    }
    
    private void rotate3D_180() {
        final double mxx = this.getMxx();
        final double myy = this.getMyy();
        this.setMxx(-mxx);
        this.setMyy(-myy);
        if (this.state3d == 4) {
            this.setMxy(-this.getMxy());
            this.setMyx(-this.getMyx());
            this.setMzx(-this.getMzx());
            this.setMzy(-this.getMzy());
            this.updateState();
            return;
        }
        if (mxx == -1.0 && myy == -1.0 && this.getMzz() == 1.0) {
            this.state3d &= 0xFFFFFFFD;
        }
        else {
            this.state3d |= 0x2;
        }
    }
    
    private void rotate3D_270() {
        final double mxx = this.getMxx();
        this.setMxx(-this.getMxy());
        this.setMxy(mxx);
        final double myx = this.getMyx();
        this.setMyx(-this.getMyy());
        this.setMyy(myx);
        final double mzx = this.getMzx();
        this.setMzx(-this.getMzy());
        this.setMzy(mzx);
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 1: {
                this.state3d = 4;
            }
            case 2:
            case 3: {
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state3d = 4;
                }
            }
            case 4: {
                this.updateState();
            }
        }
    }
    
    public void prependRotation(final double n) {
        this.atomicChange.start();
        this.preRotate2D(n);
        this.atomicChange.end();
    }
    
    public void prependRotation(final double n, final double n2, final double n3) {
        this.atomicChange.start();
        if (n2 != 0.0 || n3 != 0.0) {
            this.preTranslate2D(-n2, -n3);
            this.preRotate2D(n);
            this.preTranslate2D(n2, n3);
        }
        else {
            this.preRotate2D(n);
        }
        this.atomicChange.end();
    }
    
    public void prependRotation(final double n, final Point2D point2D) {
        this.prependRotation(n, point2D.getX(), point2D.getY());
    }
    
    public void prependRotation(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7) {
        this.atomicChange.start();
        if (n2 != 0.0 || n3 != 0.0 || n4 != 0.0) {
            this.preTranslate3D(-n2, -n3, -n4);
            this.preRotate3D(n, n5, n6, n7);
            this.preTranslate3D(n2, n3, n4);
        }
        else {
            this.preRotate3D(n, n5, n6, n7);
        }
        this.atomicChange.end();
    }
    
    public void prependRotation(final double n, final double n2, final double n3, final double n4, final Point3D point3D) {
        this.prependRotation(n, n2, n3, n4, point3D.getX(), point3D.getY(), point3D.getZ());
    }
    
    public void prependRotation(final double n, final Point3D point3D, final Point3D point3D2) {
        this.prependRotation(n, point3D.getX(), point3D.getY(), point3D.getZ(), point3D2.getX(), point3D2.getY(), point3D2.getZ());
    }
    
    private void preRotate3D(final double n, final double n2, final double n3, final double n4) {
        if (n2 == 0.0 && n3 == 0.0) {
            if (n4 > 0.0) {
                this.preRotate3D(n);
            }
            else if (n4 < 0.0) {
                this.preRotate3D(-n);
            }
            return;
        }
        final double sqrt = Math.sqrt(n2 * n2 + n3 * n3 + n4 * n4);
        if (sqrt == 0.0) {
            return;
        }
        final double n5 = 1.0 / sqrt;
        final double n6 = n2 * n5;
        final double n7 = n3 * n5;
        final double n8 = n4 * n5;
        final double sin = Math.sin(Math.toRadians(n));
        final double cos = Math.cos(Math.toRadians(n));
        final double n9 = 1.0 - cos;
        final double n10 = n6 * n8;
        final double n11 = n6 * n7;
        final double n12 = n7 * n8;
        final double mxx = n9 * n6 * n6 + cos;
        final double mxy = n9 * n11 - sin * n8;
        final double mxz = n9 * n10 + sin * n7;
        final double myx = n9 * n11 + sin * n8;
        final double myy = n9 * n7 * n7 + cos;
        final double myz = n9 * n12 - sin * n6;
        final double mzx = n9 * n10 - sin * n7;
        final double mzy = n9 * n12 + sin * n6;
        final double mzz = n9 * n8 * n8 + cos;
        Label_2058: {
            switch (this.state3d) {
                default: {
                    stateError();
                }
                case 0: {
                    switch (this.state2d) {
                        default: {
                            stateError();
                        }
                        case 7: {
                            final double mxx2 = this.getMxx();
                            final double mxy2 = this.getMxy();
                            final double tx = this.getTx();
                            final double myx2 = this.getMyx();
                            final double myy2 = this.getMyy();
                            final double ty = this.getTy();
                            this.setMxx(mxx * mxx2 + mxy * myx2);
                            this.setMxy(mxx * mxy2 + mxy * myy2);
                            this.setMxz(mxz);
                            this.setTx(mxx * tx + mxy * ty);
                            this.setMyx(myx * mxx2 + myy * myx2);
                            this.setMyy(myx * mxy2 + myy * myy2);
                            this.setMyz(myz);
                            this.setTy(myx * tx + myy * ty);
                            this.setMzx(mzx * mxx2 + mzy * myx2);
                            this.setMzy(mzx * mxy2 + mzy * myy2);
                            this.setMzz(mzz);
                            this.setTz(mzx * tx + mzy * ty);
                            break Label_2058;
                        }
                        case 6: {
                            final double mxx3 = this.getMxx();
                            final double mxy3 = this.getMxy();
                            final double myx3 = this.getMyx();
                            final double myy3 = this.getMyy();
                            this.setMxx(mxx * mxx3 + mxy * myx3);
                            this.setMxy(mxx * mxy3 + mxy * myy3);
                            this.setMxz(mxz);
                            this.setMyx(myx * mxx3 + myy * myx3);
                            this.setMyy(myx * mxy3 + myy * myy3);
                            this.setMyz(myz);
                            this.setMzx(mzx * mxx3 + mzy * myx3);
                            this.setMzy(mzx * mxy3 + mzy * myy3);
                            this.setMzz(mzz);
                            break Label_2058;
                        }
                        case 5: {
                            final double mxy4 = this.getMxy();
                            final double tx2 = this.getTx();
                            final double myx4 = this.getMyx();
                            final double ty2 = this.getTy();
                            this.setMxx(mxy * myx4);
                            this.setMxy(mxx * mxy4);
                            this.setMxz(mxz);
                            this.setTx(mxx * tx2 + mxy * ty2);
                            this.setMyx(myy * myx4);
                            this.setMyy(myx * mxy4);
                            this.setMyz(myz);
                            this.setTy(myx * tx2 + myy * ty2);
                            this.setMzx(mzy * myx4);
                            this.setMzy(mzx * mxy4);
                            this.setMzz(mzz);
                            this.setTz(mzx * tx2 + mzy * ty2);
                            break Label_2058;
                        }
                        case 4: {
                            final double mxy5 = this.getMxy();
                            final double myx5 = this.getMyx();
                            this.setMxx(mxy * myx5);
                            this.setMxy(mxx * mxy5);
                            this.setMxz(mxz);
                            this.setMyx(myy * myx5);
                            this.setMyy(myx * mxy5);
                            this.setMyz(myz);
                            this.setMzx(mzy * myx5);
                            this.setMzy(mzx * mxy5);
                            this.setMzz(mzz);
                            break Label_2058;
                        }
                        case 3: {
                            final double mxx4 = this.getMxx();
                            final double tx3 = this.getTx();
                            final double myy4 = this.getMyy();
                            final double ty3 = this.getTy();
                            this.setMxx(mxx * mxx4);
                            this.setMxy(mxy * myy4);
                            this.setMxz(mxz);
                            this.setTx(mxx * tx3 + mxy * ty3);
                            this.setMyx(myx * mxx4);
                            this.setMyy(myy * myy4);
                            this.setMyz(myz);
                            this.setTy(myx * tx3 + myy * ty3);
                            this.setMzx(mzx * mxx4);
                            this.setMzy(mzy * myy4);
                            this.setMzz(mzz);
                            this.setTz(mzx * tx3 + mzy * ty3);
                            break Label_2058;
                        }
                        case 2: {
                            final double mxx5 = this.getMxx();
                            final double myy5 = this.getMyy();
                            this.setMxx(mxx * mxx5);
                            this.setMxy(mxy * myy5);
                            this.setMxz(mxz);
                            this.setMyx(myx * mxx5);
                            this.setMyy(myy * myy5);
                            this.setMyz(myz);
                            this.setMzx(mzx * mxx5);
                            this.setMzy(mzy * myy5);
                            this.setMzz(mzz);
                            break Label_2058;
                        }
                        case 1: {
                            final double tx4 = this.getTx();
                            final double ty4 = this.getTy();
                            this.setMxx(mxx);
                            this.setMxy(mxy);
                            this.setMxz(mxz);
                            this.setTx(mxx * tx4 + mxy * ty4);
                            this.setMyx(myx);
                            this.setMyy(myy);
                            this.setMyz(myz);
                            this.setTy(myx * tx4 + myy * ty4);
                            this.setMzx(mzx);
                            this.setMzy(mzy);
                            this.setMzz(mzz);
                            this.setTz(mzx * tx4 + mzy * ty4);
                            break Label_2058;
                        }
                        case 0: {
                            this.setMxx(mxx);
                            this.setMxy(mxy);
                            this.setMxz(mxz);
                            this.setMyx(myx);
                            this.setMyy(myy);
                            this.setMyz(myz);
                            this.setMzx(mzx);
                            this.setMzy(mzy);
                            this.setMzz(mzz);
                            break Label_2058;
                        }
                    }
                    break;
                }
                case 1: {
                    final double tx5 = this.getTx();
                    final double ty5 = this.getTy();
                    final double tz = this.getTz();
                    this.setMxx(mxx);
                    this.setMxy(mxy);
                    this.setMxz(mxz);
                    this.setMyx(myx);
                    this.setMyy(myy);
                    this.setMyz(myz);
                    this.setMzx(mzx);
                    this.setMzy(mzy);
                    this.setMzz(mzz);
                    this.setTx(mxx * tx5 + mxy * ty5 + mxz * tz);
                    this.setTy(myx * tx5 + myy * ty5 + myz * tz);
                    this.setTz(mzx * tx5 + mzy * ty5 + mzz * tz);
                    break;
                }
                case 2: {
                    final double mxx6 = this.getMxx();
                    final double myy6 = this.getMyy();
                    final double mzz2 = this.getMzz();
                    this.setMxx(mxx * mxx6);
                    this.setMxy(mxy * myy6);
                    this.setMxz(mxz * mzz2);
                    this.setMyx(myx * mxx6);
                    this.setMyy(myy * myy6);
                    this.setMyz(myz * mzz2);
                    this.setMzx(mzx * mxx6);
                    this.setMzy(mzy * myy6);
                    this.setMzz(mzz * mzz2);
                    break;
                }
                case 3: {
                    final double mxx7 = this.getMxx();
                    final double tx6 = this.getTx();
                    final double myy7 = this.getMyy();
                    final double ty6 = this.getTy();
                    final double mzz3 = this.getMzz();
                    final double tz2 = this.getTz();
                    this.setMxx(mxx * mxx7);
                    this.setMxy(mxy * myy7);
                    this.setMxz(mxz * mzz3);
                    this.setTx(mxx * tx6 + mxy * ty6 + mxz * tz2);
                    this.setMyx(myx * mxx7);
                    this.setMyy(myy * myy7);
                    this.setMyz(myz * mzz3);
                    this.setTy(myx * tx6 + myy * ty6 + myz * tz2);
                    this.setMzx(mzx * mxx7);
                    this.setMzy(mzy * myy7);
                    this.setMzz(mzz * mzz3);
                    this.setTz(mzx * tx6 + mzy * ty6 + mzz * tz2);
                    break;
                }
                case 4: {
                    final double mxx8 = this.getMxx();
                    final double mxy6 = this.getMxy();
                    final double mxz2 = this.getMxz();
                    final double tx7 = this.getTx();
                    final double myx6 = this.getMyx();
                    final double myy8 = this.getMyy();
                    final double myz2 = this.getMyz();
                    final double ty7 = this.getTy();
                    final double mzx2 = this.getMzx();
                    final double mzy2 = this.getMzy();
                    final double mzz4 = this.getMzz();
                    final double tz3 = this.getTz();
                    this.setMxx(mxx * mxx8 + mxy * myx6 + mxz * mzx2);
                    this.setMxy(mxx * mxy6 + mxy * myy8 + mxz * mzy2);
                    this.setMxz(mxx * mxz2 + mxy * myz2 + mxz * mzz4);
                    this.setTx(mxx * tx7 + mxy * ty7 + mxz * tz3);
                    this.setMyx(myx * mxx8 + myy * myx6 + myz * mzx2);
                    this.setMyy(myx * mxy6 + myy * myy8 + myz * mzy2);
                    this.setMyz(myx * mxz2 + myy * myz2 + myz * mzz4);
                    this.setTy(myx * tx7 + myy * ty7 + myz * tz3);
                    this.setMzx(mzx * mxx8 + mzy * myx6 + mzz * mzx2);
                    this.setMzy(mzx * mxy6 + mzy * myy8 + mzz * mzy2);
                    this.setMzz(mzx * mxz2 + mzy * myz2 + mzz * mzz4);
                    this.setTz(mzx * tx7 + mzy * ty7 + mzz * tz3);
                    break;
                }
            }
        }
        this.updateState();
    }
    
    private void preRotate2D(final double n) {
        if (this.state3d != 0) {
            this.preRotate3D(n);
            return;
        }
        final double sin = Math.sin(Math.toRadians(n));
        if (sin == 1.0) {
            this.preRotate2D_90();
        }
        else if (sin == -1.0) {
            this.preRotate2D_270();
        }
        else {
            final double cos = Math.cos(Math.toRadians(n));
            if (cos == -1.0) {
                this.preRotate2D_180();
            }
            else if (cos != 1.0) {
                final double mxx = this.getMxx();
                final double myx = this.getMyx();
                this.setMxx(cos * mxx - sin * myx);
                this.setMyx(sin * mxx + cos * myx);
                final double mxy = this.getMxy();
                final double myy = this.getMyy();
                this.setMxy(cos * mxy - sin * myy);
                this.setMyy(sin * mxy + cos * myy);
                final double tx = this.getTx();
                final double ty = this.getTy();
                this.setTx(cos * tx - sin * ty);
                this.setTy(sin * tx + cos * ty);
                this.updateState2D();
            }
        }
    }
    
    private void preRotate2D_90() {
        final double mxx = this.getMxx();
        this.setMxx(-this.getMyx());
        this.setMyx(mxx);
        final double mxy = this.getMxy();
        this.setMxy(-this.getMyy());
        this.setMyy(mxy);
        final double tx = this.getTx();
        this.setTx(-this.getTy());
        this.setTy(tx);
        int state2d = Affine.rot90conversion[this.state2d];
        if ((state2d & 0x6) == 0x2 && this.getMxx() == 1.0 && this.getMyy() == 1.0) {
            state2d -= 2;
        }
        else if ((state2d & 0x6) == 0x4 && this.getMxy() == 0.0 && this.getMyx() == 0.0) {
            state2d = ((state2d & 0xFFFFFFFB) | 0x2);
        }
        this.state2d = state2d;
    }
    
    private void preRotate2D_180() {
        this.setMxx(-this.getMxx());
        this.setMxy(-this.getMxy());
        this.setTx(-this.getTx());
        this.setMyx(-this.getMyx());
        this.setMyy(-this.getMyy());
        this.setTy(-this.getTy());
        if ((this.state2d & 0x4) != 0x0) {
            if (this.getMxx() == 0.0 && this.getMyy() == 0.0) {
                this.state2d &= 0xFFFFFFFD;
            }
            else {
                this.state2d |= 0x2;
            }
        }
        else if (this.getMxx() == 1.0 && this.getMyy() == 1.0) {
            this.state2d &= 0xFFFFFFFD;
        }
        else {
            this.state2d |= 0x2;
        }
    }
    
    private void preRotate2D_270() {
        final double mxx = this.getMxx();
        this.setMxx(this.getMyx());
        this.setMyx(-mxx);
        final double mxy = this.getMxy();
        this.setMxy(this.getMyy());
        this.setMyy(-mxy);
        final double tx = this.getTx();
        this.setTx(this.getTy());
        this.setTy(-tx);
        int state2d = Affine.rot90conversion[this.state2d];
        if ((state2d & 0x6) == 0x2 && this.getMxx() == 1.0 && this.getMyy() == 1.0) {
            state2d -= 2;
        }
        else if ((state2d & 0x6) == 0x4 && this.getMxy() == 0.0 && this.getMyx() == 0.0) {
            state2d = ((state2d & 0xFFFFFFFB) | 0x2);
        }
        this.state2d = state2d;
    }
    
    private void preRotate3D(final double n) {
        if (this.state3d == 0) {
            this.preRotate2D(n);
            return;
        }
        final double sin = Math.sin(Math.toRadians(n));
        if (sin == 1.0) {
            this.preRotate3D_90();
        }
        else if (sin == -1.0) {
            this.preRotate3D_270();
        }
        else {
            final double cos = Math.cos(Math.toRadians(n));
            if (cos == -1.0) {
                this.preRotate3D_180();
            }
            else if (cos != 1.0) {
                final double mxx = this.getMxx();
                final double myx = this.getMyx();
                this.setMxx(cos * mxx - sin * myx);
                this.setMyx(sin * mxx + cos * myx);
                final double mxy = this.getMxy();
                final double myy = this.getMyy();
                this.setMxy(cos * mxy - sin * myy);
                this.setMyy(sin * mxy + cos * myy);
                final double mxz = this.getMxz();
                final double myz = this.getMyz();
                this.setMxz(cos * mxz - sin * myz);
                this.setMyz(sin * mxz + cos * myz);
                final double tx = this.getTx();
                final double ty = this.getTy();
                this.setTx(cos * tx - sin * ty);
                this.setTy(sin * tx + cos * ty);
                this.updateState();
            }
        }
    }
    
    private void preRotate3D_90() {
        final double mxx = this.getMxx();
        this.setMxx(-this.getMyx());
        this.setMyx(mxx);
        final double mxy = this.getMxy();
        this.setMxy(-this.getMyy());
        this.setMyy(mxy);
        final double mxz = this.getMxz();
        this.setMxz(-this.getMyz());
        this.setMyz(mxz);
        final double tx = this.getTx();
        this.setTx(-this.getTy());
        this.setTy(tx);
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 1: {
                this.state3d = 4;
            }
            case 2:
            case 3: {
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state3d = 4;
                }
            }
            case 4: {
                this.updateState();
            }
        }
    }
    
    private void preRotate3D_180() {
        final double mxx = this.getMxx();
        final double myy = this.getMyy();
        this.setMxx(-mxx);
        this.setMyy(-myy);
        this.setTx(-this.getTx());
        this.setTy(-this.getTy());
        if (this.state3d == 4) {
            this.setMxy(-this.getMxy());
            this.setMxz(-this.getMxz());
            this.setMyx(-this.getMyx());
            this.setMyz(-this.getMyz());
            this.updateState();
            return;
        }
        if (mxx == -1.0 && myy == -1.0 && this.getMzz() == 1.0) {
            this.state3d &= 0xFFFFFFFD;
        }
        else {
            this.state3d |= 0x2;
        }
    }
    
    private void preRotate3D_270() {
        final double mxx = this.getMxx();
        this.setMxx(this.getMyx());
        this.setMyx(-mxx);
        final double mxy = this.getMxy();
        this.setMxy(this.getMyy());
        this.setMyy(-mxy);
        final double mxz = this.getMxz();
        this.setMxz(this.getMyz());
        this.setMyz(-mxz);
        final double tx = this.getTx();
        this.setTx(this.getTy());
        this.setTy(-tx);
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 1: {
                this.state3d = 4;
            }
            case 2:
            case 3: {
                if (this.getMxy() != 0.0 || this.getMyx() != 0.0) {
                    this.state3d = 4;
                }
            }
            case 4: {
                this.updateState();
            }
        }
    }
    
    @Override
    public Point2D transform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        switch (this.state2d) {
            default: {
                stateError();
                return new Point2D(this.getMxx() * n + this.getMxy() * n2 + this.getTx(), this.getMyx() * n + this.getMyy() * n2 + this.getTy());
            }
            case 7: {
                return new Point2D(this.getMxx() * n + this.getMxy() * n2 + this.getTx(), this.getMyx() * n + this.getMyy() * n2 + this.getTy());
            }
            case 6: {
                return new Point2D(this.getMxx() * n + this.getMxy() * n2, this.getMyx() * n + this.getMyy() * n2);
            }
            case 5: {
                return new Point2D(this.getMxy() * n2 + this.getTx(), this.getMyx() * n + this.getTy());
            }
            case 4: {
                return new Point2D(this.getMxy() * n2, this.getMyx() * n);
            }
            case 3: {
                return new Point2D(this.getMxx() * n + this.getTx(), this.getMyy() * n2 + this.getTy());
            }
            case 2: {
                return new Point2D(this.getMxx() * n, this.getMyy() * n2);
            }
            case 1: {
                return new Point2D(n + this.getTx(), n2 + this.getTy());
            }
            case 0: {
                return new Point2D(n, n2);
            }
        }
    }
    
    @Override
    public Point3D transform(final double n, final double n2, final double n3) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                switch (this.state2d) {
                    default: {
                        stateError();
                        return new Point3D(this.getMxx() * n + this.getMxy() * n2 + this.getTx(), this.getMyx() * n + this.getMyy() * n2 + this.getTy(), n3);
                    }
                    case 7: {
                        return new Point3D(this.getMxx() * n + this.getMxy() * n2 + this.getTx(), this.getMyx() * n + this.getMyy() * n2 + this.getTy(), n3);
                    }
                    case 6: {
                        return new Point3D(this.getMxx() * n + this.getMxy() * n2, this.getMyx() * n + this.getMyy() * n2, n3);
                    }
                    case 5: {
                        return new Point3D(this.getMxy() * n2 + this.getTx(), this.getMyx() * n + this.getTy(), n3);
                    }
                    case 4: {
                        return new Point3D(this.getMxy() * n2, this.getMyx() * n, n3);
                    }
                    case 3: {
                        return new Point3D(this.getMxx() * n + this.getTx(), this.getMyy() * n2 + this.getTy(), n3);
                    }
                    case 2: {
                        return new Point3D(this.getMxx() * n, this.getMyy() * n2, n3);
                    }
                    case 1: {
                        return new Point3D(n + this.getTx(), n2 + this.getTy(), n3);
                    }
                    case 0: {
                        return new Point3D(n, n2, n3);
                    }
                }
                break;
            }
            case 1: {
                return new Point3D(n + this.getTx(), n2 + this.getTy(), n3 + this.getTz());
            }
            case 2: {
                return new Point3D(this.getMxx() * n, this.getMyy() * n2, this.getMzz() * n3);
            }
            case 3: {
                return new Point3D(this.getMxx() * n + this.getTx(), this.getMyy() * n2 + this.getTy(), this.getMzz() * n3 + this.getTz());
            }
            case 4: {
                return new Point3D(this.getMxx() * n + this.getMxy() * n2 + this.getMxz() * n3 + this.getTx(), this.getMyx() * n + this.getMyy() * n2 + this.getMyz() * n3 + this.getTy(), this.getMzx() * n + this.getMzy() * n2 + this.getMzz() * n3 + this.getTz());
            }
        }
    }
    
    @Override
    void transform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        switch (this.state2d) {
            default: {
                stateError();
            }
            case 7: {
                final double mxx = this.getMxx();
                final double mxy = this.getMxy();
                final double tx = this.getTx();
                final double myx = this.getMyx();
                final double myy = this.getMyy();
                final double ty = this.getTy();
                while (--n3 >= 0) {
                    final double n4 = array[n++];
                    final double n5 = array[n++];
                    array2[n2++] = mxx * n4 + mxy * n5 + tx;
                    array2[n2++] = myx * n4 + myy * n5 + ty;
                }
            }
            case 6: {
                final double mxx2 = this.getMxx();
                final double mxy2 = this.getMxy();
                final double myx2 = this.getMyx();
                final double myy2 = this.getMyy();
                while (--n3 >= 0) {
                    final double n6 = array[n++];
                    final double n7 = array[n++];
                    array2[n2++] = mxx2 * n6 + mxy2 * n7;
                    array2[n2++] = myx2 * n6 + myy2 * n7;
                }
            }
            case 5: {
                final double mxy3 = this.getMxy();
                final double tx2 = this.getTx();
                final double myx3 = this.getMyx();
                final double ty2 = this.getTy();
                while (--n3 >= 0) {
                    final double n8 = array[n++];
                    array2[n2++] = mxy3 * array[n++] + tx2;
                    array2[n2++] = myx3 * n8 + ty2;
                }
            }
            case 4: {
                final double mxy4 = this.getMxy();
                final double myx4 = this.getMyx();
                while (--n3 >= 0) {
                    final double n9 = array[n++];
                    array2[n2++] = mxy4 * array[n++];
                    array2[n2++] = myx4 * n9;
                }
            }
            case 3: {
                final double mxx3 = this.getMxx();
                final double tx3 = this.getTx();
                final double myy3 = this.getMyy();
                final double ty3 = this.getTy();
                while (--n3 >= 0) {
                    array2[n2++] = mxx3 * array[n++] + tx3;
                    array2[n2++] = myy3 * array[n++] + ty3;
                }
            }
            case 2: {
                final double mxx4 = this.getMxx();
                final double myy4 = this.getMyy();
                while (--n3 >= 0) {
                    array2[n2++] = mxx4 * array[n++];
                    array2[n2++] = myy4 * array[n++];
                }
            }
            case 1: {
                final double tx4 = this.getTx();
                final double ty4 = this.getTy();
                while (--n3 >= 0) {
                    array2[n2++] = array[n++] + tx4;
                    array2[n2++] = array[n++] + ty4;
                }
            }
            case 0: {
                if (array != array2 || n != n2) {
                    System.arraycopy(array, n, array2, n2, n3 * 2);
                }
            }
        }
    }
    
    @Override
    void transform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                switch (this.state2d) {
                    default: {
                        stateError();
                    }
                    case 7: {
                        final double mxx = this.getMxx();
                        final double mxy = this.getMxy();
                        final double tx = this.getTx();
                        final double myx = this.getMyx();
                        final double myy = this.getMyy();
                        final double ty = this.getTy();
                        while (--n3 >= 0) {
                            final double n4 = array[n++];
                            final double n5 = array[n++];
                            array2[n2++] = mxx * n4 + mxy * n5 + tx;
                            array2[n2++] = myx * n4 + myy * n5 + ty;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 6: {
                        final double mxx2 = this.getMxx();
                        final double mxy2 = this.getMxy();
                        final double myx2 = this.getMyx();
                        final double myy2 = this.getMyy();
                        while (--n3 >= 0) {
                            final double n6 = array[n++];
                            final double n7 = array[n++];
                            array2[n2++] = mxx2 * n6 + mxy2 * n7;
                            array2[n2++] = myx2 * n6 + myy2 * n7;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 5: {
                        final double mxy3 = this.getMxy();
                        final double tx2 = this.getTx();
                        final double myx3 = this.getMyx();
                        final double ty2 = this.getTy();
                        while (--n3 >= 0) {
                            final double n8 = array[n++];
                            array2[n2++] = mxy3 * array[n++] + tx2;
                            array2[n2++] = myx3 * n8 + ty2;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 4: {
                        final double mxy4 = this.getMxy();
                        final double myx4 = this.getMyx();
                        while (--n3 >= 0) {
                            final double n9 = array[n++];
                            array2[n2++] = mxy4 * array[n++];
                            array2[n2++] = myx4 * n9;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 3: {
                        final double mxx3 = this.getMxx();
                        final double tx3 = this.getTx();
                        final double myy3 = this.getMyy();
                        final double ty3 = this.getTy();
                        while (--n3 >= 0) {
                            array2[n2++] = mxx3 * array[n++] + tx3;
                            array2[n2++] = myy3 * array[n++] + ty3;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 2: {
                        final double mxx4 = this.getMxx();
                        final double myy4 = this.getMyy();
                        while (--n3 >= 0) {
                            array2[n2++] = mxx4 * array[n++];
                            array2[n2++] = myy4 * array[n++];
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 1: {
                        final double tx4 = this.getTx();
                        final double ty4 = this.getTy();
                        while (--n3 >= 0) {
                            array2[n2++] = array[n++] + tx4;
                            array2[n2++] = array[n++] + ty4;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 0: {
                        if (array != array2 || n != n2) {
                            System.arraycopy(array, n, array2, n2, n3 * 3);
                        }
                        return;
                    }
                }
                break;
            }
            case 1: {
                final double tx5 = this.getTx();
                final double ty5 = this.getTy();
                final double tz = this.getTz();
                while (--n3 >= 0) {
                    array2[n2++] = array[n++] + tx5;
                    array2[n2++] = array[n++] + ty5;
                    array2[n2++] = array[n++] + tz;
                }
            }
            case 2: {
                final double mxx5 = this.getMxx();
                final double myy5 = this.getMyy();
                final double mzz = this.getMzz();
                while (--n3 >= 0) {
                    array2[n2++] = mxx5 * array[n++];
                    array2[n2++] = myy5 * array[n++];
                    array2[n2++] = mzz * array[n++];
                }
            }
            case 3: {
                final double mxx6 = this.getMxx();
                final double tx6 = this.getTx();
                final double myy6 = this.getMyy();
                final double ty6 = this.getTy();
                final double mzz2 = this.getMzz();
                final double tz2 = this.getTz();
                while (--n3 >= 0) {
                    array2[n2++] = mxx6 * array[n++] + tx6;
                    array2[n2++] = myy6 * array[n++] + ty6;
                    array2[n2++] = mzz2 * array[n++] + tz2;
                }
            }
            case 4: {
                final double mxx7 = this.getMxx();
                final double mxy5 = this.getMxy();
                final double mxz = this.getMxz();
                final double tx7 = this.getTx();
                final double myx5 = this.getMyx();
                final double myy7 = this.getMyy();
                final double myz = this.getMyz();
                final double ty7 = this.getTy();
                final double mzx = this.getMzx();
                final double mzy = this.getMzy();
                final double mzz3 = this.getMzz();
                final double tz3 = this.getTz();
                while (--n3 >= 0) {
                    final double n10 = array[n++];
                    final double n11 = array[n++];
                    final double n12 = array[n++];
                    array2[n2++] = mxx7 * n10 + mxy5 * n11 + mxz * n12 + tx7;
                    array2[n2++] = myx5 * n10 + myy7 * n11 + myz * n12 + ty7;
                    array2[n2++] = mzx * n10 + mzy * n11 + mzz3 * n12 + tz3;
                }
            }
        }
    }
    
    @Override
    public Point2D deltaTransform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        switch (this.state2d) {
            default: {
                stateError();
                return new Point2D(this.getMxx() * n + this.getMxy() * n2, this.getMyx() * n + this.getMyy() * n2);
            }
            case 6:
            case 7: {
                return new Point2D(this.getMxx() * n + this.getMxy() * n2, this.getMyx() * n + this.getMyy() * n2);
            }
            case 4:
            case 5: {
                return new Point2D(this.getMxy() * n2, this.getMyx() * n);
            }
            case 2:
            case 3: {
                return new Point2D(this.getMxx() * n, this.getMyy() * n2);
            }
            case 0:
            case 1: {
                return new Point2D(n, n2);
            }
        }
    }
    
    @Override
    public Point3D deltaTransform(final double n, final double n2, final double n3) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                switch (this.state2d) {
                    default: {
                        stateError();
                        return new Point3D(this.getMxx() * n + this.getMxy() * n2, this.getMyx() * n + this.getMyy() * n2, n3);
                    }
                    case 6:
                    case 7: {
                        return new Point3D(this.getMxx() * n + this.getMxy() * n2, this.getMyx() * n + this.getMyy() * n2, n3);
                    }
                    case 4:
                    case 5: {
                        return new Point3D(this.getMxy() * n2, this.getMyx() * n, n3);
                    }
                    case 2:
                    case 3: {
                        return new Point3D(this.getMxx() * n, this.getMyy() * n2, n3);
                    }
                    case 0:
                    case 1: {
                        return new Point3D(n, n2, n3);
                    }
                }
                break;
            }
            case 1: {
                return new Point3D(n, n2, n3);
            }
            case 2:
            case 3: {
                return new Point3D(this.getMxx() * n, this.getMyy() * n2, this.getMzz() * n3);
            }
            case 4: {
                return new Point3D(this.getMxx() * n + this.getMxy() * n2 + this.getMxz() * n3, this.getMyx() * n + this.getMyy() * n2 + this.getMyz() * n3, this.getMzx() * n + this.getMzy() * n2 + this.getMzz() * n3);
            }
        }
    }
    
    @Override
    public Point2D inverseTransform(final double n, final double n2) throws NonInvertibleTransformException {
        this.ensureCanTransform2DPoint();
        switch (this.state2d) {
            default: {
                return super.inverseTransform(n, n2);
            }
            case 5: {
                final double mxy = this.getMxy();
                final double myx = this.getMyx();
                if (mxy == 0.0 || myx == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                return new Point2D(1.0 / myx * n2 - this.getTy() / myx, 1.0 / mxy * n - this.getTx() / mxy);
            }
            case 4: {
                final double mxy2 = this.getMxy();
                final double myx2 = this.getMyx();
                if (mxy2 == 0.0 || myx2 == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                return new Point2D(1.0 / myx2 * n2, 1.0 / mxy2 * n);
            }
            case 3: {
                final double mxx = this.getMxx();
                final double myy = this.getMyy();
                if (mxx == 0.0 || myy == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                return new Point2D(1.0 / mxx * n - this.getTx() / mxx, 1.0 / myy * n2 - this.getTy() / myy);
            }
            case 2: {
                final double mxx2 = this.getMxx();
                final double myy2 = this.getMyy();
                if (mxx2 == 0.0 || myy2 == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                return new Point2D(1.0 / mxx2 * n, 1.0 / myy2 * n2);
            }
            case 1: {
                return new Point2D(n - this.getTx(), n2 - this.getTy());
            }
            case 0: {
                return new Point2D(n, n2);
            }
        }
    }
    
    @Override
    public Point3D inverseTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                switch (this.state2d) {
                    default: {
                        return super.inverseTransform(n, n2, n3);
                    }
                    case 5: {
                        final double mxy = this.getMxy();
                        final double myx = this.getMyx();
                        if (mxy == 0.0 || myx == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        return new Point3D(1.0 / myx * n2 - this.getTy() / myx, 1.0 / mxy * n - this.getTx() / mxy, n3);
                    }
                    case 4: {
                        final double mxy2 = this.getMxy();
                        final double myx2 = this.getMyx();
                        if (mxy2 == 0.0 || myx2 == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        return new Point3D(1.0 / myx2 * n2, 1.0 / mxy2 * n, n3);
                    }
                    case 3: {
                        final double mxx = this.getMxx();
                        final double myy = this.getMyy();
                        if (mxx == 0.0 || myy == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        return new Point3D(1.0 / mxx * n - this.getTx() / mxx, 1.0 / myy * n2 - this.getTy() / myy, n3);
                    }
                    case 2: {
                        final double mxx2 = this.getMxx();
                        final double myy2 = this.getMyy();
                        if (mxx2 == 0.0 || myy2 == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        return new Point3D(1.0 / mxx2 * n, 1.0 / myy2 * n2, n3);
                    }
                    case 1: {
                        return new Point3D(n - this.getTx(), n2 - this.getTy(), n3);
                    }
                    case 0: {
                        return new Point3D(n, n2, n3);
                    }
                }
                break;
            }
            case 1: {
                return new Point3D(n - this.getTx(), n2 - this.getTy(), n3 - this.getTz());
            }
            case 2: {
                final double mxx3 = this.getMxx();
                final double myy3 = this.getMyy();
                final double mzz = this.getMzz();
                if (mxx3 == 0.0 || myy3 == 0.0 || mzz == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                return new Point3D(1.0 / mxx3 * n, 1.0 / myy3 * n2, 1.0 / mzz * n3);
            }
            case 3: {
                final double mxx4 = this.getMxx();
                final double myy4 = this.getMyy();
                final double mzz2 = this.getMzz();
                if (mxx4 == 0.0 || myy4 == 0.0 || mzz2 == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                return new Point3D(1.0 / mxx4 * n - this.getTx() / mxx4, 1.0 / myy4 * n2 - this.getTy() / myy4, 1.0 / mzz2 * n3 - this.getTz() / mzz2);
            }
            case 4: {
                return super.inverseTransform(n, n2, n3);
            }
        }
    }
    
    @Override
    void inverseTransform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) throws NonInvertibleTransformException {
        switch (this.state2d) {
            default: {
                super.inverseTransform2DPointsImpl(array, n, array2, n2, n3);
            }
            case 5: {
                final double mxy = this.getMxy();
                final double tx = this.getTx();
                final double myx = this.getMyx();
                final double ty = this.getTy();
                if (mxy == 0.0 || myx == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                final double n4 = tx;
                final double n5 = -ty / myx;
                final double n6 = -n4 / mxy;
                final double n7 = myx;
                final double n8 = 1.0 / mxy;
                final double n9 = 1.0 / n7;
                while (--n3 >= 0) {
                    final double n10 = array[n++];
                    array2[n2++] = n9 * array[n++] + n5;
                    array2[n2++] = n8 * n10 + n6;
                }
            }
            case 4: {
                final double mxy2 = this.getMxy();
                final double myx2 = this.getMyx();
                if (mxy2 == 0.0 || myx2 == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                final double n11 = myx2;
                final double n12 = 1.0 / mxy2;
                final double n13 = 1.0 / n11;
                while (--n3 >= 0) {
                    final double n14 = array[n++];
                    array2[n2++] = n13 * array[n++];
                    array2[n2++] = n12 * n14;
                }
            }
            case 3: {
                final double mxx = this.getMxx();
                final double tx2 = this.getTx();
                final double myy = this.getMyy();
                final double ty2 = this.getTy();
                if (mxx == 0.0 || myy == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                final double n15 = -tx2 / mxx;
                final double n16 = -ty2 / myy;
                final double n17 = 1.0 / mxx;
                final double n18 = 1.0 / myy;
                while (--n3 >= 0) {
                    array2[n2++] = n17 * array[n++] + n15;
                    array2[n2++] = n18 * array[n++] + n16;
                }
            }
            case 2: {
                final double mxx2 = this.getMxx();
                final double myy2 = this.getMyy();
                if (mxx2 == 0.0 || myy2 == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                final double n19 = 1.0 / mxx2;
                final double n20 = 1.0 / myy2;
                while (--n3 >= 0) {
                    array2[n2++] = n19 * array[n++];
                    array2[n2++] = n20 * array[n++];
                }
            }
            case 1: {
                final double tx3 = this.getTx();
                final double ty3 = this.getTy();
                while (--n3 >= 0) {
                    array2[n2++] = array[n++] - tx3;
                    array2[n2++] = array[n++] - ty3;
                }
            }
            case 0: {
                if (array != array2 || n != n2) {
                    System.arraycopy(array, n, array2, n2, n3 * 2);
                }
            }
        }
    }
    
    @Override
    void inverseTransform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) throws NonInvertibleTransformException {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                switch (this.state2d) {
                    default: {
                        super.inverseTransform3DPointsImpl(array, n, array2, n2, n3);
                        return;
                    }
                    case 5: {
                        final double mxy = this.getMxy();
                        final double tx = this.getTx();
                        final double myx = this.getMyx();
                        final double ty = this.getTy();
                        if (mxy == 0.0 || myx == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        final double n4 = tx;
                        final double n5 = -ty / myx;
                        final double n6 = -n4 / mxy;
                        final double n7 = myx;
                        final double n8 = 1.0 / mxy;
                        final double n9 = 1.0 / n7;
                        while (--n3 >= 0) {
                            final double n10 = array[n++];
                            array2[n2++] = n9 * array[n++] + n5;
                            array2[n2++] = n8 * n10 + n6;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 4: {
                        final double mxy2 = this.getMxy();
                        final double myx2 = this.getMyx();
                        if (mxy2 == 0.0 || myx2 == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        final double n11 = myx2;
                        final double n12 = 1.0 / mxy2;
                        final double n13 = 1.0 / n11;
                        while (--n3 >= 0) {
                            final double n14 = array[n++];
                            array2[n2++] = n13 * array[n++];
                            array2[n2++] = n12 * n14;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 3: {
                        final double mxx = this.getMxx();
                        final double tx2 = this.getTx();
                        final double myy = this.getMyy();
                        final double ty2 = this.getTy();
                        if (mxx == 0.0 || myy == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        final double n15 = -tx2 / mxx;
                        final double n16 = -ty2 / myy;
                        final double n17 = 1.0 / mxx;
                        final double n18 = 1.0 / myy;
                        while (--n3 >= 0) {
                            array2[n2++] = n17 * array[n++] + n15;
                            array2[n2++] = n18 * array[n++] + n16;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 2: {
                        final double mxx2 = this.getMxx();
                        final double myy2 = this.getMyy();
                        if (mxx2 == 0.0 || myy2 == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        final double n19 = 1.0 / mxx2;
                        final double n20 = 1.0 / myy2;
                        while (--n3 >= 0) {
                            array2[n2++] = n19 * array[n++];
                            array2[n2++] = n20 * array[n++];
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 1: {
                        final double tx3 = this.getTx();
                        final double ty3 = this.getTy();
                        while (--n3 >= 0) {
                            array2[n2++] = array[n++] - tx3;
                            array2[n2++] = array[n++] - ty3;
                            array2[n2++] = array[n++];
                        }
                        return;
                    }
                    case 0: {
                        if (array != array2 || n != n2) {
                            System.arraycopy(array, n, array2, n2, n3 * 3);
                        }
                        return;
                    }
                }
                break;
            }
            case 1: {
                final double tx4 = this.getTx();
                final double ty4 = this.getTy();
                final double tz = this.getTz();
                while (--n3 >= 0) {
                    array2[n2++] = array[n++] - tx4;
                    array2[n2++] = array[n++] - ty4;
                    array2[n2++] = array[n++] - tz;
                }
            }
            case 2: {
                final double mxx3 = this.getMxx();
                final double myy3 = this.getMyy();
                final double mzz = this.getMzz();
                if (mxx3 == 0.0 || (myy3 == 0.0 | mzz == 0.0)) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                final double n21 = 1.0 / mxx3;
                final double n22 = 1.0 / myy3;
                final double n23 = 1.0 / mzz;
                while (--n3 >= 0) {
                    array2[n2++] = n21 * array[n++];
                    array2[n2++] = n22 * array[n++];
                    array2[n2++] = n23 * array[n++];
                }
            }
            case 3: {
                final double mxx4 = this.getMxx();
                final double tx5 = this.getTx();
                final double myy4 = this.getMyy();
                final double ty5 = this.getTy();
                final double mzz2 = this.getMzz();
                final double tz2 = this.getTz();
                if (mxx4 == 0.0 || myy4 == 0.0 || mzz2 == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                final double n24 = -tx5 / mxx4;
                final double n25 = -ty5 / myy4;
                final double n26 = -tz2 / mzz2;
                final double n27 = 1.0 / mxx4;
                final double n28 = 1.0 / myy4;
                final double n29 = 1.0 / mzz2;
                while (--n3 >= 0) {
                    array2[n2++] = n27 * array[n++] + n24;
                    array2[n2++] = n28 * array[n++] + n25;
                    array2[n2++] = n29 * array[n++] + n26;
                }
            }
            case 4: {
                super.inverseTransform3DPointsImpl(array, n, array2, n2, n3);
            }
        }
    }
    
    @Override
    public Point2D inverseDeltaTransform(final double n, final double n2) throws NonInvertibleTransformException {
        this.ensureCanTransform2DPoint();
        switch (this.state2d) {
            default: {
                return super.inverseDeltaTransform(n, n2);
            }
            case 4:
            case 5: {
                final double mxy = this.getMxy();
                final double myx = this.getMyx();
                if (mxy == 0.0 || myx == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                return new Point2D(1.0 / myx * n2, 1.0 / mxy * n);
            }
            case 2:
            case 3: {
                final double mxx = this.getMxx();
                final double myy = this.getMyy();
                if (mxx == 0.0 || myy == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                return new Point2D(1.0 / mxx * n, 1.0 / myy * n2);
            }
            case 0:
            case 1: {
                return new Point2D(n, n2);
            }
        }
    }
    
    @Override
    public Point3D inverseDeltaTransform(final double n, final double n2, final double n3) throws NonInvertibleTransformException {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                switch (this.state2d) {
                    default: {
                        return super.inverseDeltaTransform(n, n2, n3);
                    }
                    case 4:
                    case 5: {
                        final double mxy = this.getMxy();
                        final double myx = this.getMyx();
                        if (mxy == 0.0 || myx == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        return new Point3D(1.0 / myx * n2, 1.0 / mxy * n, n3);
                    }
                    case 2:
                    case 3: {
                        final double mxx = this.getMxx();
                        final double myy = this.getMyy();
                        if (mxx == 0.0 || myy == 0.0) {
                            throw new NonInvertibleTransformException("Determinant is 0");
                        }
                        return new Point3D(1.0 / mxx * n, 1.0 / myy * n2, n3);
                    }
                    case 0:
                    case 1: {
                        return new Point3D(n, n2, n3);
                    }
                }
                break;
            }
            case 1: {
                return new Point3D(n, n2, n3);
            }
            case 2:
            case 3: {
                final double mxx2 = this.getMxx();
                final double myy2 = this.getMyy();
                final double mzz = this.getMzz();
                if (mxx2 == 0.0 || myy2 == 0.0 || mzz == 0.0) {
                    throw new NonInvertibleTransformException("Determinant is 0");
                }
                return new Point3D(1.0 / mxx2 * n, 1.0 / myy2 * n2, 1.0 / mzz * n3);
            }
            case 4: {
                return super.inverseDeltaTransform(n, n2, n3);
            }
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Affine [\n");
        sb.append("\t").append(this.getMxx());
        sb.append(", ").append(this.getMxy());
        sb.append(", ").append(this.getMxz());
        sb.append(", ").append(this.getTx());
        sb.append('\n');
        sb.append("\t").append(this.getMyx());
        sb.append(", ").append(this.getMyy());
        sb.append(", ").append(this.getMyz());
        sb.append(", ").append(this.getTy());
        sb.append('\n');
        sb.append("\t").append(this.getMzx());
        sb.append(", ").append(this.getMzy());
        sb.append(", ").append(this.getMzz());
        sb.append(", ").append(this.getTz());
        return sb.append("\n]").toString();
    }
    
    private void updateState() {
        this.updateState2D();
        this.state3d = 0;
        if (this.getMxz() != 0.0 || this.getMyz() != 0.0 || this.getMzx() != 0.0 || this.getMzy() != 0.0) {
            this.state3d = 4;
        }
        else if ((this.state2d & 0x4) == 0x0) {
            if (this.getTz() != 0.0) {
                this.state3d |= 0x1;
            }
            if (this.getMzz() != 1.0) {
                this.state3d |= 0x2;
            }
            if (this.state3d != 0) {
                this.state3d |= (this.state2d & 0x3);
            }
        }
        else if (this.getMzz() != 1.0 || this.getTz() != 0.0) {
            this.state3d = 4;
        }
    }
    
    private void updateState2D() {
        if (this.getMxy() == 0.0 && this.getMyx() == 0.0) {
            if (this.getMxx() == 1.0 && this.getMyy() == 1.0) {
                if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                    this.state2d = 0;
                }
                else {
                    this.state2d = 1;
                }
            }
            else if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                this.state2d = 2;
            }
            else {
                this.state2d = 3;
            }
        }
        else if (this.getMxx() == 0.0 && this.getMyy() == 0.0) {
            if (this.getTx() == 0.0 && this.getTy() == 0.0) {
                this.state2d = 4;
            }
            else {
                this.state2d = 5;
            }
        }
        else if (this.getTx() == 0.0 && this.getTy() == 0.0) {
            this.state2d = 6;
        }
        else {
            this.state2d = 7;
        }
    }
    
    private static void stateError() {
        throw new InternalError("missing case in a switch");
    }
    
    @Override
    void apply(final Affine3D affine3D) {
        affine3D.concatenate(this.getMxx(), this.getMxy(), this.getMxz(), this.getTx(), this.getMyx(), this.getMyy(), this.getMyz(), this.getTy(), this.getMzx(), this.getMzy(), this.getMzz(), this.getTz());
    }
    
    @Override
    BaseTransform derive(final BaseTransform baseTransform) {
        switch (this.state3d) {
            default: {
                stateError();
            }
            case 0: {
                switch (this.state2d) {
                    case 0: {
                        return baseTransform;
                    }
                    case 1: {
                        return baseTransform.deriveWithTranslation(this.getTx(), this.getTy());
                    }
                    case 2: {
                        return baseTransform.deriveWithScale(this.getMxx(), this.getMyy(), 1.0);
                    }
                    default: {
                        return baseTransform.deriveWithConcatenation(this.getMxx(), this.getMyx(), this.getMxy(), this.getMyy(), this.getTx(), this.getTy());
                    }
                }
                break;
            }
            case 1: {
                return baseTransform.deriveWithTranslation(this.getTx(), this.getTy(), this.getTz());
            }
            case 2: {
                return baseTransform.deriveWithScale(this.getMxx(), this.getMyy(), this.getMzz());
            }
            case 3:
            case 4: {
                return baseTransform.deriveWithConcatenation(this.getMxx(), this.getMxy(), this.getMxz(), this.getTx(), this.getMyx(), this.getMyy(), this.getMyz(), this.getTy(), this.getMzx(), this.getMzy(), this.getMzz(), this.getTz());
            }
        }
    }
    
    int getState2d() {
        return this.state2d;
    }
    
    int getState3d() {
        return this.state3d;
    }
    
    boolean atomicChangeRuns() {
        return this.atomicChange.runs();
    }
    
    static {
        rot90conversion = new int[] { 4, 5, 4, 5, 2, 3, 6, 7 };
    }
    
    private class AffineElementProperty extends SimpleDoubleProperty
    {
        private boolean needsValueChangedEvent;
        private double oldValue;
        
        public AffineElementProperty(final double n) {
            super(n);
            this.needsValueChangedEvent = false;
        }
        
        public void invalidated() {
            if (!Affine.this.atomicChange.runs()) {
                Affine.this.updateState();
                Affine.this.transformChanged();
            }
        }
        
        @Override
        protected void fireValueChangedEvent() {
            if (!Affine.this.atomicChange.runs()) {
                super.fireValueChangedEvent();
            }
            else {
                this.needsValueChangedEvent = true;
            }
        }
        
        private void preProcessAtomicChange() {
            this.oldValue = this.get();
        }
        
        private void postProcessAtomicChange() {
            if (this.needsValueChangedEvent) {
                this.needsValueChangedEvent = false;
                if (this.oldValue != this.get()) {
                    super.fireValueChangedEvent();
                }
            }
        }
    }
    
    private class AffineAtomicChange
    {
        private boolean running;
        
        private AffineAtomicChange() {
            this.running = false;
        }
        
        private void start() {
            if (this.running) {
                throw new InternalError("Affine internal error: trying to run inner atomic operation");
            }
            if (Affine.this.mxx != null) {
                Affine.this.mxx.preProcessAtomicChange();
            }
            if (Affine.this.mxy != null) {
                Affine.this.mxy.preProcessAtomicChange();
            }
            if (Affine.this.mxz != null) {
                Affine.this.mxz.preProcessAtomicChange();
            }
            if (Affine.this.tx != null) {
                Affine.this.tx.preProcessAtomicChange();
            }
            if (Affine.this.myx != null) {
                Affine.this.myx.preProcessAtomicChange();
            }
            if (Affine.this.myy != null) {
                Affine.this.myy.preProcessAtomicChange();
            }
            if (Affine.this.myz != null) {
                Affine.this.myz.preProcessAtomicChange();
            }
            if (Affine.this.ty != null) {
                Affine.this.ty.preProcessAtomicChange();
            }
            if (Affine.this.mzx != null) {
                Affine.this.mzx.preProcessAtomicChange();
            }
            if (Affine.this.mzy != null) {
                Affine.this.mzy.preProcessAtomicChange();
            }
            if (Affine.this.mzz != null) {
                Affine.this.mzz.preProcessAtomicChange();
            }
            if (Affine.this.tz != null) {
                Affine.this.tz.preProcessAtomicChange();
            }
            this.running = true;
        }
        
        private void end() {
            this.running = false;
            Affine.this.transformChanged();
            if (Affine.this.mxx != null) {
                Affine.this.mxx.postProcessAtomicChange();
            }
            if (Affine.this.mxy != null) {
                Affine.this.mxy.postProcessAtomicChange();
            }
            if (Affine.this.mxz != null) {
                Affine.this.mxz.postProcessAtomicChange();
            }
            if (Affine.this.tx != null) {
                Affine.this.tx.postProcessAtomicChange();
            }
            if (Affine.this.myx != null) {
                Affine.this.myx.postProcessAtomicChange();
            }
            if (Affine.this.myy != null) {
                Affine.this.myy.postProcessAtomicChange();
            }
            if (Affine.this.myz != null) {
                Affine.this.myz.postProcessAtomicChange();
            }
            if (Affine.this.ty != null) {
                Affine.this.ty.postProcessAtomicChange();
            }
            if (Affine.this.mzx != null) {
                Affine.this.mzx.postProcessAtomicChange();
            }
            if (Affine.this.mzy != null) {
                Affine.this.mzy.postProcessAtomicChange();
            }
            if (Affine.this.mzz != null) {
                Affine.this.mzz.postProcessAtomicChange();
            }
            if (Affine.this.tz != null) {
                Affine.this.tz.postProcessAtomicChange();
            }
        }
        
        private void cancel() {
            this.running = false;
        }
        
        private boolean runs() {
            return this.running;
        }
    }
}
