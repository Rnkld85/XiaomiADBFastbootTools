// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene.transform;

import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.geom.transform.Affine3D;
import javafx.geometry.Point3D;
import javafx.geometry.Point2D;
import javafx.beans.property.DoublePropertyBase;
import javafx.beans.property.DoubleProperty;

public class Translate extends Transform
{
    private DoubleProperty x;
    private DoubleProperty y;
    private DoubleProperty z;
    
    public Translate() {
    }
    
    public Translate(final double x, final double y) {
        this.setX(x);
        this.setY(y);
    }
    
    public Translate(final double n, final double n2, final double z) {
        this(n, n2);
        this.setZ(z);
    }
    
    public final void setX(final double n) {
        this.xProperty().set(n);
    }
    
    public final double getX() {
        return (this.x == null) ? 0.0 : this.x.get();
    }
    
    public final DoubleProperty xProperty() {
        if (this.x == null) {
            this.x = new DoublePropertyBase() {
                public void invalidated() {
                    Translate.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Translate.this;
                }
                
                @Override
                public String getName() {
                    return "x";
                }
            };
        }
        return this.x;
    }
    
    public final void setY(final double n) {
        this.yProperty().set(n);
    }
    
    public final double getY() {
        return (this.y == null) ? 0.0 : this.y.get();
    }
    
    public final DoubleProperty yProperty() {
        if (this.y == null) {
            this.y = new DoublePropertyBase() {
                public void invalidated() {
                    Translate.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Translate.this;
                }
                
                @Override
                public String getName() {
                    return "y";
                }
            };
        }
        return this.y;
    }
    
    public final void setZ(final double n) {
        this.zProperty().set(n);
    }
    
    public final double getZ() {
        return (this.z == null) ? 0.0 : this.z.get();
    }
    
    public final DoubleProperty zProperty() {
        if (this.z == null) {
            this.z = new DoublePropertyBase() {
                public void invalidated() {
                    Translate.this.transformChanged();
                }
                
                @Override
                public Object getBean() {
                    return Translate.this;
                }
                
                @Override
                public String getName() {
                    return "z";
                }
            };
        }
        return this.z;
    }
    
    @Override
    public double getTx() {
        return this.getX();
    }
    
    @Override
    public double getTy() {
        return this.getY();
    }
    
    @Override
    public double getTz() {
        return this.getZ();
    }
    
    @Override
    boolean computeIs2D() {
        return this.getZ() == 0.0;
    }
    
    @Override
    boolean computeIsIdentity() {
        return this.getX() == 0.0 && this.getY() == 0.0 && this.getZ() == 0.0;
    }
    
    @Override
    void fill2DArray(final double[] array) {
        array[0] = 1.0;
        array[1] = 0.0;
        array[2] = this.getX();
        array[3] = 0.0;
        array[4] = 1.0;
        array[5] = this.getY();
    }
    
    @Override
    void fill3DArray(final double[] array) {
        array[0] = 1.0;
        array[2] = (array[1] = 0.0);
        array[3] = this.getX();
        array[4] = 0.0;
        array[5] = 1.0;
        array[6] = 0.0;
        array[7] = this.getY();
        array[9] = (array[8] = 0.0);
        array[10] = 1.0;
        array[11] = this.getZ();
    }
    
    @Override
    public Transform createConcatenation(final Transform transform) {
        if (transform instanceof Translate) {
            final Translate translate = (Translate)transform;
            return new Translate(this.getX() + translate.getX(), this.getY() + translate.getY(), this.getZ() + translate.getZ());
        }
        if (transform instanceof Scale) {
            final Scale scale = (Scale)transform;
            final double x = scale.getX();
            final double y = scale.getY();
            final double z = scale.getZ();
            final double x2 = this.getX();
            final double y2 = this.getY();
            final double z2 = this.getZ();
            if ((x2 == 0.0 || x != 1.0) && (y2 == 0.0 || y != 1.0) && (z2 == 0.0 || z != 1.0)) {
                return new Scale(x, y, z, scale.getPivotX() + ((x == 1.0) ? 0.0 : (x2 / (1.0 - x))), scale.getPivotY() + ((y == 1.0) ? 0.0 : (y2 / (1.0 - y))), scale.getPivotZ() + ((z == 1.0) ? 0.0 : (z2 / (1.0 - z))));
            }
        }
        if (transform instanceof Affine) {
            final Affine affine = (Affine)transform.clone();
            affine.prepend(this);
            return affine;
        }
        return new Affine(transform.getMxx(), transform.getMxy(), transform.getMxz(), transform.getTx() + this.getX(), transform.getMyx(), transform.getMyy(), transform.getMyz(), transform.getTy() + this.getY(), transform.getMzx(), transform.getMzy(), transform.getMzz(), transform.getTz() + this.getZ());
    }
    
    @Override
    public Translate createInverse() {
        return new Translate(-this.getX(), -this.getY(), -this.getZ());
    }
    
    @Override
    public Translate clone() {
        return new Translate(this.getX(), this.getY(), this.getZ());
    }
    
    @Override
    public Point2D transform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        return new Point2D(n + this.getX(), n2 + this.getY());
    }
    
    @Override
    public Point3D transform(final double n, final double n2, final double n3) {
        return new Point3D(n + this.getX(), n2 + this.getY(), n3 + this.getZ());
    }
    
    @Override
    void transform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double x = this.getX();
        final double y = this.getY();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            array2[n2++] = n4 + x;
            array2[n2++] = n5 + y;
        }
    }
    
    @Override
    void transform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        while (--n3 >= 0) {
            final double n4 = array[n++];
            final double n5 = array[n++];
            final double n6 = array[n++];
            array2[n2++] = n4 + x;
            array2[n2++] = n5 + y;
            array2[n2++] = n6 + z;
        }
    }
    
    @Override
    public Point2D deltaTransform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        return new Point2D(n, n2);
    }
    
    @Override
    public Point2D deltaTransform(final Point2D point2D) {
        if (point2D == null) {
            throw new NullPointerException();
        }
        this.ensureCanTransform2DPoint();
        return point2D;
    }
    
    @Override
    public Point3D deltaTransform(final double n, final double n2, final double n3) {
        return new Point3D(n, n2, n3);
    }
    
    @Override
    public Point3D deltaTransform(final Point3D point3D) {
        if (point3D == null) {
            throw new NullPointerException();
        }
        return point3D;
    }
    
    @Override
    public Point2D inverseTransform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        return new Point2D(n - this.getX(), n2 - this.getY());
    }
    
    @Override
    public Point3D inverseTransform(final double n, final double n2, final double n3) {
        return new Point3D(n - this.getX(), n2 - this.getY(), n3 - this.getZ());
    }
    
    @Override
    void inverseTransform2DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double x = this.getX();
        final double y = this.getY();
        while (--n3 >= 0) {
            array2[n2++] = array[n++] - x;
            array2[n2++] = array[n++] - y;
        }
    }
    
    @Override
    void inverseTransform3DPointsImpl(final double[] array, int n, final double[] array2, int n2, int n3) {
        final double x = this.getX();
        final double y = this.getY();
        final double z = this.getZ();
        while (--n3 >= 0) {
            array2[n2++] = array[n++] - x;
            array2[n2++] = array[n++] - y;
            array2[n2++] = array[n++] - z;
        }
    }
    
    @Override
    public Point2D inverseDeltaTransform(final double n, final double n2) {
        this.ensureCanTransform2DPoint();
        return new Point2D(n, n2);
    }
    
    @Override
    public Point2D inverseDeltaTransform(final Point2D point2D) {
        if (point2D == null) {
            throw new NullPointerException();
        }
        this.ensureCanTransform2DPoint();
        return point2D;
    }
    
    @Override
    public Point3D inverseDeltaTransform(final double n, final double n2, final double n3) {
        return new Point3D(n, n2, n3);
    }
    
    @Override
    public Point3D inverseDeltaTransform(final Point3D point3D) {
        if (point3D == null) {
            throw new NullPointerException();
        }
        return point3D;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Translate [");
        sb.append("x=").append(this.getX());
        sb.append(", y=").append(this.getY());
        sb.append(", z=").append(this.getZ());
        return sb.append("]").toString();
    }
    
    @Override
    void apply(final Affine3D affine3D) {
        affine3D.translate(this.getX(), this.getY(), this.getZ());
    }
    
    @Override
    BaseTransform derive(final BaseTransform baseTransform) {
        return baseTransform.deriveWithTranslation(this.getX(), this.getY(), this.getZ());
    }
    
    @Override
    void validate() {
        this.getX();
        this.getY();
        this.getZ();
    }
    
    @Override
    void appendTo(final Affine affine) {
        affine.appendTranslation(this.getTx(), this.getTy(), this.getTz());
    }
    
    @Override
    void prependTo(final Affine affine) {
        affine.prependTranslation(this.getTx(), this.getTy(), this.getTz());
    }
}
