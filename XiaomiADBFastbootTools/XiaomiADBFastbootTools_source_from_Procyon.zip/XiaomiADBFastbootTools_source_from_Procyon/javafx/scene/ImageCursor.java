// 
// Decompiled by Procyon v0.5.36
// 

package javafx.scene;

import java.util.Arrays;
import javafx.beans.property.ReadOnlyObjectPropertyBase;
import javafx.beans.property.ReadOnlyDoublePropertyBase;
import javafx.beans.Observable;
import java.util.HashMap;
import com.sun.javafx.tk.Toolkit;
import javafx.geometry.Dimension2D;
import javafx.beans.NamedArg;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.InvalidationListener;
import java.util.Map;
import com.sun.javafx.cursor.ImageCursorFrame;
import com.sun.javafx.cursor.CursorFrame;
import javafx.scene.image.Image;

public class ImageCursor extends Cursor
{
    private ObjectPropertyImpl<Image> image;
    private DoublePropertyImpl hotspotX;
    private DoublePropertyImpl hotspotY;
    private CursorFrame currentCursorFrame;
    private ImageCursorFrame firstCursorFrame;
    private Map<Object, ImageCursorFrame> otherCursorFrames;
    private int activeCounter;
    private InvalidationListener imageListener;
    
    public final Image getImage() {
        return (this.image == null) ? null : this.image.get();
    }
    
    public final ReadOnlyObjectProperty<Image> imageProperty() {
        return this.imagePropertyImpl();
    }
    
    private ObjectPropertyImpl<Image> imagePropertyImpl() {
        if (this.image == null) {
            this.image = new ObjectPropertyImpl<Image>("image");
        }
        return this.image;
    }
    
    public final double getHotspotX() {
        return (this.hotspotX == null) ? 0.0 : this.hotspotX.get();
    }
    
    public final ReadOnlyDoubleProperty hotspotXProperty() {
        return this.hotspotXPropertyImpl();
    }
    
    private DoublePropertyImpl hotspotXPropertyImpl() {
        if (this.hotspotX == null) {
            this.hotspotX = new DoublePropertyImpl("hotspotX");
        }
        return this.hotspotX;
    }
    
    public final double getHotspotY() {
        return (this.hotspotY == null) ? 0.0 : this.hotspotY.get();
    }
    
    public final ReadOnlyDoubleProperty hotspotYProperty() {
        return this.hotspotYPropertyImpl();
    }
    
    private DoublePropertyImpl hotspotYPropertyImpl() {
        if (this.hotspotY == null) {
            this.hotspotY = new DoublePropertyImpl("hotspotY");
        }
        return this.hotspotY;
    }
    
    public ImageCursor() {
    }
    
    public ImageCursor(@NamedArg("image") final Image image) {
        this(image, 0.0, 0.0);
    }
    
    public ImageCursor(@NamedArg("image") final Image image, @NamedArg("hotspotX") final double n, @NamedArg("hotspotY") final double n2) {
        if (image != null && image.getProgress() < 1.0) {
            DelayedInitialization.applyTo(this, image, n, n2);
        }
        else {
            this.initialize(image, n, n2);
        }
    }
    
    public static Dimension2D getBestSize(final double n, final double n2) {
        return Toolkit.getToolkit().getBestCursorSize((int)n, (int)n2);
    }
    
    public static int getMaximumColors() {
        return Toolkit.getToolkit().getMaximumCursorColors();
    }
    
    public static ImageCursor chooseBestCursor(final Image[] array, final double n, final double n2) {
        final ImageCursor imageCursor = new ImageCursor();
        if (needsDelayedInitialization(array)) {
            DelayedInitialization.applyTo(imageCursor, array, n, n2);
        }
        else {
            imageCursor.initialize(array, n, n2);
        }
        return imageCursor;
    }
    
    @Override
    CursorFrame getCurrentFrame() {
        if (this.currentCursorFrame != null) {
            return this.currentCursorFrame;
        }
        final Image image = this.getImage();
        if (image == null) {
            return this.currentCursorFrame = Cursor.DEFAULT.getCurrentFrame();
        }
        final Object platformImage = Toolkit.getImageAccessor().getPlatformImage(image);
        if (platformImage == null) {
            return this.currentCursorFrame = Cursor.DEFAULT.getCurrentFrame();
        }
        if (this.firstCursorFrame == null) {
            this.firstCursorFrame = new ImageCursorFrame(platformImage, image.getWidth(), image.getHeight(), this.getHotspotX(), this.getHotspotY());
            this.currentCursorFrame = this.firstCursorFrame;
        }
        else if (this.firstCursorFrame.getPlatformImage() == platformImage) {
            this.currentCursorFrame = this.firstCursorFrame;
        }
        else {
            if (this.otherCursorFrames == null) {
                this.otherCursorFrames = new HashMap<Object, ImageCursorFrame>();
            }
            this.currentCursorFrame = this.otherCursorFrames.get(platformImage);
            if (this.currentCursorFrame == null) {
                final ImageCursorFrame currentCursorFrame = new ImageCursorFrame(platformImage, image.getWidth(), image.getHeight(), this.getHotspotX(), this.getHotspotY());
                this.otherCursorFrames.put(platformImage, currentCursorFrame);
                this.currentCursorFrame = currentCursorFrame;
            }
        }
        return this.currentCursorFrame;
    }
    
    private void invalidateCurrentFrame() {
        this.currentCursorFrame = null;
    }
    
    @Override
    void activate() {
        if (++this.activeCounter == 1) {
            this.bindImage(this.getImage());
            this.invalidateCurrentFrame();
        }
    }
    
    @Override
    void deactivate() {
        final int activeCounter = this.activeCounter - 1;
        this.activeCounter = activeCounter;
        if (activeCounter == 0) {
            this.unbindImage(this.getImage());
        }
    }
    
    private void initialize(final Image[] array, final double n, final double n2) {
        final Dimension2D bestSize = getBestSize(1.0, 1.0);
        if (array.length == 0 || bestSize.getWidth() == 0.0 || bestSize.getHeight() == 0.0) {
            return;
        }
        if (array.length == 1) {
            this.initialize(array[0], n, n2);
            return;
        }
        final Image bestImage = findBestImage(array);
        this.initialize(bestImage, n * (bestImage.getWidth() / array[0].getWidth()), n2 * (bestImage.getHeight() / array[0].getHeight()));
    }
    
    private void initialize(final Image image, double n, double n2) {
        final Image image2 = this.getImage();
        final double hotspotX = this.getHotspotX();
        final double hotspotY = this.getHotspotY();
        if (image == null || image.getWidth() < 1.0 || image.getHeight() < 1.0) {
            n = 0.0;
            n2 = 0.0;
        }
        else {
            if (n < 0.0) {
                n = 0.0;
            }
            if (n > image.getWidth() - 1.0) {
                n = image.getWidth() - 1.0;
            }
            if (n2 < 0.0) {
                n2 = 0.0;
            }
            if (n2 > image.getHeight() - 1.0) {
                n2 = image.getHeight() - 1.0;
            }
        }
        this.imagePropertyImpl().store(image);
        this.hotspotXPropertyImpl().store(n);
        this.hotspotYPropertyImpl().store(n2);
        if (image2 != image) {
            if (this.activeCounter > 0) {
                this.unbindImage(image2);
                this.bindImage(image);
            }
            this.invalidateCurrentFrame();
            this.image.fireValueChangedEvent();
        }
        if (hotspotX != n) {
            this.hotspotX.fireValueChangedEvent();
        }
        if (hotspotY != n2) {
            this.hotspotY.fireValueChangedEvent();
        }
    }
    
    private InvalidationListener getImageListener() {
        if (this.imageListener == null) {
            this.imageListener = (p0 -> this.invalidateCurrentFrame());
        }
        return this.imageListener;
    }
    
    private void bindImage(final Image image) {
        if (image == null) {
            return;
        }
        Toolkit.getImageAccessor().getImageProperty(image).addListener(this.getImageListener());
    }
    
    private void unbindImage(final Image image) {
        if (image == null) {
            return;
        }
        Toolkit.getImageAccessor().getImageProperty(image).removeListener(this.getImageListener());
    }
    
    private static boolean needsDelayedInitialization(final Image[] array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            if (array[i].getProgress() < 1.0) {
                return true;
            }
        }
        return false;
    }
    
    private static Image findBestImage(final Image[] array) {
        for (final Image image : array) {
            final Dimension2D bestSize = getBestSize((int)image.getWidth(), (int)image.getHeight());
            if (bestSize.getWidth() == image.getWidth() && bestSize.getHeight() == image.getHeight()) {
                return image;
            }
        }
        Image image2 = null;
        double n = Double.MAX_VALUE;
        for (final Image image3 : array) {
            if (image3.getWidth() > 0.0 && image3.getHeight() > 0.0) {
                final Dimension2D bestSize2 = getBestSize(image3.getWidth(), image3.getHeight());
                final double a = bestSize2.getWidth() / image3.getWidth();
                final double b = bestSize2.getHeight() / image3.getHeight();
                if (a >= 1.0 && b >= 1.0) {
                    final double max = Math.max(a, b);
                    if (max < n) {
                        image2 = image3;
                        n = max;
                    }
                }
            }
        }
        if (image2 != null) {
            return image2;
        }
        for (final Image image4 : array) {
            if (image4.getWidth() > 0.0 && image4.getHeight() > 0.0) {
                final Dimension2D bestSize3 = getBestSize(image4.getWidth(), image4.getHeight());
                if (bestSize3.getWidth() > 0.0 && bestSize3.getHeight() > 0.0) {
                    double a2 = bestSize3.getWidth() / image4.getWidth();
                    if (a2 < 1.0) {
                        a2 = 1.0 / a2;
                    }
                    double b2 = bestSize3.getHeight() / image4.getHeight();
                    if (b2 < 1.0) {
                        b2 = 1.0 / b2;
                    }
                    final double max2 = Math.max(a2, b2);
                    if (max2 < n) {
                        image2 = image4;
                        n = max2;
                    }
                }
            }
        }
        if (image2 != null) {
            return image2;
        }
        return array[0];
    }
    
    private final class DoublePropertyImpl extends ReadOnlyDoublePropertyBase
    {
        private final String name;
        private double value;
        
        public DoublePropertyImpl(final String name) {
            this.name = name;
        }
        
        public void store(final double value) {
            this.value = value;
        }
        
        public void fireValueChangedEvent() {
            super.fireValueChangedEvent();
        }
        
        @Override
        public double get() {
            return this.value;
        }
        
        @Override
        public Object getBean() {
            return ImageCursor.this;
        }
        
        @Override
        public String getName() {
            return this.name;
        }
    }
    
    private final class ObjectPropertyImpl<T> extends ReadOnlyObjectPropertyBase<T>
    {
        private final String name;
        private T value;
        
        public ObjectPropertyImpl(final String name) {
            this.name = name;
        }
        
        public void store(final T value) {
            this.value = value;
        }
        
        public void fireValueChangedEvent() {
            super.fireValueChangedEvent();
        }
        
        @Override
        public T get() {
            return this.value;
        }
        
        @Override
        public Object getBean() {
            return ImageCursor.this;
        }
        
        @Override
        public String getName() {
            return this.name;
        }
    }
    
    private static final class DelayedInitialization implements InvalidationListener
    {
        private final ImageCursor targetCursor;
        private final Image[] images;
        private final double hotspotX;
        private final double hotspotY;
        private final boolean initAsSingle;
        private int waitForImages;
        
        private DelayedInitialization(final ImageCursor targetCursor, final Image[] images, final double hotspotX, final double hotspotY, final boolean initAsSingle) {
            this.targetCursor = targetCursor;
            this.images = images;
            this.hotspotX = hotspotX;
            this.hotspotY = hotspotY;
            this.initAsSingle = initAsSingle;
        }
        
        public static void applyTo(final ImageCursor imageCursor, final Image[] original, final double n, final double n2) {
            new DelayedInitialization(imageCursor, Arrays.copyOf(original, original.length), n, n2, false).start();
        }
        
        public static void applyTo(final ImageCursor imageCursor, final Image image, final double n, final double n2) {
            new DelayedInitialization(imageCursor, new Image[] { image }, n, n2, true).start();
        }
        
        private void start() {
            for (final Image image : this.images) {
                if (image.getProgress() < 1.0) {
                    ++this.waitForImages;
                    image.progressProperty().addListener(this);
                }
            }
        }
        
        private void cleanupAndFinishInitialization() {
            final Image[] images = this.images;
            for (int length = images.length, i = 0; i < length; ++i) {
                images[i].progressProperty().removeListener(this);
            }
            if (this.initAsSingle) {
                this.targetCursor.initialize(this.images[0], this.hotspotX, this.hotspotY);
            }
            else {
                this.targetCursor.initialize(this.images, this.hotspotX, this.hotspotY);
            }
        }
        
        @Override
        public void invalidated(final Observable observable) {
            if (((ReadOnlyDoubleProperty)observable).get() == 1.0 && --this.waitForImages == 0) {
                this.cleanupAndFinishInitialization();
            }
        }
    }
}
