// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util;

@FunctionalInterface
public interface BuilderFactory
{
    Builder<?> getBuilder(final Class<?> p0);
}
