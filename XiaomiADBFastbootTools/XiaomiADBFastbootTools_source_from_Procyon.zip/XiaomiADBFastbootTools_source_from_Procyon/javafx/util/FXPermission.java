// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util;

import java.security.BasicPermission;

public final class FXPermission extends BasicPermission
{
    private static final long serialVersionUID = 2890556410764946054L;
    
    public FXPermission(final String name) {
        super(name);
    }
}
