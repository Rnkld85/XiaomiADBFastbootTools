// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util;

public abstract class StringConverter<T>
{
    public abstract String toString(final T p0);
    
    public abstract T fromString(final String p0);
}
