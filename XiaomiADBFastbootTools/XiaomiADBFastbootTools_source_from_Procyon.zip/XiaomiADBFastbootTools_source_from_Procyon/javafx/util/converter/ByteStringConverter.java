// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import javafx.util.StringConverter;

public class ByteStringConverter extends StringConverter<Byte>
{
    @Override
    public Byte fromString(String trim) {
        if (trim == null) {
            return null;
        }
        trim = trim.trim();
        if (trim.length() < 1) {
            return null;
        }
        return Byte.valueOf(trim);
    }
    
    @Override
    public String toString(final Byte b) {
        if (b == null) {
            return "";
        }
        return Byte.toString(b);
    }
}
