// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import javafx.util.StringConverter;

public class CharacterStringConverter extends StringConverter<Character>
{
    @Override
    public Character fromString(String trim) {
        if (trim == null) {
            return null;
        }
        trim = trim.trim();
        if (trim.length() < 1) {
            return null;
        }
        return trim.charAt(0);
    }
    
    @Override
    public String toString(final Character c) {
        if (c == null) {
            return "";
        }
        return c.toString();
    }
}
