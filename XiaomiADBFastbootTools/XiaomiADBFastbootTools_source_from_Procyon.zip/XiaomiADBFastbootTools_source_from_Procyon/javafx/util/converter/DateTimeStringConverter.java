// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.text.DateFormat;
import java.util.Locale;
import java.util.Date;
import javafx.util.StringConverter;

public class DateTimeStringConverter extends StringConverter<Date>
{
    protected final Locale locale;
    protected final String pattern;
    protected final DateFormat dateFormat;
    protected final int dateStyle;
    protected final int timeStyle;
    
    public DateTimeStringConverter() {
        this(null, null, null, 2, 2);
    }
    
    public DateTimeStringConverter(final int n, final int n2) {
        this(null, null, null, n, n2);
    }
    
    public DateTimeStringConverter(final Locale locale) {
        this(locale, null, null, 2, 2);
    }
    
    public DateTimeStringConverter(final Locale locale, final int n, final int n2) {
        this(locale, null, null, n, n2);
    }
    
    public DateTimeStringConverter(final String s) {
        this(null, s, null, 2, 2);
    }
    
    public DateTimeStringConverter(final Locale locale, final String s) {
        this(locale, s, null, 2, 2);
    }
    
    public DateTimeStringConverter(final DateFormat dateFormat) {
        this(null, null, dateFormat, 2, 2);
    }
    
    DateTimeStringConverter(final Locale locale, final String pattern, final DateFormat dateFormat, final int dateStyle, final int timeStyle) {
        this.locale = ((locale != null) ? locale : Locale.getDefault(Locale.Category.FORMAT));
        this.pattern = pattern;
        this.dateFormat = dateFormat;
        this.dateStyle = dateStyle;
        this.timeStyle = timeStyle;
    }
    
    @Override
    public Date fromString(String trim) {
        try {
            if (trim == null) {
                return null;
            }
            trim = trim.trim();
            if (trim.length() < 1) {
                return null;
            }
            return this.getDateFormat().parse(trim);
        }
        catch (ParseException cause) {
            throw new RuntimeException(cause);
        }
    }
    
    @Override
    public String toString(final Date date) {
        if (date == null) {
            return "";
        }
        return this.getDateFormat().format(date);
    }
    
    protected DateFormat getDateFormat() {
        if (this.dateFormat != null) {
            return this.dateFormat;
        }
        DateFormat dateTimeInstance;
        if (this.pattern != null) {
            dateTimeInstance = new SimpleDateFormat(this.pattern, this.locale);
        }
        else {
            dateTimeInstance = DateFormat.getDateTimeInstance(this.dateStyle, this.timeStyle, this.locale);
        }
        dateTimeInstance.setLenient(false);
        return dateTimeInstance;
    }
}
