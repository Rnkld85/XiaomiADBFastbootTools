// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;

public class CurrencyStringConverter extends NumberStringConverter
{
    public CurrencyStringConverter() {
        this(Locale.getDefault());
    }
    
    public CurrencyStringConverter(final Locale locale) {
        this(locale, null);
    }
    
    public CurrencyStringConverter(final String s) {
        this(Locale.getDefault(), s);
    }
    
    public CurrencyStringConverter(final Locale locale, final String s) {
        super(locale, s, null);
    }
    
    public CurrencyStringConverter(final NumberFormat numberFormat) {
        super(null, null, numberFormat);
    }
    
    @Override
    protected NumberFormat getNumberFormat() {
        final Locale locale = (this.locale == null) ? Locale.getDefault() : this.locale;
        if (this.numberFormat != null) {
            return this.numberFormat;
        }
        if (this.pattern != null) {
            return new DecimalFormat(this.pattern, new DecimalFormatSymbols(locale));
        }
        return NumberFormat.getCurrencyInstance(locale);
    }
}
