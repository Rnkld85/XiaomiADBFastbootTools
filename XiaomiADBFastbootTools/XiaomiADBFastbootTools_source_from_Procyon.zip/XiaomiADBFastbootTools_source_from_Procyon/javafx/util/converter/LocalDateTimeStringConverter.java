// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.time.format.DecimalStyle;
import java.time.format.DateTimeFormatterBuilder;
import java.time.chrono.ChronoLocalDateTime;
import java.time.chrono.ChronoLocalDate;
import java.time.DateTimeException;
import com.sun.javafx.binding.Logging;
import java.time.temporal.TemporalAccessor;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.chrono.IsoChronology;
import java.time.temporal.Temporal;
import java.time.chrono.Chronology;
import java.util.Locale;
import java.time.format.FormatStyle;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import javafx.util.StringConverter;

public class LocalDateTimeStringConverter extends StringConverter<LocalDateTime>
{
    LdtConverter<LocalDateTime> ldtConverter;
    
    public LocalDateTimeStringConverter() {
        this.ldtConverter = new LdtConverter<LocalDateTime>(LocalDateTime.class, null, null, null, null, null, null);
    }
    
    public LocalDateTimeStringConverter(final FormatStyle formatStyle, final FormatStyle formatStyle2) {
        this.ldtConverter = new LdtConverter<LocalDateTime>(LocalDateTime.class, null, null, formatStyle, formatStyle2, null, null);
    }
    
    public LocalDateTimeStringConverter(final DateTimeFormatter dateTimeFormatter, final DateTimeFormatter dateTimeFormatter2) {
        this.ldtConverter = new LdtConverter<LocalDateTime>(LocalDateTime.class, dateTimeFormatter, dateTimeFormatter2, null, null, null, null);
    }
    
    public LocalDateTimeStringConverter(final FormatStyle formatStyle, final FormatStyle formatStyle2, final Locale locale, final Chronology chronology) {
        this.ldtConverter = new LdtConverter<LocalDateTime>(LocalDateTime.class, null, null, formatStyle, formatStyle2, locale, chronology);
    }
    
    @Override
    public LocalDateTime fromString(final String s) {
        return this.ldtConverter.fromString(s);
    }
    
    @Override
    public String toString(final LocalDateTime localDateTime) {
        return this.ldtConverter.toString(localDateTime);
    }
    
    static class LdtConverter<T extends Temporal> extends StringConverter<T>
    {
        private Class<T> type;
        Locale locale;
        Chronology chronology;
        DateTimeFormatter formatter;
        DateTimeFormatter parser;
        FormatStyle dateStyle;
        FormatStyle timeStyle;
        
        LdtConverter(final Class<T> type, final DateTimeFormatter formatter, final DateTimeFormatter dateTimeFormatter, final FormatStyle formatStyle, final FormatStyle formatStyle2, final Locale locale, final Chronology chronology) {
            this.type = type;
            this.formatter = formatter;
            this.parser = ((dateTimeFormatter != null) ? dateTimeFormatter : formatter);
            this.locale = ((locale != null) ? locale : Locale.getDefault(Locale.Category.FORMAT));
            this.chronology = ((chronology != null) ? chronology : IsoChronology.INSTANCE);
            if (type == LocalDate.class || type == LocalDateTime.class) {
                this.dateStyle = ((formatStyle != null) ? formatStyle : FormatStyle.SHORT);
            }
            if (type == LocalTime.class || type == LocalDateTime.class) {
                this.timeStyle = ((formatStyle2 != null) ? formatStyle2 : FormatStyle.SHORT);
            }
        }
        
        @Override
        public T fromString(String trim) {
            if (trim == null || trim.isEmpty()) {
                return null;
            }
            trim = trim.trim();
            if (this.parser == null) {
                this.parser = this.getDefaultParser();
            }
            final TemporalAccessor parse = this.parser.parse(trim);
            if (this.type == LocalDate.class) {
                return (T)LocalDate.from((TemporalAccessor)this.chronology.date(parse));
            }
            if (this.type == LocalTime.class) {
                return (T)LocalTime.from(parse);
            }
            return (T)LocalDateTime.from((TemporalAccessor)this.chronology.localDateTime(parse));
        }
        
        @Override
        public String toString(final T t) {
            if (t == null) {
                return "";
            }
            if (this.formatter == null) {
                this.formatter = this.getDefaultFormatter();
            }
            if (t instanceof LocalDate) {
                ChronoLocalDate date;
                try {
                    date = this.chronology.date(t);
                }
                catch (DateTimeException ex) {
                    Logging.getLogger().warning(invokedynamic(makeConcatWithConstants:(Ljava/time/temporal/Temporal;Ljava/time/chrono/Chronology;)Ljava/lang/String;, t, this.chronology), (Throwable)ex);
                    this.chronology = IsoChronology.INSTANCE;
                    date = (LocalDate)t;
                }
                return this.formatter.format(date);
            }
            if (t instanceof LocalDateTime) {
                ChronoLocalDateTime<? extends ChronoLocalDate> localDateTime;
                try {
                    localDateTime = this.chronology.localDateTime(t);
                }
                catch (DateTimeException ex2) {
                    Logging.getLogger().warning(invokedynamic(makeConcatWithConstants:(Ljava/time/temporal/Temporal;Ljava/time/chrono/Chronology;)Ljava/lang/String;, t, this.chronology), (Throwable)ex2);
                    this.chronology = IsoChronology.INSTANCE;
                    localDateTime = (LocalDateTime)t;
                }
                return this.formatter.format(localDateTime);
            }
            return this.formatter.format(t);
        }
        
        private DateTimeFormatter getDefaultParser() {
            return new DateTimeFormatterBuilder().parseLenient().appendPattern(DateTimeFormatterBuilder.getLocalizedDateTimePattern(this.dateStyle, this.timeStyle, this.chronology, this.locale)).toFormatter().withChronology(this.chronology).withDecimalStyle(DecimalStyle.of(this.locale));
        }
        
        private DateTimeFormatter getDefaultFormatter() {
            DateTimeFormatter dateTimeFormatter;
            if (this.dateStyle != null && this.timeStyle != null) {
                dateTimeFormatter = DateTimeFormatter.ofLocalizedDateTime(this.dateStyle, this.timeStyle);
            }
            else if (this.dateStyle != null) {
                dateTimeFormatter = DateTimeFormatter.ofLocalizedDate(this.dateStyle);
            }
            else {
                dateTimeFormatter = DateTimeFormatter.ofLocalizedTime(this.timeStyle);
            }
            DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter.withLocale(this.locale).withChronology(this.chronology).withDecimalStyle(DecimalStyle.of(this.locale));
            if (this.dateStyle != null) {
                dateTimeFormatter2 = this.fixFourDigitYear(dateTimeFormatter2, this.dateStyle, this.timeStyle, this.chronology, this.locale);
            }
            return dateTimeFormatter2;
        }
        
        private DateTimeFormatter fixFourDigitYear(DateTimeFormatter withDecimalStyle, final FormatStyle dateStyle, final FormatStyle timeStyle, final Chronology chrono, final Locale locale) {
            final String localizedDateTimePattern = DateTimeFormatterBuilder.getLocalizedDateTimePattern(dateStyle, timeStyle, chrono, locale);
            if (localizedDateTimePattern.contains("yy") && !localizedDateTimePattern.contains("yyy")) {
                withDecimalStyle = DateTimeFormatter.ofPattern(localizedDateTimePattern.replace("yy", "yyyy")).withDecimalStyle(DecimalStyle.of(locale));
            }
            return withDecimalStyle;
        }
    }
}
