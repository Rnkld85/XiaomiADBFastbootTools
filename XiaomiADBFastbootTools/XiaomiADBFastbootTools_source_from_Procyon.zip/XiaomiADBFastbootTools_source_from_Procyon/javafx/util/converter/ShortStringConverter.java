// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import javafx.util.StringConverter;

public class ShortStringConverter extends StringConverter<Short>
{
    @Override
    public Short fromString(String trim) {
        if (trim == null) {
            return null;
        }
        trim = trim.trim();
        if (trim.length() < 1) {
            return null;
        }
        return Short.valueOf(trim);
    }
    
    @Override
    public String toString(final Short n) {
        if (n == null) {
            return "";
        }
        return Short.toString(n);
    }
}
