// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.time.chrono.Chronology;
import java.util.Locale;
import java.time.format.FormatStyle;
import java.time.format.DateTimeFormatter;
import java.time.LocalTime;
import javafx.util.StringConverter;

public class LocalTimeStringConverter extends StringConverter<LocalTime>
{
    LocalDateTimeStringConverter.LdtConverter<LocalTime> ldtConverter;
    
    public LocalTimeStringConverter() {
        this.ldtConverter = new LocalDateTimeStringConverter.LdtConverter<LocalTime>(LocalTime.class, null, null, null, null, null, null);
    }
    
    public LocalTimeStringConverter(final FormatStyle formatStyle) {
        this.ldtConverter = new LocalDateTimeStringConverter.LdtConverter<LocalTime>(LocalTime.class, null, null, null, formatStyle, null, null);
    }
    
    public LocalTimeStringConverter(final FormatStyle formatStyle, final Locale locale) {
        this.ldtConverter = new LocalDateTimeStringConverter.LdtConverter<LocalTime>(LocalTime.class, null, null, null, formatStyle, locale, null);
    }
    
    public LocalTimeStringConverter(final DateTimeFormatter dateTimeFormatter, final DateTimeFormatter dateTimeFormatter2) {
        this.ldtConverter = new LocalDateTimeStringConverter.LdtConverter<LocalTime>(LocalTime.class, dateTimeFormatter, dateTimeFormatter2, null, null, null, null);
    }
    
    @Override
    public LocalTime fromString(final String s) {
        return this.ldtConverter.fromString(s);
    }
    
    @Override
    public String toString(final LocalTime localTime) {
        return this.ldtConverter.toString(localTime);
    }
}
