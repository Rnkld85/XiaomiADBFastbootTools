// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import javafx.util.StringConverter;

public class BooleanStringConverter extends StringConverter<Boolean>
{
    @Override
    public Boolean fromString(String trim) {
        if (trim == null) {
            return null;
        }
        trim = trim.trim();
        if (trim.length() < 1) {
            return null;
        }
        return Boolean.valueOf(trim);
    }
    
    @Override
    public String toString(final Boolean b) {
        if (b == null) {
            return "";
        }
        return b.toString();
    }
}
