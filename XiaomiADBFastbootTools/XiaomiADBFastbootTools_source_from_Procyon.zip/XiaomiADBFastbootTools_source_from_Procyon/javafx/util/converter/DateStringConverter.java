// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Locale;

public class DateStringConverter extends DateTimeStringConverter
{
    public DateStringConverter() {
        this(null, null, null, 2);
    }
    
    public DateStringConverter(final int n) {
        this(null, null, null, n);
    }
    
    public DateStringConverter(final Locale locale) {
        this(locale, null, null, 2);
    }
    
    public DateStringConverter(final Locale locale, final int n) {
        this(locale, null, null, n);
    }
    
    public DateStringConverter(final String s) {
        this(null, s, null, 2);
    }
    
    public DateStringConverter(final Locale locale, final String s) {
        this(locale, s, null, 2);
    }
    
    public DateStringConverter(final DateFormat dateFormat) {
        this(null, null, dateFormat, 2);
    }
    
    private DateStringConverter(final Locale locale, final String s, final DateFormat dateFormat, final int n) {
        super(locale, s, dateFormat, n, 2);
    }
    
    @Override
    protected DateFormat getDateFormat() {
        if (this.dateFormat != null) {
            return this.dateFormat;
        }
        DateFormat dateInstance;
        if (this.pattern != null) {
            dateInstance = new SimpleDateFormat(this.pattern, this.locale);
        }
        else {
            dateInstance = DateFormat.getDateInstance(this.dateStyle, this.locale);
        }
        dateInstance.setLenient(false);
        return dateInstance;
    }
}
