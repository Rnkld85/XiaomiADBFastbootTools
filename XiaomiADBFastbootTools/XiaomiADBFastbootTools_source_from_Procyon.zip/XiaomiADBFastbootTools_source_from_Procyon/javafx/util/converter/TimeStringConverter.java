// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Locale;

public class TimeStringConverter extends DateTimeStringConverter
{
    public TimeStringConverter() {
        this(null, null, null, 2);
    }
    
    public TimeStringConverter(final int n) {
        this(null, null, null, n);
    }
    
    public TimeStringConverter(final Locale locale) {
        this(locale, null, null, 2);
    }
    
    public TimeStringConverter(final Locale locale, final int n) {
        this(locale, null, null, n);
    }
    
    public TimeStringConverter(final String s) {
        this(null, s, null, 2);
    }
    
    public TimeStringConverter(final Locale locale, final String s) {
        this(locale, s, null, 2);
    }
    
    public TimeStringConverter(final DateFormat dateFormat) {
        this(null, null, dateFormat, 2);
    }
    
    private TimeStringConverter(final Locale locale, final String s, final DateFormat dateFormat, final int n) {
        super(locale, s, dateFormat, 2, n);
    }
    
    @Override
    protected DateFormat getDateFormat() {
        if (this.dateFormat != null) {
            return this.dateFormat;
        }
        DateFormat timeInstance;
        if (this.pattern != null) {
            timeInstance = new SimpleDateFormat(this.pattern, this.locale);
        }
        else {
            timeInstance = DateFormat.getTimeInstance(this.timeStyle, this.locale);
        }
        timeInstance.setLenient(false);
        return timeInstance;
    }
}
