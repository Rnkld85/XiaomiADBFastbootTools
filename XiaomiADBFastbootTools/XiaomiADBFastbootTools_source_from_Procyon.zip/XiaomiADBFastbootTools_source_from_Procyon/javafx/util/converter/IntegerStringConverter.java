// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import javafx.util.StringConverter;

public class IntegerStringConverter extends StringConverter<Integer>
{
    @Override
    public Integer fromString(String trim) {
        if (trim == null) {
            return null;
        }
        trim = trim.trim();
        if (trim.length() < 1) {
            return null;
        }
        return Integer.valueOf(trim);
    }
    
    @Override
    public String toString(final Integer n) {
        if (n == null) {
            return "";
        }
        return Integer.toString(n);
    }
}
