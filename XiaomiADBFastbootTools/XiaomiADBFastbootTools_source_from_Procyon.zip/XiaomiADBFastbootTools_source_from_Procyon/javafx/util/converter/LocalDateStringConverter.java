// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.time.chrono.Chronology;
import java.util.Locale;
import java.time.format.FormatStyle;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import javafx.util.StringConverter;

public class LocalDateStringConverter extends StringConverter<LocalDate>
{
    LocalDateTimeStringConverter.LdtConverter<LocalDate> ldtConverter;
    
    public LocalDateStringConverter() {
        this.ldtConverter = new LocalDateTimeStringConverter.LdtConverter<LocalDate>(LocalDate.class, null, null, null, null, null, null);
    }
    
    public LocalDateStringConverter(final FormatStyle formatStyle) {
        this.ldtConverter = new LocalDateTimeStringConverter.LdtConverter<LocalDate>(LocalDate.class, null, null, formatStyle, null, null, null);
    }
    
    public LocalDateStringConverter(final DateTimeFormatter dateTimeFormatter, final DateTimeFormatter dateTimeFormatter2) {
        this.ldtConverter = new LocalDateTimeStringConverter.LdtConverter<LocalDate>(LocalDate.class, dateTimeFormatter, dateTimeFormatter2, null, null, null, null);
    }
    
    public LocalDateStringConverter(final FormatStyle formatStyle, final Locale locale, final Chronology chronology) {
        this.ldtConverter = new LocalDateTimeStringConverter.LdtConverter<LocalDate>(LocalDate.class, null, null, formatStyle, null, locale, chronology);
    }
    
    @Override
    public LocalDate fromString(final String s) {
        return this.ldtConverter.fromString(s);
    }
    
    @Override
    public String toString(final LocalDate localDate) {
        return this.ldtConverter.toString(localDate);
    }
}
