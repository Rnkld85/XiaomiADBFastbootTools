// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.text.ParsePosition;
import javafx.beans.NamedArg;
import java.text.Format;
import javafx.util.StringConverter;

public class FormatStringConverter<T> extends StringConverter<T>
{
    final Format format;
    
    public FormatStringConverter(@NamedArg("format") final Format format) {
        this.format = format;
    }
    
    @Override
    public T fromString(String trim) {
        if (trim == null) {
            return null;
        }
        trim = trim.trim();
        if (trim.length() < 1) {
            return null;
        }
        final Format format = this.getFormat();
        final ParsePosition parsePosition = new ParsePosition(0);
        final Object object = format.parseObject(trim, parsePosition);
        if (parsePosition.getIndex() != trim.length()) {
            throw new RuntimeException("Parsed string not according to the format");
        }
        return (T)object;
    }
    
    @Override
    public String toString(final T obj) {
        if (obj == null) {
            return "";
        }
        return this.getFormat().format(obj);
    }
    
    protected Format getFormat() {
        return this.format;
    }
}
