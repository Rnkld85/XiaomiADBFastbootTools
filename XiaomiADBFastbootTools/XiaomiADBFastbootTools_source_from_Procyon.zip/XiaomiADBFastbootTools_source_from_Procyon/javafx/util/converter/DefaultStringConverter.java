// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import javafx.util.StringConverter;

public class DefaultStringConverter extends StringConverter<String>
{
    @Override
    public String toString(final String s) {
        return (s != null) ? s : "";
    }
    
    @Override
    public String fromString(final String s) {
        return s;
    }
}
