// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.text.NumberFormat;
import java.util.Locale;

public class PercentageStringConverter extends NumberStringConverter
{
    public PercentageStringConverter() {
        this(Locale.getDefault());
    }
    
    public PercentageStringConverter(final Locale locale) {
        super(locale, null, null);
    }
    
    public PercentageStringConverter(final NumberFormat numberFormat) {
        super(null, null, numberFormat);
    }
    
    public NumberFormat getNumberFormat() {
        final Locale inLocale = (this.locale == null) ? Locale.getDefault() : this.locale;
        if (this.numberFormat != null) {
            return this.numberFormat;
        }
        return NumberFormat.getPercentInstance(inLocale);
    }
}
