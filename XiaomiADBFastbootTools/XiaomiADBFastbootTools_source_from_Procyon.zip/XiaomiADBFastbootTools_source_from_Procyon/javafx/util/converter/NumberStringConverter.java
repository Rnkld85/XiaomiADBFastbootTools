// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.NumberFormat;
import java.util.Locale;
import javafx.util.StringConverter;

public class NumberStringConverter extends StringConverter<Number>
{
    final Locale locale;
    final String pattern;
    final NumberFormat numberFormat;
    
    public NumberStringConverter() {
        this(Locale.getDefault());
    }
    
    public NumberStringConverter(final Locale locale) {
        this(locale, null);
    }
    
    public NumberStringConverter(final String s) {
        this(Locale.getDefault(), s);
    }
    
    public NumberStringConverter(final Locale locale, final String s) {
        this(locale, s, null);
    }
    
    public NumberStringConverter(final NumberFormat numberFormat) {
        this(null, null, numberFormat);
    }
    
    NumberStringConverter(final Locale locale, final String pattern, final NumberFormat numberFormat) {
        this.locale = locale;
        this.pattern = pattern;
        this.numberFormat = numberFormat;
    }
    
    @Override
    public Number fromString(String trim) {
        try {
            if (trim == null) {
                return null;
            }
            trim = trim.trim();
            if (trim.length() < 1) {
                return null;
            }
            return this.getNumberFormat().parse(trim);
        }
        catch (ParseException cause) {
            throw new RuntimeException(cause);
        }
    }
    
    @Override
    public String toString(final Number obj) {
        if (obj == null) {
            return "";
        }
        return this.getNumberFormat().format(obj);
    }
    
    protected NumberFormat getNumberFormat() {
        final Locale locale = (this.locale == null) ? Locale.getDefault() : this.locale;
        if (this.numberFormat != null) {
            return this.numberFormat;
        }
        if (this.pattern != null) {
            return new DecimalFormat(this.pattern, new DecimalFormatSymbols(locale));
        }
        return NumberFormat.getNumberInstance(locale);
    }
}
