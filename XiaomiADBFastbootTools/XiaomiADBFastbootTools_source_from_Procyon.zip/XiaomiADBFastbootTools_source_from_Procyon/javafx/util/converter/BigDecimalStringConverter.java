// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import java.math.BigDecimal;
import javafx.util.StringConverter;

public class BigDecimalStringConverter extends StringConverter<BigDecimal>
{
    @Override
    public BigDecimal fromString(String trim) {
        if (trim == null) {
            return null;
        }
        trim = trim.trim();
        if (trim.length() < 1) {
            return null;
        }
        return new BigDecimal(trim);
    }
    
    @Override
    public String toString(final BigDecimal bigDecimal) {
        if (bigDecimal == null) {
            return "";
        }
        return bigDecimal.toString();
    }
}
