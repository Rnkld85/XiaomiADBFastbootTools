// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util.converter;

import javafx.util.StringConverter;

public class FloatStringConverter extends StringConverter<Float>
{
    @Override
    public Float fromString(String trim) {
        if (trim == null) {
            return null;
        }
        trim = trim.trim();
        if (trim.length() < 1) {
            return null;
        }
        return Float.valueOf(trim);
    }
    
    @Override
    public String toString(final Float n) {
        if (n == null) {
            return "";
        }
        return Float.toString(n);
    }
}
