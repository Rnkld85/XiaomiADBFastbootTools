// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util;

import javafx.beans.NamedArg;
import java.io.Serializable;

public class Pair<K, V> implements Serializable
{
    private K key;
    private V value;
    
    public K getKey() {
        return this.key;
    }
    
    public V getValue() {
        return this.value;
    }
    
    public Pair(@NamedArg("key") final K key, @NamedArg("value") final V value) {
        this.key = key;
        this.value = value;
    }
    
    @Override
    public String toString() {
        return invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;, this.key, this.value);
    }
    
    @Override
    public int hashCode() {
        return 31 * (31 * 7 + ((this.key != null) ? this.key.hashCode() : 0)) + ((this.value != null) ? this.value.hashCode() : 0);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o instanceof Pair) {
            final Pair pair = (Pair)o;
            Label_0052: {
                if (this.key != null) {
                    if (this.key.equals(pair.key)) {
                        break Label_0052;
                    }
                }
                else if (pair.key == null) {
                    break Label_0052;
                }
                return false;
            }
            if (this.value != null) {
                if (this.value.equals(pair.value)) {
                    return true;
                }
            }
            else if (pair.value == null) {
                return true;
            }
            return false;
        }
        return false;
    }
}
