// 
// Decompiled by Procyon v0.5.36
// 

package javafx.util;

import javafx.beans.NamedArg;
import java.io.Serializable;

public class Duration implements Comparable<Duration>, Serializable
{
    public static final Duration ZERO;
    public static final Duration ONE;
    public static final Duration INDEFINITE;
    public static final Duration UNKNOWN;
    private final double millis;
    
    public static Duration valueOf(final String s) {
        int n = -1;
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            if (!Character.isDigit(char1) && char1 != '.' && char1 != '-') {
                n = i;
                break;
            }
        }
        if (n == -1) {
            throw new IllegalArgumentException("The time parameter must have a suffix of [ms|s|m|h]");
        }
        final double double1 = Double.parseDouble(s.substring(0, n));
        final String substring = s.substring(n);
        if ("ms".equals(substring)) {
            return millis(double1);
        }
        if ("s".equals(substring)) {
            return seconds(double1);
        }
        if ("m".equals(substring)) {
            return minutes(double1);
        }
        if ("h".equals(substring)) {
            return hours(double1);
        }
        throw new IllegalArgumentException("The time parameter must have a suffix of [ms|s|m|h]");
    }
    
    public static Duration millis(final double v) {
        if (v == 0.0) {
            return Duration.ZERO;
        }
        if (v == 1.0) {
            return Duration.ONE;
        }
        if (v == Double.POSITIVE_INFINITY) {
            return Duration.INDEFINITE;
        }
        if (Double.isNaN(v)) {
            return Duration.UNKNOWN;
        }
        return new Duration(v);
    }
    
    public static Duration seconds(final double v) {
        if (v == 0.0) {
            return Duration.ZERO;
        }
        if (v == Double.POSITIVE_INFINITY) {
            return Duration.INDEFINITE;
        }
        if (Double.isNaN(v)) {
            return Duration.UNKNOWN;
        }
        return new Duration(v * 1000.0);
    }
    
    public static Duration minutes(final double v) {
        if (v == 0.0) {
            return Duration.ZERO;
        }
        if (v == Double.POSITIVE_INFINITY) {
            return Duration.INDEFINITE;
        }
        if (Double.isNaN(v)) {
            return Duration.UNKNOWN;
        }
        return new Duration(v * 60000.0);
    }
    
    public static Duration hours(final double v) {
        if (v == 0.0) {
            return Duration.ZERO;
        }
        if (v == Double.POSITIVE_INFINITY) {
            return Duration.INDEFINITE;
        }
        if (Double.isNaN(v)) {
            return Duration.UNKNOWN;
        }
        return new Duration(v * 3600000.0);
    }
    
    public Duration(@NamedArg("millis") final double millis) {
        this.millis = millis;
    }
    
    public double toMillis() {
        return this.millis;
    }
    
    public double toSeconds() {
        return this.millis / 1000.0;
    }
    
    public double toMinutes() {
        return this.millis / 60000.0;
    }
    
    public double toHours() {
        return this.millis / 3600000.0;
    }
    
    public Duration add(final Duration duration) {
        return millis(this.millis + duration.millis);
    }
    
    public Duration subtract(final Duration duration) {
        return millis(this.millis - duration.millis);
    }
    
    @Deprecated
    public Duration multiply(final Duration duration) {
        return millis(this.millis * duration.millis);
    }
    
    public Duration multiply(final double n) {
        return millis(this.millis * n);
    }
    
    public Duration divide(final double n) {
        return millis(this.millis / n);
    }
    
    @Deprecated
    public Duration divide(final Duration duration) {
        return millis(this.millis / duration.millis);
    }
    
    public Duration negate() {
        return millis(-this.millis);
    }
    
    public boolean isIndefinite() {
        return this.millis == Double.POSITIVE_INFINITY;
    }
    
    public boolean isUnknown() {
        return Double.isNaN(this.millis);
    }
    
    public boolean lessThan(final Duration duration) {
        return this.millis < duration.millis;
    }
    
    public boolean lessThanOrEqualTo(final Duration duration) {
        return this.millis <= duration.millis;
    }
    
    public boolean greaterThan(final Duration duration) {
        return this.millis > duration.millis;
    }
    
    public boolean greaterThanOrEqualTo(final Duration duration) {
        return this.millis >= duration.millis;
    }
    
    @Override
    public String toString() {
        return this.isIndefinite() ? "INDEFINITE" : (this.isUnknown() ? "UNKNOWN" : invokedynamic(makeConcatWithConstants:(D)Ljava/lang/String;, this.millis));
    }
    
    @Override
    public int compareTo(final Duration duration) {
        return Double.compare(this.millis, duration.millis);
    }
    
    @Override
    public boolean equals(final Object o) {
        return o == this || (o instanceof Duration && this.millis == ((Duration)o).millis);
    }
    
    @Override
    public int hashCode() {
        final long doubleToLongBits = Double.doubleToLongBits(this.millis);
        return (int)(doubleToLongBits ^ doubleToLongBits >>> 32);
    }
    
    static {
        ZERO = new Duration(0.0);
        ONE = new Duration(1.0);
        INDEFINITE = new Duration(Double.POSITIVE_INFINITY);
        UNKNOWN = new Duration(Double.NaN);
    }
}
