// 
// Decompiled by Procyon v0.5.36
// 

package javafx.application;

import javafx.beans.value.ObservableValue;
import javafx.beans.property.ReadOnlyBooleanProperty;
import com.sun.javafx.tk.Toolkit;
import com.sun.javafx.application.PlatformImpl;
import javafx.beans.property.ReadOnlyBooleanWrapper;

public final class Platform
{
    private static ReadOnlyBooleanWrapper accessibilityActiveProperty;
    
    private Platform() {
    }
    
    public static void startup(final Runnable runnable) {
        PlatformImpl.startup(runnable, true);
    }
    
    public static void runLater(final Runnable runnable) {
        PlatformImpl.runLater(runnable);
    }
    
    public static void requestNextPulse() {
        Toolkit.getToolkit().requestNextPulse();
    }
    
    public static boolean isFxApplicationThread() {
        return PlatformImpl.isFxApplicationThread();
    }
    
    public static void exit() {
        PlatformImpl.exit();
    }
    
    public static void setImplicitExit(final boolean implicitExit) {
        PlatformImpl.setImplicitExit(implicitExit);
    }
    
    public static boolean isImplicitExit() {
        return PlatformImpl.isImplicitExit();
    }
    
    public static boolean isSupported(final ConditionalFeature conditionalFeature) {
        return PlatformImpl.isSupported(conditionalFeature);
    }
    
    public static Object enterNestedEventLoop(final Object o) {
        return Toolkit.getToolkit().enterNestedEventLoop(o);
    }
    
    public static void exitNestedEventLoop(final Object o, final Object o2) {
        Toolkit.getToolkit().exitNestedEventLoop(o, o2);
    }
    
    public static boolean isNestedLoopRunning() {
        return Toolkit.getToolkit().isNestedLoopRunning();
    }
    
    public static boolean isAccessibilityActive() {
        return Platform.accessibilityActiveProperty != null && Platform.accessibilityActiveProperty.get();
    }
    
    public static ReadOnlyBooleanProperty accessibilityActiveProperty() {
        if (Platform.accessibilityActiveProperty == null) {
            (Platform.accessibilityActiveProperty = new ReadOnlyBooleanWrapper(Platform.class, "accessibilityActive")).bind(PlatformImpl.accessibilityActiveProperty());
        }
        return Platform.accessibilityActiveProperty.getReadOnlyProperty();
    }
}
