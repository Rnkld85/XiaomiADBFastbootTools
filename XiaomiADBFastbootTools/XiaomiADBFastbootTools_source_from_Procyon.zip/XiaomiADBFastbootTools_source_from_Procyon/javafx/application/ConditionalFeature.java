// 
// Decompiled by Procyon v0.5.36
// 

package javafx.application;

public enum ConditionalFeature
{
    GRAPHICS, 
    CONTROLS, 
    MEDIA, 
    WEB, 
    SWT, 
    SWING, 
    FXML, 
    SCENE3D, 
    EFFECT, 
    SHAPE_CLIP, 
    INPUT_METHOD, 
    TRANSPARENT_WINDOW, 
    UNIFIED_WINDOW, 
    TWO_LEVEL_FOCUS, 
    VIRTUAL_KEYBOARD, 
    INPUT_TOUCH, 
    INPUT_MULTITOUCH, 
    INPUT_POINTER;
}
