// 
// Decompiled by Procyon v0.5.36
// 

package javafx.application;

import java.security.AccessController;

public abstract class Preloader extends Application
{
    private static final String lineSeparator;
    
    public void handleProgressNotification(final ProgressNotification progressNotification) {
    }
    
    public void handleStateChangeNotification(final StateChangeNotification stateChangeNotification) {
    }
    
    public void handleApplicationNotification(final PreloaderNotification preloaderNotification) {
    }
    
    public boolean handleErrorNotification(final ErrorNotification errorNotification) {
        return false;
    }
    
    static {
        final String s = AccessController.doPrivileged(() -> System.getProperty("line.separator"));
        lineSeparator = ((s != null) ? s : "\n");
    }
    
    public static class ErrorNotification implements PreloaderNotification
    {
        private String location;
        private String details;
        private Throwable cause;
        
        public ErrorNotification(final String location, final String details, final Throwable cause) {
            this.details = "";
            if (details == null) {
                throw new NullPointerException();
            }
            this.location = location;
            this.details = details;
            this.cause = cause;
        }
        
        public String getLocation() {
            return this.location;
        }
        
        public String getDetails() {
            return this.details;
        }
        
        public Throwable getCause() {
            return this.cause;
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("Preloader.ErrorNotification: ");
            sb.append(this.details);
            if (this.cause != null) {
                sb.append(Preloader.lineSeparator).append("Caused by: ").append(this.cause.toString());
            }
            if (this.location != null) {
                sb.append(Preloader.lineSeparator).append("Location: ").append(this.location);
            }
            return sb.toString();
        }
    }
    
    public static class ProgressNotification implements PreloaderNotification
    {
        private final double progress;
        private final String details;
        
        public ProgressNotification(final double n) {
            this(n, "");
        }
        
        private ProgressNotification(final double progress, final String details) {
            this.progress = progress;
            this.details = details;
        }
        
        public double getProgress() {
            return this.progress;
        }
        
        private String getDetails() {
            return this.details;
        }
    }
    
    public static class StateChangeNotification implements PreloaderNotification
    {
        private final Type notificationType;
        private final Application application;
        
        public StateChangeNotification(final Type notificationType) {
            this.notificationType = notificationType;
            this.application = null;
        }
        
        public StateChangeNotification(final Type notificationType, final Application application) {
            this.notificationType = notificationType;
            this.application = application;
        }
        
        public Type getType() {
            return this.notificationType;
        }
        
        public Application getApplication() {
            return this.application;
        }
        
        public enum Type
        {
            BEFORE_LOAD, 
            BEFORE_INIT, 
            BEFORE_START;
        }
    }
    
    public interface PreloaderNotification
    {
    }
}
