// 
// Decompiled by Procyon v0.5.36
// 

package javafx.application;

import java.util.Map;
import java.util.List;
import com.sun.javafx.application.PlatformImpl;
import com.sun.javafx.application.ParametersImpl;
import javafx.stage.Stage;
import com.sun.javafx.application.LauncherImpl;

public abstract class Application
{
    public static final String STYLESHEET_CASPIAN = "CASPIAN";
    public static final String STYLESHEET_MODENA = "MODENA";
    private HostServices hostServices;
    private static String userAgentStylesheet;
    
    public static void launch(final Class<? extends Application> clazz, final String... array) {
        LauncherImpl.launchApplication(clazz, array);
    }
    
    public static void launch(final String... array) {
        final StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        int n = 0;
        String name = null;
        for (final StackTraceElement stackTraceElement : stackTrace) {
            final String className = stackTraceElement.getClassName();
            final String methodName = stackTraceElement.getMethodName();
            if (n != 0) {
                name = className;
                break;
            }
            if (Application.class.getName().equals(className) && "launch".equals(methodName)) {
                n = 1;
            }
        }
        if (name == null) {
            throw new RuntimeException("Error: unable to determine Application class");
        }
        try {
            final Class<?> forName = Class.forName(name, false, Thread.currentThread().getContextClassLoader());
            if (!Application.class.isAssignableFrom(forName)) {
                throw new RuntimeException(invokedynamic(makeConcatWithConstants:(Ljava/lang/Class;)Ljava/lang/String;, forName));
            }
            LauncherImpl.launchApplication((Class<? extends Application>)forName, array);
        }
        catch (RuntimeException ex) {
            throw ex;
        }
        catch (Exception cause) {
            throw new RuntimeException(cause);
        }
    }
    
    public Application() {
        this.hostServices = null;
    }
    
    public void init() throws Exception {
    }
    
    public abstract void start(final Stage p0) throws Exception;
    
    public void stop() throws Exception {
    }
    
    public final HostServices getHostServices() {
        synchronized (this) {
            if (this.hostServices == null) {
                this.hostServices = new HostServices(this);
            }
            return this.hostServices;
        }
    }
    
    public final Parameters getParameters() {
        return ParametersImpl.getParameters(this);
    }
    
    public final void notifyPreloader(final Preloader.PreloaderNotification preloaderNotification) {
        LauncherImpl.notifyPreloader(this, preloaderNotification);
    }
    
    public static String getUserAgentStylesheet() {
        return Application.userAgentStylesheet;
    }
    
    public static void setUserAgentStylesheet(final String s) {
        Application.userAgentStylesheet = s;
        if (s == null) {
            PlatformImpl.setDefaultPlatformUserAgentStylesheet();
        }
        else {
            PlatformImpl.setPlatformUserAgentStylesheet(s);
        }
    }
    
    static {
        Application.userAgentStylesheet = null;
    }
    
    public abstract static class Parameters
    {
        public abstract List<String> getRaw();
        
        public abstract List<String> getUnnamed();
        
        public abstract Map<String, String> getNamed();
    }
}
