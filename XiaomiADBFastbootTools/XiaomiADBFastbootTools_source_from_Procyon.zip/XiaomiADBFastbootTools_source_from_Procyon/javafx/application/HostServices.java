// 
// Decompiled by Procyon v0.5.36
// 

package javafx.application;

import java.net.URI;
import com.sun.javafx.application.HostServicesDelegate;

public final class HostServices
{
    private final HostServicesDelegate delegate;
    
    HostServices(final Application application) {
        this.delegate = HostServicesDelegate.getInstance(application);
    }
    
    public final String getCodeBase() {
        return this.delegate.getCodeBase();
    }
    
    public final String getDocumentBase() {
        return this.delegate.getDocumentBase();
    }
    
    public final String resolveURI(final String str, final String str2) {
        return URI.create(str).resolve(str2).toString();
    }
    
    public final void showDocument(final String s) {
        this.delegate.showDocument(s);
    }
}
