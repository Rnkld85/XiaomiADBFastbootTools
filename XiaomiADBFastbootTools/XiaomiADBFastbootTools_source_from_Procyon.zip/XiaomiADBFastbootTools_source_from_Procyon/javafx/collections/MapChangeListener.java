// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

@FunctionalInterface
public interface MapChangeListener<K, V>
{
    void onChanged(final Change<? extends K, ? extends V> p0);
    
    public abstract static class Change<K, V>
    {
        private final ObservableMap<K, V> map;
        
        public Change(final ObservableMap<K, V> map) {
            this.map = map;
        }
        
        public ObservableMap<K, V> getMap() {
            return this.map;
        }
        
        public abstract boolean wasAdded();
        
        public abstract boolean wasRemoved();
        
        public abstract K getKey();
        
        public abstract V getValueAdded();
        
        public abstract V getValueRemoved();
    }
}
