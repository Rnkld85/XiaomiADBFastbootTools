// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import javafx.beans.InvalidationListener;
import com.sun.javafx.collections.ArrayListenerHelper;

public abstract class ObservableArrayBase<T extends ObservableArray<T>> implements ObservableArray<T>
{
    private ArrayListenerHelper<T> listenerHelper;
    
    @Override
    public final void addListener(final InvalidationListener invalidationListener) {
        this.listenerHelper = (ArrayListenerHelper<T>)ArrayListenerHelper.addListener((ArrayListenerHelper<ObservableArray>)this.listenerHelper, this, invalidationListener);
    }
    
    @Override
    public final void removeListener(final InvalidationListener invalidationListener) {
        this.listenerHelper = (ArrayListenerHelper<T>)ArrayListenerHelper.removeListener((ArrayListenerHelper<ObservableArray>)this.listenerHelper, invalidationListener);
    }
    
    @Override
    public final void addListener(final ArrayChangeListener<T> arrayChangeListener) {
        this.listenerHelper = (ArrayListenerHelper<T>)ArrayListenerHelper.addListener((ArrayListenerHelper<ObservableArray>)this.listenerHelper, this, arrayChangeListener);
    }
    
    @Override
    public final void removeListener(final ArrayChangeListener<T> arrayChangeListener) {
        this.listenerHelper = (ArrayListenerHelper<T>)ArrayListenerHelper.removeListener((ArrayListenerHelper<ObservableArray>)this.listenerHelper, arrayChangeListener);
    }
    
    protected final void fireChange(final boolean b, final int n, final int n2) {
        ArrayListenerHelper.fireValueChangedEvent((ArrayListenerHelper<ObservableArray>)this.listenerHelper, b, n, n2);
    }
}
