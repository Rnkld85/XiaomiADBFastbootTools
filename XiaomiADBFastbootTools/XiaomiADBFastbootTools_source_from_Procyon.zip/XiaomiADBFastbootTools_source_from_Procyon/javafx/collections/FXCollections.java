// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import com.sun.javafx.collections.MapAdapterChange;
import com.sun.javafx.collections.MapListenerHelper;
import java.util.AbstractMap;
import com.sun.javafx.collections.SetAdapterChange;
import com.sun.javafx.collections.SetListenerHelper;
import java.util.AbstractSet;
import java.lang.reflect.Array;
import com.sun.javafx.collections.ListListenerHelper;
import com.sun.javafx.collections.SourceAdapterChange;
import java.util.NoSuchElementException;
import java.util.Iterator;
import javafx.beans.InvalidationListener;
import java.util.ListIterator;
import java.util.AbstractList;
import java.util.Comparator;
import com.sun.javafx.collections.SortableList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.ArrayList;
import com.sun.javafx.collections.ObservableFloatArrayImpl;
import com.sun.javafx.collections.ObservableIntegerArrayImpl;
import com.sun.javafx.collections.UnmodifiableObservableMap;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import com.sun.javafx.collections.ObservableSetWrapper;
import java.util.Set;
import com.sun.javafx.collections.ObservableMapWrapper;
import java.util.Map;
import javafx.beans.Observable;
import javafx.util.Callback;
import com.sun.javafx.collections.ObservableSequentialListWrapper;
import com.sun.javafx.collections.ObservableListWrapper;
import java.util.RandomAccess;
import java.util.List;
import java.util.Random;

public class FXCollections
{
    private static ObservableMap EMPTY_OBSERVABLE_MAP;
    private static ObservableList EMPTY_OBSERVABLE_LIST;
    private static ObservableSet EMPTY_OBSERVABLE_SET;
    private static Random r;
    
    private FXCollections() {
    }
    
    public static <E> ObservableList<E> observableList(final List<E> list) {
        if (list == null) {
            throw new NullPointerException();
        }
        return (list instanceof RandomAccess) ? new ObservableListWrapper<E>((List<Object>)list) : new ObservableSequentialListWrapper<E>((List<Object>)list);
    }
    
    public static <E> ObservableList<E> observableList(final List<E> list, final Callback<E, Observable[]> callback) {
        if (list == null || callback == null) {
            throw new NullPointerException();
        }
        return (list instanceof RandomAccess) ? new ObservableListWrapper<E>((List<Object>)list, (Callback<Object, Observable[]>)callback) : new ObservableSequentialListWrapper<E>((List<Object>)list, (Callback<Object, Observable[]>)callback);
    }
    
    public static <K, V> ObservableMap<K, V> observableMap(final Map<K, V> map) {
        if (map == null) {
            throw new NullPointerException();
        }
        return new ObservableMapWrapper<K, V>(map);
    }
    
    public static <E> ObservableSet<E> observableSet(final Set<E> set) {
        if (set == null) {
            throw new NullPointerException();
        }
        return new ObservableSetWrapper<E>(set);
    }
    
    public static <E> ObservableSet<E> observableSet(final E... elements) {
        if (elements == null) {
            throw new NullPointerException();
        }
        final HashSet<Object> c = new HashSet<Object>(elements.length);
        Collections.addAll(c, elements);
        return new ObservableSetWrapper<E>((Set<E>)c);
    }
    
    public static <K, V> ObservableMap<K, V> unmodifiableObservableMap(final ObservableMap<K, V> observableMap) {
        if (observableMap == null) {
            throw new NullPointerException();
        }
        return new UnmodifiableObservableMap<K, V>(observableMap);
    }
    
    public static <K, V> ObservableMap<K, V> checkedObservableMap(final ObservableMap<K, V> observableMap, final Class<K> clazz, final Class<V> clazz2) {
        if (observableMap == null || clazz == null || clazz2 == null) {
            throw new NullPointerException();
        }
        return new CheckedObservableMap<K, V>(observableMap, clazz, clazz2);
    }
    
    public static <K, V> ObservableMap<K, V> synchronizedObservableMap(final ObservableMap<K, V> observableMap) {
        if (observableMap == null) {
            throw new NullPointerException();
        }
        return new SynchronizedObservableMap<K, V>(observableMap);
    }
    
    public static <K, V> ObservableMap<K, V> emptyObservableMap() {
        return (ObservableMap<K, V>)FXCollections.EMPTY_OBSERVABLE_MAP;
    }
    
    public static ObservableIntegerArray observableIntegerArray() {
        return new ObservableIntegerArrayImpl();
    }
    
    public static ObservableIntegerArray observableIntegerArray(final int... array) {
        return new ObservableIntegerArrayImpl(array);
    }
    
    public static ObservableIntegerArray observableIntegerArray(final ObservableIntegerArray observableIntegerArray) {
        return new ObservableIntegerArrayImpl(observableIntegerArray);
    }
    
    public static ObservableFloatArray observableFloatArray() {
        return new ObservableFloatArrayImpl();
    }
    
    public static ObservableFloatArray observableFloatArray(final float... array) {
        return new ObservableFloatArrayImpl(array);
    }
    
    public static ObservableFloatArray observableFloatArray(final ObservableFloatArray observableFloatArray) {
        return new ObservableFloatArrayImpl(observableFloatArray);
    }
    
    public static <E> ObservableList<E> observableArrayList() {
        return observableList(new ArrayList<E>());
    }
    
    public static <E> ObservableList<E> observableArrayList(final Callback<E, Observable[]> callback) {
        return observableList(new ArrayList<E>(), callback);
    }
    
    public static <E> ObservableList<E> observableArrayList(final E... array) {
        final ObservableList<E> observableArrayList = observableArrayList();
        observableArrayList.addAll(array);
        return observableArrayList;
    }
    
    public static <E> ObservableList<E> observableArrayList(final Collection<? extends E> collection) {
        final ObservableList<Object> observableArrayList = (ObservableList<Object>)observableArrayList();
        observableArrayList.addAll(collection);
        return (ObservableList<E>)observableArrayList;
    }
    
    public static <K, V> ObservableMap<K, V> observableHashMap() {
        return observableMap(new HashMap<K, V>());
    }
    
    public static <E> ObservableList<E> concat(final ObservableList<E>... array) {
        if (array.length == 0) {
            return observableArrayList();
        }
        if (array.length == 1) {
            return observableArrayList((Collection<? extends E>)array[0]);
        }
        final ArrayList<E> list = new ArrayList<E>();
        for (int length = array.length, i = 0; i < length; ++i) {
            list.addAll((Collection<? extends E>)array[i]);
        }
        return observableList(list);
    }
    
    public static <E> ObservableList<E> unmodifiableObservableList(final ObservableList<E> list) {
        if (list == null) {
            throw new NullPointerException();
        }
        return new UnmodifiableObservableListImpl<E>(list);
    }
    
    public static <E> ObservableList<E> checkedObservableList(final ObservableList<E> list, final Class<E> clazz) {
        if (list == null) {
            throw new NullPointerException();
        }
        return new CheckedObservableList<E>(list, clazz);
    }
    
    public static <E> ObservableList<E> synchronizedObservableList(final ObservableList<E> list) {
        if (list == null) {
            throw new NullPointerException();
        }
        return new SynchronizedObservableList<E>(list);
    }
    
    public static <E> ObservableList<E> emptyObservableList() {
        return (ObservableList<E>)FXCollections.EMPTY_OBSERVABLE_LIST;
    }
    
    public static <E> ObservableList<E> singletonObservableList(final E e) {
        return new SingletonObservableList<E>(e);
    }
    
    public static <E> ObservableSet<E> unmodifiableObservableSet(final ObservableSet<E> set) {
        if (set == null) {
            throw new NullPointerException();
        }
        return new UnmodifiableObservableSet<E>(set);
    }
    
    public static <E> ObservableSet<E> checkedObservableSet(final ObservableSet<E> set, final Class<E> clazz) {
        if (set == null) {
            throw new NullPointerException();
        }
        return new CheckedObservableSet<E>(set, clazz);
    }
    
    public static <E> ObservableSet<E> synchronizedObservableSet(final ObservableSet<E> set) {
        if (set == null) {
            throw new NullPointerException();
        }
        return new SynchronizedObservableSet<E>(set);
    }
    
    public static <E> ObservableSet<E> emptyObservableSet() {
        return (ObservableSet<E>)FXCollections.EMPTY_OBSERVABLE_SET;
    }
    
    public static <T> void copy(final ObservableList<? super T> list, final List<? extends T> list2) {
        final int size = list2.size();
        if (size > list.size()) {
            throw new IndexOutOfBoundsException("Source does not fit in dest");
        }
        final Object[] array = list.toArray();
        System.arraycopy(list2.toArray(), 0, array, 0, size);
        list.setAll((Object[])array);
    }
    
    public static <T> void fill(final ObservableList<? super T> list, final T val) {
        final Object[] array = new Object[list.size()];
        Arrays.fill(array, val);
        list.setAll((Object[])array);
    }
    
    public static <T> boolean replaceAll(final ObservableList<T> list, final T obj, final T t) {
        final Object[] array = list.toArray();
        boolean b = false;
        for (int i = 0; i < ((T[])array).length; ++i) {
            if (array[i].equals(obj)) {
                array[i] = t;
                b = true;
            }
        }
        if (b) {
            list.setAll((T[])array);
        }
        return b;
    }
    
    public static void reverse(final ObservableList list) {
        final Object[] array = list.toArray();
        for (int i = 0; i < array.length / 2; ++i) {
            final Object o = array[i];
            array[i] = array[array.length - i - 1];
            array[array.length - i - 1] = o;
        }
        list.setAll(array);
    }
    
    public static void rotate(final ObservableList list, int n) {
        final Object[] array = list.toArray();
        final int size = list.size();
        n %= size;
        if (n < 0) {
            n += size;
        }
        if (n == 0) {
            return;
        }
        int n2 = 0;
        int i = 0;
        while (i != size) {
            Object o = array[n2];
            int j = n2;
            do {
                j += n;
                if (j >= size) {
                    j -= size;
                }
                final Object o2 = array[j];
                array[j] = o;
                o = o2;
                ++i;
            } while (j != n2);
            ++n2;
        }
        list.setAll(array);
    }
    
    public static void shuffle(final ObservableList<?> list) {
        if (FXCollections.r == null) {
            FXCollections.r = new Random();
        }
        shuffle(list, FXCollections.r);
    }
    
    public static void shuffle(final ObservableList list, final Random random) {
        final Object[] array = list.toArray();
        for (int i = list.size(); i > 1; --i) {
            swap(array, i - 1, random.nextInt(i));
        }
        list.setAll(array);
    }
    
    private static void swap(final Object[] array, final int n, final int n2) {
        final Object o = array[n];
        array[n] = array[n2];
        array[n2] = o;
    }
    
    public static <T extends Comparable<? super T>> void sort(final ObservableList<T> c) {
        if (c instanceof SortableList) {
            ((SortableList)c).sort();
        }
        else {
            final ArrayList<Object> list = new ArrayList<Object>((Collection<? extends E>)c);
            Collections.sort((List<Comparable>)list);
            c.setAll((Collection<? extends E>)list);
        }
    }
    
    public static <T> void sort(final ObservableList<T> c, final Comparator<? super T> c2) {
        if (c instanceof SortableList) {
            ((SortableList<?>)c).sort(c2);
        }
        else {
            final ArrayList<Object> list = new ArrayList<Object>(c);
            Collections.sort(list, (Comparator<? super Object>)c2);
            c.setAll((Collection<?>)list);
        }
    }
    
    static {
        FXCollections.EMPTY_OBSERVABLE_MAP = new EmptyObservableMap();
        FXCollections.EMPTY_OBSERVABLE_LIST = new EmptyObservableList();
        FXCollections.EMPTY_OBSERVABLE_SET = new EmptyObservableSet();
    }
    
    private static class EmptyObservableList<E> extends AbstractList<E> implements ObservableList<E>
    {
        private static final ListIterator iterator;
        
        public EmptyObservableList() {
        }
        
        @Override
        public final void addListener(final InvalidationListener invalidationListener) {
        }
        
        @Override
        public final void removeListener(final InvalidationListener invalidationListener) {
        }
        
        @Override
        public void addListener(final ListChangeListener<? super E> listChangeListener) {
        }
        
        @Override
        public void removeListener(final ListChangeListener<? super E> listChangeListener) {
        }
        
        @Override
        public int size() {
            return 0;
        }
        
        @Override
        public boolean contains(final Object o) {
            return false;
        }
        
        @Override
        public Iterator<E> iterator() {
            return (Iterator<E>)EmptyObservableList.iterator;
        }
        
        @Override
        public boolean containsAll(final Collection<?> collection) {
            return collection.isEmpty();
        }
        
        @Override
        public E get(final int n) {
            throw new IndexOutOfBoundsException();
        }
        
        @Override
        public int indexOf(final Object o) {
            return -1;
        }
        
        @Override
        public int lastIndexOf(final Object o) {
            return -1;
        }
        
        @Override
        public ListIterator<E> listIterator() {
            return (ListIterator<E>)EmptyObservableList.iterator;
        }
        
        @Override
        public ListIterator<E> listIterator(final int n) {
            if (n != 0) {
                throw new IndexOutOfBoundsException();
            }
            return (ListIterator<E>)EmptyObservableList.iterator;
        }
        
        @Override
        public List<E> subList(final int n, final int n2) {
            if (n != 0 || n2 != 0) {
                throw new IndexOutOfBoundsException();
            }
            return this;
        }
        
        @Override
        public boolean addAll(final E... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean setAll(final E... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean setAll(final Collection<? extends E> collection) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean removeAll(final E... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean retainAll(final E... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public void remove(final int n, final int n2) {
            throw new UnsupportedOperationException();
        }
        
        static {
            iterator = new ListIterator() {
                @Override
                public boolean hasNext() {
                    return false;
                }
                
                @Override
                public Object next() {
                    throw new NoSuchElementException();
                }
                
                @Override
                public void remove() {
                    throw new UnsupportedOperationException();
                }
                
                @Override
                public boolean hasPrevious() {
                    return false;
                }
                
                @Override
                public Object previous() {
                    throw new NoSuchElementException();
                }
                
                @Override
                public int nextIndex() {
                    return 0;
                }
                
                @Override
                public int previousIndex() {
                    return -1;
                }
                
                @Override
                public void set(final Object o) {
                    throw new UnsupportedOperationException();
                }
                
                @Override
                public void add(final Object o) {
                    throw new UnsupportedOperationException();
                }
            };
        }
    }
    
    private static class SingletonObservableList<E> extends AbstractList<E> implements ObservableList<E>
    {
        private final E element;
        
        public SingletonObservableList(final E element) {
            if (element == null) {
                throw new NullPointerException();
            }
            this.element = element;
        }
        
        @Override
        public boolean addAll(final E... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean setAll(final E... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean setAll(final Collection<? extends E> collection) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean removeAll(final E... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean retainAll(final E... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public void remove(final int n, final int n2) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
        }
        
        @Override
        public void addListener(final ListChangeListener<? super E> listChangeListener) {
        }
        
        @Override
        public void removeListener(final ListChangeListener<? super E> listChangeListener) {
        }
        
        @Override
        public int size() {
            return 1;
        }
        
        @Override
        public boolean isEmpty() {
            return false;
        }
        
        @Override
        public boolean contains(final Object obj) {
            return this.element.equals(obj);
        }
        
        @Override
        public E get(final int n) {
            if (n != 0) {
                throw new IndexOutOfBoundsException();
            }
            return this.element;
        }
    }
    
    private static class UnmodifiableObservableListImpl<T> extends ObservableListBase<T> implements ObservableList<T>
    {
        private final ObservableList<T> backingList;
        private final ListChangeListener<T> listener;
        
        public UnmodifiableObservableListImpl(final ObservableList<T> backingList) {
            this.backingList = backingList;
            this.listener = (change -> this.fireChange((ListChangeListener.Change<?>)new SourceAdapterChange<Object>((ObservableList<Object>)this, change)));
            this.backingList.addListener(new WeakListChangeListener<Object>(this.listener));
        }
        
        @Override
        public T get(final int n) {
            return this.backingList.get(n);
        }
        
        @Override
        public int size() {
            return this.backingList.size();
        }
        
        @Override
        public boolean addAll(final T... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean setAll(final T... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean setAll(final Collection<? extends T> collection) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean removeAll(final T... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean retainAll(final T... array) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public void remove(final int n, final int n2) {
            throw new UnsupportedOperationException();
        }
    }
    
    private static class SynchronizedList<T> implements List<T>
    {
        final Object mutex;
        private final List<T> backingList;
        
        SynchronizedList(final List<T> backingList, final Object mutex) {
            this.backingList = backingList;
            this.mutex = mutex;
        }
        
        @Override
        public int size() {
            synchronized (this.mutex) {
                return this.backingList.size();
            }
        }
        
        @Override
        public boolean isEmpty() {
            synchronized (this.mutex) {
                return this.backingList.isEmpty();
            }
        }
        
        @Override
        public boolean contains(final Object o) {
            synchronized (this.mutex) {
                return this.backingList.contains(o);
            }
        }
        
        @Override
        public Iterator<T> iterator() {
            return this.backingList.iterator();
        }
        
        @Override
        public Object[] toArray() {
            synchronized (this.mutex) {
                return this.backingList.toArray();
            }
        }
        
        @Override
        public <T> T[] toArray(final T[] array) {
            synchronized (this.mutex) {
                return this.backingList.toArray(array);
            }
        }
        
        @Override
        public boolean add(final T t) {
            synchronized (this.mutex) {
                return this.backingList.add(t);
            }
        }
        
        @Override
        public boolean remove(final Object o) {
            synchronized (this.mutex) {
                return this.backingList.remove(o);
            }
        }
        
        @Override
        public boolean containsAll(final Collection<?> collection) {
            synchronized (this.mutex) {
                return this.backingList.containsAll(collection);
            }
        }
        
        @Override
        public boolean addAll(final Collection<? extends T> collection) {
            synchronized (this.mutex) {
                return this.backingList.addAll(collection);
            }
        }
        
        @Override
        public boolean addAll(final int n, final Collection<? extends T> collection) {
            synchronized (this.mutex) {
                return this.backingList.addAll(n, collection);
            }
        }
        
        @Override
        public boolean removeAll(final Collection<?> collection) {
            synchronized (this.mutex) {
                return this.backingList.removeAll(collection);
            }
        }
        
        @Override
        public boolean retainAll(final Collection<?> collection) {
            synchronized (this.mutex) {
                return this.backingList.retainAll(collection);
            }
        }
        
        @Override
        public void clear() {
            synchronized (this.mutex) {
                this.backingList.clear();
            }
        }
        
        @Override
        public T get(final int n) {
            synchronized (this.mutex) {
                return this.backingList.get(n);
            }
        }
        
        @Override
        public T set(final int n, final T t) {
            synchronized (this.mutex) {
                return this.backingList.set(n, t);
            }
        }
        
        @Override
        public void add(final int n, final T t) {
            synchronized (this.mutex) {
                this.backingList.add(n, t);
            }
        }
        
        @Override
        public T remove(final int n) {
            synchronized (this.mutex) {
                return this.backingList.remove(n);
            }
        }
        
        @Override
        public int indexOf(final Object o) {
            synchronized (this.mutex) {
                return this.backingList.indexOf(o);
            }
        }
        
        @Override
        public int lastIndexOf(final Object o) {
            synchronized (this.mutex) {
                return this.backingList.lastIndexOf(o);
            }
        }
        
        @Override
        public ListIterator<T> listIterator() {
            return this.backingList.listIterator();
        }
        
        @Override
        public ListIterator<T> listIterator(final int n) {
            synchronized (this.mutex) {
                return this.backingList.listIterator(n);
            }
        }
        
        @Override
        public List<T> subList(final int n, final int n2) {
            synchronized (this.mutex) {
                return new SynchronizedList((List<Object>)this.backingList.subList(n, n2), this.mutex);
            }
        }
        
        @Override
        public String toString() {
            synchronized (this.mutex) {
                return this.backingList.toString();
            }
        }
        
        @Override
        public int hashCode() {
            synchronized (this.mutex) {
                return this.backingList.hashCode();
            }
        }
        
        @Override
        public boolean equals(final Object o) {
            synchronized (this.mutex) {
                return this.backingList.equals(o);
            }
        }
    }
    
    private static class SynchronizedObservableList<T> extends SynchronizedList<T> implements ObservableList<T>
    {
        private ListListenerHelper helper;
        private final ObservableList<T> backingList;
        private final ListChangeListener<T> listener;
        
        SynchronizedObservableList(final ObservableList<T> backingList, final Object o) {
            super(backingList, o);
            this.backingList = backingList;
            this.listener = (change -> ListListenerHelper.fireValueChangedEvent((ListListenerHelper<Object>)this.helper, new SourceAdapterChange<Object>((ObservableList<Object>)this, change)));
            this.backingList.addListener(new WeakListChangeListener<Object>(this.listener));
        }
        
        SynchronizedObservableList(final ObservableList<T> list) {
            this(list, new Object());
        }
        
        @Override
        public boolean addAll(final T... array) {
            synchronized (this.mutex) {
                return this.backingList.addAll(array);
            }
        }
        
        @Override
        public boolean setAll(final T... all) {
            synchronized (this.mutex) {
                return this.backingList.setAll(all);
            }
        }
        
        @Override
        public boolean removeAll(final T... array) {
            synchronized (this.mutex) {
                return this.backingList.removeAll(array);
            }
        }
        
        @Override
        public boolean retainAll(final T... array) {
            synchronized (this.mutex) {
                return this.backingList.retainAll(array);
            }
        }
        
        @Override
        public void remove(final int n, final int n2) {
            synchronized (this.mutex) {
                this.backingList.remove(n, n2);
            }
        }
        
        @Override
        public boolean setAll(final Collection<? extends T> all) {
            synchronized (this.mutex) {
                return this.backingList.setAll(all);
            }
        }
        
        @Override
        public final void addListener(final InvalidationListener invalidationListener) {
            synchronized (this.mutex) {
                this.helper = ListListenerHelper.addListener((ListListenerHelper<Object>)this.helper, invalidationListener);
            }
        }
        
        @Override
        public final void removeListener(final InvalidationListener invalidationListener) {
            synchronized (this.mutex) {
                this.helper = ListListenerHelper.removeListener((ListListenerHelper<Object>)this.helper, invalidationListener);
            }
        }
        
        @Override
        public void addListener(final ListChangeListener<? super T> listChangeListener) {
            synchronized (this.mutex) {
                this.helper = ListListenerHelper.addListener((ListListenerHelper<Object>)this.helper, (ListChangeListener<? super Object>)listChangeListener);
            }
        }
        
        @Override
        public void removeListener(final ListChangeListener<? super T> listChangeListener) {
            synchronized (this.mutex) {
                this.helper = ListListenerHelper.removeListener((ListListenerHelper<Object>)this.helper, (ListChangeListener<? super Object>)listChangeListener);
            }
        }
    }
    
    private static class CheckedObservableList<T> extends ObservableListBase<T> implements ObservableList<T>
    {
        private final ObservableList<T> list;
        private final Class<T> type;
        private final ListChangeListener<T> listener;
        
        CheckedObservableList(final ObservableList<T> list, final Class<T> type) {
            if (list == null || type == null) {
                throw new NullPointerException();
            }
            this.list = list;
            this.type = type;
            this.listener = (change -> this.fireChange((ListChangeListener.Change<?>)new SourceAdapterChange<Object>((ObservableList<Object>)this, change)));
            list.addListener(new WeakListChangeListener<Object>(this.listener));
        }
        
        void typeCheck(final Object o) {
            if (o != null && !this.type.isInstance(o)) {
                throw new ClassCastException(invokedynamic(makeConcatWithConstants:(Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/String;, o.getClass(), this.type));
            }
        }
        
        @Override
        public int size() {
            return this.list.size();
        }
        
        @Override
        public boolean isEmpty() {
            return this.list.isEmpty();
        }
        
        @Override
        public boolean contains(final Object o) {
            return this.list.contains(o);
        }
        
        @Override
        public Object[] toArray() {
            return this.list.toArray();
        }
        
        @Override
        public <T> T[] toArray(final T[] array) {
            return this.list.toArray(array);
        }
        
        @Override
        public String toString() {
            return this.list.toString();
        }
        
        @Override
        public boolean remove(final Object o) {
            return this.list.remove(o);
        }
        
        @Override
        public boolean containsAll(final Collection<?> collection) {
            return this.list.containsAll(collection);
        }
        
        @Override
        public boolean removeAll(final Collection<?> collection) {
            return this.list.removeAll(collection);
        }
        
        @Override
        public boolean retainAll(final Collection<?> collection) {
            return this.list.retainAll(collection);
        }
        
        @Override
        public boolean removeAll(final T... array) {
            return this.list.removeAll(array);
        }
        
        @Override
        public boolean retainAll(final T... array) {
            return this.list.retainAll(array);
        }
        
        @Override
        public void remove(final int n, final int n2) {
            this.list.remove(n, n2);
        }
        
        @Override
        public void clear() {
            this.list.clear();
        }
        
        @Override
        public boolean equals(final Object obj) {
            return obj == this || this.list.equals(obj);
        }
        
        @Override
        public int hashCode() {
            return this.list.hashCode();
        }
        
        @Override
        public T get(final int n) {
            return this.list.get(n);
        }
        
        @Override
        public T remove(final int n) {
            return this.list.remove(n);
        }
        
        @Override
        public int indexOf(final Object o) {
            return this.list.indexOf(o);
        }
        
        @Override
        public int lastIndexOf(final Object o) {
            return this.list.lastIndexOf(o);
        }
        
        @Override
        public T set(final int n, final T t) {
            this.typeCheck(t);
            return this.list.set(n, t);
        }
        
        @Override
        public void add(final int n, final T t) {
            this.typeCheck(t);
            this.list.add(n, t);
        }
        
        @Override
        public boolean addAll(final int n, final Collection<? extends T> collection) {
            Object[] array;
            try {
                array = collection.toArray((Object[])Array.newInstance(this.type, 0));
            }
            catch (ArrayStoreException ex) {
                throw new ClassCastException();
            }
            return this.list.addAll(n, (Collection<?>)Arrays.asList(array));
        }
        
        @Override
        public boolean addAll(final Collection<? extends T> collection) {
            Object[] array;
            try {
                array = collection.toArray((Object[])Array.newInstance(this.type, 0));
            }
            catch (ArrayStoreException ex) {
                throw new ClassCastException();
            }
            return this.list.addAll((Collection<?>)Arrays.asList(array));
        }
        
        @Override
        public ListIterator<T> listIterator() {
            return this.listIterator(0);
        }
        
        @Override
        public ListIterator<T> listIterator(final int n) {
            return new ListIterator<T>() {
                ListIterator<T> i = CheckedObservableList.this.list.listIterator(n);
                
                @Override
                public boolean hasNext() {
                    return this.i.hasNext();
                }
                
                @Override
                public T next() {
                    return this.i.next();
                }
                
                @Override
                public boolean hasPrevious() {
                    return this.i.hasPrevious();
                }
                
                @Override
                public T previous() {
                    return this.i.previous();
                }
                
                @Override
                public int nextIndex() {
                    return this.i.nextIndex();
                }
                
                @Override
                public int previousIndex() {
                    return this.i.previousIndex();
                }
                
                @Override
                public void remove() {
                    this.i.remove();
                }
                
                @Override
                public void set(final T t) {
                    CheckedObservableList.this.typeCheck(t);
                    this.i.set(t);
                }
                
                @Override
                public void add(final T t) {
                    CheckedObservableList.this.typeCheck(t);
                    this.i.add(t);
                }
            };
        }
        
        @Override
        public Iterator<T> iterator() {
            return new Iterator<T>() {
                private final Iterator<T> it = CheckedObservableList.this.list.iterator();
                
                @Override
                public boolean hasNext() {
                    return this.it.hasNext();
                }
                
                @Override
                public T next() {
                    return this.it.next();
                }
                
                @Override
                public void remove() {
                    this.it.remove();
                }
            };
        }
        
        @Override
        public boolean add(final T t) {
            this.typeCheck(t);
            return this.list.add(t);
        }
        
        @Override
        public List<T> subList(final int n, final int n2) {
            return Collections.checkedList(this.list.subList(n, n2), this.type);
        }
        
        @Override
        public boolean addAll(final T... array) {
            try {
                final Object[] array2 = (Object[])Array.newInstance(this.type, array.length);
                System.arraycopy(array, 0, array2, 0, array.length);
                return this.list.addAll((T[])array2);
            }
            catch (ArrayStoreException ex) {
                throw new ClassCastException();
            }
        }
        
        @Override
        public boolean setAll(final T... array) {
            try {
                final Object[] all = (Object[])Array.newInstance(this.type, array.length);
                System.arraycopy(array, 0, all, 0, array.length);
                return this.list.setAll((T[])all);
            }
            catch (ArrayStoreException ex) {
                throw new ClassCastException();
            }
        }
        
        @Override
        public boolean setAll(final Collection<? extends T> collection) {
            Object[] array;
            try {
                array = collection.toArray((Object[])Array.newInstance(this.type, 0));
            }
            catch (ArrayStoreException ex) {
                throw new ClassCastException();
            }
            return this.list.setAll((Collection<? extends T>)Arrays.asList(array));
        }
    }
    
    private static class EmptyObservableSet<E> extends AbstractSet<E> implements ObservableSet<E>
    {
        public EmptyObservableSet() {
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
        }
        
        @Override
        public void addListener(final SetChangeListener<? super E> setChangeListener) {
        }
        
        @Override
        public void removeListener(final SetChangeListener<? super E> setChangeListener) {
        }
        
        @Override
        public int size() {
            return 0;
        }
        
        @Override
        public boolean isEmpty() {
            return true;
        }
        
        @Override
        public boolean contains(final Object o) {
            return false;
        }
        
        @Override
        public boolean containsAll(final Collection<?> collection) {
            return collection.isEmpty();
        }
        
        @Override
        public Object[] toArray() {
            return new Object[0];
        }
        
        @Override
        public <E> E[] toArray(final E[] array) {
            if (array.length > 0) {
                array[0] = null;
            }
            return array;
        }
        
        @Override
        public Iterator<E> iterator() {
            return (Iterator<E>)new Iterator() {
                @Override
                public boolean hasNext() {
                    return false;
                }
                
                @Override
                public Object next() {
                    throw new NoSuchElementException();
                }
                
                @Override
                public void remove() {
                    throw new UnsupportedOperationException();
                }
            };
        }
    }
    
    private static class UnmodifiableObservableSet<E> extends AbstractSet<E> implements ObservableSet<E>
    {
        private final ObservableSet<E> backingSet;
        private SetListenerHelper<E> listenerHelper;
        private SetChangeListener<E> listener;
        
        public UnmodifiableObservableSet(final ObservableSet<E> backingSet) {
            this.backingSet = backingSet;
            this.listener = null;
        }
        
        private void initListener() {
            if (this.listener == null) {
                this.listener = (change -> this.callObservers(new SetAdapterChange<Object>((ObservableSet<Object>)this, change)));
                this.backingSet.addListener(new WeakSetChangeListener<Object>(this.listener));
            }
        }
        
        private void callObservers(final SetChangeListener.Change<? extends E> change) {
            SetListenerHelper.fireValueChangedEvent(this.listenerHelper, change);
        }
        
        @Override
        public Iterator<E> iterator() {
            return new Iterator<E>() {
                private final Iterator<? extends E> i = UnmodifiableObservableSet.this.backingSet.iterator();
                
                @Override
                public boolean hasNext() {
                    return this.i.hasNext();
                }
                
                @Override
                public E next() {
                    return (E)this.i.next();
                }
            };
        }
        
        @Override
        public int size() {
            return this.backingSet.size();
        }
        
        @Override
        public boolean isEmpty() {
            return this.backingSet.isEmpty();
        }
        
        @Override
        public boolean contains(final Object o) {
            return this.backingSet.contains(o);
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.initListener();
            this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.listenerHelper = SetListenerHelper.removeListener(this.listenerHelper, invalidationListener);
        }
        
        @Override
        public void addListener(final SetChangeListener<? super E> setChangeListener) {
            this.initListener();
            this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, setChangeListener);
        }
        
        @Override
        public void removeListener(final SetChangeListener<? super E> setChangeListener) {
            this.listenerHelper = SetListenerHelper.removeListener(this.listenerHelper, setChangeListener);
        }
        
        @Override
        public boolean add(final E e) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean remove(final Object o) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean addAll(final Collection<? extends E> collection) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean retainAll(final Collection<?> collection) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public boolean removeAll(final Collection<?> collection) {
            throw new UnsupportedOperationException();
        }
        
        @Override
        public void clear() {
            throw new UnsupportedOperationException();
        }
    }
    
    private static class SynchronizedSet<E> implements Set<E>
    {
        final Object mutex;
        private final Set<E> backingSet;
        
        SynchronizedSet(final Set<E> backingSet, final Object mutex) {
            this.backingSet = backingSet;
            this.mutex = mutex;
        }
        
        SynchronizedSet(final Set<E> set) {
            this(set, new Object());
        }
        
        @Override
        public int size() {
            synchronized (this.mutex) {
                return this.backingSet.size();
            }
        }
        
        @Override
        public boolean isEmpty() {
            synchronized (this.mutex) {
                return this.backingSet.isEmpty();
            }
        }
        
        @Override
        public boolean contains(final Object o) {
            synchronized (this.mutex) {
                return this.backingSet.contains(o);
            }
        }
        
        @Override
        public Iterator<E> iterator() {
            return this.backingSet.iterator();
        }
        
        @Override
        public Object[] toArray() {
            synchronized (this.mutex) {
                return this.backingSet.toArray();
            }
        }
        
        @Override
        public <E> E[] toArray(final E[] array) {
            synchronized (this.mutex) {
                return this.backingSet.toArray(array);
            }
        }
        
        @Override
        public boolean add(final E e) {
            synchronized (this.mutex) {
                return this.backingSet.add(e);
            }
        }
        
        @Override
        public boolean remove(final Object o) {
            synchronized (this.mutex) {
                return this.backingSet.remove(o);
            }
        }
        
        @Override
        public boolean containsAll(final Collection<?> collection) {
            synchronized (this.mutex) {
                return this.backingSet.containsAll(collection);
            }
        }
        
        @Override
        public boolean addAll(final Collection<? extends E> collection) {
            synchronized (this.mutex) {
                return this.backingSet.addAll(collection);
            }
        }
        
        @Override
        public boolean retainAll(final Collection<?> collection) {
            synchronized (this.mutex) {
                return this.backingSet.retainAll(collection);
            }
        }
        
        @Override
        public boolean removeAll(final Collection<?> collection) {
            synchronized (this.mutex) {
                return this.backingSet.removeAll(collection);
            }
        }
        
        @Override
        public void clear() {
            synchronized (this.mutex) {
                this.backingSet.clear();
            }
        }
        
        @Override
        public boolean equals(final Object o) {
            if (o == this) {
                return true;
            }
            synchronized (this.mutex) {
                return this.backingSet.equals(o);
            }
        }
        
        @Override
        public int hashCode() {
            synchronized (this.mutex) {
                return this.backingSet.hashCode();
            }
        }
    }
    
    private static class SynchronizedObservableSet<E> extends SynchronizedSet<E> implements ObservableSet<E>
    {
        private final ObservableSet<E> backingSet;
        private SetListenerHelper listenerHelper;
        private final SetChangeListener<E> listener;
        
        SynchronizedObservableSet(final ObservableSet<E> backingSet, final Object o) {
            super(backingSet, o);
            this.backingSet = backingSet;
            this.listener = (change -> SetListenerHelper.fireValueChangedEvent((SetListenerHelper<Object>)this.listenerHelper, new SetAdapterChange<Object>((ObservableSet<Object>)this, change)));
            this.backingSet.addListener(new WeakSetChangeListener<Object>(this.listener));
        }
        
        SynchronizedObservableSet(final ObservableSet<E> set) {
            this(set, new Object());
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            synchronized (this.mutex) {
                this.listenerHelper = SetListenerHelper.addListener((SetListenerHelper<Object>)this.listenerHelper, invalidationListener);
            }
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            synchronized (this.mutex) {
                this.listenerHelper = SetListenerHelper.removeListener((SetListenerHelper<Object>)this.listenerHelper, invalidationListener);
            }
        }
        
        @Override
        public void addListener(final SetChangeListener<? super E> setChangeListener) {
            synchronized (this.mutex) {
                this.listenerHelper = SetListenerHelper.addListener((SetListenerHelper<Object>)this.listenerHelper, (SetChangeListener<? super Object>)setChangeListener);
            }
        }
        
        @Override
        public void removeListener(final SetChangeListener<? super E> setChangeListener) {
            synchronized (this.mutex) {
                this.listenerHelper = SetListenerHelper.removeListener((SetListenerHelper<Object>)this.listenerHelper, (SetChangeListener<? super Object>)setChangeListener);
            }
        }
    }
    
    private static class CheckedObservableSet<E> extends AbstractSet<E> implements ObservableSet<E>
    {
        private final ObservableSet<E> backingSet;
        private final Class<E> type;
        private SetListenerHelper listenerHelper;
        private final SetChangeListener<E> listener;
        
        CheckedObservableSet(final ObservableSet<E> backingSet, final Class<E> type) {
            if (backingSet == null || type == null) {
                throw new NullPointerException();
            }
            this.backingSet = backingSet;
            this.type = type;
            this.listener = (change -> this.callObservers(new SetAdapterChange<Object>((ObservableSet<Object>)this, change)));
            this.backingSet.addListener(new WeakSetChangeListener<Object>(this.listener));
        }
        
        private void callObservers(final SetChangeListener.Change<? extends E> change) {
            SetListenerHelper.fireValueChangedEvent((SetListenerHelper<Object>)this.listenerHelper, change);
        }
        
        void typeCheck(final Object o) {
            if (o != null && !this.type.isInstance(o)) {
                throw new ClassCastException(invokedynamic(makeConcatWithConstants:(Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/String;, o.getClass(), this.type));
            }
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.listenerHelper = SetListenerHelper.addListener((SetListenerHelper<Object>)this.listenerHelper, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.listenerHelper = SetListenerHelper.removeListener((SetListenerHelper<Object>)this.listenerHelper, invalidationListener);
        }
        
        @Override
        public void addListener(final SetChangeListener<? super E> setChangeListener) {
            this.listenerHelper = SetListenerHelper.addListener((SetListenerHelper<Object>)this.listenerHelper, (SetChangeListener<? super Object>)setChangeListener);
        }
        
        @Override
        public void removeListener(final SetChangeListener<? super E> setChangeListener) {
            this.listenerHelper = SetListenerHelper.removeListener((SetListenerHelper<Object>)this.listenerHelper, (SetChangeListener<? super Object>)setChangeListener);
        }
        
        @Override
        public int size() {
            return this.backingSet.size();
        }
        
        @Override
        public boolean isEmpty() {
            return this.backingSet.isEmpty();
        }
        
        @Override
        public boolean contains(final Object o) {
            return this.backingSet.contains(o);
        }
        
        @Override
        public Object[] toArray() {
            return this.backingSet.toArray();
        }
        
        @Override
        public <T> T[] toArray(final T[] array) {
            return this.backingSet.toArray(array);
        }
        
        @Override
        public boolean add(final E e) {
            this.typeCheck(e);
            return this.backingSet.add(e);
        }
        
        @Override
        public boolean remove(final Object o) {
            return this.backingSet.remove(o);
        }
        
        @Override
        public boolean containsAll(final Collection<?> collection) {
            return this.backingSet.containsAll(collection);
        }
        
        @Override
        public boolean addAll(final Collection<? extends E> collection) {
            Object[] array;
            try {
                array = collection.toArray((Object[])Array.newInstance(this.type, 0));
            }
            catch (ArrayStoreException ex) {
                throw new ClassCastException();
            }
            return this.backingSet.addAll((Collection<?>)Arrays.asList(array));
        }
        
        @Override
        public boolean retainAll(final Collection<?> collection) {
            return this.backingSet.retainAll(collection);
        }
        
        @Override
        public boolean removeAll(final Collection<?> collection) {
            return this.backingSet.removeAll(collection);
        }
        
        @Override
        public void clear() {
            this.backingSet.clear();
        }
        
        @Override
        public boolean equals(final Object obj) {
            return obj == this || this.backingSet.equals(obj);
        }
        
        @Override
        public int hashCode() {
            return this.backingSet.hashCode();
        }
        
        @Override
        public Iterator<E> iterator() {
            return new Iterator<E>() {
                final /* synthetic */ Iterator val$it = CheckedObservableSet.this.backingSet.iterator();
                
                @Override
                public boolean hasNext() {
                    return this.val$it.hasNext();
                }
                
                @Override
                public E next() {
                    return this.val$it.next();
                }
                
                @Override
                public void remove() {
                    this.val$it.remove();
                }
            };
        }
    }
    
    private static class EmptyObservableMap<K, V> extends AbstractMap<K, V> implements ObservableMap<K, V>
    {
        public EmptyObservableMap() {
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
        }
        
        @Override
        public void addListener(final MapChangeListener<? super K, ? super V> mapChangeListener) {
        }
        
        @Override
        public void removeListener(final MapChangeListener<? super K, ? super V> mapChangeListener) {
        }
        
        @Override
        public int size() {
            return 0;
        }
        
        @Override
        public boolean isEmpty() {
            return true;
        }
        
        @Override
        public boolean containsKey(final Object o) {
            return false;
        }
        
        @Override
        public boolean containsValue(final Object o) {
            return false;
        }
        
        @Override
        public V get(final Object o) {
            return null;
        }
        
        @Override
        public Set<K> keySet() {
            return (Set<K>)FXCollections.emptyObservableSet();
        }
        
        @Override
        public Collection<V> values() {
            return (Collection<V>)FXCollections.emptyObservableSet();
        }
        
        @Override
        public Set<Map.Entry<K, V>> entrySet() {
            return (Set<Map.Entry<K, V>>)FXCollections.emptyObservableSet();
        }
        
        @Override
        public boolean equals(final Object o) {
            return o instanceof Map && ((Map)o).isEmpty();
        }
        
        @Override
        public int hashCode() {
            return 0;
        }
    }
    
    private static class CheckedObservableMap<K, V> extends AbstractMap<K, V> implements ObservableMap<K, V>
    {
        private final ObservableMap<K, V> backingMap;
        private final Class<K> keyType;
        private final Class<V> valueType;
        private MapListenerHelper listenerHelper;
        private final MapChangeListener<K, V> listener;
        private transient Set<Map.Entry<K, V>> entrySet;
        
        CheckedObservableMap(final ObservableMap<K, V> backingMap, final Class<K> keyType, final Class<V> valueType) {
            this.entrySet = null;
            this.backingMap = backingMap;
            this.keyType = keyType;
            this.valueType = valueType;
            this.listener = (change -> this.callObservers(new MapAdapterChange<Object, Object>((ObservableMap<Object, Object>)this, change)));
            this.backingMap.addListener(new WeakMapChangeListener<Object, Object>(this.listener));
        }
        
        private void callObservers(final MapChangeListener.Change<? extends K, ? extends V> change) {
            MapListenerHelper.fireValueChangedEvent((MapListenerHelper<Object, Object>)this.listenerHelper, change);
        }
        
        void typeCheck(final Object o, final Object o2) {
            if (o != null && !this.keyType.isInstance(o)) {
                throw new ClassCastException(invokedynamic(makeConcatWithConstants:(Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/String;, o.getClass(), this.keyType));
            }
            if (o2 != null && !this.valueType.isInstance(o2)) {
                throw new ClassCastException(invokedynamic(makeConcatWithConstants:(Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/String;, o2.getClass(), this.valueType));
            }
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            this.listenerHelper = MapListenerHelper.addListener((MapListenerHelper<Object, Object>)this.listenerHelper, invalidationListener);
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            this.listenerHelper = MapListenerHelper.removeListener((MapListenerHelper<Object, Object>)this.listenerHelper, invalidationListener);
        }
        
        @Override
        public void addListener(final MapChangeListener<? super K, ? super V> mapChangeListener) {
            this.listenerHelper = MapListenerHelper.addListener((MapListenerHelper<Object, Object>)this.listenerHelper, (MapChangeListener<? super Object, ? super Object>)mapChangeListener);
        }
        
        @Override
        public void removeListener(final MapChangeListener<? super K, ? super V> mapChangeListener) {
            this.listenerHelper = MapListenerHelper.removeListener((MapListenerHelper<Object, Object>)this.listenerHelper, (MapChangeListener<? super Object, ? super Object>)mapChangeListener);
        }
        
        @Override
        public int size() {
            return this.backingMap.size();
        }
        
        @Override
        public boolean isEmpty() {
            return this.backingMap.isEmpty();
        }
        
        @Override
        public boolean containsKey(final Object o) {
            return this.backingMap.containsKey(o);
        }
        
        @Override
        public boolean containsValue(final Object o) {
            return this.backingMap.containsValue(o);
        }
        
        @Override
        public V get(final Object o) {
            return this.backingMap.get(o);
        }
        
        @Override
        public V put(final K k, final V v) {
            this.typeCheck(k, v);
            return this.backingMap.put(k, v);
        }
        
        @Override
        public V remove(final Object o) {
            return this.backingMap.remove(o);
        }
        
        @Override
        public void putAll(final Map map) {
            final Object[] array = map.entrySet().toArray();
            final ArrayList list = new ArrayList<Object>(array.length);
            final Object[] array2 = array;
            for (int length = array2.length, i = 0; i < length; ++i) {
                final Map.Entry<Object, V> entry = (Map.Entry<Object, V>)array2[i];
                final Object key = entry.getKey();
                final V value = entry.getValue();
                this.typeCheck(key, value);
                list.add(new SimpleImmutableEntry<Object, Object>(key, value));
            }
            for (final SimpleImmutableEntry<Object, Object> simpleImmutableEntry : list) {
                this.backingMap.put(simpleImmutableEntry.getKey(), simpleImmutableEntry.getValue());
            }
        }
        
        @Override
        public void clear() {
            this.backingMap.clear();
        }
        
        @Override
        public Set<K> keySet() {
            return this.backingMap.keySet();
        }
        
        @Override
        public Collection<V> values() {
            return this.backingMap.values();
        }
        
        @Override
        public Set entrySet() {
            if (this.entrySet == null) {
                this.entrySet = new CheckedEntrySet<K, V>(this.backingMap.entrySet(), this.valueType);
            }
            return this.entrySet;
        }
        
        @Override
        public boolean equals(final Object obj) {
            return obj == this || this.backingMap.equals(obj);
        }
        
        @Override
        public int hashCode() {
            return this.backingMap.hashCode();
        }
        
        static class CheckedEntrySet<K, V> implements Set<Map.Entry<K, V>>
        {
            private final Set<Map.Entry<K, V>> s;
            private final Class<V> valueType;
            
            CheckedEntrySet(final Set<Map.Entry<K, V>> s, final Class<V> valueType) {
                this.s = s;
                this.valueType = valueType;
            }
            
            @Override
            public int size() {
                return this.s.size();
            }
            
            @Override
            public boolean isEmpty() {
                return this.s.isEmpty();
            }
            
            @Override
            public String toString() {
                return this.s.toString();
            }
            
            @Override
            public int hashCode() {
                return this.s.hashCode();
            }
            
            @Override
            public void clear() {
                this.s.clear();
            }
            
            @Override
            public boolean add(final Map.Entry<K, V> entry) {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public boolean addAll(final Collection<? extends Map.Entry<K, V>> collection) {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public Iterator<Map.Entry<K, V>> iterator() {
                return new Iterator<Map.Entry<K, V>>() {
                    final /* synthetic */ Iterator val$i = CheckedEntrySet.this.s.iterator();
                    final /* synthetic */ Class val$valueType = CheckedEntrySet.this.valueType;
                    
                    @Override
                    public boolean hasNext() {
                        return this.val$i.hasNext();
                    }
                    
                    @Override
                    public void remove() {
                        this.val$i.remove();
                    }
                    
                    @Override
                    public Map.Entry<K, V> next() {
                        return (Map.Entry<K, V>)CheckedEntrySet.checkedEntry(this.val$i.next(), (Class<Object>)this.val$valueType);
                    }
                };
            }
            
            @Override
            public Object[] toArray() {
                final Object[] array = this.s.toArray();
                final Object[] array2 = CheckedEntry.class.isInstance(array.getClass().getComponentType()) ? array : new Object[array.length];
                for (int i = 0; i < array.length; ++i) {
                    array2[i] = checkedEntry((Map.Entry<Object, Object>)array[i], this.valueType);
                }
                return array2;
            }
            
            @Override
            public <T> T[] toArray(final T[] original) {
                final T[] array = this.s.toArray((original.length == 0) ? original : Arrays.copyOf(original, 0));
                for (int i = 0; i < array.length; ++i) {
                    array[i] = (T)checkedEntry((Map.Entry<Object, Object>)array[i], this.valueType);
                }
                if (array.length > original.length) {
                    return array;
                }
                System.arraycopy(array, 0, original, 0, array.length);
                if (original.length > array.length) {
                    original[array.length] = null;
                }
                return original;
            }
            
            @Override
            public boolean contains(final Object o) {
                if (!(o instanceof Map.Entry)) {
                    return false;
                }
                final Map.Entry entry = (Map.Entry)o;
                return this.s.contains((entry instanceof CheckedEntry) ? entry : checkedEntry((Map.Entry<Object, Object>)entry, this.valueType));
            }
            
            @Override
            public boolean containsAll(final Collection<?> collection) {
                final Iterator<?> iterator = collection.iterator();
                while (iterator.hasNext()) {
                    if (!this.contains(iterator.next())) {
                        return false;
                    }
                }
                return true;
            }
            
            @Override
            public boolean remove(final Object o) {
                return o instanceof Map.Entry && this.s.remove(new SimpleImmutableEntry((Map.Entry<?, ?>)o));
            }
            
            @Override
            public boolean removeAll(final Collection<?> collection) {
                return this.batchRemove(collection, false);
            }
            
            @Override
            public boolean retainAll(final Collection<?> collection) {
                return this.batchRemove(collection, true);
            }
            
            private boolean batchRemove(final Collection<?> collection, final boolean b) {
                boolean b2 = false;
                final Iterator<Map.Entry<K, V>> iterator = this.iterator();
                while (iterator.hasNext()) {
                    if (collection.contains(iterator.next()) != b) {
                        iterator.remove();
                        b2 = true;
                    }
                }
                return b2;
            }
            
            @Override
            public boolean equals(final Object o) {
                if (o == this) {
                    return true;
                }
                if (!(o instanceof Set)) {
                    return false;
                }
                final Set set = (Set)o;
                return set.size() == this.s.size() && this.containsAll(set);
            }
            
            static <K, V, T> CheckedEntry<K, V, T> checkedEntry(final Map.Entry<K, V> entry, final Class<T> clazz) {
                return new CheckedEntry<K, V, T>(entry, clazz);
            }
            
            private static class CheckedEntry<K, V, T> implements Map.Entry<K, V>
            {
                private final Map.Entry<K, V> e;
                private final Class<T> valueType;
                
                CheckedEntry(final Map.Entry<K, V> e, final Class<T> valueType) {
                    this.e = e;
                    this.valueType = valueType;
                }
                
                @Override
                public K getKey() {
                    return this.e.getKey();
                }
                
                @Override
                public V getValue() {
                    return this.e.getValue();
                }
                
                @Override
                public int hashCode() {
                    return this.e.hashCode();
                }
                
                @Override
                public String toString() {
                    return this.e.toString();
                }
                
                @Override
                public V setValue(final V value) {
                    if (value != null && !this.valueType.isInstance(value)) {
                        throw new ClassCastException(this.badValueMsg(value));
                    }
                    return this.e.setValue(value);
                }
                
                private String badValueMsg(final Object o) {
                    return invokedynamic(makeConcatWithConstants:(Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/String;, o.getClass(), this.valueType);
                }
                
                @Override
                public boolean equals(final Object o) {
                    return o == this || (o instanceof Map.Entry && this.e.equals(new SimpleImmutableEntry((Map.Entry<?, ?>)o)));
                }
            }
        }
    }
    
    private static class SynchronizedMap<K, V> implements Map<K, V>
    {
        final Object mutex;
        private final Map<K, V> backingMap;
        private transient Set<K> keySet;
        private transient Set<Entry<K, V>> entrySet;
        private transient Collection<V> values;
        
        SynchronizedMap(final Map<K, V> backingMap, final Object mutex) {
            this.keySet = null;
            this.entrySet = null;
            this.values = null;
            this.backingMap = backingMap;
            this.mutex = mutex;
        }
        
        SynchronizedMap(final Map<K, V> map) {
            this(map, new Object());
        }
        
        @Override
        public int size() {
            synchronized (this.mutex) {
                return this.backingMap.size();
            }
        }
        
        @Override
        public boolean isEmpty() {
            synchronized (this.mutex) {
                return this.backingMap.isEmpty();
            }
        }
        
        @Override
        public boolean containsKey(final Object o) {
            synchronized (this.mutex) {
                return this.backingMap.containsKey(o);
            }
        }
        
        @Override
        public boolean containsValue(final Object o) {
            synchronized (this.mutex) {
                return this.backingMap.containsValue(o);
            }
        }
        
        @Override
        public V get(final Object o) {
            synchronized (this.mutex) {
                return this.backingMap.get(o);
            }
        }
        
        @Override
        public V put(final K k, final V v) {
            synchronized (this.mutex) {
                return this.backingMap.put(k, v);
            }
        }
        
        @Override
        public V remove(final Object o) {
            synchronized (this.mutex) {
                return this.backingMap.remove(o);
            }
        }
        
        @Override
        public void putAll(final Map<? extends K, ? extends V> map) {
            synchronized (this.mutex) {
                this.backingMap.putAll(map);
            }
        }
        
        @Override
        public void clear() {
            synchronized (this.mutex) {
                this.backingMap.clear();
            }
        }
        
        @Override
        public Set<K> keySet() {
            synchronized (this.mutex) {
                if (this.keySet == null) {
                    this.keySet = new SynchronizedSet<K>(this.backingMap.keySet(), this.mutex);
                }
                return this.keySet;
            }
        }
        
        @Override
        public Collection<V> values() {
            synchronized (this.mutex) {
                if (this.values == null) {
                    this.values = new SynchronizedCollection<V>(this.backingMap.values(), this.mutex);
                }
                return this.values;
            }
        }
        
        @Override
        public Set<Entry<K, V>> entrySet() {
            synchronized (this.mutex) {
                if (this.entrySet == null) {
                    this.entrySet = new SynchronizedSet<Entry<K, V>>(this.backingMap.entrySet(), this.mutex);
                }
                return this.entrySet;
            }
        }
        
        @Override
        public boolean equals(final Object o) {
            if (o == this) {
                return true;
            }
            synchronized (this.mutex) {
                return this.backingMap.equals(o);
            }
        }
        
        @Override
        public int hashCode() {
            synchronized (this.mutex) {
                return this.backingMap.hashCode();
            }
        }
    }
    
    private static class SynchronizedCollection<E> implements Collection<E>
    {
        private final Collection<E> backingCollection;
        final Object mutex;
        
        SynchronizedCollection(final Collection<E> backingCollection, final Object mutex) {
            this.backingCollection = backingCollection;
            this.mutex = mutex;
        }
        
        SynchronizedCollection(final Collection<E> collection) {
            this(collection, new Object());
        }
        
        @Override
        public int size() {
            synchronized (this.mutex) {
                return this.backingCollection.size();
            }
        }
        
        @Override
        public boolean isEmpty() {
            synchronized (this.mutex) {
                return this.backingCollection.isEmpty();
            }
        }
        
        @Override
        public boolean contains(final Object o) {
            synchronized (this.mutex) {
                return this.backingCollection.contains(o);
            }
        }
        
        @Override
        public Iterator<E> iterator() {
            return this.backingCollection.iterator();
        }
        
        @Override
        public Object[] toArray() {
            synchronized (this.mutex) {
                return this.backingCollection.toArray();
            }
        }
        
        @Override
        public <T> T[] toArray(final T[] array) {
            synchronized (this.mutex) {
                return this.backingCollection.toArray(array);
            }
        }
        
        @Override
        public boolean add(final E e) {
            synchronized (this.mutex) {
                return this.backingCollection.add(e);
            }
        }
        
        @Override
        public boolean remove(final Object o) {
            synchronized (this.mutex) {
                return this.backingCollection.remove(o);
            }
        }
        
        @Override
        public boolean containsAll(final Collection<?> collection) {
            synchronized (this.mutex) {
                return this.backingCollection.containsAll(collection);
            }
        }
        
        @Override
        public boolean addAll(final Collection<? extends E> collection) {
            synchronized (this.mutex) {
                return this.backingCollection.addAll(collection);
            }
        }
        
        @Override
        public boolean removeAll(final Collection<?> collection) {
            synchronized (this.mutex) {
                return this.backingCollection.removeAll(collection);
            }
        }
        
        @Override
        public boolean retainAll(final Collection<?> collection) {
            synchronized (this.mutex) {
                return this.backingCollection.retainAll(collection);
            }
        }
        
        @Override
        public void clear() {
            synchronized (this.mutex) {
                this.backingCollection.clear();
            }
        }
    }
    
    private static class SynchronizedObservableMap<K, V> extends SynchronizedMap<K, V> implements ObservableMap<K, V>
    {
        private final ObservableMap<K, V> backingMap;
        private MapListenerHelper listenerHelper;
        private final MapChangeListener<K, V> listener;
        
        SynchronizedObservableMap(final ObservableMap<K, V> backingMap, final Object o) {
            super(backingMap, o);
            this.backingMap = backingMap;
            this.listener = (change -> MapListenerHelper.fireValueChangedEvent((MapListenerHelper<Object, Object>)this.listenerHelper, new MapAdapterChange<Object, Object>((ObservableMap<Object, Object>)this, change)));
            this.backingMap.addListener(new WeakMapChangeListener<Object, Object>(this.listener));
        }
        
        SynchronizedObservableMap(final ObservableMap<K, V> observableMap) {
            this(observableMap, new Object());
        }
        
        @Override
        public void addListener(final InvalidationListener invalidationListener) {
            synchronized (this.mutex) {
                this.listenerHelper = MapListenerHelper.addListener((MapListenerHelper<Object, Object>)this.listenerHelper, invalidationListener);
            }
        }
        
        @Override
        public void removeListener(final InvalidationListener invalidationListener) {
            synchronized (this.mutex) {
                this.listenerHelper = MapListenerHelper.removeListener((MapListenerHelper<Object, Object>)this.listenerHelper, invalidationListener);
            }
        }
        
        @Override
        public void addListener(final MapChangeListener<? super K, ? super V> mapChangeListener) {
            synchronized (this.mutex) {
                this.listenerHelper = MapListenerHelper.addListener((MapListenerHelper<Object, Object>)this.listenerHelper, (MapChangeListener<? super Object, ? super Object>)mapChangeListener);
            }
        }
        
        @Override
        public void removeListener(final MapChangeListener<? super K, ? super V> mapChangeListener) {
            synchronized (this.mutex) {
                this.listenerHelper = MapListenerHelper.removeListener((MapListenerHelper<Object, Object>)this.listenerHelper, (MapChangeListener<? super Object, ? super Object>)mapChangeListener);
            }
        }
    }
}
