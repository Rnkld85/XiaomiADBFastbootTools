// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import javafx.beans.Observable;
import java.util.Map;

public interface ObservableMap<K, V> extends Map<K, V>, Observable
{
    void addListener(final MapChangeListener<? super K, ? super V> p0);
    
    void removeListener(final MapChangeListener<? super K, ? super V> p0);
}
