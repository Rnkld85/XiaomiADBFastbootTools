// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

public interface ObservableFloatArray extends ObservableArray<ObservableFloatArray>
{
    void copyTo(final int p0, final float[] p1, final int p2, final int p3);
    
    void copyTo(final int p0, final ObservableFloatArray p1, final int p2, final int p3);
    
    float get(final int p0);
    
    void addAll(final float... p0);
    
    void addAll(final ObservableFloatArray p0);
    
    void addAll(final float[] p0, final int p1, final int p2);
    
    void addAll(final ObservableFloatArray p0, final int p1, final int p2);
    
    void setAll(final float... p0);
    
    void setAll(final float[] p0, final int p1, final int p2);
    
    void setAll(final ObservableFloatArray p0);
    
    void setAll(final ObservableFloatArray p0, final int p1, final int p2);
    
    void set(final int p0, final float[] p1, final int p2, final int p3);
    
    void set(final int p0, final ObservableFloatArray p1, final int p2, final int p3);
    
    void set(final int p0, final float p1);
    
    float[] toArray(final float[] p0);
    
    float[] toArray(final int p0, final float[] p1, final int p2);
}
