// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

public interface ObservableIntegerArray extends ObservableArray<ObservableIntegerArray>
{
    void copyTo(final int p0, final int[] p1, final int p2, final int p3);
    
    void copyTo(final int p0, final ObservableIntegerArray p1, final int p2, final int p3);
    
    int get(final int p0);
    
    void addAll(final int... p0);
    
    void addAll(final ObservableIntegerArray p0);
    
    void addAll(final int[] p0, final int p1, final int p2);
    
    void addAll(final ObservableIntegerArray p0, final int p1, final int p2);
    
    void setAll(final int... p0);
    
    void setAll(final int[] p0, final int p1, final int p2);
    
    void setAll(final ObservableIntegerArray p0);
    
    void setAll(final ObservableIntegerArray p0, final int p1, final int p2);
    
    void set(final int p0, final int[] p1, final int p2, final int p3);
    
    void set(final int p0, final ObservableIntegerArray p1, final int p2, final int p3);
    
    void set(final int p0, final int p1);
    
    int[] toArray(final int[] p0);
    
    int[] toArray(final int p0, final int[] p1, final int p2);
}
