// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import javafx.beans.Observable;

public interface ObservableArray<T extends ObservableArray<T>> extends Observable
{
    void addListener(final ArrayChangeListener<T> p0);
    
    void removeListener(final ArrayChangeListener<T> p0);
    
    void resize(final int p0);
    
    void ensureCapacity(final int p0);
    
    void trimToSize();
    
    void clear();
    
    int size();
}
