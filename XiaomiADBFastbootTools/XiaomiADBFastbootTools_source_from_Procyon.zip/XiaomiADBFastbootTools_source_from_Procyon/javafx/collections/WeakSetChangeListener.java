// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import javafx.beans.NamedArg;
import java.lang.ref.WeakReference;
import javafx.beans.WeakListener;

public final class WeakSetChangeListener<E> implements SetChangeListener<E>, WeakListener
{
    private final WeakReference<SetChangeListener<E>> ref;
    
    public WeakSetChangeListener(@NamedArg("listener") final SetChangeListener<E> referent) {
        if (referent == null) {
            throw new NullPointerException("Listener must be specified.");
        }
        this.ref = new WeakReference<SetChangeListener<E>>(referent);
    }
    
    @Override
    public boolean wasGarbageCollected() {
        return this.ref.get() == null;
    }
    
    @Override
    public void onChanged(final Change<? extends E> change) {
        final SetChangeListener setChangeListener = this.ref.get();
        if (setChangeListener != null) {
            setChangeListener.onChanged(change);
        }
        else {
            change.getSet().removeListener(this);
        }
    }
}
