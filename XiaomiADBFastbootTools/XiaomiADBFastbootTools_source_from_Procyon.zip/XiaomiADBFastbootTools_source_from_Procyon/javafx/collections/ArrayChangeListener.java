// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

public interface ArrayChangeListener<T extends ObservableArray<T>>
{
    void onChanged(final T p0, final boolean p1, final int p2, final int p3);
}
