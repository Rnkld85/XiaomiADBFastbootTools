// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import javafx.beans.NamedArg;
import java.lang.ref.WeakReference;
import javafx.beans.WeakListener;

public final class WeakMapChangeListener<K, V> implements MapChangeListener<K, V>, WeakListener
{
    private final WeakReference<MapChangeListener<K, V>> ref;
    
    public WeakMapChangeListener(@NamedArg("listener") final MapChangeListener<K, V> referent) {
        if (referent == null) {
            throw new NullPointerException("Listener must be specified.");
        }
        this.ref = new WeakReference<MapChangeListener<K, V>>(referent);
    }
    
    @Override
    public boolean wasGarbageCollected() {
        return this.ref.get() == null;
    }
    
    @Override
    public void onChanged(final Change<? extends K, ? extends V> change) {
        final MapChangeListener mapChangeListener = this.ref.get();
        if (mapChangeListener != null) {
            mapChangeListener.onChanged(change);
        }
        else {
            change.getMap().removeListener(this);
        }
    }
}
