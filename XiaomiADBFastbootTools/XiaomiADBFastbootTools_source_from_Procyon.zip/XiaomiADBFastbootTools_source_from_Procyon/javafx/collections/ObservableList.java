// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import java.text.Collator;
import javafx.collections.transformation.SortedList;
import java.util.Comparator;
import javafx.collections.transformation.FilteredList;
import java.util.function.Predicate;
import java.util.Collection;
import javafx.beans.Observable;
import java.util.List;

public interface ObservableList<E> extends List<E>, Observable
{
    void addListener(final ListChangeListener<? super E> p0);
    
    void removeListener(final ListChangeListener<? super E> p0);
    
    boolean addAll(final E... p0);
    
    boolean setAll(final E... p0);
    
    boolean setAll(final Collection<? extends E> p0);
    
    boolean removeAll(final E... p0);
    
    boolean retainAll(final E... p0);
    
    void remove(final int p0, final int p1);
    
    default FilteredList<E> filtered(final Predicate<E> predicate) {
        return new FilteredList<E>(this, predicate);
    }
    
    default SortedList<E> sorted(final Comparator<E> comparator) {
        return new SortedList<E>((ObservableList<? extends E>)this, comparator);
    }
    
    default SortedList<E> sorted() {
        return this.sorted(new Comparator<E>() {
            @Override
            public int compare(final E e, final E e2) {
                if (e == null && e2 == null) {
                    return 0;
                }
                if (e == null) {
                    return -1;
                }
                if (e2 == null) {
                    return 1;
                }
                if (e instanceof Comparable) {
                    return ((Comparable)e).compareTo(e2);
                }
                return Collator.getInstance().compare(e.toString(), e2.toString());
            }
        });
    }
}
