// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import java.util.ListIterator;
import java.util.Iterator;
import java.util.List;
import java.util.Collection;

public abstract class ModifiableObservableListBase<E> extends ObservableListBase<E>
{
    @Override
    public boolean setAll(final Collection<? extends E> collection) {
        this.beginChange();
        try {
            this.clear();
            this.addAll(collection);
        }
        finally {
            this.endChange();
        }
        return true;
    }
    
    @Override
    public boolean addAll(final Collection<? extends E> c) {
        this.beginChange();
        try {
            return super.addAll(c);
        }
        finally {
            this.endChange();
        }
    }
    
    @Override
    public boolean addAll(final int index, final Collection<? extends E> c) {
        this.beginChange();
        try {
            return super.addAll(index, c);
        }
        finally {
            this.endChange();
        }
    }
    
    @Override
    protected void removeRange(final int fromIndex, final int toIndex) {
        this.beginChange();
        try {
            super.removeRange(fromIndex, toIndex);
        }
        finally {
            this.endChange();
        }
    }
    
    @Override
    public boolean removeAll(final Collection<?> c) {
        this.beginChange();
        try {
            return super.removeAll(c);
        }
        finally {
            this.endChange();
        }
    }
    
    @Override
    public boolean retainAll(final Collection<?> c) {
        this.beginChange();
        try {
            return super.retainAll(c);
        }
        finally {
            this.endChange();
        }
    }
    
    @Override
    public void add(final int n, final E e) {
        this.doAdd(n, e);
        this.beginChange();
        this.nextAdd(n, n + 1);
        ++this.modCount;
        this.endChange();
    }
    
    @Override
    public E set(final int n, final E e) {
        final Object doSet = this.doSet(n, e);
        this.beginChange();
        this.nextSet(n, (E)doSet);
        this.endChange();
        return (E)doSet;
    }
    
    @Override
    public boolean remove(final Object o) {
        final int index = this.indexOf(o);
        if (index != -1) {
            this.remove(index);
            return true;
        }
        return false;
    }
    
    @Override
    public E remove(final int n) {
        final E doRemove = this.doRemove(n);
        this.beginChange();
        this.nextRemove(n, doRemove);
        ++this.modCount;
        this.endChange();
        return doRemove;
    }
    
    @Override
    public List<E> subList(final int fromIndex, final int toIndex) {
        return new SubObservableList(super.subList(fromIndex, toIndex));
    }
    
    @Override
    public abstract E get(final int p0);
    
    @Override
    public abstract int size();
    
    protected abstract void doAdd(final int p0, final E p1);
    
    protected abstract E doSet(final int p0, final E p1);
    
    protected abstract E doRemove(final int p0);
    
    private class SubObservableList implements List<E>
    {
        private List<E> sublist;
        
        public SubObservableList(final List<E> sublist) {
            this.sublist = sublist;
        }
        
        @Override
        public int size() {
            return this.sublist.size();
        }
        
        @Override
        public boolean isEmpty() {
            return this.sublist.isEmpty();
        }
        
        @Override
        public boolean contains(final Object o) {
            return this.sublist.contains(o);
        }
        
        @Override
        public Iterator<E> iterator() {
            return this.sublist.iterator();
        }
        
        @Override
        public Object[] toArray() {
            return this.sublist.toArray();
        }
        
        @Override
        public <T> T[] toArray(final T[] array) {
            return this.sublist.toArray(array);
        }
        
        @Override
        public boolean add(final E e) {
            return this.sublist.add(e);
        }
        
        @Override
        public boolean remove(final Object o) {
            return this.sublist.remove(o);
        }
        
        @Override
        public boolean containsAll(final Collection<?> collection) {
            return this.sublist.containsAll(collection);
        }
        
        @Override
        public boolean addAll(final Collection<? extends E> collection) {
            ModifiableObservableListBase.this.beginChange();
            try {
                return this.sublist.addAll(collection);
            }
            finally {
                ModifiableObservableListBase.this.endChange();
            }
        }
        
        @Override
        public boolean addAll(final int n, final Collection<? extends E> collection) {
            ModifiableObservableListBase.this.beginChange();
            try {
                return this.sublist.addAll(n, collection);
            }
            finally {
                ModifiableObservableListBase.this.endChange();
            }
        }
        
        @Override
        public boolean removeAll(final Collection<?> collection) {
            ModifiableObservableListBase.this.beginChange();
            try {
                return this.sublist.removeAll(collection);
            }
            finally {
                ModifiableObservableListBase.this.endChange();
            }
        }
        
        @Override
        public boolean retainAll(final Collection<?> collection) {
            ModifiableObservableListBase.this.beginChange();
            try {
                return this.sublist.retainAll(collection);
            }
            finally {
                ModifiableObservableListBase.this.endChange();
            }
        }
        
        @Override
        public void clear() {
            ModifiableObservableListBase.this.beginChange();
            try {
                this.sublist.clear();
            }
            finally {
                ModifiableObservableListBase.this.endChange();
            }
        }
        
        @Override
        public E get(final int n) {
            return this.sublist.get(n);
        }
        
        @Override
        public E set(final int n, final E e) {
            return this.sublist.set(n, e);
        }
        
        @Override
        public void add(final int n, final E e) {
            this.sublist.add(n, e);
        }
        
        @Override
        public E remove(final int n) {
            return this.sublist.remove(n);
        }
        
        @Override
        public int indexOf(final Object o) {
            return this.sublist.indexOf(o);
        }
        
        @Override
        public int lastIndexOf(final Object o) {
            return this.sublist.lastIndexOf(o);
        }
        
        @Override
        public ListIterator<E> listIterator() {
            return this.sublist.listIterator();
        }
        
        @Override
        public ListIterator<E> listIterator(final int n) {
            return this.sublist.listIterator(n);
        }
        
        @Override
        public List<E> subList(final int n, final int n2) {
            return new SubObservableList(this.sublist.subList(n, n2));
        }
        
        @Override
        public boolean equals(final Object o) {
            return this.sublist.equals(o);
        }
        
        @Override
        public int hashCode() {
            return this.sublist.hashCode();
        }
        
        @Override
        public String toString() {
            return this.sublist.toString();
        }
    }
}
