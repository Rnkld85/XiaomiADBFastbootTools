// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections.transformation;

import javafx.collections.WeakListChangeListener;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.ObservableListBase;

public abstract class TransformationList<E, F> extends ObservableListBase<E> implements ObservableList<E>
{
    private ObservableList<? extends F> source;
    private ListChangeListener<F> sourceListener;
    
    protected TransformationList(final ObservableList<? extends F> source) {
        if (source == null) {
            throw new NullPointerException();
        }
        (this.source = source).addListener(new WeakListChangeListener<Object>(this.getListener()));
    }
    
    public final ObservableList<? extends F> getSource() {
        return this.source;
    }
    
    public final boolean isInTransformationChain(final ObservableList<?> list) {
        if (this.source == list) {
            return true;
        }
        ObservableList<? extends F> list2 = this.source;
        while (list2 instanceof TransformationList) {
            list2 = ((TransformationList)list2).source;
            if (list2 == list) {
                return true;
            }
        }
        return false;
    }
    
    private ListChangeListener<F> getListener() {
        if (this.sourceListener == null) {
            this.sourceListener = (change -> this.sourceChanged(change));
        }
        return this.sourceListener;
    }
    
    protected abstract void sourceChanged(final ListChangeListener.Change<? extends F> p0);
    
    public abstract int getSourceIndex(final int p0);
    
    public final int getSourceIndexFor(final ObservableList<?> list, final int n) {
        if (!this.isInTransformationChain(list)) {
            throw new IllegalArgumentException("Provided list is not in the transformation chain of thistransformation list");
        }
        ObservableList<? extends F> list2 = this.source;
        int n2 = this.getSourceIndex(n);
        while (list2 != list && list2 instanceof TransformationList) {
            final TransformationList<?, ?> list3 = (TransformationList<?, ?>)list2;
            n2 = list3.getSourceIndex(n2);
            list2 = (ObservableList<? extends F>)list3.source;
        }
        return n2;
    }
    
    public abstract int getViewIndex(final int p0);
}
