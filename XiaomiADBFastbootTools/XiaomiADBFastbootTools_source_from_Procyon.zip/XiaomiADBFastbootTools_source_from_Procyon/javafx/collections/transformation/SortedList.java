// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections.transformation;

import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import com.sun.javafx.collections.NonIterableChange;
import javafx.beans.property.ObjectPropertyBase;
import com.sun.javafx.collections.SourceAdapterChange;
import javafx.collections.ListChangeListener;
import javafx.beans.NamedArg;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import com.sun.javafx.collections.SortHelper;
import java.util.Comparator;

public final class SortedList<E> extends TransformationList<E, E>
{
    private Comparator<Element<E>> elementComparator;
    private Element<E>[] sorted;
    private int[] perm;
    private int size;
    private final SortHelper helper;
    private final Element<E> tempElement;
    private ObjectProperty<Comparator<? super E>> comparator;
    
    public SortedList(@NamedArg("source") final ObservableList<? extends E> list, @NamedArg("comparator") final Comparator<? super E> comparator) {
        super(list);
        this.helper = new SortHelper();
        this.tempElement = new Element<E>(null, -1);
        this.sorted = (Element<E>[])new Element[list.size() * 3 / 2 + 1];
        this.perm = new int[this.sorted.length];
        this.size = list.size();
        for (int i = 0; i < this.size; ++i) {
            this.sorted[i] = new Element<E>(list.get(i), i);
            this.perm[i] = i;
        }
        if (comparator != null) {
            this.setComparator(comparator);
        }
    }
    
    public SortedList(@NamedArg("source") final ObservableList<? extends E> list) {
        this(list, null);
    }
    
    @Override
    protected void sourceChanged(final ListChangeListener.Change<? extends E> change) {
        if (this.elementComparator != null) {
            this.beginChange();
            while (change.next()) {
                if (change.wasPermutated()) {
                    this.updatePermutationIndexes(change);
                }
                else if (change.wasUpdated()) {
                    this.update(change);
                }
                else {
                    this.addRemove(change);
                }
            }
            this.endChange();
        }
        else {
            this.updateUnsorted(change);
            this.fireChange((ListChangeListener.Change<? extends E>)new SourceAdapterChange<Object>((ObservableList<? extends E>)this, (ListChangeListener.Change<? extends E>)change));
        }
    }
    
    public final ObjectProperty<Comparator<? super E>> comparatorProperty() {
        if (this.comparator == null) {
            this.comparator = new ObjectPropertyBase<Comparator<? super E>>() {
                @Override
                protected void invalidated() {
                    final Comparator comparator = ((ObjectPropertyBase<Comparator<? super Object>>)this).get();
                    SortedList.this.elementComparator = (Comparator<Element<E>>)((comparator != null) ? new ElementComparator(comparator) : null);
                    SortedList.this.doSortWithPermutationChange();
                }
                
                @Override
                public Object getBean() {
                    return SortedList.this;
                }
                
                @Override
                public String getName() {
                    return "comparator";
                }
            };
        }
        return this.comparator;
    }
    
    public final Comparator<? super E> getComparator() {
        return (this.comparator == null) ? null : this.comparator.get();
    }
    
    public final void setComparator(final Comparator<? super E> comparator) {
        this.comparatorProperty().set(comparator);
    }
    
    @Override
    public E get(final int n) {
        if (n >= this.size) {
            throw new IndexOutOfBoundsException();
        }
        return (E)((Element<Object>)this.sorted[n]).e;
    }
    
    @Override
    public int size() {
        return this.size;
    }
    
    private void doSortWithPermutationChange() {
        if (this.elementComparator != null) {
            final int[] sort = this.helper.sort(this.sorted, 0, this.size, this.elementComparator);
            for (int i = 0; i < this.size; ++i) {
                this.perm[((Element<Object>)this.sorted[i]).index] = i;
            }
            this.fireChange((ListChangeListener.Change<? extends E>)new NonIterableChange.SimplePermutationChange<Object>(0, this.size, sort, (ObservableList<Object>)this));
        }
        else {
            final int[] array = new int[this.size];
            final int[] array2 = new int[this.size];
            for (int j = 0; j < this.size; ++j) {
                array[j] = (array2[j] = j);
            }
            boolean b = false;
            int k = 0;
            while (k < this.size) {
                final int access$300 = ((Element<Object>)this.sorted[k]).index;
                if (access$300 == k) {
                    ++k;
                }
                else {
                    final Element<E> element = this.sorted[access$300];
                    this.sorted[access$300] = this.sorted[k];
                    this.sorted[k] = element;
                    this.perm[k] = k;
                    this.perm[access$300] = access$300;
                    array[array2[k]] = access$300;
                    array[array2[access$300]] = k;
                    final int n = array2[k];
                    array2[k] = array2[access$300];
                    array2[access$300] = n;
                    b = true;
                }
            }
            if (b) {
                this.fireChange((ListChangeListener.Change<? extends E>)new NonIterableChange.SimplePermutationChange<Object>(0, this.size, array, (ObservableList<Object>)this));
            }
        }
    }
    
    @Override
    public int getSourceIndex(final int n) {
        return ((Element<Object>)this.sorted[n]).index;
    }
    
    @Override
    public int getViewIndex(final int n) {
        return this.perm[n];
    }
    
    private void updatePermutationIndexes(final ListChangeListener.Change<? extends E> change) {
        for (int i = 0; i < this.size; ++i) {
            final int permutation = change.getPermutation(((Element<Object>)this.sorted[i]).index);
            ((Element<Object>)this.sorted[i]).index = permutation;
            this.perm[permutation] = i;
        }
    }
    
    private void updateUnsorted(final ListChangeListener.Change<? extends E> change) {
        while (change.next()) {
            if (change.wasPermutated()) {
                final Element[] sorted = new Element[this.sorted.length];
                for (int i = 0; i < this.size; ++i) {
                    if (i >= change.getFrom() && i < change.getTo()) {
                        final int permutation = change.getPermutation(i);
                        (sorted[permutation] = this.sorted[i]).index = permutation;
                        this.perm[i] = i;
                    }
                    else {
                        sorted[i] = this.sorted[i];
                    }
                }
                this.sorted = (Element<E>[])sorted;
            }
            if (change.wasRemoved()) {
                final int n = change.getFrom() + change.getRemovedSize();
                System.arraycopy(this.sorted, n, this.sorted, change.getFrom(), this.size - n);
                System.arraycopy(this.perm, n, this.perm, change.getFrom(), this.size - n);
                this.size -= change.getRemovedSize();
                this.updateIndices(n, n, -change.getRemovedSize());
            }
            if (change.wasAdded()) {
                this.ensureSize(this.size + change.getAddedSize());
                this.updateIndices(change.getFrom(), change.getFrom(), change.getAddedSize());
                System.arraycopy(this.sorted, change.getFrom(), this.sorted, change.getTo(), this.size - change.getFrom());
                System.arraycopy(this.perm, change.getFrom(), this.perm, change.getTo(), this.size - change.getFrom());
                this.size += change.getAddedSize();
                for (int j = change.getFrom(); j < change.getTo(); ++j) {
                    this.sorted[j] = new Element<E>(change.getList().get(j), j);
                    this.perm[j] = j;
                }
            }
        }
    }
    
    private void ensureSize(final int n) {
        if (this.sorted.length < n) {
            final Element[] sorted = new Element[n * 3 / 2 + 1];
            System.arraycopy(this.sorted, 0, sorted, 0, this.size);
            this.sorted = (Element<E>[])sorted;
            final int[] perm = new int[n * 3 / 2 + 1];
            System.arraycopy(this.perm, 0, perm, 0, this.size);
            this.perm = perm;
        }
    }
    
    private void updateIndices(final int n, final int n2, final int n3) {
        for (int i = 0; i < this.size; ++i) {
            if (((Element<Object>)this.sorted[i]).index >= n) {
                ((Element<Object>)this.sorted[i]).index += n3;
            }
            if (this.perm[i] >= n2) {
                final int[] perm = this.perm;
                final int n4 = i;
                perm[n4] += n3;
            }
        }
    }
    
    private int findPosition(final E e) {
        if (this.sorted.length == 0) {
            return 0;
        }
        ((Element<Object>)this.tempElement).e = e;
        return Arrays.binarySearch(this.sorted, 0, this.size, this.tempElement, this.elementComparator);
    }
    
    private void insertToMapping(final E e, final int n) {
        int position = this.findPosition(e);
        if (position < 0) {
            position ^= -1;
        }
        this.ensureSize(this.size + 1);
        this.updateIndices(n, position, 1);
        System.arraycopy(this.sorted, position, this.sorted, position + 1, this.size - position);
        this.sorted[position] = new Element<E>(e, n);
        System.arraycopy(this.perm, n, this.perm, n + 1, this.size - n);
        this.perm[n] = position;
        ++this.size;
        this.nextAdd(position, position + 1);
    }
    
    private void setAllToMapping(final List<? extends E> list, final int size) {
        this.ensureSize(size);
        this.size = size;
        for (int i = 0; i < size; ++i) {
            this.sorted[i] = new Element<E>(list.get(i), i);
        }
        System.arraycopy(this.helper.sort(this.sorted, 0, this.size, this.elementComparator), 0, this.perm, 0, this.size);
        this.nextAdd(0, this.size);
    }
    
    private void removeFromMapping(final int n, final E e) {
        final int n2 = this.perm[n];
        System.arraycopy(this.sorted, n2 + 1, this.sorted, n2, this.size - n2 - 1);
        System.arraycopy(this.perm, n + 1, this.perm, n, this.size - n - 1);
        --this.size;
        this.sorted[this.size] = null;
        this.updateIndices(n + 1, n2, -1);
        this.nextRemove(n2, (E)e);
    }
    
    private void removeAllFromMapping() {
        final ArrayList<Object> list = new ArrayList<Object>((Collection<? extends E>)this);
        for (int i = 0; i < this.size; ++i) {
            this.sorted[i] = null;
        }
        this.nextRemove(this.size = 0, (List<? extends E>)list);
    }
    
    private void update(final ListChangeListener.Change<? extends E> change) {
        final int[] sort = this.helper.sort(this.sorted, 0, this.size, this.elementComparator);
        for (int i = 0; i < this.size; ++i) {
            this.perm[((Element<Object>)this.sorted[i]).index] = i;
        }
        this.nextPermutation(0, this.size, sort);
        for (int j = change.getFrom(); j < change.getTo(); ++j) {
            this.nextUpdate(this.perm[j]);
        }
    }
    
    private void addRemove(final ListChangeListener.Change<? extends E> change) {
        if (change.getFrom() == 0 && change.getRemovedSize() == this.size) {
            this.removeAllFromMapping();
        }
        else {
            for (int i = 0; i < change.getRemovedSize(); ++i) {
                this.removeFromMapping(change.getFrom(), change.getRemoved().get(i));
            }
        }
        if (this.size == 0) {
            this.setAllToMapping(change.getList(), change.getTo());
        }
        else {
            for (int j = change.getFrom(); j < change.getTo(); ++j) {
                this.insertToMapping((E)change.getList().get(j), j);
            }
        }
    }
    
    private static class Element<E>
    {
        private E e;
        private int index;
        
        public Element(final E e, final int index) {
            this.e = e;
            this.index = index;
        }
    }
    
    private static class ElementComparator<E> implements Comparator<Element<E>>
    {
        private final Comparator<? super E> comparator;
        
        public ElementComparator(final Comparator<? super E> comparator) {
            this.comparator = comparator;
        }
        
        @Override
        public int compare(final Element<E> element, final Element<E> element2) {
            return this.comparator.compare((Object)((Element<Object>)element).e, (Object)((Element<Object>)element2).e);
        }
    }
}
