// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections.transformation;

import java.util.Iterator;
import java.util.List;
import com.sun.javafx.collections.NonIterableChange;
import java.util.Collection;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Arrays;
import javafx.collections.ListChangeListener;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.NamedArg;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import java.util.function.Predicate;
import com.sun.javafx.collections.SortHelper;

public final class FilteredList<E> extends TransformationList<E, E>
{
    private int[] filtered;
    private int size;
    private SortHelper helper;
    private static final Predicate ALWAYS_TRUE;
    private ObjectProperty<Predicate<? super E>> predicate;
    
    public FilteredList(@NamedArg("source") final ObservableList<E> list, @NamedArg("predicate") final Predicate<? super E> predicate) {
        super(list);
        this.filtered = new int[list.size() * 3 / 2 + 1];
        if (predicate != null) {
            this.setPredicate(predicate);
        }
        else {
            this.size = 0;
            while (this.size < list.size()) {
                this.filtered[this.size] = this.size;
                ++this.size;
            }
        }
    }
    
    public FilteredList(@NamedArg("source") final ObservableList<E> list) {
        this(list, null);
    }
    
    public final ObjectProperty<Predicate<? super E>> predicateProperty() {
        if (this.predicate == null) {
            this.predicate = new ObjectPropertyBase<Predicate<? super E>>() {
                @Override
                protected void invalidated() {
                    FilteredList.this.refilter();
                }
                
                @Override
                public Object getBean() {
                    return FilteredList.this;
                }
                
                @Override
                public String getName() {
                    return "predicate";
                }
            };
        }
        return this.predicate;
    }
    
    public final Predicate<? super E> getPredicate() {
        return (this.predicate == null) ? null : this.predicate.get();
    }
    
    public final void setPredicate(final Predicate<? super E> predicate) {
        this.predicateProperty().set(predicate);
    }
    
    private Predicate<? super E> getPredicateImpl() {
        if (this.getPredicate() != null) {
            return this.getPredicate();
        }
        return (Predicate<? super E>)FilteredList.ALWAYS_TRUE;
    }
    
    @Override
    protected void sourceChanged(final ListChangeListener.Change<? extends E> change) {
        this.beginChange();
        while (change.next()) {
            if (change.wasPermutated()) {
                this.permutate(change);
            }
            else if (change.wasUpdated()) {
                this.update(change);
            }
            else {
                this.addRemove(change);
            }
        }
        this.endChange();
    }
    
    @Override
    public int size() {
        return this.size;
    }
    
    @Override
    public E get(final int n) {
        if (n >= this.size) {
            throw new IndexOutOfBoundsException();
        }
        return (E)this.getSource().get(this.filtered[n]);
    }
    
    @Override
    public int getSourceIndex(final int n) {
        if (n >= this.size) {
            throw new IndexOutOfBoundsException();
        }
        return this.filtered[n];
    }
    
    @Override
    public int getViewIndex(final int key) {
        return Arrays.binarySearch(this.filtered, 0, this.size, key);
    }
    
    private SortHelper getSortHelper() {
        if (this.helper == null) {
            this.helper = new SortHelper();
        }
        return this.helper;
    }
    
    private int findPosition(final int key) {
        if (this.filtered.length == 0) {
            return 0;
        }
        if (key == 0) {
            return 0;
        }
        int binarySearch = Arrays.binarySearch(this.filtered, 0, this.size, key);
        if (binarySearch < 0) {
            binarySearch ^= -1;
        }
        return binarySearch;
    }
    
    private void ensureSize(final int n) {
        if (this.filtered.length < n) {
            final int[] filtered = new int[n * 3 / 2 + 1];
            System.arraycopy(this.filtered, 0, filtered, 0, this.size);
            this.filtered = filtered;
        }
    }
    
    private void updateIndexes(final int n, final int n2) {
        for (int i = n; i < this.size; ++i) {
            final int[] filtered = this.filtered;
            final int n3 = i;
            filtered[n3] += n2;
        }
    }
    
    private void permutate(final ListChangeListener.Change<? extends E> change) {
        final int position = this.findPosition(change.getFrom());
        final int position2 = this.findPosition(change.getTo());
        if (position2 > position) {
            for (int i = position; i < position2; ++i) {
                this.filtered[i] = change.getPermutation(this.filtered[i]);
            }
            this.nextPermutation(position, position2, this.getSortHelper().sort(this.filtered, position, position2));
        }
    }
    
    private void addRemove(final ListChangeListener.Change<? extends E> change) {
        final Predicate<? super E> predicateImpl = this.getPredicateImpl();
        this.ensureSize(this.getSource().size());
        final int position = this.findPosition(change.getFrom());
        final int position2 = this.findPosition(change.getFrom() + change.getRemovedSize());
        for (int i = position; i < position2; ++i) {
            this.nextRemove(position, (E)change.getRemoved().get(this.filtered[i] - change.getFrom()));
        }
        this.updateIndexes(position2, change.getAddedSize() - change.getRemovedSize());
        int n = position;
        int from = change.getFrom();
        ListIterator<Object> listIterator;
        for (listIterator = this.getSource().listIterator(from); n < position2 && listIterator.nextIndex() < change.getTo(); ++n) {
            if (predicateImpl.test(listIterator.next())) {
                this.filtered[n] = listIterator.previousIndex();
                this.nextAdd(n, n + 1);
            }
        }
        if (n < position2) {
            System.arraycopy(this.filtered, position2, this.filtered, n, this.size - position2);
            this.size -= position2 - n;
        }
        else {
            while (listIterator.nextIndex() < change.getTo()) {
                if (predicateImpl.test(listIterator.next())) {
                    System.arraycopy(this.filtered, n, this.filtered, n + 1, this.size - n);
                    this.filtered[n] = listIterator.previousIndex();
                    this.nextAdd(n, n + 1);
                    ++n;
                    ++this.size;
                }
                ++from;
            }
        }
    }
    
    private void update(final ListChangeListener.Change<? extends E> change) {
        final Predicate<? super E> predicateImpl = this.getPredicateImpl();
        this.ensureSize(this.getSource().size());
        int from = change.getFrom();
        final int to = change.getTo();
        final int position = this.findPosition(from);
        int position2 = this.findPosition(to);
        final ListIterator<Object> listIterator = this.getSource().listIterator(from);
        for (int n = position; n < position2 || from < to; ++from) {
            final Object next = listIterator.next();
            if (n < this.size && this.filtered[n] == from) {
                if (!predicateImpl.test(next)) {
                    this.nextRemove(n, (E)next);
                    System.arraycopy(this.filtered, n + 1, this.filtered, n, this.size - n - 1);
                    --this.size;
                    --position2;
                }
                else {
                    this.nextUpdate(n);
                    ++n;
                }
            }
            else if (predicateImpl.test(next)) {
                this.nextAdd(n, n + 1);
                System.arraycopy(this.filtered, n, this.filtered, n + 1, this.size - n);
                this.filtered[n] = from;
                ++this.size;
                ++n;
                ++position2;
            }
        }
    }
    
    private void refilter() {
        this.ensureSize(this.getSource().size());
        List<Object> list = null;
        if (this.hasListeners()) {
            list = new ArrayList<Object>(this);
        }
        this.size = 0;
        int n = 0;
        final Predicate<? super E> predicateImpl = this.getPredicateImpl();
        final Iterator<Object> iterator = this.getSource().iterator();
        while (iterator.hasNext()) {
            if (predicateImpl.test(iterator.next())) {
                this.filtered[this.size++] = n;
            }
            ++n;
        }
        if (this.hasListeners()) {
            this.fireChange((ListChangeListener.Change<? extends E>)new NonIterableChange.GenericAddRemoveChange<Object>(0, this.size, list, (ObservableList<Object>)this));
        }
    }
    
    static {
        ALWAYS_TRUE = (p0 -> true);
    }
}
