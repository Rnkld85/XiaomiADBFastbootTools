// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import javafx.beans.NamedArg;
import java.lang.ref.WeakReference;
import javafx.beans.WeakListener;

public final class WeakListChangeListener<E> implements ListChangeListener<E>, WeakListener
{
    private final WeakReference<ListChangeListener<E>> ref;
    
    public WeakListChangeListener(@NamedArg("listener") final ListChangeListener<E> referent) {
        if (referent == null) {
            throw new NullPointerException("Listener must be specified.");
        }
        this.ref = new WeakReference<ListChangeListener<E>>(referent);
    }
    
    @Override
    public boolean wasGarbageCollected() {
        return this.ref.get() == null;
    }
    
    @Override
    public void onChanged(final Change<? extends E> change) {
        final ListChangeListener listChangeListener = this.ref.get();
        if (listChangeListener != null) {
            listChangeListener.onChanged(change);
        }
        else {
            change.getList().removeListener(this);
        }
    }
}
