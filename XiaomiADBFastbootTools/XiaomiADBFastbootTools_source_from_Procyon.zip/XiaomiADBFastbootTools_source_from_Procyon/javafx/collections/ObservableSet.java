// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import javafx.beans.Observable;
import java.util.Set;

public interface ObservableSet<E> extends Set<E>, Observable
{
    void addListener(final SetChangeListener<? super E> p0);
    
    void removeListener(final SetChangeListener<? super E> p0);
}
