// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import java.util.Collection;
import java.util.Arrays;
import javafx.beans.InvalidationListener;
import java.util.List;
import com.sun.javafx.collections.ListListenerHelper;
import java.util.AbstractList;

public abstract class ObservableListBase<E> extends AbstractList<E> implements ObservableList<E>
{
    private ListListenerHelper<E> listenerHelper;
    private final ListChangeBuilder<E> changeBuilder;
    
    public ObservableListBase() {
        this.changeBuilder = new ListChangeBuilder<E>(this);
    }
    
    protected final void nextUpdate(final int n) {
        this.changeBuilder.nextUpdate(n);
    }
    
    protected final void nextSet(final int n, final E e) {
        this.changeBuilder.nextSet(n, e);
    }
    
    protected final void nextReplace(final int n, final int n2, final List<? extends E> list) {
        this.changeBuilder.nextReplace(n, n2, list);
    }
    
    protected final void nextRemove(final int n, final List<? extends E> list) {
        this.changeBuilder.nextRemove(n, list);
    }
    
    protected final void nextRemove(final int n, final E e) {
        this.changeBuilder.nextRemove(n, e);
    }
    
    protected final void nextPermutation(final int n, final int n2, final int[] array) {
        this.changeBuilder.nextPermutation(n, n2, array);
    }
    
    protected final void nextAdd(final int n, final int n2) {
        this.changeBuilder.nextAdd(n, n2);
    }
    
    protected final void beginChange() {
        this.changeBuilder.beginChange();
    }
    
    protected final void endChange() {
        this.changeBuilder.endChange();
    }
    
    @Override
    public final void addListener(final InvalidationListener invalidationListener) {
        this.listenerHelper = ListListenerHelper.addListener(this.listenerHelper, invalidationListener);
    }
    
    @Override
    public final void removeListener(final InvalidationListener invalidationListener) {
        this.listenerHelper = ListListenerHelper.removeListener(this.listenerHelper, invalidationListener);
    }
    
    @Override
    public final void addListener(final ListChangeListener<? super E> listChangeListener) {
        this.listenerHelper = ListListenerHelper.addListener(this.listenerHelper, listChangeListener);
    }
    
    @Override
    public final void removeListener(final ListChangeListener<? super E> listChangeListener) {
        this.listenerHelper = ListListenerHelper.removeListener(this.listenerHelper, listChangeListener);
    }
    
    protected final void fireChange(final ListChangeListener.Change<? extends E> change) {
        ListListenerHelper.fireValueChangedEvent(this.listenerHelper, change);
    }
    
    protected final boolean hasListeners() {
        return ListListenerHelper.hasListeners(this.listenerHelper);
    }
    
    @Override
    public boolean addAll(final E... a) {
        return this.addAll((Collection<? extends E>)Arrays.asList(a));
    }
    
    @Override
    public boolean setAll(final E... a) {
        return this.setAll((Collection<? extends E>)Arrays.asList(a));
    }
    
    @Override
    public boolean setAll(final Collection<? extends E> collection) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public boolean removeAll(final E... a) {
        return this.removeAll(Arrays.asList(a));
    }
    
    @Override
    public boolean retainAll(final E... a) {
        return this.retainAll(Arrays.asList(a));
    }
    
    @Override
    public void remove(final int fromIndex, final int toIndex) {
        this.removeRange(fromIndex, toIndex);
    }
}
