// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

@FunctionalInterface
public interface SetChangeListener<E>
{
    void onChanged(final Change<? extends E> p0);
    
    public abstract static class Change<E>
    {
        private ObservableSet<E> set;
        
        public Change(final ObservableSet<E> set) {
            this.set = set;
        }
        
        public ObservableSet<E> getSet() {
            return this.set;
        }
        
        public abstract boolean wasAdded();
        
        public abstract boolean wasRemoved();
        
        public abstract E getElementAdded();
        
        public abstract E getElementRemoved();
    }
}
