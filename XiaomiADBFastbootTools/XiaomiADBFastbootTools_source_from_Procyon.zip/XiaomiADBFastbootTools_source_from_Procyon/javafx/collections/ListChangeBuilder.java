// 
// Decompiled by Procyon v0.5.36
// 

package javafx.collections;

import com.sun.javafx.collections.ChangeHelper;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

final class ListChangeBuilder<E>
{
    private static final int[] EMPTY_PERM;
    private final ObservableListBase<E> list;
    private int changeLock;
    private List<SubChange<E>> addRemoveChanges;
    private List<SubChange<E>> updateChanges;
    private SubChange<E> permutationChange;
    
    private void checkAddRemoveList() {
        if (this.addRemoveChanges == null) {
            this.addRemoveChanges = new ArrayList<SubChange<E>>();
        }
    }
    
    private void checkState() {
        if (this.changeLock == 0) {
            throw new IllegalStateException("beginChange was not called on this builder");
        }
    }
    
    private int findSubChange(final int n, final List<SubChange<E>> list) {
        int i = 0;
        int n2 = list.size() - 1;
        while (i <= n2) {
            final int n3 = (i + n2) / 2;
            final SubChange<E> subChange = list.get(n3);
            if (n >= subChange.to) {
                i = n3 + 1;
            }
            else {
                if (n >= subChange.from) {
                    return n3;
                }
                n2 = n3 - 1;
            }
        }
        return ~i;
    }
    
    private void insertUpdate(final int from) {
        final int subChange = this.findSubChange(from, this.updateChanges);
        if (subChange < 0) {
            final int n = ~subChange;
            final SubChange<E> subChange2;
            if (n > 0 && (subChange2 = this.updateChanges.get(n - 1)).to == from) {
                subChange2.to = from + 1;
            }
            else {
                final SubChange<E> subChange3;
                if (n < this.updateChanges.size() && (subChange3 = this.updateChanges.get(n)).from == from + 1) {
                    subChange3.from = from;
                }
                else {
                    this.updateChanges.add(n, new SubChange<E>(from, from + 1, null, ListChangeBuilder.EMPTY_PERM, true));
                }
            }
        }
    }
    
    private void insertRemoved(final int n, final E e) {
        int subChange = this.findSubChange(n, this.addRemoveChanges);
        if (subChange < 0) {
            subChange ^= -1;
            final SubChange<E> subChange2;
            if (subChange > 0 && (subChange2 = this.addRemoveChanges.get(subChange - 1)).to == n) {
                subChange2.removed.add(e);
                --subChange;
            }
            else {
                final SubChange<E> subChange3;
                if (subChange < this.addRemoveChanges.size() && (subChange3 = this.addRemoveChanges.get(subChange)).from == n + 1) {
                    final SubChange<E> subChange4 = subChange3;
                    --subChange4.from;
                    final SubChange<E> subChange5 = subChange3;
                    --subChange5.to;
                    subChange3.removed.add(0, e);
                }
                else {
                    final ArrayList<E> list = new ArrayList<E>();
                    list.add(e);
                    this.addRemoveChanges.add(subChange, new SubChange<E>(n, n, (List<Object>)list, ListChangeBuilder.EMPTY_PERM, false));
                }
            }
        }
        else {
            final SubChange<E> subChange7;
            final SubChange<E> subChange6 = subChange7 = this.addRemoveChanges.get(subChange);
            --subChange7.to;
            if (subChange6.from == subChange6.to && (subChange6.removed == null || subChange6.removed.isEmpty())) {
                this.addRemoveChanges.remove(subChange);
            }
        }
        for (int i = subChange + 1; i < this.addRemoveChanges.size(); ++i) {
            final SubChange<E> subChange9;
            final SubChange<E> subChange8 = subChange9 = this.addRemoveChanges.get(i);
            --subChange9.from;
            final SubChange<E> subChange10 = subChange8;
            --subChange10.to;
        }
    }
    
    private void insertAdd(final int n, final int to) {
        int subChange = this.findSubChange(n, this.addRemoveChanges);
        final int n2 = to - n;
        if (subChange < 0) {
            subChange ^= -1;
            final SubChange<E> subChange2;
            if (subChange > 0 && (subChange2 = this.addRemoveChanges.get(subChange - 1)).to == n) {
                subChange2.to = to;
                --subChange;
            }
            else {
                this.addRemoveChanges.add(subChange, new SubChange<E>(n, to, new ArrayList<E>(), ListChangeBuilder.EMPTY_PERM, false));
            }
        }
        else {
            final SubChange<E> subChange3 = this.addRemoveChanges.get(subChange);
            subChange3.to += n2;
        }
        for (int i = subChange + 1; i < this.addRemoveChanges.size(); ++i) {
            final SubChange<E> subChange5;
            final SubChange<E> subChange4 = subChange5 = this.addRemoveChanges.get(i);
            subChange5.from += n2;
            final SubChange<E> subChange6 = subChange4;
            subChange6.to += n2;
        }
    }
    
    private int compress(final List<SubChange<E>> list) {
        int n = 0;
        SubChange<E> subChange = list.get(0);
        for (int i = 1; i < list.size(); ++i) {
            final SubChange<E> subChange2 = list.get(i);
            if (subChange.to == subChange2.from) {
                subChange.to = subChange2.to;
                if (subChange.removed != null || subChange2.removed != null) {
                    if (subChange.removed == null) {
                        subChange.removed = (List<E>)new ArrayList<Object>();
                    }
                    subChange.removed.addAll((Collection<? extends E>)subChange2.removed);
                }
                list.set(i, null);
                ++n;
            }
            else {
                subChange = subChange2;
            }
        }
        return n;
    }
    
    ListChangeBuilder(final ObservableListBase<E> list) {
        this.list = list;
    }
    
    public void nextRemove(final int n, final E e) {
        this.checkState();
        this.checkAddRemoveList();
        final SubChange<E> subChange = this.addRemoveChanges.isEmpty() ? null : this.addRemoveChanges.get(this.addRemoveChanges.size() - 1);
        if (subChange != null && subChange.to == n) {
            subChange.removed.add(e);
        }
        else if (subChange != null && subChange.from == n + 1) {
            final SubChange<E> subChange2 = subChange;
            --subChange2.from;
            final SubChange<E> subChange3 = subChange;
            --subChange3.to;
            subChange.removed.add(0, e);
        }
        else {
            this.insertRemoved(n, e);
        }
        if (this.updateChanges != null && !this.updateChanges.isEmpty()) {
            int subChange4 = this.findSubChange(n, this.updateChanges);
            if (subChange4 < 0) {
                subChange4 ^= -1;
            }
            else {
                final SubChange<E> subChange5 = this.updateChanges.get(subChange4);
                if (subChange5.from == subChange5.to - 1) {
                    this.updateChanges.remove(subChange4);
                }
                else {
                    final SubChange<E> subChange6 = subChange5;
                    --subChange6.to;
                    ++subChange4;
                }
            }
            for (int i = subChange4; i < this.updateChanges.size(); ++i) {
                final SubChange<E> subChange7 = this.updateChanges.get(i);
                --subChange7.from;
                final SubChange<E> subChange8 = this.updateChanges.get(i);
                --subChange8.to;
            }
        }
    }
    
    public void nextRemove(final int n, final List<? extends E> list) {
        this.checkState();
        for (int i = 0; i < list.size(); ++i) {
            this.nextRemove(n, list.get(i));
        }
    }
    
    public void nextAdd(final int to, final int to2) {
        this.checkState();
        this.checkAddRemoveList();
        final SubChange<E> subChange = this.addRemoveChanges.isEmpty() ? null : this.addRemoveChanges.get(this.addRemoveChanges.size() - 1);
        final int n = to2 - to;
        if (subChange != null && subChange.to == to) {
            subChange.to = to2;
        }
        else if (subChange != null && to >= subChange.from && to < subChange.to) {
            final SubChange<E> subChange2 = subChange;
            subChange2.to += n;
        }
        else {
            this.insertAdd(to, to2);
        }
        if (this.updateChanges != null && !this.updateChanges.isEmpty()) {
            int subChange3 = this.findSubChange(to, this.updateChanges);
            if (subChange3 < 0) {
                subChange3 ^= -1;
            }
            else {
                final SubChange<E> subChange4 = this.updateChanges.get(subChange3);
                this.updateChanges.add(subChange3 + 1, new SubChange<E>(to2, subChange4.to + to2 - to, null, ListChangeBuilder.EMPTY_PERM, true));
                subChange4.to = to;
                subChange3 += 2;
            }
            for (int i = subChange3; i < this.updateChanges.size(); ++i) {
                final SubChange<E> subChange5 = this.updateChanges.get(i);
                subChange5.from += n;
                final SubChange<E> subChange6 = this.updateChanges.get(i);
                subChange6.to += n;
            }
        }
    }
    
    public void nextPermutation(final int n, final int n2, final int[] array) {
        this.checkState();
        int b = n;
        int length = n2;
        int[] array2 = array;
        if (this.addRemoveChanges != null && !this.addRemoveChanges.isEmpty()) {
            final int[] array3 = new int[this.list.size()];
            final TreeSet<Integer> set = new TreeSet<Integer>();
            int to = 0;
            int n3 = 0;
            for (int i = 0; i < this.addRemoveChanges.size(); ++i) {
                final SubChange<E> subChange = this.addRemoveChanges.get(i);
                for (int j = to; j < subChange.from; ++j) {
                    array3[(j < n || j >= n2) ? j : array[j - n]] = j + n3;
                }
                for (int k = subChange.from; k < subChange.to; ++k) {
                    array3[(k < n || k >= n2) ? k : array[k - n]] = -1;
                }
                to = subChange.to;
                final int n4 = (subChange.removed != null) ? subChange.removed.size() : 0;
                for (int l = subChange.from + n3; l < subChange.from + n3 + n4; ++l) {
                    set.add(l);
                }
                n3 += n4 - (subChange.to - subChange.from);
            }
            for (int n5 = to; n5 < array3.length; ++n5) {
                array3[(n5 < n || n5 >= n2) ? n5 : array[n5 - n]] = n5 + n3;
            }
            final int[] array4 = new int[this.list.size() + n3];
            int n6 = 0;
            for (int m = 0; m < array4.length; ++m) {
                if (set.contains(m)) {
                    array4[m] = m;
                }
                else {
                    while (array3[n6] == -1) {
                        ++n6;
                    }
                    array4[array3[n6++]] = m;
                }
            }
            b = 0;
            length = array4.length;
            array2 = array4;
        }
        if (this.permutationChange != null) {
            if (b == this.permutationChange.from && length == this.permutationChange.to) {
                for (int n7 = 0; n7 < array2.length; ++n7) {
                    this.permutationChange.perm[n7] = array2[this.permutationChange.perm[n7] - b];
                }
            }
            else {
                final int max = Math.max(this.permutationChange.to, length);
                final int min = Math.min(this.permutationChange.from, b);
                final int[] perm = new int[max - min];
                for (int n8 = min; n8 < max; ++n8) {
                    if (n8 < this.permutationChange.from || n8 >= this.permutationChange.to) {
                        perm[n8 - min] = array2[n8 - b];
                    }
                    else {
                        final int n9 = this.permutationChange.perm[n8 - this.permutationChange.from];
                        if (n9 < b || n9 >= length) {
                            perm[n8 - min] = n9;
                        }
                        else {
                            perm[n8 - min] = array2[n9 - b];
                        }
                    }
                }
                this.permutationChange.from = min;
                this.permutationChange.to = max;
                this.permutationChange.perm = perm;
            }
        }
        else {
            this.permutationChange = new SubChange<E>(b, length, null, array2, false);
        }
        if (this.addRemoveChanges != null && !this.addRemoveChanges.isEmpty()) {
            final TreeSet<Integer> set2 = new TreeSet<Integer>();
            final HashMap<Integer, List<E>> hashMap = (HashMap<Integer, List<E>>)new HashMap<Object, List<? extends E>>();
            for (int n10 = 0; n10 < this.addRemoveChanges.size(); ++n10) {
                final SubChange<E> subChange2 = this.addRemoveChanges.get(n10);
                for (int from = subChange2.from; from < subChange2.to; ++from) {
                    if (from < n || from >= n2) {
                        set2.add(from);
                    }
                    else {
                        set2.add(array[from - n]);
                    }
                }
                if (subChange2.removed != null) {
                    if (subChange2.from < n || subChange2.from >= n2) {
                        hashMap.put(Integer.valueOf(subChange2.from), (List<? extends E>)subChange2.removed);
                    }
                    else {
                        hashMap.put(Integer.valueOf(array[subChange2.from - n]), (List<? extends E>)subChange2.removed);
                    }
                }
            }
            this.addRemoveChanges.clear();
            SubChange<E> subChange3 = null;
            for (final Integer n11 : set2) {
                if (subChange3 == null || subChange3.to != n11) {
                    subChange3 = new SubChange<E>(n11, n11 + 1, null, ListChangeBuilder.EMPTY_PERM, false);
                    this.addRemoveChanges.add(subChange3);
                }
                else {
                    subChange3.to = n11 + 1;
                }
                final List<? extends E> removed = hashMap.remove(n11);
                if (removed != null) {
                    if (subChange3.removed != null) {
                        subChange3.removed.addAll(removed);
                    }
                    else {
                        subChange3.removed = (List<E>)removed;
                    }
                }
            }
            for (final Map.Entry<Integer, List<? extends E>> entry : hashMap.entrySet()) {
                final Integer n12 = entry.getKey();
                final int subChange4 = this.findSubChange(n12, this.addRemoveChanges);
                assert subChange4 < 0;
                this.addRemoveChanges.add(~subChange4, new SubChange<E>(n12, n12, (List<E>)entry.getValue(), new int[0], false));
            }
        }
        if (this.updateChanges != null && !this.updateChanges.isEmpty()) {
            final TreeSet<Integer> set3 = new TreeSet<Integer>();
            for (int n13 = 0; n13 < this.updateChanges.size(); ++n13) {
                final SubChange<E> subChange5 = this.updateChanges.get(n13);
                for (int from2 = subChange5.from; from2 < subChange5.to; ++from2) {
                    if (from2 < n || from2 >= n2) {
                        set3.add(from2);
                    }
                    else {
                        set3.add(array[from2 - n]);
                    }
                }
            }
            this.updateChanges.clear();
            SubChange<E> subChange6 = null;
            for (final Integer n14 : set3) {
                if (subChange6 == null || subChange6.to != n14) {
                    subChange6 = new SubChange<E>(n14, n14 + 1, null, ListChangeBuilder.EMPTY_PERM, true);
                    this.updateChanges.add(subChange6);
                }
                else {
                    subChange6.to = n14 + 1;
                }
            }
        }
    }
    
    public void nextReplace(final int n, final int n2, final List<? extends E> list) {
        this.nextRemove(n, list);
        this.nextAdd(n, n2);
    }
    
    public void nextSet(final int n, final E e) {
        this.nextRemove(n, e);
        this.nextAdd(n, n + 1);
    }
    
    public void nextUpdate(final int n) {
        this.checkState();
        if (this.updateChanges == null) {
            this.updateChanges = new ArrayList<SubChange<E>>();
        }
        final SubChange<E> subChange = this.updateChanges.isEmpty() ? null : this.updateChanges.get(this.updateChanges.size() - 1);
        if (subChange != null && subChange.to == n) {
            subChange.to = n + 1;
        }
        else {
            this.insertUpdate(n);
        }
    }
    
    private void commit() {
        final boolean b = this.addRemoveChanges != null && !this.addRemoveChanges.isEmpty();
        final boolean b2 = this.updateChanges != null && !this.updateChanges.isEmpty();
        if (this.changeLock == 0 && (b || b2 || this.permutationChange != null)) {
            int n = ((this.updateChanges != null) ? this.updateChanges.size() : 0) + ((this.addRemoveChanges != null) ? this.addRemoveChanges.size() : 0) + ((this.permutationChange != null) ? 1 : 0);
            if (n == 1) {
                if (b) {
                    this.list.fireChange((ListChangeListener.Change<? extends E>)new SingleChange<E>((SubChange<? extends E>)finalizeSubChange(this.addRemoveChanges.get(0)), (ObservableListBase<? extends E>)this.list));
                    this.addRemoveChanges.clear();
                }
                else if (b2) {
                    this.list.fireChange((ListChangeListener.Change<? extends E>)new SingleChange<E>((SubChange<? extends E>)finalizeSubChange(this.updateChanges.get(0)), (ObservableListBase<? extends E>)this.list));
                    this.updateChanges.clear();
                }
                else {
                    this.list.fireChange((ListChangeListener.Change<? extends E>)new SingleChange<E>((SubChange<? extends E>)finalizeSubChange(this.permutationChange), (ObservableListBase<? extends E>)this.list));
                    this.permutationChange = null;
                }
            }
            else {
                if (b2) {
                    n -= this.compress(this.updateChanges);
                }
                if (b) {
                    n -= this.compress(this.addRemoveChanges);
                }
                final SubChange[] array = new SubChange[n];
                int n2 = 0;
                if (this.permutationChange != null) {
                    array[n2++] = this.permutationChange;
                }
                if (b) {
                    for (int size = this.addRemoveChanges.size(), i = 0; i < size; ++i) {
                        final SubChange<E> subChange = this.addRemoveChanges.get(i);
                        if (subChange != null) {
                            array[n2++] = subChange;
                        }
                    }
                }
                if (b2) {
                    for (int size2 = this.updateChanges.size(), j = 0; j < size2; ++j) {
                        final SubChange<E> subChange2 = this.updateChanges.get(j);
                        if (subChange2 != null) {
                            array[n2++] = subChange2;
                        }
                    }
                }
                this.list.fireChange((ListChangeListener.Change<? extends E>)new IterableChange<E>((SubChange[])finalizeSubChangeArray((SubChange<Object>[])array), (ObservableList)this.list));
                if (this.addRemoveChanges != null) {
                    this.addRemoveChanges.clear();
                }
                if (this.updateChanges != null) {
                    this.updateChanges.clear();
                }
                this.permutationChange = null;
            }
        }
    }
    
    public void beginChange() {
        ++this.changeLock;
    }
    
    public void endChange() {
        if (this.changeLock <= 0) {
            throw new IllegalStateException("Called endChange before beginChange");
        }
        --this.changeLock;
        this.commit();
    }
    
    private static <E> SubChange<E>[] finalizeSubChangeArray(final SubChange<E>[] array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            finalizeSubChange(array[i]);
        }
        return array;
    }
    
    private static <E> SubChange<E> finalizeSubChange(final SubChange<E> subChange) {
        if (subChange.perm == null) {
            subChange.perm = ListChangeBuilder.EMPTY_PERM;
        }
        if (subChange.removed == null) {
            subChange.removed = (List<E>)Collections.emptyList();
        }
        else {
            subChange.removed = (List<E>)Collections.unmodifiableList((List<? extends E>)subChange.removed);
        }
        return subChange;
    }
    
    static {
        EMPTY_PERM = new int[0];
    }
    
    private static class SubChange<E>
    {
        int from;
        int to;
        List<E> removed;
        int[] perm;
        boolean updated;
        
        public SubChange(final int from, final int to, final List<E> removed, final int[] perm, final boolean updated) {
            this.from = from;
            this.to = to;
            this.removed = removed;
            this.perm = perm;
            this.updated = updated;
        }
    }
    
    private static class SingleChange<E> extends ListChangeListener.Change<E>
    {
        private final SubChange<E> change;
        private boolean onChange;
        
        public SingleChange(final SubChange<E> change, final ObservableListBase<E> observableListBase) {
            super(observableListBase);
            this.change = change;
        }
        
        @Override
        public boolean next() {
            return !this.onChange && (this.onChange = true);
        }
        
        @Override
        public void reset() {
            this.onChange = false;
        }
        
        @Override
        public int getFrom() {
            this.checkState();
            return this.change.from;
        }
        
        @Override
        public int getTo() {
            this.checkState();
            return this.change.to;
        }
        
        @Override
        public List<E> getRemoved() {
            this.checkState();
            return this.change.removed;
        }
        
        @Override
        protected int[] getPermutation() {
            this.checkState();
            return this.change.perm;
        }
        
        @Override
        public boolean wasUpdated() {
            this.checkState();
            return this.change.updated;
        }
        
        private void checkState() {
            if (!this.onChange) {
                throw new IllegalStateException("Invalid Change state: next() must be called before inspecting the Change.");
            }
        }
        
        @Override
        public String toString() {
            String s;
            if (this.change.perm.length != 0) {
                s = ChangeHelper.permChangeToString(this.change.perm);
            }
            else if (this.change.updated) {
                s = ChangeHelper.updateChangeToString(this.change.from, this.change.to);
            }
            else {
                s = ChangeHelper.addRemoveChangeToString(this.change.from, this.change.to, this.getList(), this.change.removed);
            }
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s);
        }
    }
    
    private static class IterableChange<E> extends ListChangeListener.Change<E>
    {
        private SubChange[] changes;
        private int cursor;
        
        private IterableChange(final SubChange[] changes, final ObservableList<E> list) {
            super(list);
            this.cursor = -1;
            this.changes = changes;
        }
        
        @Override
        public boolean next() {
            if (this.cursor + 1 < this.changes.length) {
                ++this.cursor;
                return true;
            }
            return false;
        }
        
        @Override
        public void reset() {
            this.cursor = -1;
        }
        
        @Override
        public int getFrom() {
            this.checkState();
            return this.changes[this.cursor].from;
        }
        
        @Override
        public int getTo() {
            this.checkState();
            return this.changes[this.cursor].to;
        }
        
        @Override
        public List<E> getRemoved() {
            this.checkState();
            return (List<E>)this.changes[this.cursor].removed;
        }
        
        @Override
        protected int[] getPermutation() {
            this.checkState();
            return this.changes[this.cursor].perm;
        }
        
        @Override
        public boolean wasUpdated() {
            this.checkState();
            return this.changes[this.cursor].updated;
        }
        
        private void checkState() {
            if (this.cursor == -1) {
                throw new IllegalStateException("Invalid Change state: next() must be called before inspecting the Change.");
            }
        }
        
        @Override
        public String toString() {
            int i = 0;
            final StringBuilder sb = new StringBuilder();
            sb.append("{ ");
            while (i < this.changes.length) {
                if (this.changes[i].perm.length != 0) {
                    sb.append(ChangeHelper.permChangeToString(this.changes[i].perm));
                }
                else if (this.changes[i].updated) {
                    sb.append(ChangeHelper.updateChangeToString(this.changes[i].from, this.changes[i].to));
                }
                else {
                    sb.append(ChangeHelper.addRemoveChangeToString(this.changes[i].from, this.changes[i].to, this.getList(), this.changes[i].removed));
                }
                if (i != this.changes.length - 1) {
                    sb.append(", ");
                }
                ++i;
            }
            sb.append(" }");
            return sb.toString();
        }
    }
}
