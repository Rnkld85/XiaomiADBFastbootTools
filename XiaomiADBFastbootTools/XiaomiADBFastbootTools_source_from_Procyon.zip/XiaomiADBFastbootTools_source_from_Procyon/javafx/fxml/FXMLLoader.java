// 
// Decompiled by Procyon v0.5.36
// 

package javafx.fxml;

import java.lang.reflect.Modifier;
import java.util.EnumMap;
import javax.script.ScriptException;
import java.lang.reflect.Constructor;
import com.sun.javafx.reflect.ConstructorUtil;
import java.util.Locale;
import java.util.Collections;
import java.util.Set;
import java.util.ArrayList;
import java.util.AbstractMap;
import com.sun.javafx.reflect.MethodUtil;
import com.sun.javafx.beans.IDProperty;
import com.sun.javafx.util.Logging;
import javafx.event.EventType;
import javafx.event.EventTarget;
import javafx.event.Event;
import javafx.beans.value.ChangeListener;
import javafx.collections.SetChangeListener;
import javafx.collections.MapChangeListener;
import javafx.beans.InvalidationListener;
import javafx.collections.ListChangeListener;
import javafx.event.EventHandler;
import javafx.collections.ObservableSet;
import javafx.collections.ObservableList;
import java.lang.reflect.Type;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Array;
import com.sun.javafx.fxml.expression.KeyPath;
import java.net.MalformedURLException;
import com.sun.javafx.fxml.PropertyNotFoundException;
import javafx.beans.value.ObservableValue;
import com.sun.javafx.fxml.expression.ExpressionValue;
import javafx.beans.property.Property;
import com.sun.javafx.fxml.expression.Expression;
import javafx.util.Builder;
import javafx.beans.DefaultProperty;
import com.sun.javafx.fxml.BeanAdapter;
import com.sun.javafx.fxml.FXMLLoaderHelper;
import java.security.PrivilegedAction;
import java.security.AccessController;
import java.util.StringTokenizer;
import com.sun.javafx.FXPermissions;
import java.security.Permission;
import com.sun.javafx.reflect.ReflectUtil;
import javax.script.Bindings;
import javax.script.SimpleBindings;
import com.sun.javafx.fxml.ParseTraceElement;
import java.lang.reflect.InvocationTargetException;
import com.sun.javafx.fxml.MethodHelper;
import java.lang.reflect.Method;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.util.StreamReaderDelegate;
import java.io.Reader;
import java.io.InputStreamReader;
import javax.xml.stream.XMLInputFactory;
import java.io.InputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import javafx.collections.FXCollections;
import java.util.Iterator;
import java.lang.reflect.Field;
import java.util.regex.Pattern;
import javax.script.ScriptEngineManager;
import java.util.Map;
import java.util.List;
import javax.script.ScriptEngine;
import javax.xml.stream.XMLStreamReader;
import java.util.LinkedList;
import java.nio.charset.Charset;
import javafx.util.Callback;
import javafx.util.BuilderFactory;
import javafx.collections.ObservableMap;
import java.util.ResourceBundle;
import java.net.URL;

public class FXMLLoader
{
    private static final RuntimePermission GET_CLASSLOADER_PERMISSION;
    private static final StackWalker walker;
    private URL location;
    private ResourceBundle resources;
    private ObservableMap<String, Object> namespace;
    private Object root;
    private Object controller;
    private BuilderFactory builderFactory;
    private Callback<Class<?>, Object> controllerFactory;
    private Charset charset;
    private final LinkedList<FXMLLoader> loaders;
    private ClassLoader classLoader;
    private boolean staticLoad;
    private LoadListener loadListener;
    private FXMLLoader parentLoader;
    private XMLStreamReader xmlStreamReader;
    private Element current;
    private ScriptEngine scriptEngine;
    private List<String> packages;
    private Map<String, Class<?>> classes;
    private ScriptEngineManager scriptEngineManager;
    private static ClassLoader defaultClassLoader;
    private static final Pattern extraneousWhitespacePattern;
    private static BuilderFactory DEFAULT_BUILDER_FACTORY;
    public static final String DEFAULT_CHARSET_NAME = "UTF-8";
    public static final String LANGUAGE_PROCESSING_INSTRUCTION = "language";
    public static final String IMPORT_PROCESSING_INSTRUCTION = "import";
    public static final String FX_NAMESPACE_PREFIX = "fx";
    public static final String FX_CONTROLLER_ATTRIBUTE = "controller";
    public static final String FX_ID_ATTRIBUTE = "id";
    public static final String FX_VALUE_ATTRIBUTE = "value";
    public static final String FX_CONSTANT_ATTRIBUTE = "constant";
    public static final String FX_FACTORY_ATTRIBUTE = "factory";
    public static final String INCLUDE_TAG = "include";
    public static final String INCLUDE_SOURCE_ATTRIBUTE = "source";
    public static final String INCLUDE_RESOURCES_ATTRIBUTE = "resources";
    public static final String INCLUDE_CHARSET_ATTRIBUTE = "charset";
    public static final String SCRIPT_TAG = "script";
    public static final String SCRIPT_SOURCE_ATTRIBUTE = "source";
    public static final String SCRIPT_CHARSET_ATTRIBUTE = "charset";
    public static final String DEFINE_TAG = "define";
    public static final String REFERENCE_TAG = "reference";
    public static final String REFERENCE_SOURCE_ATTRIBUTE = "source";
    public static final String ROOT_TAG = "root";
    public static final String ROOT_TYPE_ATTRIBUTE = "type";
    public static final String COPY_TAG = "copy";
    public static final String COPY_SOURCE_ATTRIBUTE = "source";
    public static final String EVENT_HANDLER_PREFIX = "on";
    public static final String EVENT_KEY = "event";
    public static final String CHANGE_EVENT_HANDLER_SUFFIX = "Change";
    private static final String COLLECTION_HANDLER_NAME = "onChange";
    public static final String NULL_KEYWORD = "null";
    public static final String ESCAPE_PREFIX = "\\";
    public static final String RELATIVE_PATH_PREFIX = "@";
    public static final String RESOURCE_KEY_PREFIX = "%";
    public static final String EXPRESSION_PREFIX = "$";
    public static final String BINDING_EXPRESSION_PREFIX = "${";
    public static final String BINDING_EXPRESSION_SUFFIX = "}";
    public static final String BI_DIRECTIONAL_BINDING_PREFIX = "#{";
    public static final String BI_DIRECTIONAL_BINDING_SUFFIX = "}";
    public static final String ARRAY_COMPONENT_DELIMITER = ",";
    public static final String LOCATION_KEY = "location";
    public static final String RESOURCES_KEY = "resources";
    public static final String CONTROLLER_METHOD_PREFIX = "#";
    public static final String CONTROLLER_KEYWORD = "controller";
    public static final String CONTROLLER_SUFFIX = "Controller";
    public static final String INITIALIZE_METHOD_NAME = "initialize";
    public static final String JAVAFX_VERSION;
    public static final String FX_NAMESPACE_VERSION = "1";
    private Class<?> callerClass;
    private final ControllerAccessor controllerAccessor;
    
    private void injectFields(final String s, final Object value) throws LoadException {
        if (this.controller != null && s != null) {
            final List<Field> list = this.controllerAccessor.getControllerFields().get(s);
            if (list != null) {
                try {
                    final Iterator<Field> iterator = list.iterator();
                    while (iterator.hasNext()) {
                        iterator.next().set(this.controller, value);
                    }
                }
                catch (IllegalAccessException ex) {
                    throw this.constructLoadException(ex);
                }
            }
        }
    }
    
    public FXMLLoader() {
        this((URL)null);
    }
    
    public FXMLLoader(final URL url) {
        this(url, null);
    }
    
    public FXMLLoader(final URL url, final ResourceBundle resourceBundle) {
        this(url, resourceBundle, null);
    }
    
    public FXMLLoader(final URL url, final ResourceBundle resourceBundle, final BuilderFactory builderFactory) {
        this(url, resourceBundle, builderFactory, null);
    }
    
    public FXMLLoader(final URL url, final ResourceBundle resourceBundle, final BuilderFactory builderFactory, final Callback<Class<?>, Object> callback) {
        this(url, resourceBundle, builderFactory, callback, Charset.forName("UTF-8"));
    }
    
    public FXMLLoader(final Charset charset) {
        this(null, null, null, null, charset);
    }
    
    public FXMLLoader(final URL url, final ResourceBundle resourceBundle, final BuilderFactory builderFactory, final Callback<Class<?>, Object> callback, final Charset charset) {
        this(url, resourceBundle, builderFactory, callback, charset, new LinkedList<FXMLLoader>());
    }
    
    public FXMLLoader(final URL location, final ResourceBundle resources, final BuilderFactory builderFactory, final Callback<Class<?>, Object> controllerFactory, final Charset charset, final LinkedList<FXMLLoader> c) {
        this.namespace = FXCollections.observableHashMap();
        this.root = null;
        this.controller = null;
        this.classLoader = null;
        this.staticLoad = false;
        this.loadListener = null;
        this.xmlStreamReader = null;
        this.current = null;
        this.scriptEngine = null;
        this.packages = new LinkedList<String>();
        this.classes = new HashMap<String, Class<?>>();
        this.scriptEngineManager = null;
        this.controllerAccessor = new ControllerAccessor();
        this.setLocation(location);
        this.setResources(resources);
        this.setBuilderFactory(builderFactory);
        this.setControllerFactory(controllerFactory);
        this.setCharset(charset);
        this.loaders = new LinkedList<FXMLLoader>(c);
    }
    
    public URL getLocation() {
        return this.location;
    }
    
    public void setLocation(final URL location) {
        this.location = location;
    }
    
    public ResourceBundle getResources() {
        return this.resources;
    }
    
    public void setResources(final ResourceBundle resources) {
        this.resources = resources;
    }
    
    public ObservableMap<String, Object> getNamespace() {
        return this.namespace;
    }
    
    public <T> T getRoot() {
        return (T)this.root;
    }
    
    public void setRoot(final Object root) {
        this.root = root;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof FXMLLoader)) {
            return false;
        }
        final FXMLLoader fxmlLoader = (FXMLLoader)o;
        if (this.location == null || fxmlLoader.location == null) {
            return fxmlLoader.location == this.location;
        }
        return this.location.toExternalForm().equals(fxmlLoader.location.toExternalForm());
    }
    
    private boolean isCyclic(final FXMLLoader fxmlLoader, final FXMLLoader fxmlLoader2) {
        return fxmlLoader != null && (fxmlLoader.equals(fxmlLoader2) || this.isCyclic(fxmlLoader.parentLoader, fxmlLoader2));
    }
    
    public <T> T getController() {
        return (T)this.controller;
    }
    
    public void setController(final Object o) {
        this.controller = o;
        if (o == null) {
            this.namespace.remove("controller");
        }
        else {
            this.namespace.put("controller", o);
        }
        this.controllerAccessor.setController(o);
    }
    
    public BuilderFactory getBuilderFactory() {
        return this.builderFactory;
    }
    
    public void setBuilderFactory(final BuilderFactory builderFactory) {
        this.builderFactory = builderFactory;
    }
    
    public Callback<Class<?>, Object> getControllerFactory() {
        return this.controllerFactory;
    }
    
    public void setControllerFactory(final Callback<Class<?>, Object> controllerFactory) {
        this.controllerFactory = controllerFactory;
    }
    
    public Charset getCharset() {
        return this.charset;
    }
    
    public void setCharset(final Charset charset) {
        if (charset == null) {
            throw new NullPointerException("charset is null.");
        }
        this.charset = charset;
    }
    
    public ClassLoader getClassLoader() {
        if (this.classLoader == null) {
            return getDefaultClassLoader((System.getSecurityManager() != null) ? FXMLLoader.walker.getCallerClass() : null);
        }
        return this.classLoader;
    }
    
    public void setClassLoader(final ClassLoader classLoader) {
        if (classLoader == null) {
            throw new IllegalArgumentException();
        }
        this.classLoader = classLoader;
        this.clearImports();
    }
    
    boolean isStaticLoad() {
        return this.staticLoad;
    }
    
    void setStaticLoad(final boolean staticLoad) {
        this.staticLoad = staticLoad;
    }
    
    public LoadListener getLoadListener() {
        return this.loadListener;
    }
    
    public final void setLoadListener(final LoadListener loadListener) {
        this.loadListener = loadListener;
    }
    
    public <T> T load() throws IOException {
        return this.loadImpl((System.getSecurityManager() != null) ? FXMLLoader.walker.getCallerClass() : null);
    }
    
    public <T> T load(final InputStream inputStream) throws IOException {
        return this.loadImpl(inputStream, (System.getSecurityManager() != null) ? FXMLLoader.walker.getCallerClass() : null);
    }
    
    private <T> T loadImpl(final Class<?> clazz) throws IOException {
        if (this.location == null) {
            throw new IllegalStateException("Location is not set.");
        }
        InputStream openStream = null;
        Object loadImpl;
        try {
            openStream = this.location.openStream();
            loadImpl = this.loadImpl(openStream, clazz);
        }
        finally {
            if (openStream != null) {
                openStream.close();
            }
        }
        return (T)loadImpl;
    }
    
    private <T> T loadImpl(final InputStream in, final Class<?> clazz) throws IOException {
        if (in == null) {
            throw new NullPointerException("inputStream is null.");
        }
        this.callerClass = clazz;
        this.controllerAccessor.setCallerClass(clazz);
        try {
            this.clearImports();
            this.namespace.put("location", this.location);
            this.namespace.put("resources", this.resources);
            this.scriptEngine = null;
            try {
                final XMLInputFactory instance = XMLInputFactory.newInstance();
                instance.setProperty("javax.xml.stream.isCoalescing", true);
                this.xmlStreamReader = new StreamReaderDelegate(instance.createXMLStreamReader(new InputStreamReader(in, this.charset))) {
                    @Override
                    public String getPrefix() {
                        String prefix = super.getPrefix();
                        if (prefix != null && prefix.length() == 0) {
                            prefix = null;
                        }
                        return prefix;
                    }
                    
                    @Override
                    public String getAttributePrefix(final int index) {
                        String attributePrefix = super.getAttributePrefix(index);
                        if (attributePrefix != null && attributePrefix.length() == 0) {
                            attributePrefix = null;
                        }
                        return attributePrefix;
                    }
                };
            }
            catch (XMLStreamException ex) {
                throw this.constructLoadException(ex);
            }
            this.loaders.push(this);
            try {
                while (this.xmlStreamReader.hasNext()) {
                    switch (this.xmlStreamReader.next()) {
                        case 3: {
                            this.processProcessingInstruction();
                            continue;
                        }
                        case 5: {
                            this.processComment();
                            continue;
                        }
                        case 1: {
                            this.processStartElement();
                            continue;
                        }
                        case 2: {
                            this.processEndElement();
                            continue;
                        }
                        case 4: {
                            this.processCharacters();
                            continue;
                        }
                    }
                }
            }
            catch (XMLStreamException ex2) {
                throw this.constructLoadException(ex2);
            }
            if (this.controller != null) {
                if (this.controller instanceof Initializable) {
                    ((Initializable)this.controller).initialize(this.location, this.resources);
                }
                else {
                    this.controllerAccessor.getControllerFields();
                    this.injectFields("location", this.location);
                    this.injectFields("resources", this.resources);
                    final Method method = this.controllerAccessor.getControllerMethods().get(SupportedType.PARAMETERLESS).get("initialize");
                    if (method != null) {
                        try {
                            MethodHelper.invoke(method, this.controller, new Object[0]);
                        }
                        catch (IllegalAccessException ex3) {
                            throw this.constructLoadException(ex3);
                        }
                        catch (InvocationTargetException ex4) {
                            throw this.constructLoadException(ex4);
                        }
                    }
                }
            }
        }
        catch (LoadException ex5) {
            throw ex5;
        }
        catch (Exception ex6) {
            throw this.constructLoadException(ex6);
        }
        finally {
            this.controllerAccessor.setCallerClass(null);
            this.controllerAccessor.reset();
            this.xmlStreamReader = null;
        }
        return (T)this.root;
    }
    
    private void clearImports() {
        this.packages.clear();
        this.classes.clear();
    }
    
    private LoadException constructLoadException(final String s) {
        return new LoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, this.constructFXMLTrace()));
    }
    
    private LoadException constructLoadException(final Throwable t) {
        return new LoadException(this.constructFXMLTrace(), t);
    }
    
    private LoadException constructLoadException(final String s, final Throwable t) {
        return new LoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, this.constructFXMLTrace()), t);
    }
    
    private String constructFXMLTrace() {
        final StringBuilder sb = new StringBuilder("\n");
        for (final FXMLLoader fxmlLoader : this.loaders) {
            sb.append((fxmlLoader.location != null) ? fxmlLoader.location.getPath() : "unknown path");
            if (fxmlLoader.current != null) {
                sb.append(":");
                sb.append(fxmlLoader.getLineNumber());
            }
            sb.append("\n");
        }
        return sb.toString();
    }
    
    int getLineNumber() {
        return this.xmlStreamReader.getLocation().getLineNumber();
    }
    
    ParseTraceElement[] getParseTrace() {
        final ParseTraceElement[] array = new ParseTraceElement[this.loaders.size()];
        int n = 0;
        for (final FXMLLoader fxmlLoader : this.loaders) {
            array[n++] = new ParseTraceElement(fxmlLoader.location, (fxmlLoader.current != null) ? fxmlLoader.getLineNumber() : -1);
        }
        return array;
    }
    
    private void processProcessingInstruction() throws LoadException {
        final String trim = this.xmlStreamReader.getPITarget().trim();
        if (trim.equals("language")) {
            this.processLanguage();
        }
        else if (trim.equals("import")) {
            this.processImport();
        }
    }
    
    private void processLanguage() throws LoadException {
        if (this.scriptEngine != null) {
            throw this.constructLoadException("Page language already set.");
        }
        final String piData = this.xmlStreamReader.getPIData();
        if (this.loadListener != null) {
            this.loadListener.readLanguageProcessingInstruction(piData);
        }
        if (!this.staticLoad) {
            this.scriptEngine = this.getScriptEngineManager().getEngineByName(piData);
        }
    }
    
    private void processImport() throws LoadException {
        final String trim = this.xmlStreamReader.getPIData().trim();
        if (this.loadListener != null) {
            this.loadListener.readImportProcessingInstruction(trim);
        }
        if (trim.endsWith(".*")) {
            this.importPackage(trim.substring(0, trim.length() - 2));
        }
        else {
            this.importClass(trim);
        }
    }
    
    private void processComment() throws LoadException {
        if (this.loadListener != null) {
            this.loadListener.readComment(this.xmlStreamReader.getText());
        }
    }
    
    private void processStartElement() throws IOException {
        this.createElement();
        this.current.processStartElement();
        if (this.root == null) {
            this.root = this.current.value;
        }
    }
    
    private void createElement() throws IOException {
        final String prefix = this.xmlStreamReader.getPrefix();
        final String localName = this.xmlStreamReader.getLocalName();
        if (prefix == null) {
            final int lastIndex = localName.lastIndexOf(46);
            if (Character.isLowerCase(localName.charAt(lastIndex + 1))) {
                final String substring = localName.substring(lastIndex + 1);
                if (lastIndex == -1) {
                    if (this.loadListener != null) {
                        this.loadListener.beginPropertyElement(substring, null);
                    }
                    this.current = new PropertyElement(substring, null);
                }
                else {
                    final Class<?> type = this.getType(localName.substring(0, lastIndex));
                    if (type != null) {
                        if (this.loadListener != null) {
                            this.loadListener.beginPropertyElement(substring, type);
                        }
                        this.current = new PropertyElement(substring, type);
                    }
                    else {
                        if (!this.staticLoad) {
                            throw this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, localName));
                        }
                        if (this.loadListener != null) {
                            this.loadListener.beginUnknownStaticPropertyElement(localName);
                        }
                        this.current = new UnknownStaticPropertyElement();
                    }
                }
            }
            else {
                if (this.current == null && this.root != null) {
                    throw this.constructLoadException("Root value already specified.");
                }
                final Class<?> type2 = this.getType(localName);
                if (type2 != null) {
                    if (this.loadListener != null) {
                        this.loadListener.beginInstanceDeclarationElement(type2);
                    }
                    this.current = new InstanceDeclarationElement(type2);
                }
                else {
                    if (!this.staticLoad) {
                        throw this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, localName));
                    }
                    if (this.loadListener != null) {
                        this.loadListener.beginUnknownTypeElement(localName);
                    }
                    this.current = new UnknownTypeElement();
                }
            }
        }
        else {
            if (!prefix.equals("fx")) {
                throw this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, prefix));
            }
            if (localName.equals("include")) {
                if (this.loadListener != null) {
                    this.loadListener.beginIncludeElement();
                }
                this.current = new IncludeElement();
            }
            else if (localName.equals("reference")) {
                if (this.loadListener != null) {
                    this.loadListener.beginReferenceElement();
                }
                this.current = new ReferenceElement();
            }
            else if (localName.equals("copy")) {
                if (this.loadListener != null) {
                    this.loadListener.beginCopyElement();
                }
                this.current = new CopyElement();
            }
            else if (localName.equals("root")) {
                if (this.loadListener != null) {
                    this.loadListener.beginRootElement();
                }
                this.current = new RootElement();
            }
            else if (localName.equals("script")) {
                if (this.loadListener != null) {
                    this.loadListener.beginScriptElement();
                }
                this.current = new ScriptElement();
            }
            else {
                if (!localName.equals("define")) {
                    throw this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, prefix, localName));
                }
                if (this.loadListener != null) {
                    this.loadListener.beginDefineElement();
                }
                this.current = new DefineElement();
            }
        }
    }
    
    private void processEndElement() throws IOException {
        this.current.processEndElement();
        if (this.loadListener != null) {
            this.loadListener.endElement(this.current.value);
        }
        this.current = this.current.parent;
    }
    
    private void processCharacters() throws IOException {
        if (!this.xmlStreamReader.isWhiteSpace()) {
            this.current.processCharacters();
        }
    }
    
    private void importPackage(final String s) throws LoadException {
        this.packages.add(s);
    }
    
    private void importClass(final String s) throws LoadException {
        try {
            this.loadType(s, true);
        }
        catch (ClassNotFoundException ex) {
            throw this.constructLoadException(ex);
        }
    }
    
    private Class<?> getType(final String s) throws LoadException {
        Class<?> clazz = null;
        if (Character.isLowerCase(s.charAt(0))) {
            try {
                clazz = this.loadType(s, false);
            }
            catch (ClassNotFoundException ex) {}
        }
        else {
            clazz = this.classes.get(s);
            if (clazz == null) {
                for (final String s2 : this.packages) {
                    try {
                        clazz = this.loadTypeForPackage(s2, s);
                    }
                    catch (ClassNotFoundException ex2) {}
                    if (clazz != null) {
                        break;
                    }
                }
                if (clazz != null) {
                    this.classes.put(s, clazz);
                }
            }
        }
        return clazz;
    }
    
    private Class<?> loadType(final String s, final boolean b) throws ClassNotFoundException {
        int endIndex;
        int length;
        for (endIndex = s.indexOf(46), length = s.length(); endIndex != -1 && endIndex < length && Character.isLowerCase(s.charAt(endIndex + 1)); endIndex = s.indexOf(46, endIndex + 1)) {}
        if (endIndex == -1 || endIndex == length) {
            throw new ClassNotFoundException();
        }
        final String substring = s.substring(0, endIndex);
        final String substring2 = s.substring(endIndex + 1);
        final Class<?> loadTypeForPackage = this.loadTypeForPackage(substring, substring2);
        if (b) {
            this.classes.put(substring2, loadTypeForPackage);
        }
        return loadTypeForPackage;
    }
    
    private Class<?> loadTypeForPackage(final String s, final String s2) throws ClassNotFoundException {
        return this.getClassLoader().loadClass(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, s2.replace('.', '$')));
    }
    
    private static SupportedType toSupportedType(final Method method) {
        for (final SupportedType supportedType : SupportedType.values()) {
            if (supportedType.methodIsOfType(method)) {
                return supportedType;
            }
        }
        return null;
    }
    
    private ScriptEngineManager getScriptEngineManager() {
        if (this.scriptEngineManager == null) {
            (this.scriptEngineManager = new ScriptEngineManager()).setBindings(new SimpleBindings(this.namespace));
        }
        return this.scriptEngineManager;
    }
    
    @Deprecated
    public static Class<?> loadType(final String s, final String s2) throws ClassNotFoundException {
        return loadType(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, s2.replace('.', '$')));
    }
    
    @Deprecated
    public static Class<?> loadType(final String name) throws ClassNotFoundException {
        ReflectUtil.checkPackageAccess(name);
        return Class.forName(name, true, getDefaultClassLoader());
    }
    
    private static boolean needsClassLoaderPermissionCheck(final Class clazz) {
        return clazz != null && !FXMLLoader.class.getModule().equals(clazz.getModule());
    }
    
    private static ClassLoader getDefaultClassLoader(final Class clazz) {
        if (FXMLLoader.defaultClassLoader == null) {
            final SecurityManager securityManager = System.getSecurityManager();
            if (securityManager != null && needsClassLoaderPermissionCheck(clazz)) {
                securityManager.checkPermission(FXMLLoader.GET_CLASSLOADER_PERMISSION);
            }
            return Thread.currentThread().getContextClassLoader();
        }
        return FXMLLoader.defaultClassLoader;
    }
    
    public static ClassLoader getDefaultClassLoader() {
        return getDefaultClassLoader((System.getSecurityManager() != null) ? FXMLLoader.walker.getCallerClass() : null);
    }
    
    public static void setDefaultClassLoader(final ClassLoader defaultClassLoader) {
        if (defaultClassLoader == null) {
            throw new NullPointerException();
        }
        final SecurityManager securityManager = System.getSecurityManager();
        if (securityManager != null) {
            securityManager.checkPermission(FXPermissions.MODIFY_FXML_CLASS_LOADER_PERMISSION);
        }
        FXMLLoader.defaultClassLoader = defaultClassLoader;
    }
    
    public static <T> T load(final URL url) throws IOException {
        return loadImpl(url, (System.getSecurityManager() != null) ? FXMLLoader.walker.getCallerClass() : null);
    }
    
    private static <T> T loadImpl(final URL url, final Class<?> clazz) throws IOException {
        return loadImpl(url, null, clazz);
    }
    
    public static <T> T load(final URL url, final ResourceBundle resourceBundle) throws IOException {
        return loadImpl(url, resourceBundle, (System.getSecurityManager() != null) ? FXMLLoader.walker.getCallerClass() : null);
    }
    
    private static <T> T loadImpl(final URL url, final ResourceBundle resourceBundle, final Class<?> clazz) throws IOException {
        return loadImpl(url, resourceBundle, null, clazz);
    }
    
    public static <T> T load(final URL url, final ResourceBundle resourceBundle, final BuilderFactory builderFactory) throws IOException {
        return loadImpl(url, resourceBundle, builderFactory, (System.getSecurityManager() != null) ? FXMLLoader.walker.getCallerClass() : null);
    }
    
    private static <T> T loadImpl(final URL url, final ResourceBundle resourceBundle, final BuilderFactory builderFactory, final Class<?> clazz) throws IOException {
        return loadImpl(url, resourceBundle, builderFactory, null, clazz);
    }
    
    public static <T> T load(final URL url, final ResourceBundle resourceBundle, final BuilderFactory builderFactory, final Callback<Class<?>, Object> callback) throws IOException {
        return loadImpl(url, resourceBundle, builderFactory, callback, (System.getSecurityManager() != null) ? FXMLLoader.walker.getCallerClass() : null);
    }
    
    private static <T> T loadImpl(final URL url, final ResourceBundle resourceBundle, final BuilderFactory builderFactory, final Callback<Class<?>, Object> callback, final Class<?> clazz) throws IOException {
        return loadImpl(url, resourceBundle, builderFactory, callback, Charset.forName("UTF-8"), clazz);
    }
    
    public static <T> T load(final URL url, final ResourceBundle resourceBundle, final BuilderFactory builderFactory, final Callback<Class<?>, Object> callback, final Charset charset) throws IOException {
        return loadImpl(url, resourceBundle, builderFactory, callback, charset, (System.getSecurityManager() != null) ? FXMLLoader.walker.getCallerClass() : null);
    }
    
    private static <T> T loadImpl(final URL url, final ResourceBundle resourceBundle, final BuilderFactory builderFactory, final Callback<Class<?>, Object> callback, final Charset charset, final Class<?> clazz) throws IOException {
        if (url == null) {
            throw new NullPointerException("Location is required.");
        }
        return new FXMLLoader(url, resourceBundle, builderFactory, callback, charset).loadImpl(clazz);
    }
    
    static int compareJFXVersions(String str, final String s) {
        int n = 0;
        if (str == null || "".equals(str) || s == null || "".equals(s)) {
            return n;
        }
        if (str.equals(s)) {
            return n;
        }
        final int index = str.indexOf("-");
        if (index > 0) {
            str = str.substring(0, index);
        }
        final int index2 = str.indexOf("_");
        if (index2 > 0) {
            str = str.substring(0, index2);
        }
        if (!Pattern.matches("^(\\d+)(\\.\\d+)*$", str) || !Pattern.matches("^(\\d+)(\\.\\d+)*$", s)) {
            return n;
        }
        final StringTokenizer stringTokenizer = new StringTokenizer(s, ".");
        final StringTokenizer stringTokenizer2 = new StringTokenizer(str, ".");
        int int1 = 0;
        boolean b = false;
        while (stringTokenizer.hasMoreTokens() && n == 0) {
            int1 = Integer.parseInt(stringTokenizer.nextToken());
            if (!stringTokenizer2.hasMoreTokens()) {
                b = true;
                break;
            }
            n = Integer.parseInt(stringTokenizer2.nextToken()) - int1;
        }
        if (stringTokenizer2.hasMoreTokens() && n == 0 && Integer.parseInt(stringTokenizer2.nextToken()) > 0) {
            n = 1;
        }
        if (b) {
            if (int1 > 0) {
                n = -1;
            }
            else {
                while (stringTokenizer.hasMoreTokens()) {
                    if (Integer.parseInt(stringTokenizer.nextToken()) > 0) {
                        n = -1;
                        break;
                    }
                }
            }
        }
        return n;
    }
    
    private static void checkClassLoaderPermission() {
        final SecurityManager securityManager = System.getSecurityManager();
        if (securityManager != null) {
            securityManager.checkPermission(FXPermissions.MODIFY_FXML_CLASS_LOADER_PERMISSION);
        }
    }
    
    static {
        GET_CLASSLOADER_PERMISSION = new RuntimePermission("getClassLoader");
        walker = AccessController.doPrivileged(() -> StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE));
        FXMLLoader.defaultClassLoader = null;
        extraneousWhitespacePattern = Pattern.compile("\\s+");
        FXMLLoader.DEFAULT_BUILDER_FACTORY = new JavaFXBuilderFactory();
        JAVAFX_VERSION = AccessController.doPrivileged((PrivilegedAction<String>)new PrivilegedAction<String>() {
            @Override
            public String run() {
                return System.getProperty("javafx.version");
            }
        });
        FXMLLoaderHelper.setFXMLLoaderAccessor(new FXMLLoaderHelper.FXMLLoaderAccessor() {
            @Override
            public void setStaticLoad(final FXMLLoader fxmlLoader, final boolean staticLoad) {
                fxmlLoader.setStaticLoad(staticLoad);
            }
        });
    }
    
    private abstract class Element
    {
        public final Element parent;
        public Object value;
        private BeanAdapter valueAdapter;
        public final LinkedList<Attribute> eventHandlerAttributes;
        public final LinkedList<Attribute> instancePropertyAttributes;
        public final LinkedList<Attribute> staticPropertyAttributes;
        public final LinkedList<PropertyElement> staticPropertyElements;
        
        public Element() {
            this.value = null;
            this.valueAdapter = null;
            this.eventHandlerAttributes = new LinkedList<Attribute>();
            this.instancePropertyAttributes = new LinkedList<Attribute>();
            this.staticPropertyAttributes = new LinkedList<Attribute>();
            this.staticPropertyElements = new LinkedList<PropertyElement>();
            this.parent = FXMLLoader.this.current;
        }
        
        public boolean isCollection() {
            boolean b;
            if (this.value instanceof List) {
                b = true;
            }
            else {
                final DefaultProperty defaultProperty = this.value.getClass().getAnnotation(DefaultProperty.class);
                b = (defaultProperty != null && this.getProperties().get(defaultProperty.value()) instanceof List);
            }
            return b;
        }
        
        public void add(Object coerce) throws LoadException {
            List<Object> list;
            if (this.value instanceof List) {
                list = (List<Object>)this.value;
            }
            else {
                final Class<?> class1 = this.value.getClass();
                final String value = class1.getAnnotation(DefaultProperty.class).value();
                list = (List<Object>)this.getProperties().get(value);
                if (!Map.class.isAssignableFrom(class1)) {
                    coerce = BeanAdapter.coerce(coerce, BeanAdapter.getListItemType(this.getValueAdapter().getGenericType(value)));
                }
            }
            list.add(coerce);
        }
        
        public void set(final Object o) throws LoadException {
            if (this.value == null) {
                throw FXMLLoader.this.constructLoadException("Cannot set value on this element.");
            }
            final DefaultProperty defaultProperty = this.value.getClass().getAnnotation(DefaultProperty.class);
            if (defaultProperty == null) {
                throw FXMLLoader.this.constructLoadException("Element does not define a default property.");
            }
            this.getProperties().put(defaultProperty.value(), o);
        }
        
        public void updateValue(final Object value) {
            this.value = value;
            this.valueAdapter = null;
        }
        
        public boolean isTyped() {
            return !(this.value instanceof Map);
        }
        
        public BeanAdapter getValueAdapter() {
            if (this.valueAdapter == null) {
                this.valueAdapter = new BeanAdapter(this.value);
            }
            return this.valueAdapter;
        }
        
        public Map<String, Object> getProperties() {
            return (Map<String, Object>)(this.isTyped() ? this.getValueAdapter() : ((Map)this.value));
        }
        
        public void processStartElement() throws IOException {
            for (int i = 0; i < FXMLLoader.this.xmlStreamReader.getAttributeCount(); ++i) {
                final String attributePrefix = FXMLLoader.this.xmlStreamReader.getAttributePrefix(i);
                final String attributeLocalName = FXMLLoader.this.xmlStreamReader.getAttributeLocalName(i);
                final String attributeValue = FXMLLoader.this.xmlStreamReader.getAttributeValue(i);
                if (FXMLLoader.this.loadListener != null && attributePrefix != null && attributePrefix.equals("fx")) {
                    FXMLLoader.this.loadListener.readInternalAttribute(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, attributePrefix, attributeLocalName), attributeValue);
                }
                this.processAttribute(attributePrefix, attributeLocalName, attributeValue);
            }
        }
        
        public void processEndElement() throws IOException {
        }
        
        public void processCharacters() throws IOException {
            throw FXMLLoader.this.constructLoadException("Unexpected characters in input stream.");
        }
        
        public void processInstancePropertyAttributes() throws IOException {
            if (this.instancePropertyAttributes.size() > 0) {
                final Iterator<Attribute> iterator = this.instancePropertyAttributes.iterator();
                while (iterator.hasNext()) {
                    this.processPropertyAttribute(iterator.next());
                }
            }
        }
        
        public void processAttribute(final String s, final String s2, final String s3) throws IOException {
            if (s == null) {
                if (s2.startsWith("on")) {
                    if (FXMLLoader.this.loadListener != null) {
                        FXMLLoader.this.loadListener.readEventHandlerAttribute(s2, s3);
                    }
                    this.eventHandlerAttributes.add(new Attribute(s2, null, s3));
                }
                else {
                    final int lastIndex = s2.lastIndexOf(46);
                    if (lastIndex == -1) {
                        if (FXMLLoader.this.loadListener != null) {
                            FXMLLoader.this.loadListener.readPropertyAttribute(s2, null, s3);
                        }
                        this.instancePropertyAttributes.add(new Attribute(s2, null, s3));
                    }
                    else {
                        final String substring = s2.substring(lastIndex + 1);
                        final Class access$400 = FXMLLoader.this.getType(s2.substring(0, lastIndex));
                        if (access$400 != null) {
                            if (FXMLLoader.this.loadListener != null) {
                                FXMLLoader.this.loadListener.readPropertyAttribute(substring, access$400, s3);
                            }
                            this.staticPropertyAttributes.add(new Attribute(substring, access$400, s3));
                        }
                        else {
                            if (!FXMLLoader.this.staticLoad) {
                                throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s2));
                            }
                            if (FXMLLoader.this.loadListener != null) {
                                FXMLLoader.this.loadListener.readUnknownStaticPropertyAttribute(s2, s3);
                            }
                        }
                    }
                }
                return;
            }
            throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, s2));
        }
        
        public void processPropertyAttribute(final Attribute attribute) throws IOException {
            final String value = attribute.value;
            if (this.isBindingExpression(value)) {
                if (attribute.sourceType != null) {
                    throw FXMLLoader.this.constructLoadException("Cannot bind to static property.");
                }
                if (!this.isTyped()) {
                    throw FXMLLoader.this.constructLoadException("Cannot bind to untyped object.");
                }
                if (this.value instanceof Builder) {
                    throw FXMLLoader.this.constructLoadException("Cannot bind to builder property.");
                }
                if (!FXMLLoader.this.isStaticLoad()) {
                    final Expression<Object> value2 = Expression.valueOf(value.substring("${".length(), value.length() - 1));
                    final BeanAdapter beanAdapter = new BeanAdapter(this.value);
                    final ObservableValue<Object> propertyModel = beanAdapter.getPropertyModel(attribute.name);
                    final Class<?> type = beanAdapter.getType(attribute.name);
                    if (propertyModel instanceof Property) {
                        ((Property<Object>)propertyModel).bind(new ExpressionValue(FXMLLoader.this.namespace, value2, type));
                    }
                }
            }
            else {
                if (this.isBidirectionalBindingExpression(value)) {
                    throw FXMLLoader.this.constructLoadException(new UnsupportedOperationException("This feature is not currently enabled."));
                }
                this.processValue(attribute.sourceType, attribute.name, value);
            }
        }
        
        private boolean isBindingExpression(final String s) {
            return s.startsWith("${") && s.endsWith("}");
        }
        
        private boolean isBidirectionalBindingExpression(final String s) {
            return s.startsWith("#{");
        }
        
        private boolean processValue(final Class clazz, final String s, final String s2) throws LoadException {
            boolean b = false;
            if (clazz == null && this.isTyped()) {
                final BeanAdapter valueAdapter = this.getValueAdapter();
                final Class<?> type = valueAdapter.getType(s);
                if (type == null) {
                    throw new PropertyNotFoundException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                }
                if (List.class.isAssignableFrom(type) && valueAdapter.isReadOnly(s)) {
                    this.populateListFromString(valueAdapter, s, s2);
                    b = true;
                }
                else if (type.isArray()) {
                    this.applyProperty(s, clazz, this.populateArrayFromString(type, s2));
                    b = true;
                }
            }
            if (!b) {
                this.applyProperty(s, clazz, this.resolvePrefixedValue(s2));
                b = true;
            }
            return b;
        }
        
        private Object resolvePrefixedValue(String key) throws LoadException {
            if (!key.startsWith("\\")) {
                if (key.startsWith("@")) {
                    key = key.substring("@".length());
                    if (key.length() == 0) {
                        throw FXMLLoader.this.constructLoadException("Missing relative path.");
                    }
                    if (key.startsWith("@")) {
                        this.warnDeprecatedEscapeSequence("@");
                        return key;
                    }
                    if (key.charAt(0) == '/') {
                        final URL resource = FXMLLoader.this.getClassLoader().getResource(key.substring(1));
                        if (resource == null) {
                            throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, key));
                        }
                        return resource.toString();
                    }
                    else {
                        try {
                            return new URL(FXMLLoader.this.location, key).toString();
                        }
                        catch (MalformedURLException ex) {
                            System.err.println(invokedynamic(makeConcatWithConstants:(Ljava/net/URL;Ljava/lang/String;)Ljava/lang/String;, FXMLLoader.this.location, key));
                            return key;
                        }
                    }
                }
                if (key.startsWith("%")) {
                    key = key.substring("%".length());
                    if (key.length() == 0) {
                        throw FXMLLoader.this.constructLoadException("Missing resource key.");
                    }
                    if (key.startsWith("%")) {
                        this.warnDeprecatedEscapeSequence("%");
                        return key;
                    }
                    if (FXMLLoader.this.resources == null) {
                        throw FXMLLoader.this.constructLoadException("No resources specified.");
                    }
                    if (!FXMLLoader.this.resources.containsKey(key)) {
                        throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, key));
                    }
                    return FXMLLoader.this.resources.getString(key);
                }
                else if (key.startsWith("$")) {
                    key = key.substring("$".length());
                    if (key.length() == 0) {
                        throw FXMLLoader.this.constructLoadException("Missing expression.");
                    }
                    if (key.startsWith("$")) {
                        this.warnDeprecatedEscapeSequence("$");
                        return key;
                    }
                    if (key.equals("null")) {
                        return null;
                    }
                    return Expression.get(FXMLLoader.this.namespace, KeyPath.parse(key));
                }
                return key;
            }
            key = key.substring("\\".length());
            if (key.length() == 0 || (!key.startsWith("\\") && !key.startsWith("@") && !key.startsWith("%") && !key.startsWith("$") && !key.startsWith("#{"))) {
                throw FXMLLoader.this.constructLoadException("Invalid escape sequence.");
            }
            return key;
        }
        
        private Object populateArrayFromString(final Class<?> clazz, final String s) throws LoadException {
            final Class componentType = clazz.getComponentType();
            Object o;
            if (s.length() > 0) {
                final String[] split = s.split(",");
                o = Array.newInstance(componentType, split.length);
                for (int i = 0; i < split.length; ++i) {
                    Array.set(o, i, BeanAdapter.coerce(this.resolvePrefixedValue(split[i].trim()), (Class<?>)clazz.getComponentType()));
                }
            }
            else {
                o = Array.newInstance(componentType, 0);
            }
            return o;
        }
        
        private void populateListFromString(final BeanAdapter beanAdapter, final String s, final String s2) throws LoadException {
            final List list = (List)beanAdapter.get((Object)s);
            Type rawType = BeanAdapter.getGenericListItemType(beanAdapter.getGenericType(s));
            if (rawType instanceof ParameterizedType) {
                rawType = ((ParameterizedType)rawType).getRawType();
            }
            if (s2.length() > 0) {
                final String[] split = s2.split(",");
                for (int length = split.length, i = 0; i < length; ++i) {
                    list.add(BeanAdapter.coerce(this.resolvePrefixedValue(split[i].trim()), (Class<?>)rawType));
                }
            }
        }
        
        public void warnDeprecatedEscapeSequence(final String s) {
            System.err.println(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, s, s));
        }
        
        public void applyProperty(final String s, final Class<?> clazz, final Object o) {
            if (clazz == null) {
                this.getProperties().put(s, o);
            }
            else {
                BeanAdapter.put(this.value, clazz, s, o);
            }
        }
        
        private Object getExpressionObject(String substring) throws LoadException {
            if (!substring.startsWith("$")) {
                return null;
            }
            substring = substring.substring("$".length());
            if (substring.length() == 0) {
                throw FXMLLoader.this.constructLoadException("Missing expression reference.");
            }
            final Object value = Expression.get(FXMLLoader.this.namespace, KeyPath.parse(substring));
            if (value == null) {
                throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, substring));
            }
            return value;
        }
        
        private <T> T getExpressionObjectOfType(final String s, final Class<T> clazz) throws LoadException {
            final Object expressionObject = this.getExpressionObject(s);
            if (expressionObject == null) {
                return null;
            }
            if (clazz.isInstance(expressionObject)) {
                return (T)expressionObject;
            }
            throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, clazz.getName()));
        }
        
        private MethodHandler getControllerMethodHandle(String substring, final SupportedType... array) throws LoadException {
            if (substring.startsWith("#")) {
                substring = substring.substring("#".length());
                if (!substring.startsWith("#")) {
                    if (substring.length() == 0) {
                        throw FXMLLoader.this.constructLoadException("Missing controller method.");
                    }
                    if (FXMLLoader.this.controller == null) {
                        throw FXMLLoader.this.constructLoadException("No controller specified.");
                    }
                    for (final SupportedType supportedType : array) {
                        final Method method = FXMLLoader.this.controllerAccessor.getControllerMethods().get(supportedType).get(substring);
                        if (method != null) {
                            return new MethodHandler(FXMLLoader.this.controller, method, supportedType);
                        }
                    }
                    final Method method2 = FXMLLoader.this.controllerAccessor.getControllerMethods().get(SupportedType.PARAMETERLESS).get(substring);
                    if (method2 != null) {
                        return new MethodHandler(FXMLLoader.this.controller, method2, SupportedType.PARAMETERLESS);
                    }
                    return null;
                }
            }
            return null;
        }
        
        public void processEventHandlerAttributes() throws LoadException {
            if (this.eventHandlerAttributes.size() > 0 && !FXMLLoader.this.staticLoad) {
                for (final Attribute attribute : this.eventHandlerAttributes) {
                    final String value = attribute.value;
                    if (this.value instanceof ObservableList && attribute.name.equals("onChange")) {
                        this.processObservableListHandler(value);
                    }
                    else if (this.value instanceof ObservableMap && attribute.name.equals("onChange")) {
                        this.processObservableMapHandler(value);
                    }
                    else if (this.value instanceof ObservableSet && attribute.name.equals("onChange")) {
                        this.processObservableSetHandler(value);
                    }
                    else if (attribute.name.endsWith("Change")) {
                        this.processPropertyHandler(attribute.name, value);
                    }
                    else {
                        Object o = null;
                        final MethodHandler controllerMethodHandle = this.getControllerMethodHandle(value, SupportedType.EVENT);
                        if (controllerMethodHandle != null) {
                            o = new ControllerMethodEventHandler(controllerMethodHandle);
                        }
                        if (o == null) {
                            o = this.getExpressionObjectOfType(value, (Class<EventHandler<?>>)EventHandler.class);
                        }
                        if (o == null) {
                            if (value.length() == 0 || FXMLLoader.this.scriptEngine == null) {
                                throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, attribute.name, attribute.value));
                            }
                            o = new ScriptEventHandler(value, FXMLLoader.this.scriptEngine);
                        }
                        this.getValueAdapter().put(attribute.name, o);
                    }
                }
            }
        }
        
        private void processObservableListHandler(final String s) throws LoadException {
            final ObservableList list = (ObservableList)this.value;
            if (s.startsWith("#")) {
                final MethodHandler controllerMethodHandle = this.getControllerMethodHandle(s, SupportedType.LIST_CHANGE_LISTENER);
                if (controllerMethodHandle == null) {
                    throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                }
                list.addListener(new ObservableListChangeAdapter(controllerMethodHandle));
            }
            else if (s.startsWith("$")) {
                final Object expressionObject = this.getExpressionObject(s);
                if (expressionObject instanceof ListChangeListener) {
                    list.addListener((ListChangeListener)expressionObject);
                }
                else {
                    if (!(expressionObject instanceof InvalidationListener)) {
                        throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                    }
                    list.addListener((InvalidationListener)expressionObject);
                }
            }
        }
        
        private void processObservableMapHandler(final String s) throws LoadException {
            final ObservableMap observableMap = (ObservableMap)this.value;
            if (s.startsWith("#")) {
                final MethodHandler controllerMethodHandle = this.getControllerMethodHandle(s, SupportedType.MAP_CHANGE_LISTENER);
                if (controllerMethodHandle == null) {
                    throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                }
                observableMap.addListener(new ObservableMapChangeAdapter(controllerMethodHandle));
            }
            else if (s.startsWith("$")) {
                final Object expressionObject = this.getExpressionObject(s);
                if (expressionObject instanceof MapChangeListener) {
                    observableMap.addListener((MapChangeListener)expressionObject);
                }
                else {
                    if (!(expressionObject instanceof InvalidationListener)) {
                        throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                    }
                    observableMap.addListener((InvalidationListener)expressionObject);
                }
            }
        }
        
        private void processObservableSetHandler(final String s) throws LoadException {
            final ObservableSet set = (ObservableSet)this.value;
            if (s.startsWith("#")) {
                final MethodHandler controllerMethodHandle = this.getControllerMethodHandle(s, SupportedType.SET_CHANGE_LISTENER);
                if (controllerMethodHandle == null) {
                    throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                }
                set.addListener(new ObservableSetChangeAdapter(controllerMethodHandle));
            }
            else if (s.startsWith("$")) {
                final Object expressionObject = this.getExpressionObject(s);
                if (expressionObject instanceof SetChangeListener) {
                    set.addListener((SetChangeListener)expressionObject);
                }
                else {
                    if (!(expressionObject instanceof InvalidationListener)) {
                        throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s));
                    }
                    set.addListener((InvalidationListener)expressionObject);
                }
            }
        }
        
        private void processPropertyHandler(final String s, final String s2) throws LoadException {
            final int length = "on".length();
            final int endIndex = s.length() - "Change".length();
            if (length != endIndex) {
                final String s3 = invokedynamic(makeConcatWithConstants:(CLjava/lang/String;)Ljava/lang/String;, Character.toLowerCase(s.charAt(length)), s.substring(length + 1, endIndex));
                final ObservableValue<Object> propertyModel = this.getValueAdapter().getPropertyModel(s3);
                if (propertyModel == null) {
                    throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, this.value.getClass().getName(), s3));
                }
                if (s2.startsWith("#")) {
                    final MethodHandler controllerMethodHandle = this.getControllerMethodHandle(s2, SupportedType.PROPERTY_CHANGE_LISTENER, SupportedType.EVENT);
                    if (controllerMethodHandle == null) {
                        throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s2));
                    }
                    if (controllerMethodHandle.type == SupportedType.EVENT) {
                        propertyModel.addListener(new ChangeListener<Object>() {
                            @Override
                            public void changed(final ObservableValue<?> observableValue, final Object o, final Object o2) {
                                controllerMethodHandle.invoke(new Event(Element.this.value, null, Event.ANY));
                            }
                        });
                    }
                    else {
                        propertyModel.addListener(new PropertyChangeAdapter(controllerMethodHandle));
                    }
                }
                else if (s2.startsWith("$")) {
                    final Object expressionObject = this.getExpressionObject(s2);
                    if (expressionObject instanceof ChangeListener) {
                        propertyModel.addListener((ChangeListener<? super Object>)expressionObject);
                    }
                    else {
                        if (!(expressionObject instanceof InvalidationListener)) {
                            throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s2));
                        }
                        propertyModel.addListener((InvalidationListener)expressionObject);
                    }
                }
            }
        }
    }
    
    private abstract class ValueElement extends Element
    {
        public String fx_id;
        
        private ValueElement() {
            this.fx_id = null;
        }
        
        @Override
        public void processStartElement() throws IOException {
            super.processStartElement();
            this.updateValue(this.constructValue());
            if (this.value instanceof Builder) {
                this.processInstancePropertyAttributes();
            }
            else {
                this.processValue();
            }
        }
        
        @Override
        public void processEndElement() throws IOException {
            super.processEndElement();
            if (this.value instanceof Builder) {
                this.updateValue(((Builder)this.value).build());
                this.processValue();
            }
            else {
                this.processInstancePropertyAttributes();
            }
            this.processEventHandlerAttributes();
            if (this.staticPropertyAttributes.size() > 0) {
                final Iterator<Attribute> iterator = this.staticPropertyAttributes.iterator();
                while (iterator.hasNext()) {
                    this.processPropertyAttribute(iterator.next());
                }
            }
            if (this.staticPropertyElements.size() > 0) {
                for (final PropertyElement propertyElement : this.staticPropertyElements) {
                    BeanAdapter.put(this.value, propertyElement.sourceType, propertyElement.name, propertyElement.value);
                }
            }
            if (this.parent != null) {
                if (this.parent.isCollection()) {
                    this.parent.add(this.value);
                }
                else {
                    this.parent.set(this.value);
                }
            }
        }
        
        private Object getListValue(final Element element, final String s, Object coerce) {
            if (element.isTyped()) {
                final Type genericType = element.getValueAdapter().getGenericType(s);
                if (genericType != null) {
                    Type type = BeanAdapter.getGenericListItemType(genericType);
                    if (type instanceof ParameterizedType) {
                        type = ((ParameterizedType)type).getRawType();
                    }
                    coerce = BeanAdapter.coerce(coerce, (Class<?>)type);
                }
            }
            return coerce;
        }
        
        private void processValue() throws LoadException {
            if (this.parent == null) {
                FXMLLoader.this.root = this.value;
                final String namespaceURI = FXMLLoader.this.xmlStreamReader.getNamespaceContext().getNamespaceURI("fx");
                if (namespaceURI != null) {
                    final String substring = namespaceURI.substring(namespaceURI.lastIndexOf("/") + 1);
                    if (FXMLLoader.compareJFXVersions("1", substring) < 0) {
                        throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, substring));
                    }
                }
                final String namespaceURI2 = FXMLLoader.this.xmlStreamReader.getNamespaceContext().getNamespaceURI("");
                if (namespaceURI2 != null) {
                    final String substring2 = namespaceURI2.substring(namespaceURI2.lastIndexOf("/") + 1);
                    if (FXMLLoader.compareJFXVersions(FXMLLoader.JAVAFX_VERSION, substring2) < 0) {
                        Logging.getJavaFXLogger().warning(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, substring2, FXMLLoader.JAVAFX_VERSION));
                    }
                }
            }
            if (this.fx_id != null) {
                FXMLLoader.this.namespace.put(this.fx_id, this.value);
                final IDProperty idProperty = this.value.getClass().getAnnotation(IDProperty.class);
                if (idProperty != null) {
                    final Map<String, Object> properties = this.getProperties();
                    if (properties.get(idProperty.value()) == null) {
                        properties.put(idProperty.value(), this.fx_id);
                    }
                }
                FXMLLoader.this.injectFields(this.fx_id, this.value);
            }
        }
        
        @Override
        public void processCharacters() throws LoadException {
            final Class<?> class1 = this.value.getClass();
            final DefaultProperty defaultProperty = class1.getAnnotation(DefaultProperty.class);
            if (defaultProperty != null) {
                final String replaceAll = FXMLLoader.extraneousWhitespacePattern.matcher(FXMLLoader.this.xmlStreamReader.getText()).replaceAll(" ");
                final String value = defaultProperty.value();
                final BeanAdapter valueAdapter = this.getValueAdapter();
                if (valueAdapter.isReadOnly(value) && List.class.isAssignableFrom(valueAdapter.getType(value))) {
                    ((List)valueAdapter.get((Object)value)).add(this.getListValue(this, value, replaceAll));
                }
                else {
                    valueAdapter.put(value, replaceAll.trim());
                }
                return;
            }
            throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, class1.getName()));
        }
        
        @Override
        public void processAttribute(final String s, final String s2, final String s3) throws IOException {
            if (s != null && s.equals("fx")) {
                if (s2.equals("id")) {
                    if (s3.equals("null")) {
                        throw FXMLLoader.this.constructLoadException("Invalid identifier.");
                    }
                    for (int i = 0; i < s3.length(); ++i) {
                        if (!Character.isJavaIdentifierPart(s3.charAt(i))) {
                            throw FXMLLoader.this.constructLoadException("Invalid identifier.");
                        }
                    }
                    this.fx_id = s3;
                }
                else {
                    if (!s2.equals("controller")) {
                        throw FXMLLoader.this.constructLoadException("Invalid attribute.");
                    }
                    if (FXMLLoader.this.current.parent != null) {
                        throw FXMLLoader.this.constructLoadException("fx:controller can only be applied to root element.");
                    }
                    if (FXMLLoader.this.controller != null) {
                        throw FXMLLoader.this.constructLoadException("Controller value already specified.");
                    }
                    if (!FXMLLoader.this.staticLoad) {
                        Class<?> loadClass;
                        try {
                            loadClass = FXMLLoader.this.getClassLoader().loadClass(s3);
                        }
                        catch (ClassNotFoundException ex) {
                            throw FXMLLoader.this.constructLoadException(ex);
                        }
                        try {
                            if (FXMLLoader.this.controllerFactory == null) {
                                ReflectUtil.checkPackageAccess(loadClass);
                                FXMLLoader.this.setController(loadClass.newInstance());
                            }
                            else {
                                FXMLLoader.this.setController(FXMLLoader.this.controllerFactory.call(loadClass));
                            }
                        }
                        catch (InstantiationException ex2) {
                            throw FXMLLoader.this.constructLoadException(ex2);
                        }
                        catch (IllegalAccessException ex3) {
                            throw FXMLLoader.this.constructLoadException(ex3);
                        }
                    }
                }
            }
            else {
                super.processAttribute(s, s2, s3);
            }
        }
        
        public abstract Object constructValue() throws IOException;
    }
    
    private class InstanceDeclarationElement extends ValueElement
    {
        public Class<?> type;
        public String constant;
        public String factory;
        
        public InstanceDeclarationElement(final Class<?> type) throws LoadException {
            this.constant = null;
            this.factory = null;
            this.type = type;
        }
        
        @Override
        public void processAttribute(final String s, final String s2, final String factory) throws IOException {
            if (s != null && s.equals("fx")) {
                if (s2.equals("value")) {
                    this.value = factory;
                }
                else if (s2.equals("constant")) {
                    this.constant = factory;
                }
                else if (s2.equals("factory")) {
                    this.factory = factory;
                }
                else {
                    super.processAttribute(s, s2, factory);
                }
            }
            else {
                super.processAttribute(s, s2, factory);
            }
        }
        
        @Override
        public Object constructValue() throws IOException {
            Object o;
            if (this.value != null) {
                o = BeanAdapter.coerce(this.value, this.type);
            }
            else if (this.constant != null) {
                o = BeanAdapter.getConstantValue(this.type, this.constant);
            }
            else if (this.factory != null) {
                Method method;
                try {
                    method = MethodUtil.getMethod(this.type, this.factory, new Class[0]);
                }
                catch (NoSuchMethodException ex) {
                    throw FXMLLoader.this.constructLoadException(ex);
                }
                try {
                    o = MethodHelper.invoke(method, null, new Object[0]);
                }
                catch (IllegalAccessException ex2) {
                    throw FXMLLoader.this.constructLoadException(ex2);
                }
                catch (InvocationTargetException ex3) {
                    throw FXMLLoader.this.constructLoadException(ex3);
                }
            }
            else {
                o = ((FXMLLoader.this.builderFactory == null) ? null : FXMLLoader.this.builderFactory.getBuilder(this.type));
                if (o == null) {
                    o = FXMLLoader.DEFAULT_BUILDER_FACTORY.getBuilder(this.type);
                }
                if (o == null) {
                    try {
                        ReflectUtil.checkPackageAccess(this.type);
                        o = this.type.newInstance();
                    }
                    catch (InstantiationException ex4) {
                        throw FXMLLoader.this.constructLoadException(ex4);
                    }
                    catch (IllegalAccessException ex5) {
                        throw FXMLLoader.this.constructLoadException(ex5);
                    }
                }
            }
            return o;
        }
    }
    
    private class UnknownTypeElement extends ValueElement
    {
        @Override
        public void processEndElement() throws IOException {
        }
        
        @Override
        public Object constructValue() throws LoadException {
            return new UnknownValueMap();
        }
        
        @DefaultProperty("items")
        public class UnknownValueMap extends AbstractMap<String, Object>
        {
            private ArrayList<?> items;
            private HashMap<String, Object> values;
            
            public UnknownValueMap() {
                this.items = new ArrayList<Object>();
                this.values = new HashMap<String, Object>();
            }
            
            @Override
            public Object get(final Object key) {
                if (key == null) {
                    throw new NullPointerException();
                }
                return key.equals(this.getClass().getAnnotation(DefaultProperty.class).value()) ? this.items : this.values.get(key);
            }
            
            @Override
            public Object put(final String key, final Object value) {
                if (key == null) {
                    throw new NullPointerException();
                }
                if (key.equals(this.getClass().getAnnotation(DefaultProperty.class).value())) {
                    throw new IllegalArgumentException();
                }
                return this.values.put(key, value);
            }
            
            @Override
            public Set<Map.Entry<String, Object>> entrySet() {
                return Collections.emptySet();
            }
        }
    }
    
    private class IncludeElement extends ValueElement
    {
        public String source;
        public ResourceBundle resources;
        public Charset charset;
        
        private IncludeElement() {
            this.source = null;
            this.resources = FXMLLoader.this.resources;
            this.charset = FXMLLoader.this.charset;
        }
        
        @Override
        public void processAttribute(final String s, final String s2, final String charsetName) throws IOException {
            if (s == null) {
                if (s2.equals("source")) {
                    if (FXMLLoader.this.loadListener != null) {
                        FXMLLoader.this.loadListener.readInternalAttribute(s2, charsetName);
                    }
                    this.source = charsetName;
                }
                else if (s2.equals("resources")) {
                    if (FXMLLoader.this.loadListener != null) {
                        FXMLLoader.this.loadListener.readInternalAttribute(s2, charsetName);
                    }
                    this.resources = ResourceBundle.getBundle(charsetName, Locale.getDefault(), FXMLLoader.this.resources.getClass().getClassLoader());
                }
                else if (s2.equals("charset")) {
                    if (FXMLLoader.this.loadListener != null) {
                        FXMLLoader.this.loadListener.readInternalAttribute(s2, charsetName);
                    }
                    this.charset = Charset.forName(charsetName);
                }
                else {
                    super.processAttribute(s, s2, charsetName);
                }
            }
            else {
                super.processAttribute(s, s2, charsetName);
            }
        }
        
        @Override
        public Object constructValue() throws IOException {
            if (this.source == null) {
                throw FXMLLoader.this.constructLoadException("source is required.");
            }
            final ClassLoader classLoader = FXMLLoader.this.getClassLoader();
            URL resource;
            if (this.source.charAt(0) == '/') {
                resource = classLoader.getResource(this.source.substring(1));
                if (resource == null) {
                    throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.source));
                }
            }
            else {
                if (FXMLLoader.this.location == null) {
                    throw FXMLLoader.this.constructLoadException("Base location is undefined.");
                }
                resource = new URL(FXMLLoader.this.location, this.source);
            }
            final FXMLLoader fxmlLoader = new FXMLLoader(resource, this.resources, FXMLLoader.this.builderFactory, FXMLLoader.this.controllerFactory, this.charset, FXMLLoader.this.loaders);
            fxmlLoader.parentLoader = FXMLLoader.this;
            if (FXMLLoader.this.isCyclic(FXMLLoader.this, fxmlLoader)) {
                throw new IOException(String.format("Including \"%s\" in \"%s\" created cyclic reference.", fxmlLoader.location.toExternalForm(), FXMLLoader.this.location.toExternalForm()));
            }
            fxmlLoader.setClassLoader(classLoader);
            fxmlLoader.setStaticLoad(FXMLLoader.this.staticLoad);
            final Object access$2700 = fxmlLoader.loadImpl(FXMLLoader.this.callerClass);
            if (this.fx_id != null) {
                final String s = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.fx_id);
                final Object controller = fxmlLoader.getController();
                FXMLLoader.this.namespace.put(s, controller);
                FXMLLoader.this.injectFields(s, controller);
            }
            return access$2700;
        }
    }
    
    private class ReferenceElement extends ValueElement
    {
        public String source;
        
        private ReferenceElement() {
            this.source = null;
        }
        
        @Override
        public void processAttribute(final String s, final String s2, final String source) throws IOException {
            if (s == null) {
                if (s2.equals("source")) {
                    if (FXMLLoader.this.loadListener != null) {
                        FXMLLoader.this.loadListener.readInternalAttribute(s2, source);
                    }
                    this.source = source;
                }
                else {
                    super.processAttribute(s, s2, source);
                }
            }
            else {
                super.processAttribute(s, s2, source);
            }
        }
        
        @Override
        public Object constructValue() throws LoadException {
            if (this.source == null) {
                throw FXMLLoader.this.constructLoadException("source is required.");
            }
            final KeyPath parse = KeyPath.parse(this.source);
            if (!Expression.isDefined(FXMLLoader.this.namespace, parse)) {
                throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.source));
            }
            return Expression.get(FXMLLoader.this.namespace, parse);
        }
    }
    
    private class CopyElement extends ValueElement
    {
        public String source;
        
        private CopyElement() {
            this.source = null;
        }
        
        @Override
        public void processAttribute(final String s, final String s2, final String source) throws IOException {
            if (s == null) {
                if (s2.equals("source")) {
                    if (FXMLLoader.this.loadListener != null) {
                        FXMLLoader.this.loadListener.readInternalAttribute(s2, source);
                    }
                    this.source = source;
                }
                else {
                    super.processAttribute(s, s2, source);
                }
            }
            else {
                super.processAttribute(s, s2, source);
            }
        }
        
        @Override
        public Object constructValue() throws LoadException {
            if (this.source == null) {
                throw FXMLLoader.this.constructLoadException("source is required.");
            }
            final KeyPath parse = KeyPath.parse(this.source);
            if (!Expression.isDefined(FXMLLoader.this.namespace, parse)) {
                throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.source));
            }
            final Object value = Expression.get(FXMLLoader.this.namespace, parse);
            final Class<?> class1 = value.getClass();
            Constructor<?> constructor = null;
            try {
                constructor = ConstructorUtil.getConstructor(class1, new Class[] { class1 });
            }
            catch (NoSuchMethodException ex4) {}
            if (constructor != null) {
                try {
                    ReflectUtil.checkPackageAccess(class1);
                    return constructor.newInstance(value);
                }
                catch (InstantiationException ex) {
                    throw FXMLLoader.this.constructLoadException(ex);
                }
                catch (IllegalAccessException ex2) {
                    throw FXMLLoader.this.constructLoadException(ex2);
                }
                catch (InvocationTargetException ex3) {
                    throw FXMLLoader.this.constructLoadException(ex3);
                }
                throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;)Ljava/lang/String;, value));
            }
            throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/Object;)Ljava/lang/String;, value));
        }
    }
    
    private class RootElement extends ValueElement
    {
        public String type;
        
        private RootElement() {
            this.type = null;
        }
        
        @Override
        public void processAttribute(final String s, final String s2, final String type) throws IOException {
            if (s == null) {
                if (s2.equals("type")) {
                    if (FXMLLoader.this.loadListener != null) {
                        FXMLLoader.this.loadListener.readInternalAttribute(s2, type);
                    }
                    this.type = type;
                }
                else {
                    super.processAttribute(s, s2, type);
                }
            }
            else {
                super.processAttribute(s, s2, type);
            }
        }
        
        @Override
        public Object constructValue() throws LoadException {
            if (this.type == null) {
                throw FXMLLoader.this.constructLoadException("type is required.");
            }
            final Class access$400 = FXMLLoader.this.getType(this.type);
            if (access$400 == null) {
                throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.type));
            }
            Object o;
            if (FXMLLoader.this.root == null) {
                if (!FXMLLoader.this.staticLoad) {
                    throw FXMLLoader.this.constructLoadException("Root hasn't been set. Use method setRoot() before load.");
                }
                o = ((FXMLLoader.this.builderFactory == null) ? null : FXMLLoader.this.builderFactory.getBuilder(access$400));
                if (o == null) {
                    o = FXMLLoader.DEFAULT_BUILDER_FACTORY.getBuilder(access$400);
                }
                if (o == null) {
                    try {
                        ReflectUtil.checkPackageAccess(access$400);
                        o = access$400.newInstance();
                    }
                    catch (InstantiationException ex) {
                        throw FXMLLoader.this.constructLoadException(ex);
                    }
                    catch (IllegalAccessException ex2) {
                        throw FXMLLoader.this.constructLoadException(ex2);
                    }
                }
                FXMLLoader.this.root = o;
            }
            else {
                if (!access$400.isAssignableFrom(FXMLLoader.this.root.getClass())) {
                    throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, access$400.getName()));
                }
                o = FXMLLoader.this.root;
            }
            return o;
        }
    }
    
    private class PropertyElement extends Element
    {
        public final String name;
        public final Class<?> sourceType;
        public final boolean readOnly;
        
        public PropertyElement(final String name, final Class<?> sourceType) throws LoadException {
            if (this.parent == null) {
                throw FXMLLoader.this.constructLoadException("Invalid root element.");
            }
            if (this.parent.value == null) {
                throw FXMLLoader.this.constructLoadException("Parent element does not support property elements.");
            }
            this.name = name;
            if ((this.sourceType = sourceType) == null) {
                if (name.startsWith("on")) {
                    throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, name));
                }
                final Map<String, Object> properties = this.parent.getProperties();
                if (this.parent.isTyped()) {
                    this.readOnly = this.parent.getValueAdapter().isReadOnly(name);
                }
                else {
                    this.readOnly = properties.containsKey(name);
                }
                if (this.readOnly) {
                    final Object value = properties.get(name);
                    if (value == null) {
                        throw FXMLLoader.this.constructLoadException("Invalid property.");
                    }
                    this.updateValue(value);
                }
            }
            else {
                this.readOnly = false;
            }
        }
        
        @Override
        public boolean isCollection() {
            return this.readOnly && super.isCollection();
        }
        
        @Override
        public void add(Object coerce) throws LoadException {
            if (this.parent.isTyped()) {
                coerce = BeanAdapter.coerce(coerce, BeanAdapter.getListItemType(this.parent.getValueAdapter().getGenericType(this.name)));
            }
            super.add(coerce);
        }
        
        @Override
        public void set(final Object o) throws LoadException {
            this.updateValue(o);
            if (this.sourceType == null) {
                this.parent.getProperties().put(this.name, o);
            }
            else if (this.parent.value instanceof Builder) {
                this.parent.staticPropertyElements.add(this);
            }
            else {
                BeanAdapter.put(this.parent.value, this.sourceType, this.name, o);
            }
        }
        
        @Override
        public void processAttribute(final String s, final String s2, final String s3) throws IOException {
            if (!this.readOnly) {
                throw FXMLLoader.this.constructLoadException("Attributes are not supported for writable property elements.");
            }
            super.processAttribute(s, s2, s3);
        }
        
        @Override
        public void processEndElement() throws IOException {
            super.processEndElement();
            if (this.readOnly) {
                this.processInstancePropertyAttributes();
                this.processEventHandlerAttributes();
            }
        }
        
        @Override
        public void processCharacters() throws IOException {
            final String trim = FXMLLoader.extraneousWhitespacePattern.matcher(FXMLLoader.this.xmlStreamReader.getText()).replaceAll(" ").trim();
            if (this.readOnly) {
                if (this.isCollection()) {
                    this.add(trim);
                }
                else {
                    super.processCharacters();
                }
            }
            else {
                this.set(trim);
            }
        }
    }
    
    private class UnknownStaticPropertyElement extends Element
    {
        public UnknownStaticPropertyElement() throws LoadException {
            if (this.parent == null) {
                throw FXMLLoader.this.constructLoadException("Invalid root element.");
            }
            if (this.parent.value == null) {
                throw FXMLLoader.this.constructLoadException("Parent element does not support property elements.");
            }
        }
        
        @Override
        public boolean isCollection() {
            return false;
        }
        
        @Override
        public void set(final Object o) {
            this.updateValue(o);
        }
        
        @Override
        public void processCharacters() throws IOException {
            this.updateValue(FXMLLoader.extraneousWhitespacePattern.matcher(FXMLLoader.this.xmlStreamReader.getText()).replaceAll(" ").trim());
        }
    }
    
    private class ScriptElement extends Element
    {
        public String source;
        public Charset charset;
        
        private ScriptElement() {
            this.source = null;
            this.charset = FXMLLoader.this.charset;
        }
        
        @Override
        public boolean isCollection() {
            return false;
        }
        
        @Override
        public void processStartElement() throws IOException {
            super.processStartElement();
            if (this.source != null && !FXMLLoader.this.staticLoad) {
                final int lastIndex = this.source.lastIndexOf(".");
                if (lastIndex == -1) {
                    throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.source));
                }
                final String substring = this.source.substring(lastIndex + 1);
                final ClassLoader classLoader = FXMLLoader.this.getClassLoader();
                ScriptEngine scriptEngine;
                if (FXMLLoader.this.scriptEngine != null && FXMLLoader.this.scriptEngine.getFactory().getExtensions().contains(substring)) {
                    scriptEngine = FXMLLoader.this.scriptEngine;
                }
                else {
                    final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
                    try {
                        Thread.currentThread().setContextClassLoader(classLoader);
                        scriptEngine = FXMLLoader.this.getScriptEngineManager().getEngineByExtension(substring);
                    }
                    finally {
                        Thread.currentThread().setContextClassLoader(contextClassLoader);
                    }
                }
                if (scriptEngine == null) {
                    throw FXMLLoader.this.constructLoadException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, substring));
                }
                try {
                    URL resource;
                    if (this.source.charAt(0) == '/') {
                        resource = classLoader.getResource(this.source.substring(1));
                    }
                    else {
                        if (FXMLLoader.this.location == null) {
                            throw FXMLLoader.this.constructLoadException("Base location is undefined.");
                        }
                        resource = new URL(FXMLLoader.this.location, this.source);
                    }
                    InputStreamReader inputStreamReader = null;
                    try {
                        inputStreamReader = new InputStreamReader(resource.openStream(), this.charset);
                        scriptEngine.eval(inputStreamReader);
                    }
                    catch (ScriptException ex) {
                        ex.printStackTrace();
                    }
                    finally {
                        if (inputStreamReader != null) {
                            inputStreamReader.close();
                        }
                    }
                }
                catch (IOException ex2) {
                    throw FXMLLoader.this.constructLoadException(ex2);
                }
            }
        }
        
        @Override
        public void processEndElement() throws IOException {
            super.processEndElement();
            if (this.value != null && !FXMLLoader.this.staticLoad) {
                try {
                    FXMLLoader.this.scriptEngine.eval((String)this.value);
                }
                catch (ScriptException ex) {
                    System.err.println(ex.getMessage());
                }
            }
        }
        
        @Override
        public void processCharacters() throws LoadException {
            if (this.source != null) {
                throw FXMLLoader.this.constructLoadException("Script source already specified.");
            }
            if (FXMLLoader.this.scriptEngine == null && !FXMLLoader.this.staticLoad) {
                throw FXMLLoader.this.constructLoadException("Page language not specified.");
            }
            this.updateValue(FXMLLoader.this.xmlStreamReader.getText());
        }
        
        @Override
        public void processAttribute(final String s, final String s2, final String s3) throws IOException {
            if (s == null && s2.equals("source")) {
                if (FXMLLoader.this.loadListener != null) {
                    FXMLLoader.this.loadListener.readInternalAttribute(s2, s3);
                }
                this.source = s3;
            }
            else {
                if (!s2.equals("charset")) {
                    throw FXMLLoader.this.constructLoadException((s == null) ? s2 : invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, s, s2));
                }
                if (FXMLLoader.this.loadListener != null) {
                    FXMLLoader.this.loadListener.readInternalAttribute(s2, s3);
                }
                this.charset = Charset.forName(s3);
            }
        }
    }
    
    private class DefineElement extends Element
    {
        @Override
        public boolean isCollection() {
            return true;
        }
        
        @Override
        public void add(final Object o) {
        }
        
        @Override
        public void processAttribute(final String s, final String s2, final String s3) throws LoadException {
            throw FXMLLoader.this.constructLoadException("Element does not support attributes.");
        }
    }
    
    private static class Attribute
    {
        public final String name;
        public final Class<?> sourceType;
        public final String value;
        
        public Attribute(final String name, final Class<?> sourceType, final String value) {
            this.name = name;
            this.sourceType = sourceType;
            this.value = value;
        }
    }
    
    private static class ControllerMethodEventHandler<T extends Event> implements EventHandler<T>
    {
        private final MethodHandler handler;
        
        public ControllerMethodEventHandler(final MethodHandler handler) {
            this.handler = handler;
        }
        
        @Override
        public void handle(final T t) {
            this.handler.invoke(t);
        }
    }
    
    private static class ScriptEventHandler implements EventHandler<Event>
    {
        public final String script;
        public final ScriptEngine scriptEngine;
        
        public ScriptEventHandler(final String script, final ScriptEngine scriptEngine) {
            this.script = script;
            this.scriptEngine = scriptEngine;
        }
        
        @Override
        public void handle(final Event event) {
            final Bindings bindings = this.scriptEngine.getBindings(100);
            final Bindings bindings2 = this.scriptEngine.createBindings();
            bindings2.put("event", (Object)event);
            bindings2.putAll(bindings);
            this.scriptEngine.setBindings(bindings2, 100);
            try {
                this.scriptEngine.eval(this.script);
            }
            catch (ScriptException cause) {
                throw new RuntimeException(cause);
            }
            this.scriptEngine.setBindings(bindings, 100);
        }
    }
    
    private static class ObservableListChangeAdapter implements ListChangeListener
    {
        private final MethodHandler handler;
        
        public ObservableListChangeAdapter(final MethodHandler handler) {
            this.handler = handler;
        }
        
        @Override
        public void onChanged(final Change change) {
            if (this.handler != null) {
                this.handler.invoke(change);
            }
        }
    }
    
    private static class ObservableMapChangeAdapter implements MapChangeListener
    {
        public final MethodHandler handler;
        
        public ObservableMapChangeAdapter(final MethodHandler handler) {
            this.handler = handler;
        }
        
        @Override
        public void onChanged(final Change change) {
            if (this.handler != null) {
                this.handler.invoke(change);
            }
        }
    }
    
    private static class ObservableSetChangeAdapter implements SetChangeListener
    {
        public final MethodHandler handler;
        
        public ObservableSetChangeAdapter(final MethodHandler handler) {
            this.handler = handler;
        }
        
        @Override
        public void onChanged(final Change change) {
            if (this.handler != null) {
                this.handler.invoke(change);
            }
        }
    }
    
    private static class PropertyChangeAdapter implements ChangeListener<Object>
    {
        public final MethodHandler handler;
        
        public PropertyChangeAdapter(final MethodHandler handler) {
            this.handler = handler;
        }
        
        @Override
        public void changed(final ObservableValue<?> observableValue, final Object o, final Object o2) {
            this.handler.invoke(observableValue, o, o2);
        }
    }
    
    private static class MethodHandler
    {
        private final Object controller;
        private final Method method;
        private final SupportedType type;
        
        private MethodHandler(final Object controller, final Method method, final SupportedType type) {
            this.method = method;
            this.controller = controller;
            this.type = type;
        }
        
        public void invoke(final Object... array) {
            try {
                if (this.type != SupportedType.PARAMETERLESS) {
                    MethodHelper.invoke(this.method, this.controller, array);
                }
                else {
                    MethodHelper.invoke(this.method, this.controller, new Object[0]);
                }
            }
            catch (InvocationTargetException cause) {
                throw new RuntimeException(cause);
            }
            catch (IllegalAccessException cause2) {
                throw new RuntimeException(cause2);
            }
        }
    }
    
    private enum SupportedType
    {
        PARAMETERLESS(0) {
            @Override
            protected boolean methodIsOfType(final Method method) {
                return method.getParameterTypes().length == 0;
            }
        }, 
        EVENT(1) {
            @Override
            protected boolean methodIsOfType(final Method method) {
                return method.getParameterTypes().length == 1 && Event.class.isAssignableFrom(method.getParameterTypes()[0]);
            }
        }, 
        LIST_CHANGE_LISTENER(2) {
            @Override
            protected boolean methodIsOfType(final Method method) {
                return method.getParameterTypes().length == 1 && method.getParameterTypes()[0].equals(ListChangeListener.Change.class);
            }
        }, 
        MAP_CHANGE_LISTENER(3) {
            @Override
            protected boolean methodIsOfType(final Method method) {
                return method.getParameterTypes().length == 1 && method.getParameterTypes()[0].equals(MapChangeListener.Change.class);
            }
        }, 
        SET_CHANGE_LISTENER(4) {
            @Override
            protected boolean methodIsOfType(final Method method) {
                return method.getParameterTypes().length == 1 && method.getParameterTypes()[0].equals(SetChangeListener.Change.class);
            }
        }, 
        PROPERTY_CHANGE_LISTENER(5) {
            @Override
            protected boolean methodIsOfType(final Method method) {
                return method.getParameterTypes().length == 3 && ObservableValue.class.isAssignableFrom(method.getParameterTypes()[0]) && method.getParameterTypes()[1].equals(method.getParameterTypes()[2]);
            }
        };
        
        protected abstract boolean methodIsOfType(final Method p0);
    }
    
    private static final class ControllerAccessor
    {
        private static final int PUBLIC = 1;
        private static final int PROTECTED = 2;
        private static final int PACKAGE = 4;
        private static final int PRIVATE = 8;
        private static final int INITIAL_CLASS_ACCESS = 15;
        private static final int INITIAL_MEMBER_ACCESS = 15;
        private static final int METHODS = 0;
        private static final int FIELDS = 1;
        private Object controller;
        private ClassLoader callerClassLoader;
        private Map<String, List<Field>> controllerFields;
        private Map<SupportedType, Map<String, Method>> controllerMethods;
        
        void setController(final Object controller) {
            if (this.controller != controller) {
                this.controller = controller;
                this.reset();
            }
        }
        
        void setCallerClass(final Class<?> clazz) {
            final ClassLoader callerClassLoader = (clazz != null) ? clazz.getClassLoader() : null;
            if (this.callerClassLoader != callerClassLoader) {
                this.callerClassLoader = callerClassLoader;
                this.reset();
            }
        }
        
        void reset() {
            this.controllerFields = null;
            this.controllerMethods = null;
        }
        
        Map<String, List<Field>> getControllerFields() {
            if (this.controllerFields == null) {
                this.controllerFields = new HashMap<String, List<Field>>();
                if (this.callerClassLoader == null) {
                    checkClassLoaderPermission();
                }
                this.addAccessibleMembers(this.controller.getClass(), 15, 15, 1);
            }
            return this.controllerFields;
        }
        
        Map<SupportedType, Map<String, Method>> getControllerMethods() {
            if (this.controllerMethods == null) {
                this.controllerMethods = new EnumMap<SupportedType, Map<String, Method>>(SupportedType.class);
                final SupportedType[] values = SupportedType.values();
                for (int length = values.length, i = 0; i < length; ++i) {
                    this.controllerMethods.put(values[i], new HashMap<String, Method>());
                }
                if (this.callerClassLoader == null) {
                    checkClassLoaderPermission();
                }
                this.addAccessibleMembers(this.controller.getClass(), 15, 15, 0);
            }
            return this.controllerMethods;
        }
        
        private void addAccessibleMembers(final Class<?> clazz, final int n, final int n2, final int n3) {
            if (clazz == Object.class) {
                return;
            }
            int n4 = n;
            int n5 = n2;
            if (this.callerClassLoader != null && clazz.getClassLoader() != this.callerClassLoader) {
                n4 &= 0x1;
                n5 &= 0x1;
            }
            if ((getAccess(clazz.getModifiers()) & n4) == 0x0) {
                return;
            }
            ReflectUtil.checkPackageAccess(clazz);
            this.addAccessibleMembers(clazz.getSuperclass(), n4, n5, n3);
            AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction<Void>() {
                @Override
                public Void run() {
                    if (n3 == 1) {
                        ControllerAccessor.this.addAccessibleFields(clazz, n5);
                    }
                    else {
                        ControllerAccessor.this.addAccessibleMethods(clazz, n5);
                    }
                    return null;
                }
            });
        }
        
        private void addAccessibleFields(final Class<?> clazz, final int n) {
            final boolean public1 = Modifier.isPublic(clazz.getModifiers());
            final Field[] declaredFields = clazz.getDeclaredFields();
            for (int i = 0; i < declaredFields.length; ++i) {
                final Field field = declaredFields[i];
                final int modifiers = field.getModifiers();
                if ((modifiers & 0x18) == 0x0) {
                    if ((getAccess(modifiers) & n) != 0x0) {
                        if (!public1 || !Modifier.isPublic(modifiers)) {
                            if (field.getAnnotation(FXML.class) == null) {
                                continue;
                            }
                            field.setAccessible(true);
                        }
                        List<Field> list = this.controllerFields.get(field.getName());
                        if (list == null) {
                            list = new ArrayList<Field>(1);
                            this.controllerFields.put(field.getName(), list);
                        }
                        list.add(field);
                    }
                }
            }
        }
        
        private void addAccessibleMethods(final Class<?> clazz, final int n) {
            final boolean public1 = Modifier.isPublic(clazz.getModifiers());
            final Method[] declaredMethods = clazz.getDeclaredMethods();
            for (int i = 0; i < declaredMethods.length; ++i) {
                final Method method = declaredMethods[i];
                final int modifiers = method.getModifiers();
                if ((modifiers & 0x108) == 0x0) {
                    if ((getAccess(modifiers) & n) != 0x0) {
                        if (!public1 || !Modifier.isPublic(modifiers)) {
                            if (method.getAnnotation(FXML.class) == null) {
                                continue;
                            }
                            method.setAccessible(true);
                        }
                        final String name = method.getName();
                        final SupportedType access$4100;
                        if ((access$4100 = toSupportedType(method)) != null) {
                            this.controllerMethods.get(access$4100).put(name, method);
                        }
                    }
                }
            }
        }
        
        private static int getAccess(final int n) {
            switch (n & 0x7) {
                case 1: {
                    return 1;
                }
                case 4: {
                    return 2;
                }
                case 2: {
                    return 8;
                }
                default: {
                    return 4;
                }
            }
        }
    }
}
