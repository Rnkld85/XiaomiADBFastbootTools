// 
// Decompiled by Procyon v0.5.36
// 

package javafx.fxml;

public interface LoadListener
{
    void readImportProcessingInstruction(final String p0);
    
    void readLanguageProcessingInstruction(final String p0);
    
    void readComment(final String p0);
    
    void beginInstanceDeclarationElement(final Class<?> p0);
    
    void beginUnknownTypeElement(final String p0);
    
    void beginIncludeElement();
    
    void beginReferenceElement();
    
    void beginCopyElement();
    
    void beginRootElement();
    
    void beginPropertyElement(final String p0, final Class<?> p1);
    
    void beginUnknownStaticPropertyElement(final String p0);
    
    void beginScriptElement();
    
    void beginDefineElement();
    
    void readInternalAttribute(final String p0, final String p1);
    
    void readPropertyAttribute(final String p0, final Class<?> p1, final String p2);
    
    void readUnknownStaticPropertyAttribute(final String p0, final String p1);
    
    void readEventHandlerAttribute(final String p0, final String p1);
    
    void endElement(final Object p0);
}
