// 
// Decompiled by Procyon v0.5.36
// 

package javafx.fxml;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableMap;
import com.sun.javafx.logging.PlatformLogger;
import com.sun.javafx.fxml.BeanAdapter;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.lang.reflect.InvocationTargetException;
import javafx.scene.Node;
import java.util.AbstractMap;
import java.lang.reflect.Modifier;
import com.sun.javafx.reflect.MethodUtil;
import java.util.HashMap;
import java.util.Map;
import java.lang.reflect.Method;
import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import javafx.beans.NamedArg;
import com.sun.javafx.reflect.ConstructorUtil;
import com.sun.javafx.fxml.builder.ProxyBuilder;
import com.sun.javafx.fxml.builder.TriangleMeshBuilder;
import javafx.scene.shape.TriangleMesh;
import com.sun.javafx.fxml.builder.URLBuilder;
import java.net.URL;
import com.sun.javafx.fxml.builder.JavaFXImageBuilder;
import javafx.scene.image.Image;
import com.sun.javafx.fxml.builder.JavaFXFontBuilder;
import javafx.scene.text.Font;
import com.sun.javafx.fxml.builder.JavaFXSceneBuilder;
import javafx.scene.Scene;
import javafx.util.Builder;
import javafx.application.Platform;
import javafx.application.ConditionalFeature;
import javafx.util.BuilderFactory;

public final class JavaFXBuilderFactory implements BuilderFactory
{
    private final ClassLoader classLoader;
    private final boolean webSupported;
    private static final String WEBVIEW_NAME = "javafx.scene.web.WebView";
    private static final String WEBVIEW_BUILDER_NAME = "com.sun.javafx.fxml.builder.web.WebViewBuilder";
    
    public JavaFXBuilderFactory() {
        this(FXMLLoader.getDefaultClassLoader());
    }
    
    public JavaFXBuilderFactory(final ClassLoader classLoader) {
        if (classLoader == null) {
            throw new NullPointerException();
        }
        this.classLoader = classLoader;
        this.webSupported = Platform.isSupported(ConditionalFeature.WEB);
    }
    
    @Override
    public Builder<?> getBuilder(final Class<?> clazz) {
        if (clazz == null) {
            throw new NullPointerException();
        }
        Object builder;
        if (clazz == Scene.class) {
            builder = new JavaFXSceneBuilder();
        }
        else if (clazz == Font.class) {
            builder = new JavaFXFontBuilder();
        }
        else if (clazz == Image.class) {
            builder = new JavaFXImageBuilder();
        }
        else if (clazz == URL.class) {
            builder = new URLBuilder(this.classLoader);
        }
        else if (clazz == TriangleMesh.class) {
            builder = new TriangleMeshBuilder();
        }
        else if (this.webSupported && clazz.getName().equals("javafx.scene.web.WebView")) {
            try {
                builder = new ObjectBuilderWrapper(this.classLoader.loadClass("com.sun.javafx.fxml.builder.web.WebViewBuilder")).createBuilder();
            }
            catch (Exception ex) {
                builder = null;
            }
        }
        else if (this.scanForConstructorAnnotations(clazz)) {
            builder = new ProxyBuilder(clazz);
        }
        else {
            builder = null;
        }
        return (Builder<?>)builder;
    }
    
    private boolean scanForConstructorAnnotations(final Class<?> clazz) {
        for (final Constructor<?> constructor : ConstructorUtil.getConstructors(clazz)) {
            final Annotation[][] parameterAnnotations = constructor.getParameterAnnotations();
            for (int j = 0; j < constructor.getParameterTypes().length; ++j) {
                final Annotation[] array = parameterAnnotations[j];
                for (int length2 = array.length, k = 0; k < length2; ++k) {
                    if (array[k] instanceof NamedArg) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    private static final class ObjectBuilderWrapper
    {
        private static final Object[] NO_ARGS;
        private static final Class<?>[] NO_SIG;
        private final Class<?> builderClass;
        private final Method createMethod;
        private final Method buildMethod;
        private final Map<String, Method> methods;
        private final Map<String, Method> getters;
        private final Map<String, Method> setters;
        
        ObjectBuilderWrapper() {
            this.methods = new HashMap<String, Method>();
            this.getters = new HashMap<String, Method>();
            this.setters = new HashMap<String, Method>();
            this.builderClass = null;
            this.createMethod = null;
            this.buildMethod = null;
        }
        
        ObjectBuilderWrapper(final Class<?> builderClass) throws NoSuchMethodException, InstantiationException, IllegalAccessException {
            this.methods = new HashMap<String, Method>();
            this.getters = new HashMap<String, Method>();
            this.setters = new HashMap<String, Method>();
            this.builderClass = builderClass;
            this.createMethod = MethodUtil.getMethod(builderClass, "create", ObjectBuilderWrapper.NO_SIG);
            this.buildMethod = MethodUtil.getMethod(builderClass, "build", ObjectBuilderWrapper.NO_SIG);
            assert Modifier.isStatic(this.createMethod.getModifiers());
            assert !Modifier.isStatic(this.buildMethod.getModifiers());
        }
        
        Builder<Object> createBuilder() {
            return new ObjectBuilder();
        }
        
        private Method findMethod(String anObject) {
            if (anObject.length() > 1 && Character.isUpperCase(anObject.charAt(1))) {
                anObject = invokedynamic(makeConcatWithConstants:(CLjava/lang/String;)Ljava/lang/String;, Character.toUpperCase(anObject.charAt(0)), anObject.substring(1));
            }
            for (final Method method : MethodUtil.getMethods(this.builderClass)) {
                if (method.getName().equals(anObject)) {
                    return method;
                }
            }
            throw new IllegalArgumentException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, anObject, this.builderClass.getName()));
        }
        
        public Class<?> getTargetClass() {
            return this.buildMethod.getReturnType();
        }
        
        static {
            NO_ARGS = new Object[0];
            NO_SIG = new Class[0];
        }
        
        final class ObjectBuilder extends AbstractMap<String, Object> implements Builder<Object>
        {
            private final Map<String, Object> containers;
            private Object builder;
            private Map<Object, Object> properties;
            
            private ObjectBuilder() {
                this.containers = new HashMap<String, Object>();
                this.builder = null;
                try {
                    this.builder = ObjectBuilderWrapper.this.createMethod.invoke(null, ObjectBuilderWrapper.NO_ARGS);
                }
                catch (Exception cause) {
                    throw new RuntimeException(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, ObjectBuilderWrapper.this.builderClass.getName()), (Throwable)cause);
                }
            }
            
            @Override
            public Object build() {
                for (final Map.Entry<String, V> entry : this.containers.entrySet()) {
                    this.put(entry.getKey(), entry.getValue());
                }
                Object o;
                try {
                    o = ObjectBuilderWrapper.this.buildMethod.invoke(this.builder, ObjectBuilderWrapper.NO_ARGS);
                    if (this.properties != null && o instanceof Node) {
                        ((Node)o).getProperties().putAll(this.properties);
                    }
                }
                catch (InvocationTargetException cause) {
                    throw new RuntimeException(cause);
                }
                catch (IllegalAccessException cause2) {
                    throw new RuntimeException(cause2);
                }
                finally {
                    this.builder = null;
                }
                return o;
            }
            
            @Override
            public int size() {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public boolean isEmpty() {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public boolean containsKey(final Object o) {
                return this.getTemporaryContainer(o.toString()) != null;
            }
            
            @Override
            public boolean containsValue(final Object o) {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public Object get(final Object o) {
                return this.getTemporaryContainer(o.toString());
            }
            
            @Override
            public Object put(final String anObject, Object o) {
                if (Node.class.isAssignableFrom(ObjectBuilderWrapper.this.getTargetClass()) && "properties".equals(anObject)) {
                    this.properties = (Map<Object, Object>)o;
                    return null;
                }
                try {
                    Method access$500 = ObjectBuilderWrapper.this.methods.get(anObject);
                    if (access$500 == null) {
                        access$500 = ObjectBuilderWrapper.this.findMethod(anObject);
                        ObjectBuilderWrapper.this.methods.put(anObject, access$500);
                    }
                    try {
                        final Class<?> clazz = access$500.getParameterTypes()[0];
                        if (clazz.isArray()) {
                            List<String> list;
                            if (o instanceof List) {
                                list = (List<String>)o;
                            }
                            else {
                                list = Arrays.asList(o.toString().split(","));
                            }
                            final Class componentType = clazz.getComponentType();
                            final Object instance = Array.newInstance(componentType, list.size());
                            for (int i = 0; i < list.size(); ++i) {
                                Array.set(instance, i, BeanAdapter.coerce((Object)list.get(i), (Class<?>)componentType));
                            }
                            o = instance;
                        }
                        access$500.invoke(this.builder, BeanAdapter.coerce(o, clazz));
                    }
                    catch (Exception ex) {
                        PlatformLogger.getLogger(ObjectBuilderWrapper.class.getName()).warning(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, access$500.getName()), (Throwable)ex);
                    }
                    return null;
                }
                catch (Exception ex2) {
                    PlatformLogger.getLogger(ObjectBuilderWrapper.class.getName()).warning(invokedynamic(makeConcatWithConstants:(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/String;, ObjectBuilderWrapper.this.getTargetClass(), anObject, ObjectBuilderWrapper.this.builderClass), (Throwable)ex2);
                    return null;
                }
            }
            
            Object getReadOnlyProperty(final String s) {
                if (ObjectBuilderWrapper.this.setters.get(s) != null) {
                    return null;
                }
                Method method = ObjectBuilderWrapper.this.getters.get(s);
                if (method == null) {
                    Method method2 = null;
                    final Class<?> targetClass = ObjectBuilderWrapper.this.getTargetClass();
                    final String s2 = invokedynamic(makeConcatWithConstants:(CLjava/lang/String;)Ljava/lang/String;, Character.toUpperCase(s.charAt(0)), s.substring(1));
                    try {
                        method = MethodUtil.getMethod(targetClass, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s2), (Class<?>[])ObjectBuilderWrapper.NO_SIG);
                        method2 = MethodUtil.getMethod(targetClass, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s2), (Class<?>[])new Class[] { method.getReturnType() });
                    }
                    catch (Exception ex) {}
                    if (method != null) {
                        ObjectBuilderWrapper.this.getters.put(s, method);
                        ObjectBuilderWrapper.this.setters.put(s, method2);
                    }
                    if (method2 != null) {
                        return null;
                    }
                }
                Class<?> returnType;
                if (method == null) {
                    final Method access$500 = ObjectBuilderWrapper.this.findMethod(s);
                    if (access$500 == null) {
                        return null;
                    }
                    returnType = access$500.getParameterTypes()[0];
                    if (returnType.isArray()) {
                        returnType = List.class;
                    }
                }
                else {
                    returnType = method.getReturnType();
                }
                if (ObservableMap.class.isAssignableFrom(returnType)) {
                    return FXCollections.observableMap(new HashMap<Object, Object>());
                }
                if (Map.class.isAssignableFrom(returnType)) {
                    return new HashMap();
                }
                if (ObservableList.class.isAssignableFrom(returnType)) {
                    return FXCollections.observableArrayList();
                }
                if (List.class.isAssignableFrom(returnType)) {
                    return new ArrayList();
                }
                if (Set.class.isAssignableFrom(returnType)) {
                    return new HashSet();
                }
                return null;
            }
            
            public Object getTemporaryContainer(final String s) {
                Object o = this.containers.get(s);
                if (o == null) {
                    o = this.getReadOnlyProperty(s);
                    if (o != null) {
                        this.containers.put(s, o);
                    }
                }
                return o;
            }
            
            @Override
            public Object remove(final Object o) {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public void putAll(final Map<? extends String, ?> map) {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public void clear() {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public Set<String> keySet() {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public Collection<Object> values() {
                throw new UnsupportedOperationException();
            }
            
            @Override
            public Set<Map.Entry<String, Object>> entrySet() {
                throw new UnsupportedOperationException();
            }
        }
    }
}
