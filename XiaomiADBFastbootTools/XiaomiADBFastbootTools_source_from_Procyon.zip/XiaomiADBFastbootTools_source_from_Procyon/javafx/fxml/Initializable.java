// 
// Decompiled by Procyon v0.5.36
// 

package javafx.fxml;

import java.util.ResourceBundle;
import java.net.URL;

public interface Initializable
{
    void initialize(final URL p0, final ResourceBundle p1);
}
