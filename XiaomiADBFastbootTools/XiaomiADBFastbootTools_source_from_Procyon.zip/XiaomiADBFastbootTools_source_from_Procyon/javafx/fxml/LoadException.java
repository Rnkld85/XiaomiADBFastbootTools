// 
// Decompiled by Procyon v0.5.36
// 

package javafx.fxml;

import java.io.IOException;

public class LoadException extends IOException
{
    private static final long serialVersionUID = 0L;
    
    public LoadException() {
    }
    
    public LoadException(final String message) {
        super(message);
    }
    
    public LoadException(final Throwable cause) {
        super(cause);
    }
    
    public LoadException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
