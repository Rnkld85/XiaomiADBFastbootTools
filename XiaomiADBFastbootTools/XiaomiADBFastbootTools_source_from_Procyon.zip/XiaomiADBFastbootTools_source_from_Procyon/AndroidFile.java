import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import kotlin.Metadata;

// 
// Decompiled by Procyon v0.5.36
// 

@Metadata(mv = { 1, 4, 0 }, bv = { 1, 0, 3 }, k = 1, d1 = { "\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0012\n\u0002\u0010\u0007\n\u0000\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0005¢\u0006\u0002\u0010\tJ\u0006\u0010\u0012\u001a\u00020\u0005J\u0010\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u001aH\u0002R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u001a\u0010\b\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u000f\"\u0004\b\u0017\u0010\u0011¨\u0006\u001b" }, d2 = { "LAndroidFile;", "", "dir", "", "name", "", "size", "", "time", "(ZLjava/lang/String;ILjava/lang/String;)V", "getDir", "()Z", "setDir", "(Z)V", "getName", "()Ljava/lang/String;", "setName", "(Ljava/lang/String;)V", "getSize", "()I", "setSize", "(I)V", "getTime", "setTime", "shorten", "num", "", "XiaomiADBFastbootTools" })
public final class AndroidFile
{
    private boolean dir;
    @NotNull
    private String name;
    private int size;
    @NotNull
    private String time;
    
    private final String shorten(final float num) {
        final String str = String.valueOf(num);
        if (StringsKt__StringsKt.substringAfter$default(str, '.', null, 2, null).length() > 2) {
            final String s = str;
            final int beginIndex = 0;
            final int endIndex = StringsKt__StringsKt.indexOf$default(str, '.', 0, false, 6, null) + 3;
            final String s2 = s;
            if (s2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
            }
            final String substring = s2.substring(beginIndex, endIndex);
            Intrinsics.checkNotNullExpressionValue(substring, "(this as java.lang.Strin\u2026ing(startIndex, endIndex)");
            return substring;
        }
        else {
            if (StringsKt__StringsJVMKt.endsWith$default(str, ".0", false, 2, null)) {
                return StringsKt__StringsKt.substringBefore$default(str, '.', null, 2, null);
            }
            return str;
        }
    }
    
    @NotNull
    public final String getSize() {
        String s;
        if (this.size > 1024) {
            float siz = this.size / 1024.0f;
            if (siz > 1024.0f) {
                siz /= 1024.0f;
                if (siz > 1024.0f) {
                    siz /= 1024.0f;
                    s = this.shorten(siz) + " GB";
                }
                else {
                    s = this.shorten(siz) + " MB";
                }
            }
            else {
                s = this.shorten(siz) + " KB";
            }
        }
        else {
            s = this.size + " B";
        }
        return s;
    }
    
    public final boolean getDir() {
        return this.dir;
    }
    
    public final void setDir(final boolean <set-?>) {
        this.dir = <set-?>;
    }
    
    @NotNull
    public final String getName() {
        return this.name;
    }
    
    public final void setName(@NotNull final String <set-?>) {
        Intrinsics.checkNotNullParameter(<set-?>, "<set-?>");
        this.name = <set-?>;
    }
    
    public final int getSize() {
        return this.size;
    }
    
    public final void setSize(final int <set-?>) {
        this.size = <set-?>;
    }
    
    @NotNull
    public final String getTime() {
        return this.time;
    }
    
    public final void setTime(@NotNull final String <set-?>) {
        Intrinsics.checkNotNullParameter(<set-?>, "<set-?>");
        this.time = <set-?>;
    }
    
    public AndroidFile(final boolean dir, @NotNull final String name, final int size, @NotNull final String time) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(time, "time");
        this.dir = dir;
        this.name = name;
        this.size = size;
        this.time = time;
    }
}
