// 
// Decompiled by Procyon v0.5.36
// 

package org.intellij.lang.annotations;

import java.lang.annotation.Annotation;

public class JdkConstants
{
    public @interface TabLayoutPolicy {
    }
    
    public @interface TabPlacement {
    }
    
    public @interface TitledBorderTitlePosition {
    }
    
    public @interface TitledBorderJustification {
    }
    
    public @interface FontStyle {
    }
    
    public @interface TreeSelectionMode {
    }
    
    public @interface ListSelectionMode {
    }
    
    public @interface BoxLayoutAxis {
    }
    
    public @interface PatternFlags {
    }
    
    public @interface CalendarMonth {
    }
    
    public @interface AdjustableOrientation {
    }
    
    public @interface InputEventMask {
    }
    
    public @interface CursorType {
    }
    
    public @interface FlowLayoutAlignment {
    }
    
    public @interface HorizontalAlignment {
    }
}
