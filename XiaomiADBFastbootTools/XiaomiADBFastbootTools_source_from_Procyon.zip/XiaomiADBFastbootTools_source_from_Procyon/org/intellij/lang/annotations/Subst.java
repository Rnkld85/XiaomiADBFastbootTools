// 
// Decompiled by Procyon v0.5.36
// 

package org.intellij.lang.annotations;

import java.lang.annotation.Annotation;

public @interface Subst {
    String value();
}
